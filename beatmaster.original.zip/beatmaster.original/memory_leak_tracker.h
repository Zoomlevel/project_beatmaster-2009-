//------------------------------------------------------------------------------------------------
//
//	memory leak tracker
//
//	overloads global new operator to track down unfreed memory
//	only for debug
//
//------------------------------------------------------------------------------------------------

#ifdef _DEBUG

#if !defined MEMORY_LEAK_TRACKER
#define MEMORY_LEAK_TRACKER

//#include <windows.h>

//------------------------------------------------------------------------------------------------

//add entry to memory allocation list
void AddTrack(DWORD addr, DWORD asize, const char *fname, DWORD lnum);

//remove entry from memory allocation list
void RemoveTrack(DWORD addr);

//write unfreed memory in log file
void DumpUnfreed();

//overloaded global new operator
void * __cdecl operator new(unsigned int size, const char *file, int line);

//overloaded global new [] operator
void * __cdecl operator new[](unsigned int size, const char *file, int line);

//overloaded global delete operator
void __cdecl operator delete(void *p);

//overloaded global delete [] operator
void __cdecl operator delete[](void *p);

//C4291 compiler warning, solution according to documentary
//overloaded delete operator with same arguments as overloaded new operators
void __cdecl operator delete(void *p, const char *file, int line);
void __cdecl operator delete[](void *p, const char *file, int line);

//add arguments to new
#define new new(__FILE__, __LINE__)

#endif

#endif