//------------------------------------------------------------------------------------------------
//
//	memory leak tracker definitions
//
//------------------------------------------------------------------------------------------------

#ifdef _DEBUG

#include <windows.h>
#include <malloc.h>
#include <list>

#define	FMEMORY				"log/memory_log.txt"	//lists unfreed memory
													//(also declared in structs.h for winmain.cpp)

//------------------------------------------------------------------------------------------------

using namespace std;

//contains memory allocation info
typedef struct
{
	DWORD	address;			//address of memory pointer
	DWORD	size;				//size of allocated memory

	char	file[256];			//source file name with allocation
	DWORD	line;				//line within source file with allocation
} ALLOC_INFO;

//stl list, template
typedef list<ALLOC_INFO*> AllocList;

//global alloc info object
AllocList *allocList;

//------------------------------------------------------------------------------------------------
//
//	global AddTrack
//
//	add entry to memory allocation list
//
//------------------------------------------------------------------------------------------------

void AddTrack(DWORD addr,  DWORD asize,  const char *fname, DWORD lnum)
{
	ALLOC_INFO *info;

	if(!allocList)
	{
		allocList	= new(AllocList);
	}

	info			= new(ALLOC_INFO);
	info->address	= addr;

	sprintf (info->file, "%s", fname);

	info->line		= lnum;
	info->size		= asize;

	allocList->insert(allocList->end(), info);
}

//------------------------------------------------------------------------------------------------
//
//	global RemoveTrack
//
//	delete entry from memory allocation list
//
//------------------------------------------------------------------------------------------------

void RemoveTrack(DWORD addr)
{
	AllocList::iterator i;

	if(!allocList)
		return;

	//search list for address of deleted memory and remove entry from list
	for(i = allocList->begin(); i != allocList->end(); ++i)
	{
		if((*i)->address == addr)
		{
			allocList->remove((*i));
			break;
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	global DumpUnfreed
//
//	create file listing unfreed memory
//	also output to debug string message
//
//------------------------------------------------------------------------------------------------

void DumpUnfreed()
{
	AllocList::iterator i;

	DWORD totalSize = 0;

	char buf[1024];

	FILE *pFile;

	if(!allocList)
		return;

	pFile = fopen (FMEMORY, "w");

	for(i = allocList->begin(); i != allocList->end(); i++) 
	{
		sprintf(buf, "%-50s:\t\tLINE %d,\t\tADDRESS %d\t%d byte\n",
				(*i)->file, (*i)->line, (*i)->address, (*i)->size);

		OutputDebugString(buf);

		fprintf (pFile, buf);

		totalSize += (*i)->size;
	}

	if (totalSize > 0)
	{
		sprintf(buf, "-----------------------------------------------------------\n");
		fprintf (pFile, buf);
	}

	OutputDebugString("-----------------------------------------------------------\n");

	sprintf(buf, "Total Unfreed Memory: %d byte\n", totalSize);

	OutputDebugString(buf);
	OutputDebugString("-----------------------------------------------------------\n");

	fprintf (pFile, buf);

	fclose (pFile);
}

//------------------------------------------------------------------------------------------------
//
//	global operator new
//
//	gets source file name with new statement and line within source file as arguments
//	(per define)
//
//------------------------------------------------------------------------------------------------

void * __cdecl operator new(unsigned int size, const char *file, int line)
{
	//allocate memory of size bytes
	void *ptr = (void*)malloc(size);

	AddTrack((DWORD)ptr, size, file, line);

	return(ptr);
}

//------------------------------------------------------------------------------------------------
//
//	global operator new []
//
//	gets source file name with new statement and line within source file as arguments
//	(per define)
//
//------------------------------------------------------------------------------------------------

void * __cdecl operator new[](unsigned int size, const char *file, int line)
{
	void *ptr = (void *)malloc(size);

	AddTrack((DWORD)ptr, size, file, line);

	return(ptr);
}

//------------------------------------------------------------------------------------------------
//
//	global operator delete
//
//------------------------------------------------------------------------------------------------

void __cdecl operator delete(void *p)
{
	RemoveTrack((DWORD)p);

	free(p);
}

void __cdecl operator delete(void *p, const char *file, int line)
{
	RemoveTrack((DWORD)p);

	free(p);
}

//------------------------------------------------------------------------------------------------
//
//	global operator delete []
//
//------------------------------------------------------------------------------------------------

void __cdecl operator delete[](void *p)
{
	RemoveTrack((DWORD)p);

	free(p);
}

void __cdecl operator delete[](void *p, const char *file, int line)
{
	RemoveTrack((DWORD)p);

	free(p);
}

#endif