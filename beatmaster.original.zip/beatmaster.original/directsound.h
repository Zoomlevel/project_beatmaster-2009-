//------------------------------------------------------------------------------------------------
//
//	directsound class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef DIRECTSOUND_H
#define DIRECTSOUND_H						//begin DIRECTSOUND_H

#ifndef DIRECTSOUND_VERSION
#define DIRECTSOUND_VERSION		0x0700		//usded ds version
#endif

#include <dsound.h>							//direct sound header
#include "structs.h"						//memory_leak_tracker

//------------------------------------------------------------------------------------------------

//console data
#define CON_LINEMAX							256			//maximum characters per line
//declare console for directsound
struct console;

//frequency
#define		FREQ_STANDARD					22050
//#define		FREQ_STANDARD					11025
#define		FREQ_BGM						16000

//number of soundbuffers for system sounds
#define	NSBS								15
//number of soundbuffers for player sounds (for each player)
//player.h
#define	NSBP								20

//buffer types
#define		BT_ALL							-1
#define		BT_P1							0
#define		BT_P2							1
#define		BT_SYS							2
#define		BT_BGM							3

//all wave-files in 11.025hz, 8/16bit, mono/stereo
//--> 22.050hz

//system sound indices
#define		S_ERROR							0			//error signal
#define		S_JINGLE						1			//startup jingle
#define		S_MSELECT						2			//menu select
#define		S_MCANCEL						3			//cancel sound
#define		S_MBEAT							4			//beat-master
#define		S_MENTER						5			//menu enter

#define		S_ROUND							6			//round, 1, 2, 3, 4, fight
#define		S_ONE							7
#define		S_TWO							8
#define		S_THREE							9
#define		S_FOUR							10
#define		S_FIGHT							11

#define		S_TICK							12			//ticking clock
#define		S_RET							13

//player sound indices
//player.h
#define		S_ERROR							0

#define		S_JAB							1
#define		S_CROSS							2
#define		S_KICK_FWD						3
#define		S_KICK_SWD						4

#define		S_TAP							5

#define		S_HIT_STD						6
#define		S_HIT_DPART						7
#define		S_HIT_TAP						8
#define		S_HIT_RET						9
#define		S_HIT_BLOOD						10
#define		S_HIT_KO						11
#define		S_HIT_CANCEL					12

#define		S_ATT_LOCKED					13

#define		S_HEALTH						14

#define		S_AGA1							15
#define		S_AGA2							16
#define		S_UHU							17

#define		S_TAUNT1						18
#define		S_TAUNT2						19

//---- error message strings ---------------------------------------------------------------------

//global logger function
//extern bool gf_logger(char *p_message_1, char *p_message_2, bool error);
extern bool gf_logger(bool error, char *format, ...);

extern const char *gp_ErrStr;				//global error string, in winmain.cpp

const char Err_DSDirectSoundCreate[]		= "DirectSoundCreate FAILED";
const char Err_DSSetCooperativeLevel[]		= "DS_SetCooperativeLevel FAILED";
const char Err_DSCreateSoundBuffer[]		= "CreateSoundBuffer FAILED";
const char Err_DSWaveOpenFile[]				= "WaveOpenFile FAILED";
const char Err_DSWaveStartDataRead[]		= "WaveStartDataRead FAILED";
const char Err_DSWaveReadFile[]				= "WaveReadFile FAILED";
const char Err_DSReadMMIO[]					= "ReadMMIO FAILED";
const char Err_DSFillSoundBuffer[]			= "FillSoundBuffer FAILED";
const char Err_DSRestore[]					= "Error Restoring Soundbuffer";

//------------------------------------------------------------------------------------------------

//global program options object
struct program_options;
extern program_options	gProgramOptions;

//------------------------------------------------------------------------------------------------

class directsound
{
//------------------------------------------------------------------------------------------------
//	private directsound elements
//------------------------------------------------------------------------------------------------

private:

	HRESULT				hRet;					//result of dsound methods

	LPDIRECTSOUND		lpDS;					//pointer to sounddevice

	//array of static secondary buffers
	//system sounds and player sounds
	LPDIRECTSOUNDBUFFER	lpDSBStatic_sys[NSBS];
	LPDIRECTSOUNDBUFFER	lpDSBStatic_P1[NSBP];
	LPDIRECTSOUNDBUFFER lpDSBStatic_P2[NSBP];
	//holds the backgroundmusic
	LPDIRECTSOUNDBUFFER	lpDSBStatic_BGM;
	DSBUFFERDESC		dsbdesc;				//contains soundbuffer description

	//objects to open wave files
	WAVEFORMATEX		*m_pwfx;				//defines waveform audio
	HMMIO				m_hmmioIn;				//MM I/O handle for the WAVE
	MMCKINFO			m_ckIn;					//Multimedia RIFF chunk
	MMCKINFO			m_ckInRiff;				//parent chunk info

	//pointers to soundfile names, initialized in constructor
	char				*psoundfile_sys[NSBS];	//system sounds
	char				*psoundfile_p[NSBP];	//player sounds
	char				*psoundfile_bgm;		//pointer to backgroundmusic soundfile

//------------------------------------------------------------------------------------------------
//	private directsound functions
//------------------------------------------------------------------------------------------------

	//----- wave file read help functions --------------------------------------------------------

	//support function for reading from a multimedia i/o stream
	HRESULT ReadMMIO(HMMIO hmmioIn,
					 MMCKINFO* pckInRIFF,
					 WAVEFORMATEX** ppwfxInfo);

	//support function for reading from a multimedia i/o stream
	HRESULT	WaveOpenFile(char *strFileName,
						 HMMIO *phmmioIn,
						 WAVEFORMATEX **ppwfxInfo,
						 MMCKINFO* pckInRIFF);
	
	//routine has to be called before WaveReadFile as it searches for the
	//chunk to descend into for reading, that is, the 'data' chunk.
	HRESULT WaveStartDataRead(HMMIO* phmmioIn,
							  MMCKINFO* pckIn,
							  MMCKINFO* pckInRIFF);
	
	//reads wave data from the wave file. make sure we're descended into
	//the data chunk before calling this function.
	HRESULT WaveReadFile(HMMIO hmmioIn,
						 UINT cbRead,
						 BYTE* pbDest,
						 MMCKINFO* pckIn,
						 UINT* cbActualRead);

	//opens a wave file for reading
    HRESULT Open(CHAR* strFilename);

	//resets internal m_ckIn pointer so reading starts from the beginning of the file again
	HRESULT Reset();
    
	//reads a wave file into a pointer and returns how much read
	//using m_ckIn to determine where to start reading from
	HRESULT Read(UINT nSizeToRead,
				 BYTE* pbData,
				 UINT* pnSizeRead);

	//closes an open wave file
	HRESULT Close();

//------------------------------------------------------------------------------------------------
//	public directsound elements
//------------------------------------------------------------------------------------------------

public:
	//---- timer/option data ---------------------------------------------------------------------

	const options	*p_option;						//pointer to options
	const timer		*p_time;						//pointer to timer

	//---- option data ---------------------------------------------------------------------------
	//replaced by pointer to option object
	//general sound availability set in dataDEF.sound
	//current sound status set in data.sound

	//ds.sound_sys/set assures that no sound is played even if specific function is called
	//so if no sound is available or turned off i don't have to take care for it
//	int			sound_sys;						//indicates if sound is available (1) or not (0)
//	const int	*psound_set;					//pointer to user set sound option (on or off)
//	int			sound_set;

	//---- console variables ---------------------------------------------------------------------

	char				con_dumpmessage[CON_LINEMAX];	//console dump message

	//CLASS_CON_VAR(int, mainvolume);				//volume for all soundbuffers

	//---- hud text data -------------------------------------------------------------------------
	//public for faster ini in mf_initialization

	hud_text			*p_hud_text;					//pointer to hud text

	//---- general data ---------------------------------------------------------------------------

	float freq_speed_last;							//ingame speed last frame
													//to recognize change in ingame speed
													//and to adjust soundbuffer frequency

//------------------------------------------------------------------------------------------------
//	public directsound functions
//------------------------------------------------------------------------------------------------

public:

	//constructor
	directsound();

	//initialization
	bool ds_initialization(HWND hwnd);			//hwnd for SetCooperativeLevel
//						   int *psound);		//pointer to user set sound option

	//cleanup
	void ds_cleanup();

	//restore
	bool ds_restore();

	//set pointer to timer/option/hud data pointer
	void set_data_pointer(options *_options, timer *_timer, hud_text *_hud);

	//plays specified soundbuffer
	void playbuffer(int b_type,						//buffer type
													//0 = player 1
													//1 = player 2
													//2 = menu sounds
													//3 = background music
					int b_index,					//index within buffer
					bool loop = false);				//play sound as loop, default = false

	//stops specified soundbuffer
	void stopbuffer(int b_type,						//buffer type, see playbuffer
					int b_index,					//index to stop
					bool reset = true);				//if to reset play position, default = true

	//!!
	//gets a reference to an byte-sized array which indicates the soundbuffers
	//to be played without loop (0 == don't play, 1 == play)
	//void playbuffer(BYTE sbufferflag[NSB]);

	//stops playing a buffer indexed by i
	//index = -1 (default) all buffers stop
	//void stopbuffer(int i = -1);

	//plays extra background music buffer
	void playbgm(bool loop = false);

	//stops extra background music buffer
	void stopbgm(bool reset = true);

	//sets stereo pan for specified buffer
	void setpan(int b_type, int pan);

	//sets volume of specified soundbuffer
	void setvolume(int b_type, int b_index, int volume);

	//returns volume of specified soundbuffer
	//returns 1 if fails
	long getvolume(int b_type, int b_index);

	//sets frequency of soundbuffers according to user set speed of game
	void setfrequency(int b_type,							//buffer type
					  int b_index,							//index of buffer to set
															//-1 = all buffers of buffer type
					  float s_speed);						//user set speed

	//returns current play position of argumented soundbuffer
	//if error returns -1
	unsigned long getcurrentposition(int b_type, int b_index);

	//adjusts frequency of sound buffers if ingame speed changed
	void freq_process();

	//---- console -------------------------------------------------------------------------------

	//registers console variable
	void RegisterConVars(console *pcon);

	//dumps message in console
	void con_add_message(char *format, ...);

	//clear console message string
	void con_clear();

	//---- hud text ------------------------------------------------------------------------------

	//writes message on hud
	void hud_add_message(int _hud_id, int color, char *format, ...);
	void hud_add_message(char *format, ...);
};

#endif										//end DIRECTSOUND_H
