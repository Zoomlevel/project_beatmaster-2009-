//------------------------------------------------------------------------------------------------
//
//	directinput class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef DIRECTINPUT_H
#define DIRECTINPUT_H						//begin DIRECTINPUT_H

#include <math.h>							//acos, etc.
#include "structs.h"						//for option, timer

//------------------------------------------------------------------------------------------------

//global input devices guids
extern GUID		guid_mouse01;
extern GUID		guid_mouse02;
extern GUID		guid_controller01;
extern GUID		guid_controller02;

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//---- defines -----------------------------------------------------------------------------------

#define	PI			3.141592654f			//pi constant

#define P1			0						//for player input commands
#define P2			1
#define PUNCH		0
#define KICK		1
#define DEFEND		2
#define LEFT		3
#define RIGHT		4
#define SPECIAL		5

#define OFF			0
#define ON			1

#define SLEFT		0						//stance, side
#define SRIGHT		1

//number of player actions
//structs.h
#define	NPAC				38				//number of player actions

//action states
//0 = inactive
//1 = active/pre phase
//2 = active/final phase
//3 = active/cancel phase
#define AS_INACTIVE			0
#define	AS_ACTIVE			1				//used for non phased actions
#define AS_PRE				1				//default angle: 0/179
#define AS_FINAL			2
#define AS_CANCEL			3
#define AS_DONE				4				//used in animator
#define AS_CONTEXT			5				//same as final but for context activated actions

#define AC_DEFAULT			0				//default keyframe
#define AC_HIT				1
#define AC_IDLE_HI			2
#define AC_IDLE_LO			3
#define AC_IDLE_SETS		4
#define AC_STANCE_ARMS		5				//mm_angle and mm_angle_180 hold more data
#define AC_STANCE_FEET		6
#define	AC_CHANGE_SIDE		7
#define	AC_WALK_FWD			8
#define	AC_WALK_BWD			9
#define	AC_WALK_SLIDE_FWD	10
#define	AC_WALK_SLIDE_BWD	11

#define AC_JAB				12
#define AC_JAB_HOOK			13
#define AC_CROSS			14
#define AC_CROSS_HOOK		15
#define AC_KICK_FWD			16
#define AC_KICK_KNEE		17
#define AC_KICK_SWD			18
#define AC_KICK_SWD_HI		19

#define AC_DEFEND			20				//defence button pressed
#define AC_EVADE_HI			21				//move upper torso
#define AC_EVADE_LO			22				//move lower torso/hip/leg
#define AC_DUCK				23
#define AC_EVADE_HI_HOLD	24				//evade hold states
#define AC_EVADE_LO_HOLD	25
#define AC_DUCK_HOLD		26

#define AC_TAP_ARMS			27
#define AC_TAP_ARMS_SET		28
#define AC_TAP_LEG			29				//rise knee to defend
#define	AC_GUARD_ARMS		30
#define AC_GUARD_LEGS		31
#define AC_GUARD_FULL		32
#define AC_PUSH_ARMS		33
#define AC_PULL_ARMS		34

#define AC_TAUNT1			35
#define AC_TAUNT2			36

#define AC_KNOCKOUT			37

//pre and final state angle limit
//offsets from 90 (min) and 270 (max)

#define AL_JAB_MIN				50
#define AL_JAB_MAX				40
//				40		140
//				310		230
#define AL_CROSS_MIN			50			//hi
#define AL_CROSS_MAX			60//55			//low
//				40		140
//				325		215
#define AL_KICK_FWD_MIN			40
#define AL_KICK_FWD_MAX			70
//				50		130
//				340		200
#define AL_KICK_SWD_MIN			30
#define AL_KICK_SWD_MAX			70			//60 swd_hi
//				130		50
//				200		340

#define AL_KICK_KNEE_MIN		70
#define AL_KICK_KNEE_MAX		50
//				20		320
//				160		220

#define AL_PUSH_ARMS_MIN		50
#define AL_PUSH_ARMS_MAX		40
//				40		310
//				140		230
#define AL_PULL_ARMS_MIN		40
#define AL_PULL_ARMS_MAX		50
//				130		220
//				50		320

//---- error message strings ---------------------------------------------------------------------

//global logger function
//extern bool gf_logger(char *p_message_1, char *p_message_2, bool error);
extern bool gf_logger(bool error, char *format, ...);

extern const char *gp_ErrStr;				//global error string, in winmain.cpp

const char Err_DIDirectInputCreateEx[]		= "DirectInputCreateEx FAILED";
const char Err_DICreateDeviceExKB[]			= "DI_CreateDeviceEx_KB FAILED";
const char Err_DICreateDeviceExSM[]			= "DI_CreateDeviceEx_SM FAILED";
const char Err_DICreateDeviceExM1[]			= "DI_CreateDeviceEx_M1 FAILED";
const char Err_DICreateDeviceExM2[]			= "DI_CreateDeviceEx_M2 FAILED";
const char Err_DISetCooperativeLevel[]		= "DI_SetCooperativeLevel FAILED";
const char Err_DISetDataFormatKB[]			= "SetDataFormat_KB FAILED";
const char Err_DISetDataFormatM[]			= "SetDataFormat_M FAILED";
const char Err_DIAcquire[]					= "DID_Acquire FAILED";

//---- structs -----------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//
//	inputstate
//
//------------------------------------------------------------------------------------------------

struct inputstate
{
	const options	*p_option;				//pointer to options
	const timer		*p_time;				//pointer to timer

	BYTE			dikey[256];				//keyboard button state
	BYTE			dikey1D[256];			//kbs but keys can be down only one time before being up again
	BYTE			dikeyUP[256];			//help structure to decide if key was up
	BYTE			dikey1DU[256];			//shows buttons which were down last frame and are now up
	BYTE			dikeyLD[256];			//if button was down last frame
	unsigned int	kbsize;					//size of dikey[256]

	//---- look up tables ------------------------------------------------------------------------

	WORD			*p_lutDIK_ASCII_US;		//DIK to ASCII unshifted
	WORD			*p_lutDIK_ASCII_SH;		//DIK to ASCII shifted
	char			**p_lutDIK_DESC;		//DIK description
	char			**p_lutASCII_DESC;		//ASCII key description
	char			**p_lutFUNC_DESC;		//function description

	int				ascii;					//ascii code of currently pressed DIKey
											//first pressed key only

	//--------------------------------------------------------------------------------------------

	DIMOUSESTATE	dimouse[3];				//0 = system mouse, 1 = usb_1, 2 = usb_2
	DIMOUSESTATE	dimouse1D[3];			//buttons can be down only once before being up again
	DIMOUSESTATE	dimouseUP[3];			//help structure for 1D mouse
	DIMOUSESTATE	dimouse1DU[3];			//shows buttons which were down last frame and are now up
	DIMOUSESTATE	dimouseLD[3];			//if button was down last frame
	unsigned int	msize;					//size of DIMOUSESTATE

	DIJOYSTATE		dicon[2];				//2 controllers
	DIJOYSTATE		dicon1D[2];				//1D state
	DIJOYSTATE		diconUP[2];
	DIJOYSTATE		dicon1DU[2];
	DIJOYSTATE		diconLD[2];
	unsigned int	csize;					//size of DIJOYSTATE

	BYTE			mouse_2usb;				//indicates whether 2 usb mice available (1) or not (0)

	int				ui_assigned[2][8];		//controls assigned by user [P1/P2][PKDLRSUD] see define
	BYTE			ui_state[2][8];			//state of user controls
	BYTE			ui_state1D[2][8];		//1Dstate of user controls

	BYTE			CS[256];				//command state
	BYTE			CS1D[256];				//command state 1D

	LONGLONG		t_dikey_start[256];		//time stamp of key beeing pressed down
	LONGLONG		t_dimouse_start[3][4];	//time stamp of mouse button beeing pressed down
	LONGLONG		t_dicon_start[2][32];	//time stamp of controller button pressed down

	float			t_dikey[256];			//time in seconds key is down
	float			t_dimouse[3][4];		//time in seconds mouse button is down
	float			t_dicon[2][32];			//time in seconds controller button down
	float			t_ui_assigned[2][8];	//time in seconds user assigned input down
	float			t_CS[256];				//time in seconds commands down

	LONGLONG		t_dikey_bh_last[256];		//time stamp for keyhold function
	LONGLONG		t_dimouse_bh_last[3][4];	//time stamp for mousehold function

	float			t_move[2][2];			//move time for both players and both directions (relative, 0 = bwd, 1 = fwd)
											//time in seconds the move key is down
	LONGLONG		t_startmove[2][2];		//starting time of movement for both players and both sides
	LONGLONG		t_move1D[2][2];			//time index of 1D of left/right movement

	LONGLONG		t_laststate1D[2][6][2];	//holds time indices for the two last times the user button was 1D
											//to determine double button presses
	float			t_doubletap[6];			//time between two button presses to count as double tap
											//for all actions

	int				mm_state[2];			//mouse movement state for both players
											//0 = no movement
											//1	= pre (buffer) state
											//2 = final phase
											//3 = canceling

	int				mm_button[2];			//mouse movement button
											//0 = none
											//1 = punch only
											//2 = kick only
											//3 = defend only
											//4 = punch and defend
											//5 = kick and defend
											//6 = special only
	int				mm_button_flag[2];		//down flags for buttons, after an action they must
											//be up before a new action can be executed
											//same as mm_button, this button has to be down
											//before button_flag is cleared
	int				mm_action[2];			//holds current active defined player action

	LONGLONG		def_tstart[2];			//holds start time for simple defense mode
											//when key is down
	int				def_button[2];			//defense button index, same as mm_button
	int				def_fullflag[2];		//set to 1 if full guard (p + k)
											//allows flexible change from guard_full to either
											//guard_arms or guard_legs regardless of which guard
											//was activated first (changes mm_button_flag)
	LONGLONG		t_defdown[2];			//defense button down start time index
											//for auto evade t_ui_assigned is used to get
											//maximum hold down time
											//but for manual evade t_defdown is used which gets
											//the time index of mouse movement

	LONGLONG		mm_t_start[2];			//mouse movement start time

	LONG			mcx[2], mcy[2];			//current mouse movement
	LONG			mmx[2],	mmy[2];			//maximum mouse movement
	float			mm_length_c[2];			//length of current relative movement
	float			mm_length_m[2];			//length of maximum movement
	float			mm_buffer_time[2];		//time in seconds before mouse movement
											//gets registered as pre-state
	ipoint			mm_buffer[2];			//units to move mouse on x and y axis
											//before mouse movement gets registered
	bool			ycontext_up[2];			//true if context action
	bool			ycontext_do[2];
	int				mm_cancel[2];			//true if some mouse movement action was canceled

	int				mm_angle[2];			//angle in degree of mouse movement
											//int for simplicity
											//during pre_state holds pre-defined angle
											//during final_state holds final angle
	int				mm_angle_180[2];		//angle with values from 0 to 179 only
											//between 271 and 90 counts as right (271 = 0)
											//between 270 and 91 counts as left (absolut) (270 = 0)
	int				mm_angle_pre[2];		//angles of pre state
	int				mm_angle_180_pre[2];	//for comparison with final state
	int				mm_angle_rev[2];		//reverse flag, set true for cross/kick_swd and all
											//actions which are executed in backward direction

	int				PA[2][NPAC];			//holds defined player actions o 1D basis

	//---- hud text data -------------------------------------------------------------------------

	hud_text		*p_hud_text;					//pointer to hud text

	//---- developer data ------------------------------------------------------------------------

	int								dev_i;						//can be filled with various data
	float							dev_f;						//just used to check certain values

	int								*dev_pi;
	float							*dev_pf;

	//---- constructor ---------------------------------------------------------------------------

	inputstate()
	{
		//timer/option pointer
		p_option		= NULL;
		p_time			= NULL;

		//clear all
		kbsize		= sizeof(dikey);
		ZeroMemory(&dikey, sizeof(dikey));
		ZeroMemory(&dikeyUP, sizeof(dikeyUP));
		ZeroMemory(&dikey1D, sizeof(dikey1D));
		ZeroMemory(&dikey1DU, sizeof(dikey1DU));
		ZeroMemory(&dikeyLD, sizeof(dikeyLD));

		p_lutDIK_ASCII_US		= NULL;
		p_lutDIK_ASCII_SH		= NULL;
		p_lutDIK_DESC			= NULL;
		p_lutASCII_DESC			= NULL;
		p_lutFUNC_DESC			= NULL;

		ascii		= 0;

		//only the size of one DIMOUSESTATE structure (for GetDeviceState)
		msize		= sizeof(dimouse[0]);
		//size of whole array
		ZeroMemory(&dimouse, sizeof(dimouse));
		ZeroMemory(&dimouseUP, sizeof(dimouse));
		ZeroMemory(&dimouse1D, sizeof(dimouse));
		ZeroMemory(&dimouse1DU, sizeof(dimouse));
		ZeroMemory(&dimouseLD, sizeof(dimouse));

		csize		= sizeof(dicon[0]);
		ZeroMemory(&dicon, sizeof(dicon));
		ZeroMemory(&dicon1D, sizeof(dicon));
		ZeroMemory(&diconUP, sizeof(dicon));
		ZeroMemory(&dicon1DU, sizeof(dicon));
		ZeroMemory(&diconLD, sizeof(dicon));

		ZeroMemory(&ui_assigned, sizeof(ui_assigned));
		ZeroMemory(&ui_state, sizeof(ui_state));
		ZeroMemory(&ui_state1D, sizeof(ui_state1D));

		ZeroMemory(&CS, sizeof(CS));
		ZeroMemory(&CS1D, sizeof(CS1D));

		ZeroMemory(&t_dikey_start, sizeof(t_dikey_start));
		ZeroMemory(&t_dimouse_start, sizeof(t_dimouse_start));
		ZeroMemory(&t_dicon_start, sizeof(t_dicon_start));
		ZeroMemory(&t_dikey, sizeof(t_dikey));
		ZeroMemory(&t_dimouse, sizeof(t_dimouse));
		ZeroMemory(&t_dicon, sizeof(t_dicon));
		ZeroMemory(&t_ui_assigned, sizeof(t_ui_assigned));
		ZeroMemory(&t_CS, sizeof(t_CS));

		ZeroMemory(&t_dikey_bh_last, sizeof(t_dikey_bh_last));
		ZeroMemory(&t_dimouse_bh_last, sizeof(t_dimouse_bh_last));

		ZeroMemory(&t_move, sizeof(t_move));
		ZeroMemory(&t_startmove, sizeof(t_startmove));
		ZeroMemory(&t_move1D, sizeof(t_move1D));
		ZeroMemory(&t_laststate1D, sizeof(t_laststate1D));

		//double tap times
		t_doubletap[PUNCH]		= 0.3f;
		t_doubletap[KICK]		= 1.0f;
		t_doubletap[DEFEND]		= 0.3f;
		t_doubletap[LEFT]		= 0.3f;
		t_doubletap[RIGHT]		= 0.3f;
		t_doubletap[SPECIAL]	= 0.4f;

		ZeroMemory(&def_tstart, sizeof(def_tstart));
		ZeroMemory(&def_button, sizeof(def_button));
		ZeroMemory(&def_fullflag, sizeof(def_fullflag));
		ZeroMemory(&t_defdown, sizeof(t_defdown));

		ZeroMemory(&mm_state, sizeof(mm_state));
		ZeroMemory(&mm_button, sizeof(mm_button));
		ZeroMemory(&mm_button_flag, sizeof(mm_button_flag));
		ZeroMemory(&mm_action, sizeof(mm_action));
		ZeroMemory(&mm_t_start, sizeof(mm_t_start));
		ZeroMemory(&mcx, sizeof(mcx));
		ZeroMemory(&mcy, sizeof(mcy));
		ZeroMemory(&mmx, sizeof(mmx));
		ZeroMemory(&mmy, sizeof(mmy));

		mm_buffer_time[P1]	= mm_buffer_time[P2]	= 0.02f;
		mm_buffer[P1].x = mm_buffer[P2].x = mm_buffer[P1].y = mm_buffer[P2].y = 0;

		ZeroMemory(&ycontext_up, sizeof(ycontext_up));
		ZeroMemory(&ycontext_do, sizeof(ycontext_do));
		ZeroMemory(&mm_cancel, sizeof(mm_cancel));

		ZeroMemory(&mm_length_c, sizeof(mm_length_c));
		ZeroMemory(&mm_length_m, sizeof(mm_length_m));
		ZeroMemory(&mm_angle, sizeof(mm_angle));
		ZeroMemory(&mm_angle_180, sizeof(mm_angle_180));
		ZeroMemory(&mm_angle_pre, sizeof(mm_angle_pre));
		ZeroMemory(&mm_angle_180_pre, sizeof(mm_angle_180_pre));
		ZeroMemory(&mm_angle_rev, sizeof(mm_angle_rev));

		ZeroMemory(&PA, sizeof(PA));

		//---- hud data --------------------------------------------------------------------------

		p_hud_text				= NULL;

		dev_i	= 0;
		dev_f	= 0;
		dev_pi	= NULL;
		dev_pf	= NULL;
	};

	//---- destructor ----------------------------------------------------------------------------

	~inputstate()
	{
		//---- LUT -------------------------------------------------------------------------------

		delete [] p_lutDIK_ASCII_US;		p_lutDIK_ASCII_US		= NULL;
		delete [] p_lutDIK_ASCII_SH;		p_lutDIK_ASCII_SH		= NULL;
		delete [] p_lutDIK_DESC;			p_lutDIK_DESC			= NULL;
		delete [] p_lutASCII_DESC;			p_lutASCII_DESC			= NULL;
		delete [] p_lutFUNC_DESC;			p_lutFUNC_DESC			= NULL;
	};

	//---- initialization ------------------------------------------------------------------------
	//called by master_frame::initialization after di-setup

	bool initialization(options *_options, timer *_timer, hud_text *_hud)
	{
		p_option			= _options;
		p_time				= _timer;
		p_hud_text			= _hud;

		//mouse indicates if two usb mice are available (2) or not (<= 1)
		mouse_2usb = p_option->dataDEF.mouseflag;

		//copy user control settings from option.data into
		//own version of it (ui_assigned)
/*		ui_assigned[P1][PUNCH]		= p_option->data.CBT[cP1PUNCH];
		ui_assigned[P1][KICK]		= p_option->data.CBT[cP1KICK];
		ui_assigned[P1][DEFEND]		= p_option->data.CBT[cP1DEFEND];
		ui_assigned[P1][LEFT]		= p_option->data.CBT[cP1LEFT];
		ui_assigned[P1][RIGHT]		= p_option->data.CBT[cP1RIGHT];
		ui_assigned[P1][SPECIAL]	= p_option->data.CBT[cP1SPECIAL];
		ui_assigned[P2][PUNCH]		= p_option->data.CBT[cP2PUNCH];
		ui_assigned[P2][KICK]		= p_option->data.CBT[cP2KICK];
		ui_assigned[P2][DEFEND]		= p_option->data.CBT[cP2DEFEND];
		ui_assigned[P2][LEFT]		= p_option->data.CBT[cP2LEFT];
		ui_assigned[P2][RIGHT]		= p_option->data.CBT[cP2RIGHT];
		ui_assigned[P2][SPECIAL]	= p_option->data.CBT[cP2SPECIAL];*/
		/*for (register int player = 0; player < 2; ++player)
			for (register int action = 0; action < 6; ++action)
				ui_assigned[player][action] = p_option->data.ckey[player][action];*/

		//---- LUT -----------------------------------------------------------------------------------

		p_lutDIK_ASCII_US		= new WORD[256];	if (p_lutDIK_ASCII_US == NULL)	return false;
		p_lutDIK_ASCII_SH		= new WORD[256];	if (p_lutDIK_ASCII_SH == NULL)	return false;
		p_lutDIK_DESC			= new char*[256];	if (p_lutDIK_DESC == NULL)		return false;
		p_lutASCII_DESC			= new char*[256];	if (p_lutASCII_DESC == NULL)	return false;
		p_lutFUNC_DESC			= new char*[256];	if (p_lutFUNC_DESC == NULL)		return false;

		fill_DIKASCII_LUT(p_lutDIK_ASCII_US, 0);
		fill_DIKASCII_LUT(p_lutDIK_ASCII_SH, 1);
		fill_KEYDESC_LUT(p_lutDIK_DESC, 1);
		fill_FUNCDESC_LUT(p_lutFUNC_DESC);
	//	fill_KEYDESC_LUT(p_lutASCII_DESC, 1);

		return(true);
	};

	//---- cancel_paction ------------------------------------------------------------------------
	//cancels argumented player action

	void cancel_paction(int p, int i)				//player and index to cancel
	{
		//cancel specified action
		PA[p][i] = AS_INACTIVE;

		//cancel mouse movement
		//for those actions no mouse movement cancel necessary
		if (i == AC_IDLE_HI ||
			i == AC_IDLE_LO ||
			i == AC_STANCE_ARMS ||
			i == AC_STANCE_FEET ||
			i == AC_CHANGE_SIDE ||
			i == AC_WALK_FWD ||
			i == AC_WALK_BWD ||
			i == AC_WALK_SLIDE_FWD ||
			i == AC_WALK_SLIDE_BWD ||
			i == AC_DEFEND)
			return;
		else
		{
			def_tstart[p]		= 0;
			def_button[p]		= 0;
			def_fullflag[p]		= 0;
			t_defdown[p]		= 0;

			//cancel mousemovement
			mm_button_flag[p]	= mm_button[p];

			mm_state[p]			= 0;
			mm_t_start[p]		= 0;
			mm_button[p]		= 0;
			mcx[p]	= mcy[p]	= 0;
			mmx[p]	= mmy[p]	= 0;
			ycontext_up[p]		= false;
			ycontext_do[p]		= false;

			mm_length_c[p]		= 0;
			mm_length_m[p]		= 0;
			mm_angle_rev[p]		= 0;
		}
	};

	//---- key functions -------------------------------------------------------------------------
	//they return true if specified key is pressed (or mouse moved) else false

	bool key(BYTE key)
	{
		if (dikey[key] & 0x80)			return true;
		else							return false;
	};

	bool key1D(BYTE key)
	{
		if (dikey1D[key] & 0x80)		return true;
		else							return false;
	};

	bool keyUP(BYTE key)
	{
		if (dikeyUP[key] & 0x80)		return true;
		else							return false;
	};

	bool key1DU(BYTE key)
	{
		if (dikey1DU[key] & 0x80)		return true;
		else							return false;
	};

	bool keyLD(BYTE key)
	{
		if (dikeyLD[key] & 0x80)		return true;
		else							return false;
	};

	bool mouse(int mouse, bool x, bool y, bool z)
	{
		if (x)
			if (dimouse[mouse].lX != 0)					return(true);

		if (y)
			if (dimouse[mouse].lY != 0)					return(true);

		if (z)
			if (dimouse[mouse].lZ != 0)					return(true);

		return(false);
	};

	bool mouse(int mouse, int button)
	{
		if (dimouse[mouse].rgbButtons[button] & 0x80)		return true;
		else												return false;
	};

	bool mouse1D(int mouse, int button)
	{
		if (dimouse1D[mouse].rgbButtons[button] & 0x80)		return true;
		else												return false;
	};

	bool mouseUP(int mouse, int button)
	{
		if (dimouseUP[mouse].rgbButtons[button] & 0x80)		return true;
		else												return false;
	};

	bool mouse1DU(int mouse, int button)
	{
		if (dimouse1DU[mouse].rgbButtons[button] & 0x80)	return true;
		else												return false;
	};

	bool mouseLD(int mouse, int button)
	{
		if (dimouseLD[mouse].rgbButtons[button] & 0x80)		return true;
		else												return false;
	};

	//user input keys
	bool ui(int player, int command)
	{
		if (ui_state[player][command] & 0x80)				return true;
		else												return false;
	};

	bool ui1D(int player, int command)
	{
		if (ui_state1D[player][command] & 0x80)				return true;
		else												return false;
	};

	bool COM(int command)
	{
		if (CS[command] & 0x80)								return true;
		else												return false;
	};

	bool COM1D(int command)
	{
		if (CS1D[command] & 0x80)							return true;
		else												return false;
	};

	//returns true if any mouse button pressed
	//(assuming all mice input is added to mouse[0]
	bool mouseALL()
	{
		if (dimouse[0].rgbButtons[0] & 0x80 ||
			dimouse[0].rgbButtons[1] & 0x80 ||
			dimouse[0].rgbButtons[2] & 0x80 ||
			dimouse[0].rgbButtons[3] & 0x80)
			return(true);
		else
			return(false);
	};
	bool mouse1DALL()
	{
		if (dimouse1D[0].rgbButtons[0] & 0x80 ||
			dimouse1D[0].rgbButtons[1] & 0x80 ||
			dimouse1D[0].rgbButtons[2] & 0x80 ||
			dimouse1D[0].rgbButtons[3] & 0x80)
			return(true);
		else
			return(false);
	};
	bool mouse1DUALL()
	{
		if (dimouse1DU[0].rgbButtons[0] & 0x80 ||
			dimouse1DU[0].rgbButtons[1] & 0x80 ||
			dimouse1DU[0].rgbButtons[2] & 0x80 ||
			dimouse1DU[0].rgbButtons[3] & 0x80)
			return(true);
		else
			return(false);
	};

	//returns true if any keyboard button pressed
	bool keyALL()
	{
		for (register int i = 0; i < 256; ++i)
			if (dikey[i] & 0x80)
				return(true);
		return(false);
	};
	bool key1DALL()
	{
		for (register int i = 0; i < 256; ++i)
			if (dikey1D[i] & 0x80)
				return(true);
		return(false);
	};
	bool key1DUALL()
	{
		for (register int i = 0; i < 256; ++i)
			if (dikey1DU[i] & 0x80)
				return(true);
		return(false);
	};

	//returns 1 t_sec-times a second after specified key
	//has been pressed at least t_min seconds
	int keyhold(BYTE key, float t_sec = 2.0f, float t_min = 0.75f)
	{
		//verify, 0.00001f = every 27.7hours
		//verify arguments
		if (key < 0 || key > 255 ||
			t_sec <= 0 ||
			t_min < 0)
			return(0);

		//button pressed and for at least buffer time
		if (dikey[key] & 0x80 && t_dikey[key] >= t_min)
		{
			//if at least 1 / t_sec a seconds since last update passed
			if ((p_time->current - t_dikey_bh_last[key]) / (double)p_time->freq >= 1.0f / t_sec)
			{
				//update last update and return 1
				t_dikey_bh_last[key] = p_time->current;
				return(1);
			}
			else
				//not enough time since last update passed
				return(0);
		}
		else
		{
			//button not pressed at least t_min seconds
			return(0);
		}
	};

	//hold linear over time
	//returns 1 between t_sec_min-times a second and t_sec_max-times a second after specified key
	//has been pressed at least t_min seconds or at most t_max seconds
	int keyhold_t(BYTE key,
				  float t_sec_min = 1.0f, float t_sec_max = 5.0f,
				  float t_min = 0.75f, float t_max = 1.75f)
	{
		//verify arguments
		if (key < 0 || key > 255 ||
			t_sec_min <= 0 || t_sec_max <= 0 ||
			t_min < 0 || t_max < 0)
			return(0);
		if (t_sec_min > t_sec_max ||
			t_min > t_max)
			return(0);

		//button pressed and for at least buffer time
		if (dikey[key] & 0x80 && t_dikey[key] >= t_min)
		{
			//get percentage between 0 and 1.0 of how much of the argumented time range has passed
			//and linearly adjust update times
			float x		= (t_dikey[key] - t_min) / (t_max - t_min);
			if (x > 1.0f)	x = 1.0f;
			//linear
			float _ts	= t_sec_min + ((t_sec_max - t_sec_min) * x);
			//float _ts	= t_sec_min + ((t_sec_max - t_sec_min) * ((t_dikey[key] - t_min) / (t_max - t_min)));

			//if at least 1 / t_sec a seconds since last update passed
			if ((p_time->current - t_dikey_bh_last[key]) / (double)p_time->freq >= 1.0f / _ts)
			{
				//update last update and return 1
				t_dikey_bh_last[key] = p_time->current;
				return(1);
			}
			else
				//not enough time since last update passed
				return(0);
		}
		else
		{
			//button not pressed at least t_min seconds
			return(0);
		}
	};

	//returns 1 t_sec-times a second after specified button of specified mouse
	//has been pressed at least t_min seconds
	int mousehold(int mouse, int button, float t_sec = 2.0f, float t_min = 0.75f)
	{
		//verify arguments
		if (mouse < 0 || mouse > 2 ||
			button < 0 || button > 3 ||
			t_sec <= 0 ||
			t_min < 0)
			return(0);

		//button pressed and for at least buffer time
		if (dimouse[mouse].rgbButtons[button] & 0x80 && t_dimouse[mouse][button] >= t_min)
		{
			//if at least 1 / t_sec a seconds since last update passed
			if ((p_time->current - t_dimouse_bh_last[mouse][button]) / (double)p_time->freq >= 1.0f / t_sec)
			{
				//update last update and return 1
				t_dimouse_bh_last[mouse][button] = p_time->current;
				return(1);
			}
			else
				//not enough time since last update passed
				return(0);
		}
		else
		{
			//button not pressed at least t_min seconds
			return(0);
		}
	};

	//returns 1 between t_sec_min-times a second and t_sec_max-times a second after specified button
	//of specified mouse has been pressed at least t_min and at most t_max seconds
	int mousehold_t(int mouse, int button,
					float t_sec_min = 2.0f, float t_sec_max = 5.0f,
					float t_min = 0.75f, float t_max = 1.75f)
	{
		//verify arguments
		if (mouse < 0 || mouse > 2 ||
			button < 0 || button > 3 ||
			t_sec_min <= 0 || t_sec_max <= 0 ||
			t_min < 0 || t_max < 0)
			return(0);
		if (t_sec_min > t_sec_max ||
			t_min > t_max)
			return(0);

		//button pressed and for at least buffer time
		if (dimouse[mouse].rgbButtons[button] & 0x80 && t_dimouse[mouse][button] >= t_min)
		{
			//get percentage between 0 and 1.0 of how much of the argumented time range has passed
			//and linearly adjust update times
			float x		= (t_dimouse[mouse][button] - t_min) / (t_max - t_min);
			if (x > 1.0f)	x = 1.0f;
			//linear
			float _ts	= t_sec_min + ((t_sec_max - t_sec_min) * x);
			//float _ts	= t_sec_min + ((t_sec_max - t_sec_min) * ((t_dimouse[mouse][button] - t_min) / (t_max - t_min)));

			//if at least 1 / t_sec a seconds since last update passed
			if ((p_time->current - t_dimouse_bh_last[mouse][button]) / (double)p_time->freq >= 1.0f / _ts)
			{
				//update last update and return 1
				t_dimouse_bh_last[mouse][button] = p_time->current;
				return(1);
			}
			else
				//not enough time since last update passed
				return(0);
		}
		else
		{
			//button not pressed at least t_min seconds
			return(0);
		}
	};

	//!!
/*	bool DS(int player, int command)
	{
		if (player == P1)
		{
			if (command == PUNCH)		command = cP1PUNCH;		else
			if (command == KICK)		command = cP1KICK;		else
			if (command == DEFEND)		command = cP1DEFEND;	else
			if (command == LEFT)		command = cP1LEFT;		else
			if (command == RIGHT)		command = cP1RIGHT;		else
			if (command == SPECIAL)		command = cP1SPECIAL;
		}
		else
		{
			if (command == PUNCH)		command = cP2PUNCH;		else
			if (command == KICK)		command = cP2KICK;		else
			if (command == DEFEND)		command = cP2DEFEND;	else
			if (command == LEFT)		command = cP2LEFT;		else
			if (command == RIGHT)		command = cP2RIGHT;		else
			if (command == SPECIAL)		command = cP2SPECIAL;
		}
	};*/

	//---- process -------------------------------------------------------------------------------
	//dikey holds the current keyboard state (keys up or down)
	//dikey1D is the current keyboard state but a key can be only down one time (like
	//one frame), than it must be up before it can be down again and after beeing down
	//it counts as up no matter if it still hold down
	//dikeyUP indicates whether or not a key was up after beeing down
	//
	//this is also done for all mouse buttons
	//
	//also the function fills ui_state and ui_state1D structures with appropriate
	//data
	//
	//finally the function processes mouse movment input

	void process(bool con_state,				//console state
												//if on, no further input processing
				 int sip1, int sip2,			//side indices for both players
												//0 = left of other player
												//1 = right of other player
				 int p1x, int p2x)				//x-coordinates of both players to calculate difference
	{
		//set side indices into array for two players for easier use
		int		si[2] = {sip1, sip2};
		//set x-positions of both players
		int		px[2] = {p1x, p2x};

		//---- keyboard buttons ------------------------------------------------------------------

		//for all keys
		for (register int i = 0; i < 256; ++i)
		{
			//if key is down
			if (dikey[i] & 0x80)
				//and key wasn't down one frame earlier
				if (dikey1D[i] == 0)
					//and was up at least one frame earlier
					if (dikeyUP[i] & 0x80)
						//key is down
						dikey1D[i] = dikey[i];
					else
						//else it's up
						dikey1D[i] = 0;
				else
					dikey1D[i] = 0;
			else
				dikey1D[i] = 0;

			//if key is up, set UP flag to up, else to down
			//this is done after the check above so it gets
			//the dikey data before this is updatet (well next frame)
			if (dikey[i] == 0)
				dikeyUP[i] = 0x80;
			else
				dikeyUP[i] = 0;

			//set 1DU if button was down last frame and is up now
			if (dikeyLD[i] & 0x80 && dikey[i] == 0)
				dikey1DU[i] = 0x80;
			else
				dikey1DU[i] = 0;

			//if button down set LD
			//this is done after the above check to always have data for next frame
			if (dikey[i] & 0x80)
				dikeyLD[i] = 0x80;
			else
				dikeyLD[i] = 0;
		}

		//---- ascii code ------------------------------------------------------------------------

		//reset ascii
		ascii		= 0;

		//for all keys
		for (i = 0; i < 256; ++i)
		{
			//first key that is down, ignoring shift
			if (dikey1D[i] & 0x80 && i != DIK_LSHIFT && i != DIK_RSHIFT)
			{
				//shifted ascii
				if (dikey[DIK_LSHIFT] & 0x80 || dikey[DIK_RSHIFT] & 0x80)
					ascii	= p_lutDIK_ASCII_SH[i];
				else
				//unshifted ascii
					ascii	= p_lutDIK_ASCII_US[i];

				break;
			}
		}

		//---- mice buttons ----------------------------------------------------------------------

		//for all 4 buttons
		for (i = 0; i < 4; ++i)
		{
			//---- system mouse ------------------------------------------------------------------

			//if button is down
			if (dimouse[0].rgbButtons[i] & 0x80)
				//and button wasn't down one frame earlier
				if (dimouse1D[0].rgbButtons[i] == 0)
					//and was up at least one frame earlier
					if (dimouseUP[0].rgbButtons[i] & 0x80)
						//button is down
						dimouse1D[0].rgbButtons[i] = dimouse[0].rgbButtons[i];
					else
						//else it's up
						dimouse1D[0].rgbButtons[i] = 0;
				else
					dimouse1D[0].rgbButtons[i] = 0;
			else
				dimouse1D[0].rgbButtons[i] = 0;

			//if button is up, set UP flag to up, else to down
			//this is done after the check above so it gets
			//the dimouse data before this is updatet (well, next frame)
			if (dimouse[0].rgbButtons[i] == 0)
				dimouseUP[0].rgbButtons[i] = 0x80;
			else
				dimouseUP[0].rgbButtons[i] = 0;

			//set 1DU if button was down last frame and is up now
			if (dimouseLD[0].rgbButtons[i] & 0x80 && dimouse[0].rgbButtons[i] == 0)
				dimouse1DU[0].rgbButtons[i] = 0x80;
			else
				dimouse1DU[0].rgbButtons[i] = 0;

			//if button down set LD
			//this is done after the above check to always have data for next frame
			if (dimouse[0].rgbButtons[i] & 0x80)	dimouseLD[0].rgbButtons[i] = 0x80;
			else									dimouseLD[0].rgbButtons[i] = 0;

			//---- usb 1 mouse -------------------------------------------------------------------

			//if button is down
			if (dimouse[1].rgbButtons[i] & 0x80)
				//and button wasn't down one frame earlier
				if (dimouse1D[1].rgbButtons[i] == 0)
					//and was up at least one frame earlier
					if (dimouseUP[1].rgbButtons[i] & 0x80)
						//button is down
						dimouse1D[1].rgbButtons[i] = dimouse[1].rgbButtons[i];
					else
						//else it's up
						dimouse1D[1].rgbButtons[i] = 0;
				else
					dimouse1D[1].rgbButtons[i] = 0;
			else
				dimouse1D[1].rgbButtons[i] = 0;

			//if button is up, set UP flag to up, else to down
			//this is done after the check above so it gets
			//the dimouse data before this is updatet (well, next frame)
			if (dimouse[1].rgbButtons[i] == 0)
				dimouseUP[1].rgbButtons[i] = 0x80;
			else
				dimouseUP[1].rgbButtons[i] = 0;

			//set 1DU if button was down last frame and is up now
			if (dimouseLD[1].rgbButtons[i] & 0x80 && dimouse[1].rgbButtons[i] == 0)
				dimouse1DU[1].rgbButtons[i] = 0x80;
			else
				dimouse1DU[1].rgbButtons[i] = 0;

			//if button down set LD
			//this is done after the above check to always have data for next frame
			if (dimouse[1].rgbButtons[i] & 0x80)	dimouseLD[1].rgbButtons[i] = 0x80;
			else									dimouseLD[1].rgbButtons[i] = 0;

			//---- usb 2 mouse -------------------------------------------------------------------

			//if button is down
			if (dimouse[2].rgbButtons[i] & 0x80)
				//and button wasn't down one frame earlier
				if (dimouse1D[2].rgbButtons[i] == 0)
					//and was up at least one frame earlier
					if (dimouseUP[2].rgbButtons[i] & 0x80)
						//button is down
						dimouse1D[2].rgbButtons[i] = dimouse[2].rgbButtons[i];
					else
						//else it's up
						dimouse1D[2].rgbButtons[i] = 0;
				else
					dimouse1D[2].rgbButtons[i] = 0;
			else
				dimouse1D[2].rgbButtons[i] = 0;

			//if button is up, set UP flag to up, else to down
			//this is done after the check above so it gets
			//the dimouse data before this is updatet (well, next frame)
			if (dimouse[2].rgbButtons[i] == 0)
				dimouseUP[2].rgbButtons[i] = 0x80;
			else
				dimouseUP[2].rgbButtons[i] = 0;

			//set 1DU if button was down last frame and is up now
			if (dimouseLD[2].rgbButtons[i] & 0x80 && dimouse[2].rgbButtons[i] == 0)
				dimouse1DU[2].rgbButtons[i] = 0x80;
			else
				dimouse1DU[2].rgbButtons[i] = 0;

			//if button down set LD
			//this is done after the above check to always have data for next frame
			if (dimouse[2].rgbButtons[i] & 0x80)	dimouseLD[2].rgbButtons[i] = 0x80;
			else									dimouseLD[2].rgbButtons[i] = 0;
		}

		//---- mouse redirect --------------------------------------------------------------------

		//only for directinput
		//if no 2 usb mice available use only data of system mouse
		if (INPUTTYPE == IP_DI && mouse_2usb < 2)
		{
			dimouse[1]		= dimouse[0];
			dimouseUP[1]	= dimouseUP[0];
			dimouse1D[1]	= dimouse1D[0];
//			dimouse[2]		= dimouse[1]	= dimouse[0];
//			dimouseUP[2]	= dimouseUP[1]	= dimouseUP[0];
//			dimouse1D[2]	= dimouse1D[1]	= dimouse1D[0];
		}

		//---- controller buttons ----------------------------------------------------------------

		//for all 32 buttons
		for (i = 0; i < 32; ++i)
		{
			//for both controllers
			for (register int c = 0; c < 2; ++c)
			{
				//if button is down
				if (dicon[c].rgbButtons[i] & 0x80)
					//and button wasn't down one frame earlier
					if (dicon1D[c].rgbButtons[i] == 0)
						//and was up at least one frame earlier
						if (diconUP[c].rgbButtons[i] & 0x80)
							//button is down
							dicon1D[c].rgbButtons[i] = dicon[c].rgbButtons[i];
						else
							//else it's up
							dicon1D[c].rgbButtons[i] = 0;
					else
						dicon1D[c].rgbButtons[i] = 0;
				else
					dicon1D[c].rgbButtons[i] = 0;

				//if button is up, set UP flag to up, else to down
				//this is done after the check above so it gets
				//the dicon data before this is updatet (well, next frame)
				if (dicon[c].rgbButtons[i] == 0)
					diconUP[c].rgbButtons[i] = 0x80;
				else
					diconUP[c].rgbButtons[i] = 0;

				//set 1DU if button was down last frame and is up now
				if (diconLD[c].rgbButtons[i] & 0x80 && dicon[c].rgbButtons[i] == 0)
					dicon1DU[c].rgbButtons[i] = 0x80;
				else
					dicon1DU[c].rgbButtons[i] = 0;

				//if button down set LD
				//this is done after the above check to always have data for next frame
				if (dicon[c].rgbButtons[i] & 0x80)	diconLD[c].rgbButtons[i] = 0x80;
				else								diconLD[c].rgbButtons[i] = 0;
			}
		}

		//---- key and button times --------------------------------------------------------------

		//keyboard
		for (i = 0; i < 256; ++i)
		{
			//if key is down
			if (dikey[i] & 0x80)
			{
				//if key was up last frame
				if (dikey1D[i] & 0x80)
					//set start index
					t_dikey_start[i] = p_time->current;
				else
				//else calculate down time
					t_dikey[i] = (float)(p_time->current - t_dikey_start[i]) / p_time->freq;
			}
			else
			{
				//key up, reset times
				t_dikey[i]			= 0;
				//reset button hold time
				t_dikey_bh_last[i]	= 0;
			}
		}

		//mice
		//for all three mice
		for (register int m = 0; m < 3; ++m)
		{
			//for all buttons
			for (register int i = 0; i < 4; ++i)
			{
				//if button is down
				if (dimouse[m].rgbButtons[i] & 0x80)
				{
					//if button was up last frame
					if (dimouse1D[m].rgbButtons[i] & 0x80)
						//set start index
						t_dimouse_start[m][i] = p_time->current;
					else
					//else calculate down time
						t_dimouse[m][i] = (float)(p_time->current - t_dimouse_start[m][i]) / p_time->freq;
				}
				else
				{
					//button up, reset times
					t_dimouse[m][i]			= 0;
					//reset button hold time
					t_dimouse_bh_last[m][i]	= 0;
				}
			}
		}

		//controller
		for (register int c = 0; c < 2; ++c)
		{
			//for all buttons
			for (register int i = 0; i < 32; ++i)
			{
				//if button is down
				if (dicon[c].rgbButtons[i] & 0x80)
				{
					//if button was up last frame
					if (dicon1D[c].rgbButtons[i] & 0x80)
						//set start index
						t_dicon_start[c][i] = p_time->current;
					else
					//else calculate down time
						t_dicon[c][i] = (float)(p_time->current - t_dicon_start[c][i]) / p_time->freq;
				}
				else
				{
					//button up, reset times
					t_dicon[c][i]	= 0;
				}
			}
		}

		//---- commands --------------------------------------------------------------------------
		//and time

		//reset
		ZeroMemory(&CS, sizeof(CS));
		ZeroMemory(&CS1D, sizeof(CS1D));

		//for all commands
		for (c = 0; c < 256; ++c)
		{
			//bound to keyboard
			if (p_option->data.CBT[c] >= 0 && p_option->data.CBT[c] < 256)
			{
				CS[c]		= dikey[p_option->data.CBT[c]];
				CS1D[c]		= dikey1D[p_option->data.CBT[c]];
				t_CS[c]		= t_dikey[p_option->data.CBT[c]];
			}

			//bound to mouse 1
			if (p_option->data.CBT[c] >= 300 && p_option->data.CBT[c] <= 303)
			{
				CS[c]		= dimouse[1].rgbButtons[p_option->data.CBT[c] - 300];
				CS1D[c]		= dimouse1D[1].rgbButtons[p_option->data.CBT[c] - 300];
				//!! bug
				//t_CS[c]		= dimouse[1].rgbButtons[p_option->data.CBT[c] - 300];
				t_CS[c]		= t_dimouse[1][p_option->data.CBT[c] - 300];
			}

			//bound to mouse 2
			if (p_option->data.CBT[c] >= 400 && p_option->data.CBT[c] <= 403)
			{
				CS[c]		= dimouse[2].rgbButtons[p_option->data.CBT[c] - 400];
				CS1D[c]		= dimouse1D[2].rgbButtons[p_option->data.CBT[c] - 400];
				t_CS[c]		= t_dimouse[2][p_option->data.CBT[c] - 400];
			}

			//bound to mousewheel 1
			//!! no times?
			if (p_option->data.CBT[c] >= 305 && p_option->data.CBT[c] <= 306)
			{
				//up
				if (p_option->data.CBT[c] == 305)
					if (dimouse[1].lZ < 0)		CS[c]	= CS1D[c]	= 0x80;
				//down
				if (p_option->data.CBT[c] == 306)
					if (dimouse[1].lZ > 0)		CS[c]	= CS1D[c]	= 0x80;
			}

			//bound to mousewheel 2
			if (p_option->data.CBT[c] >= 405 && p_option->data.CBT[c] <= 406)
			{
				//up
				if (p_option->data.CBT[c] == 405)
					if (dimouse[2].lZ < 0)		CS[c]	= CS1D[c]	= 0x80;
				//down
				if (p_option->data.CBT[c] == 406)
					if (dimouse[2].lZ > 0)		CS[c]	= CS1D[c]	= 0x80;
			}

			//bound to controller 1
			if (p_option->data.CBT[c] >= 500 && p_option->data.CBT[c] <= 531)
			{
				CS[c]		= dicon[0].rgbButtons[p_option->data.CBT[c] - 500];
				CS1D[c]		= dicon1D[0].rgbButtons[p_option->data.CBT[c] - 500];
				//!! bug
				//t_CS[c]		= dicon[0].rgbButtons[p_option->data.CBT[c] - 500];
				t_CS[c]		= t_dicon[0][p_option->data.CBT[c] - 500];
			}

			//bound to controller 2
			if (p_option->data.CBT[c] >= 600 && p_option->data.CBT[c] <= 631)
			{
				CS[c]		= dicon[1].rgbButtons[p_option->data.CBT[c] - 600];
				CS1D[c]		= dicon1D[1].rgbButtons[p_option->data.CBT[c] - 600];
				//t_CS[c]		= dicon[1].rgbButtons[p_option->data.CBT[c] - 600];
				t_CS[c]		= t_dicon[1][p_option->data.CBT[c] - 600];
			}
		}

		//---- player commands -------------------------------------------------------------------
		//and times

		ui_state[P1][PUNCH]				= CS[cP1PUNCH];
		ui_state[P1][KICK]				= CS[cP1KICK];
		ui_state[P1][DEFEND]			= CS[cP1DEFEND];
		ui_state[P1][LEFT]				= CS[cP1LEFT];
		ui_state[P1][RIGHT]				= CS[cP1RIGHT];
		ui_state[P1][SPECIAL]			= CS[cP1SPECIAL];
		ui_state[P1][STANCEUP]			= CS[cP1STANCEUP];
		ui_state[P1][STANCEDOWN]		= CS[cP1STANCEDOWN];
		ui_state1D[P1][PUNCH]			= CS1D[cP1PUNCH];
		ui_state1D[P1][KICK]			= CS1D[cP1KICK];
		ui_state1D[P1][DEFEND]			= CS1D[cP1DEFEND];
		ui_state1D[P1][LEFT]			= CS1D[cP1LEFT];
		ui_state1D[P1][RIGHT]			= CS1D[cP1RIGHT];
		ui_state1D[P1][SPECIAL]			= CS1D[cP1SPECIAL];
		ui_state1D[P1][STANCEUP]		= CS1D[cP1STANCEUP];
		ui_state1D[P1][STANCEDOWN]		= CS1D[cP1STANCEDOWN];
		t_ui_assigned[P1][PUNCH]		= t_CS[cP1PUNCH];
		t_ui_assigned[P1][KICK]			= t_CS[cP1KICK];
		t_ui_assigned[P1][DEFEND]		= t_CS[cP1DEFEND];
		t_ui_assigned[P1][LEFT]			= t_CS[cP1LEFT];
		t_ui_assigned[P1][RIGHT]		= t_CS[cP1RIGHT];
		t_ui_assigned[P1][SPECIAL]		= t_CS[cP1SPECIAL];
		t_ui_assigned[P1][STANCEUP]		= t_CS[cP1STANCEUP];
		t_ui_assigned[P1][STANCEDOWN]	= t_CS[cP1STANCEDOWN];
		ui_state[P2][PUNCH]				= CS[cP2PUNCH];
		ui_state[P2][KICK]				= CS[cP2KICK];
		ui_state[P2][DEFEND]			= CS[cP2DEFEND];
		ui_state[P2][LEFT]				= CS[cP2LEFT];
		ui_state[P2][RIGHT]				= CS[cP2RIGHT];
		ui_state[P2][SPECIAL]			= CS[cP2SPECIAL];
		ui_state[P2][STANCEUP]			= CS[cP2STANCEUP];
		ui_state[P2][STANCEDOWN]		= CS[cP2STANCEDOWN];
		ui_state1D[P2][PUNCH]			= CS1D[cP2PUNCH];
		ui_state1D[P2][KICK]			= CS1D[cP2KICK];
		ui_state1D[P2][DEFEND]			= CS1D[cP2DEFEND];
		ui_state1D[P2][LEFT]			= CS1D[cP2LEFT];
		ui_state1D[P2][RIGHT]			= CS1D[cP2RIGHT];
		ui_state1D[P2][SPECIAL]			= CS1D[cP2SPECIAL];
		ui_state1D[P2][STANCEUP]		= CS1D[cP2STANCEUP];
		ui_state1D[P2][STANCEDOWN]		= CS1D[cP2STANCEDOWN];
		t_ui_assigned[P2][PUNCH]		= t_CS[cP2PUNCH];
		t_ui_assigned[P2][KICK]			= t_CS[cP2KICK];
		t_ui_assigned[P2][DEFEND]		= t_CS[cP2DEFEND];
		t_ui_assigned[P2][LEFT]			= t_CS[cP2LEFT];
		t_ui_assigned[P2][RIGHT]		= t_CS[cP2RIGHT];
		t_ui_assigned[P2][SPECIAL]		= t_CS[cP2SPECIAL];
		t_ui_assigned[P2][STANCEUP]		= t_CS[cP2STANCEUP];
		t_ui_assigned[P2][STANCEDOWN]	= t_CS[cP2STANCEDOWN];

/*		//for both players
		for (p = 0; p < 2; ++p)
		{
			//for all commands
			for (register int c = 0; c < 6; ++c)
			{
				//if key assigned is to keyboard button copy states
				if (ui_assigned[p][c] > 0)
				{
					ui_state[p][c]		= dikey[ui_assigned[p][c]];
					ui_state1D[p][c]	= dikey1D[ui_assigned[p][c]];
				}
				else
				//if assigned to mouse button (negative value)
				//reverse value and copy mouse button state
				{
					ui_state[p][c]		= dimouse[p + 1].rgbButtons[-ui_assigned[p][c]];
					ui_state1D[p][c]	= dimouse1D[p + 1].rgbButtons[-ui_assigned[p][c]];
				}
			}
		}

		//times
		for (register int p = 0; p < 2; ++p)
			for (register int k = 0; k < 6; ++k)
			{
				//keyboard
				if (ui_assigned[p][k] > 0)
					t_ui_assigned[p][k] = t_dikey[ui_assigned[p][k]];
				else
				//mouse
					t_ui_assigned[p][k] = t_dimouse[p + 1][-ui_assigned[p][k]];
			}*/

		//---- command input ---------------------------------------------------------------------

		//reset all player actions
		ZeroMemory(&PA, sizeof(PA));

		//---- console ---------------------------------------------------------------------------

		//if console active ignore further input processing
		if (con_state)
			return;

		//---- double button presses -------------------------------------------------------------

		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//not while moving
//			if (ui_state[p][SPECIAL] & 0x80 &&
//				ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0)
//				mm_button_flag[p]		= 6;
			//even while walking
//			if (ui_state[p][SPECIAL] & 0x80)
//				mm_button_flag[p]		= 6;

			//for all buttons
			for (register int b = 0; b < 6; ++b)
			{
				//special double tap only while not moving
				//if (b == SPECIAL &&
				//	(ui_state[p][LEFT] & 0x80 ||
				//	ui_state[p][RIGHT] & 0x80))
				//	break;

				//if button down
				if (ui_state1D[p][b] & 0x80)
				{
					//save last time index when button was 1D in first array
					//and save current time index in last array index
					t_laststate1D[p][b][0]	= t_laststate1D[p][b][1];
					t_laststate1D[p][b][1]	= p_time->current;

					//if time difference between tappings is smaller than defined time span
					//and both are not zero then set action
					if (t_laststate1D[p][b][0] != 0 && t_laststate1D[p][b][1] != 0)
						if (t_laststate1D[p][b][1] - t_laststate1D[p][b][0] < p_time->freq * t_doubletap[b])
						{
							//---- stance change -------------------------------------------------

							if (b == SPECIAL)
							{
								//stance change
								if (ui_state[p][DEFEND] == 0 &&
									ui_state[p][PUNCH] == 0 &&
									ui_state[p][KICK] == 0)
									PA[p][AC_STANCE_FEET]	= AS_ACTIVE;
								//faked stance change
								//no good since in simple defense mode it will activate evading
								//if (ui_state[p][DEFEND] & 0x80 &&
								//	ui_state[p][PUNCH] == 0 &&
								//	ui_state[p][KICK] == 0)
//								if (dimouse[1 + p_option->data.inputdevice[p]].lX)
//									PA[p][AC_STANCE_FEET]	= AS_CANCEL;

								//set special key button flag
								mm_button_flag[p]	= 6;
							}

							//---- taunting ------------------------------------------------------

							//hold special key and double tap punch/kick
							//not while walking
							//if (b == PUNCH && ui_state[p][SPECIAL] & 0x80 &&
							//	(ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0))
							//	PA[p][AC_TAUNT1]		= AS_ACTIVE;
							//if (b == KICK && ui_state[p][SPECIAL] & 0x80 &&
							//	(ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0))
							//	PA[p][AC_TAUNT2]		= AS_ACTIVE;
							//even while walking
							if (b == PUNCH && ui_state[p][SPECIAL] & 0x80)
							{
								PA[p][AC_TAUNT1]		= AS_ACTIVE;
							}
							if (b == KICK && ui_state[p][SPECIAL] & 0x80)
							{
								PA[p][AC_TAUNT2]		= AS_ACTIVE;
							}

							//---- push and pull -------------------------------------------------

							//hold special key and double tap punch/kick
							//not while walking
							//if (b == PUNCH && ui_state[p][SPECIAL] & 0x80 &&
							//	(ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0))
							//	PA[p][AC_TAUNT1]		= AS_ACTIVE;
							//if (b == KICK && ui_state[p][SPECIAL] & 0x80 &&
							//	(ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0))
							//	PA[p][AC_TAUNT2]		= AS_ACTIVE;
							//even while walking
//							if (b == PUNCH && ui_state[p][SPECIAL] & 0x80)
//								PA[p][AC_PUSH_ARMS]		= AS_ACTIVE;
//							if (b == KICK && ui_state[p][SPECIAL] & 0x80)
//								PA[p][AC_PULL_ARMS]		= AS_ACTIVE;

							//---- walk slide double tap -----------------------------------------

							//special key up
							if (ui_state[p][SPECIAL] == 0)
							{
								if (b == LEFT)
									if (si[p] == SLEFT)			PA[p][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
									else						PA[p][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
								if (b == RIGHT)
									if (si[p] == SLEFT)			PA[p][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
									else						PA[p][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
							}
							/*else
							//special key down
							//---- push and pull -------------------------------------------------
							{
								if (b == LEFT)
									if (p == P1)
										if (sip1 == SLEFT)			PA[p][AN_PULL_ARMS] = AS_ACTIVE;
										else						PA[p][AN_PUSH_ARMS] = AS_ACTIVE;
									else
										if (sip2 == SLEFT)			PA[p][AN_PULL_ARMS] = AS_ACTIVE;
										else						PA[p][AN_PUSH_ARMS] = AS_ACTIVE;
								if (b == RIGHT)
									if (p == P1)
										if (sip1 == SLEFT)			PA[p][AN_PUSH_ARMS] = AS_ACTIVE;
										else						PA[p][AN_PULL_ARMS] = AS_ACTIVE;
									else
										if (sip2 == SLEFT)			PA[p][AN_PUSH_ARMS] = AS_ACTIVE;
										else						PA[p][AN_PULL_ARMS] = AS_ACTIVE;
							}
							//---- taunting ------------------------------------------------------
							{
								if (b == LEFT)
									if (p == P1)
										if (sip1 == SLEFT)			PA[p][AN_TAUNT2] = AS_ACTIVE;
										else						PA[p][AN_TAUNT1] = AS_ACTIVE;
									else
										if (sip2 == SLEFT)			PA[p][AN_TAUNT2] = AS_ACTIVE;
										else						PA[p][AN_TAUNT1] = AS_ACTIVE;
								if (b == RIGHT)
									if (p == P1)
										if (sip1 == SLEFT)			PA[p][AN_TAUNT1] = AS_ACTIVE;
										else						PA[p][AN_TAUNT2] = AS_ACTIVE;
									else
										if (sip2 == SLEFT)			PA[p][AN_TAUNT1] = AS_ACTIVE;
										else						PA[p][AN_TAUNT2] = AS_ACTIVE;
							}*/

							//reset
							t_laststate1D[p][b][0]	= 0;
							t_laststate1D[p][b][1]	= 0;
						}
				}
			}
		}

/*		//---- push and pull ---------------------------------------------------------------------

		for (register int p = 0; p < 2; ++p)
		{
			//defend button up
			if (ui_state[p][DEFEND] == 0)
			{
				//if special hold and kick pushed or
				//kick hold and special pushed
				if ((ui_state[p][SPECIAL] & 0x80 && ui_state1D[p][KICK] & 0x80) ||
					(ui_state1D[p][SPECIAL] & 0x80 && ui_state[p][KICK] & 0x80))
				{
					PA[p][AC_PULL_ARMS]		= AS_ACTIVE;

					//reset special double tap
					t_laststate1D[p][SPECIAL][0]	= 0;
					t_laststate1D[p][SPECIAL][1]	= 0;
				}
				if ((ui_state[p][SPECIAL] & 0x80 && ui_state1D[p][PUNCH] & 0x80) ||
					(ui_state1D[p][SPECIAL] & 0x80 && ui_state[p][PUNCH] & 0x80))
				{
					PA[p][AC_PUSH_ARMS]		= AS_ACTIVE;

					//if full guard an special pushed
					//push but don't pull
					PA[p][AC_PULL_ARMS]		= AS_INACTIVE;

					//reset special double tap
					t_laststate1D[p][SPECIAL][0]	= 0;
					t_laststate1D[p][SPECIAL][1]	= 0;
				}
			}
		}*/

		//---- taunting --------------------------------------------------------------------------

/*		for (p = 0; p < 2; ++p)
		{
			//special and defend down
			if (ui_state[p][SPECIAL] & 0x80 && ui_state[p][DEFEND] & 0x80)
			{
				//set special key button flag
				mm_button_flag[p]	= 6;

				//reset special key double tap
				t_laststate1D[p][SPECIAL][0]	= 0;
				t_laststate1D[p][SPECIAL][1]	= 0;

				if (ui_state1D[p][PUNCH] & 0x80)
				{
					PA[p][AN_TAUNT1]	= AS_ACTIVE;
				}
				if (ui_state1D[p][KICK] & 0x80)
				{
					PA[p][AN_TAUNT2]	= AS_ACTIVE;
				}
			}
		}*/

/*		if (sip1 == SLEFT)
		{
//			if (mm_button_flag[P1] != 6)
			{
				if ((ui_state[P1][SPECIAL] & 0x80 && ui_state1D[P1][RIGHT] & 0x80) ||
					(ui_state1D[P1][SPECIAL] & 0x80 && ui_state[P1][RIGHT] & 0x80))
				{
					PA[P1][AC_PUSH_ARMS]	= AS_ACTIVE;
					mm_button_flag[P1]		= 6;
				}
				if ((ui_state[P1][SPECIAL] & 0x80 && ui_state1D[P1][LEFT] & 0x80) ||
					(ui_state1D[P1][SPECIAL] & 0x80 && ui_state[P1][LEFT] & 0x80))
				{
					PA[P1][AC_PULL_ARMS]	= AS_ACTIVE;
					mm_button_flag[P1]		= 6;
				}
			}
		}
		else
		{
//			if (mm_button_flag[P1] != 6)
			{
				if ((ui_state[P1][SPECIAL] & 0x80 && ui_state1D[P1][RIGHT] & 0x80) ||
					(ui_state1D[P1][SPECIAL] & 0x80 && ui_state[P1][RIGHT] & 0x80))
				{
					PA[P1][AC_PULL_ARMS]	= AS_ACTIVE;
					mm_button_flag[P1]		= 6;
				}
				if ((ui_state[P1][SPECIAL] & 0x80 && ui_state1D[P1][LEFT] & 0x80) ||
					(ui_state1D[P1][SPECIAL] & 0x80 && ui_state[P1][LEFT] & 0x80))
				{
					PA[P1][AC_PUSH_ARMS]	= AS_ACTIVE;
					mm_button_flag[P1]		= 6;
				}
			}
		}
		if (sip2 == SLEFT)
		{
//			if (mm_button_flag[P2] != 6)
			{
				if ((ui_state[P2][SPECIAL] & 0x80 && ui_state1D[P2][RIGHT] & 0x80) ||
					(ui_state1D[P2][SPECIAL] & 0x80 && ui_state[P2][RIGHT] & 0x80))
				{
					PA[P2][AC_PUSH_ARMS]	= AS_ACTIVE;
					mm_button_flag[P2]		= 6;
				}
				if ((ui_state[P2][SPECIAL] & 0x80 && ui_state1D[P2][LEFT] & 0x80) ||
					(ui_state1D[P2][SPECIAL] & 0x80 && ui_state[P2][LEFT] & 0x80))
				{
					PA[P2][AC_PULL_ARMS]	= AS_ACTIVE;
					mm_button_flag[P2]		= 6;
				}
			}
		}
		else
		{
//			if (mm_button_flag[P2] != 6)
			{
				if ((ui_state[P2][SPECIAL] & 0x80 && ui_state1D[P2][RIGHT] & 0x80) ||
					(ui_state1D[P2][SPECIAL] & 0x80 && ui_state[P2][RIGHT] & 0x80))
				{
					PA[P2][AC_PULL_ARMS]	= AS_ACTIVE;
					mm_button_flag[P2]		= 6;
				}
				if ((ui_state[P2][SPECIAL] & 0x80 && ui_state1D[P2][LEFT] & 0x80) ||
					(ui_state1D[P2][SPECIAL] & 0x80 && ui_state[P2][LEFT] & 0x80))
				{
					PA[P2][AC_PUSH_ARMS]	= AS_ACTIVE;
					mm_button_flag[P2]		= 6;
				}
			}
		}*/

		//---- walk slide (special + walk) -------------------------------------------------------

		/*special hold and direction tap or
		//direction hold and special tap
		if (ui_state[P1][LEFT] & 0x80 &&
			ui_state1D[P1][SPECIAL])
			if (sip1 == SLEFT)			PA[P1][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
			else						PA[P1][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
		if (ui_state[P1][RIGHT] & 0x80 &&
			ui_state1D[P1][SPECIAL])
			if (sip1 == SLEFT)			PA[P1][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
			else						PA[P1][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
		if (ui_state[P2][LEFT] & 0x80 &&
			ui_state1D[P2][SPECIAL])
			if (sip2 == SLEFT)			PA[P2][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
			else						PA[P2][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
		if (ui_state[P2][RIGHT] & 0x80 &&
			ui_state1D[P2][SPECIAL])
			if (sip2 == SLEFT)			PA[P2][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
			else						PA[P2][AC_WALK_SLIDE_BWD] = AS_ACTIVE;*/
		/*for (p = 0; p < 2; ++p)
		{
		if ((ui_state1D[p][LEFT] & 0x80 &&
			ui_state[p][SPECIAL]) ||
			(ui_state[p][LEFT] & 0x80 &&
			ui_state1D[p][SPECIAL]))
			if (sip1 == SLEFT)			PA[p][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
			else						PA[p][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
		if ((ui_state1D[p][RIGHT] & 0x80 &&
			ui_state[p][SPECIAL]) ||
			(ui_state[p][RIGHT] & 0x80 &&
			ui_state1D[p][SPECIAL]))
			if (sip1 == SLEFT)			PA[p][AC_WALK_SLIDE_FWD] = AS_ACTIVE;
			else						PA[p][AC_WALK_SLIDE_BWD] = AS_ACTIVE;
		}*/

		//---- movement order --------------------------------------------------------------------

		//players can either move left OR right, if both buttons are pressed at the same time
		//they stop
		//set 1D times
		if (ui_state1D[P1][LEFT] & 0x80)			t_move1D[P1][0] = p_time->current;
		if (ui_state1D[P1][RIGHT] & 0x80)			t_move1D[P1][1] = p_time->current;
		if (ui_state1D[P2][LEFT] & 0x80)			t_move1D[P2][0] = p_time->current;
		if (ui_state1D[P2][RIGHT] & 0x80)			t_move1D[P2][1] = p_time->current;

		//if both keys pressed the same time, don't move at all
		if (ui_state[P1][LEFT] & 0x80 && ui_state[P1][RIGHT] & 0x80)
			ui_state[P1][LEFT] = ui_state[P1][RIGHT] = 0;
			//if time index of LEFT is later than RIGHT move LEFT else RIGHT
			//if (t_move1D[P1][0] > t_move1D[P1][1])
			//	ui_state[P1][RIGHT]	= 0;
			//else
			//	ui_state[P1][LEFT]	= 0;
		if (ui_state[P2][LEFT] & 0x80 && ui_state[P2][RIGHT] & 0x80)
			ui_state[P2][LEFT] = ui_state[P2][RIGHT] = 0;
			//if (t_move1D[P2][0] > t_move1D[P2][1])
			//	ui_state[P2][RIGHT]	= 0;
			//else
			//	ui_state[P2][LEFT]	= 0;

		//set player walk actions depending on site relative to other player
		if (ui_state[P1][LEFT] & 0x80)
		{
			if (sip1 == 0)				PA[P1][AC_WALK_BWD]		= AS_ACTIVE;
			else						PA[P1][AC_WALK_FWD]		= AS_ACTIVE;
		}
		if (ui_state[P1][RIGHT] & 0x80)
		{
			if (sip1 == 0)				PA[P1][AC_WALK_FWD]		= AS_ACTIVE;
			else						PA[P1][AC_WALK_BWD]		= AS_ACTIVE;
		}
		if (ui_state[P2][LEFT] & 0x80)
		{
			if (sip2 == 0)				PA[P2][AC_WALK_BWD]		= AS_ACTIVE;
			else						PA[P2][AC_WALK_FWD]		= AS_ACTIVE;
		}
		if (ui_state[P2][RIGHT] & 0x80)
		{
			if (sip2 == 0)				PA[P2][AC_WALK_FWD]		= AS_ACTIVE;
			else						PA[P2][AC_WALK_BWD]		= AS_ACTIVE;
		}

		//---- movement time ---------------------------------------------------------------------

		//for both players
		for (p = 0; p < 2; ++p)
		{
			//if moving forward
			if (PA[p][AC_WALK_FWD] == AS_ACTIVE)
			{
				//set start time if not set yet
				if (t_startmove[p][1] == 0)
					t_startmove[p][1] = p_time->current;
				else
					//else calculate passed time and stre it in t_move
					t_move[p][1] = (float)(p_time->current - t_startmove[p][1]) / p_time->freq;
			}
			else
			{
				//if not moving forward reset start time and move time
				t_move[p][1]		= 0;
				t_startmove[p][1]	= 0;
			}

			//same for moving backward
			if (PA[p][AC_WALK_BWD] == AS_ACTIVE)
			{
				if (t_startmove[p][0] == 0)
					t_startmove[p][0] = p_time->current;
				else
					t_move[p][0] = (float)(p_time->current - t_startmove[p][0]) / p_time->freq;
			}
			else
			{
				t_move[p][0]		= 0;
				t_startmove[p][0]	= 0;
			}
		}

		//---- stance arms -----------------------------------------------------------------------

		for (p = 0; p < 2; ++p)
		{
			//no other action
			if (mm_button[p] == 0)
			{
				//stanceup/down button
				if (ui_state1D[p][STANCEUP] & 0x80)
				{
					PA[p][AC_STANCE_ARMS]	= 1000;
					break;
				}
				if (ui_state1D[p][STANCEDOWN] & 0x80)
				{
					PA[p][AC_STANCE_ARMS]	= -1000;
					break;
				}

				//!!ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0

				//special button down and
				//defense button down
				//but not walking
				if (ui_state[p][SPECIAL] & 0x80 &&
					ui_state[p][DEFEND] & 0x80 &&
					ui_state[p][LEFT] == 0 &&
					ui_state[p][RIGHT] == 0)
				{
					//mouse input
					if (p_option->data.inputdevice[p] == DCD_MOUSE1 ||
						p_option->data.inputdevice[p] == DCD_MOUSE2)
					{
						//y-axis movement
						//int lY	= dimouse[1 + p_option->data.inputdevice[p]].lY;

						//min y threshold
						//if (lY > 5)			PA[p][AC_STANCE_ARMS]	= (lY - 5) * 50;
						//if (lY < -5)		PA[p][AC_STANCE_ARMS]	= (lY + 5) * 50;

						//y-axis movement
						if (dimouse[1 + p_option->data.inputdevice[p]].lY != 0)
						{
							PA[p][AC_STANCE_ARMS]	= dimouse[1 + p_option->data.inputdevice[p]].lY * 50;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}

					//digital controller input
					if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_DIG ||
						p_option->data.inputdevice[p] == DCD_CONTROLLER2_DIG)
					{
						//y-axis movement
						if (dicon[p_option->data.inputdevice[p] - 2].lY != 0)
						{
							//PA[p][AC_STANCE_ARMS]	= dicon[p_option->data.inputdevice[p] - 2].lY;
							if (dicon[p_option->data.inputdevice[p] - 2].lY < 0)
								PA[p][AC_STANCE_ARMS]	= -200;
							if (dicon[p_option->data.inputdevice[p] - 2].lY > 0)
								PA[p][AC_STANCE_ARMS]	= 200;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}

					//analog controller input
					if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_ANA ||
						p_option->data.inputdevice[p] == DCD_CONTROLLER2_ANA)
					{
						//y-axis movement
						if (dicon[p_option->data.inputdevice[p] - 4].lY != 0)
						{
							//PA[p][AC_STANCE_ARMS]	= dicon[p_option->data.inputdevice[p] - 2].lY;
							if (dicon[p_option->data.inputdevice[p] - 4].lY < 0)
								PA[p][AC_STANCE_ARMS]	= -200;
							if (dicon[p_option->data.inputdevice[p] - 4].lY > 0)
								PA[p][AC_STANCE_ARMS]	= 200;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}
				}
			}
		}

			/*not while walking (slide)
			if ((mm_button[p] == 0) &&
				((ui_state[p][SPECIAL] & 0x80 && dimouse[p + 1].lY != 0
				&& ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0) ||
				(ui_state1D[p][STANCEUP] & 0x80 || ui_state1D[p][STANCEDOWN] & 0x80)))
			{
				//per key
				if (ui_state1D[p][STANCEUP] & 0x80 || ui_state1D[p][STANCEDOWN] & 0x80)
				{
					if (ui_state1D[p][STANCEUP] & 0x80)			PA[p][AC_STANCE_ARMS]	= -1000;
					if (ui_state1D[p][STANCEDOWN] & 0x80)		PA[p][AC_STANCE_ARMS]	= 1000;
				}
				else
				//per mouse
				{
					PA[p][AC_STANCE_ARMS]			= dimouse[p + 1].lY;
					//halt mouse movement
					//special key has to be released before processing mouse movement
					mm_button_flag[p]		= 6;
				}
			}*/

		/*if lY != 0, new stance is applied through mm_angle
		//if lZ != 0, new stance is applied through mm_angle180
		for (p = 0; p < 2; ++p)
		{
			//if ((mm_button[p] == 0) &&
			//	((ui_state[p][SPECIAL] & 0x80 && dimouse[p + 1].lY != 0) ||
			//	dimouse[p + 1].lZ != 0))
			//not while walking (slide)
			if ((mm_button[p] == 0) &&
				((ui_state[p][SPECIAL] & 0x80 && dimouse[p + 1].lY != 0
				&& ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0) ||
				dimouse[p + 1].lZ != 0))
			{
				//mousewheel
				if (dimouse[p + 1].lZ)
				{
					if (dimouse[p + 1].lZ > 0)		PA[p][AC_STANCE_ARMS]		= 1000;
					if (dimouse[p + 1].lZ < 0)		PA[p][AC_STANCE_ARMS]		= -1000;
				}
				else
				{
					PA[p][AC_STANCE_ARMS]			= dimouse[p + 1].lY;
					//halt mouse movement
					//special key has to be released before processing mouse movement
					mm_button_flag[p]		= 6;
				}
			}
		}*/

		//---- defense ---------------------------------------------------------------------------

		//not while special button down
		for (p = 0; p < 2 && ui_state[p][SPECIAL] == 0; ++p)
		{
			//guard
			//if punch/kick and defend hold down
			//if (ui_state[p][DEFEND] & 0x80 && ui_state[p][PUNCH] & 0x80)
			//	PA[p][AC_GUARD_ARMS]	= AS_FINAL;
			//if (ui_state[p][DEFEND] & 0x80 && ui_state[p][KICK] & 0x80)
			//	PA[p][AC_GUARD_LEGS]	= AS_FINAL;
			//if (ui_state[p][DEFEND] & 0x80 && ui_state[p][PUNCH] & 0x80 && ui_state[p][KICK] & 0x80)
			//	PA[p][AC_GUARD_FULL]	= AS_FINAL;

			//if button hold longer than 0.25 sec (adjusted to game speed) plus t_defbuffer time
			//and longer then defense tap buffer time
			//and button not down from previous canceled action
			//and not within mmovement
			if (t_ui_assigned[p][PUNCH] >= 0.25f / p_option->data.speed + p_option->data.t_defbuffer[p] &&
				mm_cancel[p] == 0 &&
				mm_button_flag[p] == 1)
			{
				PA[p][AC_GUARD_ARMS]	= AS_FINAL;
			}
			if (t_ui_assigned[p][KICK] >= 0.25f / p_option->data.speed + p_option->data.t_defbuffer[p] &&
				mm_cancel[p] == 0 &&
				mm_button_flag[p] == 2)
			{
				PA[p][AC_GUARD_LEGS]	= AS_FINAL;
			}
			//no minimum time
			if (ui_state[p][PUNCH] & 0x80 && ui_state[p][KICK] & 0x80 &&
				mm_cancel[p] == 0 &&
				(mm_button_flag[p] == 1 || mm_button_flag[p] == 2))
			{
				PA[p][AC_GUARD_ARMS]	= AS_INACTIVE;
				PA[p][AC_GUARD_LEGS]	= AS_INACTIVE;
				PA[p][AC_GUARD_FULL]	= AS_FINAL;
				//set full guard flag
				def_fullflag[p]			= 1;
			}

			//if full guard flag and button flag set
			//allows flexible change from guard_full to either guard_arms or
			//guard_legs regardless of which guard was activated first
			//(changes mm_button_flag)
			if (def_fullflag[p] && mm_button_flag[p])
			{
				//but punch key is up change button_flag to kick release
				if (ui_state[p][PUNCH] == 0 && ui_state[p][KICK] & 0x80)
				{
					mm_button_flag[p]	= 2;
				}
				//but kick key is up change button_flag to punch release
				if (ui_state[p][PUNCH] & 0x80 && ui_state[p][KICK] == 0)
				{
					mm_button_flag[p]	= 1;
				}
				//if both up reset full guard flag
				if (ui_state[p][PUNCH] == 0 && ui_state[p][KICK] == 0)
				{
					def_fullflag[p]		= 0;
				}
			}

			if (ui_state[p][PUNCH] == 0 && ui_state[p][KICK] == 0)
				mm_cancel[p]	= 0;

			//if simple defense mode
			//if (p_option->data.defense_mode[p] == dm_sim)
			{
				//if button1D down, set starting time
				if (ui_state1D[p][PUNCH] & 0x80 && mm_button_flag[p] == 0 && def_button[p] == 0)
				{
					def_button[p]	= 1;
					def_tstart[p]	= p_time->current;
				}
				if (ui_state1D[p][KICK] & 0x80 && mm_button_flag[p] == 0 && def_button[p] == 0)
				{
					def_button[p]	= 2;
					def_tstart[p]	= p_time->current;
				}

				//if starting time set
				if (def_tstart[p])
				{
					//mousemovement cancels
					if (mcx[p] || mcy[p])
					{
						def_tstart[p]		= 0;
						def_button[p]		= 0;
					}

					//button released or time up
					if (def_tstart[p] &&
						(ui_state[p][def_button[p] - 1] == 0 ||
						p_time->current >= def_tstart[p] + p_time->freq * p_option->data.t_defbuffer[p]))
					{
						if (def_button[p] == 1)
						{
							//PA[p][AC_TAP_JAB]		= AS_FINAL;
							PA[p][AC_TAP_ARMS]		= AS_FINAL;
							mm_button_flag[p]		= def_button[p];
							def_button[p]			= 0;
							def_tstart[p]			= 0;
						}
						else
						{
							PA[p][AC_TAP_LEG]		= AS_FINAL;
							mm_button_flag[p]		= def_button[p];
							def_button[p]			= 0;
							def_tstart[p]			= 0;
						}
					}
				}

				//if simple defense mode
				if (p_option->data.defense_mode[p] == DM_aTaE ||
					p_option->data.defense_mode[p] == DM_mTaE)
				{
					//special key up
					if (ui_state[p][SPECIAL] == 0)
					{
						//evade hold, only for limited time (adjusted to game speed)
						//and not the first frame the key is hold
						if (ui_state[p][DEFEND] & 0x80 &&
							ui_state1D[p][DEFEND] == 0 &&
							t_ui_assigned[p][DEFEND] <= T_EVADE_HOLD / p_option->data.speed)
							PA[p][AC_DEFEND]	= AS_ACTIVE;

						//evade
						if (ui_state1D[p][DEFEND] & 0x80)
							PA[p][AC_DEFEND]	= AS_FINAL;

						//else
						//??
						//!! if (ui_state1D[P1][DEFEND] == 0 && ui_state[P1][DEFEND] & 0x80)
							//holding defend
						//	if (ui_state[p][DEFEND] & 0x80)
						//		PA[p][AC_DEFEND] = AS_ACTIVE;
					}
				}
				else
				//manual evade mode
				{
					//special key up
					if (ui_state[p][SPECIAL] == 0)
					{
						//evade hold, only for limited time (adjusted to game speed)
						if (ui_state[p][DEFEND] & 0x80 &&
							ui_state1D[p][DEFEND] == 0 &&
							((float)(p_time->current - t_defdown[p]) / p_time->freq) <=
							T_EVADE_HOLD / p_option->data.speed)
							PA[p][AC_DEFEND]	= AS_ACTIVE;
					}
				}
			}
		}

		//---- mouse movement --------------------------------------------------------------------

		//for both players
		for (p = 0; p < 2; ++p)
		{
			//---- mouse input -------------------------------------------------------------------

			if (p_option->data.inputdevice[p] == DCD_MOUSE1 ||
				p_option->data.inputdevice[p] == DCD_MOUSE2)
			{
				//check for button flags. a button flag is set if a player executes a certain
				//move. than the button has to be up before executing a new move else any
				//movement will be ignored
				switch (mm_button_flag[p])
				{
				//punch only
				case (1):
					{
						if (ui_state[p][PUNCH] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				//kick only
				case (2):
					{
						if (ui_state[p][KICK] == 0)		mm_button_flag[p]	= 0;
						break;
					}

				//defend only
				case (3):
					{
						if (ui_state[p][DEFEND] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				/*/punch and defend
				case (4):
					{
						if (ui_state[p][PUNCH] == 0 && ui_state[p][DEFEND] == 0)	mm_button_flag[p] = 0;
						break;
					}

				//kick and defend
				case (5):
					{
						if (ui_state[p][KICK] == 0 && ui_state[p][DEFEND] == 0)		mm_button_flag[p] = 0;
						break;
					}*/

				//special only
				case(6):
					{
						if (ui_state[p][SPECIAL] == 0)	mm_button_flag[p]	= 0;
						break;
					}
				}

				switch (mm_state[p])
				{
				//---- no action yet -----------------------------------------------------------------
				case (0):
					{
						//if mouse moved and start of action not already registered
						//(p + 1 because mouse of player one is dimouse[1])
						if ((dimouse[1 + p_option->data.inputdevice[p]].lX != 0 || dimouse[1 + p_option->data.inputdevice[p]].lY != 0) &&
							mm_t_start[p] == 0 &&
							mm_button_flag[p] == 0)
						{
							//register held down button
							//punch only
							if (ui_state[p][PUNCH] & 0x80)
								mm_button[p]	= 1;
							//kick only
							if (ui_state[p][KICK] & 0x80)
								mm_button[p]	= 2;
							//defend only
							//only in complex defense mode
							if (p_option->data.defense_mode[p] == DM_aTmE ||
								p_option->data.defense_mode[p] == DM_mTmE)
								if (ui_state[p][DEFEND] & 0x80)
									mm_button[p]	= 3;
							/*punch and defend
							if (ui_state[p][PUNCH] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 4;
							//kick and defend
							if (ui_state[p][KICK] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 5;*/
							//special only
							if (ui_state[p][SPECIAL] & 0x80)
								mm_button[p]	= 6;

							//if any valid button hit
							if (mm_button[p] != 0)
							{
								//assign current relative mouse movement
								mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
								mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;

								//set start time
								mm_t_start[p]	= p_time->current;
							}

							break;
						}

						//if time after button pressed and mouse moved is at least 20ms
						//and moved at least mm_buffer units
						if (p_time->current >= mm_t_start[p] + p_time->freq * mm_buffer_time[p] && mm_button[p] != 0 &&
							(mcx[p] >= mm_buffer[p].x || mcx[p] <= -mm_buffer[p].x ||
							mcy[p] >= mm_buffer[p].y || mcy[p] <= -mm_buffer[p].y))
						//why does this one work?
						//because it takes the mouse movement input from only one frame
						//and calculates the angle from it (since one x/y input can have
						//values > 1)
	//					if (mm_t_start[p] != 0)
						{
							//get current length of movement
							mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

							//calculate pre angle
							mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);

							//if current y-position is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)
								mm_angle[p]	= 360 - mm_angle[p];

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)
								mm_angle[p] = 0;

							//apply user set sensitivity
							//the higher the sensitivity the more the angle gets drawn
							//towards 0/180 degrees
							if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}

							//set 180 angle in general
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//---- set states ----------------------------------------------------

							//---- punch only ----------------------------------------------------

							if (mm_button[p] == 1)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left jab, on right cross
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] > 90 - AL_JAB_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 - AL_JAB_MIN;
										if (mm_angle[p] < 270 + AL_JAB_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_JAB_MAX;

										//no 180 check allows deeper jab
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
									else
									{
										mm_action[p] = AC_CROSS;
										//reverse angle (up/down) because of shoulder
										//if shoulder points up, cross goes down and vice versa
										mm_angle[p] = 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] > 90 - AL_CROSS_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 - AL_CROSS_MIN;
										if (mm_angle[p] < 270 + AL_CROSS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_CROSS_MAX;

										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_CROSS;
										//adjust angle but don't change angle_180
										//mm_angle[p] = 180 - (mm_angle[p] - 180);
										mm_angle[p]	= 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] < 90 + AL_CROSS_MIN)		mm_angle[p] = 90 + AL_CROSS_MIN;
										if (mm_angle[p] > 270 - AL_CROSS_MAX)		mm_angle[p] = 270 - AL_CROSS_MAX;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
									else
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] < 90 + AL_JAB_MIN)		mm_angle[p] = 90 + AL_JAB_MIN;
										if (mm_angle[p] > 270 - AL_JAB_MAX)		mm_angle[p] = 270 - AL_JAB_MAX;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
								}

								//set action state
								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- kick only ---------------------------------------------------------

							if (mm_button[p] == 2)
							{
								//if mouse moved to right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left fwd kick, on the right swd kick
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] > 90 - AL_KICK_FWD_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 - AL_KICK_FWD_MIN;
										if (mm_angle[p] < 270 + AL_KICK_FWD_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_KICK_FWD_MAX;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle since always kicking with front foot
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] < 90 + AL_KICK_SWD_MIN)		mm_angle[p] = 90 + AL_KICK_SWD_MIN;
										if (mm_angle[p] > 270 - AL_KICK_SWD_MAX)	mm_angle[p] = 270 - AL_KICK_SWD_MAX;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] > 90 - AL_KICK_SWD_MIN && mm_angle[p] <= 90)	mm_angle[p] = 90 - AL_KICK_SWD_MIN;
										if (mm_angle[p] < 270 + AL_KICK_SWD_MAX && mm_angle[p] > 270)	mm_angle[p] = 270 + AL_KICK_SWD_MAX;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] < 90 + AL_KICK_FWD_MIN)		mm_angle[p] = 90 + AL_KICK_FWD_MIN;
										if (mm_angle[p] > 270 - AL_KICK_FWD_MAX)	mm_angle[p] = 270 - AL_KICK_FWD_MAX;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}

								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- defend only -------------------------------------------------------

							//already set separately
							if (mm_button[p] == 3)
							{
								//set start time of defense button
								t_defdown[p]				= p_time->current;
								mm_action[p]				= AC_DEFEND;
								PA[p][mm_action[p]]			= AS_ACTIVE;
							}

							//---- punch and defend --------------------------------------------------

							if (mm_button[p] == 4)
							{
							}

							//---- kick and defend ---------------------------------------------------

							if (mm_button[p] == 5)
							{
							}

							//---- special only --------------------------------------------------

							if (mm_button[p] == 6)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left push, on right pull
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PUSH_ARMS;
										//mm_angle_180 reinnehmen, falls pre angle limit
										//
										//pre angle limits
										if (mm_angle[p] > 90 - AL_PUSH_ARMS_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 - AL_PUSH_ARMS_MIN;
										if (mm_angle[p] < 270 + AL_PUSH_ARMS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_PUSH_ARMS_MAX;
									}
									else
									{
										mm_action[p] = AC_PULL_ARMS;
										//mirror angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] > 90 - AL_PULL_ARMS_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 - AL_PULL_ARMS_MIN;
										if (mm_angle[p] < 270 + AL_PULL_ARMS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_PULL_ARMS_MAX;
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PULL_ARMS;
										//adjust angle but don't change angle_180
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] > 90 + AL_PULL_ARMS_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 + AL_PULL_ARMS_MIN;
										if (mm_angle[p] < 270 - AL_PULL_ARMS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 - AL_PULL_ARMS_MAX;
									}
									else
									{
										mm_action[p] = AC_PUSH_ARMS;
										//pre angle limits
										if (mm_angle[p] > 90 + AL_PUSH_ARMS_MIN && mm_angle[p] < 90)		mm_angle[p] = 90 + AL_PUSH_ARMS_MIN;
										if (mm_angle[p] < 270 - AL_PUSH_ARMS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 - AL_PUSH_ARMS_MAX;
									}
								}
							}

							//------------------------------------------------------------------------

							//assign current relative mouse movement
							//mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
							//mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;

							//if reverse flag set, reverse previous mouse x input
							//(y isn't reversed)
							if (mm_angle_rev[p] == 1)
								mcx[p] = -mcx[p];

							//set mm_state to pre-state
							mm_state[p]			= 1;
							//assign pre angles
							mm_angle_pre[p]		= mm_angle[p];
							mm_angle_180_pre[p]	= mm_angle_180[p];
						}
						else
						//buffer time not done yet, add mouse coordinates if valid button down
						//(which set start time)
						{
							if (mm_t_start[p] != 0)
							{
								mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
								mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;
							}
						}

						break;
					}

				//---- pre state ---------------------------------------------------------------------
				case (1):
					{
						//assign relative mouse movement
						//if reverse flag set, reverse mouse x input
						if (mm_angle_rev[p] == 1)
							mcx[p] += -dimouse[1 + p_option->data.inputdevice[p]].lX;
						else
							mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
						//mouse y not affected
						mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;

						//get current length of movement
						mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

						//if necessary assign new max length and max coordinates
						if (mm_length_c[p] > mm_length_m[p])
						{
							mm_length_m[p]	= mm_length_c[p];
							mmx[p]			= mcx[p];
							mmy[p]			= mcy[p];
						}

						//complete move flag (if time is up or button no longer down)
						bool cm				= false;
						//if mouse movement in defense mode 0 within crad buffer
						//a cancel move shouldn't cancel the defense, but finish it
						bool def_nocancel	= false;

						//if punch/kick button is held down for more than a second
						//(adjusted to user set speed) cancel move
						if (mm_button[p] < 3)
						{
							if (p_time->current >= mm_t_start[p] + p_time->freq / p_option->data.speed)
							{
								//cancel move
								mm_state[p]			= 3;
								//set cancel
								mm_cancel[p]		= 1;
							}

							//if time passed sind mouse movement started >= p_option->data.t_defbuffer
							if (p_time->current >= mm_t_start[p] + p_time->freq * p_option->data.t_defbuffer[p])
								//if maximum mouse movement length <= p_option->data.crad
								if (mm_length_m[p] <= p_option->data.crad[p])
								{
									//complete defense tap move
									cm = true;
									//set flag to not cancel move if
									//mouse movement within mrad_fwd is a cancel move
									def_nocancel = true;
								}

/*							//if simple defense mode
	//						if (p_option->data.defense_mode[p] == dm_sim)
								//time passed since mouse movement started <= p_option->data.t_defbuffer
								if (p_time->current >= mm_t_start[p] + p_time->freq * p_option->data.t_defbuffer[p])
									//if (longest) mouse movement length <= mradius
	//								if (mm_length_c[p] <= p_option->data.mrad_fwd[p])
	//								if (mm_length_m[p] <= p_option->data.mrad_fwd[p])
									if (mm_length_m[p] <= p_option->data.crad[p])
									{
										//complete defense tap move
										cm = true;
										//set flag to not cancel move if
										//mouse movement within mrad_fwd is a cancel move
										def_nocancel = true;
									}*/
						}

						//defend
						if (mm_button[p] == 3)
						{
							//set flag to not cancel move if
							//mouse movement within crad is a cancel move
							def_nocancel = true;

							//!! auch nach p_option->data.t_defbuffer[p]?
							//complete move for (d)/(d + p)/(d + k) after 20ms
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								//complete defense
								cm = true;
							}
						}

						//special
						if (mm_button[p] == 6)
						{
							//don't cancel action if mouse movement within crad
							def_nocancel	= true;

							//finish move after 1/50 seconds
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								cm = true;
							}

/*							//if longer hold than a half second cancel move
							if (p_time->current >= mm_t_start[p] + (p_time->freq * 0.5f) / p_option->data.speed)
							{
								//cancel move
								mm_state[p]			= 3;
								//set cancel
								mm_cancel[p]		= 1;
							}
*/						}

						//complete move if valid button up
						switch (mm_button[p])
						{
						//punch only
						case (1):
							{
								if (ui_state[p][PUNCH] == 0)	cm = true;
								break;
							}

						//kick only
						case (2):
							{
								if (ui_state[p][KICK] == 0)		cm = true;
								break;
							}

						//defend only
						case (3):
							{
								if (ui_state[p][DEFEND] == 0)	cm = true;
								break;
							}

						//punch and defend
						case (4):
							{
								//if (ui_state[p][PUNCH] == 0 || ui_state[p][DEFEND] == 0)	cm = true;
								//break;
							}

						//kick and defend
						case (5):
							{
								//if (ui_state[p][KICK] == 0 || ui_state[p][DEFEND] == 0)		cm = true;
								//break;
							}

						//special only
						case (6):
							{
								if (ui_state[p][SPECIAL] == 0)	cm = true;
								break;
							}
						}

						//complete move
						if (cm == true)
						{
							//calculate angle of current position
							//!! and also angle of maximum position
							//integer division

							//angle of pre_state input
	//						int mm_angle_pre	= mm_angle[p];
	//						int mm_angle_pre180	= mm_angle_180[p];

							//no division through 0
							if (mm_length_c[p] != 0)
								mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);
							else
								mm_angle[p] = 0;

							//!! angle of maximum length?
							float mm_angle_m;
							if (mm_length_m[p] != 0)
								mm_angle_m = (float)acos(mmx[p] / mm_length_m[p]) * 180 / PI;
							else
								mm_angle_m = 0;

							/*old, wrong version
							//mcy not valid for mm_angle_m
							//if current y-position is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)
							{
								mm_angle[p]	= 360 - mm_angle[p];
								mm_angle_m	= 360 - mm_angle_m;
							}

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)
								mm_angle[p] = 0;*/

							//if y-position (current and max) is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)			mm_angle[p]	= 360 - mm_angle[p];
							if (mmy[p] < 0)			mm_angle_m	= 360 - mm_angle_m;

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)				mm_angle[p] = 0;
							if (mm_angle_m == 360)				mm_angle_m = 0;

							//apply user set sensitivity
							if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}

							//if the final angle is on the other side compared to pre angel
							//cancel move
							//(mirror final angle)
							//don't if within defense mode 0 buffer radius
							if (!def_nocancel)
								if (mm_angle_pre[p] > 270 || mm_angle_pre[p] <= 90)
								{
									if (mm_angle[p] > 90 && mm_angle[p] <= 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}
								else
								{
									if (mm_angle[p] <= 90 || mm_angle[p] > 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}

							//set 180 angle
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//move counts as canceled if the length of the final mouse position
							//<= the length of the whole mouse movement * 0.75
							//cancel only possible if punch or kick
							//don't if within defense mode 0 buffer radius
							if (mm_button[p] < 3)
							{
								if (mm_length_c[p] <= mm_length_m[p] * 0.75 &&
									!def_nocancel)
								{
									//cancel and break
									mm_state[p] = 3;
									break;
								}
								else
									mm_state[p]	= 2;
							}
							else
								mm_state[p] = 2;

							/*tested for individual actions
							//y-axis context
							//if mouse moved down and button released after moved up
							//or vice versa trigger context event
							if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
								ycontext_up[p] = true;
							if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
								ycontext_do[p] = true;*/

							//if first moved up than down
	/*						if ((mm_angle_pre >= 200 && mm_angle_pre <= 340) &&
								(mm_angle[p] <= 160 && mm_angle[p] >= 20))
								ycontext_do[p] = true;
							//if first moved down than up
							if ((mm_angle_pre <= 160 && mm_angle_pre >= 20) &&
								(mm_angle[p] >= 200 && mm_angle[p] <= 340))
								ycontext_up[p] = true;*/

	/*						//if first moved up
							if (mmy[P1] < 0)
								//check how far back down mouse was moved
								if (mcy[P1] - mmy[P1] > mmy[P1] * -0.3f)
									ycontext_do[p] = true;
							//if first moved down
							if (mmy[P1] >= 0)
								//check how far back up mouse was movded
								if (mmy[P1] - mcy[P1] > mmy[P1] * 0.3f)
									ycontext_up[p] = true;

	/*						//if first moved up than down
							if ((mm_angle_pre >= 200 && mm_angle_pre <= 340) &&
								(mm_angle[p] <= 160 && mm_angle[p] >= 20))
								ycontext_do[p] = true;
							//if first moved down than up
							if ((mm_angle_pre <= 160 && mm_angle_pre >= 20) &&
								(mm_angle[p] >= 200 && mm_angle[p] <= 340))
								ycontext_up[p] = true;

	/*						//get coordinates after half of input time
							int _mchx = mchx[p][(int)(mcc[p] / 2.0f)];
							int _mchy = mchy[p][(int)(mcc[p] / 2.0f)];

							//get coordinates of half of final release point
							int _mlhx = (int)(mcx[p] / 2.0f);
							int _mlhy = (int)(mcy[p] / 2.0f);

							//get length between the two
							float mhlength = (float)sqrt(abs(_mlhx - _mchx) * abs(_mlhx - _mchx) +
														 abs(_mlhy - _mchy) * abs(_mlhy - _mchy));

							//if length between half final release point to half input point
							//exceeds certain value set context flag
							if (mhlength > mm_length_c[p] * 0.2f)
								m_context[p] = true;

							//get length from final release point to this half point
	//						float mhlength = (float)sqrt(_mchx * _mchx + _mchy * _mchy);

							//if length to half point is longer than x times half the length
							//of final release point set context flag
	//						if (mhlength > mm_length_c[p] / 2.0f * 1.1f)
	//							m_context[p] = true;*/

							//set final data
							switch (mm_button[p])
							{
							//punch only
							case (1):
								{
									if (mm_action[p] == AC_JAB)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_JAB;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_JAB]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 90 - AL_JAB_MIN && mm_angle[p] <= 90)		mm_angle[p] = 90 - AL_JAB_MIN;
											if (mm_angle[p] < 270 + AL_JAB_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_JAB_MAX;
										}
										else
										{
											if (mm_angle[p] < 90 + AL_JAB_MIN)		mm_angle[p] = 90 + AL_JAB_MIN;
											if (mm_angle[p] > 270 - AL_JAB_MAX)		mm_angle[p] = 270 - AL_JAB_MAX;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_CROSS)
									{
										//mirror final angle up/down
										//if (si[p] == SLEFT)					mm_angle[p] = 180 - (mm_angle[p] - 180);
										//else								mm_angle[p] = 360 - mm_angle[p];
										mm_angle[p]	= 360 - mm_angle[p];

										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_CROSS;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_CROSS]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//adjust pre angle (since it's both reversed up/down and left/right)
										//mm_angle_pre[p] += 180;
										//if (mm_angle_pre[p] > 359)		mm_angle_pre[p] -= 360;
										//if (mm_angle_pre[p] < 0)		mm_angle_pre[p] += 360;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] < 90 + AL_CROSS_MIN)	mm_angle[p] = 90 + AL_CROSS_MIN;
											if (mm_angle[p] > 270 - AL_CROSS_MAX)	mm_angle[p] = 270 - AL_CROSS_MAX;
										}
										else
										{
											if (mm_angle[p] > 90 - AL_CROSS_MIN && mm_angle[p] <= 90)	mm_angle[p] = 90 - AL_CROSS_MIN;
											if (mm_angle[p] < 270 + AL_CROSS_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_CROSS_MAX;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180[p] = 180 - mm_angle_180[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180_pre[p] = 180 - mm_angle_180_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
											//mirror since mm_angle is mirrored on y-axis
											mm_angle_180[p] = 180 - mm_angle_180[p];
										}

										break;
									}
								}

							//kick only
							case (2):
								{
									if (mm_action[p] == AC_KICK_FWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff	= 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 90 - AL_KICK_FWD_MIN && mm_angle[p] <= 90)	mm_angle[p] = 90 - AL_KICK_FWD_MIN;
											if (mm_angle[p] < 270 + AL_KICK_FWD_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_KICK_FWD_MAX;
										}
										else
										{
											if (mm_angle[p] < 90 + AL_KICK_FWD_MIN)		mm_angle[p] = 90 + AL_KICK_FWD_MIN;
											if (mm_angle[p] > 270 - AL_KICK_FWD_MAX)	mm_angle[p] = 270 - AL_KICK_FWD_MAX;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;

											//context angle limits
											if (si[p] == SLEFT)
											{
												if (mm_angle[p] > 90 - AL_KICK_KNEE_MIN && mm_angle[p] <= 90)		mm_angle[p] = 90 - AL_KICK_KNEE_MIN;
												if (mm_angle[p] < 270 + AL_KICK_KNEE_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_KICK_KNEE_MAX;
											}
											else
											{
												if (mm_angle[p] < 90 + AL_KICK_KNEE_MIN)		mm_angle[p] = 90 + AL_KICK_KNEE_MIN;
												if (mm_angle[p] > 270 - AL_KICK_KNEE_MAX)		mm_angle[p] = 270 - AL_KICK_KNEE_MAX;
											}

											break;
										}
										if (ycontext_do[p])
										{
											//ycontext_do[p]		= false;
											PA[p][mm_action[p]]		= AS_CONTEXT;

											//context angle limits
											if (si[p] == SLEFT)
											{
												if (mm_angle[p] > 90 - AL_KICK_KNEE_MIN && mm_angle[p] <= 90)		mm_angle[p] = 90 - AL_KICK_KNEE_MIN;
												if (mm_angle[p] < 270 + AL_KICK_KNEE_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_KICK_KNEE_MAX;
											}
											else
											{
												if (mm_angle[p] < 90 + AL_KICK_KNEE_MIN)		mm_angle[p] = 90 + AL_KICK_KNEE_MIN;
												if (mm_angle[p] > 270 - AL_KICK_KNEE_MAX)		mm_angle[p] = 270 - AL_KICK_KNEE_MAX;
											}

											break;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_KICK_SWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
										}

										//maximum pre-final angle difference
										int maxdiff	= 30;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 90 - AL_KICK_SWD_MIN && mm_angle[p] <= 90)	mm_angle[p] = 90 - AL_KICK_SWD_MIN;
											if (mm_angle[p] < 270 + AL_KICK_SWD_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_KICK_SWD_MAX;
										}
										else
										{
											if (mm_angle[p] < 90 + AL_KICK_SWD_MIN)		mm_angle[p] = 90 + AL_KICK_SWD_MIN;
											if (mm_angle[p] > 270 - AL_KICK_SWD_MAX)	mm_angle[p] = 270 - AL_KICK_SWD_MAX;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//context
										ycontext_up[p]			= false;
										ycontext_do[p]			= false;

										//pre final angle difference
										if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}
								}

							//defend only
							case (3):
								{
									break;
								}

							//punch and defend
							case (4):
								{
									break;
								}

							//kick and defend
							case (5):
								{
									break;
								}

							//special only
							case (6):
								{
									//cancel if current mouse movement too short
									if (mm_length_c[p] <= p_option->data.crad[p] * 2.5f)
									{
										PA[p][mm_action[p]]	= AS_INACTIVE;
										//cancel move
										mm_state[p]			= 3;
										//set cancel
										mm_cancel[p]		= 1;

										break;
									}

									//reset special key double tap
									t_laststate1D[p][SPECIAL][0]	= 0;
									t_laststate1D[p][SPECIAL][1]	= 0;

									if (mm_action[p] == AC_PUSH_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 90 - AL_PUSH_ARMS_MIN && mm_angle[p] <= 90)	mm_angle[p] = 90 - AL_PUSH_ARMS_MIN;
											if (mm_angle[p] < 270 + AL_PUSH_ARMS_MAX && mm_angle[p] >= 270)	mm_angle[p] = 270 + AL_PUSH_ARMS_MAX;
										}
										else
										{
											if (mm_angle[p] < 90 + AL_PUSH_ARMS_MIN)		mm_angle[p] = 90 + AL_PUSH_ARMS_MIN;
											if (mm_angle[p] > 270 - AL_PUSH_ARMS_MAX)		mm_angle[p] = 270 - AL_PUSH_ARMS_MAX;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}

									if (mm_action[p] == AC_PULL_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 90 - AL_PULL_ARMS_MIN && mm_angle[p] <= 90)		mm_angle[p] = 90 - AL_PULL_ARMS_MIN;
											if (mm_angle[p] < 270 + AL_PULL_ARMS_MAX && mm_angle[p] >= 270)		mm_angle[p] = 270 + AL_PULL_ARMS_MAX;
										}
										else
										{
											if (mm_angle[p] < 90 + AL_PULL_ARMS_MIN)	mm_angle[p] = 90 + AL_PULL_ARMS_MIN;
											if (mm_angle[p] > 270 - AL_PULL_ARMS_MAX)	mm_angle[p] = 270 - AL_PULL_ARMS_MAX;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}
								}
							}
						}

						break;
					}

				//case 2 and 3 reset
				//---- final state -------------------------------------------------------------------
				case (2):
					{
						//complete action if not already context activated
						if (PA[p][mm_action[p]] != AS_CONTEXT)
							PA[p][mm_action[p]] = AS_FINAL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}

				//---- canceling ---------------------------------------------------------------------
				case (3):
					{
						//cancel action
						PA[p][mm_action[p]] = AS_CANCEL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}
				}
			}

			//---- digital controller input ------------------------------------------------------

			if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_DIG ||
				p_option->data.inputdevice[p] == DCD_CONTROLLER2_DIG)
			{
				//check for button flags. a button flag is set if a player executes a certain
				//move. than the button has to be up before executing a new move else any
				//movement will be ignored
				switch (mm_button_flag[p])
				{
				//punch only
				case (1):
					{
						if (ui_state[p][PUNCH] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				//kick only
				case (2):
					{
						if (ui_state[p][KICK] == 0)		mm_button_flag[p]	= 0;
						break;
					}

				//defend only
				case (3):
					{
						if (ui_state[p][DEFEND] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				/*/punch and defend
				case (4):
					{
						if (ui_state[p][PUNCH] == 0 && ui_state[p][DEFEND] == 0)	mm_button_flag[p] = 0;
						break;
					}

				//kick and defend
				case (5):
					{
						if (ui_state[p][KICK] == 0 && ui_state[p][DEFEND] == 0)		mm_button_flag[p] = 0;
						break;
					}*/

				//special only
				case(6):
					{
						if (ui_state[p][SPECIAL] == 0)	mm_button_flag[p]	= 0;
						break;
					}
				}

				switch (mm_state[p])
				{
				//---- no action yet -----------------------------------------------------------------
				case (0):
					{
						//if controlpad moved and start of action not already registered
						if ((dicon[p_option->data.inputdevice[p] - 2].lX != 0 || dicon[p_option->data.inputdevice[p] - 2].lY != 0) &&
							mm_t_start[p] == 0 &&
							mm_button_flag[p] == 0)
						{
							//register held down button
							//punch only
							if (ui_state[p][PUNCH] & 0x80)
								mm_button[p]	= 1;
							//kick only
							if (ui_state[p][KICK] & 0x80)
								mm_button[p]	= 2;
							//defend only
							//only in complex defense mode
							if (p_option->data.defense_mode[p] == DM_aTmE ||
								p_option->data.defense_mode[p] == DM_mTmE)
								if (ui_state[p][DEFEND] & 0x80)
									mm_button[p]	= 3;
							/*punch and defend
							if (ui_state[p][PUNCH] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 4;
							//kick and defend
							if (ui_state[p][KICK] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 5;*/
							//special only
							if (ui_state[p][SPECIAL] & 0x80)
								mm_button[p]	= 6;

							//if any valid button hit
							if (mm_button[p] != 0)
							{
								//assign current relative mouse movement
								mcx[p] = dicon[p_option->data.inputdevice[p] - 2].lX;
								mcy[p] = dicon[p_option->data.inputdevice[p] - 2].lY;

								//set start time
								mm_t_start[p]	= p_time->current;
							}

							break;
						}

						//if time after button pressed and mouse moved is at least 20ms
						//and moved at least mm_buffer units
						if (p_time->current >= mm_t_start[p] + p_time->freq * mm_buffer_time[p] && mm_button[p] != 0 &&
							(mcx[p] >= mm_buffer[p].x || mcx[p] <= -mm_buffer[p].x ||
							mcy[p] >= mm_buffer[p].y || mcy[p] <= -mm_buffer[p].y))
						//why does this one work?
						//because it takes the mouse movement input from only one frame
						//and calculates the angle from it (since one x/y input can have
						//values > 1)
	//					if (mm_t_start[p] != 0)
						{
							//get current length of movement
							mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

							//calculate pre angle
							mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);

							//if current y-position is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)
								mm_angle[p]	= 360 - mm_angle[p];

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)
								mm_angle[p] = 0;

							//apply user set sensitivity
							//the higher the sensitivity the more the angle gets drawn
							//towards 0/180 degrees
							/*if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}*/

							//set 180 angle in general
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//---- set states --------------------------------------------------------

							//---- punch only --------------------------------------------------------

							if (mm_button[p] == 1)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left jab, on right cross
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										if (mm_angle[p] < 310 && mm_angle[p] >= 270)	mm_angle[p] = 310;

										//no 180 check allows deeper jab
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
									else
									{
										mm_action[p] = AC_CROSS;
										//reverse angle (up/down) because of shoulder
										//if shoulder points up, cross goes down and vice versa
										mm_angle[p] = 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										if (mm_angle[p] < 325 && mm_angle[p] >= 270)	mm_angle[p] = 325;

										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_CROSS;
										//adjust angle but don't change angle_180
										//mm_angle[p] = 180 - (mm_angle[p] - 180);
										mm_angle[p]	= 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] < 140)		mm_angle[p] = 140;
										if (mm_angle[p] > 215)		mm_angle[p] = 215;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
									else
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] < 140)		mm_angle[p] = 140;
										if (mm_angle[p] > 230)		mm_angle[p] = 230;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
								}

								//set action state
								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- kick only ---------------------------------------------------------

							if (mm_button[p] == 2)
							{
								//if mouse moved to right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left fwd kick, on the right swd kick
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] > 50 && mm_angle[p] <= 90)		mm_angle[p] = 50;
										if (mm_angle[p] < 340 && mm_angle[p] >= 270)	mm_angle[p] = 340;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle since always kicking with front foot
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] < 130)		mm_angle[p] = 130;
										//if (mm_angle[p] > 220)		mm_angle[p] = 220;
										if (mm_angle[p] > 200)		mm_angle[p] = 200;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] > 50 && mm_angle[p] <= 90)		mm_angle[p] = 50;
										//if (mm_angle[p] < 320 && mm_angle[p] >= 270)	mm_angle[p] = 320;
										if (mm_angle[p] < 340 && mm_angle[p] >= 270)	mm_angle[p] = 340;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] < 130)		mm_angle[p] = 130;
										if (mm_angle[p] > 200)		mm_angle[p] = 200;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}

								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- defend only -------------------------------------------------------

							//already set separately
							if (mm_button[p] == 3)
							{
								//set start time of defense button
								t_defdown[p]				= p_time->current;
								mm_action[p]				= AC_DEFEND;
								PA[p][mm_action[p]]			= AS_ACTIVE;
							}

							//---- punch and defend --------------------------------------------------

							if (mm_button[p] == 4)
							{
							}

							//---- kick and defend ---------------------------------------------------

							if (mm_button[p] == 5)
							{
							}

							//---- special only --------------------------------------------------

							if (mm_button[p] == 6)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left push, on right pull
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PUSH_ARMS;
										//mm_angle_180 reinnehmen, falls pre angle limit
										//
										//pre angle limits
										//if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										//if (mm_angle[p] < 310 && mm_angle[p] >= 270)	mm_angle[p] = 310;
									}
									else
									{
										mm_action[p] = AC_PULL_ARMS;
										//mirror angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										//if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										//if (mm_angle[p] < 325 && mm_angle[p] >= 270)	mm_angle[p] = 325;
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PULL_ARMS;
										//adjust angle but don't change angle_180
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										//if (mm_angle[p] < 140)		mm_angle[p] = 140;
										//if (mm_angle[p] > 215)		mm_angle[p] = 215;
									}
									else
									{
										mm_action[p] = AC_PUSH_ARMS;
										//pre angle limits
										//if (mm_angle[p] < 140)		mm_angle[p] = 140;
										//if (mm_angle[p] > 230)		mm_angle[p] = 230;
									}
								}
							}

							//------------------------------------------------------------------------

							//assign current relative mouse movement
							//mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
							//mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;

							//if reverse flag set, reverse previous mouse x input
							//(y isn't reversed)
							if (mm_angle_rev[p] == 1)
								mcx[p] = -mcx[p];

							//set mm_state to pre-state
							mm_state[p]			= 1;
							//assign pre angles
							mm_angle_pre[p]		= mm_angle[p];
							mm_angle_180_pre[p]	= mm_angle_180[p];
						}
						else
						//buffer time not done yet, add mouse coordinates if valid button down
						//(which set start time)
						{
							if (mm_t_start[p] != 0)
							{
								mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
								mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;
							}
						}

						break;
					}

				//---- pre state ---------------------------------------------------------------------
				case (1):
					{
						//assign relative mouse movement
						//if reverse flag set, reverse mouse x input
						if (mm_angle_rev[p] == 1)
							mcx[p] = -dicon[p_option->data.inputdevice[p] - 2].lX;
						else
							mcx[p] = dicon[p_option->data.inputdevice[p] - 2].lX;
						//mouse y not affected
						mcy[p] = dicon[p_option->data.inputdevice[p] - 2].lY;

						//get current length of movement
						mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

						//if necessary assign new max length and max coordinates
						if (mm_length_c[p] > mm_length_m[p])
						{
							mm_length_m[p]	= mm_length_c[p];
							mmx[p]			= mcx[p];
							mmy[p]			= mcy[p];
						}

						//complete move flag (if time is up or button no longer down)
						bool cm				= false;
						//if mouse movement in defense mode 0 within mrad_fwd buffer
						//a cancel move shouldn't cancel the defense, but finish it
						bool def_nocancel	= false;

						//if punch/kick button is held down for more than a second
						//(adjusted to user set speed) cancel move
						if (mm_button[p] < 3)
						{
							if (p_time->current >= mm_t_start[p] + p_time->freq / p_option->data.speed)
							{
								//cancel move
								mm_state[p]			= 3;
								//set cancel
								mm_cancel[p]		= 1;
							}

							//if time passed sind mouse movement started >= p_option->data.t_defbuffer
							if (p_time->current >= mm_t_start[p] + p_time->freq * p_option->data.t_defbuffer[p])
								//if maximum mouse movement length <= p_option->data.crad
								if (mm_length_m[p] <= p_option->data.crad[p])
								{
									//complete defense tap move
									cm = true;
									//set flag to not cancel move if
									//mouse movement within mrad_fwd is a cancel move
									def_nocancel = true;
								}
						}

						//defend
						if (mm_button[p] == 3)
						{
							//set flag to not cancel move if
							//mouse movement within crad is a cancel move
							def_nocancel = true;

							//!! auch nach p_option->data.t_defbuffer[p]?
							//complete move for (d)/(d + p)/(d + k) after 20ms
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								//complete defense
								cm = true;
							}
						}

						//special
						if (mm_button[p] == 6)
						{
							//don't cancel action if mouse movement within crad
							def_nocancel	= true;

							//finish move after 1/50 seconds
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								cm = true;
							}
						}

						//complete move if valid button up
						switch (mm_button[p])
						{
						//punch only
						case (1):
							{
								if (ui_state[p][PUNCH] == 0)	cm = true;
								break;
							}

						//kick only
						case (2):
							{
								if (ui_state[p][KICK] == 0)		cm = true;
								break;
							}

						//defend only
						case (3):
							{
								if (ui_state[p][DEFEND] == 0)	cm = true;
								break;
							}

						//punch and defend
						case (4):
							{
								//if (ui_state[p][PUNCH] == 0 || ui_state[p][DEFEND] == 0)	cm = true;
								//break;
							}

						//kick and defend
						case (5):
							{
								//if (ui_state[p][KICK] == 0 || ui_state[p][DEFEND] == 0)		cm = true;
								//break;
							}

						//special only
						case (6):
							{
								if (ui_state[p][SPECIAL] == 0)	cm = true;
								break;
							}
						}

						//complete move
						if (cm == true)
						{
							//calculate angle of current position
							//!! and also angle of maximum position
							//integer division

							//angle of pre_state input
	//						int mm_angle_pre	= mm_angle[p];
	//						int mm_angle_pre180	= mm_angle_180[p];

							//no division through 0
							if (mm_length_c[p] != 0)
								mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);
							else
								mm_angle[p] = 0;

							//!! angle of maximum length?
							float mm_angle_m;
							if (mm_length_m[p] != 0)
								mm_angle_m = (float)acos(mmx[p] / mm_length_m[p]) * 180 / PI;
							else
								mm_angle_m = 0;

							//if y-position (current and max) is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)			mm_angle[p]	= 360 - mm_angle[p];
							if (mmy[p] < 0)			mm_angle_m	= 360 - mm_angle_m;

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)				mm_angle[p] = 0;
							if (mm_angle_m == 360)				mm_angle_m = 0;

							/*/apply user set sensitivity
							if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}*/

							//if the final angle is on the other side compared to pre angel
							//cancel move
							//(mirror final angle)
							//don't if within defense mode 0 buffer radius
							if (!def_nocancel)
								if (mm_angle_pre[p] > 270 || mm_angle_pre[p] <= 90)
								{
									if (mm_angle[p] > 90 && mm_angle[p] <= 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}
								else
								{
									if (mm_angle[p] <= 90 || mm_angle[p] > 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}

							//set 180 angle
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//move counts as canceled if the length of the final mouse position
							//<= the length of the whole mouse movement * 0.75
							//cancel only possible if punch or kick
							//don't if within defense mode 0 buffer radius
							/*if (mm_button[p] < 3)
							{
								if (mm_length_c[p] <= mm_length_m[p] * 0.75 &&
									!def_nocancel)
								{
									//cancel and break
									mm_state[p] = 3;
									break;
								}
								else
									mm_state[p]	= 2;
							}
							else
								mm_state[p] = 2;*/

							//move canceled if digipad back in neutral position
							if (mm_button[p] < 3)
							{
								if (dicon[p_option->data.inputdevice[p] - 2].lX == 0 &&
									dicon[p_option->data.inputdevice[p] - 2].lY == 0 &&
									!def_nocancel)
								{
									//cancel and break
									mm_state[p] = 3;
									break;
								}
								else
									mm_state[p]	= 2;
							}
							else
								mm_state[p] = 2;

							/*y-axis context
							//if mouse moved down and button released after moved up
							//or vice versa trigger context event
							if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
								ycontext_up[p] = true;
							if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
								ycontext_do[p] = true;*/

							//set final data
							switch (mm_button[p])
							{
							//punch only
							case (1):
								{
									if (mm_action[p] == AC_JAB)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_JAB;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_JAB]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)			mm_angle[p] = 40;
											if (mm_angle[p] < 310 && mm_angle[p] >= 270)		mm_angle[p] = 310;
										}
										else
										{
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 230)		mm_angle[p] = 230;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_CROSS)
									{
										//mirror final angle up/down
										//if (si[p] == SLEFT)					mm_angle[p] = 180 - (mm_angle[p] - 180);
										//else								mm_angle[p] = 360 - mm_angle[p];
										mm_angle[p]	= 360 - mm_angle[p];

										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_CROSS;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_CROSS]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//adjust pre angle (since it's both reversed up/down and left/right)
										//mm_angle_pre[p] += 180;
										//if (mm_angle_pre[p] > 359)		mm_angle_pre[p] -= 360;
										//if (mm_angle_pre[p] < 0)		mm_angle_pre[p] += 360;

										//final angle limits
										if (si[p] == SLEFT)
										{
											//if (mm_angle[p] > 40 && mm_angle[p] <= 90)				mm_angle[p] = 40;
											//if (mm_angle[p] < 310 && mm_angle[p] >= 270)			mm_angle[p] = 310;
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 215)		mm_angle[p] = 215;
										}
										else
										{
											//if (mm_angle[p] < 140)		mm_angle[p] = 140;
											//if (mm_angle[p] > 230)		mm_angle[p] = 230;
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)				mm_angle[p] = 40;
											if (mm_angle[p] < 325 && mm_angle[p] >= 270)			mm_angle[p] = 325;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180[p] = 180 - mm_angle_180[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180_pre[p] = 180 - mm_angle_180_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
											//mirror since mm_angle is mirrored on y-axis
											mm_angle_180[p] = 180 - mm_angle_180[p];
										}

										break;
									}
								}

							//kick only
							case (2):
								{
									if (mm_action[p] == AC_KICK_FWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff	= 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											if (mm_angle[p] < 340 && mm_angle[p] >= 270)		mm_angle[p] = 340;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											if (mm_angle[p] > 200)		mm_angle[p] = 200;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;

											//context angle limits
											if (si[p] == SLEFT)
											{
												if (mm_angle[p] > 20 && mm_angle[p] <= 90)			mm_angle[p] = 20;
												if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
											}
											else
											{
												if (mm_angle[p] < 160)		mm_angle[p] = 160;
												if (mm_angle[p] > 220)		mm_angle[p] = 220;
											}

											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_KICK_SWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
										}

										//maximum pre-final angle difference
										int maxdiff	= 30;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											//if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
											if (mm_angle[p] < 340 && mm_angle[p] >= 270)		mm_angle[p] = 340;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											//if (mm_angle[p] > 220)		mm_angle[p] = 220;
											if (mm_angle[p] > 200)		mm_angle[p] = 200;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//context
										ycontext_up[p]			= false;
										ycontext_do[p]			= false;

										//pre final angle difference
										if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}
								}

							//defend only
							case (3):
								{
									break;
								}

							//punch and defend
							case (4):
								{
									break;
								}
							//kick and defend
							case (5):
								{
									break;
								}

							//special only
							case (6):
								{
									//cancel if current mouse movement too short
									if (mm_length_c[p] <= p_option->data.crad[p] * 2.5f)
									{
										PA[p][mm_action[p]]	= AS_INACTIVE;
										//cancel move
										mm_state[p]			= 3;
										//set cancel
										mm_cancel[p]		= 1;

										break;
									}

									//reset special key double tap
									t_laststate1D[p][SPECIAL][0]	= 0;
									t_laststate1D[p][SPECIAL][1]	= 0;

									if (mm_action[p] == AC_PUSH_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)			mm_angle[p] = 40;
											if (mm_angle[p] < 310 && mm_angle[p] >= 270)		mm_angle[p] = 310;
										}
										else
										{
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 230)		mm_angle[p] = 230;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}

									if (mm_action[p] == AC_PULL_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											if (mm_angle[p] > 220)		mm_angle[p] = 220;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}
								}
							}
						}

						break;
					}

				//case 2 and 3 reset
				//---- final state -------------------------------------------------------------------
				case (2):
					{
						//complete action if not already context activated
						if (PA[p][mm_action[p]] != AS_CONTEXT)
							PA[p][mm_action[p]] = AS_FINAL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}

				//---- canceling ---------------------------------------------------------------------
				case (3):
					{
						//cancel action
						PA[p][mm_action[p]] = AS_CANCEL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}
				}
			}

			//---- analog controller input -------------------------------------------------------

			if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_ANA ||
				p_option->data.inputdevice[p] == DCD_CONTROLLER2_ANA)
			{
				//check for button flags. a button flag is set if a player executes a certain
				//move. than the button has to be up before executing a new move else any
				//movement will be ignored
				switch (mm_button_flag[p])
				{
				//punch only
				case (1):
					{
						if (ui_state[p][PUNCH] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				//kick only
				case (2):
					{
						if (ui_state[p][KICK] == 0)		mm_button_flag[p]	= 0;
						break;
					}

				//defend only
				case (3):
					{
						if (ui_state[p][DEFEND] == 0)	mm_button_flag[p]	= 0;
						break;
					}

				/*/punch and defend
				case (4):
					{
						if (ui_state[p][PUNCH] == 0 && ui_state[p][DEFEND] == 0)	mm_button_flag[p] = 0;
						break;
					}

				//kick and defend
				case (5):
					{
						if (ui_state[p][KICK] == 0 && ui_state[p][DEFEND] == 0)		mm_button_flag[p] = 0;
						break;
					}*/

				//special only
				case(6):
					{
						if (ui_state[p][SPECIAL] == 0)	mm_button_flag[p]	= 0;
						break;
					}
				}

				switch (mm_state[p])
				{
				//---- no action yet -----------------------------------------------------------------
				case (0):
					{
						//if mouse moved and start of action not already registered
						//(p + 1 because mouse of player one is dimouse[1])
//if ((dicon[p_option->data.inputdevice[p] - 4].lX != 0 || dicon[p_option->data.inputdevice[p] - 4].lY != 0) &&
						if ((dicon[p_option->data.inputdevice[p] - 4].lX > p_option->data.crad[p] ||
							dicon[p_option->data.inputdevice[p] - 4].lX < -p_option->data.crad[p] ||
							dicon[p_option->data.inputdevice[p] - 4].lY > p_option->data.crad[p] ||
							dicon[p_option->data.inputdevice[p] - 4].lY < -p_option->data.crad[p]) &&
							mm_t_start[p] == 0 &&
							mm_button_flag[p] == 0)
						{
							//register held down button
							//punch only
							if (ui_state[p][PUNCH] & 0x80)
								mm_button[p]	= 1;
							//kick only
							if (ui_state[p][KICK] & 0x80)
								mm_button[p]	= 2;
							//defend only
							//only in complex defense mode
							if (p_option->data.defense_mode[p] == DM_aTmE ||
								p_option->data.defense_mode[p] == DM_mTmE)
								if (ui_state[p][DEFEND] & 0x80)
									mm_button[p]	= 3;
							/*punch and defend
							if (ui_state[p][PUNCH] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 4;
							//kick and defend
							if (ui_state[p][KICK] & 0x80 && ui_state[p][DEFEND] & 0x80)
								mm_button[p]	= 5;*/
							//special only
							if (ui_state[p][SPECIAL] & 0x80)
								mm_button[p]	= 6;

							//if any valid button hit
							if (mm_button[p] != 0)
							{
								//assign current absolute controller movement
								mcx[p] = dicon[p_option->data.inputdevice[p] - 4].lX;
								mcy[p] = dicon[p_option->data.inputdevice[p] - 4].lY;

								//set start time
								mm_t_start[p]	= p_time->current;
							}

							break;
						}

						//if time after button pressed and mouse moved is at least 20ms
						//and moved at least mm_buffer units
						if (p_time->current >= mm_t_start[p] + p_time->freq * mm_buffer_time[p] && mm_button[p] != 0 &&
							(mcx[p] >= mm_buffer[p].x || mcx[p] <= -mm_buffer[p].x ||
							mcy[p] >= mm_buffer[p].y || mcy[p] <= -mm_buffer[p].y))
						//why does this one work?
						//because it takes the mouse movement input from only one frame
						//and calculates the angle from it (since one x/y input can have
						//values > 1)
	//					if (mm_t_start[p] != 0)
						{
							//get current length of movement
							mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

							//calculate pre angle
							mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);

							//if current y-position is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)
								mm_angle[p]	= 360 - mm_angle[p];

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)
								mm_angle[p] = 0;

							//apply user set sensitivity
							//the higher the sensitivity the more the angle gets drawn
							//towards 0/180 degrees
							if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}

							//set 180 angle in general
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//---- set states --------------------------------------------------------

							//---- punch only --------------------------------------------------------

							if (mm_button[p] == 1)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left jab, on right cross
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										if (mm_angle[p] < 310 && mm_angle[p] >= 270)	mm_angle[p] = 310;

										//no 180 check allows deeper jab
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
									else
									{
										mm_action[p] = AC_CROSS;
										//reverse angle (up/down) because of shoulder
										//if shoulder points up, cross goes down and vice versa
										mm_angle[p] = 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										if (mm_angle[p] < 325 && mm_angle[p] >= 270)	mm_angle[p] = 325;

										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_CROSS;
										//adjust angle but don't change angle_180
										//mm_angle[p] = 180 - (mm_angle[p] - 180);
										mm_angle[p]	= 360 - mm_angle[p];
										//pre angle limits
										if (mm_angle[p] < 140)		mm_angle[p] = 140;
										if (mm_angle[p] > 215)		mm_angle[p] = 215;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//reverse
										mm_angle_180[p]	= 180 - mm_angle_180[p];*/
									}
									else
									{
										mm_action[p] = AC_JAB;
										//pre angle limits
										if (mm_angle[p] < 140)		mm_angle[p] = 140;
										if (mm_angle[p] > 230)		mm_angle[p] = 230;
										/*set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];*/
									}
								}

								//set action state
								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- kick only ---------------------------------------------------------

							if (mm_button[p] == 2)
							{
								//if mouse moved to right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left fwd kick, on the right swd kick
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] > 50 && mm_angle[p] <= 90)		mm_angle[p] = 50;
										if (mm_angle[p] < 340 && mm_angle[p] >= 270)	mm_angle[p] = 340;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle since always kicking with front foot
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] < 130)		mm_angle[p] = 130;
										//if (mm_angle[p] > 220)		mm_angle[p] = 220;
										if (mm_angle[p] > 200)		mm_angle[p] = 200;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_KICK_SWD;
										//mirror final angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										if (mm_angle[p] > 50 && mm_angle[p] <= 90)		mm_angle[p] = 50;
										//if (mm_angle[p] < 320 && mm_angle[p] >= 270)	mm_angle[p] = 320;
										if (mm_angle[p] < 340 && mm_angle[p] >= 270)	mm_angle[p] = 340;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
									else
									{
										mm_action[p] = AC_KICK_FWD;
										//pre angle limits
										if (mm_angle[p] < 130)		mm_angle[p] = 130;
										if (mm_angle[p] > 200)		mm_angle[p] = 200;
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
									}
								}

								PA[p][mm_action[p]]			= AS_PRE;
							}

							//---- defend only -------------------------------------------------------

							//already set separately
							if (mm_button[p] == 3)
							{
								//set start time of defense button
								t_defdown[p]				= p_time->current;
								mm_action[p]				= AC_DEFEND;
								PA[p][mm_action[p]]			= AS_ACTIVE;
							}

							//---- punch and defend --------------------------------------------------

							if (mm_button[p] == 4)
							{
							}

							//---- kick and defend ---------------------------------------------------

							if (mm_button[p] == 5)
							{
							}

							//---- special only --------------------------------------------------

							if (mm_button[p] == 6)
							{
								//if moved to the right
								if (mm_angle[p] >= 270 || mm_angle[p] < 90)
								{
									//on left push, on right pull
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PUSH_ARMS;
										//mm_angle_180 reinnehmen, falls pre angle limit
										//
										//pre angle limits
										//if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										//if (mm_angle[p] < 310 && mm_angle[p] >= 270)	mm_angle[p] = 310;
									}
									else
									{
										mm_action[p] = AC_PULL_ARMS;
										//mirror angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										//if (mm_angle[p] > 40 && mm_angle[p] <= 90)		mm_angle[p] = 40;
										//if (mm_angle[p] < 325 && mm_angle[p] >= 270)	mm_angle[p] = 325;
									}
								}
								else
								//mouse moved to left vice versa
								{
									if (si[p] == SLEFT)
									{
										mm_action[p] = AC_PULL_ARMS;
										//adjust angle but don't change angle_180
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//set reverse flag
										mm_angle_rev[p] = 1;
										//pre angle limits
										//if (mm_angle[p] < 140)		mm_angle[p] = 140;
										//if (mm_angle[p] > 215)		mm_angle[p] = 215;
									}
									else
									{
										mm_action[p] = AC_PUSH_ARMS;
										//pre angle limits
										//if (mm_angle[p] < 140)		mm_angle[p] = 140;
										//if (mm_angle[p] > 230)		mm_angle[p] = 230;
									}
								}
							}

							//------------------------------------------------------------------------

							//assign current relative mouse movement
							//mcx[p] += dimouse[1 + p_option->data.inputdevice[p]].lX;
							//mcy[p] += dimouse[1 + p_option->data.inputdevice[p]].lY;

							//if reverse flag set, reverse previous mouse x input
							//(y isn't reversed)
							if (mm_angle_rev[p] == 1)
								mcx[p] = -mcx[p];

							//set mm_state to pre-state
							mm_state[p]		= 1;
							//assign pre angles
							mm_angle_pre[p]		= mm_angle[p];
							mm_angle_180_pre[p]	= mm_angle_180[p];
						}
						else
						//buffer time not done yet, add mouse coordinates if valid button down
						//(which set start time)
						{
							if (mm_t_start[p] != 0)
							{
								mcx[p] = dicon[p_option->data.inputdevice[p] - 4].lX;
								mcy[p] = dicon[p_option->data.inputdevice[p] - 4].lY;
							}
						}

						break;
					}

				//---- pre state ---------------------------------------------------------------------
				case (1):
					{
						//assign relative mouse movement
						//if reverse flag set, reverse mouse x input
						if (mm_angle_rev[p] == 1)
							mcx[p] = -dicon[p_option->data.inputdevice[p] - 4].lX;
						else
							mcx[p] = dicon[p_option->data.inputdevice[p] - 4].lX;
						//mouse y not affected
						mcy[p] = dicon[p_option->data.inputdevice[p] - 4].lY;

						//get current length of movement
						mm_length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

						//if necessary assign new max length and max coordinates
						if (mm_length_c[p] > mm_length_m[p])
						{
							mm_length_m[p]	= mm_length_c[p];
							mmx[p]			= mcx[p];
							mmy[p]			= mcy[p];
						}

						//complete move flag (if time is up or button no longer down)
						bool cm				= false;
						//if mouse movement in defense mode 0 within mrad_fwd buffer
						//a cancel move shouldn't cancel the defense, but finish it
						bool def_nocancel	= false;

						//if punch/kick button is held down for more than a second
						//(adjusted to user set speed) cancel move
						if (mm_button[p] < 3)
						{
							if (p_time->current >= mm_t_start[p] + p_time->freq / p_option->data.speed)
							{
								//cancel move
								mm_state[p]			= 3;
								//set cancel
								mm_cancel[p]		= 1;
							}

							//if time passed sind mouse movement started >= p_option->data.t_defbuffer
							if (p_time->current >= mm_t_start[p] + p_time->freq * p_option->data.t_defbuffer[p])
								//if maximum mouse movement length <= p_option->data.crad
								if (mm_length_m[p] <= p_option->data.crad[p])
								{
									//complete defense tap move
									cm = true;
									//set flag to not cancel move if
									//mouse movement within mrad_fwd is a cancel move
									def_nocancel = true;
								}

/*							//if simple defense mode
	//						if (p_option->data.defense_mode[p] == dm_sim)
								//time passed since mouse movement started <= p_option->data.t_defbuffer
								if (p_time->current >= mm_t_start[p] + p_time->freq * p_option->data.t_defbuffer[p])
									//if (longest) mouse movement length <= mradius
	//								if (mm_length_c[p] <= p_option->data.mrad_fwd[p])
	//								if (mm_length_m[p] <= p_option->data.mrad_fwd[p])
									if (mm_length_m[p] <= p_option->data.crad[p])
									{
										//complete defense tap move
										cm = true;
										//set flag to not cancel move if
										//mouse movement within mrad_fwd is a cancel move
										def_nocancel = true;
									}*/
						}

						//defend
						if (mm_button[p] == 3)
						{
							//set flag to not cancel move if
							//mouse movement within crad is a cancel move
							def_nocancel = true;

							//!! auch nach p_option->data.t_defbuffer[p]?
							//complete move for (d)/(d + p)/(d + k) after 20ms
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								//complete defense
								cm = true;
							}
						}

						//special
						if (mm_button[p] == 6)
						{
							//don't cancel action if mouse movement within crad
							def_nocancel	= true;

							//finish move after 1/50 seconds
							if (p_time->current >= mm_t_start[p] + p_time->freq / 50)
							{
								cm = true;
							}

/*							//if longer hold than a half second cancel move
							if (p_time->current >= mm_t_start[p] + (p_time->freq * 0.5f) / p_option->data.speed)
							{
								//cancel move
								mm_state[p]			= 3;
								//set cancel
								mm_cancel[p]		= 1;
							}
*/						}

						//complete move if valid button up
						switch (mm_button[p])
						{
						//punch only
						case (1):
							{
								if (ui_state[p][PUNCH] == 0)	cm = true;
								break;
							}

						//kick only
						case (2):
							{
								if (ui_state[p][KICK] == 0)		cm = true;
								break;
							}

						//defend only
						case (3):
							{
								if (ui_state[p][DEFEND] == 0)	cm = true;
								break;
							}

						//punch and defend
						case (4):
							{
								//if (ui_state[p][PUNCH] == 0 || ui_state[p][DEFEND] == 0)	cm = true;
								//break;
							}

						//kick and defend
						case (5):
							{
								//if (ui_state[p][KICK] == 0 || ui_state[p][DEFEND] == 0)		cm = true;
								//break;
							}

						//special only
						case (6):
							{
								if (ui_state[p][SPECIAL] == 0)	cm = true;
								break;
							}
						}

						//complete move
						if (cm == true)
						{
							//calculate angle of current position
							//!! and also angle of maximum position
							//integer division

							//angle of pre_state input
	//						int mm_angle_pre	= mm_angle[p];
	//						int mm_angle_pre180	= mm_angle_180[p];

							//no division through 0
							if (mm_length_c[p] != 0)
								mm_angle[p] = (int)(acos(mcx[p] / mm_length_c[p]) * 180 / PI);
							else
								mm_angle[p] = 0;

							//!! angle of maximum length?
							float mm_angle_m;
							if (mm_length_m[p] != 0)
								mm_angle_m = (float)acos(mmx[p] / mm_length_m[p]) * 180 / PI;
							else
								mm_angle_m = 0;

							//if y-position (current and max) is negative, angle is negative
							//so take 360 - angle
							if (mcy[p] < 0)			mm_angle[p]	= 360 - mm_angle[p];
							if (mmy[p] < 0)			mm_angle_m	= 360 - mm_angle_m;

							//no 360 degrees (existing because of round errors?)
							if (mm_angle[p] == 360)				mm_angle[p] = 0;
							if (mm_angle_m == 360)				mm_angle_m = 0;

							//apply user set sensitivity
							if (p_option->data.sensitivity[p] != 1.0f)
							{
								//convert mm_angle into 0 to 90 degree
								//apply sensitivity and adjust mm_angle according to new value
								if (mm_angle[p] <= 90)
								{
									mm_angle[p] = (int)(mm_angle[p] / p_option->data.sensitivity[p]);
								}
								if (mm_angle[p] > 90 && mm_angle[p] < 180)
								{
									mm_angle[p] = (int)(180 - ((180 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 180 && mm_angle[p] < 270)
								{
									mm_angle[p] = (int)(180 + ((-180 + mm_angle[p]) / p_option->data.sensitivity[p]));
								}
								if (mm_angle[p] >= 270)
								{
									mm_angle[p] = (int)(360 - ((360 - mm_angle[p]) / p_option->data.sensitivity[p]));
								}
							}

							//if the final angle is on the other side compared to pre angel
							//cancel move
							//(mirror final angle)
							//don't if within defense mode 0 buffer radius
							if (!def_nocancel)
								if (mm_angle_pre[p] > 270 || mm_angle_pre[p] <= 90)
								{
									if (mm_angle[p] > 90 && mm_angle[p] <= 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}
								else
								{
									if (mm_angle[p] <= 90 || mm_angle[p] > 270)
									{
										//cancel move
										mm_state[p] = 3;
										break;
		/*								//mirror
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									}
								}

							//set 180 angle
							if (mm_angle[p] > 270)
								mm_angle_180[p] = mm_angle[p] - 271;
							if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
								mm_angle_180[p] = mm_angle[p] + 89;
							if (mm_angle[p] > 90 && mm_angle[p] <= 270)
								mm_angle_180[p] = 270 - mm_angle[p];

							//move counts as canceled if the length of the final mouse position
							//<= the length of the whole mouse movement * 0.75
							//cancel only possible if punch or kick
							//don't if within defense mode 0 buffer radius
							/*if (mm_button[p] < 3)
							{
								if (mm_length_c[p] <= mm_length_m[p] * 0.75 &&
									!def_nocancel)
								{
									//cancel and break
									mm_state[p] = 3;
									break;
								}
								else
									mm_state[p]	= 2;
							}
							else
								mm_state[p] = 2;*/
							//move canceled if analogstick back in neutral position
							//plus tolerance zone crad

							if (mm_button[p] < 3)
							{
								if (dicon[p_option->data.inputdevice[p] - 4].lX < p_option->data.crad[p] &&
									dicon[p_option->data.inputdevice[p] - 4].lX > -p_option->data.crad[p] &&
									dicon[p_option->data.inputdevice[p] - 4].lY < p_option->data.crad[p] &&
									dicon[p_option->data.inputdevice[p] - 4].lY > -p_option->data.crad[p] &&
									!def_nocancel)
								{
									//cancel and break
									mm_state[p] = 3;
									break;
								}
								else
									mm_state[p]	= 2;
							}
							else
								mm_state[p] = 2;

							//set final data
							switch (mm_button[p])
							{
							//punch only
							case (1):
								{
									if (mm_action[p] == AC_JAB)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_JAB;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_JAB]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)			mm_angle[p] = 40;
											if (mm_angle[p] < 310 && mm_angle[p] >= 270)		mm_angle[p] = 310;
										}
										else
										{
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 230)		mm_angle[p] = 230;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_CROSS)
									{
										//mirror final angle up/down
										//if (si[p] == SLEFT)					mm_angle[p] = 180 - (mm_angle[p] - 180);
										//else								mm_angle[p] = 360 - mm_angle[p];
										mm_angle[p]	= 360 - mm_angle[p];

										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											//mm_action[p]		= AC_TAP_CROSS;
											mm_action[p]		= AC_TAP_ARMS;
											//PA[p][AC_TAP_CROSS]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff = 15;

										//adjust pre angle (since it's both reversed up/down and left/right)
										//mm_angle_pre[p] += 180;
										//if (mm_angle_pre[p] > 359)		mm_angle_pre[p] -= 360;
										//if (mm_angle_pre[p] < 0)		mm_angle_pre[p] += 360;

										//final angle limits
										if (si[p] == SLEFT)
										{
											//if (mm_angle[p] > 40 && mm_angle[p] <= 90)				mm_angle[p] = 40;
											//if (mm_angle[p] < 310 && mm_angle[p] >= 270)			mm_angle[p] = 310;
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 215)		mm_angle[p] = 215;
										}
										else
										{
											//if (mm_angle[p] < 140)		mm_angle[p] = 140;
											//if (mm_angle[p] > 230)		mm_angle[p] = 230;
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)				mm_angle[p] = 40;
											if (mm_angle[p] < 325 && mm_angle[p] >= 270)			mm_angle[p] = 325;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180[p] = 180 - mm_angle_180[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];
										//mirror since mm_angle is mirrored on y-axis
										mm_angle_180_pre[p] = 180 - mm_angle_180_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;
											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
											//mirror since mm_angle is mirrored on y-axis
											mm_angle_180[p] = 180 - mm_angle_180[p];
										}

										break;
									}
								}

							//kick only
							case (2):
								{
									if (mm_action[p] == AC_KICK_FWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
											break;
										}

										//maximum pre-final angle difference
										int maxdiff	= 15;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											if (mm_angle[p] < 340 && mm_angle[p] >= 270)		mm_angle[p] = 340;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											if (mm_angle[p] > 200)		mm_angle[p] = 200;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//y-axis context
										//if mouse moved down and button released after moved up
										//or vice versa trigger context event
										if (mm_angle_180_pre[p] - mm_angle_180[p] >= 20)
											ycontext_up[p] = true;
										if (mm_angle_180_pre[p] - mm_angle_180[p] <= -20)
											ycontext_do[p] = true;

										//context
										if (ycontext_up[p])
										{
											PA[p][mm_action[p]]		= AS_CONTEXT;

											//context angle limits
											if (si[p] == SLEFT)
											{
												if (mm_angle[p] > 20 && mm_angle[p] <= 90)			mm_angle[p] = 20;
												if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
											}
											else
											{
												if (mm_angle[p] < 160)		mm_angle[p] = 160;
												if (mm_angle[p] > 220)		mm_angle[p] = 220;
											}

											break;
										}
										if (ycontext_do[p])
										{
											//PA[p][mm_action[p]]	= AS_CONTEXT;
											//break;
											ycontext_do[p]		= false;
										}

										//pre final angle difference
										//if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}

									if (mm_action[p] == AC_KICK_SWD)
									{
										//short/long movement
										if (mm_length_c[p] <= p_option->data.crad[p])
										{
											PA[p][mm_action[p]] = AS_INACTIVE;
											mm_action[p]		= AC_TAP_LEG;
											//PA[p][AC_TAP_LEG]	= AS_FINAL;
										}

										//maximum pre-final angle difference
										int maxdiff	= 30;

										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											//if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
											if (mm_angle[p] < 340 && mm_angle[p] >= 270)		mm_angle[p] = 340;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											//if (mm_angle[p] > 220)		mm_angle[p] = 220;
											if (mm_angle[p] > 200)		mm_angle[p] = 200;
										}
										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										//adjust 180 pre angle
										//in pre state angle 180 is not adjusted to
										//angle limits (allows deeper jab)
										//but for ycontext it needs to be adjusted to
										//angle limits or else if final angel gets
										//adjusted ycontext could get set unintentional
										if (mm_angle_pre[p] > 270)
											mm_angle_180_pre[p] = mm_angle_pre[p] - 271;
										if (mm_angle_pre[p] >= 0 && mm_angle_pre[p] <= 90)
											mm_angle_180_pre[p] = mm_angle_pre[p] + 89;
										if (mm_angle_pre[p] > 90 && mm_angle_pre[p] <= 270)
											mm_angle_180_pre[p] = 270 - mm_angle_pre[p];

										//context
										ycontext_up[p]			= false;
										ycontext_do[p]			= false;

										//pre final angle difference
										if (!ycontext_up[p] && !ycontext_do[p])
										{
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) >= maxdiff)
												mm_angle[p]	= mm_angle_pre[p] - maxdiff;
											if (angle_diff(mm_angle[p], mm_angle_pre[p]) <= -maxdiff)
												mm_angle[p]	= mm_angle_pre[p] + maxdiff;
											//angle limits
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;

											//set 180 angle
											if (mm_angle[p] > 270)
												mm_angle_180[p] = mm_angle[p] - 271;
											if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
												mm_angle_180[p] = mm_angle[p] + 89;
											if (mm_angle[p] > 90 && mm_angle[p] <= 270)
												mm_angle_180[p] = 270 - mm_angle[p];
										}

										break;
									}
								}

							//defend only
							case (3):
								{
									break;
								}

							//punch and defend
							case (4):
								{
									break;
								}

							//kick and defend
							case (5):
								{
									break;
								}

							//special only
							case (6):
								{
									//cancel if current mouse movement too short
									if (mm_length_c[p] <= p_option->data.crad[p] * 2.5f)
									{
										PA[p][mm_action[p]]	= AS_INACTIVE;
										//cancel move
										mm_state[p]			= 3;
										//set cancel
										mm_cancel[p]		= 1;

										break;
									}

									//reset special key double tap
									t_laststate1D[p][SPECIAL][0]	= 0;
									t_laststate1D[p][SPECIAL][1]	= 0;

									if (mm_action[p] == AC_PUSH_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 40 && mm_angle[p] <= 90)			mm_angle[p] = 40;
											if (mm_angle[p] < 310 && mm_angle[p] >= 270)		mm_angle[p] = 310;
										}
										else
										{
											if (mm_angle[p] < 140)		mm_angle[p] = 140;
											if (mm_angle[p] > 230)		mm_angle[p] = 230;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}

									if (mm_action[p] == AC_PULL_ARMS)
									{
										//final angle limits
										if (si[p] == SLEFT)
										{
											if (mm_angle[p] > 50 && mm_angle[p] <= 90)			mm_angle[p] = 50;
											if (mm_angle[p] < 320 && mm_angle[p] >= 270)		mm_angle[p] = 320;
										}
										else
										{
											if (mm_angle[p] < 130)		mm_angle[p] = 130;
											if (mm_angle[p] > 220)		mm_angle[p] = 220;
										}

										//set 180 angle
										if (mm_angle[p] > 270)
											mm_angle_180[p] = mm_angle[p] - 271;
										if (mm_angle[p] >= 0 && mm_angle[p] <= 90)
											mm_angle_180[p] = mm_angle[p] + 89;
										if (mm_angle[p] > 90 && mm_angle[p] <= 270)
											mm_angle_180[p] = 270 - mm_angle[p];

										break;
									}
								}
							}
						}

						break;
					}

				//case 2 and 3 reset
				//---- final state -------------------------------------------------------------------
				case (2):
					{
						//complete action if not already context activated
						if (PA[p][mm_action[p]] != AS_CONTEXT)
							PA[p][mm_action[p]] = AS_FINAL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}

				//---- canceling ---------------------------------------------------------------------
				case (3):
					{
						//cancel action
						PA[p][mm_action[p]] = AS_CANCEL;

						//set button flag
						mm_button_flag[p]	= mm_button[p];

						//reset data
						mm_state[p]			= 0;
						mm_t_start[p]		= 0;
						mm_button[p]		= 0;
						mcx[p] = mcy[p]		= 0;
						mmx[p] = mmy[p]		= 0;
	//					mcc[p]				= 0;
						ycontext_up[p]		= false;
						ycontext_do[p]		= false;

						mm_length_c[p]		= 0;
						mm_length_m[p]		= 0;
						mm_angle_rev[p]		= 0;
						break;
					}
				}
			}
		}

		//reset mouse data
		//reset_mouse_mov_data();
	};

	//---- reset mouse move data -----------------------------------------------------------------

	void reset_mouse_mov_data()
	{
		//reset mouse data
		for (register int i = 0; i < 4; ++i)
		{
			dimouse[i].lX			= 0;
			dimouse[i].lY			= 0;
			dimouse[i].lZ			= 0;
		}
	};

	//---- angle_diff_abs ------------------------------------------------------------------------
	//returns shortest absolute difference between two angles (0 - 360 degree)

	int angle_diff_abs(int a1, int a2)
	{
		if (a2 < a1)
		{
			if (a1 - a2 <= 180)
			{
				return(a1 - a2);
			}
			else
			{
				return(a2 + (360 - a1));
			}
		}
		else
		{
			if (a2 - a1 <= 180)
			{
				return(a2 - a1);
			}
			else
			{
				return(a1 + (360 - a2));
			}
		}
	};

	//---- angle_diff ----------------------------------------------------------------------------
	//returns shortest relative (from a1) difference between two angles (0 - 360 degree)

	int angle_diff(int a1, int a2)
	{
		if (a2 < a1)
		{
			if (a1 - a2 <= 180)
			{
				//diff negative
				return(-a1 + a2);
			}
			else
			{
				//diff positive
				return(a2 + (360 - a1));
			}
		}
		else
		{
			if (a2 - a1 <= 180)
			{
				//diff positive
				return(a2 - a1);
			}
			else
			{
				//diff negative
				return(-(a1 + (360 - a2)));
			}
		}
	};

	//---- fill_DIKASCII_LUT ---------------------------------------------------------------------
	//fills DIK to ASCII look up table, either shifted or unshifted version

	void fill_DIKASCII_LUT(WORD *plut, int shifted)
	{
		//clear lut
		for (register int i = 0; i < 256; ++i)
			plut[i]	= 0;

		if (!shifted)
		{
			//numbers
			plut[DIK_0]				= 48;
			plut[DIK_1]				= 49;
			plut[DIK_2]				= 50;
			plut[DIK_3]				= 51;
			plut[DIK_4]				= 52;
			plut[DIK_5]				= 53;
			plut[DIK_6]				= 54;
			plut[DIK_7]				= 55;
			plut[DIK_8]				= 56;
			plut[DIK_9]				= 57;

			//letters
			plut[DIK_A]				= 97;
			plut[DIK_B]				= 98;
			plut[DIK_C]				= 99;
			plut[DIK_D]				= 100;
			plut[DIK_E]				= 101;
			plut[DIK_F]				= 102;
			plut[DIK_G]				= 103;
			plut[DIK_H]				= 104;
			plut[DIK_I]				= 105;
			plut[DIK_J]				= 106;
			plut[DIK_K]				= 107;
			plut[DIK_L]				= 108;
			plut[DIK_M]				= 109;
			plut[DIK_N]				= 110;
			plut[DIK_O]				= 111;
			plut[DIK_P]				= 112;
			plut[DIK_Q]				= 113;
			plut[DIK_R]				= 114;
			plut[DIK_S]				= 115;
			plut[DIK_T]				= 116;
			plut[DIK_U]				= 117;
			plut[DIK_V]				= 118;
			plut[DIK_W]				= 119;
			plut[DIK_X]				= 120;
			plut[DIK_Y]				= 121;
			plut[DIK_Z]				= 122;

			//symbols
			plut[DIK_ESCAPE]		= 0;		//27
			plut[DIK_MINUS]			= 45;
			plut[DIK_EQUALS]		= 61;
			plut[DIK_BACK]			= 0;
			plut[DIK_TAB]			= 0;
			plut[DIK_LBRACKET]		= 91;
			plut[DIK_RBRACKET]		= 93;
			plut[DIK_RETURN]		= 0;
			plut[DIK_LCONTROL]		= 0;
			plut[DIK_SEMICOLON]		= 59;
			plut[DIK_APOSTROPHE]	= 39;
			plut[DIK_GRAVE]			= 0;
			plut[DIK_LSHIFT]		= 0;
			plut[DIK_BACKSLASH]		= 92;
			plut[DIK_COMMA]			= 44;
			plut[DIK_PERIOD]		= 46;
			plut[DIK_SLASH]			= 47;
			plut[DIK_RSHIFT]		= 0;
			plut[DIK_MULTIPLY]		= 42;
			plut[DIK_LMENU]			= 0;
			plut[DIK_SPACE]			= 32;
			plut[DIK_CAPITAL]		= 0;
			plut[DIK_F1]			= 0;
			plut[DIK_F2]			= 0;
			plut[DIK_F3]			= 0;
			plut[DIK_F4]			= 0;
			plut[DIK_F5]			= 0;
			plut[DIK_F6]			= 0;
			plut[DIK_F7]			= 0;
			plut[DIK_F8]			= 0;
			plut[DIK_F9]			= 0;
			plut[DIK_F10]			= 0;
			plut[DIK_F11]			= 0;
			plut[DIK_F12]			= 0;
			plut[DIK_NUMLOCK]		= 0;
			plut[DIK_SCROLL]		= 0;
			plut[DIK_NUMPAD7]		= 55;
			plut[DIK_NUMPAD8]		= 56;
			plut[DIK_NUMPAD9]		= 57;
			plut[DIK_SUBTRACT]		= 45;
			plut[DIK_NUMPAD4]		= 52;
			plut[DIK_NUMPAD5]		= 53;
			plut[DIK_NUMPAD6]		= 54;
			plut[DIK_ADD]			= 43;
			plut[DIK_NUMPAD1]		= 49;
			plut[DIK_NUMPAD2]		= 50;
			plut[DIK_NUMPAD3]		= 51;
			plut[DIK_NUMPAD0]		= 48;
			plut[DIK_DECIMAL]		= 46;
			plut[DIK_OEM_102]		= 92;
			plut[DIK_NUMPADENTER]	= 0;
			plut[DIK_RCONTROL]		= 0;
			plut[DIK_NUMPADCOMMA]	= 44;
			plut[DIK_DIVIDE]		= 47;
			plut[DIK_SYSRQ]			= 0;
			plut[DIK_RMENU]			= 0;
			plut[DIK_PAUSE]			= 0;
			plut[DIK_HOME]			= 0;
			plut[DIK_UP]			= 0;
			plut[DIK_PRIOR]			= 0;
			plut[DIK_LEFT]			= 0;
			plut[DIK_RIGHT]			= 0;
			plut[DIK_END]			= 0;
			plut[DIK_DOWN]			= 0;
			plut[DIK_NEXT]			= 0;
			plut[DIK_INSERT]		= 0;
			plut[DIK_DELETE]		= 0;
			plut[DIK_LWIN]			= 0;
			plut[DIK_RWIN]			= 0;
			plut[DIK_APPS]			= 0;
		}
		else
		{
			//numbers
			plut[DIK_0]				= 41;
			plut[DIK_1]				= 33;
			plut[DIK_2]				= 64;
			plut[DIK_3]				= 35;
			plut[DIK_4]				= 36;
			plut[DIK_5]				= 37;
			plut[DIK_6]				= 94;
			plut[DIK_7]				= 38;
			plut[DIK_8]				= 42;
			plut[DIK_9]				= 40;

			//letters
			plut[DIK_A]				= 65;
			plut[DIK_B]				= 66;
			plut[DIK_C]				= 67;
			plut[DIK_D]				= 68;
			plut[DIK_E]				= 69;
			plut[DIK_F]				= 70;
			plut[DIK_G]				= 71;
			plut[DIK_H]				= 72;
			plut[DIK_I]				= 73;
			plut[DIK_J]				= 74;
			plut[DIK_K]				= 75;
			plut[DIK_L]				= 76;
			plut[DIK_M]				= 77;
			plut[DIK_N]				= 78;
			plut[DIK_O]				= 79;
			plut[DIK_P]				= 80;
			plut[DIK_Q]				= 81;
			plut[DIK_R]				= 82;
			plut[DIK_S]				= 83;
			plut[DIK_T]				= 84;
			plut[DIK_U]				= 85;
			plut[DIK_V]				= 86;
			plut[DIK_W]				= 87;
			plut[DIK_X]				= 88;
			plut[DIK_Y]				= 89;
			plut[DIK_Z]				= 90;

			//symbols
			plut[DIK_ESCAPE]		= 0;		//27
			plut[DIK_MINUS]			= 95;
			plut[DIK_EQUALS]		= 43;
			plut[DIK_BACK]			= 0;
			plut[DIK_TAB]			= 0;
			plut[DIK_LBRACKET]		= 123;
			plut[DIK_RBRACKET]		= 125;
			plut[DIK_RETURN]		= 0;
			plut[DIK_LCONTROL]		= 0;
			plut[DIK_SEMICOLON]		= 58;
			plut[DIK_APOSTROPHE]	= 34;
			plut[DIK_GRAVE]			= 0;
			plut[DIK_LSHIFT]		= 0;
			plut[DIK_BACKSLASH]		= 124;
			plut[DIK_COMMA]			= 60;
//			plut[DIK_PERIOD]		= 62;
			plut[DIK_PERIOD]		= 46;
			plut[DIK_SLASH]			= 63;
			plut[DIK_RSHIFT]		= 0;
			plut[DIK_MULTIPLY]		= 42;
			plut[DIK_LMENU]			= 0;
			plut[DIK_SPACE]			= 32;
			plut[DIK_CAPITAL]		= 0;
			plut[DIK_F1]			= 0;
			plut[DIK_F2]			= 0;
			plut[DIK_F3]			= 0;
			plut[DIK_F4]			= 0;
			plut[DIK_F5]			= 0;
			plut[DIK_F6]			= 0;
			plut[DIK_F7]			= 0;
			plut[DIK_F8]			= 0;
			plut[DIK_F9]			= 0;
			plut[DIK_F10]			= 0;
			plut[DIK_F11]			= 0;
			plut[DIK_F12]			= 0;
			plut[DIK_NUMLOCK]		= 0;
			plut[DIK_SCROLL]		= 0;
			plut[DIK_NUMPAD7]		= 55;
			plut[DIK_NUMPAD8]		= 56;
			plut[DIK_NUMPAD9]		= 57;
			plut[DIK_SUBTRACT]		= 45;
			plut[DIK_NUMPAD4]		= 52;
			plut[DIK_NUMPAD5]		= 53;
			plut[DIK_NUMPAD6]		= 54;
			plut[DIK_ADD]			= 43;
			plut[DIK_NUMPAD1]		= 49;
			plut[DIK_NUMPAD2]		= 50;
			plut[DIK_NUMPAD3]		= 51;
			plut[DIK_NUMPAD0]		= 48;
			plut[DIK_DECIMAL]		= 46;
			plut[DIK_OEM_102]		= 124;
			plut[DIK_NUMPADENTER]	= 0;
			plut[DIK_RCONTROL]		= 0;
			plut[DIK_NUMPADCOMMA]	= 44;
			plut[DIK_DIVIDE]		= 47;
			plut[DIK_SYSRQ]			= 0;
			plut[DIK_RMENU]			= 0;
			plut[DIK_PAUSE]			= 0;
			plut[DIK_HOME]			= 0;
			plut[DIK_UP]			= 0;
			plut[DIK_PRIOR]			= 0;
			plut[DIK_LEFT]			= 0;
			plut[DIK_RIGHT]			= 0;
			plut[DIK_END]			= 0;
			plut[DIK_DOWN]			= 0;
			plut[DIK_NEXT]			= 0;
			plut[DIK_INSERT]		= 0;
			plut[DIK_DELETE]		= 0;
			plut[DIK_LWIN]			= 0;
			plut[DIK_RWIN]			= 0;
			plut[DIK_APPS]			= 0;
		}
	};

	//---- fill_KEYDESC_LUT ----------------------------------------------------------------------
	//fills DIK/ASCII key description table

	void fill_KEYDESC_LUT(char **plut, int _dik)
	{
		//clear lut
		for (register int i = 0; i < 256; ++i)
			plut[i]	= NOTAVAILABLE;

		//numbers
		plut[DIK_0]				= "0";
		plut[DIK_1]				= "1";
		plut[DIK_2]				= "2";
		plut[DIK_3]				= "3";
		plut[DIK_4]				= "4";
		plut[DIK_5]				= "5";
		plut[DIK_6]				= "6";
		plut[DIK_7]				= "7";
		plut[DIK_8]				= "8";
		plut[DIK_9]				= "9";

		//letters
		plut[DIK_A]				= "A";
		plut[DIK_B]				= "B";
		plut[DIK_C]				= "C";
		plut[DIK_D]				= "D";
		plut[DIK_E]				= "E";
		plut[DIK_F]				= "F";
		plut[DIK_G]				= "G";
		plut[DIK_H]				= "H";
		plut[DIK_I]				= "I";
		plut[DIK_J]				= "J";
		plut[DIK_K]				= "K";
		plut[DIK_L]				= "L";
		plut[DIK_M]				= "M";
		plut[DIK_N]				= "N";
		plut[DIK_O]				= "O";
		plut[DIK_P]				= "P";
		plut[DIK_Q]				= "Q";
		plut[DIK_R]				= "R";
		plut[DIK_S]				= "S";
		plut[DIK_T]				= "T";
		plut[DIK_U]				= "U";
		plut[DIK_V]				= "V";
		plut[DIK_W]				= "W";
		plut[DIK_X]				= "X";
		plut[DIK_Y]				= "Y";
		plut[DIK_Z]				= "Z";

		//symbols
		plut[DIK_MINUS]			= "-";
		plut[DIK_PERIOD]		= ".";
		plut[DIK_SPACE]			= "SPACE";
		plut[DIK_ESCAPE]		= "ESC";
		plut[DIK_EQUALS]		= "=";
		plut[DIK_BACK]			= "BACK";
		plut[DIK_TAB]			= "TAB";
		plut[DIK_LBRACKET]		= "[";
		plut[DIK_RBRACKET]		= "]";
		plut[DIK_RETURN]		= "RET";
		plut[DIK_LCONTROL]		= "LCON";
		plut[DIK_RCONTROL]		= "RCON";
		plut[DIK_SEMICOLON]		= ";";
		plut[DIK_APOSTROPHE]	= "'";
		plut[DIK_GRAVE]			= "GRAVE";
		plut[DIK_LSHIFT]		= "LSHI";
		plut[DIK_RSHIFT]		= "RSHI";
		plut[DIK_BACKSLASH]		= "\\";
		plut[DIK_COMMA]			= ",";
		plut[DIK_SLASH]			= "/";
		plut[DIK_MULTIPLY]		= "NP*";
		plut[DIK_LMENU]			= "LALT";
		plut[DIK_RMENU]			= "RALT";
		plut[DIK_CAPITAL]		= "CAPS";
		plut[DIK_F1]			= "F1";
		plut[DIK_F2]			= "F2";
		plut[DIK_F3]			= "F3";
		plut[DIK_F4]			= "F4";
		plut[DIK_F5]			= "F5";
		plut[DIK_F6]			= "F6";
		plut[DIK_F7]			= "F7";
		plut[DIK_F8]			= "F8";
		plut[DIK_F9]			= "F9";
		plut[DIK_F10]			= "F10";
		plut[DIK_NUMLOCK]		= "NUM";
		plut[DIK_SCROLL]		= "SCR";
		plut[DIK_NUMPAD7]		= "NP7";
		plut[DIK_NUMPAD8]		= "NP8";
		plut[DIK_NUMPAD9]		= "NP9";
		plut[DIK_SUBTRACT]		= "NP-";
		plut[DIK_NUMPAD4]		= "NP4";
		plut[DIK_NUMPAD5]		= "NP5";
		plut[DIK_NUMPAD6]		= "NP6";
		plut[DIK_ADD]			= "NP+";
		plut[DIK_NUMPAD1]		= "NP1";
		plut[DIK_NUMPAD2]		= "NP2";
		plut[DIK_NUMPAD3]		= "NP3";
		plut[DIK_NUMPAD0]		= "NP0";
		plut[DIK_DECIMAL]		= "NP.";
		plut[DIK_OEM_102]		= "GARR";
		plut[DIK_F11]			= "F11";
		plut[DIK_F12]			= "F12";
		plut[DIK_NUMPADEQUALS]	= "NP=";
		plut[DIK_NUMPADENTER]	= "NPRET";
		plut[DIK_NUMPADCOMMA]	= "NP,";
		plut[DIK_DIVIDE]		= "NP/";
		plut[DIK_SYSRQ]			= "SYSRQ";
		plut[DIK_PAUSE]			= "PAUSE";
		plut[DIK_HOME]			= "HOME";
		plut[DIK_UP]			= "UP";
		plut[DIK_DOWN]			= "DOWN";
		plut[DIK_LEFT]			= "LEFT";
		plut[DIK_RIGHT]			= "RIGHT";
		plut[DIK_PRIOR]			= "PGUP";
		plut[DIK_END]			= "END";
		plut[DIK_NEXT]			= "PGDN";
		plut[DIK_INSERT]		= "INS";
		plut[DIK_DELETE]		= "DEL";
		plut[DIK_LWIN]			= "LWIN";
		plut[DIK_RWIN]			= "RWIN";
		plut[DIK_APPS]			= "APPS";
	};

	//---- fill_FUNCDESC_LUT ---------------------------------------------------------------------
	//fills array with function description strings

	void fill_FUNCDESC_LUT(char **plut)
	{
		//clear lut
		for (register int i = 0; i < 256; ++i)
			plut[i]	= NOTAVAILABLE;

		plut[cP1PUNCH]			= "p1punch";
		plut[cP1KICK]			= "p1kick";
		plut[cP1DEFEND]			= "p1defend";
		plut[cP1LEFT]			= "p1left";
		plut[cP1RIGHT]			= "p1right";
		plut[cP1SPECIAL]		= "p1special";
		plut[cP2PUNCH]			= "p2punch";
		plut[cP2KICK]			= "p2kick";
		plut[cP2DEFEND]			= "p2defend";
		plut[cP2LEFT]			= "p2left";
		plut[cP2RIGHT]			= "p2right";
		plut[cP2SPECIAL]		= "p2special";

		plut[cP1STANCEUP]		= "p1stanceup";
		plut[cP1STANCEDOWN]		= "p1stancedown";
		plut[cP2STANCEUP]		= "p2stanceup";
		plut[cP2STANCEDOWN]		= "p2stancedown";

		plut[cPAUSE]			= "pause";
		plut[cEXIT]				= "exit";
		plut[cCONSOLE]			= "console";
		plut[cSCREENSHOT]		= "screenshot";
		plut[cSCREENMODE]		= "screenmode";
		plut[cVSYNC]			= "vsync";
		plut[cSHADOWS]			= "shadows";
		plut[cBLURUP]			= "blurup";
		plut[cBLURDOWN]			= "blurdown";
		plut[cSPEEDUP]			= "speedup";
		plut[cSPEEDDOWN]		= "speeddown";
		plut[cSOUND]			= "sound";
		plut[cBWMODE]			= "bwmode";
		plut[cDAMUP]			= "damup";
		plut[cDAMDOWN]			= "damdown";
		plut[cFATUP]			= "fatup";
		plut[cFATDOWN]			= "fatdown";

		plut[cTOGGLEBOT1]		= "togglebot1";
		plut[cTOGGLEBOT2]		= "togglebot2";

		//!! ergaenzen!
	};

	//---- hud text ------------------------------------------------------------------------------

	void hud_add_message(int _hud_id, int color, char *format, ...)
	{
		//no text
		if (format == NULL)
		{
			gf_logger(true, "di::is.hud_add_message NULL");
			return;
		}

		//verify id
		if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
		if (_hud_id < 0)				_hud_id = 0;

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
//		char *pbuffer	= new char[strlen(format) + 1];
		char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
		//copy message into buffer
		vsprintf(pbuffer, format, ap);
		//clear up
		va_end(ap);

		//create new hud entry
		p_hud_text[_hud_id].add_entry(color, pbuffer);

//		delete []	pbuffer;
//		pbuffer		= NULL;
	}

	void hud_add_message(char *format, ...)
	{
		//no text
		if (format == NULL)
		{
			gf_logger(true, "di:is.hud_add_message NULL");
			return;
		}

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
//		char *pbuffer	= new char[strlen(format) + 1];
		char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
		//copy message into buffer
		vsprintf(pbuffer, format, ap);
		//clear up
		va_end(ap);

		//default values
		int _hud_id		= 0;
		int color		= bmfblack;

		//create new hud entry
		p_hud_text[_hud_id].add_entry(color, pbuffer);

//		delete []	pbuffer;
//		pbuffer		= NULL;
	}
};

//------------------------------------------------------------------------------------------------
//
//	rawinput
//
//------------------------------------------------------------------------------------------------

struct rawinput
{
	//---- raw input data ------------------------------------------------------------------------

	HANDLE			*pRImouse;				//pointer to array of handles with all available ri mice
	HANDLE			pRIsysmouse;			//pointer to system mouse handle
	UINT			RIDn;					//number of all raw input devices
	UINT			RIMn;					//number of all raw input mice

	//---- constructor ---------------------------------------------------------------------------

	rawinput()
	{
		//raw input data
		pRImouse				= NULL;
		pRIsysmouse				= NULL;
		RIDn					= 0;
		RIMn					= 0;
	};

	//---- destructor ----------------------------------------------------------------------------

	~rawinput()
	{
		//raw input data
		if (pRImouse != NULL)
		{
			delete [] pRImouse;
			pRImouse	= NULL;
		}
		pRIsysmouse				= NULL;
		RIDn					= 0;
		RIMn					= 0;
	};

	//---- setup --------------------------------------------------------------------------------
	//enumerates and registers all mice
	//gets reference to mf option object to verify player_mouse data after setup

	bool setup(options &option)
	{
		RAWINPUTDEVICE RID[1]					= {0};		//RI device info for initialization
		int rir									= 0;		//raw input result
		PRAWINPUTDEVICELIST pRawInputDeviceList	= NULL;		//pointer to RI device list

		//get number of RI devices
		rir	= GetRawInputDeviceList(NULL, &RIDn, sizeof(RAWINPUTDEVICELIST));
		if (rir == -1)
		{
			gf_logger(true, "rawinput::RI_setup (%i)GetRawInputDeviceList #RID FAILED", rir);
			return(false);
		}
		else
		{
			gf_logger(false, "rawinput::RI_setup Number of RI Devices: %i", RIDn);
			//reset
			rir = 0;
		}

		//limit maximum number of devices
		if (RIDn > RIDmax)			RIDn	= RIDmax;

		//allocate RI device list
		if (RIDn > 0)
		{
			pRawInputDeviceList = new RAWINPUTDEVICELIST[sizeof(RAWINPUTDEVICELIST) * RIDn];
			if (pRawInputDeviceList == NULL)
			{
				gf_logger(true, "rawinput::RI_setup allocate RI device list FAILED");
				return(false);
			}
		}
		else
		{
			gf_logger(true, "rawinput::RI_setup RIDn: %i", RIDn);
			return(false);
		}

		//fill RI device list
		rir = GetRawInputDeviceList(pRawInputDeviceList, &RIDn, sizeof(RAWINPUTDEVICELIST));
		if (rir == -1)
		{
			//free RI device list
			if (pRawInputDeviceList != NULL)
				delete [] pRawInputDeviceList;

			gf_logger(true, "rawinput::RI_setup (%i)GetRawInputDeviceList Fill FAILED", rir);
			return(false);
		}
		else
		{
			//reset
			rir = 0;
		}

		//count every mouse
		for (register int d = 0; d < (int)RIDn; ++d)
		{
			//if device is mouse
			if (pRawInputDeviceList[d].dwType == RIM_TYPEMOUSE)
			{
				//increase number of available mice
				++RIMn;
			}
		}
		//allocate RI mouse pointer array
		if (RIMn > 0)
		{
			pRImouse = new HANDLE[sizeof(HANDLE) * RIMn];
			if (pRImouse == NULL)
			{
				gf_logger(true, "rawinput::RI_setup allocate pRImouse FAILED");
				return(false);
			}
			if (RIMn > 1)		gf_logger(false, "rawinput::RI_setup Mice found: %i", RIMn);
			else				gf_logger(false, "rawinput::RI_setup Mouse found: %i", RIMn);
		}
		else
		{
			gf_logger(true, "rawinput::RI_setup No Mouse found");
			return(false);
		}

		//index counter for pRImouse array
		int mc	= 0;
		//for every available RI device
		//get type and name of device and log data
		for (d = 0; d < (int)RIDn; ++d)
		{
			//size of device name
			UINT nSize		= 0;
			//pointer to device name
			char *pRIDName	= NULL;

			//get size of device name
			rir = GetRawInputDeviceInfo(pRawInputDeviceList[d].hDevice, RIDI_DEVICENAME, NULL, &nSize);
			if (rir != 0)
			{
				gf_logger(true, "rawinput::RI_setup (%i)GetRawInputDeviceInfo FAILED", rir);
				return(false);
			}
			else
			{
				//reset
				rir = 0;
			}

			//allocate array for device name
			pRIDName	= new char[sizeof(char) * nSize];
			if (pRIDName == NULL)
			{
				gf_logger(true, "rawinput::RI_setup RI Device Name allocation FAILED");
				return(false);
			}

			//get device name
			rir = GetRawInputDeviceInfo(pRawInputDeviceList[d].hDevice, RIDI_DEVICENAME, pRIDName, &nSize);
			if (rir < 0)
			{
				gf_logger(true, "rawinput::RI_setup (%i)GetRawInputDeviceInfo FAILED", rir);
				return(false);
			}
			else
			{
				char RIDNameShort[35] = {0};
				for (register int i = 0; i < 34; ++i)
					RIDNameShort[i] = pRIDName[i];

				gf_logger(false, "rawinput::RI_setup RID[%i] %s", d, RIDNameShort);
				//gf_logger(false, "RID[%i] %s", d, pRIDName);
				//gf_logger(false, "rawinput::RI_setup RID[%i] %s", d, pRIDName);
				//reset
				rir = 0;
			}

			//if device is mouse
			if (pRawInputDeviceList[d].dwType == RIM_TYPEMOUSE)
			{
				bool rdp_mouse		= true;
				//compare device name to system mouse device name
				if (pRIDName != NULL)
				{
					char cRDPString[]	= RDP_MOUSE_STRING;

					if (strlen(pRIDName) < 22)
					{
						rdp_mouse	= false;
					}

					//compare letters
					for (register int i = 0; i < 22; ++i)
					{
						if (cRDPString[i] != pRIDName[i])
						{
							rdp_mouse	= false;
							break;
						}
					}

					if (rdp_mouse)		gf_logger(false, "rawinput::RI_setup        RDP_MOUSE_STRING FOUND");
					//else				gf_logger(false, "rawinput::RI_setup        RDP_MOUSE_STRING NOT FOUND");

					//if system mouse and not to include system mouse
					if (rdp_mouse && !RI_INCL_SYSMOUSE)
					{
						//reduce number of mice
						--RIMn;
						//allocate smaller RI mouse pointer array
						if (pRImouse != NULL)
						{
							delete [] pRImouse;
							pRImouse	= NULL;
						}
						if (RIMn > 0)
						{
							pRImouse = new HANDLE[sizeof(HANDLE) * RIMn];
							if (pRImouse == NULL)
							{
								gf_logger(true, "rawinput::RI_setup allocate pRImouse FAILED");
								return(false);
							}
							if (RIMn > 1)		gf_logger(false, "rawinput::RI_setup Non System Mice found: %i", RIMn);
							else				gf_logger(false, "rawinput::RI_setup Non System Mouse found: %i", RIMn);
						}
						else
						{
							gf_logger(true, "rawinput::RI_setup No Non System Mouse found");
							return(false);
						}
					}
				}

				//include system mouse or not
				//don't include only if system mouse and not to include system mouse
				if (!rdp_mouse || RI_INCL_SYSMOUSE)
				{
					//assign mouse handle to mouse array
					pRImouse[mc]	= pRawInputDeviceList[d].hDevice;
//gf_logger(true, "mc: %i, handle: %i (%i)", mc, (int)pRImouse[mc], (int)rdp_mouse);
					//increase index counter for pRImouse array
					++mc;

					//if system mouse
					if (rdp_mouse)
					{
						//set handle to system mouse
						pRIsysmouse		= pRawInputDeviceList[d].hDevice;
					}

					//set device usage data
					RID[0].usUsagePage	= 0x01;				//
					RID[0].usUsage		= 0x02;				//device is mouse
					RID[0].dwFlags		= 0;				//no flags
										//RIDEV_NOLEGACY	//ignores legacy mouse messages
					RID[0].hwndTarget	= NULL;				//handle to target window, NULL = keyboard focus

					//register device
					rir = RegisterRawInputDevices(&RID[0], 1, sizeof(RID[0]));
					if (rir == FALSE)
					{
						gf_logger(true, "rawinput::RI_setup        (%i)RegisterRawInputDevices[%i] FAILED", rir, d);
						return(false);
					}
					else
					{
						gf_logger(false, "rawinput::RI_setup        (%i)RegisterRawInputDevices[%i] DONE", rir, d);
						//reset
						rir = 0;
					}
				}
			}

			//delete name array
			if (pRIDName != NULL)
				delete [] pRIDName;
		}

		//free RAWINPUTDEVICELIST
		if (pRawInputDeviceList)
			delete [] pRawInputDeviceList;

		//list and log registered devices
		//if (DEVELOPER_)
		{
			//number of registered devices
			UINT grri	= 0;
			//get number of registered devices
			rir			= GetRegisteredRawInputDevices(NULL, &grri, sizeof(RAWINPUTDEVICE));
			if (rir < 0)
			{
				gf_logger(true, "rawinput::RI_setup (%i)GetRegisteredRawInputDevices Number of Devices: %i", (int)rir, grri);
				return(false);
			}
			else
			{
				gf_logger(false, "rawinput::RI_setup (%i)GetRegisteredRawInputDevices Number of Devices: %i", (int)rir, grri);
				rir		= 0;
			}

			//allocate RI device list
			RAWINPUTDEVICE *GRID	= new RAWINPUTDEVICE[sizeof(RAWINPUTDEVICE) * grri];
			if (GRID == NULL)
			{
				gf_logger(true, "rawinput::RI_setup allocate RID list FAILED");
				return(false);
			}

			//fill RID list
			rir			= GetRegisteredRawInputDevices(GRID, &grri, sizeof(RAWINPUTDEVICE));
			if (rir , 0)
			{
				gf_logger(true, "rawinput::RI_setup (%i)GetRegisteredRawInputDevices Number of Devices: %i", (int)rir, grri);
				return(false);
			}
			else
			{
				gf_logger(false, "rawinput::RI_setup (%i)GetRegisteredRawInputDevices Number of Devices filled: %i", (int)rir, grri);
				rir		= 0;
			}

			//log registered RID information
			for (register int i = 0; i < (int)grri; ++i)
			{
				gf_logger(false, "rawinput::RI_setup registered RID[%i] %i %i %i %i", i, (int)GRID[i].usUsagePage, (int)GRID[i].usUsage, (int)GRID[i].dwFlags, (int)GRID[i].hwndTarget);
			}

			if (GRID != NULL)
				delete [] GRID;
		}

		//verify player_mouse data
		//not above available mouse index limit, not same device
		//only if at least 2 usb mice available
		if (RIMn > 1)
		{
			for (register int p = 0; p < 2; ++p)
			{
				if (option.data.player_mouse[p] > (int)RIMn - 1)
				{
					gf_logger(true, "rawinput::RI_setup player_mouse[%i] = %i of %i", p, option.data.player_mouse[p] + 1, RIMn);
					option.data.player_mouse[p] = (int)RIMn - 1;
				}
				if (option.data.player_mouse[p] < 0)
				{
					gf_logger(true, "rawinput::RI_setup player_mouse[%i] = %i of %i", p, option.data.player_mouse[p] + 1, RIMn);
					option.data.player_mouse[p] = 0;
				}

				//set option max value
				option.dataMAX.player_mouse[p] = (int)RIMn - 1;
			}
			//!! users can share same mouse
			if (option.data.player_mouse[P1] == option.data.player_mouse[P2])
			{
				gf_logger(true, "rawinput::RI_setup player_mouse[P1/P2] assigned to same device");
/*				if (option.data.player_mouse[P1] > 0)			option.data.player_mouse[P2] = 0;
				else											option.data.player_mouse[P2] = 1;
				gf_logger(true, "rawinput::RI_setup player_mouse[P1/P2] assigned to same device");*/
			}
		}

		return(true);
	};

	//---- get_input -----------------------------------------------------------------------------
	//process WM_INPUT message
	//gets the WM message, the inputstate object and options object as reference from DI within masterframe

	bool get_input(MSG &msg, inputstate &is, options &option)
	{
		LPBYTE lpb			= NULL;		//pointer to rawinput structure
		UINT dwSize			= 0;		//size of rawinput structure
		int rir				= 0;		//raw input result
		RAWINPUT *raw		= NULL;		//pointer to rawinput structure for easier access
										//raw-> equals ((RAWINPUT*)lpb)->

		//get required size
		rir = GetRawInputData((HRAWINPUT)msg.lParam, RID_INPUT, NULL, &dwSize, sizeof(RAWINPUTHEADER));
		if (rir != 0)
		{
			gf_logger(true, "rawinput::get_input (%i)GetRawInputData get size FAILED", rir);
			return(false);
		}
		else
		{
			rir = 0;
		}

		//allocate RI array
		lpb = new unsigned char[sizeof(unsigned char) * dwSize];
		if (lpb != NULL)
		{
			//for easier access
			raw	= (RAWINPUT*)lpb;
			//get data
			rir = GetRawInputData((HRAWINPUT)msg.lParam, RID_INPUT, lpb, &dwSize, sizeof(RAWINPUTHEADER));
			if (rir < 0)
			{
				gf_logger(true, "rawinput::get_input (%i)GetRawInputData FAILED", rir);
				return(false);
			}
			else
			{
				rir = 0;
			}

			//if device from WM_INPUT message is mouse
			//(only mice get registered, so...)
			if (raw->header.dwType == RIM_TYPEMOUSE)
			{
				//if there is a system mouse and flag is set to include system mouse
				//if (pRIsysmouse != NULL && RI_INCL_SYSMOUSE)
				//include all inputs into system mouse (index [0]) in inputstate
				{
					//assign data
					is.dimouse[0].lX		= (int)raw->data.mouse.lLastX;
					is.dimouse[0].lY		= (int)raw->data.mouse.lLastY;
					//mousewheel
					is.dimouse[0].lZ		= (int)(SHORT)raw->data.mouse.usButtonData;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_DOWN)		is.dimouse[0].rgbButtons[0]	= 0x80;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_UP)		is.dimouse[0].rgbButtons[0]	= 0;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_DOWN)		is.dimouse[0].rgbButtons[1]	= 0x80;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_UP)		is.dimouse[0].rgbButtons[1]	= 0;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_DOWN)		is.dimouse[0].rgbButtons[2]	= 0x80;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_UP)		is.dimouse[0].rgbButtons[2]	= 0;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN)		is.dimouse[0].rgbButtons[3]	= 0x80;
					if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_UP)		is.dimouse[0].rgbButtons[3]	= 0;
					//alternate way for mousewheel data
					//if (raw->data.mouse.usButtonFlags & RI_MOUSE_WHEEL)
					//	is.dimouse[0].lZ		= (int)(SHORT)raw->data.mouse.usButtonData;
				}

				//for both players
				for (register int p = 0; p < 2; ++p)
				{
					//verify min/max mouse index and only if more than 1 mouse available
					if ((int)RIMn > 1 &&
						option.data.player_mouse[p] >= 0 &&
						option.data.player_mouse[p] < (int)RIMn)
					{
						//if this mouse is mouse indexed by options
						//or player is bound to system mouse and system mouse included
						if (raw->header.hDevice == pRImouse[option.data.player_mouse[p]] ||
							pRIsysmouse == pRImouse[option.data.player_mouse[p]])
						{
							//assign data
							is.dimouse[p + 1].lX		= (int)raw->data.mouse.lLastX;
							is.dimouse[p + 1].lY		= (int)raw->data.mouse.lLastY;
							//mousewheel
							is.dimouse[p + 1].lZ		= (int)(SHORT)raw->data.mouse.usButtonData;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_DOWN)		is.dimouse[p + 1].rgbButtons[0]	= 0x80;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_UP)		is.dimouse[p + 1].rgbButtons[0]	= 0;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_DOWN)		is.dimouse[p + 1].rgbButtons[1]	= 0x80;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_UP)		is.dimouse[p + 1].rgbButtons[1]	= 0;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_DOWN)		is.dimouse[p + 1].rgbButtons[2]	= 0x80;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_UP)		is.dimouse[p + 1].rgbButtons[2]	= 0;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN)		is.dimouse[p + 1].rgbButtons[3]	= 0x80;
							if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_UP)		is.dimouse[p + 1].rgbButtons[3]	= 0;
						}
					}
					else
					//wrong mouse index set or only one mouse available
					//assign input to first player mouse (index [1])
					{
						//assign data
						is.dimouse[1].lX		= (int)raw->data.mouse.lLastX;
						is.dimouse[1].lY		= (int)raw->data.mouse.lLastY;
						//mousewheel
						is.dimouse[1].lZ		= (int)(SHORT)raw->data.mouse.usButtonData;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_DOWN)		is.dimouse[1].rgbButtons[0]	= 0x80;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_1_UP)		is.dimouse[1].rgbButtons[0]	= 0;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_DOWN)		is.dimouse[1].rgbButtons[1]	= 0x80;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_2_UP)		is.dimouse[1].rgbButtons[1]	= 0;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_DOWN)		is.dimouse[1].rgbButtons[2]	= 0x80;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_3_UP)		is.dimouse[1].rgbButtons[2]	= 0;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN)		is.dimouse[1].rgbButtons[3]	= 0x80;
						if (raw->data.mouse.usButtonFlags & RI_MOUSE_BUTTON_4_UP)		is.dimouse[1].rgbButtons[3]	= 0;
					}
				}
			}

			delete [] lpb;
		}
		else
		{
			gf_logger(true, "rawinput::get_input allocate RI FAILED");
			return(false);
		}

		return(true);
	};
};

//------------------------------------------------------------------------------------------------
//
//	directinput
//
//------------------------------------------------------------------------------------------------

class directinput
{
//------------------------------------------------------------------------------------------------
//	private directinput objects
//------------------------------------------------------------------------------------------------

private:

	HRESULT							hRet;				//result of dinput methods

	LPDIRECTINPUT7					lpDI7;				//general directinput object
	LPDIRECTINPUTDEVICE7			lpDIKeyboard;		//system keyboard
	LPDIRECTINPUTDEVICE7			lpDISysMouse;		//system mouse
	LPDIRECTINPUTDEVICE7			lpDIMouse01;		//usb-mouse #1
	LPDIRECTINPUTDEVICE7			lpDIMouse02;		//usb-mouse #2
	LPDIRECTINPUTDEVICE7			lpDIController01;	//controlpad #1
	LPDIRECTINPUTDEVICE7			lpDIController02;	//controlpad #2

//------------------------------------------------------------------------------------------------
//	private directinput functions
//------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------------
//	public directinput objects
//------------------------------------------------------------------------------------------------

public:

	rawinput						RI;					//rawinput structure

//------------------------------------------------------------------------------------------------
//	public directinput functions
//------------------------------------------------------------------------------------------------

	//constructor
	directinput();

	//directinput initialization
	//return values: 0 = ok, 1 = error (ex: no system mouse), 2 = not two usb mice
	int di_initialization(HWND hwnd,					//hwnd for SetCooperativeLevel
						  options &option);

	//cleanup
	void di_cleanup();

	//re/aquires devices
	bool di_acquire(char **pmm, char **pcm,				//mouse and controller restore message
					int mouseflag,						//indicates how many mice to acquire
														//1 = only system mouse
														//2 = system and 2 usb mice
					int controllerflag);				//number of available controllers

	//enumeration callback function
	static int CALLBACK DIEnumDCallback(LPCDIDEVICEINSTANCE lpddi,
										LPVOID pvRef);

	static int CALLBACK DIEnumJoystickCallback(LPCDIDEVICEINSTANCE lpddi,
											   LPVOID pvRef);

	//--------------------------------------------------------------------------------------------

	//gets keyboard, mouse and controller input
	void get_input(inputstate &is);
};

#endif										//end DIRECTINPUT_H
