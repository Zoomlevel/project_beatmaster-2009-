//------------------------------------------------------------------------------------------------
//
//	directdraw 32bit drawing functions definitions
//
//------------------------------------------------------------------------------------------------

#include "directdraw.h"				//class declaration header

//------------------------------------------------------------------------------------------------
//
//	directdraw typefont
//
//	draws wordstring using bitmap or scanline font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typefont_32(int x,								//x-coordinate
							 int y,								//y-coordinate
							 char string[101],					//string to display
							 double number,						//or number to display
							 int precision,						//after decimal point, 5 default
							 int type,							//0 = bitmap, 1 = scanline
							 float sizefactor,					//size
							 int bred, int bgreen, int bblue,	//border color
							 int fred, int fgreen, int fblue)	//fill color
																//bred -1 for bitmap black, else white
																//bred -1 and scanline: unfilled
{
	//---- copy string or number into new buffer -------------------------------------------------

	//message string buffer
	//unsigned, else you get negative values for the LUT
	unsigned char wordstring[101] = "";

	//copy string or number into new buffer
	//if string is empty
	if (string[0] == 0 || string == NULL)
	{
		//convert number (double) into string and store it in wordstring buffer
//		_gcvt(number, 8, wordstring);

		//check precision for validity
		if (precision < 0 || precision > 12)
			precision = 5;

		int decimal = 0;		int sign = 0;
		char *ws;
		//convert number in ws char pointer, store decimal and sign in temporary variables
		ws = _fcvt(number, precision, &decimal, &sign);

		//if length of ws is zero, assign '0' and null to string
		if (strlen(ws) == 0)
		{
//			wordstring[0] = 157;
			wordstring[0] = 48;
			wordstring[1] = 0;
		}

		//format string using decimal and sign and store it in wordstring buffer
		for (register int i = 0, k = 0; i < 101 && ws[k] != 0; ++i, ++k)
		{
			if (k == 0 && sign != 0)
			{
				wordstring[i] = '-';
				++i;
			}

			if (k == 0 && decimal <= 0)
			{
				wordstring[i] = '0';
				wordstring[i + 1] = '.';
				i += 2;

				for (register int d = 0; d < -decimal; ++d)
				{
					wordstring[i] = '0';
					++i;
				}
			}

			if (k != 0 && decimal == k)
			{
				wordstring[i] = '.';
				++i;
			}

			wordstring[i] = ws[k];
		}
	}
	else
		//copy string into wordstring until null terminated
		for (register int i = 0; i < 101; ++i)
		{
			wordstring[i] = string[i];
			if (string[i] == 0)
				i = 101;
		}

	//---- bitmap font ---------------------------------------------------------------------------

	//use bitmap font if type == 0 else use scanline font
	if (type == 0)
	{
		//destination of string, clipping source, clipping destination
		RECT tempdest, csource, cdest;
		tempdest.left = x;	tempdest.top = y;

		//verify color
		if (bred < 0)			bred	= 0;
		if (bred > bmfMAX)		bred	= bmfMAX;

		//for every letter while not null (end of string)
		for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
		{
			//set right and bottom members of tempdest
			tempdest.right = tempdest.left + (long)(8 * sizefactor);
			tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

			//assign RECTS to temp RECTS so the originals don't get clipped
			//(especially the LUT)
			cdest	= tempdest;

			//offscreen surface offset depending on color
			csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[bred].x;
			csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[bred].y;
			csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[bred].x;
			csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[bred].y;

			//if clipper returns true which means dest RECT is within screen (and clipped),
			//blit letter
			if (clipper(rSCREEN, csource, cdest))
				lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
							   lpDDSOff,					//dd surface which is source of blit
							   &csource,					//source rect, NULL for entire surface
							   DDBLT_KEYSRC,				//flags
							   NULL);						//address of DDBLTFX structure
//			else
				//if letter completely out of screen
				//- and so every following - end loop
				//!! wrongo --> not true for left screen side, following letters may be within screen
//				i = 101;

			//set new tempdest left
			tempdest.left += (long)(8 * sizefactor);
		}
	}
	else
	//---- scanline font -------------------------------------------------------------------------
	{
		//---- setup -----------------------------------------------------------------------------

		//lock surface
		if (!BBLock())
			return(false);

		//surface pointers
		DWORD	*pslocked32 = NULL;						//pointer is 32bit

		if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
		{
			lpDDSBack->Unlock(NULL);
			pslocked32 = NULL;
			return(false);
		}

		//backup pointer so we don't have to convert ddsd.lpSurface
		//everytime we reset pslocked32
		DWORD *psbackup32	= pslocked32;

		//pre calculate y offset
		int yoffset	= ddspitch / sizeof(DWORD);

		//----------------------------------------------------------------------------------------

		//frame for each letter to draw
		//starts at x/y and is increased after each letter by
		//32 + 3 times sizefactor
		RECT tempdest;
		tempdest.left = x;	tempdest.top = y;

		//for every letter while not null (end of string)
		for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
		{
			//for every part of the letter up to six (if not used, indicated by -1 values)
			for (register int r = 0; r < 6 && p_cfontsl_LUT[wordstring[i]][r].left != -1; ++r)
			{
				//convert RECT of scanline font LUT into rectangle object (to draw it
				//via drawrectangle)
				rectangle		re;

				re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
				re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
				re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
				re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
				re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
				re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;
				re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
				re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;

				//clip rectangle to draw
				re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
				re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
				re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
				re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

				re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
				re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
				re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
				re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

				re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
				re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
				re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
				re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

				re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
				re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
				re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
				re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

				//---- setup values --------------------------------------------------------------------------

				//set colors
				DWORD pixelb32, pixelf32;

				if (bred != -1)
				{
					pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
					pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
				}
				else
				{
					//if unfilled letters, use fill color as border color
					pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
					//pixelf = WORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
				}

				//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
				//edge_state: 0 == uninitialized, 1 == in use, 2 == done
				//converted to int
				float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

				//for all 4 edges
				for (register int i = 0; i < 4; ++i)
				{
					//if y1 <= y2
					if (edge[i][1] <= edge[i][3])
					{
						//y_min is y1
						edge[i][4] = edge[i][1];
						//y_max is y2
						edge[i][5] = edge[i][3];
						//x_y_min is x-intersection is x1
						edge[i][7] = edge[i][9] = edge[i][0];
					}
					else
					{
						//else vice versa
						edge[i][4] = edge[i][3];
						edge[i][5] = edge[i][1];
						edge[i][7] = edge[i][9] = edge[i][2];
					}

					//assign x_min
					//if x1 <= x2
					if (edge[i][0] <= edge[i][2])
						//x_min is x1
						edge[i][6] = edge[i][0];
					else
						//else x_min is x2
						edge[i][6] = edge[i][2];

					//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
					//note that values are not absolutes because slope has to be positive and negative
					float dx = edge[i][0] - edge[i][2];
					float dy = edge[i][1] - edge[i][3];

					//if both dx and dy is zero, which means edge has no length
					//set slope to zero so its not used in drawing the polygon
					if (dx == 0 && dy == 0)
						edge[i][8] = 0;
					else
						//if only dx is zero, wehich means infinite slope (straight vertical line)
						//set slope to 1000
						if (dx == 0)
							edge[i][8] = 1000;
						//else slope is dy / dx
						else
							edge[i][8] = dy / dx;
				}

				//if not unfilled scanline
				if (bred != -1)
				{
					//---- scanline algorithm --------------------------------------------------------------------

					//---- bubble sort edges by y_min, x_min -----------------------------------------------------

					//temporary edge needed for swapping process
					float temp_edge[11];

					//for maximal 3 loops (since 4 variable need not more loops to be sorted)
					for (i = 0; i < 3; ++i)
					{
						//check for swapping edge 1 and 2
						//if y_min 2nd edge < y_min 1st edge
						if (edge[1][4] < edge[0][4])
							//swap all elements of the two edges
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
							}
						else
							//if y_min 2nd edge == y_min 1st edge, sort by x_min
							if (edge[1][4] == edge[0][4])
								//if x_min 2nd edge < x_min 1st edge
								if (edge[1][6] < edge[0][6])
								{
									//swap all elements of the two edges
									for (int s = 0; s < 11; s++)
									{
										temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
									}
								}
						//otherwise just let the edges as they are

						//check for swapping edge 2 and 3
						if (edge[2][4] < edge[1][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
							}
						else
							if (edge[2][4] == edge[1][4])
								if (edge[2][6] < edge[1][6])
								{
									for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
									}
								}

						//check for swapping edge 3 and 4
						if (edge[3][4] < edge[2][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
							}
						else
							if (edge[3][4] == edge[2][4])
								if (edge[3][6] < edge[2][6])
								{
									for (register int s = 0; s < 11; ++s)
										{
											temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
										}
								}
					}

					//---- assign scanline -----------------------------------------------------------------------

					//start scanline at y_min of first edge
					int scanline = (int)edge[0][4];

					//---- activate first edge -------------------------------------------------------------------

					//for every edge
					for (register int e = 0; e < 4; ++e)
					{
						//if slope is zero (horizontal edge)
						if (edge[e][8] == 0)
							//set edge_state to "done"
							edge[e][10] = 2;

						//if edge not "done"
						if (edge[e][10] != 2)
							//activate edge if y_min is scanline
							//(always 2 edges activated at the same time)
							if (edge[e][4] == scanline)
								edge[e][10] = 1;
					}

					//---- drawing -------------------------------------------------------------------------------

					//indicates if there are edges left to draw
					int EDGES = 1;
					//ptd[0] is x-intersection of first active edge,
					//ptd[1] is x-intersection of second active edge,
					//while ptd[2] is used for swapping both values
					int ptd[3] = {0};
					//index of ptd
					int ptd_i = 0;

					while (EDGES)
					{
						//reset pdi index so first active edge is assigned to ptd[0]
						ptd_i = 0;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
							{
								//ptd[ptd_i] is x-intersection
								ptd[ptd_i] = (int)edge[e][9];

								//increase ptd_i so second active edge
								//is assigned to ptd[1]
								++ptd_i;
							}
						}

						//swap first and second ptd using the third one
						//if second ptd is smaller than first ptd
						if (ptd[1] < ptd[0])
						{
							ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
						}

						//draw all pixels beginning at pdt[0] + 1 to pdt[1]
						//(x-intersections of scanline with both active edges)
						for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
						{
							//assign x-coordinate
							pslocked32 += fp;
							//assign y-coordinate
//							pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
							pslocked32 += yoffset * scanline;
							//set pixel
							*pslocked32 = pixelf32;
							//reset pixel pointer
							pslocked32 = psbackup32;
						}

						//---- reorder edges -------------------------------------------------------------------------

						//increase scanline
						++scanline;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
								//set edge state to "done" if y_max == scanline
								if (edge[e][5] == scanline)
									edge[e][10] = 2;
								else
									//check if slope is not infinite
									if (edge[e][8] != 1000)
										//increase x-intersection by (1 / slope)
										edge[e][9] += (1 / edge[e][8]);

								//if edge state not "done"
								if (edge[e][10] != 2)
									//if y_min == scanline
									if (edge[e][4] == scanline)
										//activate edge
										edge[e][10] = 1;
						}

						//leave while loop if every edge is done
						if (edge[0][10] == 2)
							if (edge[1][10] == 2)
								if (edge[2][10] == 2)
									if (edge[3][10] == 2)
										EDGES = 0;
					}
				}

				//---- bresenham line drawing ----------------------------------------------------------------

				//for every edge
				for (i = 0; i < 4; ++i)
				{
					int x = (int)edge[i][0],		y = (int)edge[i][1];
					int dx = abs((int)(edge[i][2] - edge[i][0]));
					int dy = abs((int)(edge[i][3] - edge[i][1]));

					int xinc1, xinc2, yinc1, yinc2;
					int denominator, numerator, numadd, numpixels, curpixel;

					if (edge[i][2] >= edge[i][0])
					{
						xinc1 = 1;	xinc2 = 1;
					}
					else
					{
						xinc1 = -1; xinc2 = -1;
					}

					if (edge[i][3] >= edge[i][1])
					{
						yinc1 = 1;	yinc2 = 1;
					}
					else
					{
						yinc1 = -1; yinc2 = -1;
					}

					if (dx >= dy)
					{
						xinc1 = 0;			yinc2 = 0;
						denominator = dx;	numerator = dx / 2;
						numadd = dy;		numpixels = dx;
					}
					else
					{
						xinc2 = 0;			yinc1 = 0;
						denominator = dy;	numerator = dy / 2;
						numadd = dx;		numpixels = dy;
					}

					for (curpixel = 0; curpixel <= numpixels; ++curpixel)
					{
						//assign x-coordinate
						pslocked32 += x;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * y;
						pslocked32 += yoffset * y;
						//set pixel
						*pslocked32 = pixelb32;
						//reset pixel pointer
						pslocked32 = psbackup32;

						numerator += numadd;
						if (numerator >= denominator)
						{
							numerator -= denominator;
							x += xinc1;		y += yinc1;
						}
						x += xinc2;		y += yinc2;
					}
				}
			}

			//increase frame
			tempdest.left += (long)((32 + 3) * sizefactor);
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typeSLF
//
//	draws wordstring using scanline font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typeSLF_32(int x, int y,
							int bred, int bgreen, int bblue,
							int fred, int fgreen, int fblue,
							float sizefactor,
							char *format)
{
	//---- copy string or number into new buffer -------------------------------------------------

	//message string buffer
	//unsigned, else you get negative values for the LUT
	unsigned char wordstring[101] = "";

	//copy string into wordstring until null terminated
	for (register int i = 0; i < 101; ++i)
	{
		wordstring[i] = format[i];
		if (format[i] == 0)
			i = 101;
	}

	//---- scanline font -------------------------------------------------------------------------

	//---- setup -----------------------------------------------------------------------------

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32 = NULL;						//pointer is 32bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//----------------------------------------------------------------------------------------

	//frame for each letter to draw
	//starts at x/y and is increased after each letter by
	//32 + 3 times sizefactor
	RECT tempdest;
	tempdest.left = x;	tempdest.top = y;

	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//for every part of the letter up to six (if not used, indicated by -1 values)
		for (register int r = 0; r < 6 && p_cfontsl_LUT[wordstring[i]][r].left != -1; ++r)
		{
			//convert RECT of scanline font LUT into rectangle object (to draw it
			//via drawrectangle)
			rectangle		re;

			re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
			re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
			re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
			re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
			re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
			re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;
			re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
			re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;

			//clip rectangle to draw
			re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
			re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
			re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
			re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

			re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
			re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
			re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
			re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

			re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
			re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
			re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
			re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

			re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
			re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
			re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
			re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

			//---- setup values --------------------------------------------------------------------------

			//set colors
			DWORD pixelb32, pixelf32;

			if (bred != -1)
			{
				pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
				pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
			}
			else
			{
				//if unfilled letters, use fill color as border color
				pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
				//pixelf = WORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
			}

			//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
			//edge_state: 0 == uninitialized, 1 == in use, 2 == done
			//converted to int
			float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

			//for all 4 edges
			for (register int i = 0; i < 4; ++i)
			{
				//if y1 <= y2
				if (edge[i][1] <= edge[i][3])
				{
					//y_min is y1
					edge[i][4] = edge[i][1];
					//y_max is y2
					edge[i][5] = edge[i][3];
					//x_y_min is x-intersection is x1
					edge[i][7] = edge[i][9] = edge[i][0];
				}
				else
				{
					//else vice versa
					edge[i][4] = edge[i][3];
					edge[i][5] = edge[i][1];
					edge[i][7] = edge[i][9] = edge[i][2];
				}

				//assign x_min
				//if x1 <= x2
				if (edge[i][0] <= edge[i][2])
					//x_min is x1
					edge[i][6] = edge[i][0];
				else
					//else x_min is x2
					edge[i][6] = edge[i][2];

				//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
				//note that values are not absolutes because slope has to be positive and negative
				float dx = edge[i][0] - edge[i][2];
				float dy = edge[i][1] - edge[i][3];

				//if both dx and dy is zero, which means edge has no length
				//set slope to zero so its not used in drawing the polygon
				if (dx == 0 && dy == 0)
					edge[i][8] = 0;
				else
					//if only dx is zero, wehich means infinite slope (straight vertical line)
					//set slope to 1000
					if (dx == 0)
						edge[i][8] = 1000;
					//else slope is dy / dx
					else
						edge[i][8] = dy / dx;
			}

			//if not unfilled scanline
			if (bred != -1)
			{
				//---- scanline algorithm --------------------------------------------------------------------

				//---- bubble sort edges by y_min, x_min -----------------------------------------------------

				//temporary edge needed for swapping process
				float temp_edge[11];

				//for maximal 3 loops (since 4 variable need not more loops to be sorted)
				for (i = 0; i < 3; ++i)
				{
					//check for swapping edge 1 and 2
					//if y_min 2nd edge < y_min 1st edge
					if (edge[1][4] < edge[0][4])
						//swap all elements of the two edges
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
						}
					else
						//if y_min 2nd edge == y_min 1st edge, sort by x_min
						if (edge[1][4] == edge[0][4])
							//if x_min 2nd edge < x_min 1st edge
							if (edge[1][6] < edge[0][6])
							{
								//swap all elements of the two edges
								for (int s = 0; s < 11; s++)
								{
									temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
								}
							}
					//otherwise just let the edges as they are

					//check for swapping edge 2 and 3
					if (edge[2][4] < edge[1][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
						}
					else
						if (edge[2][4] == edge[1][4])
							if (edge[2][6] < edge[1][6])
							{
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
								}
							}

					//check for swapping edge 3 and 4
					if (edge[3][4] < edge[2][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
						}
					else
						if (edge[3][4] == edge[2][4])
							if (edge[3][6] < edge[2][6])
							{
								for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
									}
							}
				}

				//---- assign scanline -----------------------------------------------------------------------

				//start scanline at y_min of first edge
				int scanline = (int)edge[0][4];

				//---- activate first edge -------------------------------------------------------------------

				//for every edge
				for (register int e = 0; e < 4; ++e)
				{
					//if slope is zero (horizontal edge)
					if (edge[e][8] == 0)
						//set edge_state to "done"
						edge[e][10] = 2;

					//if edge not "done"
					if (edge[e][10] != 2)
						//activate edge if y_min is scanline
						//(always 2 edges activated at the same time)
						if (edge[e][4] == scanline)
							edge[e][10] = 1;
				}

				//---- drawing -------------------------------------------------------------------------------

				//indicates if there are edges left to draw
				int EDGES = 1;
				//ptd[0] is x-intersection of first active edge,
				//ptd[1] is x-intersection of second active edge,
				//while ptd[2] is used for swapping both values
				int ptd[3] = {0};
				//index of ptd
				int ptd_i = 0;

				while (EDGES)
				{
					//reset pdi index so first active edge is assigned to ptd[0]
					ptd_i = 0;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
						{
							//ptd[ptd_i] is x-intersection
							ptd[ptd_i] = (int)edge[e][9];

							//increase ptd_i so second active edge
							//is assigned to ptd[1]
							++ptd_i;
						}
					}

					//swap first and second ptd using the third one
					//if second ptd is smaller than first ptd
					if (ptd[1] < ptd[0])
					{
						ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
					}

					//draw all pixels beginning at pdt[0] + 1 to pdt[1]
					//(x-intersections of scanline with both active edges)
					for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
					{
						//assign x-coordinate
						pslocked32 += fp;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
						pslocked32 += yoffset * scanline;
						//set pixel
						*pslocked32 = pixelf32;
						//reset pixel pointer
						pslocked32 = psbackup32;
					}

					//---- reorder edges -------------------------------------------------------------------------

					//increase scanline
					++scanline;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
							//set edge state to "done" if y_max == scanline
							if (edge[e][5] == scanline)
								edge[e][10] = 2;
							else
								//check if slope is not infinite
								if (edge[e][8] != 1000)
									//increase x-intersection by (1 / slope)
									edge[e][9] += (1 / edge[e][8]);

							//if edge state not "done"
							if (edge[e][10] != 2)
								//if y_min == scanline
								if (edge[e][4] == scanline)
									//activate edge
									edge[e][10] = 1;
					}

					//leave while loop if every edge is done
					if (edge[0][10] == 2)
						if (edge[1][10] == 2)
							if (edge[2][10] == 2)
								if (edge[3][10] == 2)
									EDGES = 0;
				}
			}

			//---- bresenham line drawing ----------------------------------------------------------------

			//for every edge
			for (i = 0; i < 4; ++i)
			{
				int x = (int)edge[i][0],		y = (int)edge[i][1];
				int dx = abs((int)(edge[i][2] - edge[i][0]));
				int dy = abs((int)(edge[i][3] - edge[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (edge[i][2] >= edge[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (edge[i][3] >= edge[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += x;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * y;
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixelb32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}
		}

		//increase frame
		tempdest.left += (long)((32 + 3) * sizefactor);
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32	= NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typeSLF_ML
//
//	draws wordstring using scanline font, manual lock version
//
//------------------------------------------------------------------------------------------------

bool directdraw::typeSLF_32_ML(int x, int y,
							   int bred, int bgreen, int bblue,
							   int fred, int fgreen, int fblue,
							   float sizefactor,
							   char *format)
{
	//---- copy string or number into new buffer -------------------------------------------------

	//message string buffer
	//unsigned, else you get negative values for the LUT
	unsigned char wordstring[101] = "";

	//copy string into wordstring until null terminated
	for (register int i = 0; i < 101; ++i)
	{
		wordstring[i] = format[i];
		if (format[i] == 0)
			i = 101;
	}

	//---- scanline font -------------------------------------------------------------------------

	//---- setup -----------------------------------------------------------------------------

	//surface pointers
	DWORD	*pslocked32 = NULL;						//pointer is 32bit

	if (!(pslocked32 = (DWORD*)ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//----------------------------------------------------------------------------------------

	//frame for each letter to draw
	//starts at x/y and is increased after each letter by
	//32 + 3 times sizefactor
	RECT tempdest;
	tempdest.left = x;	tempdest.top = y;

	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//for every part of the letter up to six (if not used, indicated by -1 values)
		for (register int r = 0; r < 6 && p_cfontsl_LUT[wordstring[i]][r].left != -1; ++r)
		{
			//convert RECT of scanline font LUT into rectangle object (to draw it
			//via drawrectangle)
			rectangle		re;

			re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
			re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
			re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
			re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].top * sizefactor;
			re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].right * sizefactor;
			re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;
			re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[wordstring[i]][r].left * sizefactor;
			re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[wordstring[i]][r].bottom * sizefactor;

			//clip rectangle to draw
			re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
			re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
			re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
			re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

			re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
			re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
			re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
			re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

			re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
			re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
			re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
			re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

			re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
			re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
			re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
			re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

			//---- setup values --------------------------------------------------------------------------

			//set colors
			DWORD pixelb32, pixelf32;

			if (bred != -1)
			{
				pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
				pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
			}
			else
			{
				//if unfilled letters, use fill color as border color
				pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
				//pixelf = WORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
			}

			//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
			//edge_state: 0 == uninitialized, 1 == in use, 2 == done
			//converted to int
			float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

			//for all 4 edges
			for (register int i = 0; i < 4; ++i)
			{
				//if y1 <= y2
				if (edge[i][1] <= edge[i][3])
				{
					//y_min is y1
					edge[i][4] = edge[i][1];
					//y_max is y2
					edge[i][5] = edge[i][3];
					//x_y_min is x-intersection is x1
					edge[i][7] = edge[i][9] = edge[i][0];
				}
				else
				{
					//else vice versa
					edge[i][4] = edge[i][3];
					edge[i][5] = edge[i][1];
					edge[i][7] = edge[i][9] = edge[i][2];
				}

				//assign x_min
				//if x1 <= x2
				if (edge[i][0] <= edge[i][2])
					//x_min is x1
					edge[i][6] = edge[i][0];
				else
					//else x_min is x2
					edge[i][6] = edge[i][2];

				//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
				//note that values are not absolutes because slope has to be positive and negative
				float dx = edge[i][0] - edge[i][2];
				float dy = edge[i][1] - edge[i][3];

				//if both dx and dy is zero, which means edge has no length
				//set slope to zero so its not used in drawing the polygon
				if (dx == 0 && dy == 0)
					edge[i][8] = 0;
				else
					//if only dx is zero, wehich means infinite slope (straight vertical line)
					//set slope to 1000
					if (dx == 0)
						edge[i][8] = 1000;
					//else slope is dy / dx
					else
						edge[i][8] = dy / dx;
			}

			//if not unfilled scanline
			if (bred != -1)
			{
				//---- scanline algorithm --------------------------------------------------------------------

				//---- bubble sort edges by y_min, x_min -----------------------------------------------------

				//temporary edge needed for swapping process
				float temp_edge[11];

				//for maximal 3 loops (since 4 variable need not more loops to be sorted)
				for (i = 0; i < 3; ++i)
				{
					//check for swapping edge 1 and 2
					//if y_min 2nd edge < y_min 1st edge
					if (edge[1][4] < edge[0][4])
						//swap all elements of the two edges
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
						}
					else
						//if y_min 2nd edge == y_min 1st edge, sort by x_min
						if (edge[1][4] == edge[0][4])
							//if x_min 2nd edge < x_min 1st edge
							if (edge[1][6] < edge[0][6])
							{
								//swap all elements of the two edges
								for (int s = 0; s < 11; s++)
								{
									temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
								}
							}
					//otherwise just let the edges as they are

					//check for swapping edge 2 and 3
					if (edge[2][4] < edge[1][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
						}
					else
						if (edge[2][4] == edge[1][4])
							if (edge[2][6] < edge[1][6])
							{
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
								}
							}

					//check for swapping edge 3 and 4
					if (edge[3][4] < edge[2][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
						}
					else
						if (edge[3][4] == edge[2][4])
							if (edge[3][6] < edge[2][6])
							{
								for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
									}
							}
				}

				//---- assign scanline -----------------------------------------------------------------------

				//start scanline at y_min of first edge
				int scanline = (int)edge[0][4];

				//---- activate first edge -------------------------------------------------------------------

				//for every edge
				for (register int e = 0; e < 4; ++e)
				{
					//if slope is zero (horizontal edge)
					if (edge[e][8] == 0)
						//set edge_state to "done"
						edge[e][10] = 2;

					//if edge not "done"
					if (edge[e][10] != 2)
						//activate edge if y_min is scanline
						//(always 2 edges activated at the same time)
						if (edge[e][4] == scanline)
							edge[e][10] = 1;
				}

				//---- drawing -------------------------------------------------------------------------------

				//indicates if there are edges left to draw
				int EDGES = 1;
				//ptd[0] is x-intersection of first active edge,
				//ptd[1] is x-intersection of second active edge,
				//while ptd[2] is used for swapping both values
				int ptd[3] = {0};
				//index of ptd
				int ptd_i = 0;

				while (EDGES)
				{
					//reset pdi index so first active edge is assigned to ptd[0]
					ptd_i = 0;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
						{
							//ptd[ptd_i] is x-intersection
							ptd[ptd_i] = (int)edge[e][9];

							//increase ptd_i so second active edge
							//is assigned to ptd[1]
							++ptd_i;
						}
					}

					//swap first and second ptd using the third one
					//if second ptd is smaller than first ptd
					if (ptd[1] < ptd[0])
					{
						ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
					}

					//draw all pixels beginning at pdt[0] + 1 to pdt[1]
					//(x-intersections of scanline with both active edges)
					for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
					{
						//assign x-coordinate
						pslocked32 += fp;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
						pslocked32 += yoffset * scanline;
						//set pixel
						*pslocked32 = pixelf32;
						//reset pixel pointer
						pslocked32 = psbackup32;
					}

					//---- reorder edges -------------------------------------------------------------------------

					//increase scanline
					++scanline;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
							//set edge state to "done" if y_max == scanline
							if (edge[e][5] == scanline)
								edge[e][10] = 2;
							else
								//check if slope is not infinite
								if (edge[e][8] != 1000)
									//increase x-intersection by (1 / slope)
									edge[e][9] += (1 / edge[e][8]);

							//if edge state not "done"
							if (edge[e][10] != 2)
								//if y_min == scanline
								if (edge[e][4] == scanline)
									//activate edge
									edge[e][10] = 1;
					}

					//leave while loop if every edge is done
					if (edge[0][10] == 2)
						if (edge[1][10] == 2)
							if (edge[2][10] == 2)
								if (edge[3][10] == 2)
									EDGES = 0;
				}
			}

			//---- bresenham line drawing ----------------------------------------------------------------

			//for every edge
			for (i = 0; i < 4; ++i)
			{
				int x = (int)edge[i][0],		y = (int)edge[i][1];
				int dx = abs((int)(edge[i][2] - edge[i][0]));
				int dy = abs((int)(edge[i][3] - edge[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (edge[i][2] >= edge[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (edge[i][3] >= edge[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += x;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * y;
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixelb32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}
		}

		//increase frame
		tempdest.left += (long)((32 + 3) * sizefactor);
	}

	//---- cleanup -------------------------------------------------------------------------------

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw font_pfx
//
//	locks offscreen surface and reads each letter of a string
//	off the surface according to the look up table and the appropriate
//	RECT, scanning each letter for its pixels and assigning the
//	offset position as particle origin
//	returns pointer to partical array
//
//------------------------------------------------------------------------------------------------

particle *directdraw::font_pfx_32(char string[101],				//fx-string
								  int &size,					//size of array as reference
																//so that pa_heap knows its size
								  int x, int y)					//offset coordinates
{
	//---- setup ---------------------------------------------------------------------------------

	//message string buffer
	//unsigned, else you get negative values for the LUT (no ascii codes above 128)
	unsigned char wordstring[101];

	//copy string into wordstring
	for (int i = 0; i < 101; ++i)
	{
		wordstring[i] = string[i];
		if (string[i] == 0)
			i = 101;
	}

	//surface lock-area
	RECT lock_area;
	fillRECT(lock_area, 0, 0, 256, 128);

	//pixel color we're looking for (white)
	DWORD pixel32 = DWORD(p_rLUT[255] | p_gLUT[255] | p_bLUT[255]);

	//increase video ram lock counter and set status to locked
	++VRAM_nlocks;
	VRAM_locked		= 1;

	//lock offscreen surface read only, return false if it fails
	hRet = lpDDSOff->Lock(&lock_area,				//RECT of area to be locked, NULL entire surface
						  &ddsd,					//DDSURFACEDESC2 structure to be filled with all relevant details
						  DDLOCK_READONLY |
						  DDLOCK_SURFACEMEMORYPTR,	//flags
						  NULL);					//NULL
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::font_pfx_32 Lock FAILED (%i)", hRet);
		lpDDSOff->Unlock(&lock_area);
		return(NULL);
	}

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 32bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSOff->Unlock(NULL);
		pslocked32 = NULL;
		return(NULL);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//assign surface pitch
	ddspitch = ddsd.lPitch;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- read pixels ---------------------------------------------------------------------------

	//first get the number of pixels needed, allocate particle array according to size
	//then read pixels again and assign their coordinates including offset to particle array

	//argumented referenced size should be 0
	if (size != 0)
	{
		gf_logger(true, "directdraw_32::font_pfx_32 argumented size not 0");
		return(NULL);
	}

	//get size
	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
		//for every line
		for (int li = 0; li < 16; ++li)
			//for every column
			for (int co = 0; co < 8; ++co)
			{
				//assign x-coordinate
				pslocked32 += (int)(p_cfontbm_LUT[wordstring[i]].left + co);
				//assign y-coordinate
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * (p_cfontbm_LUT[wordstring[i]].top + li));
				pslocked32 += yoffset * (p_cfontbm_LUT[wordstring[i]].top + li);

				//if pixel on offscreen-surface is pixel searched
				if (*pslocked32 == pixel32)
				{
					//increment particle array size
					++size;
				}

				//reset pixel pointer
				pslocked32 = psbackup32;
			}

	//allocate particle array
	particle *p			= new particle[size];
	//particle counter
	int cp				= 0;

	//assign particle coordinates
	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
		//for every line
		for (int li = 0; li < 16; ++li)
			//for every column
			for (int co = 0; co < 8; ++co)
			{
				//assign x-coordinate
				pslocked32 += (int)(p_cfontbm_LUT[wordstring[i]].left + co);
				//assign y-coordinate
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * (p_cfontbm_LUT[wordstring[i]].top + li));
				pslocked32 += yoffset * (p_cfontbm_LUT[wordstring[i]].top + li);

				//if pixel on offscreen-surface is pixel searched
				if (*pslocked32 == pixel32)
				{
					//assign offsets
					//(at least one particle exists)
					p[cp].p_origin.x = (float)(x + co + i * 8);
					p[cp].p_origin.y = (float)(y + li);
					++cp;
				}

				//reset pixel pointer
				pslocked32 = psbackup32;
			}

	//old version
	//results in a delete [] bug within ~animation()
/*
	//new array with size + 1
	particle *p			= NULL;
	//old array
	particle *pold		= NULL;

	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//for every line
		for (register int li = 0; li < 16; ++li)
		{
			//for every column
			for (register int co = 0; co < 8; ++co)
			{
				//assign x-coordinate
				pslocked32 += (int)(p_cfontbm_LUT[wordstring[i]].left + co);
				//assign y-coordinate
				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * (p_cfontbm_LUT[wordstring[i]].top + li));

				//if pixel on offscreen-surface is pixel searched
				if (*pslocked32 == pixel32)
				{
					//increment particle array size
					++size;
					//assign pold to old smaller array
					pold	= p;
					//assign p to new bigger array
					p		= new particle[size];

					//copy old data into new one
					//(size - 1 because old array is size - 1)
					for (register int c = 0; c < size - 1; ++c)
					{
						//assign offsets to particle origin
						p[c].p_origin.x = pold[c].p_origin.x;
						p[c].p_origin.y = pold[c].p_origin.y;
					}

					//delete old array
					delete	[] pold;
					pold	= NULL;

					//if at least one particle exists
					if (size > 0)
					{
						//assign offsets
						p[size - 1].p_origin.x = (float)(x + co + i * 8);
						p[size - 1].p_origin.y = (float)(y + li);
					}
				}

				//reset pixel pointer
				pslocked32 = psbackup32;
			}
		}
	}*/

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer, reset surface pointer
	lpDDSOff->Unlock(&lock_area);
	pslocked32 = NULL;

	return(p);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawpoint
//
//	draws a single point with specified color (black by default) given by value
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawpoint_32(point p, RGBcolor c, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip point
	p.x < rSCREEN.left			? p.x = (float)rSCREEN.left			: p.x;
	p.x > rSCREEN.right - 1		? p.x = (float)rSCREEN.right - 1	: p.x;
	p.y < rSCREEN.top			? p.y = (float)rSCREEN.top			: p.y;
	p.y > rSCREEN.bottom - 1	? p.y = (float)rSCREEN.bottom - 1	: p.y;

	//convert points to integers
	p.x = (float)(int)p.x;
	p.y = (float)(int)p.y;

	//set pixel color
	DWORD pixel32 = DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//---- plot pixel ----------------------------------------------------------------------------

	//assign x-coordinate
	//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
	pslocked32 += (int)p.x;
	//assign y-coordinate
	//ddspitch is in byte, but since one pixel is short and pslocked32
	//is incremented by short you have to adjust the ddspitch value by
	//the size of short
	pslocked32 += (int)((ddspitch / sizeof(DWORD)) * p.y);
	//set pixel
	*pslocked32 = pixel32;

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawline
//
//	draws a single line with specified color (black by default) given by value
//	uses bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawline_32(line l, RGBcolor c)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip line, don't draw if out of screen
	if (!lineclipper(l))
		return(false);

	//clip points (only x-axis)
//	l.p[0].x < rSCREEN.left			? l.p[0].x = (float)rSCREEN.left		: l.p[0].x;
//	l.p[0].x > rSCREEN.right - 1	? l.p[0].x = (float)rSCREEN.right - 1	: l.p[0].x;
//	l.p[0].y < rSCREEN.top			? l.p[0].y = (float)rSCREEN.top			: l.p[0].y;
//	l.p[0].y > rSCREEN.bottom - 1	? l.p[0].y = (float)rSCREEN.bottom - 1	: l.p[0].y;
//	l.p[1].x < rSCREEN.left			? l.p[1].x = (float)rSCREEN.left		: l.p[1].x;
//	l.p[1].x > rSCREEN.right - 1	? l.p[1].x = (float)rSCREEN.right - 1	: l.p[1].x;
//	l.p[1].y < rSCREEN.top			? l.p[1].y = (float)rSCREEN.top			: l.p[1].y;
//	l.p[1].y > rSCREEN.bottom - 1	? l.p[1].y = (float)rSCREEN.bottom - 1	: l.p[1].y;

	//set pixel color
	DWORD pixel32	= DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham line drawing ----------------------------------------------------------------

	int x = (int)l.p[0].x,		y = (int)l.p[0].y;
	int dx = abs((int)(l.p[1].x - l.p[0].x));
	int dy = abs((int)(l.p[1].y - l.p[0].y));

	int xinc1, xinc2, yinc1, yinc2;
	int denominator, numerator, numadd, numpixels, curpixel;

	if (l.p[1].x >= l.p[0].x)
	{
		xinc1 = 1;	xinc2 = 1;
	}
	else
	{
		xinc1 = -1; xinc2 = -1;
	}

	if (l.p[1].y >= l.p[0].y)
	{
		yinc1 = 1;	yinc2 = 1;
	}
	else
	{
		yinc1 = -1; yinc2 = -1;
	}

	if (dx >= dy)
	{
		xinc1 = 0;			yinc2 = 0;
		denominator = dx;	numerator = dx / 2;
		numadd = dy;		numpixels = dx;
	}
	else
	{
		xinc2 = 0;			yinc1 = 0;
		denominator = dy;	numerator = dy / 2;
		numadd = dx;		numpixels = dy;
	}

	for (curpixel = 0; curpixel <= numpixels; ++curpixel)
	{
		//assign x-coordinate
		pslocked32 += (int)x;
		//assign y-coordinate
//		pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
		pslocked32 += yoffset * y;
		//set pixel
		*pslocked32 = pixel32;
		//reset pixel pointer
		pslocked32 = psbackup32;

		numerator += numadd;
		if (numerator >= denominator)
		{
			numerator -= denominator;
			x += xinc1;		y += yinc1;
		}

		x += xinc2;		y += yinc2;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32	= NULL;

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawline
//
//	draws a single line with specified color (black by default) given by value
//	uses bresenhams line algorithm
//	manual lock version
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawline_32_ML(line l, RGBcolor c)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip line, don't draw if out of screen
	if (!lineclipper(l))
		return(false);

	//clip points (only x-axis)
//	l.p[0].x < rSCREEN.left			? l.p[0].x = (float)rSCREEN.left		: l.p[0].x;
//	l.p[0].x > rSCREEN.right - 1	? l.p[0].x = (float)rSCREEN.right - 1	: l.p[0].x;
//	l.p[0].y < rSCREEN.top			? l.p[0].y = (float)rSCREEN.top			: l.p[0].y;
//	l.p[0].y > rSCREEN.bottom - 1	? l.p[0].y = (float)rSCREEN.bottom - 1	: l.p[0].y;
//	l.p[1].x < rSCREEN.left			? l.p[1].x = (float)rSCREEN.left		: l.p[1].x;
//	l.p[1].x > rSCREEN.right - 1	? l.p[1].x = (float)rSCREEN.right - 1	: l.p[1].x;
//	l.p[1].y < rSCREEN.top			? l.p[1].y = (float)rSCREEN.top			: l.p[1].y;
//	l.p[1].y > rSCREEN.bottom - 1	? l.p[1].y = (float)rSCREEN.bottom - 1	: l.p[1].y;

	//set pixel color
	DWORD pixel32	= DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham line drawing ----------------------------------------------------------------

	int x = (int)l.p[0].x,		y = (int)l.p[0].y;
	int dx = abs((int)(l.p[1].x - l.p[0].x));
	int dy = abs((int)(l.p[1].y - l.p[0].y));

	int xinc1, xinc2, yinc1, yinc2;
	int denominator, numerator, numadd, numpixels, curpixel;

	if (l.p[1].x >= l.p[0].x)
	{
		xinc1 = 1;	xinc2 = 1;
	}
	else
	{
		xinc1 = -1; xinc2 = -1;
	}

	if (l.p[1].y >= l.p[0].y)
	{
		yinc1 = 1;	yinc2 = 1;
	}
	else
	{
		yinc1 = -1; yinc2 = -1;
	}

	if (dx >= dy)
	{
		xinc1 = 0;			yinc2 = 0;
		denominator = dx;	numerator = dx / 2;
		numadd = dy;		numpixels = dx;
	}
	else
	{
		xinc2 = 0;			yinc1 = 0;
		denominator = dy;	numerator = dy / 2;
		numadd = dx;		numpixels = dy;
	}

	for (curpixel = 0; curpixel <= numpixels; ++curpixel)
	{
		//assign x-coordinate
		pslocked32 += (int)x;
		//assign y-coordinate
//		pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
		pslocked32 += yoffset * y;
		//set pixel
		*pslocked32 = pixel32;
		//reset pixel pointer
		pslocked32 = psbackup32;

		numerator += numadd;
		if (numerator >= denominator)
		{
			numerator -= denominator;
			x += xinc1;		y += yinc1;
		}

		x += xinc2;		y += yinc2;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//reset surface pointer
	pslocked32	= NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_uf
//
//	draws a single unfilled rectangle with specified bordercolor given by value
//	using bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_uf_32(rectangle r, RGBcolor bc, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip points
	rectclipper(r);

	//set pixel color
	DWORD pixel32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham line drawing ----------------------------------------------------------------

	//dynamic allocated array of 4 pointers to arrays of 4 floats
	//containing rectangle data
//	float (*pe)[4] = new float[4][4];
	int (*pe)[4] = new int[4][4];

	pe[0][0] = (int)r.p[0].x;	pe[0][1] = (int)r.p[0].y;	pe[0][2] = (int)r.p[1].x;	pe[0][3] = (int)r.p[1].y;
	pe[1][0] = (int)r.p[1].x;	pe[1][1] = (int)r.p[1].y;	pe[1][2] = (int)r.p[2].x;	pe[1][3] = (int)r.p[2].y;
	pe[2][0] = (int)r.p[2].x;	pe[2][1] = (int)r.p[2].y;	pe[2][2] = (int)r.p[3].x;	pe[2][3] = (int)r.p[3].y;
	pe[3][0] = (int)r.p[3].x;	pe[3][1] = (int)r.p[3].y;	pe[3][2] = (int)r.p[0].x;	pe[3][3] = (int)r.p[0].y;

	//for every edge
	for (register int i = 0; i < 4; ++i)
	{
		int x = (int)pe[i][0],		y = (int)pe[i][1];
		int dx = abs((int)(pe[i][2] - pe[i][0]));
		int dy = abs((int)(pe[i][3] - pe[i][1]));

		int xinc1, xinc2, yinc1, yinc2;
		int denominator, numerator, numadd, numpixels, curpixel;

		if (pe[i][2] >= pe[i][0])
		{
			xinc1 = 1;	xinc2 = 1;
		}
		else
		{
			xinc1 = -1; xinc2 = -1;
		}

		if (pe[i][3] >= pe[i][1])
		{
			yinc1 = 1;	yinc2 = 1;
		}
		else
		{
			yinc1 = -1; yinc2 = -1;
		}

		if (dx >= dy)
		{
			xinc1 = 0;			yinc2 = 0;
			denominator = dx;	numerator = dx / 2;
			numadd = dy;		numpixels = dx;
		}
		else
		{
			xinc2 = 0;			yinc1 = 0;
			denominator = dy;	numerator = dy / 2;
			numadd = dx;		numpixels = dy;
		}

		for (curpixel = 0; curpixel <= numpixels; ++curpixel)
		{
			//assign x-coordinate
			pslocked32 += (int)x;
			//assign y-coordinate
//			pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
			pslocked32 += yoffset * y;
			//set pixel
			*pslocked32 = pixel32;
			//reset pixel pointer
			pslocked32 = psbackup32;

			numerator += numadd;
			if (numerator >= denominator)
			{
				numerator -= denominator;
				x += xinc1;		y += yinc1;
			}
			x += xinc2;		y += yinc2;
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//delete allocated array
	delete[] pe;

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_array
//
//	draws several unfilled rectangle with specified bordercolor given by value
//	using bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_array_32(rectangle r[], int elements, RGBcolor bc)
{
	//verify
	if (elements < 1)
		return(false);

	//---- setup ---------------------------------------------------------------------------------

	//set pixel color
	DWORD pixel32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham line drawing ----------------------------------------------------------------

	//dynamic allocated array of 4 pointers to arrays of 4 floats
	//containing rectangle data
	//	float (*pe)[4] = new float[4][4];
	int (*pe)[4] = new int[4][4];

	//for all rectangles
	for (register int e = 0; e < elements; ++e)
	{
		//clip rectangle
		rectclipper(r[e]);

		pe[0][0] = (int)r[e].p[0].x;	pe[0][1] = (int)r[e].p[0].y;	pe[0][2] = (int)r[e].p[1].x;	pe[0][3] = (int)r[e].p[1].y;
		pe[1][0] = (int)r[e].p[1].x;	pe[1][1] = (int)r[e].p[1].y;	pe[1][2] = (int)r[e].p[2].x;	pe[1][3] = (int)r[e].p[2].y;
		pe[2][0] = (int)r[e].p[2].x;	pe[2][1] = (int)r[e].p[2].y;	pe[2][2] = (int)r[e].p[3].x;	pe[2][3] = (int)r[e].p[3].y;
		pe[3][0] = (int)r[e].p[3].x;	pe[3][1] = (int)r[e].p[3].y;	pe[3][2] = (int)r[e].p[0].x;	pe[3][3] = (int)r[e].p[0].y;

		//for every edge
		for (register int i = 0; i < 4; ++i)
		{
			int x = (int)pe[i][0],		y = (int)pe[i][1];
			int dx = abs((int)(pe[i][2] - pe[i][0]));
			int dy = abs((int)(pe[i][3] - pe[i][1]));

			int xinc1, xinc2, yinc1, yinc2;
			int denominator, numerator, numadd, numpixels, curpixel;

			if (pe[i][2] >= pe[i][0])
			{
				xinc1 = 1;	xinc2 = 1;
			}
			else
			{
				xinc1 = -1; xinc2 = -1;
			}

			if (pe[i][3] >= pe[i][1])
			{
				yinc1 = 1;	yinc2 = 1;
			}
			else
			{
				yinc1 = -1; yinc2 = -1;
			}

			if (dx >= dy)
			{
				xinc1 = 0;			yinc2 = 0;
				denominator = dx;	numerator = dx / 2;
				numadd = dy;		numpixels = dx;
			}
			else
			{
				xinc2 = 0;			yinc1 = 0;
				denominator = dy;	numerator = dy / 2;
				numadd = dx;		numpixels = dy;
			}

			for (curpixel = 0; curpixel <= numpixels; ++curpixel)
			{
				//assign x-coordinate
				pslocked32 += (int)x;
				//assign y-coordinate
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
				pslocked32 += yoffset * y;
				//set pixel
				*pslocked32 = pixel32;
				//reset pixel pointer
				pslocked32 = psbackup32;

				numerator += numadd;
				if (numerator >= denominator)
				{
					numerator -= denominator;
					x += xinc1;		y += yinc1;
				}
				x += xinc2;		y += yinc2;
			}
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//delete allocated array
	delete[] pe;

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_f
//
//	draws a single filled rectangle without border
//	using polygon scanline algorithm to fill it
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_f_32(rectangle r, RGBcolor fc, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip points
	rectclipper(r);

	//set pixel32 color
	DWORD pixel32 = DWORD(p_rLUT[fc.r] | p_gLUT[fc.g] | p_bLUT[fc.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- scanline algorithm --------------------------------------------------------------------

	//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
	//edge_state: 0 == uninitialized, 1 == in use, 2 == done
	//converted to int
	float edge[4][11] = {(float)(int)r.p[0].x, (float)(int)r.p[0].y, (float)(int)r.p[1].x, (float)(int)r.p[1].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[1].x, (float)(int)r.p[1].y, (float)(int)r.p[2].x, (float)(int)r.p[2].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[2].x, (float)(int)r.p[2].y, (float)(int)r.p[3].x, (float)(int)r.p[3].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[3].x, (float)(int)r.p[3].y, (float)(int)r.p[0].x, (float)(int)r.p[0].y, 0, 0, 0, 0, 0, 0, 0};

	//---- assign values for all edges -----------------------------------------------------------

	//for all 4 edges
	for (register int i = 0; i < 4; ++i)
	{
		//if y1 <= y2
		if (edge[i][1] <= edge[i][3])
		{
			//y_min is y1
			edge[i][4] = edge[i][1];
			//y_max is y2
			edge[i][5] = edge[i][3];
			//x_y_min is x-intersection is x1
			edge[i][7] = edge[i][9] = edge[i][0];
		}
		else
		{
			//else vice versa
			edge[i][4] = edge[i][3];
			edge[i][5] = edge[i][1];
			edge[i][7] = edge[i][9] = edge[i][2];
		}

		//assign x_min
		//if x1 <= x2
		if (edge[i][0] <= edge[i][2])
			//x_min is x1
			edge[i][6] = edge[i][0];
		else
			//else x_min is x2
			edge[i][6] = edge[i][2];

		//!!! bresenham int?
		//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
		//note that values are not absolutes because slope has to be positive and negative
		float dx = edge[i][0] - edge[i][2];
		float dy = edge[i][1] - edge[i][3];

		//if both dx and dy is zero, which means edge has no length
		//set slope to zero so its not used in drawing the polygon
		if (dx == 0 && dy == 0)
			edge[i][8] = 0;
		else
			//if only dx is zero, wehich means infinite slope (straight vertical line)
			//set slope to 1000
			if (dx == 0)
				edge[i][8] = 1000;
			//else slope is dy / dx
			else
				edge[i][8] = dy / dx;
	}

	//---- bubble sort edges by y_min, x_min -----------------------------------------------------

	//temporary edge needed for swapping process
	float temp_edge[11];

	//for maximal 3 loops (since 4 variable need not more loops to be sorted)
	for (i = 0; i < 3; ++i)
	{
		//check for swapping edge 1 and 2
		//if y_min 2nd edge < y_min 1st edge
		if (edge[1][4] < edge[0][4])
			//swap all elements of the two edges
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
			}
		else
			//if y_min 2nd edge == y_min 1st edge, sort by x_min
			if (edge[1][4] == edge[0][4])
				//if x_min 2nd edge < x_min 1st edge
				if (edge[1][6] < edge[0][6])
				{
					//swap all elements of the two edges
					for (int s = 0; s < 11; s++)
					{
						temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
					}
				}
		//otherwise just let the edges as they are

		//check for swapping edge 2 and 3
		if (edge[2][4] < edge[1][4])
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
			}
		else
			if (edge[2][4] == edge[1][4])
				if (edge[2][6] < edge[1][6])
				{
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
					}
				}

		//check for swapping edge 3 and 4
		if (edge[3][4] < edge[2][4])
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
			}
		else
			if (edge[3][4] == edge[2][4])
				if (edge[3][6] < edge[2][6])
				{
					for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
						}
				}
	}

	//---- assign scanline -----------------------------------------------------------------------

	//start scanline at y_min of first edge
	int scanline = (int)edge[0][4];

	//---- activate first edge -------------------------------------------------------------------

	//for every edge
	for (register int e = 0; e < 4; ++e)
	{
		//if slope is zero (horizontal edge)
		if (edge[e][8] == 0)
			//set edge_state to "done"
			edge[e][10] = 2;

		//if edge not "done"
		if (edge[e][10] != 2)
			//activate edge if y_min is scanline
			//(always 2 edges activated at the same time)
			if (edge[e][4] == scanline)
				edge[e][10] = 1;
	}

	//---- drawing -------------------------------------------------------------------------------

	//indicates if there are edges left to draw
	int EDGES = 1;
	//ptd[0] is x-intersection of first active edge,
	//ptd[1] is x-intersection of second active edge,
	//while ptd[2] is used for swapping both values
	int ptd[3] = {0};
	//index of ptd
	int ptd_i = 0;

	while (EDGES)
	{
		//reset pdi index so first active edge is assigned to ptd[0]
		ptd_i = 0;

		//for every edge
		for (e = 0; e < 4; ++e)
		{
			//if edge state is "in use"
			if (edge[e][10] == 1)
			{
				//ptd[ptd_i] is x-intersection
				ptd[ptd_i] = (int)edge[e][9];

				//increase ptd_i so second active edge
				//is assigned to ptd[1]
				++ptd_i;
			}
		}

		//swap first and second ptd using the third one
		//if second ptd is smaller than first ptd
		if (ptd[1] < ptd[0])
		{
			ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
		}

		//draw all pixel32s beginning at pdt[0] + 1 to pdt[1]
		//(x-intersections of scanline with both active edges)
		for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
		{
			//assign x-coordinate
			pslocked32 += fp;
			//assign y-coordinate
//			pslocked32 += (int)((ddspitch / sizeof(DWORD)) * scanline);
			pslocked32 += yoffset * scanline;
			//set pixel32
			*pslocked32 = pixel32;
			//reset pixel32 pointer
			pslocked32 = psbackup32;
		}

	//---- reorder edges -------------------------------------------------------------------------

		//increase scanline
		++scanline;

		//for every edge
		for (e = 0; e < 4; ++e)
		{
			//if edge state is "in use"
			if (edge[e][10] == 1)
				//set edge state to "done" if y_max == scanline
				if (edge[e][5] == scanline)
					edge[e][10] = 2;
				else
					//check if slope is not infinite
					if (edge[e][8] != 1000)
						//increase x-intersection by (1 / slope)
						edge[e][9] += (1 / edge[e][8]);

				//if edge state not "done"
				if (edge[e][10] != 2)
					//if y_min == scanline
					if (edge[e][4] == scanline)
						//activate edge
						edge[e][10] = 1;
		}

		//leave while loop if every edge is done
		if (edge[0][10] == 2)
			if (edge[1][10] == 2)
				if (edge[2][10] == 2)
					if (edge[3][10] == 2)
						EDGES = 0;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_bf
//
//	draws a single filled rectangle with specified colored border
//	using bresenhams line algorithm and polygon scanline algorithm to fill it
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_bf_32(rectangle r, RGBcolor bc, RGBcolor fc, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//clip points
	rectclipper(r);

	//set colors
	DWORD pixelb32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
	DWORD pixelf32 = DWORD(p_rLUT[fc.r] | p_gLUT[fc.g] | p_bLUT[fc.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- setup values --------------------------------------------------------------------------

	//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
	//edge_state: 0 == uninitialized, 1 == in use, 2 == done
	//converted to int
	float edge[4][11] = {(float)(int)r.p[0].x, (float)(int)r.p[0].y, (float)(int)r.p[1].x, (float)(int)r.p[1].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[1].x, (float)(int)r.p[1].y, (float)(int)r.p[2].x, (float)(int)r.p[2].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[2].x, (float)(int)r.p[2].y, (float)(int)r.p[3].x, (float)(int)r.p[3].y, 0, 0, 0, 0, 0, 0, 0,
						 (float)(int)r.p[3].x, (float)(int)r.p[3].y, (float)(int)r.p[0].x, (float)(int)r.p[0].y, 0, 0, 0, 0, 0, 0, 0};

	//for all 4 edges
	for (register int i = 0; i < 4; ++i)
	{
		//if y1 <= y2
		if (edge[i][1] <= edge[i][3])
		{
			//y_min is y1
			edge[i][4] = edge[i][1];
			//y_max is y2
			edge[i][5] = edge[i][3];
			//x_y_min is x-intersection is x1
			edge[i][7] = edge[i][9] = edge[i][0];
		}
		else
		{
			//else vice versa
			edge[i][4] = edge[i][3];
			edge[i][5] = edge[i][1];
			edge[i][7] = edge[i][9] = edge[i][2];
		}

		//assign x_min
		//if x1 <= x2
		if (edge[i][0] <= edge[i][2])
			//x_min is x1
			edge[i][6] = edge[i][0];
		else
			//else x_min is x2
			edge[i][6] = edge[i][2];

		//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
		//note that values are not absolutes because slope has to be positive and negative
		float dx = edge[i][0] - edge[i][2];
		float dy = edge[i][1] - edge[i][3];

		//if both dx and dy is zero, which means edge has no length
		//set slope to zero so its not used in drawing the polygon
		if (dx == 0 && dy == 0)
			edge[i][8] = 0;
		else
			//if only dx is zero, wehich means infinite slope (straight vertical line)
			//set slope to 1000
			if (dx == 0)
				edge[i][8] = 1000;
			//else slope is dy / dx
			else
				edge[i][8] = dy / dx;
	}

	//---- scanline algorithm --------------------------------------------------------------------

	//---- bubble sort edges by y_min, x_min -----------------------------------------------------

	//temporary edge needed for swapping process
	float temp_edge[11];

	//for maximal 3 loops (since 4 variable need not more loops to be sorted)
	for (i = 0; i < 3; ++i)
	{
		//check for swapping edge 1 and 2
		//if y_min 2nd edge < y_min 1st edge
		if (edge[1][4] < edge[0][4])
			//swap all elements of the two edges
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
			}
		else
			//if y_min 2nd edge == y_min 1st edge, sort by x_min
			if (edge[1][4] == edge[0][4])
				//if x_min 2nd edge < x_min 1st edge
				if (edge[1][6] < edge[0][6])
				{
					//swap all elements of the two edges
					for (int s = 0; s < 11; s++)
					{
						temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
					}
				}
		//otherwise just let the edges as they are

		//check for swapping edge 2 and 3
		if (edge[2][4] < edge[1][4])
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
			}
		else
			if (edge[2][4] == edge[1][4])
				if (edge[2][6] < edge[1][6])
				{
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
					}
				}

		//check for swapping edge 3 and 4
		if (edge[3][4] < edge[2][4])
			for (register int s = 0; s < 11; ++s)
			{
				temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
			}
		else
			if (edge[3][4] == edge[2][4])
				if (edge[3][6] < edge[2][6])
				{
					for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
						}
				}
	}

	//---- assign scanline -----------------------------------------------------------------------

	//start scanline at y_min of first edge
	int scanline = (int)edge[0][4];

	//---- activate first edge -------------------------------------------------------------------

	//for every edge
	for (register int e = 0; e < 4; ++e)
	{
		//if slope is zero (horizontal edge)
		if (edge[e][8] == 0)
			//set edge_state to "done"
			edge[e][10] = 2;

		//if edge not "done"
		if (edge[e][10] != 2)
			//activate edge if y_min is scanline
			//(always 2 edges activated at the same time)
			if (edge[e][4] == scanline)
				edge[e][10] = 1;
	}

	//---- drawing -------------------------------------------------------------------------------

	//indicates if there are edges left to draw
	int EDGES = 1;
	//ptd[0] is x-intersection of first active edge,
	//ptd[1] is x-intersection of second active edge,
	//while ptd[2] is used for swapping both values
	int ptd[3] = {0};
	//index of ptd
	int ptd_i = 0;

	while (EDGES)
	{
		//reset pdi index so first active edge is assigned to ptd[0]
		ptd_i = 0;

		//for every edge
		for (e = 0; e < 4; ++e)
		{
			//if edge state is "in use"
			if (edge[e][10] == 1)
			{
				//ptd[ptd_i] is x-intersection
				ptd[ptd_i] = (int)edge[e][9];

				//increase ptd_i so second active edge
				//is assigned to ptd[1]
				++ptd_i;
			}
		}

		//swap first and second ptd using the third one
		//if second ptd is smaller than first ptd
		if (ptd[1] < ptd[0])
		{
			ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
		}

		//draw all pixels beginning at pdt[0] + 1 to pdt[1]
		//(x-intersections of scanline with both active edges)
		for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
		{
			//assign x-coordinate
			pslocked32 += fp;
			//assign y-coordinate
//			pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
			pslocked32 += yoffset * scanline;
			//set pixel
			*pslocked32 = pixelf32;
			//reset pixel pointer
			pslocked32 = psbackup32;
		}

	//---- reorder edges -------------------------------------------------------------------------

		//increase scanline
		++scanline;

		//for every edge
		for (e = 0; e < 4; ++e)
		{
			//if edge state is "in use"
			if (edge[e][10] == 1)
				//set edge state to "done" if y_max == scanline
				if (edge[e][5] == scanline)
					edge[e][10] = 2;
				else
					//check if slope is not infinite
					if (edge[e][8] != 1000)
						//increase x-intersection by (1 / slope)
						edge[e][9] += (1 / edge[e][8]);

				//if edge state not "done"
				if (edge[e][10] != 2)
					//if y_min == scanline
					if (edge[e][4] == scanline)
						//activate edge
						edge[e][10] = 1;
		}

		//leave while loop if every edge is done
		if (edge[0][10] == 2)
			if (edge[1][10] == 2)
				if (edge[2][10] == 2)
					if (edge[3][10] == 2)
						EDGES = 0;
	}

	//---- bresenham line drawing ----------------------------------------------------------------

	//for every edge
	for (i = 0; i < 4; ++i)
	{
		int x = (int)edge[i][0],		y = (int)edge[i][1];
		int dx = abs((int)(edge[i][2] - edge[i][0]));
		int dy = abs((int)(edge[i][3] - edge[i][1]));

		int xinc1, xinc2, yinc1, yinc2;
		int denominator, numerator, numadd, numpixels, curpixel;

		if (edge[i][2] >= edge[i][0])
		{
			xinc1 = 1;	xinc2 = 1;
		}
		else
		{
			xinc1 = -1; xinc2 = -1;
		}

		if (edge[i][3] >= edge[i][1])
		{
			yinc1 = 1;	yinc2 = 1;
		}
		else
		{
			yinc1 = -1; yinc2 = -1;
		}

		if (dx >= dy)
		{
			xinc1 = 0;			yinc2 = 0;
			denominator = dx;	numerator = dx / 2;
			numadd = dy;		numpixels = dx;
		}
		else
		{
			xinc2 = 0;			yinc1 = 0;
			denominator = dy;	numerator = dy / 2;
			numadd = dx;		numpixels = dy;
		}

		for (curpixel = 0; curpixel <= numpixels; ++curpixel)
		{
			//assign x-coordinate
			pslocked32 += x;
			//assign y-coordinate
//			pslocked32 += (ddspitch / sizeof(DWORD)) * y;
			pslocked32 += yoffset * y;
			//set pixel
			*pslocked32 = pixelb32;
			//reset pixel pointer
			pslocked32 = psbackup32;

			numerator += numadd;
			if (numerator >= denominator)
			{
				numerator -= denominator;
				x += xinc1;		y += yinc1;
			}
			x += xinc2;		y += yinc2;
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawcircle
//
//	draws a single circle with specified color (black by default)
//	useing bresenhams circle algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawcircle_32(int cx, int cy, int radius, RGBcolor c, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//set pixel color
	DWORD pixel32 = DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham circle drawing --------------------------------------------------------------

	//!!
	int	x	= 0;
	int y	= radius;
	int p	= 3 - 2 * radius;

	//plotting coordinates
	int px	= 0,	py	= 0;

	while (x <= y)
	{
		//for all octants
		//!!
		for (register int i = 0; i < 8; ++i)
		{
			//set coordinates
			if (i == 0)	{	px = cx + x;		py = cy + y;	}
			if (i == 1)	{	px = cx + x;		py = cy - y;	}
			if (i == 2)	{	px = cx - x;		py = cy + y;	}
			if (i == 3)	{	px = cx - x;		py = cy - y;	}
			if (i == 4)	{	px = cx + y;		py = cy + x;	}
			if (i == 5)	{	px = cx + y;		py = cy - x;	}
			if (i == 6)	{	px = cx - y;		py = cy + x;	}
			if (i == 7)	{	px = cx - y;		py = cy - x;	}

			//clip coordinates
			if (px >= rSCREEN169.left	&& px <= rSCREEN169.right &&
				py >= rSCREEN169.top	&& py <= rSCREEN169.bottom)
			{
				//assign x- and y-coordinates
//				pslocked32 += px;		pslocked32 += (int)((ddspitch / sizeof(DWORD)) * py);
				pslocked32 += px;		pslocked32 += yoffset * py;
				//set pixel, reset pixel pointer
				*pslocked32 = pixel32;		pslocked32 = psbackup32;
			}
		}

		//!!
		if (p < 0)
			p = p + (4 * x) + 6;
		else
		{
			p = p + 4 * (x - y) + 10;
			--y;
		}

		//!!
		++x;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawcircle_array
//
//	draws several unfilled circles with specified bordercolor given by argument
//	using bresenhams circle algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawcircle_array_32(circle c[], int elements, RGBcolor bc)
{
	//verify
	if (elements < 1)
		return(false);

	//---- setup ---------------------------------------------------------------------------------

	//set pixel color
	DWORD pixel32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- bresenham circle drawing --------------------------------------------------------------

	//for all circles
	for (register int e = 0; e < elements; ++e)
	{
		//!!
		int	x	= 0;
		int y	= (int)c[e].radius;
		int p	= 3 - 2 * (int)c[e].radius;

		//plotting coordinates
		int px	= 0,	py	= 0;

		while (x <= y)
		{
			//for all octants
			//!!
			for (register int i = 0; i < 8; ++i)
			{
				//set coordinates
				if (i == 0)	{	px = (int)c[e].c.x + x;		py = (int)c[e].c.y + y;	}
				if (i == 1)	{	px = (int)c[e].c.x + x;		py = (int)c[e].c.y - y;	}
				if (i == 2)	{	px = (int)c[e].c.x - x;		py = (int)c[e].c.y + y;	}
				if (i == 3)	{	px = (int)c[e].c.x - x;		py = (int)c[e].c.y - y;	}
				if (i == 4)	{	px = (int)c[e].c.x + y;		py = (int)c[e].c.y + x;	}
				if (i == 5)	{	px = (int)c[e].c.x + y;		py = (int)c[e].c.y - x;	}
				if (i == 6)	{	px = (int)c[e].c.x - y;		py = (int)c[e].c.y + x;	}
				if (i == 7)	{	px = (int)c[e].c.x - y;		py = (int)c[e].c.y - x;	}

				//clip coordinates
				if (px >= rSCREEN169.left	&& px <= rSCREEN169.right &&
					py >= rSCREEN169.top	&& py <= rSCREEN169.bottom)
				{
					//assign x- and y-coordinates
//					pslocked32 += px;		pslocked32 += (int)((ddspitch / sizeof(DWORD)) * py);
					pslocked32 += px;		pslocked32 += yoffset * py;
					//set pixel, reset pixel pointer
					*pslocked32 = pixel32;		pslocked32 = psbackup32;
				}
			}

			//!!
			if (p < 0)
				p = p + (4 * x) + 6;
			else
			{
				p = p + 4 * (x - y) + 10;
				--y;
			}

			//!!
			++x;
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawfist
//
//	draws fist with appropriate color for option menu
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawfist_32(int x, int y, RGBcolor fc, int ml)
{
	//---- setup ---------------------------------------------------------------------------------

	//colors, uses pixelb as border, pixelf as fillcolor (damage)
	DWORD pixelb32 = DWORD(p_rLUT[0] | p_gLUT[0] | p_bLUT[0]);
	DWORD pixelf32 = DWORD(p_rLUT[fc.r] | p_gLUT[fc.g] | p_bLUT[fc.b]);

	//auto lock
	if (!ml)
	{
		//lock surface
		if (!BBLock())
			return(false);
	}

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- draw fist -----------------------------------------------------------------------------

	//!!! radius?
	//size of fist
	int fist_s		= 12;

	//offset as argument
	int offx = x;	int offy = y;

	//draw fist array
	for (register int line = 0; line < fist_s; ++line)
		for (register int column = 0; column < fist_s; ++column)
		{
			//clipping
			if (offx + column	>= rSCREEN169.left	&& offx + column	<= rSCREEN169.right - 1 &&
				offy + line		>= rSCREEN169.top	&& offy + line		<= rSCREEN169.bottom - 1)
				{
					//set surface pointer
					pslocked32 += offx + column;
//					pslocked32 += (ddspitch / sizeof(DWORD)) * (offy + line);
					pslocked32 += yoffset * (offy + line);

					//set pixel according to array
					if (fist_a[line * fist_s + column] == 1)
						*pslocked32 = pixelb32;
					if (fist_a[line * fist_s + column] == 2)
						*pslocked32 = pixelf32;
				}

				//reset surface pointer
				pslocked32 = psbackup32;
		}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	if (!ml)
		BBUnlock();
	//reset surface pointer
	pslocked32 = NULL;

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw pixelfilter
//
//	renders whole scene with certain effect (negative, grayscale)
//	used for pause mode
//	(used to take average of every rgb-value to determine
//	grayscale the right formula however is 0.3 * red + 0.59 * green + 0.11 * blue)
//
//------------------------------------------------------------------------------------------------

bool directdraw::pixelfilter_32(RECT area, int effect, WORD bred, WORD bgreen, WORD bblue)
{
	//---- setup ---------------------------------------------------------------------------------

	//check color bias for validity
	bred	< 0	? bred		= 0		: bred		> 255 ? bred	= 255 : bred;
	bgreen	< 0	? bgreen	= 0		: bgreen	> 255 ? bgreen	= 255 : bgreen;
	bblue	< 0	? bblue		= 0		: bblue		> 255 ? bblue	= 255 :	bblue;

	//pixel color
	DWORD pixel32 = DWORD(p_rLUT[0] | p_gLUT[0] | p_bLUT[0]);

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- render scene color biased -------------------------------------------------------------

	//colors in video ram
	DWORD vred = 0, vgreen = 0, vblue = 0;
	//consisting for rgb-triplet
	DWORD vcolor = 0;
	//effect color
	//grayscale (0.3 * red + 0.59 * green + 0.11 * blue)
	int cfx = 0;

	//for every pixel in area
	for (register int l = area.top, r = area.left; l < area.bottom; ++l)
	{
		//assign x-coordinate
		pslocked32 += area.left;
		//assign y-coordinate
//		pslocked32 += (int)((ddspitch / sizeof(DWORD)) * l);
		pslocked32 += yoffset * l;

		for (r = area.left; r < area.right; ++r)
		{
			//read pixel
			vcolor = *pslocked32;

			//split color into rgb components
			//(filtering color components by & combining with rgb-mask)
			vred	= vcolor & (DWORD)ddpixel.dwRBitMask;
			vgreen	= vcolor & (DWORD)ddpixel.dwGBitMask;
			vblue	= vcolor & (DWORD)ddpixel.dwBBitMask;

			//get the right index of color (0 to 255)
			vred	= (DWORD)((255.0f / ddpixel.dwRBitMask) * vred);
			vgreen	= (DWORD)((255.0f / ddpixel.dwGBitMask) * vgreen);
			vblue	= (DWORD)((255.0f / ddpixel.dwBBitMask) * vblue);

			//add effect in accordance with argument
			//negative
			if (effect == 0)
			{
				//calculate negative
				vred			= 255 - vred;
				vgreen			= 255 - vgreen;
				vblue			= 255 - vblue;
			}
			else
			//color bias
			{
				//calculate color bias
				cfx = (int)(0.3 * vred + 0.59 * vgreen + 0.11 * vblue);
				//apply bias and check for validity
				vred			= cfx + bred;
				vgreen			= cfx + bgreen;
				vblue			= cfx + bblue;
				vred	> 255	? vred		= 255	: vred;
				vgreen	> 255	? vgreen	= 255	: vgreen;
				vblue	> 255	? vblue		= 255	: vblue;
			}

			//set effect pixel
			pixel32 = DWORD(p_rLUT[vred] | p_gLUT[vgreen] | p_bLUT[vblue]);
			*pslocked32 = pixel32;

			//increase row
			++pslocked32;
		}

		//reset pixel pointer
		pslocked32 = psbackup32;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawparticles
//
//	draws particles, gets array of particles, number of particles and color scheme
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawparticles_32(particle *pa, int size, int shadows, int c_scheme, int r_no)
{
	//---- setup ---------------------------------------------------------------------------------

	//colorindex for color change LUT
	int			ci = 0;

	//gets pixel32 color
	DWORD pixel32;

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- plot particles ------------------------------------------------------------------------

	int x, y;

	//for every particle
	for (register int i = 0; i < size; ++i)
	{
		//get particle color
		switch (c_scheme)
		{

		//---- white to color fades --------------------------------------------------------------

		//these old color schemes look shitty and produce faulty pixel32 values
/*		//white to black
		case (0):
			{
				//color depends on age (minus or plus value to start not from beginning
				//which takes too long)
				//round for more smooth change
				ci = 100 - round_fi((((float)pa[i].age) + 3000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;

				//get rgb colors
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);

				break;
			}

		//white to blue
		case (1):
			{
				ci = 100 - round_fi((((float)pa[i].age) + 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_bluewhiteLUT[ci][0]] |
							   p_gLUT[p_bluewhiteLUT[ci][1]] |
							   p_bLUT[p_bluewhiteLUT[ci][2]]);
				break;
			}

		//white to red
		case (2):
			{
				ci = 100 - round_fi((((float)pa[i].age) + 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[255] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//green
		case (3):
			{
				pixel32	= DWORD(p_rLUT[0] |
							   p_gLUT[128] |
							   p_bLUT[0]);
				break;
			}

		//white to pink
		case (4):
			{
				ci = 100 - round_fi((((float)pa[i].age) + 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[255] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[255]);
				break;
			}

		//gray
		case (5):
			{
				pixel32	= DWORD(p_rLUT[128] |
							   p_gLUT[128] |
							   p_bLUT[128]);
				break;
			}

		//purple
		case (6):
			{
				pixel32	= DWORD(p_rLUT[128] |
							   p_gLUT[0] |
							   p_bLUT[255]);
				break;
			}

		//---- color to white fades --------------------------------------------------------------

		//black to white fade
		case (7):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//blue to white fade
		case (8):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_bluewhiteLUT[ci][0]] |
							   p_gLUT[p_bluewhiteLUT[ci][1]] |
							   p_bLUT[p_bluewhiteLUT[ci][2]]);
				break;
			}

		//red to white fade
		case (9):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[255] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//green to white fade
		//!!
		case (10):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
//				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
//							   p_gLUT[255] |
//							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[128] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//pink to white fade
		case (11):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[255] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[255]);
				break;
			}

		//gray to white fade
		case (12):
			{
				ci = round_fi(((float)pa[i].age) / 20.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//purple to white fade
		case (13):
			{
				ci = round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[255] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[255]);
				break;
			}

		//---- black to color fades --------------------------------------------------------------

		//black to white
		case (14):
			{
				ci = round_fi((((float)pa[i].age) + 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//green to red/pure red
		case (15):
			{
				//if random number is zero use green-red, else pure red
				if (r_no == 0)
				{
					ci = round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_greenredLUT[ci][0]] |
								   p_gLUT[p_greenredLUT[ci][1]] |
								   p_bLUT[p_greenredLUT[ci][2]]);
				}
				else
				{
					ci = round_fi((((float)pa[i].age) + 7000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
								   p_gLUT[0] |
								   p_bLUT[0]);
				}
				break;
			}

		//red to green/pure green
		case (16):
			{
				//if random number is zero use red-green, else pure green
				if (r_no == 0)
				{
					ci = 100 - round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_greenredLUT[ci][0]] |
								   p_gLUT[p_greenredLUT[ci][1]] |
								   p_bLUT[p_greenredLUT[ci][2]]);
				}
				else
				{
					ci = round_fi((((float)pa[i].age) + 7000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[0] |
								   p_gLUT[p_blackwhiteLUT[ci][1]] |
								   p_bLUT[0]);
				}
				break;
			}

		//green to blue/pure light blue
		case (17):
			{
				//if random number is zero use green-blue, else pure light blue
				if (r_no == 0)
				{
					ci = round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_greenblueLUT[ci][0]] |
								   p_gLUT[p_greenblueLUT[ci][1]] |
								   p_bLUT[p_greenblueLUT[ci][2]]);
				}
				else
				{
					ci = round_fi((((float)pa[i].age) + 7000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[0] |
								   p_gLUT[p_blackwhiteLUT[ci][1]] |
								   p_bLUT[p_blackwhiteLUT[ci][2]]);
				}
				break;
			}

		//blue to green
		case (18):
			{
				ci = 100 - round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_greenblueLUT[ci][0]] |
							   p_gLUT[p_greenblueLUT[ci][1]] |
							   p_bLUT[p_greenblueLUT[ci][2]]);
				break;
			}

		//yellow to pink
		case (19):
			{
				ci = round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_yellowpinkLUT[ci][0]] |
							   p_gLUT[p_yellowpinkLUT[ci][1]] |
							   p_bLUT[p_yellowpinkLUT[ci][2]]);
				break;
			}

		//pink to yellow/pure yellow
		case (20):
			{
				//if random number is zero use pink-yellow, else pure yellow
				if (r_no == 0)
				{
					ci = 100 - round_fi((((float)pa[i].age) - 5000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_yellowpinkLUT[ci][0]] |
								   p_gLUT[p_yellowpinkLUT[ci][1]] |
								   p_bLUT[p_yellowpinkLUT[ci][2]]);
				}
				else
				{
					ci = round_fi((((float)pa[i].age) + 7000.0f) / 100.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
								   p_gLUT[p_blackwhiteLUT[ci][1]] |
								   p_bLUT[0]);
				}
				break;
			}

		//---- color to black fades --------------------------------------------------------------

		//white to black fade
		case (21):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//red to black fade
		case (22):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[0] |
							   p_bLUT[0]);
				break;
			}

		//green to black fade
		case (23):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[0] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[0]);
				break;
			}

		//blue to black fade
		case (24):
			{
				//if random number is zero use blue, else pure light blue
				if (r_no == 0)
				{
					ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[0] |
								   p_gLUT[0] |
								   p_bLUT[p_blackwhiteLUT[ci][2]]);
				}
				else
				{
					ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
					ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
					pixel32	= DWORD(p_rLUT[0] |
								   p_gLUT[p_blackwhiteLUT[ci][1]] |
								   p_bLUT[p_blackwhiteLUT[ci][2]]);
				}
				break;
			}

		//green to black fade
		case (25):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[0] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[0]);
				break;
			}

		//pink to black fade
		case (26):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[0] |
							   p_bLUT[p_blackwhiteLUT[ci][2]]);
				break;
			}

		//yellow to black fade
		case (27):
			{
				ci = 100 - round_fi(((float)pa[i].age) / 30.0f);
				ci > 100 ? ci = 100	: ci;	ci < 0 ? ci = 0 : ci;
				pixel32	= DWORD(p_rLUT[p_blackwhiteLUT[ci][0]] |
							   p_gLUT[p_blackwhiteLUT[ci][1]] |
							   p_bLUT[0]);
				break;
			}*/

		//---- simple colors ---------------------------------------------------------------------

		//red only (blood)
		case (100):
			{
				pixel32	= DWORD(p_rLUT[255] |
								p_gLUT[0] |
								p_bLUT[0]);
				break;
			}

		//200 - 207, BLACK BACKGROUND
		//white
		case (200):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[255] |
								p_bLUT[255]);
				break;
			}

		//red
		case (201):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[0] |
								p_bLUT[0]);
				break;
			}

		//green
		case (202):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[255] |
								p_bLUT[0]);
				break;
			}

		//blue
		case (203):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[0] |
								p_bLUT[255]);
				break;
			}

		//yellow
		case (204):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[255] |
								p_bLUT[0]);
				break;
			}

		//pink
		case (205):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[0] |
								p_bLUT[255]);
				break;
			}

		//lightblue
		case (206):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[255] |
								p_bLUT[255]);
				break;
			}

		//orange
		case (207):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[155] |
								p_bLUT[0]);
				break;
			}

		//300 - 307, WHITE BACKGROUND
		//black
		case (300):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[0] |
								p_bLUT[0]);
				break;
			}

		//red
		case (301):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[0] |
								p_bLUT[0]);
				break;
			}

		//green
		case (302):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[128] |
								p_bLUT[0]);
				break;
			}

		//blue
		case (303):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[0] |
								p_bLUT[255]);
				break;
			}

		//yellow
		case (304):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[220] |
								p_bLUT[0]);
				break;
			}

		//pink
		case (305):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[0] |
								p_bLUT[255]);
				break;
			}

		//lightblue
		case (306):
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[255] |
								p_bLUT[255]);
				break;
			}

		//orange
		case (307):
			{
				pixel32 = DWORD(p_rLUT[255] |
								p_gLUT[155] |
								p_bLUT[0]);
				break;
			}

		//default
		default:
			{
				pixel32 = DWORD(p_rLUT[0] |
								p_gLUT[0] |
								p_bLUT[0]);

				gf_logger(true, "dd::drawparticles_32 DEFAULT color scheme (%i)", c_scheme);

				break;
			}
		}

		//if age != -1 which would mean particle is out of bounds
		//and age is not bigger than lifetime or lifetime is infinite,
		//draw particle
		if (pa[i].age != -1 &&
			(pa[i].age <= pa[i].lifetime || pa[i].lifetime == -1))
		{
			//draw particle shadow first if option is on
			if (shadows == ON)
			{
				//clipping
				if ((int)pa[i].pos_s.x >= rSCREEN169.left && (int)pa[i].pos_s.x <= rSCREEN169.right - 1 &&
					(int)pa[i].pos_s.y >= rSCREEN169.top && (int)pa[i].pos_s.y <= rSCREEN169.bottom - 1)
				{
					pslocked32 += (int)pa[i].pos_s.x;
//					pslocked32 += (int)((ddspitch / sizeof(DWORD)) * (int)pa[i].pos_s.y);
					pslocked32 += yoffset * (int)pa[i].pos_s.y;
					//shadows are dark gray
					*pslocked32 = DWORD(p_rLUT[30] | p_gLUT[30] | p_bLUT[30]);
					//reset pixel32 pointer
					pslocked32 = psbackup32;
				}
			}

			//convert pos into integers
			x = (int)pa[i].pos.x;
			y = (int)pa[i].pos.y;

			//assign x-coordinate
			//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
			pslocked32 += x;
			//assign y-coordinate
			//ddspitch is in byte, but since one pixel32 is short and pslocked32
			//is incremented by short you have to adjust the ddspitch value by
			//the size of short
//			pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
			pslocked32 += yoffset * y;
			//set pixel32
			*pslocked32 = pixel32;
			//reset pixel32 pointer
			pslocked32 = psbackup32;
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawplayers
//
//	draws both players with or without shadows in correct z-order
//	blackwhite mode colorflag as argument
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawplayers_32(player_data *pd, int shadows, int bwmode, float s_zoom)
{
	//---- setup ---------------------------------------------------------------------------------

	//border color (black)
	DWORD pixelb32 = DWORD(p_rLUT[0] | p_gLUT[0] | p_bLUT[0]);
	//fill color in dependence of bone damage
	DWORD pixelf32;

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointers
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	//get adress of surface memory
	//return false if NULL pointer is returned
	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- setup values --------------------------------------------------------------------------

	//number of bones
	int nob = 38;

	//if shadow option is off, number of bones is 38, else it's 76
	if (shadows == 1)		nob = 76;

	//for every bone starting with shadows
	for (register int b = nob - 1; b >= 0; --b)
	{
		//if not the shadow
		if (b < 38)
		{
			//assign appropriate color
			//if damage visible
//!!
//			if (pd->pzb[b]->type < 2)
			if (pd->pzb[b]->type != 2)
			{
				//if no blackwhite mode use standard color table
				if (bwmode == 0)
				{
					//white/red flash
					if (pd->pzb[b]->hit_state == 1)
						pixelf32 = DWORD(p_rLUT[255] |
									  p_gLUT[255] |
									  p_bLUT[255]);
					else
						pixelf32 = DWORD(p_rLUT[p_greenredLUT[pd->pzb[b]->damage][0]] |
									  p_gLUT[p_greenredLUT[pd->pzb[b]->damage][1]] |
									  p_bLUT[p_greenredLUT[pd->pzb[b]->damage][2]]);
				}
				else
				{
					if (pd->pzb[b]->hit_state == 1)
						pixelf32 = DWORD(p_rLUT[255] |
									  p_gLUT[0] |
									  p_bLUT[0]);
					else
						//100 - damage because table is from black to white
						//while increasing damage is from white to black
						pixelf32 = DWORD(p_rLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][0]] |
									  p_gLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][1]] |
									  p_bLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]]);
				}

				//!!
				//wenn state von bone soundso (= getroffen)
				//weisses aufblitzen des bones (nach zeit oder nur ein frame?)
			}
			else
			{
				//if no damage visible black
				if (pd->pzb[b]->hit_state == 1)
					pixelf32 = DWORD(p_rLUT[255] |
								  p_gLUT[255] |
								  p_bLUT[255]);
				else
//				if (pd->pzb[b]->type > 1)
					pixelf32 = DWORD(p_rLUT[0] | p_gLUT[0] | p_bLUT[0]);
			}
		}
		else
		{
			//shadows are dark gray
			pixelf32 = DWORD(p_rLUT[30] | p_gLUT[30] | p_bLUT[30]);
		}

		//outside of if-statement cause else the rest of the function
		//doesn't know this array
		float edge[4][11] = {0};

		//if not the shadow
		if (b < 38)
		{
			//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
			//edge_state: 0 == uninitialized, 1 == in use, 2 == done
			//converted to int (and back to float to suppress converting warnings)
			edge[0][0] = (float)(int)pd->pzb[b]->v.p[0].x;
			edge[0][1] = (float)(int)pd->pzb[b]->v.p[0].y;
			edge[0][2] = (float)(int)pd->pzb[b]->v.p[1].x;
			edge[0][3] = (float)(int)pd->pzb[b]->v.p[1].y;

			edge[1][0] = (float)(int)pd->pzb[b]->v.p[1].x;
			edge[1][1] = (float)(int)pd->pzb[b]->v.p[1].y;
			edge[1][2] = (float)(int)pd->pzb[b]->v.p[2].x;
			edge[1][3] = (float)(int)pd->pzb[b]->v.p[2].y;

			edge[2][0] = (float)(int)pd->pzb[b]->v.p[2].x;
			edge[2][1] = (float)(int)pd->pzb[b]->v.p[2].y;
			edge[2][2] = (float)(int)pd->pzb[b]->v.p[3].x;
			edge[2][3] = (float)(int)pd->pzb[b]->v.p[3].y;

			edge[3][0] = (float)(int)pd->pzb[b]->v.p[3].x;
			edge[3][1] = (float)(int)pd->pzb[b]->v.p[3].y;
			edge[3][2] = (float)(int)pd->pzb[b]->v.p[0].x;
			edge[3][3] = (float)(int)pd->pzb[b]->v.p[0].y;
		}
		else
		{
			edge[0][0] = (float)(int)pd->pzb[b - 38]->vs.p[0].x;
			edge[0][1] = (float)(int)pd->pzb[b - 38]->vs.p[0].y;
			edge[0][2] = (float)(int)pd->pzb[b - 38]->vs.p[1].x;
			edge[0][3] = (float)(int)pd->pzb[b - 38]->vs.p[1].y;

			edge[1][0] = (float)(int)pd->pzb[b - 38]->vs.p[1].x;
			edge[1][1] = (float)(int)pd->pzb[b - 38]->vs.p[1].y;
			edge[1][2] = (float)(int)pd->pzb[b - 38]->vs.p[2].x;
			edge[1][3] = (float)(int)pd->pzb[b - 38]->vs.p[2].y;

			edge[2][0] = (float)(int)pd->pzb[b - 38]->vs.p[2].x;
			edge[2][1] = (float)(int)pd->pzb[b - 38]->vs.p[2].y;
			edge[2][2] = (float)(int)pd->pzb[b - 38]->vs.p[3].x;
			edge[2][3] = (float)(int)pd->pzb[b - 38]->vs.p[3].y;

			edge[3][0] = (float)(int)pd->pzb[b - 38]->vs.p[3].x;
			edge[3][1] = (float)(int)pd->pzb[b - 38]->vs.p[3].y;
			edge[3][2] = (float)(int)pd->pzb[b - 38]->vs.p[0].x;
			edge[3][3] = (float)(int)pd->pzb[b - 38]->vs.p[0].y;
		}

		//----------------------------------------------------------------------------------------

		 //for all 4 edges
		for (register int i = 0; i < 4; ++i)
		{
			//if y1 <= y2
			if (edge[i][1] <= edge[i][3])
			{
				//y_min is y1
				edge[i][4] = edge[i][1];
				//y_max is y2
				edge[i][5] = edge[i][3];
				//x_y_min is x-intersection is x1
				edge[i][7] = edge[i][9] = edge[i][0];
			}
			else
			{
				//else vice versa
				edge[i][4] = edge[i][3];
				edge[i][5] = edge[i][1];
				edge[i][7] = edge[i][9] = edge[i][2];
			}

			//assign x_min
			//if x1 <= x2
			if (edge[i][0] <= edge[i][2])
				//x_min is x1
				edge[i][6] = edge[i][0];
			else
				//else x_min is x2
				edge[i][6] = edge[i][2];

			//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
			//note that values are not absolutes because slope has to be positive and negative
			float dx = edge[i][0] - edge[i][2];
			float dy = edge[i][1] - edge[i][3];

			//if both dx and dy is zero, which means edge has no length
			//set slope to zero so its not used in drawing the polygon
			if (dx == 0 && dy == 0)
				edge[i][8] = 0;
			else
				//if only dx is zero, wehich means infinite slope (straight vertical line)
				//set slope to 1000
				if (dx == 0)
					edge[i][8] = 1000;
				//else slope is dy / dx
				else
					edge[i][8] = dy / dx;
		}

		//---- scanline algorithm ----------------------------------------------------------------

		//---- bubble sort edges by y_min, x_min -------------------------------------------------

		//temporary edge needed for swapping process
		float temp_edge[11];

		//for maximal 3 loops (since 4 variable need not more loops to be sorted)
		for (i = 0; i < 3; ++i)
		{
			//check for swapping edge 1 and 2
			//if y_min 2nd edge < y_min 1st edge
			if (edge[1][4] < edge[0][4])
				//swap all elements of the two edges
				for (register int s = 0; s < 11; ++s)
				{
					temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
				}
			else
				//if y_min 2nd edge == y_min 1st edge, sort by x_min
				if (edge[1][4] == edge[0][4])
					//if x_min 2nd edge < x_min 1st edge
					if (edge[1][6] < edge[0][6])
					{
						//swap all elements of the two edges
						for (int s = 0; s < 11; s++)
						{
							temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
						}
					}
			//otherwise just let the edges as they are

			//check for swapping edge 2 and 3
			if (edge[2][4] < edge[1][4])
				for (register int s = 0; s < 11; ++s)
				{
					temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
				}
			else
				if (edge[2][4] == edge[1][4])
					if (edge[2][6] < edge[1][6])
					{
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
						}
					}

			//check for swapping edge 3 and 4
			if (edge[3][4] < edge[2][4])
				for (register int s = 0; s < 11; ++s)
				{
					temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
				}
			else
				if (edge[3][4] == edge[2][4])
					if (edge[3][6] < edge[2][6])
					{
						for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
							}
					}
		}

		//---- assign scanline -------------------------------------------------------------------

		//start scanline at y_min of first edge
		int scanline = (int)edge[0][4];

		//---- activate first edge ---------------------------------------------------------------

		//for every edge
		for (register int e = 0; e < 4; ++e)
		{
			//if slope is zero (horizontal edge)
			if (edge[e][8] == 0)
				edge[e][10] = 2;
				//set edge_state to "done"

			//if edge not "done"
			if (edge[e][10] != 2)
				//activate edge if y_min is scanline
				//(always 2 edges activated at the same time)
				if (edge[e][4] == scanline)
					edge[e][10] = 1;
		}

		//---- drawing ---------------------------------------------------------------------------

		//indicates if there are edges left to draw
		int EDGES = 1;
		//ptd[0] is x-intersection of first active edge,
		//ptd[1] is x-intersection of second active edge,
		//while ptd[2] is used for swapping both values
		int ptd[3] = {0};
		//index of ptd
		int ptd_i = 0;

		while (EDGES)
		{
			//reset pdi index so first active edge is assigned to ptd[0]
			ptd_i = 0;

			//for every edge
			for (e = 0; e < 4; ++e)
			{
				//if edge state is "in use"
				if (edge[e][10] == 1)
				{
					//ptd[ptd_i] is x-intersection
					ptd[ptd_i] = (int)edge[e][9];

					//increase ptd_i so second active edge
					//is assigned to ptd[1]
					++ptd_i;
				}
			}

			//swap first and second ptd using the third one
			//if second ptd is smaller than first ptd
			if (ptd[1] < ptd[0])
			{
				ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
			}

			//if not the shadow draw normal
			if (b < 38)
			{
				//draw all pixels beginning at pdt[0] + 1 to pdt[1]
				//(x-intersections of scanline with both active edges)
				for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
				{
					//assign x-coordinate
					pslocked32 += fp;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
					pslocked32 += yoffset * scanline;
					//set pixel
					*pslocked32 = pixelf32;
					//reset pixel pointer
					pslocked32 = psbackup32;
				}
			}
			else
			//draw it thicker
			{
				for (int fp = ptd[0], lp = ptd[1]; fp <= lp; ++fp)
				{
					//assign x-coordinate
					pslocked32 += fp;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
					pslocked32 += yoffset * scanline;
					//set pixel
					*pslocked32 = pixelf32;
					//reset pixel pointer
					pslocked32 = psbackup32;
				}
			}

			//---- reorder edges -----------------------------------------------------------------

			//increase scanline
				++scanline;

			//for every edge
			for (e = 0; e < 4; ++e)
			{
				//if edge state is "in use"
				if (edge[e][10] == 1)
					//set edge state to "done" if y_max == scanline
					if (edge[e][5] == scanline)
						edge[e][10] = 2;
					else
						//check if slope is not infinite
						if (edge[e][8] != 1000)
							//increase x-intersection by (1 / slope)
							edge[e][9] += (1 / edge[e][8]);

					//if edge state not "done"
					if (edge[e][10] != 2)
						//if y_min == scanline
						if (edge[e][4] == scanline)
							//activate edge
							edge[e][10] = 1;
			}

			//leave while loop if every edge is done
			if (edge[0][10] == 2)
				if (edge[1][10] == 2)
					if (edge[2][10] == 2)
						if (edge[3][10] == 2)
							EDGES = 0;
		}

		//---- bresenham line drawing ------------------------------------------------------------

		//only if not the shadow
		if (b < 38)
		{
			//for every edge
			for (i = 0; i < 4; ++i)
			{
				int x = (int)edge[i][0],		y = (int)edge[i][1];
				int dx = abs((int)(edge[i][2] - edge[i][0]));
				int dy = abs((int)(edge[i][3] - edge[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (edge[i][2] >= edge[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (edge[i][3] >= edge[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += x;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * y;
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixelb32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}
		}

		//---- fist/head drawing -----------------------------------------------------------------

		//colors, uses pixelb32 as border, pixelf32 as fillcolor (damage) and
		//pixel_fa32 as head fillcolor (fatigue)
		DWORD pixel_fa32;

		//if not the shadow
		if (b < 38)
		{
			//if bone has fist draw it
			if (pd->pzb[b]->type == 1)
			{
				//assign user set fistcolor
				pixelf32		= DWORD(p_rLUT[p_option->data.fistcolor[pd->pzb[b]->id].r] |
								   p_gLUT[p_option->data.fistcolor[pd->pzb[b]->id].g] |
								   p_bLUT[p_option->data.fistcolor[pd->pzb[b]->id].b]);

				//!!! radius?
				//size of fist
				int fist_s			= 12;
				//assign zoomfactor and round .5 up
				int fist_sz			= (int)(fist_s * s_zoom + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//get fist_array offset from hitbox
				int offx = pd->pzb[b]->hitbox_e.left;
				int offy = pd->pzb[b]->hitbox_e.top;

				//draw fist array
				for (register int line = 0; line < fist_sz; ++line)
					for (register int column = 0; column < fist_sz; ++column)
					{
						//clipping
						if (offx + column	>= rSCREEN169.left	&& offx + column	<= rSCREEN169.right - 1 &&
							offy + line		>= rSCREEN169.top	&& offy + line		<= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += offx + column;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * (offy + line);
							pslocked32 += yoffset * (offy + line);

							//get line and column index of original array
							index_l = (int)((line + 1) / s_zoom + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > fist_s)	index_l = fist_s;
							index_c	= (int)((column + 1) / s_zoom + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > fist_s)	index_c = fist_s;

							//set pixel according to array
							if (fist_a[index_l * fist_s + index_c] == 1)
								*pslocked32 = pixelb32;
							if (fist_a[index_l * fist_s + index_c] == 2)
								*pslocked32 = pixelf32;

//!!!
/*							if (fist_a[line * fist_s + column] == 1)
								*pslocked32 = pixelb32;
							if (fist_a[line * fist_s + column] == 2)
								*pslocked32 = pixelf32;*/
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}

			//if bone has head draw it
			if (pd->pzb[b]->type == 3)
			{
				//assing appropriate headdamage and fatigue color
				//player 1
				if (pd->pzb[b]->id == P1)
				{
					//if no blackwhite mode use standard color table
					if (bwmode == 0)
					{
						//damage
						pixelf32		= DWORD(p_rLUT[p_greenredLUT[pd->pzb[b]->damage][0]] |
										   p_gLUT[p_greenredLUT[pd->pzb[b]->damage][1]] |
										   p_bLUT[p_greenredLUT[pd->pzb[b]->damage][2]]);

						//!!! fatigue int to float
						//fatigue
						pixel_fa32	= DWORD(p_rLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P1]][0]] |
										   p_gLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P1]][1]] |
										   p_bLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P1]][2]]);
					}
					else
					{
						//damage
						pixelf32		= DWORD(p_rLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][0]] |
										   p_gLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][1]] |
										   p_bLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]]);

						//fatigue
						pixel_fa32	= DWORD(p_rLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P1]][0]] |
										   p_gLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P1]][1]] |
										   p_bLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P1]][2]]);
					}
				}
				else
				//player 2
				{
					//if no blackwhite mode use standard color table
					if (bwmode == 0)
					{
						//damage
						pixelf32		= DWORD(p_rLUT[p_greenredLUT[pd->pzb[b]->damage][0]] |
										   p_gLUT[p_greenredLUT[pd->pzb[b]->damage][1]] |
										   p_bLUT[p_greenredLUT[pd->pzb[b]->damage][2]]);

						//fatigue
						pixel_fa32	= DWORD(p_rLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P2]][0]] |
										   p_gLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P2]][1]] |
										   p_bLUT[p_bluewhiteLUT[(int)*pd->p_fatigue[P2]][2]]);
					}
					else
					{
						//damage
						pixelf32		= DWORD(p_rLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][0]] |
										   p_gLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][1]] |
										   p_bLUT[p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]]);

						//fatigue
						pixel_fa32	= DWORD(p_rLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P2]][0]] |
										   p_gLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P2]][1]] |
										   p_bLUT[p_blackwhiteLUT[(int)*pd->p_fatigue[P2]][2]]);
					}
				}

				//!!! radius?
				//size of head
				int head_s		= 26;
				//assign zoomfactor and round .5 up
				int head_sz		= (int)(head_s * s_zoom + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//!! headorder

				//pointer to back or front head in dependence of stance
				signed char *head_a;
				//player 1
				if (pd->pzb[b]->id == P1)
					//on the left side
					if (*pd->p_side[P1] == SLEFT)
					{
						//left foot forward
						if (*pd->p_stance[P1] == 0)
							head_a = head_f;
						else
						//right foot forward
							head_a = head_b;
					}
					else
					//on the right
					{
						//left foot forward
						if (*pd->p_stance[P1] == 0)
							head_a = head_b;
						else
						//right foot forward
							head_a = head_f;
					}
				else
				//player 2
					//on the left side
					if (*pd->p_side[P2] == SLEFT)
					{
						//left foot forward
						if (*pd->p_stance[P2] == 0)
							head_a = head_f;
						else
						//right foot forward
							head_a = head_b;
					}
					else
					//on the right
					{
						//left foot forward
						if (*pd->p_stance[P2] == 0)
							head_a = head_b;
						else
						//right foot forward
							head_a = head_f;
					}

				//get head_array offset from hitbox
				int offx = pd->pzb[b]->hitbox_e.left;
				int offy = pd->pzb[b]->hitbox_e.top;

				//draw head array
				for (register int line = 0; line < head_sz; ++line)
					for (register int column = 0; column < head_sz; ++column)
					{
						//clipping
						if (offx + column	>= rSCREEN169.left	&& offx + column	<= rSCREEN169.right - 1 &&
							offy + line		>= rSCREEN169.top	&& offy + line		<= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += offx + column;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * (offy + line);
							pslocked32 += yoffset * (offy + line);

							//get line and column index of original array
							index_l = (int)((line + 1) / s_zoom + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > head_s)	index_l = head_s;
							index_c	= (int)((column + 1) / s_zoom + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > head_s)	index_c = head_s;

							//set pixel according to array
							if (head_a[index_l * head_s + index_c] == 1)
								*pslocked32 = pixelb32;
							if (head_a[index_l * head_s + index_c] == 2)
								*pslocked32 = pixelf32;
							if (head_a[index_l * head_s + index_c] == 3)
								*pslocked32 = pixel_fa32;
//!!
/*							//set pixel according to array
							if (head_a[line * head_s + column] == 1)
								*pslocked32 = pixelb32;
							if (head_a[line * head_s + column] == 2)
								*pslocked32 = pixelf32;
							if (head_a[line * head_s + column] == 3)
								*pslocked32 = pixel_fa32;*/
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}
		}
		else
		//if shadow (which means shadow option is on)
		{
			//if bone has fist draw it
			if (pd->pzb[b - 38]->type == 1)
			{
				//shadows are dark gray
				pixelf32 = DWORD(p_rLUT[30] | p_gLUT[30] | p_bLUT[30]);

				//size of fist
				int fist_s		= 12;
				//assign zoomfactor and round .5 up
				int fist_sz			= (int)(fist_s * s_zoom + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//shadow points
				int	sx = 0, sy = 0;

				//get fist_array offset from hitbox
				int offx = pd->pzb[b - 38]->hitbox_e.left;
				int offy = pd->pzb[b - 38]->hitbox_e.top;

				//draw fist array
				for (register int line = 0; line < fist_sz; ++line)
					for (register int column = 0; column < fist_sz; ++column)
					{
						//scale shadow point
						if (offy + line <= *pd->p_s_mpy)
							sy = (int)(*pd->p_s_mpy + (*pd->p_s_mpy - (offy + line)) * pd->p_s_scale->y);
						else
							sy = offy + line;
						sx = (int)((offx + column) + pd->p_s_scale->x * (float)(fabs((offy + line) - sy)));
			
						//clipping
						if (sx >= rSCREEN169.left	&& sx <= rSCREEN169.right - 1 &&
							sy >= rSCREEN169.top	&& sy <= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += sx;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * sy;
							pslocked32 += yoffset * sy;

							//get line and column index of original array
							index_l = (int)((line + 1) / s_zoom + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > fist_s)	index_l = fist_s;
							index_c	= (int)((column + 1) / s_zoom + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > fist_s)	index_c = fist_s;

							//set pixel according to array
							if (fist_a[index_l * fist_s + index_c] != 0)
								*pslocked32 = pixelf32;

							//!!
							//set pixel according to array
							//if (fist_a[line * fist_s + column] != 0)
							//	*pslocked32 = pixelf32;
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}

			//if bone has head draw it
			if (pd->pzb[b - 38]->type == 3)
			{
				//shadows are dark gray
				pixelf32 = DWORD(p_rLUT[30] | p_gLUT[30] | p_bLUT[30]);

				//size of head
				int head_s		= 26;
				//assign zoomfactor and round .5 up
				int head_sz		= (int)(head_s * s_zoom + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//shadow points
				int	sx = 0, sy = 0;

				//get head_array offset from hitbox
				int offx = pd->pzb[b - 38]->hitbox_e.left;
				int offy = pd->pzb[b - 38]->hitbox_e.top;

				//draw head array
				for (register int line = 0; line < head_sz; ++line)
					for (register int column = 0; column < head_sz; ++column)
					{
						//scale shadow point
						if (offy + line <= *pd->p_s_mpy)
							sy = (int)(*pd->p_s_mpy + (*pd->p_s_mpy - (offy + line)) * pd->p_s_scale->y);
						else
							sy = offy + line;
						sx = (int)((offx + column) + pd->p_s_scale->x * (float)(fabs((offy + line) - sy)));
			
						//clipping
						if (sx >= rSCREEN169.left	&& sx <= rSCREEN169.right - 1 &&
							sy >= rSCREEN169.top	&& sy <= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += sx;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * sy;
							pslocked32 += yoffset * sy;

							//get line and column index of original array
							index_l = (int)((line + 1) / s_zoom + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > head_s)	index_l = head_s;
							index_c	= (int)((column + 1) / s_zoom + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > head_s)	index_c = head_s;

							//set pixel according to array
							if (head_f[index_l * head_s + index_c] != 0)
								*pslocked32 = pixelf32;

							//!!
							//set pixel according to array
							//if (head_f[line * head_s + column] != 0)
							//	*pslocked32 = pixelf32;
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}
		}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawscene
//
//	draws whole scene in one lock
//	including both players with or without shadows in correct z-order and color mode (blackwhite)
//	winning points and names for both players
//	and blood particle arrays if active (same z-order as head)
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawscene_32(player_data *pd,
							  int mode_lutf,
							  int mode_lutd,
							  RGBcolor boneborder,
							  int bias_r,
							  int bias_g,
							  int bias_b)
{
	//---- dd setup ------------------------------------------------------------------------------

	//lock surface
	if (!BBLock())
		return(false);

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- player names --------------------------------------------------------------------------

	//coordinates
	int		x = 0, y = 0;
	//size
	float	sizefactor = 0.35f;
	//border and fill color
	int bred, bgreen, bblue;
	int fred, fgreen, fblue;
	RGBcolor cbbot(BOTNAMEBORDER);
	RGBcolor cfbot(BOTNAMEFILL);
	RGBcolor cbhum(PLAYERNAMEBORDER);
	RGBcolor cfhum(PLAYERNAMEFILL);
	//black white mode
	if (p_option->data.bw_mode)
	{
		cbbot.setcolor(BOTNAMEBORDERBW);
		cfbot.setcolor(BOTNAMEFILLBW);
		cbhum.setcolor(PLAYERNAMEBORDERBW);
		cfhum.setcolor(PLAYERNAMEFILLBW);
	}

	//message string buffer
	//unsigned, else you get negative values for the LUT
	unsigned char DWORDstring[101] = "";

	//for both names
	for (register int p = 0; p < 2; ++p)
	{
		//different name color if player is bot
		if (*pd->p_bot[p] == true)
		{
			bred	= cbbot.r,		bgreen	= cbbot.g,			bblue	= cbbot.b;
			fred	= cfbot.r;		fgreen	= cfbot.g;			fblue	= cfbot.b;
		}
		else
		//is not bot
		{
			bred	= cbhum.r,		bgreen	= cbhum.g,			bblue	= cbhum.b;
			fred	= cfhum.r;		fgreen	= cfhum.g;			fblue	= cfhum.b;
		}

		//copy string into DWORDstring until null terminated
		for (register int i = 0; i < 101; ++i)
		{
			DWORDstring[i] = p_option->data.name[p][i];
			if (p_option->data.name[p][i] == 0)
				i = 101;
		}

		//calculate x and y coordinates
		if (p == P1)
			x	= (int)(0 + (399 - 0) / 2.0 -
				  (strlen(p_option->data.name[p]) * 32.0f * sizefactor + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * sizefactor) / 2.0f);
		else
			x	= (int)(400 + (799 - 400) / 2.0 -
				  (strlen(p_option->data.name[p]) * 32.0f * sizefactor + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * sizefactor) / 2.0f);
		y	= 29;

		//---- scanline font ---------------------------------------------------------------------

		//frame for each letter to draw
		//starts at x/y and is increased after each letter by
		//32 + 3 times sizefactor
		RECT tempdest;
		tempdest.left = x;	tempdest.top = y;

		//for every letter while not null (end of string)
		for (i = 0; i < 101 && DWORDstring[i] != 0; ++i)
		{
			//for every part of the letter up to six (if not used, indicated by -1 values)
			for (register int r = 0; r < 6 && p_cfontsl_LUT[DWORDstring[i]][r].left != -1; ++r)
			{
				//convert RECT of scanline font LUT into rectangle object (to draw it
				//via drawrectangle)
				rectangle		re;

				re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
				re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
				re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
				re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
				re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
				re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;
				re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
				re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;

				//clip rectangle to draw
				re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
				re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
				re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
				re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

				re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
				re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
				re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
				re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

				re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
				re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
				re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
				re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

				re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
				re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
				re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
				re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

				//---- setup values --------------------------------------------------------------------------

				//set colors
				DWORD pixelb32, pixelf32;

				if (bred != -1)
				{
					pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
					pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
				}
				else
				{
					//if unfilled letters, use fill color as border color
					pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
					//pixelf = DWORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
				}

				//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
				//edge_state: 0 == uninitialized, 1 == in use, 2 == done
				//converted to int
				float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

				//for all 4 edges
				for (register int i = 0; i < 4; ++i)
				{
					//if y1 <= y2
					if (edge[i][1] <= edge[i][3])
					{
						//y_min is y1
						edge[i][4] = edge[i][1];
						//y_max is y2
						edge[i][5] = edge[i][3];
						//x_y_min is x-intersection is x1
						edge[i][7] = edge[i][9] = edge[i][0];
					}
					else
					{
						//else vice versa
						edge[i][4] = edge[i][3];
						edge[i][5] = edge[i][1];
						edge[i][7] = edge[i][9] = edge[i][2];
					}

					//assign x_min
					//if x1 <= x2
					if (edge[i][0] <= edge[i][2])
						//x_min is x1
						edge[i][6] = edge[i][0];
					else
						//else x_min is x2
						edge[i][6] = edge[i][2];

					//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
					//note that values are not absolutes because slope has to be positive and negative
					float dx = edge[i][0] - edge[i][2];
					float dy = edge[i][1] - edge[i][3];

					//if both dx and dy is zero, which means edge has no length
					//set slope to zero so its not used in drawing the polygon
					if (dx == 0 && dy == 0)
						edge[i][8] = 0;
					else
						//if only dx is zero, wehich means infinite slope (straight vertical line)
						//set slope to 1000
						if (dx == 0)
							edge[i][8] = 1000;
						//else slope is dy / dx
						else
							edge[i][8] = dy / dx;
				}

				//if not unfilled scanline
				if (bred != -1)
				{
					//---- scanline algorithm --------------------------------------------------------------------

					//---- bubble sort edges by y_min, x_min -----------------------------------------------------

					//temporary edge needed for swapping process
					float temp_edge[11];

					//for maximal 3 loops (since 4 variable need not more loops to be sorted)
					for (i = 0; i < 3; ++i)
					{
						//check for swapping edge 1 and 2
						//if y_min 2nd edge < y_min 1st edge
						if (edge[1][4] < edge[0][4])
							//swap all elements of the two edges
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
							}
						else
							//if y_min 2nd edge == y_min 1st edge, sort by x_min
							if (edge[1][4] == edge[0][4])
								//if x_min 2nd edge < x_min 1st edge
								if (edge[1][6] < edge[0][6])
								{
									//swap all elements of the two edges
									for (int s = 0; s < 11; s++)
									{
										temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
									}
								}
						//otherwise just let the edges as they are

						//check for swapping edge 2 and 3
						if (edge[2][4] < edge[1][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
							}
						else
							if (edge[2][4] == edge[1][4])
								if (edge[2][6] < edge[1][6])
								{
									for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
									}
								}

						//check for swapping edge 3 and 4
						if (edge[3][4] < edge[2][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
							}
						else
							if (edge[3][4] == edge[2][4])
								if (edge[3][6] < edge[2][6])
								{
									for (register int s = 0; s < 11; ++s)
										{
											temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
										}
								}
					}

					//---- assign scanline -----------------------------------------------------------------------

					//start scanline at y_min of first edge
					int scanline = (int)edge[0][4];

					//---- activate first edge -------------------------------------------------------------------

					//for every edge
					for (register int e = 0; e < 4; ++e)
					{
						//if slope is zero (horizontal edge)
						if (edge[e][8] == 0)
							//set edge_state to "done"
							edge[e][10] = 2;

						//if edge not "done"
						if (edge[e][10] != 2)
							//activate edge if y_min is scanline
							//(always 2 edges activated at the same time)
							if (edge[e][4] == scanline)
								edge[e][10] = 1;
					}

					//---- drawing -------------------------------------------------------------------------------

					//indicates if there are edges left to draw
					int EDGES = 1;
					//ptd[0] is x-intersection of first active edge,
					//ptd[1] is x-intersection of second active edge,
					//while ptd[2] is used for swapping both values
					int ptd[3] = {0};
					//index of ptd
					int ptd_i = 0;

					while (EDGES)
					{
						//reset pdi index so first active edge is assigned to ptd[0]
						ptd_i = 0;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
							{
								//ptd[ptd_i] is x-intersection
								ptd[ptd_i] = (int)edge[e][9];

								//increase ptd_i so second active edge
								//is assigned to ptd[1]
								++ptd_i;
							}
						}

						//swap first and second ptd using the third one
						//if second ptd is smaller than first ptd
						if (ptd[1] < ptd[0])
						{
							ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
						}

						//draw all pixels beginning at pdt[0] + 1 to pdt[1]
						//(x-intersections of scanline with both active edges)
						for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
						{
							//assign x-coordinate
							pslocked32 += fp;
							//assign y-coordinate
//							pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
							pslocked32 += yoffset * scanline;
							//set pixel
							*pslocked32 = pixelf32;
							//reset pixel pointer
							pslocked32 = psbackup32;
						}

					//---- reorder edges -------------------------------------------------------------------------

						//increase scanline
						++scanline;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
								//set edge state to "done" if y_max == scanline
								if (edge[e][5] == scanline)
									edge[e][10] = 2;
								else
									//check if slope is not infinite
									if (edge[e][8] != 1000)
										//increase x-intersection by (1 / slope)
										edge[e][9] += (1 / edge[e][8]);

								//if edge state not "done"
								if (edge[e][10] != 2)
									//if y_min == scanline
									if (edge[e][4] == scanline)
										//activate edge
										edge[e][10] = 1;
						}

						//leave while loop if every edge is done
						if (edge[0][10] == 2)
							if (edge[1][10] == 2)
								if (edge[2][10] == 2)
									if (edge[3][10] == 2)
										EDGES = 0;
					}
				}

				//---- bresenham line drawing ----------------------------------------------------------------

				//for every edge
				for (i = 0; i < 4; ++i)
				{
					int x = (int)edge[i][0],		y = (int)edge[i][1];
					int dx = abs((int)(edge[i][2] - edge[i][0]));
					int dy = abs((int)(edge[i][3] - edge[i][1]));

					int xinc1, xinc2, yinc1, yinc2;
					int denominator, numerator, numadd, numpixels, curpixel;

					if (edge[i][2] >= edge[i][0])
					{
						xinc1 = 1;	xinc2 = 1;
					}
					else
					{
						xinc1 = -1; xinc2 = -1;
					}

					if (edge[i][3] >= edge[i][1])
					{
						yinc1 = 1;	yinc2 = 1;
					}
					else
					{
						yinc1 = -1; yinc2 = -1;
					}

					if (dx >= dy)
					{
						xinc1 = 0;			yinc2 = 0;
						denominator = dx;	numerator = dx / 2;
						numadd = dy;		numpixels = dx;
					}
					else
					{
						xinc2 = 0;			yinc1 = 0;
						denominator = dy;	numerator = dy / 2;
						numadd = dx;		numpixels = dy;
					}

					for (curpixel = 0; curpixel <= numpixels; ++curpixel)
					{
						//assign x-coordinate
						pslocked32 += x;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * y;
						pslocked32 += yoffset * y;
						//set pixel
						*pslocked32 = pixelb32;
						//reset pixel pointer
						pslocked32 = psbackup32;

						numerator += numadd;
						if (numerator >= denominator)
						{
							numerator -= denominator;
							x += xinc1;		y += yinc1;
						}
						x += xinc2;		y += yinc2;
					}
				}
			}

			//increase frame
			tempdest.left += (long)((32 + 3) * sizefactor);
		}
	}

	//---- round time ----------------------------------------------------------------------------

	//if roundtime on
	if (p_option->data.roundtime)
	{
		//coordinates
		int		x = 0, y = 0;
		//size
		float	sizefactor = 0.45f;
		//border and fill color
		int		bred = 000, bgreen = 000, bblue = 000;
		int		fred, fgreen, fblue;

		//red for the last 5 seconds
		if (*pd->p_roundtime > 5)
		{
			fred = 255; fgreen = 255; fblue = 255;
		}
		else
		{
			fred = 255; fgreen = 0; fblue = 0;
		}

		//message string buffer
		//unsigned, else you get negative values for the LUT
		unsigned char DWORDstring[6] = "";

		//copy string into DWORDstring until null terminated
		for (register int i = 0; i < 6; ++i)
		{
			DWORDstring[i] = pd->p_rts[i];
		}

		//calculate x and y coordinates
		x	= (int)(rSCREEN169.left +
			  (rSCREEN169.right - rSCREEN169.left) / 2.0f -
			  (5 * 32.0f * sizefactor + (5 - 1.0f) * 3.0f * sizefactor) / 2.0f)
			  + 1;
		y	= (int)((75.0f / 2.0f) - (48.0f * sizefactor / 2.0f));

		//---- scanline font ---------------------------------------------------------------------
		//frame for each letter to draw
		//starts at x/y and is increased after each letter by
		//32 + 3 times sizefactor
		RECT tempdest;
		tempdest.left = x;	tempdest.top = y;

		//for every letter while not null (end of string)
		for (i = 0; i < 6 && DWORDstring[i] != 0; ++i)
		{
			//for every part of the letter up to six (if not used, indicated by -1 values)
			for (register int r = 0; r < 6 && p_cfontsl_LUT[DWORDstring[i]][r].left != -1; ++r)
			{
				//convert RECT of scanline font LUT into rectangle object (to draw it
				//via drawrectangle)
				rectangle		re;

				re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
				re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
				re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
				re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
				re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
				re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;
				re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
				re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;

				//clip rectangle to draw
				re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
				re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
				re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
				re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

				re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
				re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
				re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
				re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

				re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
				re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
				re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
				re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

				re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
				re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
				re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
				re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

				//---- setup values --------------------------------------------------------------------------

				//set colors
				DWORD pixelb32, pixelf32;

				if (bred != -1)
				{
					pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
					pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
				}
				else
				{
					//if unfilled letters, use fill color as border color
					pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
					//pixelf = DWORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
				}

				//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
				//edge_state: 0 == uninitialized, 1 == in use, 2 == done
				//converted to int
				float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

				//for all 4 edges
				for (register int i = 0; i < 4; ++i)
				{
					//if y1 <= y2
					if (edge[i][1] <= edge[i][3])
					{
						//y_min is y1
						edge[i][4] = edge[i][1];
						//y_max is y2
						edge[i][5] = edge[i][3];
						//x_y_min is x-intersection is x1
						edge[i][7] = edge[i][9] = edge[i][0];
					}
					else
					{
						//else vice versa
						edge[i][4] = edge[i][3];
						edge[i][5] = edge[i][1];
						edge[i][7] = edge[i][9] = edge[i][2];
					}

					//assign x_min
					//if x1 <= x2
					if (edge[i][0] <= edge[i][2])
						//x_min is x1
						edge[i][6] = edge[i][0];
					else
						//else x_min is x2
						edge[i][6] = edge[i][2];

					//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
					//note that values are not absolutes because slope has to be positive and negative
					float dx = edge[i][0] - edge[i][2];
					float dy = edge[i][1] - edge[i][3];

					//if both dx and dy is zero, which means edge has no length
					//set slope to zero so its not used in drawing the polygon
					if (dx == 0 && dy == 0)
						edge[i][8] = 0;
					else
						//if only dx is zero, wehich means infinite slope (straight vertical line)
						//set slope to 1000
						if (dx == 0)
							edge[i][8] = 1000;
						//else slope is dy / dx
						else
							edge[i][8] = dy / dx;
				}

				//if not unfilled scanline
				if (bred != -1)
				{
					//---- scanline algorithm --------------------------------------------------------------------

					//---- bubble sort edges by y_min, x_min -----------------------------------------------------

					//temporary edge needed for swapping process
					float temp_edge[11];

					//for maximal 3 loops (since 4 variable need not more loops to be sorted)
					for (i = 0; i < 3; ++i)
					{
						//check for swapping edge 1 and 2
						//if y_min 2nd edge < y_min 1st edge
						if (edge[1][4] < edge[0][4])
							//swap all elements of the two edges
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
							}
						else
							//if y_min 2nd edge == y_min 1st edge, sort by x_min
							if (edge[1][4] == edge[0][4])
								//if x_min 2nd edge < x_min 1st edge
								if (edge[1][6] < edge[0][6])
								{
									//swap all elements of the two edges
									for (int s = 0; s < 11; s++)
									{
										temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
									}
								}
						//otherwise just let the edges as they are

						//check for swapping edge 2 and 3
						if (edge[2][4] < edge[1][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
							}
						else
							if (edge[2][4] == edge[1][4])
								if (edge[2][6] < edge[1][6])
								{
									for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
									}
								}

						//check for swapping edge 3 and 4
						if (edge[3][4] < edge[2][4])
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
							}
						else
							if (edge[3][4] == edge[2][4])
								if (edge[3][6] < edge[2][6])
								{
									for (register int s = 0; s < 11; ++s)
										{
											temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
										}
								}
					}

					//---- assign scanline -----------------------------------------------------------------------

					//start scanline at y_min of first edge
					int scanline = (int)edge[0][4];

					//---- activate first edge -------------------------------------------------------------------

					//for every edge
					for (register int e = 0; e < 4; ++e)
					{
						//if slope is zero (horizontal edge)
						if (edge[e][8] == 0)
							//set edge_state to "done"
							edge[e][10] = 2;

						//if edge not "done"
						if (edge[e][10] != 2)
							//activate edge if y_min is scanline
							//(always 2 edges activated at the same time)
							if (edge[e][4] == scanline)
								edge[e][10] = 1;
					}

					//---- drawing -------------------------------------------------------------------------------

					//indicates if there are edges left to draw
					int EDGES = 1;
					//ptd[0] is x-intersection of first active edge,
					//ptd[1] is x-intersection of second active edge,
					//while ptd[2] is used for swapping both values
					int ptd[3] = {0};
					//index of ptd
					int ptd_i = 0;

					while (EDGES)
					{
						//reset pdi index so first active edge is assigned to ptd[0]
						ptd_i = 0;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
							{
								//ptd[ptd_i] is x-intersection
								ptd[ptd_i] = (int)edge[e][9];

								//increase ptd_i so second active edge
								//is assigned to ptd[1]
								++ptd_i;
							}
						}

						//swap first and second ptd using the third one
						//if second ptd is smaller than first ptd
						if (ptd[1] < ptd[0])
						{
							ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
						}

						//draw all pixels beginning at pdt[0] + 1 to pdt[1]
						//(x-intersections of scanline with both active edges)
						for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
						{
							//assign x-coordinate
							pslocked32 += fp;
							//assign y-coordinate
//							pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
							pslocked32 += yoffset * scanline;
							//set pixel
							*pslocked32 = pixelf32;
							//reset pixel pointer
							pslocked32 = psbackup32;
						}

					//---- reorder edges -------------------------------------------------------------------------

						//increase scanline
						++scanline;

						//for every edge
						for (e = 0; e < 4; ++e)
						{
							//if edge state is "in use"
							if (edge[e][10] == 1)
								//set edge state to "done" if y_max == scanline
								if (edge[e][5] == scanline)
									edge[e][10] = 2;
								else
									//check if slope is not infinite
									if (edge[e][8] != 1000)
										//increase x-intersection by (1 / slope)
										edge[e][9] += (1 / edge[e][8]);

								//if edge state not "done"
								if (edge[e][10] != 2)
									//if y_min == scanline
									if (edge[e][4] == scanline)
										//activate edge
										edge[e][10] = 1;
						}

						//leave while loop if every edge is done
						if (edge[0][10] == 2)
							if (edge[1][10] == 2)
								if (edge[2][10] == 2)
									if (edge[3][10] == 2)
										EDGES = 0;
					}
				}

				//---- bresenham line drawing ----------------------------------------------------------------

				//for every edge
				for (i = 0; i < 4; ++i)
				{
					int x = (int)edge[i][0],		y = (int)edge[i][1];
					int dx = abs((int)(edge[i][2] - edge[i][0]));
					int dy = abs((int)(edge[i][3] - edge[i][1]));

					int xinc1, xinc2, yinc1, yinc2;
					int denominator, numerator, numadd, numpixels, curpixel;

					if (edge[i][2] >= edge[i][0])
					{
						xinc1 = 1;	xinc2 = 1;
					}
					else
					{
						xinc1 = -1; xinc2 = -1;
					}

					if (edge[i][3] >= edge[i][1])
					{
						yinc1 = 1;	yinc2 = 1;
					}
					else
					{
						yinc1 = -1; yinc2 = -1;
					}

					if (dx >= dy)
					{
						xinc1 = 0;			yinc2 = 0;
						denominator = dx;	numerator = dx / 2;
						numadd = dy;		numpixels = dx;
					}
					else
					{
						xinc2 = 0;			yinc1 = 0;
						denominator = dy;	numerator = dy / 2;
						numadd = dx;		numpixels = dy;
					}

					for (curpixel = 0; curpixel <= numpixels; ++curpixel)
					{
						//assign x-coordinate
						pslocked32 += x;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * y;
						pslocked32 += yoffset * y;
						//set pixel
						*pslocked32 = pixelb32;
						//reset pixel pointer
						pslocked32 = psbackup32;

						numerator += numadd;
						if (numerator >= denominator)
						{
							numerator -= denominator;
							x += xinc1;		y += yinc1;
						}
						x += xinc2;		y += yinc2;
					}
				}
			}

			//increase frame
			tempdest.left += (long)((32 + 3) * sizefactor);
		}
	}

	//---- score ---------------------------------------------------------------------------------

	if (p_option->data.show_scores)
	{
		//offsets
		int x, y;
		//size
		float	sizefactor = 0.30f;
		//border and fill color
		int		bred = 000, bgreen = 000, bblue = 000;
		int		fred = 255, fgreen = 255, fblue = 255;

		//message string buffer
		//unsigned, else you get negative values for the LUT
		unsigned char DWORDstring[101] = "";

		//for both players score
		for (register int p = 0; p < 2; ++p)
		{
			//copy scores into DWORDstring
			_itoa((int)*pd->p_score[p], (char*)DWORDstring, 10);

			//fill score with 0 on left side
			int digits			= 4;
			int length			= strlen((char*)DWORDstring) - 1;
			bool score_signed	= false;

			//if score negative and length of string is smaller than number of digits
			//delete sign and apply later at first digit
			if (*pd->p_score[p] < 0 && length < digits - 1)
			{
				DWORDstring[0] = '0';
				score_signed = true;
			}

			//align score on right side of string
			for (register int f = digits - 1, d = length; d >= 0 && length < digits - 1; --f, --d)
			{
				DWORDstring[f]		= DWORDstring[d];
				DWORDstring[d]		= '0';
			}

			//fill left side with 0 and null terminate string
			if (length < digits - 1)
			{
				for (f = digits - 1 - (length + 1); f >= 0; --f)
					DWORDstring[f] = '0';

				DWORDstring[digits] = 0;
			}
			//apply sign
			if (score_signed)
				DWORDstring[0] = '-';

			//calculate x and y coordinates
			if (p == P1)
				x	= (int)(0 + (399 - 0) / 2.0 -
					  (strlen(p_option->data.name[p]) * 32.0f * 0.35f + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * 0.35f) / 2.0f);
			else
				x	= (int)(400 + (799 - 400) / 2.0 -
					  (strlen(p_option->data.name[p]) * 32.0f * 0.35f + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * 0.35f) / 2.0f);
			y	= 54;

			//---- scanline font ---------------------------------------------------------------------

			//frame for each letter to draw
			//starts at x/y and is increased after each letter by
			//32 + 3 times sizefactor
			RECT tempdest;
			tempdest.left = x;	tempdest.top = y;

			//for every letter while not null (end of string)
			for (register int i = 0; i < 101 && DWORDstring[i] != 0; ++i)
			{
				//for every part of the letter up to six (if not used, indicated by -1 values)
				for (register int r = 0; r < 6 && p_cfontsl_LUT[DWORDstring[i]][r].left != -1; ++r)
				{
					//convert RECT of scanline font LUT into rectangle object (to draw it
					//via drawrectangle)
					rectangle		re;

					re.p[0].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
					re.p[0].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
					re.p[1].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
					re.p[1].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].top * sizefactor;
					re.p[2].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].right * sizefactor;
					re.p[2].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;
					re.p[3].x = tempdest.left + (float)p_cfontsl_LUT[DWORDstring[i]][r].left * sizefactor;
					re.p[3].y = tempdest.top + (float)p_cfontsl_LUT[DWORDstring[i]][r].bottom * sizefactor;

					//clip rectangle to draw
					re.p[0].x < rSCREEN.left		? re.p[0].x = (float)rSCREEN.left		: re.p[0].x;
					re.p[0].x > rSCREEN.right - 1	? re.p[0].x = (float)rSCREEN.right - 1	: re.p[0].x;
					re.p[0].y < rSCREEN.top			? re.p[0].y = (float)rSCREEN.top		: re.p[0].y;
					re.p[0].y > rSCREEN.bottom - 1	? re.p[0].y = (float)rSCREEN.bottom - 1	: re.p[0].y;

					re.p[1].x < rSCREEN.left		? re.p[1].x = (float)rSCREEN.left		: re.p[1].x;
					re.p[1].x > rSCREEN.right - 1	? re.p[1].x = (float)rSCREEN.right - 1	: re.p[1].x;
					re.p[1].y < rSCREEN.top			? re.p[1].y = (float)rSCREEN.top		: re.p[1].y;
					re.p[1].y > rSCREEN.bottom - 1	? re.p[1].y = (float)rSCREEN.bottom - 1	: re.p[1].y;

					re.p[2].x < rSCREEN.left		? re.p[2].x = (float)rSCREEN.left		: re.p[2].x;
					re.p[2].x > rSCREEN.right - 1	? re.p[2].x = (float)rSCREEN.right - 1	: re.p[2].x;
					re.p[2].y < rSCREEN.top			? re.p[2].y = (float)rSCREEN.top		: re.p[2].y;
					re.p[2].y > rSCREEN.bottom - 1	? re.p[2].y = (float)rSCREEN.bottom - 1	: re.p[2].y;

					re.p[3].x < rSCREEN.left		? re.p[3].x = (float)rSCREEN.left		: re.p[3].x;
					re.p[3].x > rSCREEN.right - 1	? re.p[3].x = (float)rSCREEN.right - 1	: re.p[3].x;
					re.p[3].y < rSCREEN.top			? re.p[3].y = (float)rSCREEN.top		: re.p[3].y;
					re.p[3].y > rSCREEN.bottom - 1	? re.p[3].y = (float)rSCREEN.bottom - 1	: re.p[3].y;

					//---- setup values --------------------------------------------------------------------------

					//set colors
					DWORD pixelb32, pixelf32;

					if (bred != -1)
					{
						pixelb32 = DWORD(p_rLUT[bred] | p_gLUT[bgreen] | p_bLUT[bblue]);
						pixelf32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
					}
					else
					{
						//if unfilled letters, use fill color as border color
						pixelb32 = DWORD(p_rLUT[fred] | p_gLUT[fgreen] | p_bLUT[fblue]);
						//pixelf = DWORD(p_rLUT[cf.r] | p_gLUT[cf.g] | p_bLUT[cf.b]);
					}

					//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
					//edge_state: 0 == uninitialized, 1 == in use, 2 == done
					//converted to int
					float edge[4][11] = {(float)(int)re.p[0].x, (float)(int)re.p[0].y, (float)(int)re.p[1].x, (float)(int)re.p[1].y, 0, 0, 0, 0, 0, 0, 0,
										 (float)(int)re.p[1].x, (float)(int)re.p[1].y, (float)(int)re.p[2].x, (float)(int)re.p[2].y, 0, 0, 0, 0, 0, 0, 0,
										 (float)(int)re.p[2].x, (float)(int)re.p[2].y, (float)(int)re.p[3].x, (float)(int)re.p[3].y, 0, 0, 0, 0, 0, 0, 0,
										 (float)(int)re.p[3].x, (float)(int)re.p[3].y, (float)(int)re.p[0].x, (float)(int)re.p[0].y, 0, 0, 0, 0, 0, 0, 0};

					//for all 4 edges
					for (register int i = 0; i < 4; ++i)
					{
						//if y1 <= y2
						if (edge[i][1] <= edge[i][3])
						{
							//y_min is y1
							edge[i][4] = edge[i][1];
							//y_max is y2
							edge[i][5] = edge[i][3];
							//x_y_min is x-intersection is x1
							edge[i][7] = edge[i][9] = edge[i][0];
						}
						else
						{
							//else vice versa
							edge[i][4] = edge[i][3];
							edge[i][5] = edge[i][1];
							edge[i][7] = edge[i][9] = edge[i][2];
						}

						//assign x_min
						//if x1 <= x2
						if (edge[i][0] <= edge[i][2])
							//x_min is x1
							edge[i][6] = edge[i][0];
						else
							//else x_min is x2
							edge[i][6] = edge[i][2];

						//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
						//note that values are not absolutes because slope has to be positive and negative
						float dx = edge[i][0] - edge[i][2];
						float dy = edge[i][1] - edge[i][3];

						//if both dx and dy is zero, which means edge has no length
						//set slope to zero so its not used in drawing the polygon
						if (dx == 0 && dy == 0)
							edge[i][8] = 0;
						else
							//if only dx is zero, wehich means infinite slope (straight vertical line)
							//set slope to 1000
							if (dx == 0)
								edge[i][8] = 1000;
							//else slope is dy / dx
							else
								edge[i][8] = dy / dx;
					}

					//if not unfilled scanline
					if (bred != -1)
					{
						//---- scanline algorithm --------------------------------------------------------------------

						//---- bubble sort edges by y_min, x_min -----------------------------------------------------

						//temporary edge needed for swapping process
						float temp_edge[11];

						//for maximal 3 loops (since 4 variable need not more loops to be sorted)
						for (i = 0; i < 3; ++i)
						{
							//check for swapping edge 1 and 2
							//if y_min 2nd edge < y_min 1st edge
							if (edge[1][4] < edge[0][4])
								//swap all elements of the two edges
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
								}
							else
								//if y_min 2nd edge == y_min 1st edge, sort by x_min
								if (edge[1][4] == edge[0][4])
									//if x_min 2nd edge < x_min 1st edge
									if (edge[1][6] < edge[0][6])
									{
										//swap all elements of the two edges
										for (int s = 0; s < 11; s++)
										{
											temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
										}
									}
							//otherwise just let the edges as they are

							//check for swapping edge 2 and 3
							if (edge[2][4] < edge[1][4])
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
								}
							else
								if (edge[2][4] == edge[1][4])
									if (edge[2][6] < edge[1][6])
									{
										for (register int s = 0; s < 11; ++s)
										{
											temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
										}
									}

							//check for swapping edge 3 and 4
							if (edge[3][4] < edge[2][4])
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
								}
							else
								if (edge[3][4] == edge[2][4])
									if (edge[3][6] < edge[2][6])
									{
										for (register int s = 0; s < 11; ++s)
											{
												temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
											}
									}
						}

						//---- assign scanline -----------------------------------------------------------------------

						//start scanline at y_min of first edge
						int scanline = (int)edge[0][4];

						//---- activate first edge -------------------------------------------------------------------

						//for every edge
						for (register int e = 0; e < 4; ++e)
						{
							//if slope is zero (horizontal edge)
							if (edge[e][8] == 0)
								//set edge_state to "done"
								edge[e][10] = 2;

							//if edge not "done"
							if (edge[e][10] != 2)
								//activate edge if y_min is scanline
								//(always 2 edges activated at the same time)
								if (edge[e][4] == scanline)
									edge[e][10] = 1;
						}

						//---- drawing -------------------------------------------------------------------------------

						//indicates if there are edges left to draw
						int EDGES = 1;
						//ptd[0] is x-intersection of first active edge,
						//ptd[1] is x-intersection of second active edge,
						//while ptd[2] is used for swapping both values
						int ptd[3] = {0};
						//index of ptd
						int ptd_i = 0;

						while (EDGES)
						{
							//reset pdi index so first active edge is assigned to ptd[0]
							ptd_i = 0;

							//for every edge
							for (e = 0; e < 4; ++e)
							{
								//if edge state is "in use"
								if (edge[e][10] == 1)
								{
									//ptd[ptd_i] is x-intersection
									ptd[ptd_i] = (int)edge[e][9];

									//increase ptd_i so second active edge
									//is assigned to ptd[1]
									++ptd_i;
								}
							}

							//swap first and second ptd using the third one
							//if second ptd is smaller than first ptd
							if (ptd[1] < ptd[0])
							{
								ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
							}

							//draw all pixels beginning at pdt[0] + 1 to pdt[1]
							//(x-intersections of scanline with both active edges)
							for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
							{
								//assign x-coordinate
								pslocked32 += fp;
								//assign y-coordinate
//								pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
								pslocked32 += yoffset * scanline;
								//set pixel
								*pslocked32 = pixelf32;
								//reset pixel pointer
								pslocked32 = psbackup32;
							}

						//---- reorder edges -------------------------------------------------------------------------

							//increase scanline
							++scanline;

							//for every edge
							for (e = 0; e < 4; ++e)
							{
								//if edge state is "in use"
								if (edge[e][10] == 1)
									//set edge state to "done" if y_max == scanline
									if (edge[e][5] == scanline)
										edge[e][10] = 2;
									else
										//check if slope is not infinite
										if (edge[e][8] != 1000)
											//increase x-intersection by (1 / slope)
											edge[e][9] += (1 / edge[e][8]);

									//if edge state not "done"
									if (edge[e][10] != 2)
										//if y_min == scanline
										if (edge[e][4] == scanline)
											//activate edge
											edge[e][10] = 1;
							}

							//leave while loop if every edge is done
							if (edge[0][10] == 2)
								if (edge[1][10] == 2)
									if (edge[2][10] == 2)
										if (edge[3][10] == 2)
											EDGES = 0;
						}
					}

					//---- bresenham line drawing ----------------------------------------------------------------

					//for every edge
					for (i = 0; i < 4; ++i)
					{
						int x = (int)edge[i][0],		y = (int)edge[i][1];
						int dx = abs((int)(edge[i][2] - edge[i][0]));
						int dy = abs((int)(edge[i][3] - edge[i][1]));

						int xinc1, xinc2, yinc1, yinc2;
						int denominator, numerator, numadd, numpixels, curpixel;

						if (edge[i][2] >= edge[i][0])
						{
							xinc1 = 1;	xinc2 = 1;
						}
						else
						{
							xinc1 = -1; xinc2 = -1;
						}

						if (edge[i][3] >= edge[i][1])
						{
							yinc1 = 1;	yinc2 = 1;
						}
						else
						{
							yinc1 = -1; yinc2 = -1;
						}

						if (dx >= dy)
						{
							xinc1 = 0;			yinc2 = 0;
							denominator = dx;	numerator = dx / 2;
							numadd = dy;		numpixels = dx;
						}
						else
						{
							xinc2 = 0;			yinc1 = 0;
							denominator = dy;	numerator = dy / 2;
							numadd = dx;		numpixels = dy;
						}

						for (curpixel = 0; curpixel <= numpixels; ++curpixel)
						{
							//assign x-coordinate
							pslocked32 += x;
							//assign y-coordinate
//							pslocked32 += (ddspitch / sizeof(DWORD)) * y;
							pslocked32 += yoffset * y;
							//set pixel
							*pslocked32 = pixelb32;
							//reset pixel pointer
							pslocked32 = psbackup32;

							numerator += numadd;
							if (numerator >= denominator)
							{
								numerator -= denominator;
								x += xinc1;		y += yinc1;
							}
							x += xinc2;		y += yinc2;
						}
					}
				}

				//increase frame
				tempdest.left += (long)((32 + 3) * sizefactor);
			}
		}
	}

	//---- win points ----------------------------------------------------------------------------

	//icon dimensions, icon type, 0 = unfilled, 1 = filled, icon color
	RECT		icon;
	int			icon_t;
	RGBcolor	icon_c;

	//offsets
	int offx, offy;

	//starting x-offsets
	//(first time i used modulo)
	if (p_option->data.rounds % 2)	offx = 395 - (p_option->data.rounds / 2) * 20;
	else								offx = (int)((399 - (p_option->data.rounds / 2.0f) * 20.0f) + 6);

	//if round timer beneath timer else centered between names
	if (p_option->data.roundtime)	offy = 55;
	else								offy = 31;

	//!! halbe/halbe fuer draw?

	//for all rounds
	for (register int r = 0; r < p_option->data.rounds; ++r)
	{
		//color of icon
		//non black and white mode
		if (!p_option->data.bw_mode)
		{
			if (pd->p_winloss[r] == 0)
			{
				icon_t	= 0;
				icon_c.setcolor(white);
				fillRECT(icon, offx + r * 20 + 1, offy, offx + r * 20 + 7, offy + 12);
			}
			else
			{
				icon_t	= 1;

				if (pd->p_winloss[r] == 1)		icon_c = p_option->data.fistcolor[P1];
				if (pd->p_winloss[r] == 2)		icon_c = p_option->data.fistcolor[P2];
				if (pd->p_winloss[r] == 3)		icon_c.setcolor(lightgray);

				fillRECT(icon, offx + r * 20, offy, offx + r * 20 + 7, offy + 13);
			}
		}
		else
		//bw mode
		{
			if (pd->p_winloss[r] == 0)
			{
				icon_t	= 0;
				icon_c.setcolor(white);
				fillRECT(icon, offx + r * 20 + 1, offy, offx + r * 20 + 7, offy + 12);
			}
			else
			{
				icon_t	= 1;

				if (pd->p_winloss[r] == 1)		icon_c = p_option->data.fistcolor[P1];
				if (pd->p_winloss[r] == 2)		icon_c = p_option->data.fistcolor[P2];
				if (pd->p_winloss[r] == 3)		icon_c.setcolor(lightgray);

				fillRECT(icon, offx + r * 20, offy, offx + r * 20 + 7, offy + 13);
			}
		}

		//---- drawing ---------------------------------------------------------------------------

		//bresenham only
		if (icon_t == 0)
		{
			//---- setup ---------------------------------------------------------------------

			rectangle r = icon;

			//clip points
			rectclipper(r);

			//set pixel color
			DWORD pixel32 = DWORD(p_rLUT[icon_c.r] | p_gLUT[icon_c.g] | p_bLUT[icon_c.b]);

			//---- bresenham line drawing ----------------------------------------------------

			//dynamic allocated array of 4 pointers to arrays of 4 floats
			//containing rectangle data
			int (*pe)[4] = new int[4][4];

			pe[0][0] = (int)r.p[0].x;	pe[0][1] = (int)r.p[0].y;	pe[0][2] = (int)r.p[1].x;	pe[0][3] = (int)r.p[1].y;
			pe[1][0] = (int)r.p[1].x;	pe[1][1] = (int)r.p[1].y;	pe[1][2] = (int)r.p[2].x;	pe[1][3] = (int)r.p[2].y;
			pe[2][0] = (int)r.p[2].x;	pe[2][1] = (int)r.p[2].y;	pe[2][2] = (int)r.p[3].x;	pe[2][3] = (int)r.p[3].y;
			pe[3][0] = (int)r.p[3].x;	pe[3][1] = (int)r.p[3].y;	pe[3][2] = (int)r.p[0].x;	pe[3][3] = (int)r.p[0].y;

			//for every edge
			for (register int i = 0; i < 4; ++i)
			{
				int x = (int)pe[i][0],		y = (int)pe[i][1];
				int dx = abs((int)(pe[i][2] - pe[i][0]));
				int dy = abs((int)(pe[i][3] - pe[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (pe[i][2] >= pe[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (pe[i][3] >= pe[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += (int)x;
					//assign y-coordinate
//					pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixel32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}

			//delete allocated array
			delete [] pe;
		}
		else
		//scanline only
		{
			//---- setup ---------------------------------------------------------------------

			rectangle r = icon;

			//clip points
			rectclipper(r);

			//set pixel color
			DWORD pixel32 = DWORD(p_rLUT[icon_c.r] | p_gLUT[icon_c.g] | p_bLUT[icon_c.b]);

			//---- scanline algorithm --------------------------------------------------------

			//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
			//edge_state: 0 == uninitialized, 1 == in use, 2 == done
			//converted to int
			float edge[4][11] = {(float)(int)r.p[0].x, (float)(int)r.p[0].y, (float)(int)r.p[1].x, (float)(int)r.p[1].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)r.p[1].x, (float)(int)r.p[1].y, (float)(int)r.p[2].x, (float)(int)r.p[2].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)r.p[2].x, (float)(int)r.p[2].y, (float)(int)r.p[3].x, (float)(int)r.p[3].y, 0, 0, 0, 0, 0, 0, 0,
								 (float)(int)r.p[3].x, (float)(int)r.p[3].y, (float)(int)r.p[0].x, (float)(int)r.p[0].y, 0, 0, 0, 0, 0, 0, 0};

			//---- assign values for all edges -----------------------------------------------

			//for all 4 edges
			for (register int i = 0; i < 4; ++i)
			{
				//if y1 <= y2
				if (edge[i][1] <= edge[i][3])
				{
					//y_min is y1
					edge[i][4] = edge[i][1];
					//y_max is y2
					edge[i][5] = edge[i][3];
					//x_y_min is x-intersection is x1
					edge[i][7] = edge[i][9] = edge[i][0];
				}
				else
				{
					//else vice versa
					edge[i][4] = edge[i][3];
					edge[i][5] = edge[i][1];
					edge[i][7] = edge[i][9] = edge[i][2];
				}

				//assign x_min
				//if x1 <= x2
				if (edge[i][0] <= edge[i][2])
					//x_min is x1
					edge[i][6] = edge[i][0];
				else
					//else x_min is x2
					edge[i][6] = edge[i][2];

				//!!! bresenham int?
				//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
				//note that values are not absolutes because slope has to be positive and negative
				float dx = edge[i][0] - edge[i][2];
				float dy = edge[i][1] - edge[i][3];

				//if both dx and dy is zero, which means edge has no length
				//set slope to zero so its not used in drawing the polygon
				if (dx == 0 && dy == 0)
					edge[i][8] = 0;
				else
					//if only dx is zero, wehich means infinite slope (straight vertical line)
					//set slope to 1000
					if (dx == 0)
						edge[i][8] = 1000;
					//else slope is dy / dx
					else
						edge[i][8] = dy / dx;
			}

			//---- bubble sort edges by y_min, x_min -----------------------------------------

			//temporary edge needed for swapping process
			float temp_edge[11];

			//for maximal 3 loops (since 4 variable need not more loops to be sorted)
			for (i = 0; i < 3; ++i)
			{
				//check for swapping edge 1 and 2
				//if y_min 2nd edge < y_min 1st edge
				if (edge[1][4] < edge[0][4])
					//swap all elements of the two edges
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
					}
				else
					//if y_min 2nd edge == y_min 1st edge, sort by x_min
					if (edge[1][4] == edge[0][4])
						//if x_min 2nd edge < x_min 1st edge
						if (edge[1][6] < edge[0][6])
						{
							//swap all elements of the two edges
							for (int s = 0; s < 11; s++)
							{
								temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
							}
						}
				//otherwise just let the edges as they are

				//check for swapping edge 2 and 3
				if (edge[2][4] < edge[1][4])
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
					}
				else
					if (edge[2][4] == edge[1][4])
						if (edge[2][6] < edge[1][6])
						{
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
							}
						}

				//check for swapping edge 3 and 4
				if (edge[3][4] < edge[2][4])
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
					}
				else
					if (edge[3][4] == edge[2][4])
						if (edge[3][6] < edge[2][6])
						{
							for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
								}
						}
			}

			//---- assign scanline -----------------------------------------------------------

			//start scanline at y_min of first edge
			int scanline = (int)edge[0][4];

			//---- activate first edge -------------------------------------------------------

			//for every edge
			for (register int e = 0; e < 4; ++e)
			{
				//if slope is zero (horizontal edge)
				if (edge[e][8] == 0)
					//set edge_state to "done"
					edge[e][10] = 2;

				//if edge not "done"
				if (edge[e][10] != 2)
					//activate edge if y_min is scanline
					//(always 2 edges activated at the same time)
					if (edge[e][4] == scanline)
						edge[e][10] = 1;
			}

			//---- drawing -------------------------------------------------------------------

			//indicates if there are edges left to draw
			int EDGES = 1;
			//ptd[0] is x-intersection of first active edge,
			//ptd[1] is x-intersection of second active edge,
			//while ptd[2] is used for swapping both values
			int ptd[3] = {0};
			//index of ptd
			int ptd_i = 0;

			while (EDGES)
			{
				//reset pdi index so first active edge is assigned to ptd[0]
				ptd_i = 0;

				//for every edge
				for (e = 0; e < 4; ++e)
				{
					//if edge state is "in use"
					if (edge[e][10] == 1)
					{
						//ptd[ptd_i] is x-intersection
						ptd[ptd_i] = (int)edge[e][9];

						//increase ptd_i so second active edge
						//is assigned to ptd[1]
						++ptd_i;
					}
				}

				//swap first and second ptd using the third one
				//if second ptd is smaller than first ptd
				if (ptd[1] < ptd[0])
				{
					ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
				}

				//draw all pixels beginning at pdt[0] + 1 to pdt[1]
				//(x-intersections of scanline with both active edges)
				for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
				{
					//assign x-coordinate
					pslocked32 += fp;
					//assign y-coordinate
//					pslocked32 += (int)((ddspitch / sizeof(DWORD)) * scanline);
					pslocked32 += yoffset * scanline;
					//set pixel
					*pslocked32 = pixel32;
					//reset pixel pointer
					pslocked32 = psbackup32;
				}

			//---- reorder edges -------------------------------------------------------------

				//increase scanline
				++scanline;

				//for every edge
				for (e = 0; e < 4; ++e)
				{
					//if edge state is "in use"
					if (edge[e][10] == 1)
						//set edge state to "done" if y_max == scanline
						if (edge[e][5] == scanline)
							edge[e][10] = 2;
						else
							//check if slope is not infinite
							if (edge[e][8] != 1000)
								//increase x-intersection by (1 / slope)
								edge[e][9] += (1 / edge[e][8]);

						//if edge state not "done"
						if (edge[e][10] != 2)
							//if y_min == scanline
							if (edge[e][4] == scanline)
								//activate edge
								edge[e][10] = 1;
				}

				//leave while loop if every edge is done
				if (edge[0][10] == 2)
					if (edge[1][10] == 2)
						if (edge[2][10] == 2)
							if (edge[3][10] == 2)
								EDGES = 0;
			}
		}
	}

//!! old version
/*	//icon dimension, type and color
	RECT		icon;
	int			icon_t;
	RGBcolor	icon_c;

	//coordinates
	int	offx	= 0;

	//for number of rounds
	for (register int r = 0; r < p_option->data.rounds; ++r)
	{
		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//offset coordinate
			if (p == P1)
				offx	= (int)(0 + (399 - 0) / 2.0 -
						  (strlen(p_option->data.name[p]) * 32.0f * sizefactor + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * sizefactor ) / 2.0f);
			else
				offx	= (int)(400 + (799 - 400) / 2.0 -
						  (strlen(p_option->data.name[p]) * 32.0f * sizefactor + (strlen(p_option->data.name[p]) - 1.0f) * 3.0f * sizefactor ) / 2.0f);

			//slot empty
			if (pd->p_winloss[p][r] == 0)
			{
				fillRECT(icon, offx + 20 * r + 1, 54, offx + 7 + 20 * r, 66);
				icon_t	= 0;
				icon_c	= white;
			}
			//win
			if (pd->p_winloss[p][r] == 1)
			{
				fillRECT(icon, offx + 20 * r, 54, offx + 7 + 20 * r, 67);
				icon_t	= 1;
				if (p_option->data.bw_mode == 0)		icon_c	= green;
				else										icon_c	= white;
			}
			//loss
			if (pd->p_winloss[p][r] == -1)
			{
				fillRECT(icon, offx + 20 * r, 54, offx + 7 + 20 * r, 67);
				icon_t	= -1;
				if (p_option->data.bw_mode == 0)		icon_c	= red;
				else										icon_c	= darkgray;
			}

			//---- drawing -----------------------------------------------------------------------

			//bresenham only
			if (icon_t == 0)
			{
				//---- setup ---------------------------------------------------------------------

				rectangle r = icon;

				//clip points
				rectclipper(r);

				//set pixel color
				DWORD pixel = DWORD(p_rLUT[icon_c.r] | p_gLUT[icon_c.g] | p_bLUT[icon_c.b]);

				//---- bresenham line drawing ----------------------------------------------------

				//dynamic allocated array of 4 pointers to arrays of 4 floats
				//containing rectangle data
				int (*pe)[4] = new int[4][4];

				pe[0][0] = (int)r.p[0].x;	pe[0][1] = (int)r.p[0].y;	pe[0][2] = (int)r.p[1].x;	pe[0][3] = (int)r.p[1].y;
				pe[1][0] = (int)r.p[1].x;	pe[1][1] = (int)r.p[1].y;	pe[1][2] = (int)r.p[2].x;	pe[1][3] = (int)r.p[2].y;
				pe[2][0] = (int)r.p[2].x;	pe[2][1] = (int)r.p[2].y;	pe[2][2] = (int)r.p[3].x;	pe[2][3] = (int)r.p[3].y;
				pe[3][0] = (int)r.p[3].x;	pe[3][1] = (int)r.p[3].y;	pe[3][2] = (int)r.p[0].x;	pe[3][3] = (int)r.p[0].y;

				//for every edge
				for (register int i = 0; i < 4; ++i)
				{
					int x = (int)pe[i][0],		y = (int)pe[i][1];
					int dx = abs((int)(pe[i][2] - pe[i][0]));
					int dy = abs((int)(pe[i][3] - pe[i][1]));

					int xinc1, xinc2, yinc1, yinc2;
					int denominator, numerator, numadd, numpixels, curpixel;

					if (pe[i][2] >= pe[i][0])
					{
						xinc1 = 1;	xinc2 = 1;
					}
					else
					{
						xinc1 = -1; xinc2 = -1;
					}

					if (pe[i][3] >= pe[i][1])
					{
						yinc1 = 1;	yinc2 = 1;
					}
					else
					{
						yinc1 = -1; yinc2 = -1;
					}

					if (dx >= dy)
					{
						xinc1 = 0;			yinc2 = 0;
						denominator = dx;	numerator = dx / 2;
						numadd = dy;		numpixels = dx;
					}
					else
					{
						xinc2 = 0;			yinc1 = 0;
						denominator = dy;	numerator = dy / 2;
						numadd = dx;		numpixels = dy;
					}

					for (curpixel = 0; curpixel <= numpixels; ++curpixel)
					{
						//assign x-coordinate
						pslocked32 += (int)x;
						//assign y-coordinate
						pslocked32 += (int)((ddspitch / sizeof(short)) * y);
						//set pixel
						*pslocked32 = pixel;
						//reset pixel pointer
						pslocked32 = lpbackup;

						numerator += numadd;
						if (numerator >= denominator)
						{
							numerator -= denominator;
							x += xinc1;		y += yinc1;
						}
						x += xinc2;		y += yinc2;
					}
				}
			}
			else
			//scanline only
			{
				//---- setup ---------------------------------------------------------------------

				rectangle r = icon;

				//clip points
				rectclipper(r);

				//set pixel color
				DWORD pixel = DWORD(p_rLUT[icon_c.r] | p_gLUT[icon_c.g] | p_bLUT[icon_c.b]);

				//---- scanline algorithm --------------------------------------------------------

				//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
				//edge_state: 0 == uninitialized, 1 == in use, 2 == done
				//converted to int
				float edge[4][11] = {(float)(int)r.p[0].x, (float)(int)r.p[0].y, (float)(int)r.p[1].x, (float)(int)r.p[1].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)r.p[1].x, (float)(int)r.p[1].y, (float)(int)r.p[2].x, (float)(int)r.p[2].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)r.p[2].x, (float)(int)r.p[2].y, (float)(int)r.p[3].x, (float)(int)r.p[3].y, 0, 0, 0, 0, 0, 0, 0,
									 (float)(int)r.p[3].x, (float)(int)r.p[3].y, (float)(int)r.p[0].x, (float)(int)r.p[0].y, 0, 0, 0, 0, 0, 0, 0};

				//---- assign values for all edges -----------------------------------------------

				//for all 4 edges
				for (register int i = 0; i < 4; ++i)
				{
					//if y1 <= y2
					if (edge[i][1] <= edge[i][3])
					{
						//y_min is y1
						edge[i][4] = edge[i][1];
						//y_max is y2
						edge[i][5] = edge[i][3];
						//x_y_min is x-intersection is x1
						edge[i][7] = edge[i][9] = edge[i][0];
					}
					else
					{
						//else vice versa
						edge[i][4] = edge[i][3];
						edge[i][5] = edge[i][1];
						edge[i][7] = edge[i][9] = edge[i][2];
					}

					//assign x_min
					//if x1 <= x2
					if (edge[i][0] <= edge[i][2])
						//x_min is x1
						edge[i][6] = edge[i][0];
					else
						//else x_min is x2
						edge[i][6] = edge[i][2];

					//!!! bresenham int?
					//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
					//note that values are not absolutes because slope has to be positive and negative
					float dx = edge[i][0] - edge[i][2];
					float dy = edge[i][1] - edge[i][3];

					//if both dx and dy is zero, which means edge has no length
					//set slope to zero so its not used in drawing the polygon
					if (dx == 0 && dy == 0)
						edge[i][8] = 0;
					else
						//if only dx is zero, wehich means infinite slope (straight vertical line)
						//set slope to 1000
						if (dx == 0)
							edge[i][8] = 1000;
						//else slope is dy / dx
						else
							edge[i][8] = dy / dx;
				}

				//---- bubble sort edges by y_min, x_min -----------------------------------------

				//temporary edge needed for swapping process
				float temp_edge[11];

				//for maximal 3 loops (since 4 variable need not more loops to be sorted)
				for (i = 0; i < 3; ++i)
				{
					//check for swapping edge 1 and 2
					//if y_min 2nd edge < y_min 1st edge
					if (edge[1][4] < edge[0][4])
						//swap all elements of the two edges
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
						}
					else
						//if y_min 2nd edge == y_min 1st edge, sort by x_min
						if (edge[1][4] == edge[0][4])
							//if x_min 2nd edge < x_min 1st edge
							if (edge[1][6] < edge[0][6])
							{
								//swap all elements of the two edges
								for (int s = 0; s < 11; s++)
								{
									temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
								}
							}
					//otherwise just let the edges as they are

					//check for swapping edge 2 and 3
					if (edge[2][4] < edge[1][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
						}
					else
						if (edge[2][4] == edge[1][4])
							if (edge[2][6] < edge[1][6])
							{
								for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
								}
							}

					//check for swapping edge 3 and 4
					if (edge[3][4] < edge[2][4])
						for (register int s = 0; s < 11; ++s)
						{
							temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
						}
					else
						if (edge[3][4] == edge[2][4])
							if (edge[3][6] < edge[2][6])
							{
								for (register int s = 0; s < 11; ++s)
									{
										temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
									}
							}
				}

				//---- assign scanline -----------------------------------------------------------

				//start scanline at y_min of first edge
				int scanline = (int)edge[0][4];

				//---- activate first edge -------------------------------------------------------

				//for every edge
				for (register int e = 0; e < 4; ++e)
				{
					//if slope is zero (horizontal edge)
					if (edge[e][8] == 0)
						//set edge_state to "done"
						edge[e][10] = 2;

					//if edge not "done"
					if (edge[e][10] != 2)
						//activate edge if y_min is scanline
						//(always 2 edges activated at the same time)
						if (edge[e][4] == scanline)
							edge[e][10] = 1;
				}

				//---- drawing -------------------------------------------------------------------

				//indicates if there are edges left to draw
				int EDGES = 1;
				//ptd[0] is x-intersection of first active edge,
				//ptd[1] is x-intersection of second active edge,
				//while ptd[2] is used for swapping both values
				int ptd[3] = {0};
				//index of ptd
				int ptd_i = 0;

				while (EDGES)
				{
					//reset pdi index so first active edge is assigned to ptd[0]
					ptd_i = 0;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
						{
							//ptd[ptd_i] is x-intersection
							ptd[ptd_i] = (int)edge[e][9];

							//increase ptd_i so second active edge
							//is assigned to ptd[1]
							++ptd_i;
						}
					}

					//swap first and second ptd using the third one
					//if second ptd is smaller than first ptd
					if (ptd[1] < ptd[0])
					{
						ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
					}

					//draw all pixels beginning at pdt[0] + 1 to pdt[1]
					//(x-intersections of scanline with both active edges)
					for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
					{
						//assign x-coordinate
						pslocked32 += fp;
						//assign y-coordinate
						pslocked32 += (int)((ddspitch / sizeof(short)) * scanline);
						//set pixel
						*pslocked32 = pixel;
						//reset pixel pointer
						pslocked32 = lpbackup;
					}

				//---- reorder edges -------------------------------------------------------------

					//increase scanline
					++scanline;

					//for every edge
					for (e = 0; e < 4; ++e)
					{
						//if edge state is "in use"
						if (edge[e][10] == 1)
							//set edge state to "done" if y_max == scanline
							if (edge[e][5] == scanline)
								edge[e][10] = 2;
							else
								//check if slope is not infinite
								if (edge[e][8] != 1000)
									//increase x-intersection by (1 / slope)
									edge[e][9] += (1 / edge[e][8]);

							//if edge state not "done"
							if (edge[e][10] != 2)
								//if y_min == scanline
								if (edge[e][4] == scanline)
									//activate edge
									edge[e][10] = 1;
					}

					//leave while loop if every edge is done
					if (edge[0][10] == 2)
						if (edge[1][10] == 2)
							if (edge[2][10] == 2)
								if (edge[3][10] == 2)
									EDGES = 0;
				}
			}
		}
	}*/

	//---- hitboxes ------------------------------------------------------------------------------
	//have to be drawn before all other bones

	if (p_option->data.show_hitbox)
	{
		//color of hitboxes
		DWORD pixel32 = DWORD(p_rLUT[255] | p_gLUT[0] | p_bLUT[0]);

		//dynamic allocated array of 4 pointers to arrays of 4 int
		//containing rectangle data
		int (*pe)[4] = new int[4][4];

		//for all bones of both players
		//plus whole player hitboxes
		for (register int b = 0; b < 38 + 2; ++b)
		{
			//assign edges
			if (b < 38)
			{
				pe[0][0] = (int)pd->pzb[b]->hitbox.left;	pe[0][1] = (int)pd->pzb[b]->hitbox.top;
				pe[0][2] = (int)pd->pzb[b]->hitbox.right;	pe[0][3] = (int)pd->pzb[b]->hitbox.top;
				pe[1][0] = (int)pd->pzb[b]->hitbox.right;	pe[1][1] = (int)pd->pzb[b]->hitbox.top;
				pe[1][2] = (int)pd->pzb[b]->hitbox.right;	pe[1][3] = (int)pd->pzb[b]->hitbox.bottom;
				pe[2][0] = (int)pd->pzb[b]->hitbox.right;	pe[2][1] = (int)pd->pzb[b]->hitbox.bottom;
				pe[2][2] = (int)pd->pzb[b]->hitbox.left;	pe[2][3] = (int)pd->pzb[b]->hitbox.bottom;
				pe[3][0] = (int)pd->pzb[b]->hitbox.left;	pe[3][1] = (int)pd->pzb[b]->hitbox.bottom;
				pe[3][2] = (int)pd->pzb[b]->hitbox.left;	pe[3][3] = (int)pd->pzb[b]->hitbox.top;
			}
			else
			//whole player hitboxes
			{
				pe[0][0] = (int)pd->p_rbhp[39 - b]->left;	pe[0][1] = (int)pd->p_rbhp[39 - b]->top;
				pe[0][2] = (int)pd->p_rbhp[39 - b]->right;	pe[0][3] = (int)pd->p_rbhp[39 - b]->top;
				pe[1][0] = (int)pd->p_rbhp[39 - b]->right;	pe[1][1] = (int)pd->p_rbhp[39 - b]->top;
				pe[1][2] = (int)pd->p_rbhp[39 - b]->right;	pe[1][3] = (int)pd->p_rbhp[39 - b]->bottom;
				pe[2][0] = (int)pd->p_rbhp[39 - b]->right;	pe[2][1] = (int)pd->p_rbhp[39 - b]->bottom;
				pe[2][2] = (int)pd->p_rbhp[39 - b]->left;	pe[2][3] = (int)pd->p_rbhp[39 - b]->bottom;
				pe[3][0] = (int)pd->p_rbhp[39 - b]->left;	pe[3][1] = (int)pd->p_rbhp[39 - b]->bottom;
				pe[3][2] = (int)pd->p_rbhp[39 - b]->left;	pe[3][3] = (int)pd->p_rbhp[39 - b]->top;
			}

			//for each edge
			for (register int i = 0; i < 4; ++i)
			{
				int x = (int)pe[i][0],		y = (int)pe[i][1];
				int dx = abs((int)(pe[i][2] - pe[i][0]));
				int dy = abs((int)(pe[i][3] - pe[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (pe[i][2] >= pe[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (pe[i][3] >= pe[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += (int)x;
					//assign y-coordinate
//					pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixel32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}

			//head, fist hitbox
			if (pd->pzb[b]->type == 1 || pd->pzb[b]->type == 3)
			{
				//assign edges
				pe[0][0] = (int)pd->pzb[b]->hitbox_e.left;	pe[0][1] = (int)pd->pzb[b]->hitbox_e.top;
				pe[0][2] = (int)pd->pzb[b]->hitbox_e.right;	pe[0][3] = (int)pd->pzb[b]->hitbox_e.top;
				pe[1][0] = (int)pd->pzb[b]->hitbox_e.right;	pe[1][1] = (int)pd->pzb[b]->hitbox_e.top;
				pe[1][2] = (int)pd->pzb[b]->hitbox_e.right;	pe[1][3] = (int)pd->pzb[b]->hitbox_e.bottom;
				pe[2][0] = (int)pd->pzb[b]->hitbox_e.right;	pe[2][1] = (int)pd->pzb[b]->hitbox_e.bottom;
				pe[2][2] = (int)pd->pzb[b]->hitbox_e.left;	pe[2][3] = (int)pd->pzb[b]->hitbox_e.bottom;
				pe[3][0] = (int)pd->pzb[b]->hitbox_e.left;	pe[3][1] = (int)pd->pzb[b]->hitbox_e.bottom;
				pe[3][2] = (int)pd->pzb[b]->hitbox_e.left;	pe[3][3] = (int)pd->pzb[b]->hitbox_e.top;

				//for each edge
				for (register int i = 0; i < 4; ++i)
				{
					int x = (int)pe[i][0],		y = (int)pe[i][1];
					int dx = abs((int)(pe[i][2] - pe[i][0]));
					int dy = abs((int)(pe[i][3] - pe[i][1]));

					int xinc1, xinc2, yinc1, yinc2;
					int denominator, numerator, numadd, numpixels, curpixel;

					if (pe[i][2] >= pe[i][0])
					{
						xinc1 = 1;	xinc2 = 1;
					}
					else
					{
						xinc1 = -1; xinc2 = -1;
					}

					if (pe[i][3] >= pe[i][1])
					{
						yinc1 = 1;	yinc2 = 1;
					}
					else
					{
						yinc1 = -1; yinc2 = -1;
					}

					if (dx >= dy)
					{
						xinc1 = 0;			yinc2 = 0;
						denominator = dx;	numerator = dx / 2;
						numadd = dy;		numpixels = dx;
					}
					else
					{
						xinc2 = 0;			yinc1 = 0;
						denominator = dy;	numerator = dy / 2;
						numadd = dx;		numpixels = dy;
					}

					for (curpixel = 0; curpixel <= numpixels; ++curpixel)
					{
						//assign x-coordinate
						pslocked32 += (int)x;
						//assign y-coordinate
//						pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
						pslocked32 += yoffset * y;
						//set pixel
						*pslocked32 = pixel32;
						//reset pixel pointer
						pslocked32 = psbackup32;

						numerator += numadd;
						if (numerator >= denominator)
						{
							numerator -= denominator;
							x += xinc1;		y += yinc1;
						}
						x += xinc2;		y += yinc2;
					}
				}
			}
		}

		//delete allocated array
		delete [] pe;
	}

	//---- players, shadows and particles --------------------------------------------------------

	//whether colorbias is used or 
	bool colorbias;
	if (bias_r != 0 || bias_g != 0 || bias_b != 0)
		colorbias = true;
	else
		colorbias = false;

	//check color bias for validity
	if (colorbias)
	{
		bias_r	< 0	? bias_r	= 0	: bias_r > 255	? bias_r	= 255 : bias_r;
		bias_g	< 0	? bias_g	= 0	: bias_g > 255	? bias_g	= 255 : bias_g;
		bias_b	< 0	? bias_b	= 0	: bias_b > 255	? bias_b	= 255 : bias_b;
	}

	//bias color effect value (0.3 * red + 0.59 * green + 0.11 * blue)
	int cfx = 0;
	//color with applied bias if activated or standard color if not
	RGBcolor	bc(black);

	//bone border color
	//apply color bias if activated (see pixelfilter() for details)
	if (colorbias)
	{
		cfx		= (int)(0.3 * boneborder.r + 0.59 * boneborder.g + 0.11 * boneborder.b);
		bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
		bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
	}
	else
	{
		bc.r		= boneborder.r;
		bc.g		= boneborder.g;
		bc.b		= boneborder.b;
	}

	DWORD pixelb32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
	
	//bone fill color in dependence of bone damage
	DWORD pixelf32;

	//---- setup values --------------------------------------------------------------------------

	//number of bones
	int nob = 38;

	//if shadow option is off, number of bones is 38, else it's 76
	if (p_option->data.shadows == 1)		nob = 76;

	//for every bone starting with shadows
	for (register int b = nob - 1; b >= 0; --b)
	{
		//if not the shadow
		if (b < 38)
		{
			//assign appropriate color
			//if damage visible
			//or to show cd_state
			if (pd->pzb[b]->type != 2 ||
				p_option->data.cd_state)
			{
				//if no blackwhite mode use standard color table
				if (p_option->data.bw_mode == 0)
				{
					//condition masking off or only opponent and bone belongs not to host
					if (p_option->data.condition_masking == 0 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_greenredLUT[pd->pzb[b]->damage][0] + 0.59 * p_greenredLUT[pd->pzb[b]->damage][1] + 0.11 * p_greenredLUT[pd->pzb[b]->damage][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_greenredLUT[pd->pzb[b]->damage][0];
							bc.g	= p_greenredLUT[pd->pzb[b]->damage][1];
							bc.b	= p_greenredLUT[pd->pzb[b]->damage][2];
						}
					//condition masking both or only opponent and bone belongs to opponent
					if (p_option->data.condition_masking == 2 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_greenredLUT[0][0] + 0.59 * p_greenredLUT[0][1] + 0.11 * p_greenredLUT[0][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_greenredLUT[0][0];
							bc.g	= p_greenredLUT[0][1];
							bc.b	= p_greenredLUT[0][2];
						}

					//if bone hit select color depending on hit state
					if (pd->pzb[b]->hit_state == hs_hit)
						bc.setcolor(hsc_hit);
					if (pd->pzb[b]->hit_state == hs_hitred)
						bc.setcolor(hsc_hitred);
					if (pd->pzb[b]->hit_state == hs_hitdef)
						bc.setcolor(hsc_hitdef);
					if (pd->pzb[b]->hit_state == hs_hitret)
						bc.setcolor(hsc_hitret);
					if (pd->pzb[b]->hit_state == hs_stanceflash)
						bc.setcolor(hsc_stanceflash);
				}
				else
				{
					//condition masking off or only opponent and bone belongs not to host
					if (p_option->data.condition_masking == 0 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][0] + 0.59 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][1] + 0.11 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							//100 - damage because table is from black to white
							//while increasing damage is from white to black
							bc.r	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][0];
							bc.g	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][1];
							bc.b	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][2];
						}
					//condition masking both or only opponent and bone belongs to opponent
					if (p_option->data.condition_masking == 2 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_blackwhiteLUT[100][0] + 0.59 * p_blackwhiteLUT[100][1] + 0.11 * p_blackwhiteLUT[100][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							//100 - damage because table is from black to white
							//while increasing damage is from white to black
							bc.r	= p_blackwhiteLUT[100][0];
							bc.g	= p_blackwhiteLUT[100][1];
							bc.b	= p_blackwhiteLUT[100][2];
						}

					//if bone hit select color depending on hit state
					if (pd->pzb[b]->hit_state == hs_hit)
						bc.setcolor(hscbw_hit);
					if (pd->pzb[b]->hit_state == hs_hitred)
						bc.setcolor(hscbw_hitred);
					if (pd->pzb[b]->hit_state == hs_hitdef)
						bc.setcolor(hscbw_hitdef);
					if (pd->pzb[b]->hit_state == hs_hitret)
						bc.setcolor(hscbw_hitret);
					if (pd->pzb[b]->hit_state == hs_stanceflash)
						bc.setcolor(hscbw_stanceflash);
				}

				//draw states instead of damage if option on
				if (p_option->data.cd_state)
				{
					//no hit
					if (pd->pzb[b]->cd_state == cds_nohit)
						bc.setcolor(cdsc_nohit);
					//hitable
					if (pd->pzb[b]->cd_state == cds_hit)
						bc.setcolor(cdsc_hit);
					//defending
					if (pd->pzb[b]->cd_state == cds_def)
						bc.setcolor(cdsc_def);
					//hit return
					if (pd->pzb[b]->cd_state == cds_hitret)
						bc.setcolor(cdsc_hitret);
					//defending part
					if (pd->pzb[b]->cd_state == cds_defpart ||
						pd->pzb[b]->cd_state == cds_defpart_b)
						bc.setcolor(cdsc_defpart);
					if (pd->pzb[b]->cd_state == cds_defpart_e)
						bc.setcolor(cdsc_hit);
				}

				pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
			}
			else
			//if no damage visible
			{
				//if bone not hit color black with bias
				if (pd->pzb[b]->hit_state == hs_nohit)
				{
					//apply color bias if activated
					if (colorbias)
					{
						cfx		= 0;
						//(int)(0.3 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][0] + 0.59 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][1] + 0.11 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]);
						//bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
						bc.r	= bias_r;			bc.g		= bias_g; 		bc.b	= bias_b;
						bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
					}
					else
					{
						bc.r	= 0;
						bc.g	= 0;
						bc.b	= 0;
					}
				}
				else
				{
					//if bone hit select color depending on hit state
					if (p_option->data.bw_mode == 0)
					{
						if (pd->pzb[b]->hit_state == hs_hit)
							bc.setcolor(hsc_hit);
						if (pd->pzb[b]->hit_state == hs_hitred)
							bc.setcolor(hsc_hitred);
						if (pd->pzb[b]->hit_state == hs_hitdef)
							bc.setcolor(hsc_hitdef);
						if (pd->pzb[b]->hit_state == hs_hitret)
							bc.setcolor(hsc_hitret);
						if (pd->pzb[b]->hit_state == hs_stanceflash)
							bc.setcolor(hsc_stanceflash);
					}
					else
					{
						if (pd->pzb[b]->hit_state == hs_hit)
							bc.setcolor(hscbw_hit);
						if (pd->pzb[b]->hit_state == hs_hitred)
							bc.setcolor(hscbw_hitred);
						if (pd->pzb[b]->hit_state == hs_hitdef)
							bc.setcolor(hscbw_hitdef);
						if (pd->pzb[b]->hit_state == hs_hitret)
							bc.setcolor(hscbw_hitret);
						if (pd->pzb[b]->hit_state == hs_stanceflash)
							bc.setcolor(hscbw_stanceflash);
					}
				}

				pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
			}
		}
		else
		//shadow of bone
		{
			//apply color bias if activated
			if (colorbias)
			{
				cfx		= (int)(0.3 * 30 + 0.59 * 30 + 0.11 * 30);
				bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
				bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
			}
			else
			{
				bc.r	= 30;
				bc.g	= 30;
				bc.b	= 30;
			}

			pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
		}

		//change bone border color to fill color if in hollow-mode
		if (p_option->data.r_hollow)
		{
			pixelb32 = pixelf32;
		}

		//outside of if-statement cause else the rest of the function
		//doesn't know this array
		float edge[4][11] = {0};

		//if not the shadow
		if (b < 38)
		{
			//x1, y1, x2, y2, y_min, y_max, x_min, x_y_min, slope, x-intersection, edge_state
			//edge_state: 0 == uninitialized, 1 == in use, 2 == done
			//converted to int (and back to float to suppress converting warnings)
			edge[0][0] = (float)(int)pd->pzb[b]->v.p[0].x;
			edge[0][1] = (float)(int)pd->pzb[b]->v.p[0].y;
			edge[0][2] = (float)(int)pd->pzb[b]->v.p[1].x;
			edge[0][3] = (float)(int)pd->pzb[b]->v.p[1].y;

			edge[1][0] = (float)(int)pd->pzb[b]->v.p[1].x;
			edge[1][1] = (float)(int)pd->pzb[b]->v.p[1].y;
			edge[1][2] = (float)(int)pd->pzb[b]->v.p[2].x;
			edge[1][3] = (float)(int)pd->pzb[b]->v.p[2].y;

			edge[2][0] = (float)(int)pd->pzb[b]->v.p[2].x;
			edge[2][1] = (float)(int)pd->pzb[b]->v.p[2].y;
			edge[2][2] = (float)(int)pd->pzb[b]->v.p[3].x;
			edge[2][3] = (float)(int)pd->pzb[b]->v.p[3].y;

			edge[3][0] = (float)(int)pd->pzb[b]->v.p[3].x;
			edge[3][1] = (float)(int)pd->pzb[b]->v.p[3].y;
			edge[3][2] = (float)(int)pd->pzb[b]->v.p[0].x;
			edge[3][3] = (float)(int)pd->pzb[b]->v.p[0].y;
		}
		else
		{
			edge[0][0] = (float)(int)pd->pzb[b - 38]->vs.p[0].x;
			edge[0][1] = (float)(int)pd->pzb[b - 38]->vs.p[0].y;
			edge[0][2] = (float)(int)pd->pzb[b - 38]->vs.p[1].x;
			edge[0][3] = (float)(int)pd->pzb[b - 38]->vs.p[1].y;

			edge[1][0] = (float)(int)pd->pzb[b - 38]->vs.p[1].x;
			edge[1][1] = (float)(int)pd->pzb[b - 38]->vs.p[1].y;
			edge[1][2] = (float)(int)pd->pzb[b - 38]->vs.p[2].x;
			edge[1][3] = (float)(int)pd->pzb[b - 38]->vs.p[2].y;

			edge[2][0] = (float)(int)pd->pzb[b - 38]->vs.p[2].x;
			edge[2][1] = (float)(int)pd->pzb[b - 38]->vs.p[2].y;
			edge[2][2] = (float)(int)pd->pzb[b - 38]->vs.p[3].x;
			edge[2][3] = (float)(int)pd->pzb[b - 38]->vs.p[3].y;

			edge[3][0] = (float)(int)pd->pzb[b - 38]->vs.p[3].x;
			edge[3][1] = (float)(int)pd->pzb[b - 38]->vs.p[3].y;
			edge[3][2] = (float)(int)pd->pzb[b - 38]->vs.p[0].x;
			edge[3][3] = (float)(int)pd->pzb[b - 38]->vs.p[0].y;
		}

		//----------------------------------------------------------------------------------------

		 //for all 4 edges
		for (register int i = 0; i < 4; ++i)
		{
			//if y1 <= y2
			if (edge[i][1] <= edge[i][3])
			{
				//y_min is y1
				edge[i][4] = edge[i][1];
				//y_max is y2
				edge[i][5] = edge[i][3];
				//x_y_min is x-intersection is x1
				edge[i][7] = edge[i][9] = edge[i][0];
			}
			else
			{
				//else vice versa
				edge[i][4] = edge[i][3];
				edge[i][5] = edge[i][1];
				edge[i][7] = edge[i][9] = edge[i][2];
			}

			//assign x_min
			//if x1 <= x2
			if (edge[i][0] <= edge[i][2])
				//x_min is x1
				edge[i][6] = edge[i][0];
			else
				//else x_min is x2
				edge[i][6] = edge[i][2];

			//calculate slope of edges; dx = x2 - x1 and dy = y2 - y1
			//note that values are not absolutes because slope has to be positive and negative
			float dx = edge[i][0] - edge[i][2];
			float dy = edge[i][1] - edge[i][3];

			//if both dx and dy is zero, which means edge has no length
			//set slope to zero so its not used in drawing the polygon
			if (dx == 0 && dy == 0)
				edge[i][8] = 0;
			else
				//if only dx is zero, wehich means infinite slope (straight vertical line)
				//set slope to 1000
				if (dx == 0)
					edge[i][8] = 1000;
				//else slope is dy / dx
				else
					edge[i][8] = dy / dx;
		}

		//---- scanline algorithm ----------------------------------------------------------------

		//---- bubble sort edges by y_min, x_min -------------------------------------------------

		//if not hollow mode or bone is shadow
//		if (!p_option->data.r_hollow || b >= 38)
		if (!p_option->data.r_hollow)
		{
			//temporary edge needed for swapping process
			float temp_edge[11];

			//for maximal 3 loops (since 4 variable need not more loops to be sorted)
			for (i = 0; i < 3; ++i)
			{
				//check for swapping edge 1 and 2
				//if y_min 2nd edge < y_min 1st edge
				if (edge[1][4] < edge[0][4])
					//swap all elements of the two edges
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
					}
				else
					//if y_min 2nd edge == y_min 1st edge, sort by x_min
					if (edge[1][4] == edge[0][4])
						//if x_min 2nd edge < x_min 1st edge
						if (edge[1][6] < edge[0][6])
						{
							//swap all elements of the two edges
							for (int s = 0; s < 11; s++)
							{
								temp_edge[s] = edge[0][s]; edge[0][s] = edge[1][s]; edge[1][s] = temp_edge[s];
							}
						}
				//otherwise just let the edges as they are

				//check for swapping edge 2 and 3
				if (edge[2][4] < edge[1][4])
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
					}
				else
					if (edge[2][4] == edge[1][4])
						if (edge[2][6] < edge[1][6])
						{
							for (register int s = 0; s < 11; ++s)
							{
								temp_edge[s] = edge[1][s]; edge[1][s] = edge[2][s];	edge[2][s] = temp_edge[s];
							}
						}

				//check for swapping edge 3 and 4
				if (edge[3][4] < edge[2][4])
					for (register int s = 0; s < 11; ++s)
					{
						temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
					}
				else
					if (edge[3][4] == edge[2][4])
						if (edge[3][6] < edge[2][6])
						{
							for (register int s = 0; s < 11; ++s)
								{
									temp_edge[s] = edge[2][s]; edge[2][s] = edge[3][s]; edge[3][s] = temp_edge[s];
								}
						}
			}

			//---- assign scanline -------------------------------------------------------------------

			//start scanline at y_min of first edge
			int scanline = (int)edge[0][4];

			//---- activate first edge ---------------------------------------------------------------

			//for every edge
			for (register int e = 0; e < 4; ++e)
			{
				//if slope is zero (horizontal edge)
				if (edge[e][8] == 0)
					edge[e][10] = 2;
					//set edge_state to "done"

				//if edge not "done"
				if (edge[e][10] != 2)
					//activate edge if y_min is scanline
					//(always 2 edges activated at the same time)
					if (edge[e][4] == scanline)
						edge[e][10] = 1;
			}

			//---- drawing ---------------------------------------------------------------------------

			//indicates if there are edges left to draw
			int EDGES = 1;
			//ptd[0] is x-intersection of first active edge,
			//ptd[1] is x-intersection of second active edge,
			//while ptd[2] is used for swapping both values
			int ptd[3] = {0};
			//index of ptd
			int ptd_i = 0;

			while (EDGES)
			{
				//reset pdi index so first active edge is assigned to ptd[0]
				ptd_i = 0;

				//for every edge
				for (e = 0; e < 4; ++e)
				{
					//if edge state is "in use"
					if (edge[e][10] == 1)
					{
						//ptd[ptd_i] is x-intersection
						ptd[ptd_i] = (int)edge[e][9];

						//increase ptd_i so second active edge
						//is assigned to ptd[1]
						++ptd_i;
					}
				}

				//swap first and second ptd using the third one
				//if second ptd is smaller than first ptd
				if (ptd[1] < ptd[0])
				{
					ptd[2] = ptd[0]; ptd[0] = ptd[1]; ptd[1] = ptd[2];
				}

				//!! thicker version causes artifacts an the left screen
				//if not the shadow draw normal
	//			if (b < 38)
				{
					//draw all pixels beginning at pdt[0] + 1 to pdt[1]
					//(x-intersections of scanline with both active edges)
					for (int fp = ptd[0] + 1, lp = ptd[1]; fp <= lp; ++fp)
					{
						//assign x-coordinate
						pslocked32 += fp;
						//assign y-coordinate
//						pslocked32 += (ddspitch / sizeof(DWORD)) * scanline;
						pslocked32 += yoffset * scanline;
						//set pixel
						*pslocked32 = pixelf32;
						//reset pixel pointer
						pslocked32 = psbackup32;
					}
				}
	/*			else
				//draw it thicker
				{
					for (int fp = ptd[0], lp = ptd[1]; fp <= lp; ++fp)
					{
						//assign x-coordinate
						pslocked32 += fp;
						//assign y-coordinate
						pslocked32 += (ddspitch / sizeof(short)) * scanline;
						//set pixel
						*pslocked32 = pixelf;
						//reset pixel pointer
						pslocked32 = lpbackup;
					}
				}*/

				//---- reorder edges -----------------------------------------------------------------

				//increase scanline
					++scanline;

				//for every edge
				for (e = 0; e < 4; ++e)
				{
					//if edge state is "in use"
					if (edge[e][10] == 1)
						//set edge state to "done" if y_max == scanline
						if (edge[e][5] == scanline)
							edge[e][10] = 2;
						else
							//check if slope is not infinite
							if (edge[e][8] != 1000)
								//increase x-intersection by (1 / slope)
								edge[e][9] += (1 / edge[e][8]);

						//if edge state not "done"
						if (edge[e][10] != 2)
							//if y_min == scanline
							if (edge[e][4] == scanline)
								//activate edge
								edge[e][10] = 1;
				}

				//leave while loop if every edge is done
				if (edge[0][10] == 2)
					if (edge[1][10] == 2)
						if (edge[2][10] == 2)
							if (edge[3][10] == 2)
								EDGES = 0;
			}
		}

		//---- bresenham line drawing ------------------------------------------------------------

		RGBcolor	bonecolor(black);

		//only if not the shadow or in hollow mode
		if (b < 38 || p_option->data.r_hollow)
		{
			//if option on and not r_hollow and no colorbias (paused)
			if (p_option->data.show_lockstate &&
				!p_option->data.r_hollow &&
				!colorbias)
			{
				//color depending on lock state
				if (p_option->data.bw_mode == 0)
				{
					if (pd->pzb[b]->lock_state == ls_nolock)	bonecolor.setcolor(lsc_nolock);
					if (pd->pzb[b]->lock_state == ls_off)		bonecolor.setcolor(lsc_off);
					if (pd->pzb[b]->lock_state == ls_def)		bonecolor.setcolor(lsc_def);
					if (pd->pzb[b]->lock_state == ls_offdef)	bonecolor.setcolor(lsc_offdef);
				}
				else
				{
					if (pd->pzb[b]->lock_state == ls_nolock)	bonecolor.setcolor(lscbw_nolock);
					if (pd->pzb[b]->lock_state == ls_off)		bonecolor.setcolor(lscbw_off);
					if (pd->pzb[b]->lock_state == ls_def)		bonecolor.setcolor(lscbw_def);
					if (pd->pzb[b]->lock_state == ls_offdef)	bonecolor.setcolor(lscbw_offdef);
				}

				pixelb32	= DWORD(p_rLUT[bonecolor.r] | p_gLUT[bonecolor.g] | p_bLUT[bonecolor.b]);
//!!
//full damage, bone border red
if (pd->pzb[b]->damage == 100 && pd->pzb[b]->lock_state == ls_nolock)
	pixelb32	= DWORD(p_rLUT[200] | p_gLUT[0] | p_bLUT[0]);
			}

			//for every edge
			for (i = 0; i < 4; ++i)
			{
				int x = (int)edge[i][0],		y = (int)edge[i][1];
				int dx = abs((int)(edge[i][2] - edge[i][0]));
				int dy = abs((int)(edge[i][3] - edge[i][1]));

				int xinc1, xinc2, yinc1, yinc2;
				int denominator, numerator, numadd, numpixels, curpixel;

				if (edge[i][2] >= edge[i][0])
				{
					xinc1 = 1;	xinc2 = 1;
				}
				else
				{
					xinc1 = -1; xinc2 = -1;
				}

				if (edge[i][3] >= edge[i][1])
				{
					yinc1 = 1;	yinc2 = 1;
				}
				else
				{
					yinc1 = -1; yinc2 = -1;
				}

				if (dx >= dy)
				{
					xinc1 = 0;			yinc2 = 0;
					denominator = dx;	numerator = dx / 2;
					numadd = dy;		numpixels = dx;
				}
				else
				{
					xinc2 = 0;			yinc1 = 0;
					denominator = dy;	numerator = dy / 2;
					numadd = dx;		numpixels = dy;
				}

				for (curpixel = 0; curpixel <= numpixels; ++curpixel)
				{
					//assign x-coordinate
					pslocked32 += x;
					//assign y-coordinate
//					pslocked32 += (ddspitch / sizeof(DWORD)) * y;
					pslocked32 += yoffset * y;
					//set pixel
					*pslocked32 = pixelb32;
					//reset pixel pointer
					pslocked32 = psbackup32;

					numerator += numadd;
					if (numerator >= denominator)
					{
						numerator -= denominator;
						x += xinc1;		y += yinc1;
					}
					x += xinc2;		y += yinc2;
				}
			}
		}

		//---- fist/head drawing -----------------------------------------------------------------

		//colors, uses pixelb as border, pixelf as fillcolor (damage) and
		//pixel_fa as head fillcolor (fatigue)
		DWORD pixel_fa32;

		//if not the shadow
		if (b < 38)
		{
			//if bone has fist draw it
			if (pd->pzb[b]->type == 1)
			{
				//if not hit assign user set fistcolor
				if (pd->pzb[b]->hit_state_e == hs_nohit)
				{
					//apply color bias if activated
					if (colorbias)
					{
						cfx		= (int)(0.3 * p_option->data.fistcolor[pd->pzb[b]->id].r + 0.59 * p_option->data.fistcolor[pd->pzb[b]->id].g + 0.11 * p_option->data.fistcolor[pd->pzb[b]->id].b);
						bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
						bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
					}
					else
					//standard color
					{
						bc.r	= p_option->data.fistcolor[pd->pzb[b]->id].r;
						bc.g	= p_option->data.fistcolor[pd->pzb[b]->id].g;
						bc.b	= p_option->data.fistcolor[pd->pzb[b]->id].b;
					}
				}
				else
				//flash depending on hit state
				{
					if (p_option->data.bw_mode == 0)
					{
						if (pd->pzb[b]->hit_state_e == hs_hit)
							bc.setcolor(hsc_hit);
						if (pd->pzb[b]->hit_state_e == hs_hitred)
							bc.setcolor(hsc_hitred);
						if (pd->pzb[b]->hit_state_e == hs_hitdef)
							bc.setcolor(hsc_hitdef);
						if (pd->pzb[b]->hit_state_e == hs_hitret)
							bc.setcolor(hsc_hitret);
						if (pd->pzb[b]->hit_state_e == hs_stanceflash)
							bc.setcolor(hsc_stanceflash);
					}
					else
					{
						if (pd->pzb[b]->hit_state_e == hs_hit)
							bc.setcolor(hscbw_hit);
						if (pd->pzb[b]->hit_state_e == hs_hitred)
							bc.setcolor(hscbw_hitred);
						if (pd->pzb[b]->hit_state_e == hs_hitdef)
							bc.setcolor(hscbw_hitdef);
						if (pd->pzb[b]->hit_state_e == hs_hitret)
							bc.setcolor(hscbw_hitret);
						if (pd->pzb[b]->hit_state_e == hs_stanceflash)
							bc.setcolor(hscbw_stanceflash);
					}

					//if hit state flash color is the same as fistcolor
					//negativize hit state flash color
					//(e.g. in color mode if fists are blue hs_hitdef is
					//also blue)
					if (bc == p_option->data.fistcolor[pd->pzb[b]->id])
						bc.setcolor(negative);
				}

				//draw states instead of damage if option on
				if (p_option->data.cd_state)
				{
					//no hit
					if (pd->pzb[b]->cd_state == cds_nohit)
						bc.setcolor(cdsc_nohit);
					//hitable
					if (pd->pzb[b]->cd_state == cds_hit)
						bc.setcolor(cdsc_hit);
					//defending
					if (pd->pzb[b]->cd_state == cds_def)
						bc.setcolor(cdsc_def);
					//hit return
					if (pd->pzb[b]->cd_state == cds_hitret)
						bc.setcolor(cdsc_hitret);
					//defending part
					if (pd->pzb[b]->cd_state == cds_defpart ||
						pd->pzb[b]->cd_state == cds_defpart_e)
						bc.setcolor(cdsc_defpart);
					if (pd->pzb[b]->cd_state == cds_defpart_b)
						bc.setcolor(cdsc_hit);
				}

				pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

				//!!! radius?
				//size of fist
				int fist_s			= 12;
				//assign zoomfactor and round .5 up
				int fist_sz			= (int)(fist_s * p_option->data.zoomfactor + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//get fist_array offset from hitbox
				int offx = pd->pzb[b]->hitbox_e.left;
				int offy = pd->pzb[b]->hitbox_e.top;

				//draw fist array
				for (register int line = 0; line < fist_sz; ++line)
					for (register int column = 0; column < fist_sz; ++column)
					{
						//clipping
						if (offx + column	>= rSCREEN169.left	&& offx + column	<= rSCREEN169.right - 1 &&
							offy + line		>= rSCREEN169.top	&& offy + line		<= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += offx + column;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * (offy + line);
							pslocked32 += yoffset * (offy + line);

							//get line and column index of original array
							index_l = (int)((line + 1) / p_option->data.zoomfactor + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > fist_s)	index_l = fist_s;
							index_c	= (int)((column + 1) / p_option->data.zoomfactor + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > fist_s)	index_c = fist_s;

							//set pixel according to array
							if (!p_option->data.r_hollow)
							{
								if (fist_a[index_l * fist_s + index_c] == 1)
									*pslocked32 = pixelb32;
								if (fist_a[index_l * fist_s + index_c] == 2)
									*pslocked32 = pixelf32;
							}
							else
							{
								if (fist_a[index_l * fist_s + index_c] == 1)
									*pslocked32 = pixelf32;
							}

//!!!
/*							if (fist_a[line * fist_s + column] == 1)
								*pslocked32 = pixelb;
							if (fist_a[line * fist_s + column] == 2)
								*pslocked32 = pixelf;*/
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}

			//if bone has head draw it
			if (pd->pzb[b]->type == 3)
			{
				//assign appropriate headdamage and fatigue color
				//if no blackwhite mode use standard color table
				if (p_option->data.bw_mode == 0)
				{
					//damage
					//if hit
					if (pd->pzb[b]->hit_state_e == hs_nohit)
					{
						//condition masking off or only opponent and bone belongs not to host
						if (p_option->data.condition_masking == 0 ||
							(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
							//apply color bias if activated
							if (colorbias)
							{
								cfx		= (int)(0.3 * p_greenredLUT[pd->pzb[b]->damage][0] + 0.59 * p_greenredLUT[pd->pzb[b]->damage][1] + 0.11 * p_greenredLUT[pd->pzb[b]->damage][2]);
								bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
								bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
							}
							else
							//standard color
							{
								bc.r	= p_greenredLUT[pd->pzb[b]->damage][0];
								bc.g	= p_greenredLUT[pd->pzb[b]->damage][1];
								bc.b	= p_greenredLUT[pd->pzb[b]->damage][2];
							}
						//condition masking both or only opponent and bone belongs to opponent
						if (p_option->data.condition_masking == 2 ||
							(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
							//apply color bias if activated
							if (colorbias)
							{
								cfx		= (int)(0.3 * p_greenredLUT[0][0] + 0.59 * p_greenredLUT[0][1] + 0.11 * p_greenredLUT[0][2]);
								bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
								bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
							}
							else
							//standard color
							{
								bc.r	= p_greenredLUT[0][0];
								bc.g	= p_greenredLUT[0][1];
								bc.b	= p_greenredLUT[0][2];
							}
					}
					else
					{
						if (pd->pzb[b]->hit_state_e == hs_hit)
							bc.setcolor(hsc_hit);
						if (pd->pzb[b]->hit_state_e == hs_hitred)
							bc.setcolor(hsc_hitred);
						if (pd->pzb[b]->hit_state_e == hs_hitdef)
							bc.setcolor(hsc_hitdef);
						if (pd->pzb[b]->hit_state_e == hs_hitret)
							bc.setcolor(hsc_hitret);
						if (pd->pzb[b]->hit_state_e == hs_stanceflash)
							bc.setcolor(hsc_stanceflash);
					}

					pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

					//fatigue
					//condition masking off or only opponent and bone belongs not to host
					if (p_option->data.condition_masking == 0 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][0] + 0.59 * p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][1] + 0.11 * p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][0];
							bc.g	= p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][1];
							bc.b	= p_bluewhiteLUT[(int)*pd->p_fatigue[pd->pzb[b]->id]][2];
						}
					//condition masking both or only opponent and bone belongs to opponent
					if (p_option->data.condition_masking == 2 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_bluewhiteLUT[0][0] + 0.59 * p_bluewhiteLUT[0][1] + 0.11 * p_bluewhiteLUT[0][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_bluewhiteLUT[0][0];
							bc.g	= p_bluewhiteLUT[0][1];
							bc.b	= p_bluewhiteLUT[0][2];
						}

					pixel_fa32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
				}
				else
				//bw_mode
				{
					//damage bw
					if (pd->pzb[b]->hit_state_e == hs_nohit)
					{
						//condition masking off or only opponent and bone belongs not to host
						if (p_option->data.condition_masking == 0 ||
							(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
							//apply color bias if activated
							if (colorbias)
							{
								cfx		= (int)(0.3 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][0] + 0.59 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][1] + 0.11 * p_blackwhiteLUT[100 - pd->pzb[b]->damage][2]);
								bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
								bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
							}
							else
							//standard color
							{
								bc.r	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][0];
								bc.g	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][1];
								bc.b	= p_blackwhiteLUT[100 - pd->pzb[b]->damage][2];
							}
						//condition masking both or only opponent and bone belongs to opponent
						if (p_option->data.condition_masking == 2 ||
							(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
							//apply color bias if activated
							if (colorbias)
							{
								cfx		= (int)(0.3 * p_blackwhiteLUT[100][0] + 0.59 * p_blackwhiteLUT[100][1] + 0.11 * p_blackwhiteLUT[100][2]);
								bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
								bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
							}
							else
							//standard color
							{
								bc.r	= p_blackwhiteLUT[100][0];
								bc.g	= p_blackwhiteLUT[100][1];
								bc.b	= p_blackwhiteLUT[100][2];
							}
					}
					else
					{
						if (pd->pzb[b]->hit_state_e == hs_hit)
							bc.setcolor(hscbw_hit);
						if (pd->pzb[b]->hit_state_e == hs_hitred)
							bc.setcolor(hscbw_hitred);
						if (pd->pzb[b]->hit_state_e == hs_hitdef)
							bc.setcolor(hscbw_hitdef);
						if (pd->pzb[b]->hit_state_e == hs_hitret)
							bc.setcolor(hscbw_hitret);
						if (pd->pzb[b]->hit_state_e == hs_stanceflash)
							bc.setcolor(hscbw_stanceflash);
					}

					pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

					//fatigue
					//condition masking off or only opponent and bone belongs not to host
					if (p_option->data.condition_masking == 0 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id == *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][0] + 0.59 * p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][1] + 0.11 * p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][0];
							bc.g	= p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][1];
							bc.b	= p_blackwhiteLUT[100 - (int)*pd->p_fatigue[pd->pzb[b]->id]][2];
						}
					//condition masking both or only opponent and bone belongs to opponent
					if (p_option->data.condition_masking == 2 ||
						(p_option->data.condition_masking == 1 && pd->pzb[b]->id != *pd->phost_id))
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * p_blackwhiteLUT[100][0] + 0.59 * p_blackwhiteLUT[100][1] + 0.11 * p_blackwhiteLUT[100][2]);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						//standard color
						{
							bc.r	= p_blackwhiteLUT[100][0];
							bc.g	= p_blackwhiteLUT[100][1];
							bc.b	= p_blackwhiteLUT[100][2];
						}

					pixel_fa32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);
				}

				//draw states instead of damage if option on
				if (p_option->data.cd_state)
				{
					RGBcolor tmpclr;

					//no hit
					if (pd->pzb[b]->cd_state == cds_nohit)
						tmpclr.setcolor(cdsc_nohit);
					//hitable
					if (pd->pzb[b]->cd_state == cds_hit)
						tmpclr.setcolor(cdsc_hit);
					//defending
					if (pd->pzb[b]->cd_state == cds_def)
						tmpclr.setcolor(cdsc_def);
					//hit return
					if (pd->pzb[b]->cd_state == cds_hitret)
						tmpclr.setcolor(cdsc_hitret);
					//defending part
					if (pd->pzb[b]->cd_state == cds_defpart)
//						tmpclr.setcolor(cdsc_defpart);
//!!!
						tmpclr.setcolor(lightblue);

					pixelf32 = DWORD(p_rLUT[tmpclr.r] | p_gLUT[tmpclr.g] | p_bLUT[tmpclr.b]);
				}

				//!!! radius?
				//size of head
				int head_s		= 26;
				//assign zoomfactor and round .5 up
				int head_sz		= (int)(head_s * p_option->data.zoomfactor + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//!! headorder

				//pointer to back or front head in dependence of stance
				signed char *head_a;

				//on the left side
				if (*pd->p_side[pd->pzb[b]->id] == SLEFT)
				{
					//left foot forward
					if (*pd->p_stance[pd->pzb[b]->id] == 0)
						head_a = head_f;
					else
					//right foot forward
						head_a = head_b;
				}
				else
				//on the right
				{
					//left foot forward
					if (*pd->p_stance[pd->pzb[b]->id] == 0)
						head_a = head_b;
					else
					//right foot forward
						head_a = head_f;
				}

				//get head_array offset from hitbox
				int offx = pd->pzb[b]->hitbox_e.left;
				int offy = pd->pzb[b]->hitbox_e.top;

				//draw head array
				for (register int line = 0; line < head_sz; ++line)
					for (register int column = 0; column < head_sz; ++column)
					{
						//clipping
						if (offx + column	>= rSCREEN169.left	&& offx + column	<= rSCREEN169.right - 1 &&
							offy + line		>= rSCREEN169.top	&& offy + line		<= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += offx + column;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * (offy + line);
							pslocked32 += yoffset * (offy + line);

							//get line and column index of original array
							index_l = (int)((line + 1) / p_option->data.zoomfactor + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > head_s)	index_l = head_s;
							index_c	= (int)((column + 1) / p_option->data.zoomfactor + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > head_s)	index_c = head_s;

							//set pixel according to array
							if (!p_option->data.r_hollow)
							{
								if (head_a[index_l * head_s + index_c] == 1 ||
									head_a[index_l * head_s + index_c] == 4)
									*pslocked32 = pixelb32;
								if (head_a[index_l * head_s + index_c] == 2)
									*pslocked32 = pixelf32;
								if (head_a[index_l * head_s + index_c] == 3)
									*pslocked32 = pixel_fa32;
							}
							else
							{
								if (head_a[index_l * head_s + index_c] == 1)
									*pslocked32 = pixelf32;
								if (head_a[index_l * head_s + index_c] == 4)
									*pslocked32 = pixel_fa32;
								//if (head_a[index_l * head_s + index_c] == 2)
								//	*pslocked32 = pixelf;
							}
//!!
/*							//set pixel according to array
							if (head_a[line * head_s + column] == 1)
								*pslocked32 = pixelb;
							if (head_a[line * head_s + column] == 2)
								*pslocked32 = pixelf;
							if (head_a[line * head_s + column] == 3)
								*pslocked32 = pixel_fa;*/
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}

				//---- blood particles -----------------------------------------------------------
				//same z-order as head

				//for both particle heaps
				for (register int h = 0; h < 2; ++h)
					//if heap active
					if (pd->p_blood_active[pd->pzb[b]->id][h] == 1)
					{
						//blood is always red, even in bw_mode
						//only exception when PAL activated (blood is green)
						DWORD pixel32;
						if (!p_option->data.pal)
							pixel32		= DWORD(p_rLUT[255] | p_gLUT[0] | p_bLUT[0]);
						else
							pixel32		= DWORD(p_rLUT[0] | p_gLUT[128] | p_bLUT[0]);

						//particle coordinates
						int x, y;

						//for every particle until maximum number of particles to be drawn
						for (register int i = 0; i < pd->p_bsize[pd->pzb[b]->id][h]; ++i)
						{
							//if age != -1 which would mean particle is out of bounds
							//and age is not bigger than lifetime or lifetime is infinite,
							//draw particle
							if (pd->p_heap[pd->pzb[b]->id][h].pp[i].age != -1 &&
								(pd->p_heap[pd->pzb[b]->id][h].pp[i].age <= pd->p_heap[pd->pzb[b]->id][h].pp[i].lifetime || pd->p_heap[pd->pzb[b]->id][h].pp[i].lifetime == -1))
//								pa[i].age != -1 &&
//								(pa[i].age <= pa[i].lifetime || pa[i].lifetime == -1))
							{
								//extra clipping
								//may not be necessary since particles get already clipped in
								//particle_heap
								if ((int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.x >= rSCREEN169.left && (int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.x <= rSCREEN169.right - 1 &&
									(int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.y >= rSCREEN169.top && (int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.y <= rSCREEN169.bottom - 1)
								{
									//convert pos into integers
									x = (int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.x;
									y = (int)pd->p_heap[pd->pzb[b]->id][h].pp[i].pos.y;

									//assign x-coordinate
									//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
									pslocked32 += x;
									//assign y-coordinate
									//ddspitch is in byte, but since one pixel is short and pslocked32
									//is incremented by short you have to adjust the ddspitch value by
									//the size of short
//									pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
									pslocked32 += yoffset * y;
									//set pixel
									*pslocked32 = pixel32;
									//reset pixel pointer
									pslocked32 = psbackup32;
								}
							}
						}
					}
			}
		}
		else
		//if shadow (which means shadow option is on)
		{
			//if bone has fist draw it
			if (pd->pzb[b - 38]->type == 1)
			{
				//shadow color
				//apply color bias if activated
				if (colorbias)
				{
					cfx		= (int)(0.3 * 30 + 0.59 * 30 + 0.11 * 30);
					bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
					bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
				}
				else
				{
					bc.r	= 30;
					bc.g	= 30;
					bc.b	= 30;
				}

				pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

				//size of fist
				int fist_s		= 12;
				//assign zoomfactor and round .5 up
				int fist_sz			= (int)(fist_s * p_option->data.zoomfactor + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//shadow points
				int	sx = 0, sy = 0;

				//get fist_array offset from hitbox
				int offx = pd->pzb[b - 38]->hitbox_e.left;
				int offy = pd->pzb[b - 38]->hitbox_e.top;

				//draw fist array
				for (register int line = 0; line < fist_sz; ++line)
					for (register int column = 0; column < fist_sz; ++column)
					{
						//scale shadow point
						if (offy + line <= *pd->p_s_mpy)
							sy = (int)(*pd->p_s_mpy + (*pd->p_s_mpy - (offy + line)) * pd->p_s_scale->y);
						else
							sy = offy + line;
						sx = (int)((offx + column) + pd->p_s_scale->x * (float)(fabs((offy + line) - sy)));
			
						//clipping
						if (sx >= rSCREEN169.left	&& sx <= rSCREEN169.right - 1 &&
							sy >= rSCREEN169.top	&& sy <= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += sx;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * sy;
							pslocked32 += yoffset * sy;

							//get line and column index of original array
							index_l = (int)((line + 1) / p_option->data.zoomfactor + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > fist_s)	index_l = fist_s;
							index_c	= (int)((column + 1) / p_option->data.zoomfactor + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > fist_s)	index_c = fist_s;

							//set pixel according to array
							if (!p_option->data.r_hollow)
							{
								if (fist_a[index_l * fist_s + index_c] != 0)
									*pslocked32 = pixelf32;
							}
							else
							{
								if (fist_a[index_l * fist_s + index_c] == 1)
									*pslocked32 = pixelf32;
							}

							//!!
							//set pixel according to array
							//if (fist_a[line * fist_s + column] != 0)
							//	*pslocked32 = pixelf;
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}
			}

			//if bone has head draw it
			if (pd->pzb[b - 38]->type == 3)
			{
				//shadow color
				//apply color bias if activated
				if (colorbias)
				{
					cfx		= (int)(0.3 * 30 + 0.59 * 30 + 0.11 * 30);
					bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
					bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
				}
				else
				{
					bc.r	= 30;
					bc.g	= 30;
					bc.b	= 30;
				}

				pixelf32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

				//size of head
				int head_s		= 26;
				//assign zoomfactor and round .5 up
				int head_sz		= (int)(head_s * p_option->data.zoomfactor + 0.5f);
				//line and column index of zoomfactor uneffected source array
				int	index_l, index_c;

				//shadow points
				int	sx = 0, sy = 0;

				//get head_array offset from hitbox
				int offx = pd->pzb[b - 38]->hitbox_e.left;
				int offy = pd->pzb[b - 38]->hitbox_e.top;

				//draw head array
				for (register int line = 0; line < head_sz; ++line)
					for (register int column = 0; column < head_sz; ++column)
					{
						//scale shadow point
						if (offy + line <= *pd->p_s_mpy)
							sy = (int)(*pd->p_s_mpy + (*pd->p_s_mpy - (offy + line)) * pd->p_s_scale->y);
						else
							sy = offy + line;
						sx = (int)((offx + column) + pd->p_s_scale->x * (float)(fabs((offy + line) - sy)));
			
						//clipping
						if (sx >= rSCREEN169.left	&& sx <= rSCREEN169.right - 1 &&
							sy >= rSCREEN169.top	&& sy <= rSCREEN169.bottom - 1)
						{
							//set surface pointer
							pslocked32 += sx;
//							pslocked32 += (ddspitch / sizeof(DWORD)) * sy;
							pslocked32 += yoffset * sy;

							//get line and column index of original array
							index_l = (int)((line + 1) / p_option->data.zoomfactor + 0.5f);
							--index_l;
							if (index_l < 0)		index_l = 0;
							if (index_l > head_s)	index_l = head_s;
							index_c	= (int)((column + 1) / p_option->data.zoomfactor + 0.5f);
							--index_c;
							if (index_c < 0)		index_c = 0;
							if (index_c > head_s)	index_c = head_s;

							//set pixel according to array
							if (!p_option->data.r_hollow)
							{
								if (head_f[index_l * head_s + index_c] != 0)
									*pslocked32 = pixelf32;
							}
							else
							{
								if (head_f[index_l * head_s + index_c] == 1)
									*pslocked32 = pixelf32;
							}

							//!!
							//set pixel according to array
							//if (head_f[line * head_s + column] != 0)
							//	*pslocked32 = pixelf;
						}

						//reset surface pointer
						pslocked32 = psbackup32;
					}

				//---- blood particles shadow ----------------------------------------------------
				//same z-order as head

				//for both particle heaps
				for (register int h = 0; h < 2; ++h)
					//if heap active
					if (pd->p_blood_active[pd->pzb[b - 38]->id][h] == 1)
					{
						//shadow color
						//apply color bias if activated
						if (colorbias)
						{
							cfx		= (int)(0.3 * 30 + 0.59 * 30 + 0.11 * 30);
							bc.r	= cfx + bias_r;			bc.g		= cfx + bias_g; 		bc.b	= cfx + bias_b;
							bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;
						}
						else
						{
							bc.r	= 30;
							bc.g	= 30;
							bc.b	= 30;
						}

						DWORD pixel32 = DWORD(p_rLUT[bc.r] | p_gLUT[bc.g] | p_bLUT[bc.b]);

						//particle coordinates
						int x, y;

						//for every particle until maximum number of particles to be drawn
						for (register int i = 0; i < pd->p_bsize[pd->pzb[b - 38]->id][h]; ++i)
						{
							//if age != -1 which would mean particle is out of bounds
							//and age is not bigger than lifetime or lifetime is infinite,
							//draw particle
							if (pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].age != -1 &&
								(pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].age <= pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].lifetime || pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].lifetime == -1))
							{
								//clipping
								//particle shadows aren't clipped in particle_heap
								if ((int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.x >= rSCREEN169.left && (int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.x <= rSCREEN169.right - 1 &&
									(int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.y >= rSCREEN169.top && (int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.y <= rSCREEN169.bottom - 1)
								{
									//convert pos into integers
									x = (int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.x;
									y = (int)pd->p_heap[pd->pzb[b - 38]->id][h].pp[i].pos_s.y;

									//assign x-coordinate
									//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
									pslocked32 += x;
									//assign y-coordinate
									//ddspitch is in byte, but since one pixel is short and pslocked32
									//is incremented by short you have to adjust the ddspitch value by
									//the size of short
//									pslocked32 += (int)((ddspitch / sizeof(DWORD)) * y);
									pslocked32 += yoffset * y;
									//set pixel
									*pslocked32 = pixel32;
									//reset pixel pointer
									pslocked32 = psbackup32;
								}
							}
						}
					}
			}
		}
	}

	//---- player messages -----------------------------------------------------------------------

	//both players
	for (p = 0; p < 2; ++p)
	{
		//all messages
		for (register int m = 0; m < NPMESSAGES; ++m)
		{
			//if message active
			if (pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].active)
			{
				//type message
				typeSLF_ML((int)pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].cpos.x,
						   (int)pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].cpos.y,
						   pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].b_color_adj.r, pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].b_color_adj.g, pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].b_color_adj.b,
						   pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].f_color_adj.r, pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].f_color_adj.g, pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].f_color_adj.b,
						   pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].size,
						   "%s", pd->p_message[p]->pm[pd->p_message[p]->pm_sorted[m]].message);
			}
		}
	}

	//---- dd cleanup ----------------------------------------------------------------------------

	//unlock backbuffer
	BBUnlock();
	pslocked32 = NULL;

	return(true);
}