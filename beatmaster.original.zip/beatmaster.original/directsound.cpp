//------------------------------------------------------------------------------------------------
//
//	directsound class definitions
//
//------------------------------------------------------------------------------------------------

#include "directsound.h"			//class declaration header

//------------------------------------------------------------------------------------------------
//
//	directsound contstructor
//
//------------------------------------------------------------------------------------------------

directsound::directsound()
{
	//initialize directsound objects with NULL pointer
	lpDS			= NULL;

	for (register int i = 0; i < NSBS; ++i)
		lpDSBStatic_sys[i] = NULL;
	for (i = 0; i < NSBP; ++i)
		lpDSBStatic_P1[i] = lpDSBStatic_P2[i] = NULL;

	lpDSBStatic_BGM	= NULL;

    m_pwfx			= NULL;

	//timer/option pointer
	p_option		= NULL;
	p_time			= NULL;

	//so first restoring after program start is done
//	sound_sys		= 1;
//	psound_set		= NULL;
//	sound_set		= 1;

	//---- system soundfile names ----------------------------------------------------------------

	psoundfile_sys[S_ERROR]		= "sound/s_error.wav";			//79KB
	psoundfile_sys[S_JINGLE]	= "sound/s_jingle.wav";			//159KB
	psoundfile_sys[S_MSELECT]	= "sound/m_select.wav";			//4KB
	psoundfile_sys[S_MCANCEL]	= "sound/m_cancel.wav";			//79KB
	psoundfile_sys[S_MBEAT]		= "sound/m_beat.wav";			//21KB
	psoundfile_sys[S_MENTER]	= "sound/m_enter.wav";			//7KB

	psoundfile_sys[S_ROUND]		= "sound/igm_round.wav";		//22KB
	psoundfile_sys[S_ONE]		= "sound/igm_one.wav";			//12KB
	psoundfile_sys[S_TWO]		= "sound/igm_two.wav";			//16KB
	psoundfile_sys[S_THREE]		= "sound/igm_three.wav";		//18KB
	psoundfile_sys[S_FOUR]		= "sound/igm_four.wav";			//18KB
	psoundfile_sys[S_FIGHT]		= "sound/igm_fight.wav";		//14KB

	psoundfile_sys[S_TICK]		= "sound/igm_tick.wav";			//4KB
	psoundfile_sys[13]			= "sound/g_taunt1.wav";			//13KB
	psoundfile_sys[14]			= "sound/g_taunt1.wav";			//87KB

	//627KB

	//---- player soundfile names ----------------------------------------------------------------

	psoundfile_p[S_ERROR]		= "sound/s_error.wav";			//102KB

	psoundfile_p[S_JAB]			= "sound/g_punch_dummy.wav";	//15KB
	psoundfile_p[S_CROSS]		= "sound/g_punch_dummy.wav";	//15KB
	psoundfile_p[S_KICK_FWD]	= "sound/g_punch_dummy.wav";	//15KB
	psoundfile_p[S_KICK_SWD]	= "sound/g_punch_dummy.wav";	//15KB

	psoundfile_p[S_TAP]			= "sound/g_tap.wav";			//3KB

	psoundfile_p[S_HIT_STD]		= "sound/g_hit_std.wav";		//21KB
	psoundfile_p[S_HIT_DPART]	= "sound/g_hit_dpart.wav";		//13KB
	psoundfile_p[S_HIT_TAP]		= "sound/g_hit_tap.wav";
	psoundfile_p[S_HIT_RET]		= "sound/g_hit_ret.wav";
	psoundfile_p[S_HIT_BLOOD]	= "sound/g_hit_blood.wav";
	psoundfile_p[S_HIT_KO]		= "sound/g_hit_ko.wav";
	psoundfile_p[S_HIT_CANCEL]	= "sound/g_hit_cancel.wav";

	psoundfile_p[S_ATT_LOCKED]	= "sound/g_att_locked.wav";

	psoundfile_p[S_HEALTH]		= "sound/g_health.wav";			//6442byte

	psoundfile_p[S_AGA1]		= "sound/g_l_aga1.wav";
	psoundfile_p[S_AGA2]		= "sound/g_l_aga2.wav";
	psoundfile_p[S_UHU]			= "sound/g_l_uhu.wav";

	psoundfile_p[S_TAUNT1]		= "sound/g_taunt1.wav";			//102KB
	psoundfile_p[S_TAUNT2]		= "sound/g_taunt2.wav";			//102KB

	//---- background music soundfile name --------------------------------------------------------

//!!	psoundfile_bgm				= "sound/kung fu fighting.wav";
	psoundfile_bgm				= "sound/s_error.wav";

	//---- last frame ingame speed ----------------------------------------------------------------

	freq_speed_last				= 0;

	//---- console -------------------------------------------------------------------------------

	//clear console message buffer
	con_clear();

	//---- hud data ------------------------------------------------------------------------------

	p_hud_text					= NULL;

	gf_logger(false, "directsound::directsound done");
}

//------------------------------------------------------------------------------------------------
//
//	directsound initialization
//
//------------------------------------------------------------------------------------------------

bool directsound::ds_initialization(HWND hwnd)
{
	//user set sound option
	//psound_set		= psound;

	//---- create instance of directsound-object -------------------------------------------------
	hRet = DirectSoundCreate(NULL,						//GUID of sound device, NULL default
							 &lpDS,						//adress of DS pointer
							 NULL);						//NULL
	if (hRet != DS_OK)
	{
		gf_logger(true, "directsound::ds_initialization DSC failed");
		gp_ErrStr = Err_DSDirectSoundCreate;
		ds_cleanup();
		return false;
	}

	//---- determine top-level behavior of application -------------------------------------------

	hRet = lpDS->SetCooperativeLevel(hwnd,				//window handle
									 DSSCL_PRIORITY);	//priority mode
	if (hRet != DS_OK)
	{
		gf_logger(true, "directsound::ds_initialization SCL failed");
		gp_ErrStr = Err_DSSetCooperativeLevel;
		ds_cleanup();
		return false;
	}

	//---- move onboard sound memory into one block ----------------------------------------------

	hRet = lpDS->Compact();
	if (hRet != DS_OK)
	{
		gf_logger(true, "directsound::ds_initialization Compact failed");
		gp_ErrStr = "Err_DSCompact";
		ds_cleanup();
		return false;
	}

	//---- open, read all wave files, create all static secondary sound buffers and
	//---- fill them with the wave data ----------------------------------------------------------

	//---- player sounds -------------------------------------------------------------------------

	//for both players
	for (register int p = 0; p < 2 ; ++p)
	{
		for (register int i = 0; i < NSBP; ++i)
		{
			HRESULT		hRet;

			//open wave file, 0 if okay
			hRet		= WaveOpenFile(psoundfile_p[i], &m_hmmioIn, &m_pwfx, &m_ckInRiff);

			if (hRet != S_OK)
			{
				gf_logger(true, "directsound::ds_initialization WOF failed %s", psoundfile_p[i]);
				//gp_ErrStr = Err_DSWaveOpenFile;
				gp_ErrStr = psoundfile_p[i];
				ds_cleanup();
				return false;
			}

			//start wave file reading
			if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
			{
				gf_logger(true, "directsound::ds_initialization WSDR failed %s", psoundfile_p[i]);
				gp_ErrStr = Err_DSWaveStartDataRead;
				ds_cleanup();
				return false;
			}

			//set buffer description
			memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));
			dsbdesc.dwSize = sizeof(DSBUFFERDESC);
			dsbdesc.dwFlags = DSBCAPS_STATIC |				//static buffer
//DSBCAPS_LOCSOFTWARE |
							  DSBCAPS_CTRLPAN |				//control pan
							  DSBCAPS_CTRLVOLUME |			//control volume
							  DSBCAPS_CTRLFREQUENCY;		//control frequency
			dsbdesc.dwBufferBytes = m_ckIn.cksize;			//size of buffer in bytes
			dsbdesc.lpwfxFormat = m_pwfx;					//address of structure specifying the waveform format for buffer

			//create buffers
			//depending on player
			if (p == 0)
			{
				if (FAILED(lpDS->CreateSoundBuffer(&dsbdesc,			//description of surface
												   &lpDSBStatic_P1[i],	//buffer
												   NULL)))				//NULL
				{
					gf_logger(true, "directsound::ds_initialization CSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSCreateSoundBuffer;
					Close();
					ds_cleanup();
					return false; 
				}
			}
			else
			{
				if (FAILED(lpDS->CreateSoundBuffer(&dsbdesc,			//description of surface
												   &lpDSBStatic_P2[i],	//buffer
												   NULL)))				//NULL
				{
					gf_logger(true, "directsound::ds_initialization CSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSCreateSoundBuffer;
					Close();
					ds_cleanup();
					return false; 
				}
			}

			//log if buffer in hard- or software
			DSBCAPS scapi;
			ZeroMemory(&scapi, sizeof(DSBCAPS));
			scapi.dwSize = sizeof(DSBCAPS);
			if (p == 0)
				lpDSBStatic_P1[i]->GetCaps(&scapi);
			else
				lpDSBStatic_P2[i]->GetCaps(&scapi);

			if ((scapi.dwFlags & DSBCAPS_LOCHARDWARE) != 0)
				gf_logger(false, "LOCHARDWARE P[%i] S[%i] %s", p, i, psoundfile_p[i]);
			else
				gf_logger(false, "LOCSOFTWARE P[%i] S[%i] %s", p, i, psoundfile_p[i]);

			LPVOID lpvAudio1;
			DWORD  dwBytes1;

			//lock buffer and fill it with wave audio data
			if (p == 0)
			{
				if (FAILED(lpDSBStatic_P1[i]->Lock(0,					//offset of lock start
												   0,					//size of lock, ignored in this case
												   &lpvAudio1,			//address of lock start
												   &dwBytes1,			//number of bytes locked
												   NULL,				//wrap around start, not used
												   NULL,				//wrap around size, not used
												   DSBLOCK_ENTIREBUFFER)))	//flags
				{
					gf_logger(true, "directsound::ds_initialization LSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSFillSoundBuffer;
					Close();
					ds_cleanup();
					return false;
				}
			}
			else
			{
				if (FAILED(lpDSBStatic_P2[i]->Lock(0,					//offset of lock start
												   0,					//size of lock, ignored in this case
												   &lpvAudio1,			//address of lock start
												   &dwBytes1,			//number of bytes locked
												   NULL,				//wrap around start, not used
												   NULL,				//wrap around size, not used
												   DSBLOCK_ENTIREBUFFER)))	//flags
				{
					gf_logger(true, "directsound::ds_initialization LSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSFillSoundBuffer;
					Close();
					ds_cleanup();
					return false;
				}
			}
		
			UINT cbBytesRead;

			//
			if (WaveReadFile(m_hmmioIn,							//file handle
				 			 dwBytes1,							//no. of bytes to read
			 				 (BYTE *) lpvAudio1,				//destination
				 			 &m_ckIn,							//file chunk info 
							 &cbBytesRead))						//actual no. of bytes read
			{
				gf_logger(true, "directsound::ds_initialization WRF failed %s", psoundfile_p[i]);
				gp_ErrStr = Err_DSFillSoundBuffer;
				Close();
				ds_cleanup();
				return false;
			}

			//unlock buffer
			if (p == 0)
				lpDSBStatic_P1[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
			else
				lpDSBStatic_P2[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
			Close();

			delete m_pwfx;
			m_pwfx = NULL;
		}
	}
	
	//---- system sound --------------------------------------------------------------------------

	for (register int i = 0; i < NSBS; ++i)
	{
		HRESULT		hRet;

		//open wave file, 0 if okay
		hRet		= WaveOpenFile(psoundfile_sys[i], &m_hmmioIn, &m_pwfx, &m_ckInRiff);

		if (hRet != S_OK)
		{
			gf_logger(true, "directsound::ds_initialization WOF failed %s", psoundfile_sys[i]);
			//gp_ErrStr = Err_DSWaveOpenFile;
			gp_ErrStr = psoundfile_sys[i];
			ds_cleanup();
			return false;
		}

		//start wave file reading
		if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
		{
			gf_logger(true, "directsound::ds_initialization WSDR failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSWaveStartDataRead;
			ds_cleanup();
			return false;
		}

		//!!! pan volume and frequency muss nicht geaendert werden

		//set buffer description
		memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));
		dsbdesc.dwSize = sizeof(DSBUFFERDESC);
		dsbdesc.dwFlags = DSBCAPS_STATIC |				//static buffer
DSBCAPS_LOCSOFTWARE |
//						  DSBCAPS_CTRLPAN |				//control pan
						  DSBCAPS_CTRLVOLUME |			//control volume
						  DSBCAPS_CTRLFREQUENCY;		//control frequency
		dsbdesc.dwBufferBytes = m_ckIn.cksize;			//size of buffer in bytes
		dsbdesc.lpwfxFormat = m_pwfx;					//address of structure specifying the waveform format for buffer

		//create buffers
		if (FAILED(lpDS->CreateSoundBuffer(&dsbdesc,			//description of surface
										   &lpDSBStatic_sys[i],	//buffer
										   NULL)))				//NULL
		{
			gf_logger(true, "directsound::ds_initialization CSB failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSCreateSoundBuffer;
			Close();
			ds_cleanup();
			return false; 
		}

		//log if buffer in hard- or software
		DSBCAPS scapi;
		ZeroMemory(&scapi, sizeof(DSBCAPS));
		scapi.dwSize = sizeof(DSBCAPS);
		lpDSBStatic_sys[i]->GetCaps(&scapi);
		if ((scapi.dwFlags & DSBCAPS_LOCHARDWARE) != 0)
			gf_logger(false, "LOCHARDWARE SYS S[%i] %s", i, psoundfile_p[i]);
		else
			gf_logger(false, "LOCSOFTWARE SYS S[%i] %s", i, psoundfile_p[i]);

		LPVOID lpvAudio1;
		DWORD  dwBytes1;

		//lock buffer and fill it with wave audio data
		if (FAILED(lpDSBStatic_sys[i]->Lock(0,					//offset of lock start
											0,					//size of lock, ignored in this case
											&lpvAudio1,			//address of lock start
											&dwBytes1,			//number of bytes locked
											NULL,				//wrap around start, not used
											NULL,				//wrap around size, not used
											DSBLOCK_ENTIREBUFFER)))	//flags
		{
			gf_logger(true, "directsound::ds_initialization LSB failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSFillSoundBuffer;
			Close();
			ds_cleanup();
			return false;
		}
	
		UINT cbBytesRead;

		//
		if (WaveReadFile(m_hmmioIn,							//file handle
				 		 dwBytes1,							//no. of bytes to read
			 			 (BYTE *) lpvAudio1,				//destination
				 		 &m_ckIn,							//file chunk info 
						 &cbBytesRead))						//actual no. of bytes read
		{
			gf_logger(true, "directsound::ds_initialization WRF failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSFillSoundBuffer;
			Close();
			ds_cleanup();
			return false;
		}

		//unlock buffer
		lpDSBStatic_sys[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
		Close();

		delete m_pwfx;
		m_pwfx = NULL;
	}

	//---- create extra buffer for background music ----------------------------------------------

	//open wave file, 0 if okay
	if (WaveOpenFile(psoundfile_bgm, &m_hmmioIn, &m_pwfx, &m_ckInRiff) != 0)
	{
		gf_logger(true, "directsound::ds_initialization WOF BGM failed %s", psoundfile_bgm);
		//gp_ErrStr = Err_DSWaveOpenFile;
		gp_ErrStr = psoundfile_bgm;
		ds_cleanup();
		return false;
	}

	//start wave file reading
	if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
	{
		gf_logger(true, "directsound::ds_initialization WSDR BGM failed");
		gp_ErrStr = Err_DSWaveStartDataRead;
		ds_cleanup();
		return false;
	}

	//set buffer description
	memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));
	dsbdesc.dwSize = sizeof(DSBUFFERDESC);
	dsbdesc.dwFlags = DSBCAPS_STATIC |				//static buffer
					  DSBCAPS_LOCSOFTWARE |			//but create in system memory
					  DSBCAPS_CTRLPAN |				//control pan
					  DSBCAPS_CTRLVOLUME |			//control volume
					  DSBCAPS_CTRLFREQUENCY;		//control frequency
	dsbdesc.dwBufferBytes = m_ckIn.cksize;			//size of buffer in bytes
	dsbdesc.lpwfxFormat = m_pwfx;					//address of structure specifying the waveform format for buffer

	//create buffers
	if (FAILED(lpDS->CreateSoundBuffer(&dsbdesc,			//description of surface
									   &lpDSBStatic_BGM,	//buffer
									   NULL)))				//NULL
	{
		gf_logger(true, "directsound::ds_initialization CSB BGM failed");
		gp_ErrStr = Err_DSCreateSoundBuffer;
		Close();
		ds_cleanup();
		return false; 
	}

	//log if buffer in hard- or software
	DSBCAPS scapi;
	ZeroMemory(&scapi, sizeof(DSBCAPS));
	scapi.dwSize = sizeof(DSBCAPS);
	lpDSBStatic_BGM->GetCaps(&scapi);
	if ((scapi.dwFlags & DSBCAPS_LOCHARDWARE) != 0)
		gf_logger(false, "LOCHARDWARE BGM");
	else
		gf_logger(false, "LOCSOFTWARE BGM");

	LPVOID lpvAudio1;
	DWORD  dwBytes1;

	//lock buffer and fill it with wave audio data
	if (FAILED(lpDSBStatic_BGM->Lock(0,							//offset of lock start
									 0,							//size of lock, ignored in this case
									 &lpvAudio1,				//address of lock start
									 &dwBytes1,					//number of bytes locked
									 NULL,						//wrap around start, not used
									 NULL,						//wrap around size, not used
									 DSBLOCK_ENTIREBUFFER)))	//flags
	{
		gf_logger(true, "directsound::ds_initialization LSB BGM failed");
		gp_ErrStr = Err_DSFillSoundBuffer;
		Close();
		ds_cleanup();
		return false;
	}
	
	UINT cbBytesRead;

	//
	if (WaveReadFile(m_hmmioIn,							//file handle
			 		 dwBytes1,							//no. of bytes to read
		 			 (BYTE *) lpvAudio1,				//destination
			 		 &m_ckIn,							//file chunk info 
					 &cbBytesRead))						//actual no. of bytes read
	{
		gf_logger(true, "directsound::ds_initialization WRF BGM failed");
		gp_ErrStr = Err_DSFillSoundBuffer;
		Close();
		ds_cleanup();
		return false;
	}

	//unlock buffer
	lpDSBStatic_BGM->Unlock(lpvAudio1, dwBytes1, NULL, 0);
	Close();

	delete m_pwfx;
	m_pwfx = NULL;

	gf_logger(false, "directsound::ds_initialization done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directsound restore function
//
//	restores previously created buffers and reloades wave files
//
//------------------------------------------------------------------------------------------------

bool directsound::ds_restore()
{
	//if no sound available return
	//if (sound_sys == 0)
	if (p_option->dataDEF.sound == 0)
		return false;

	//restore soundbuffers
	for (register int i = 0; i < NSBS; ++i)
	{
		hRet = lpDSBStatic_sys[i]->Restore();
		if (hRet != DS_OK)
		{
			gf_logger(true, "directsound::ds_restore failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSRestore;
			ds_cleanup();
			return false;
		}
	}
	for (i = 0; i < NSBP; ++i)
	{
		hRet = lpDSBStatic_P1[i]->Restore();
		if (hRet != DS_OK)
		{
			gf_logger(true, "directsound::ds_restore failed %s", psoundfile_p[i]);
			gp_ErrStr = Err_DSRestore;
			ds_cleanup();
			return false;
		}

		hRet = lpDSBStatic_P2[i]->Restore();
		if (hRet != DS_OK)
		{
			gf_logger(true, "directsound::ds_restore failed %s", psoundfile_p[i]);
			gp_ErrStr = Err_DSRestore;
			ds_cleanup();
			return false;
		}
	}

/*	//restore bgm soundbuffer
	hRet = lpDSBStatic_BGM->Restore();
	if (hRet != DS_OK)
	{
		gf_logger("directsound::ds_restore failed", "BGM", true);
		gp_ErrStr = Err_DSRestore;
		ds_cleanup();
		return false;
	}*/

	//---- reopen, reread all wave files and fill buffers with the wave data ---------------------

	for (i = 0; i < NSBS; ++i)
	{
		//open wave file, 0 if okay

		//---- system sounds ---------------------------------------------------------------------

		if (WaveOpenFile(psoundfile_sys[i], &m_hmmioIn, &m_pwfx, &m_ckInRiff) != 0)
		{
			gf_logger(true, "directsound::ds_restore WOF failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSWaveOpenFile;
			ds_cleanup();
			return false;
		}

		//start wave file reading
		if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
		{
			gf_logger(true, "directsound::ds_restore WSDR failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSWaveStartDataRead;
			ds_cleanup();
			return false;
		}

		LPVOID lpvAudio1;
		DWORD  dwBytes1;

		//lock buffer and fill it with wave audio data
		if (FAILED(lpDSBStatic_sys[i]->Lock(0,					//offset of lock start
											0,					//size of lock, ignored in this case
											&lpvAudio1,			//address of lock start
											&dwBytes1,			//number of bytes locked
											NULL,				//wrap around start, not used
											NULL,				//wrap around size, not used
											DSBLOCK_ENTIREBUFFER)))	//flags
		{
			gf_logger(true, "directsound::ds_restore LSB failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSFillSoundBuffer;
			Close();
			ds_cleanup();
			return false;
		}
	
		UINT cbBytesRead;

		//
		if (WaveReadFile(m_hmmioIn,							//file handle
				 		 dwBytes1,							//no. of bytes to read
			 			 (BYTE *) lpvAudio1,				//destination
				 		 &m_ckIn,							//file chunk info 
						 &cbBytesRead))						//actual no. of bytes read
		{
			gf_logger(true, "directsound::ds_restore WRF failed %s", psoundfile_sys[i]);
			gp_ErrStr = Err_DSFillSoundBuffer;
			Close();
			ds_cleanup();
			return false;
		}

		//unlock buffer
		lpDSBStatic_sys[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
		Close();

		delete m_pwfx;
		m_pwfx = NULL;
	}

	//---- player sounds -------------------------------------------------------------------------

	//for both players
	for (register int p = 0; p < 2; ++p)
		for (register int i = 0; i < NSBP; ++i)
		{
			HRESULT		hRet;

			//open wave file, 0 if okay
			hRet		= WaveOpenFile(psoundfile_p[i], &m_hmmioIn, &m_pwfx, &m_ckInRiff);

			if (hRet != S_OK)
			{
				gf_logger(true, "directsound::ds_initialization WOF failed %s", psoundfile_p[i]);
				//gp_ErrStr = Err_DSWaveOpenFile;
				gp_ErrStr = psoundfile_p[i];
				ds_cleanup();
				return false;
			}

			//start wave file reading
			if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
			{
				gf_logger(true, "directsound::ds_initialization WSDR failed %s", psoundfile_p[i]);
				gp_ErrStr = Err_DSWaveStartDataRead;
				ds_cleanup();
				return false;
			}

			LPVOID lpvAudio1;
			DWORD  dwBytes1;

			//lock buffer and fill it with wave audio data
			if (p == 0)
			{
				if (FAILED(lpDSBStatic_P1[i]->Lock(0,					//offset of lock start
												   0,					//size of lock, ignored in this case
												   &lpvAudio1,			//address of lock start
												   &dwBytes1,			//number of bytes locked
												   NULL,				//wrap around start, not used
												   NULL,				//wrap around size, not used
												   DSBLOCK_ENTIREBUFFER)))	//flags
				{
					gf_logger(true, "directsound::ds_initialization LSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSFillSoundBuffer;
					Close();
					ds_cleanup();
					return false;
				}
			}
			else
			{
				if (FAILED(lpDSBStatic_P2[i]->Lock(0,					//offset of lock start
												   0,					//size of lock, ignored in this case
												   &lpvAudio1,			//address of lock start
												   &dwBytes1,			//number of bytes locked
												   NULL,				//wrap around start, not used
												   NULL,				//wrap around size, not used
												   DSBLOCK_ENTIREBUFFER)))	//flags
				{
					gf_logger(true, "directsound::ds_initialization LSB failed %s", psoundfile_p[i]);
					gp_ErrStr = Err_DSFillSoundBuffer;
					Close();
					ds_cleanup();
					return false;
				}
			}
		
			UINT cbBytesRead;

			//
			if (WaveReadFile(m_hmmioIn,							//file handle
				 			 dwBytes1,							//no. of bytes to read
			 				 (BYTE *) lpvAudio1,				//destination
				 			 &m_ckIn,							//file chunk info 
							 &cbBytesRead))						//actual no. of bytes read
			{
				gf_logger(true, "directsound::ds_initialization WRF failed %s", psoundfile_p[i]);
				gp_ErrStr = Err_DSFillSoundBuffer;
				Close();
				ds_cleanup();
				return false;
			}

			//unlock buffer
			if (p == 0)
				lpDSBStatic_P1[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
			else
				lpDSBStatic_P2[i]->Unlock(lpvAudio1, dwBytes1, NULL, 0);
			Close();

			delete m_pwfx;
			m_pwfx = NULL;
		}

	//---- create extra buffer for background music ----------------------------------------------

	//open wave file, 0 if okay
	if (WaveOpenFile(psoundfile_bgm, &m_hmmioIn, &m_pwfx, &m_ckInRiff) != 0)
	{
		gf_logger(true, "directsound::ds_restore WOF BGM failed %s", psoundfile_bgm);
		gp_ErrStr = Err_DSWaveOpenFile;
		ds_cleanup();
		return false;
	}

	//start wave file reading
	if (WaveStartDataRead(&m_hmmioIn, &m_ckIn, &m_ckInRiff) != 0)
	{
		gf_logger(true, "directsound::ds_restore WSDR BGM failed %s", psoundfile_bgm);
		gp_ErrStr = Err_DSWaveStartDataRead;
		ds_cleanup();
		return false;
	}

	//set buffer description
	memset(&dsbdesc, 0, sizeof(DSBUFFERDESC));
	dsbdesc.dwSize = sizeof(DSBUFFERDESC);
	dsbdesc.dwFlags = DSBCAPS_STATIC |				//static buffer
					  DSBCAPS_LOCSOFTWARE |			//but create in system memory
					  DSBCAPS_CTRLPAN |				//control pan
					  DSBCAPS_CTRLVOLUME |			//control volume
					  DSBCAPS_CTRLFREQUENCY;		//control frequency
	dsbdesc.dwBufferBytes = m_ckIn.cksize;			//size of buffer in bytes
	dsbdesc.lpwfxFormat = m_pwfx;					//address of structure specifying the waveform format for buffer

	//create buffers
	if (FAILED(lpDS->CreateSoundBuffer(&dsbdesc,			//description of surface
									   &lpDSBStatic_BGM,	//buffer
									   NULL)))				//NULL
	{
		gf_logger(true, "directsound::ds_restore CSB BGM failed %s", psoundfile_bgm);
		gp_ErrStr = Err_DSCreateSoundBuffer;
		Close();
		ds_cleanup();
		return false; 
	}

	LPVOID lpvAudio1;
	DWORD  dwBytes1;

	//lock buffer and fill it with wave audio data
	if (FAILED(lpDSBStatic_BGM->Lock(0,							//offset of lock start
									 0,							//size of lock, ignored in this case
									 &lpvAudio1,				//address of lock start
									 &dwBytes1,					//number of bytes locked
									 NULL,						//wrap around start, not used
									 NULL,						//wrap around size, not used
									 DSBLOCK_ENTIREBUFFER)))	//flags
	{
		gf_logger(true, "directsound::ds_restore LSB BGM failed %s", psoundfile_bgm);
		gp_ErrStr = Err_DSFillSoundBuffer;
		Close();
		ds_cleanup();
		return false;
	}
	
	UINT cbBytesRead;

	//
	if (WaveReadFile(m_hmmioIn,							//file handle
			 		 dwBytes1,							//no. of bytes to read
		 			 (BYTE *) lpvAudio1,				//destination
			 		 &m_ckIn,							//file chunk info 
					 &cbBytesRead))						//actual no. of bytes read
	{
		gf_logger(true, "directsound::ds_restore WRF BGM failed %s", psoundfile_bgm);
		gp_ErrStr = Err_DSFillSoundBuffer;
		Close();
		ds_cleanup();
		return false;
	}

	//unlock buffer
	lpDSBStatic_BGM->Unlock(lpvAudio1, dwBytes1, NULL, 0);
	Close();

	delete m_pwfx;
	m_pwfx = NULL;

	gf_logger(false, "directsound::ds_restore done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directsound cleanup
//
//	frees directsound interfaces
//
//------------------------------------------------------------------------------------------------

void directsound::ds_cleanup()
{
	if (m_pwfx)
	{
		delete m_pwfx;
		m_pwfx = NULL;
	}

	if (lpDS != NULL)
	{
		/*!!
		//stop all buffers from playing
		stopbuffer(-1);
		//stop bgm
		stopbgm(true);*/

		//release buffers
		for (register int i = 0; i < NSBS; ++i)
			if (lpDSBStatic_sys[i] != NULL)
			{
				lpDSBStatic_sys[i]->Release();
				lpDSBStatic_sys[i]	= NULL;
			}
		//player sounds
		for (i = 0; i < NSBP; ++i)
		{
			if (lpDSBStatic_P1[i] != NULL)
			{
				lpDSBStatic_P1[i]->Release();
				lpDSBStatic_P1[i]	= NULL;
			}
			if (lpDSBStatic_P2[i] != NULL)
			{
				lpDSBStatic_P2[i]->Release();
				lpDSBStatic_P2[i]	= NULL;
			}
		}

		//release bgm buffer
		if (lpDSBStatic_BGM != NULL)
		{
			lpDSBStatic_BGM->Release();
			lpDSBStatic_BGM = NULL;
		}

		//release ds-object
		lpDS->Release();
		lpDS = NULL;
	}

	gf_logger(false, "directsound::ds_cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	directsound set_data_pointer
//
//	fills pointer to timer/option data
//
//------------------------------------------------------------------------------------------------

void directsound::set_data_pointer(options *_options, timer *_timer, hud_text *_hud)
{
	p_option			= _options;
	p_time				= _timer;
	p_hud_text			= _hud;
}

//------------------------------------------------------------------------------------------------
//
//	directsound ReadMMIO
//
//	support function for reading from a multimedia i/o stream
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::ReadMMIO(HMMIO hmmioIn,
							  MMCKINFO* pckInRIFF,
							  WAVEFORMATEX** ppwfxInfo)
{
	MMCKINFO			ckIn;			//chunk info. for general use
	PCMWAVEFORMAT		pcmWaveFormat;	//temp PCM structure to load in

    *ppwfxInfo = NULL;

	if ((0 != mmioDescend(hmmioIn, pckInRIFF, NULL, 0)))
		return E_FAIL;

	if ((pckInRIFF->ckid != FOURCC_RIFF) ||
		(pckInRIFF->fccType != mmioFOURCC('W', 'A', 'V', 'E')))
		return E_FAIL;

	//search the input file for for the 'fmt ' chunk
	ckIn.ckid = mmioFOURCC('f', 'm', 't', ' ');
	if (0 != mmioDescend(hmmioIn, &ckIn, pckInRIFF, MMIO_FINDCHUNK))
		return E_FAIL;

	//expect the 'fmt' chunk to be at least as large as <PCMWAVEFORMAT>
	//if there are extra parameters at the end, we'll ignore them
	if (ckIn.cksize < (LONG) sizeof(PCMWAVEFORMAT))
		return E_FAIL;

	//read the 'fmt ' chunk into <pcmWaveFormat>
	if (mmioRead(hmmioIn, (HPSTR) &pcmWaveFormat,
				 sizeof(pcmWaveFormat)) != sizeof(pcmWaveFormat))
		return E_FAIL;

	//allocate the waveformatex, but if its not pcm format, read the next
	//word, and thats how many extra bytes to allocate.
	if (pcmWaveFormat.wf.wFormatTag == WAVE_FORMAT_PCM)
	{
		if (NULL == (*ppwfxInfo = new WAVEFORMATEX))
			return E_FAIL;

		//copy the bytes from the pcm structure to the waveformatex structure
		memcpy(*ppwfxInfo, &pcmWaveFormat, sizeof(pcmWaveFormat));
		(*ppwfxInfo)->cbSize = 0;
	}
	else
	{
		//read in length of extra bytes.
		WORD cbExtraBytes = 0L;
		if (mmioRead(hmmioIn, (CHAR*)&cbExtraBytes, sizeof(WORD)) != sizeof(WORD))
			return E_FAIL;

		*ppwfxInfo = (WAVEFORMATEX*)new CHAR[sizeof(WAVEFORMATEX) + cbExtraBytes];
		if (NULL == *ppwfxInfo)
			return E_FAIL;

		//copy the bytes from the pcm structure to the waveformatex structure
		memcpy(*ppwfxInfo, &pcmWaveFormat, sizeof(pcmWaveFormat));
		(*ppwfxInfo)->cbSize = cbExtraBytes;

		//now, read those extra bytes into the structure, if cbExtraAlloc != 0.
		if (mmioRead(hmmioIn, (CHAR*)(((BYTE*)&((*ppwfxInfo)->cbSize))+sizeof(WORD)),
			cbExtraBytes) != cbExtraBytes)
		{
			delete *ppwfxInfo;
			*ppwfxInfo = NULL;
			return E_FAIL;
		}
	}

	//ascend the input file out of the 'fmt ' chunk.
	if (0 != mmioAscend(hmmioIn, &ckIn, 0))
	{
		delete *ppwfxInfo;
		*ppwfxInfo = NULL;
		return E_FAIL;
	}

	return S_OK;
}

//------------------------------------------------------------------------------------------------
//
//	directsound WaveOpenFile
//
//	support function for reading from a multimedia i/o stream
//
//------------------------------------------------------------------------------------------------

HRESULT	directsound::WaveOpenFile(char *strFileName,
								  HMMIO *phmmioIn,
								  WAVEFORMATEX **ppwfxInfo,
								  MMCKINFO* pckInRIFF)
{
	HRESULT			hRet;
	HMMIO			hmmioIn = NULL;

	if(NULL == (hmmioIn = mmioOpen(strFileName, NULL, MMIO_ALLOCBUF|MMIO_READ)))
		return E_FAIL;

	if(FAILED(hRet = ReadMMIO(hmmioIn, pckInRIFF, ppwfxInfo)))
	{
		mmioClose(hmmioIn, 0);
		return hRet;
	}

	*phmmioIn = hmmioIn;

	return S_OK;
}

//------------------------------------------------------------------------------------------------
//
//	directsound WaveStartDataRead
//
//	routine has to be called before WaveReadFile as it searches for the
//	chunk to descend into for reading, that is, the 'data' chunk.
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::WaveStartDataRead(HMMIO* phmmioIn,
									   MMCKINFO* pckIn,
									   MMCKINFO* pckInRIFF)
{
	//seek to the data
	if (-1 == mmioSeek(*phmmioIn, pckInRIFF->dwDataOffset + sizeof(FOURCC),
		SEEK_SET))
		return E_FAIL;

	//search the input file for for the 'data' chunk.
	pckIn->ckid = mmioFOURCC('d', 'a', 't', 'a');
	if (0 != mmioDescend(*phmmioIn, pckIn, pckInRIFF, MMIO_FINDCHUNK))
		return E_FAIL;

	return S_OK;
}

//------------------------------------------------------------------------------------------------
//	directsound WaveReadFile
//
//	reads wave data from the wave file. make sure we're descended into
//	the data chunk before calling this function.
//		hmmioIn      - handle to mmio.
//		cbRead       - # of bytes to read.   
//		pbDest       - destination buffer to put bytes.
//		cbActualRead - # of bytes actually read.
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::WaveReadFile(HMMIO hmmioIn,
								  UINT cbRead,
								  BYTE* pbDest,
								  MMCKINFO* pckIn,
								  UINT* cbActualRead)
{
	//current status of <hmmioIn>
	MMIOINFO			mmioinfoIn;

	*cbActualRead = 0;

	if (0 != mmioGetInfo(hmmioIn, &mmioinfoIn, 0))
		return E_FAIL;

	UINT cbDataIn = cbRead;
	if (cbDataIn > pckIn->cksize)
		cbDataIn = pckIn->cksize;

	pckIn->cksize -= cbDataIn;

	for (DWORD cT = 0; cT < cbDataIn; cT++)
	{
		//copy the bytes from the io to the buffer.
		if (mmioinfoIn.pchNext == mmioinfoIn.pchEndRead)
		{
			if (0 != mmioAdvance(hmmioIn, &mmioinfoIn, MMIO_READ))
				return E_FAIL;

			if (mmioinfoIn.pchNext == mmioinfoIn.pchEndRead)
				return E_FAIL;
		}

		//actual copy.
		*((BYTE*)pbDest+cT) = *((BYTE*)mmioinfoIn.pchNext);
		mmioinfoIn.pchNext++;
	}

	if (0 != mmioSetInfo(hmmioIn, &mmioinfoIn, 0))
		return E_FAIL;

	*cbActualRead = cbDataIn;
	return S_OK;
}

//------------------------------------------------------------------------------------------------
//
//	directsound open
//
//	opens a wave file for reading
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::Open(CHAR* strFilename)
{
	if (m_pwfx)
	{
		delete (m_pwfx);
		m_pwfx = NULL;
	}

	HRESULT		hr;

	if (FAILED(hr = WaveOpenFile(strFilename,
								 &m_hmmioIn,
								 &m_pwfx,
								 &m_ckInRiff)))
		return hr;

	if (FAILED(hr = Reset()))
		return hr;

	return hr;
}

//------------------------------------------------------------------------------------------------
//
//	directsound reset
//
//	resets internal m_ckIn pointer so reading starts from the beginning of the file again
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::Reset()
{
	return WaveStartDataRead(&m_hmmioIn,
							 &m_ckIn,
							 &m_ckInRiff);
}

//------------------------------------------------------------------------------------------------
//
//	directsound read
//
//	reads a wave file into a pointer and returns how much read
//	using m_ckIn to determine where to start reading from
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::Read(UINT nSizeToRead,
						  BYTE* pbData,
						  UINT* pnSizeRead)
{
	return WaveReadFile(m_hmmioIn,
						nSizeToRead,
						pbData,
						&m_ckIn,
						pnSizeRead);
}

//------------------------------------------------------------------------------------------------
//
//	directsound close
//
//	closes an open wave file
//
//------------------------------------------------------------------------------------------------

HRESULT directsound::Close()
{
	mmioClose(m_hmmioIn, 0);
	return S_OK;
}

//------------------------------------------------------------------------------------------------
//
//	directsound playbuffer
//
//	plays specified soundbuffer
//
//------------------------------------------------------------------------------------------------

void directsound::playbuffer(int b_type, int b_index, bool loop)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//system sound buffer
	if (b_type == BT_SYS)
	{
		//valid index
		if (b_index >= 0 && b_index < NSBS)
		{
			//loop
			if (!loop)
				hRet = lpDSBStatic_sys[b_index]->Play(0,				//reserved, must be 0
													  0,				//priority
													  0);				//flag DSBPLAY_LOOPING for looping
			else
				hRet = lpDSBStatic_sys[b_index]->Play(0, 0, DSBPLAY_LOOPING);

			//if buffer lost restore buffers and return
			if (hRet == DSERR_BUFFERLOST)
			{
				gf_logger(true, "directsound::playbuffer buffer lost");
				ds_restore();
				return;
			}
		}
	}

	//player buffer
	if (b_type == BT_P1 || b_type == BT_P2)
	{
		//valid index
		if (b_index >= 0 && b_index < NSBP)
		{
			//loop
			if (!loop)
				if (b_type == BT_P1)
					hRet = lpDSBStatic_P1[b_index]->Play(0, 0, 0);
				else
					hRet = lpDSBStatic_P2[b_index]->Play(0, 0, 0);
			else
				if (b_type == BT_P1)
					hRet = lpDSBStatic_P1[b_index]->Play(0, 0, DSBPLAY_LOOPING);
				else
					hRet = lpDSBStatic_P2[b_index]->Play(0, 0, DSBPLAY_LOOPING);

			//if buffer lost restore buffers and return
			if (hRet == DSERR_BUFFERLOST)
			{
				gf_logger(true, "directsound::playbuffer buffer lost");
				ds_restore();
				return;
			}
		}
	}
}

//!!
/*void directsound::playbuffer(BYTE sbufferflag[NSB])
{
	//if no sound available or sound off return
	if (sound_sys == 0 || sound_set == 0)
		return;

	//for every soundbuffer
	for (register int i = 0; i < NSB; ++i)
		if (sbufferflag[i] == 1)
		{
			hRet = lpDSBStatic_sys[i]->Play(0,				//reserved, must be 0
											0,				//priority
											0);				//flag DSBPLAY_LOOPING for looping

			//if buffer is lost, restore buffers and exit play loop
			if (hRet == DSERR_BUFFERLOST)
			{
				gf_logger("directsound::playbuffer buffer lost", NULL, true);
				ds_restore();
				break;
			}
		}
}*/

//------------------------------------------------------------------------------------------------
//
//	directsound stopbuffer
//
//	stops specified buffer, reset if argumented
//
//------------------------------------------------------------------------------------------------

void directsound::stopbuffer(int b_type, int b_index, bool reset)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//system sound buffer
	if (b_type == BT_SYS)
	{
		//valid index
		if (b_index >= 0 && b_index < NSBS)
		{
			//stop buffer
			lpDSBStatic_sys[b_index]->Stop();

			//reset if specified
			if (reset)
				lpDSBStatic_sys[b_index]->SetCurrentPosition(0L);
		}
	}

	//player buffer
	if (b_type == BT_P1 || b_type == BT_P2)
	{
		//valid index
		if (b_index >= 0 && b_index < NSBP)
		{
			if (b_type == BT_P1)
			{
				lpDSBStatic_P1[b_index]->Stop();
				if (reset)
					lpDSBStatic_P1[b_index]->SetCurrentPosition(0L);
			}
			else
			{
				lpDSBStatic_P2[b_index]->Stop();
				if (reset)
					lpDSBStatic_P2[b_index]->SetCurrentPosition(0L);
			}
		}
	}
}

//!!
/*void directsound::stopbuffer(int i)
{
	//if no sound available or sound off return
	if (sound_sys == 0 || sound_set == 0)
		return;

	//if all soundbuffers to stop
	if (i == -1)
	{
		for (register int sb = 0; sb < NSB; ++sb)
		{
			//stop buffer from playing
			lpDSBStatic_sys[sb]->Stop();

			//reset play position back to beginning
			lpDSBStatic_sys[sb]->SetCurrentPosition(0L);
		}
	}
	else
	//if only indexed buffer to stop
	{
		//stop buffer from playing
		lpDSBStatic_sys[i]->Stop();

		//reset play position back to beginning
		lpDSBStatic_sys[i]->SetCurrentPosition(0L);
	}
}*/

//------------------------------------------------------------------------------------------------
//
//	directsound playbgm
//
//	plays backgroundmusic buffer
//
//------------------------------------------------------------------------------------------------

void directsound::playbgm(bool loop)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	if (!loop)
		hRet = lpDSBStatic_BGM->Play(0,					//reserved, must be 0
									 0,					//priority
									 0);				//flag DSBPLAY_LOOPING for looping
	else
		hRet = lpDSBStatic_BGM->Play(0,					//reserved, must be 0
									 0,					//priority
									 DSBPLAY_LOOPING);	//flag DSBPLAY_LOOPING for looping

	//if buffer is lost, restore buffers and exit play loop
	if (hRet == DSERR_BUFFERLOST)
	{
		gf_logger(true, "directsound::playbuffer buffer lost");
		ds_restore();
		return;
	}
}

//------------------------------------------------------------------------------------------------
//
//	directsound stopbgm
//
//	stops playing background music buffer and resets the buffer according to argument
//
//------------------------------------------------------------------------------------------------

void directsound::stopbgm(bool reset)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//stop buffer from playing
	lpDSBStatic_BGM->Stop();

	//if bgm to reset, reset
	if (reset)
		lpDSBStatic_BGM->SetCurrentPosition(0L);
}

//------------------------------------------------------------------------------------------------
//
//	directsound getcurrentposition
//
//	returns current play position of argumented soundbuffer
//	if error returns -1
//
//------------------------------------------------------------------------------------------------

unsigned long directsound::getcurrentposition(int b_type, int b_index)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return(-1);

	//holds play position
	unsigned long		position = 0;

	//system sound
	if (b_type == BT_SYS)
	{
		//get and return play position
		if (b_type >= 0 && b_type < NSBS)
			lpDSBStatic_sys[b_index]->GetCurrentPosition(&position, NULL);	//read, write address
		else
			return -1;
	}

	//player sound
	if (b_type == BT_P1)
	{
		//get and return play position
		if (b_type >= 0 && b_type < NSBP)
			lpDSBStatic_P1[b_index]->GetCurrentPosition(&position, NULL);	//read, write address
		else
			return -1;
	}

	if (b_type == BT_P2)
	{
		//get and return play position
		if (b_type >= 0 && b_type < NSBP)
			lpDSBStatic_P2[b_index]->GetCurrentPosition(&position, NULL);	//read, write address
		else
			return -1;
	}

	//bgm
	if (b_type == BT_BGM)
	{
		//get and return play position
		lpDSBStatic_BGM->GetCurrentPosition(&position, NULL);	//read, write address
	}

	//return position
	return position;

//!!
/*	//if position of backgroundmusic buffer
	if (i == -1)
	{
		//get and return play position
		lpDSBStatic_BGM->GetCurrentPosition(&position, NULL);

		return position;
	}

	//regular sound buffer
	if (i >= 0 && i < NSB)
	{
		lpDSBStatic_sys[i]->GetCurrentPosition(&position, NULL);

		return position;
	}
	else
		return -1;*/
}

//------------------------------------------------------------------------------------------------
//
//	directsound setpan
//
//	sets pan of soundbuffers
//	-10.000 to 10.000 (hundreth decibel)
//
//------------------------------------------------------------------------------------------------

void directsound::setpan(int b_type, int pan)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//system soundbuffer
	if (b_type == BT_SYS)
		for (register int i = 0; i < NSBS; ++i)
			lpDSBStatic_sys[i]->SetPan(pan);

	//player soundbuffer
	if (b_type == BT_P1)
		for (register int i = 0; i < NSBP; ++i)
			lpDSBStatic_P1[i]->SetPan(pan);

	if (b_type == BT_P2)
		for (register int i = 0; i < NSBP; ++i)
			lpDSBStatic_P2[i]->SetPan(pan);

	//bgm buffer
	if (b_type == BT_BGM)
		lpDSBStatic_BGM->SetPan(pan);

//!!
/*	//if no sound available or sound off return
	if (sound_sys == 0 || sound_set == 0)
		return;

	//first half of buffers for player1 rest for player2

	//-10.000 to 10.000 (hundreth decibel)

	for (register int i = 0; i < (NSB / 2); ++i)
		lpDSBStatic_sys[i]->SetPan(pan1);

	for (i = (NSB / 2); i < NSB; ++i)
		lpDSBStatic_sys[i]->SetPan(pan2);*/
}

//------------------------------------------------------------------------------------------------
//
//	directsound setvolume
//
//	sets volume of specified sound buffer
//
//------------------------------------------------------------------------------------------------

void directsound::setvolume(int b_type, int b_index, int volume)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//volume limits
	if (volume > 0)			volume = 0;
	if (volume < -10000)	volume = -10000;

	//system soundbuffer
	if (b_type == BT_SYS)
		if (b_index >= 0 && b_index < NSBS)
			lpDSBStatic_sys[b_index]->SetVolume(volume);

	//player soundbuffer
	if (b_type == BT_P1)
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P1[b_index]->SetVolume(volume);

	if (b_type == BT_P2)
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P2[b_index]->SetVolume(volume);

	//bgm buffer
	if (b_type == BT_BGM)
		lpDSBStatic_BGM->SetVolume(volume);

	//all buffers
	if (b_type == BT_ALL)
	{
		for (register int i = 0; i < NSBS; ++i)
			lpDSBStatic_sys[i]->SetVolume(volume);

		for (i = 0; i < NSBP; ++i)
		{
			lpDSBStatic_P1[i]->SetVolume(volume);
			lpDSBStatic_P2[i]->SetVolume(volume);
		}

		lpDSBStatic_BGM->SetVolume(volume);
	}

/*	//set volume of buffer
	if (i >= 0 && i < NSB)
		lpDSBStatic_sys[i]->SetVolume(volume);

	//backgroundmusic
	if (i == -1)
		lpDSBStatic_BGM->SetVolume(volume);*/
}

//------------------------------------------------------------------------------------------------
//
//	directsound getvolume
//
//	returns volume of specified sound buffer
//	returns 1 if fails
//
//------------------------------------------------------------------------------------------------

long directsound::getvolume(int b_type, int b_index)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return (1);

	//holds volume
	long	volume = 0;

	//system soundbuffer
	if (b_type == BT_SYS)
		if (b_index >= 0 && b_index < NSBS)
			lpDSBStatic_sys[b_index]->GetVolume(&volume);

	//player soundbuffer
	if (b_type == BT_P1)
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P1[b_index]->GetVolume(&volume);

	if (b_type == BT_P2)
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P2[b_index]->GetVolume(&volume);

	//bgm buffer
	if (b_type == BT_BGM)
		lpDSBStatic_BGM->GetVolume(&volume);

/*	//get volume of buffer
	if (i >= 0 && i < NSB)
		lpDSBStatic_sys[i]->GetVolume(&volume);

	//backgroundmusic
	if (i == -1)
		lpDSBStatic_BGM->GetVolume(&volume);*/

	return(volume);
}

//------------------------------------------------------------------------------------------------
//
//	directsound setfrequency
//
//	sets frequency of sound buffers according to user set speed of game
//
//------------------------------------------------------------------------------------------------

void directsound::setfrequency(int b_type, int b_index, float s_speed)
{
	//if no sound available or sound off return
	//if (sound_sys == 0 || sound_set == 0)
	if (p_option->dataDEF.sound == 0 || p_option->data.sound == 0)
		return;

	//system sound
	if (b_type == BT_SYS || b_type == BT_ALL)
	{
		//only specified buffer
		if (b_index >= 0 && b_index < NSBS)
			lpDSBStatic_sys[b_index]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
		//or
		//all buffers of buffer type
		if (b_index == -1)
			for (register int i = 0; i < NSBS; ++i)
				lpDSBStatic_sys[i]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
	}

	//player sound
	if (b_type == BT_P1 || b_type == BT_ALL)
	{
		//only specified buffer
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P1[b_index]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
		//or
		//all buffers of buffer type
		if (b_index == -1)
			for (register int i = 0; i < NSBP; ++i)
				lpDSBStatic_P1[i]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
	}

	if (b_type == BT_P2 || b_type == BT_ALL)
	{
		//only specified buffer
		if (b_index >= 0 && b_index < NSBP)
			lpDSBStatic_P2[b_index]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
		//or
		//all buffers of buffer type
		if (b_index == -1)
			for (register int i = 0; i < NSBP; ++i)
				lpDSBStatic_P2[i]->SetFrequency(unsigned long(FREQ_STANDARD * s_speed));
	}

	//bgm
	if (b_type == BT_BGM || b_type == BT_ALL)
	{
		lpDSBStatic_BGM->SetFrequency(unsigned long(FREQ_BGM * s_speed));
	}
}

//------------------------------------------------------------------------------------------------
//
//	directsound freq_process
//
//	adjusts frequency of sound buffers if ingame speed changed
//
//------------------------------------------------------------------------------------------------

void directsound::freq_process()
{
	//if ingame speed changed
	if (freq_speed_last != p_option->data.speed)
	{
		//set current speed
		freq_speed_last = p_option->data.speed;

		//set frequency of both player's soundbuffers
		setfrequency(BT_P1, -1, p_option->data.speed);
		setfrequency(BT_P2, -1, p_option->data.speed);

		//hud message
//		if (DEVELOPER_)
//			hud_add_message(0, bmfgreen, "ds::freq_process %.2f", p_option->data.speed);
	}
}

//------------------------------------------------------------------------------------------------
//
//	directsound RegisterConVars
//
//	registers console variable
//
//------------------------------------------------------------------------------------------------

void directsound::RegisterConVars(console *pcon)
{
//	CLASS_CVI(int, mainvolume, 5000, 0, 1000, 0);
}

//------------------------------------------------------------------------------------------------
//
//	directsound con_add_message
//
//	adds message to console
//
//------------------------------------------------------------------------------------------------

void directsound::con_add_message(char *format, ...)
{
	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	//clear message dump
	con_clear();

	//print formated string in console dump message
    vsprintf(con_dumpmessage, format, ap);

	//clear up
	va_end(ap);
}

//------------------------------------------------------------------------------------------------
//
//	directsound con_clear
//
//	clears console message buffer
//
//------------------------------------------------------------------------------------------------

void directsound::con_clear()
{
	ZeroMemory(&con_dumpmessage, sizeof(con_dumpmessage));
}

//------------------------------------------------------------------------------------------------
//
//	directsound hud_add_message
//
//------------------------------------------------------------------------------------------------

void directsound::hud_add_message(int _hud_id, int color, char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "directsound::hud_add_message NULL");
		return;
	}

	//verify id
	if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
	if (_hud_id < 0)				_hud_id = 0;

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	directsound hud_add_message
//
//------------------------------------------------------------------------------------------------

void directsound::hud_add_message(char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "directsound::hud_add_message NULL");
		return;
	}

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//default values
	int _hud_id		= 0;
	int color		= bmfblack;

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}
