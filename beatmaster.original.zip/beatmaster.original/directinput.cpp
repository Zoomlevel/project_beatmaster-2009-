//------------------------------------------------------------------------------------------------
//
//	directinput class definitions
//
//------------------------------------------------------------------------------------------------

#include "directinput.h"			//class declaration header

//------------------------------------------------------------------------------------------------
//
//	directinput contstructor
//
//------------------------------------------------------------------------------------------------

directinput::directinput()
{
	//initialize directinput objects
	lpDI7				= NULL;
	lpDIKeyboard		= NULL;
	lpDISysMouse		= NULL;
	lpDIMouse01			= NULL;
	lpDIMouse02			= NULL;
	lpDIController01	= NULL;
	lpDIController02	= NULL;

	ZeroMemory(&guid_mouse01, sizeof(guid_mouse01));
	ZeroMemory(&guid_mouse02, sizeof(guid_mouse02));
	ZeroMemory(&guid_controller01, sizeof(guid_controller01));
	ZeroMemory(&guid_controller02, sizeof(guid_controller02));

	//---- console -------------------------------------------------------------------------------

	//clear console message buffer
//	con_clear();

	gf_logger(false, "directinput::directinput done");
}

//------------------------------------------------------------------------------------------------
//
//	directinput initialization
//	return values: 0 = ok, 1 = error (ex: no system mouse), 2 = not two usb mice
//
//------------------------------------------------------------------------------------------------

int directinput::di_initialization(HWND hwnd, options &option)
{
	//---- create instance of latest directinput-object ------------------------------------------

	hRet = DirectInputCreateEx(GetModuleHandle(NULL),	//get instance of application
							   DIRECTINPUT_VERSION,		//directinput version
							   IID_IDirectInput7,		//UID for desired dinput interface
							   (void**)&lpDI7,			//pointer to receive object
							   NULL);					//NULL if interface is not aggregated
	if (hRet != DI_OK)
	{
		gf_logger(true, "directinput::di_initialization DICE failed");
		gp_ErrStr = Err_DIDirectInputCreateEx;
		di_cleanup();
		return(1);
	}

	//---- create system keyboard ----------------------------------------------------------------

	hRet = lpDI7->CreateDeviceEx(GUID_SysKeyboard,			//GUID for the desired input device, here: pre-defined system keyboard
								 IID_IDirectInputDevice7,	//unique identifier for the desired interface
								 (void**)&lpDIKeyboard,		//pointer to get object address
								 NULL);						//NULL if the interface is not aggregated
	if (hRet != DI_OK)
	{
		gf_logger(true, "directinput::di_initialization CDE SysKeyboard failed");
		gp_ErrStr = Err_DICreateDeviceExKB;
		di_cleanup();
		return(1);
	}

	//---- raw mouse setup -----------------------------------------------------------------------

	if (INPUTTYPE == IP_RAW)
	{
		if (!RI.setup(option))
		{
			gf_logger(true, "directinput::di_initialization Raw Input Setup FAILED");
			//continue setup
		}
		else
		{
			gf_logger(false, "directinput::di_initialization Raw Input Setup DONE");
		}
	}

	//---- enumerate mice ------------------------------------------------------------------------
	//if no system mouse is found, program exits
	//if only system mouse is found and no other or only one usb-mouse
	//is found, set option.data/DEF.mouse flag to 0
	//and use system mouse as gaming mouse (no 2 player mode)

	if (INPUTTYPE == IP_DI)
	{
		//enumerate all mice
		lpDI7->EnumDevices(DIDEVTYPE_MOUSE,			//devices to enumerate
						   DIEnumDCallback,			//function to call for every device found
						   0,						//32-bit value to be passed to callback function
						   DIEDFL_ATTACHEDONLY);	//flag which devices to enumerate

		//indicates if two usb mice exist (1) or not (0)
		option.dataDEF.mouseflag = 0;

		//check if two usb mice exist after enumeration
		if (guid_mouse02.Data1 == NULL && guid_mouse02.Data2 == NULL &&	guid_mouse02.Data3 == NULL)
			option.dataDEF.mouseflag = 1;
		else
			option.dataDEF.mouseflag = 2;

		//---- create all mice -----------------------------------------------------------------------

		//create system mouse
		hRet = lpDI7->CreateDeviceEx(GUID_SysMouse,
									 IID_IDirectInputDevice7,
									 (void**)&lpDISysMouse,
									 NULL);
		//if creating system mouse fails, exit program
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization CDE SysMouse failed");
			gp_ErrStr = Err_DICreateDeviceExSM;
			di_cleanup();
			return(1);
		}

		//if two usb mice found, create the two
		//!!!
		//possiblitiy that two mice exist, but something goes
		//wrong creating them and instead of exiting just using system mouse?
		if (option.dataDEF.mouseflag == 2)
		{
			hRet = lpDI7->CreateDeviceEx(guid_mouse01,
										 IID_IDirectInputDevice7,
										(void**)&lpDIMouse01,
										NULL);
			if (hRet != DI_OK)
			{
				gf_logger(true, "directinput::di_initialization CDE guid_mouse01 failed");
				gp_ErrStr = Err_DICreateDeviceExM1;
				di_cleanup();
				return(1);
			}
			
			hRet = lpDI7->CreateDeviceEx(guid_mouse02,
										 IID_IDirectInputDevice7,
										 (void**)&lpDIMouse02,
										 NULL);
			if (hRet != DI_OK)
			{
				gf_logger(true, "directinput::di_initialization CDE guid_mouse02 failed");
				gp_ErrStr = Err_DICreateDeviceExM2;
				di_cleanup();
				return(1);
			}
		}
	}

	//---- enumerate controllers -----------------------------------------------------------------

	//enumerate up to two controllers
	lpDI7->EnumDevices(DIDEVTYPE_JOYSTICK,
					   DIEnumJoystickCallback,
					   0,
					   DIEDFL_ATTACHEDONLY);

	//indicates if two controllers exist (1) or not (0)
	option.dataDEF.controllerflag	= 0;

	//one controller available
	if (guid_controller01.Data1 != NULL && guid_controller01.Data2 != NULL &&
		guid_controller01.Data3 != NULL)
	{
		option.dataDEF.controllerflag	= 1;

		//two controller available
		if (guid_controller02.Data1 != NULL && guid_controller02.Data2 != NULL &&
			guid_controller02.Data3 != NULL)
			option.dataDEF.controllerflag	= 2;
	}

	//---- create controllers --------------------------------------------------------------------

	if (option.dataDEF.controllerflag >= 1)
	{
		hRet = lpDI7->CreateDeviceEx(guid_controller01,
									 IID_IDirectInputDevice7,
									(void**)&lpDIController01,
									NULL);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization CDE guid_controller01 failed");
			//gp_ErrStr = Err_DICreateDeviceExM1;
			di_cleanup();
			return(1);
		}
	}
	if (option.dataDEF.controllerflag >= 2)
	{
		hRet = lpDI7->CreateDeviceEx(guid_controller02,
									 IID_IDirectInputDevice7,
									(void**)&lpDIController02,
									NULL);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization CDE guid_controller02 failed");
			//gp_ErrStr = Err_DICreateDeviceExM1;
			di_cleanup();
			return(1);
		}
	}

	//---- set cooperative level of all di devices -----------------------------------------------

	hRet = lpDIKeyboard->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND | DISCL_NOWINKEY);
	if (hRet != DI_OK)
	{
		gf_logger(true, "directinput::di_initialization SCL SysKeyboard failed");
		gp_ErrStr = Err_DISetCooperativeLevel;
		di_cleanup();
		return(1);
	}

	if (lpDISysMouse != NULL)
	{
		hRet = lpDISysMouse->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
//		hRet = lpDISysMouse->SetCooperativeLevel(hwnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SCL SysMouse failed");
			gp_ErrStr = Err_DISetCooperativeLevel;
			di_cleanup();
			return(1);
		}
	}

	//if two usb mice exist
	if (option.dataDEF.mouseflag == 2)
	{
		hRet = lpDIMouse01->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
//		hRet = lpDIMouse01->SetCooperativeLevel(hwnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SCL mouse01 failed");
			gp_ErrStr = Err_DISetCooperativeLevel;
			di_cleanup();
			return(1);
		}

		hRet = lpDIMouse02->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
//		hRet = lpDIMouse02->SetCooperativeLevel(hwnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SCL mouse02 failed");
			gp_ErrStr = Err_DISetCooperativeLevel;
			di_cleanup();
			return(1);
		}
	}

	//controllers
	if (option.dataDEF.controllerflag >= 1)
	{
		hRet = lpDIController01->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SCL controller01 failed");
			gp_ErrStr = Err_DISetCooperativeLevel;
			di_cleanup();
			return(1);
		}
	}
	if (option.dataDEF.controllerflag >= 2)
	{
		hRet = lpDIController02->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SCL controller02 failed");
			gp_ErrStr = Err_DISetCooperativeLevel;
			di_cleanup();
			return(1);
		}
	}

	//---- set data format -----------------------------------------------------------------------

	hRet = lpDIKeyboard->SetDataFormat(&c_dfDIKeyboard);
	if (hRet != DI_OK)
	{
		gf_logger(true, "directinput::di_initialization SDF SysKeyboard failed");
		gp_ErrStr = Err_DISetDataFormatKB;
		di_cleanup();
		return(1);
	}

	if (lpDISysMouse != NULL)
	{
		hRet = lpDISysMouse->SetDataFormat(&c_dfDIMouse);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SDF SysMouse failed");
			gp_ErrStr = Err_DISetDataFormatM;
			di_cleanup();
			return(1);
		}
	}

	//if two usb mice exist
	if (option.dataDEF.mouseflag == 2)
	{
		hRet = lpDIMouse01->SetDataFormat(&c_dfDIMouse);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SDF mouse01 failed");
			gp_ErrStr = Err_DISetDataFormatM;
			di_cleanup();
			return(1);
		}

		hRet = lpDIMouse02->SetDataFormat(&c_dfDIMouse);
		if (hRet != DI_OK)
		{
			gf_logger(true, "directinput::di_initialization SDF mouse02 failed");
			gp_ErrStr = Err_DISetDataFormatM;
			di_cleanup();
			return(1);
		}
	}

	//controllers
	if (option.dataDEF.controllerflag >= 1)
	{
		hRet = lpDIController01->SetDataFormat(&c_dfDIJoystick);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SDF controller01 failed");
			gp_ErrStr = Err_DISetDataFormatM;
			di_cleanup();
			return(1);
		}

		//set property data (axis range, deathzone)
		DIPROPRANGE	diprg;

		diprg.diph.dwSize			= sizeof(diprg);
		diprg.diph.dwHeaderSize		= sizeof(diprg.diph);
		diprg.diph.dwObj			= DIJOFS_X;
		diprg.diph.dwHow			= DIPH_BYOFFSET;
		diprg.lMin					= -100;
		diprg.lMax					= +100;

		hRet = lpDIController01->SetProperty(DIPROP_RANGE, &diprg.diph);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SPX controller01 failed");
			di_cleanup();
			return(1);
		}
		diprg.diph.dwObj			= DIJOFS_Y;
		hRet = lpDIController01->SetProperty(DIPROP_RANGE, &diprg.diph);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SPY controller01 failed");
			di_cleanup();
			return(1);
		}
	}
	if (option.dataDEF.controllerflag >= 2)
	{
		hRet = lpDIController02->SetDataFormat(&c_dfDIJoystick);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SDF controller02 failed");
			gp_ErrStr = Err_DISetDataFormatM;
			di_cleanup();
			return(1);
		}

		//set property data (axis range, deathzone)
		DIPROPRANGE	diprg;

		diprg.diph.dwSize			= sizeof(diprg);
		diprg.diph.dwHeaderSize		= sizeof(diprg.diph);
		diprg.diph.dwObj			= DIJOFS_X;
		diprg.diph.dwHow			= DIPH_BYOFFSET;
		diprg.lMin					= -100;
		diprg.lMax					= +100;

		hRet = lpDIController02->SetProperty(DIPROP_RANGE, &diprg.diph);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SP controller02 failed");
			di_cleanup();
			return(1);
		}
		diprg.diph.dwObj			= DIJOFS_Y;
		hRet = lpDIController02->SetProperty(DIPROP_RANGE, &diprg.diph);
		if (hRet != DI_OK)
		{
			gf_logger(false, "directinput::di_initialization SPY controller02 failed");
			di_cleanup();
			return(1);
		}
	}

	//---- acquire di devices --------------------------------------------------------------------

	char *pvoid = NULL;
	di_acquire(&pvoid, &pvoid, option.dataDEF.mouseflag, option.dataDEF.controllerflag);

	//one or two usb mice don't exist
	if (option.dataDEF.mouseflag == 1)
		gf_logger(false, "directinput::di_initialization SYS done");
	if (option.dataDEF.mouseflag == 2)
		gf_logger(false, "directinput::di_initialization USB(2) done");

	//controllers
	if (option.dataDEF.controllerflag == 0)
		gf_logger(false, "directinput::di_initialization NO CONTROLLER done");
	if (option.dataDEF.controllerflag == 1)
		gf_logger(false, "directinput::di_initialization CONTROLLER01 done");
	if (option.dataDEF.controllerflag == 2)
		gf_logger(false, "directinput::di_initialization CONTROLLER01 AND 02 done");

	return(0);
}

//------------------------------------------------------------------------------------------------
//
//	directinput acquire
//
//------------------------------------------------------------------------------------------------

bool directinput::di_acquire(char **pmm, char **pcm, int mouseflag, int controllerflag)
{
	if (lpDIKeyboard != NULL)
		lpDIKeyboard->Acquire();

	if (lpDISysMouse != NULL)
		lpDISysMouse->Acquire();

	if (mouseflag == 2)
	{
		lpDIMouse01->Acquire();
		lpDIMouse02->Acquire();

		//reaquired message
		gf_logger(false, "directinput::di_acquire USB(2) done");
		*pmm	= "DI_REACQUIRED(USB)";
	}
	else
	{
		if (lpDISysMouse != NULL)
		{
			//reaquired message
			gf_logger(false, "directinput::di_acquire SYS done");
			*pmm	= "DI_REACQUIRED(SYS)";
		}
	}

	if (controllerflag == 1)
	{
		lpDIController01->Acquire();
		//reaquired message
		gf_logger(false, "directinput::di_acquire CON(1) done");
		*pcm	= "DI_REACQUIRED(1CON)";
	}
	if (controllerflag == 2)
	{
		lpDIController01->Acquire();
		lpDIController02->Acquire();

		//reaquired message
		gf_logger(false, "directinput::di_acquire CON(2) done");

		*pcm = "DI_REACQUIRED(2CON)";
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directinput enumeration callback function
//
//	this one is a little tricky (it's tricky, tricky, tricky, tricky).
//	i don't know why but as a member function of a class the EnumDevices callback
//	function only works if it is declared as static (maybe because of the this-pointer).
//	when static, it can't use non-static elements of this class, so guid_mouse01 and
//	guide_mouse02 have to be global.
//
//	first this function makes sure the enumerated device is a mouse. than it makes
//	sure it isn't the system mouse (all plugged mice combined into one). the two
//	mouse guids are zero-ised in the directinput-constructor, so this function knows
//	if the first mouse is unassigned when its guid-elements are still zero.
//	if not it checks if the current device has the same GUID as the one of the first
//	mouse. if not this GUID is assigned to the second mouse and enumeration is stopped.
//	this works but i don't guarantee for nothing.
//
//------------------------------------------------------------------------------------------------

int directinput::DIEnumDCallback(LPCDIDEVICEINSTANCE lpddi,
								 LPVOID pvRef)
{
	//make sure enumerated device is a mouse
	if (lpddi->dwDevType & DIDEVTYPE_MOUSE)
		//make sure enumerated device is not system mouse (all mice combined into one)
		if (lpddi->guidInstance != GUID_SysMouse)
			//check if guid_mouse01 is already assigned (zero'ed in directinput constructor)
			if (guid_mouse01.Data1 == NULL &&
				guid_mouse01.Data2 == NULL &&
				guid_mouse01.Data3 == NULL)
			{
				//get first mouse guid
				guid_mouse01 = lpddi->guidInstance;

				//continue enumeration
				return DIENUM_CONTINUE;
			}
			else
				//make sure second mouse is not the same as first
				if (lpddi->guidInstance != guid_mouse01)
				{
					//get second mouse guid
					guid_mouse02 = lpddi->guidInstance;

					//when second mouse found, stop enumeration
					return DIENUM_STOP;
				}

	//continue enumeration
	gf_logger(false, "directinput::DIEnumDCallback done");
	return DIENUM_CONTINUE;
}

//------------------------------------------------------------------------------------------------
//
//	directinput enumeration callback function
//
//	this one is a little tricky (it's tricky, tricky, tricky, tricky).
//
//------------------------------------------------------------------------------------------------

int directinput::DIEnumJoystickCallback(LPCDIDEVICEINSTANCE lpddi,
										LPVOID pvRef)
{
	//make sure enumerated device is a controller (joystick)
	if (lpddi->dwDevType & DIDEVTYPE_JOYSTICK)
		//check if guid_controller01 is already assigned (zero'ed in directinput constructor)
		if (guid_controller01.Data1 == NULL &&
			guid_controller01.Data2 == NULL &&
			guid_controller01.Data3 == NULL)
		{
			//get first controller guid
			guid_controller01 = lpddi->guidInstance;

			//continue enumeration
			return DIENUM_CONTINUE;
		}
		else
			//make sure second controller is not the same as first
			if (lpddi->guidInstance != guid_controller01)
			{
				//get second controller guid
				guid_controller02 = lpddi->guidInstance;

				//when second controller found, stop enumeration
				return DIENUM_STOP;
			}

	//continue enumeration
	gf_logger(false, "directinput::DIEnumJoystickCallback done");
	return DIENUM_CONTINUE;
}

//------------------------------------------------------------------------------------------------
//
//	directinput cleanup
//
//	frees directinput interfaces
//
//------------------------------------------------------------------------------------------------

void directinput::di_cleanup()
{
	//unacquire and release all directinputdevice objects
	//if existing
    if (lpDIKeyboard) 
	{
		lpDIKeyboard->Unacquire();
		lpDIKeyboard->Release();
		lpDIKeyboard = NULL;
	}

	if (lpDISysMouse)
	{
		lpDISysMouse->Unacquire();
		lpDISysMouse->Release();
		lpDISysMouse = NULL;
	}

	if (lpDIMouse01)
	{
		lpDIMouse01->Unacquire();
		lpDIMouse01->Release();
		lpDIMouse01 = NULL;
	}

	if (lpDIMouse02)
	{
		lpDIMouse02->Unacquire();
		lpDIMouse02->Release();
		lpDIMouse02 = NULL;
	}

	if (lpDIController01)
	{
		//!!
		lpDIController01	= NULL;
	}

	if (lpDIController02)
	{
		//!!
		lpDIController02	= NULL;
	}

	//release DI object
	if (lpDI7)
	{
		lpDI7->Release();
		lpDI7 = NULL;
	}

	gf_logger(false, "directinput::di_cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	directinput get_input
//
//	gets keyboard and mouse input and fills inputstate object
//	with appropriate data
//
//------------------------------------------------------------------------------------------------

void directinput::get_input(inputstate &is)
{
	//---- get keyboard input --------------------------------------------------------------------

	//if keyboard valid
	if (lpDIKeyboard)
		//get keyboard state
		lpDIKeyboard->GetDeviceState(is.kbsize, &is.dikey);

	//---- get system mouse input ----------------------------------------------------------------

	if (INPUTTYPE == IP_DI)
	{
		//if mouse valid
		if (lpDISysMouse)
		{
			//get mouse state
			int res = lpDISysMouse->GetDeviceState(is.msize, &is.dimouse[0]);
		/*	if (res == DIERR_NOTACQUIRED) 		gf_logger(true, "gds DIERR_NOTACQUIRED %i", res);
			if (res == DIERR_INPUTLOST)			gf_logger(true, "gds DIERR_INPUTLOST %i", res);
			if (res == DIERR_INVALIDPARAM)		gf_logger(true, "gds DIERR_INVALIDPARAM %i", res);
			if (res == DIERR_NOTINITIALIZED)	gf_logger(true, "gds DIERR_NOTINITIALIZED %i", res);
			if (res == E_PENDING)				gf_logger(true, "gds E_PENDING %i", res);

			gf_logger(true, "%i", DIERR_NOTACQUIRED);*/
		}
		else
			gf_logger(true, "directinput::get_input NO SYSTEM MOUSE");

		//---- get mouse 1 input ---------------------------------------------------------------------

		//if mouse valid
		if (lpDIMouse01)
			//get mouse state
			lpDIMouse01->GetDeviceState(is.msize, &is.dimouse[1]);

		//---- get mouse 2 input ---------------------------------------------------------------------

		//if mouse valid
		if (lpDIMouse02)
			//get mouse state
			lpDIMouse02->GetDeviceState(is.msize, &is.dimouse[2]);
	}

  //---- get controller 1 input ----------------------------------------------------------------

	//if controller valid
	if (lpDIController01)
	{
		//poll
		lpDIController01->Poll();
		//get mouse state
		lpDIController01->GetDeviceState(is.csize, &is.dicon[0]);
	}

	//---- get controller 2 input ----------------------------------------------------------------

	//if controller valid
	if (lpDIController02)
	{
		//poll
		lpDIController02->Poll();
		//get mouse state
		lpDIController02->GetDeviceState(is.csize, &is.dicon[1]);
	}
}