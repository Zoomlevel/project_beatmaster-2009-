//------------------------------------------------------------------------------------------------
//
//	bot class definitions
//
//------------------------------------------------------------------------------------------------

#include "bot.h"					//class declaration header

//------------------------------------------------------------------------------------------------
//
//	bot constructor
//
//------------------------------------------------------------------------------------------------

bot::bot()
{
	//---- timer/option data ---------------------------------------------------------------------

	p_option				= NULL;
	p_time					= NULL;
	t_sca_sf				= 0;

	t_lastupdate			= 0;

	p_P						= NULL;
	p_is					= NULL;

	//--------------------------------------------------------------------------------------------

	id						= 0;

	active					= false;

	//---- bot_action_processor data -------------------------------------------------------------

	p_queue					= NULL;
	elements				= 0;
	ZeroMemory(&PAC, sizeof(PAC));
	ZeroMemory(&PAY, sizeof(PAY));

	recording				= false;
	replaying				= false;

	rec_queue				= 0;
	rep_queue				= 0;
	rep_eposi				= 0;
	rec_id					= 0;

	t_recstart				= 0;
	t_repstart				= 0;
	t_lastautosave			= 0;
	t_lastrec				= 0;
	t_lastrep				= 0;

	ZeroMemory(&t_walk_start, sizeof(t_walk_start));

	//---- console data --------------------------------------------------------------------------

	//clear console message buffer
	con_clear();

	//---- hud data ------------------------------------------------------------------------------

	p_hud_text				= NULL;

	//---- developer data ------------------------------------------------------------------------

	dev_i					= 0;
	dev_f					= 0;
	dev_pi					= NULL;
	dev_pf					= NULL;

	//--------------------------------------------------------------------------------------------

	gf_logger(false, "bot::bot done");
}

//------------------------------------------------------------------------------------------------
//
//	bot RegisterConVars
//
//	registers console variables
//
//------------------------------------------------------------------------------------------------

void bot::RegisterConVars(console *pcon)
{
	CLASS_CVI(bool, active, 0, 0, 1, 0);
}

//------------------------------------------------------------------------------------------------
//
//	bot initialization
//
//------------------------------------------------------------------------------------------------

bool bot::bot_initialization(int _bot)
{
	id		= _bot;

	//load default queue
	if (!load_queue(F_BAQDEFAULT))
	{
		gf_logger(true, "bot::bot_initialization load_queue FAILED %s", F_BAQDEFAULT);
		return(false);
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot cleanup
//
//------------------------------------------------------------------------------------------------

void bot::bot_cleanup()
{
	//---- bot_action_processor data -------------------------------------------------------------

	if (p_queue)
	{
		delete []			p_queue;
		p_queue				= NULL;
	}
	elements		= 0;

	gf_logger(false, "bot::bot_cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	bot set_data_pointer
//
//	fills pointer to timer and option data
//
//------------------------------------------------------------------------------------------------

void bot::set_data_pointer(options *_options, timer *_timer, hud_text *_hud, player *_player, inputstate *_is)
{
	p_option			= _options;
	p_time				= _timer;
	p_hud_text			= _hud;

	p_P					= _player;
	p_is				= _is;
}

//------------------------------------------------------------------------------------------------
//
//	bot reset
//
//	resets bot
//
//------------------------------------------------------------------------------------------------

void bot::reset()
{
	//---- xxx -----------------------------------------------------------------------------------
}

//------------------------------------------------------------------------------------------------
//
//	bot toggle_bot
//
//	sets bot ON or OFF
//
//------------------------------------------------------------------------------------------------

void bot::toggle_bot()
{
	//if bot on set off, if bot off set on
	active	= !active;
	if (active)
	{
		if (id == B1)	hud_add_message(id, bmfblue, "BOT[%i] ON", id);
		else			hud_add_message(id, bmfblue, "BOT[%i] ON", id);
	}
	else
	{
		if (id == B1)	hud_add_message(id, bmfred, "BOT[%i] OFF", id);
		else			hud_add_message(id, bmfred, "BOT[%i] OFF", id);
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot check_update
//
//	returns true if to update bot
//
//------------------------------------------------------------------------------------------------

bool bot::check_update()
{
	if ((p_time->current - t_lastupdate) / (float)p_time->freq >= 1.0f / p_option->data.bot_ticks)
	{
		//update t_lastupdate
		t_lastupdate		= p_time->current;

		return(true);
	}
	else
		//no processing
		return(false);
}

//------------------------------------------------------------------------------------------------
//
//	bot reset timers
//
//	reset timers if game was paused
//
//------------------------------------------------------------------------------------------------

void bot::reset_timers()
{
	if (recording)
		t_lastrec		= p_time->current;
	if (replaying)
		t_lastrep		= p_time->current;
}

//------------------------------------------------------------------------------------------------
//
//	bot add_queue
//
//------------------------------------------------------------------------------------------------

bool bot::add_queue()
{
	//create new bot_action_queue array which is 1 element bigger than the existing one
	bot_action_queue *p_temp		= new bot_action_queue[elements + 1];

	//allocation failed
	if (p_temp == NULL)
	{
		gf_logger(true, "bot[%i]::add_queue allocation failed", id + 1);
		return(false);
	}

	//copy old array data into new array
	for (register int i = 0; i < elements; ++i)
	{
		p_temp[i]		= p_queue[i];
		//reset *p_event pointer to NULL
		//so it isn't tried to get deleted by the destructor when old array is
		//deleted below
		p_queue[i].reset();
	}

	//delete old array if existing
	if (p_queue)
	{
		delete []			p_queue;
	}

	//assign new array
	p_queue				= p_temp;
	p_temp				= NULL;

	//increase number of elements counter
	++elements;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot append_queue
//
//------------------------------------------------------------------------------------------------

bool bot::append_queue(bot_action_queue *p_qdest,	//pointer to queue getting p_qsource appended
					   bot_action_queue *p_qsource,	//pointer to queue appended to p_qdest
					   float t_offset)				//time offset between the two queues
{
	//valid queues
	if (p_qdest == NULL || p_qsource == NULL)
	{
		gf_logger(true, "bot[%i]::append_queue NULL queue", id + 1);
		return(false);
	}

	//offset time between queues
	if (t_offset < 0)
		t_offset	= 0;

	//create time buffer event
	if (p_qdest->add_event(t_offset, 0, 89, 0) == false)
	{
		gf_logger(true, "bot[%i]::append_queue add_event t_offset failed", id + 1);
		return(false);
	}

	//for every event of source queue
	for (register int e = 0; e < p_qsource->elements; ++e)
	{
		//create new event in dest queue with source queue event data
		if (p_qdest->add_event(p_qsource->p_event[e].t_,
							   p_qsource->p_event[e].angle,
							   p_qsource->p_event[e].angle_180,
							   p_qsource->p_event[e].distance) == false)
		{
			gf_logger(true, "bot[%i]::append_queue add_event failed", id + 1);
			return(false);
		}

		//for every event state of source queue
		for (register int s = 0; s < p_qsource->p_event[e].elements; ++s)
		{
			//create new event state in dest queue with source queue event state data
			if (p_qdest->p_event[p_qdest->elements - 1].add_estate(p_qsource->p_event[e].p_estate[s].action_index,
																   p_qsource->p_event[e].p_estate[s].state) == false)
			{
				gf_logger(true, "bot[%i]::append_queue add_estate failed", id + 1);
				return(false);
			}
		}
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_start_record
//
//------------------------------------------------------------------------------------------------

bool bot::mr_start_record(int queue_id, int player, bool reset, float t_offset)
{
	//already recording
	if (recording)
		return(false);

	//verify player
	if (player != P1 && player != P2)
		return(false);

	//verify queue
	if (queue_id > elements - 1)
		//first queue requested but none available
		if (queue_id == 0)
			//create new one
			queue_id = -1;
		else
			return(false);

	//new queue if queue_id negative
	if (queue_id < 0)
	{
		if (add_queue() == false)
		{
			gf_logger(true, "bot[%i]::start_record add_queue failed", id + 1);
			return(false);
		}

		//save queue id of queue to be recorded
		rec_queue		= elements - 1;
	}
	else
		rec_queue		= queue_id;

	//if recording queue is the same as the replay queue and
	//also replaying
	if (replaying && rec_queue == rep_queue)
		return(false);

	//delete old queue data
	if (reset)
	{
		p_queue[rec_queue].del_queue();
	}
	else
	//append new queue data with argumented time offset
	{
		if (t_offset < 0)
			t_offset	= 0;

		//create time buffer event
		if (p_queue[rec_queue].add_event(t_offset, 0, 89, 0) == false)
		{
			gf_logger(true, "bot[%i]::start_record[%i] add_event t_offset failed", id + 1, rec_queue);
			return(false);
		}
	}

	rec_id			= player;
	recording		= true;

	//set start time
	t_recstart		= p_time->current;
	//set last auto save time stamp
	t_lastautosave	= p_time->current;
	//reset last record index
	t_lastrec		= 0;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_stop_record
//
//------------------------------------------------------------------------------------------------

bool bot::mr_stop_record()
{
	//not recording
	if (!recording)
		return(false);
	else
	{
		recording		= false;
		return(true);
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_record
//
//------------------------------------------------------------------------------------------------

bool bot::mr_record()
{
/*	//if maximum recording length reached stop recording
	if ((p_time->current - t_recstart) / (float)p_time->freq >= MAXRECLENGTH)
	{
		mr_stop_record();
		hud_add_message(id, bmfred, "BOT[%i] recording STOPPED (max length: %.1f)", id, MAXRECLENGTH);
		return(true);
	}*/

	//if auto save on
	if (BAQ_AUTOSAVE_INTERVAL > 0)
		//save queue every BAQ_AUTOSAVE_INTERVAL seconds
		if ((p_time->current - t_lastautosave) / (float)p_time->freq >= BAQ_AUTOSAVE_INTERVAL)
		{
			//set last auto save time stamp
			t_lastautosave	= p_time->current;

			//file name depending on bot
			if (id == B1)
			{
//!! welche queue?
				if (save_queue(0, F_BAQAUTOSAVE_1))
					hud_add_message(id, bmfred, "BOT[%i] REC SAVED \"%s\" (%.1f)", id, F_BAQAUTOSAVE_1, BAQ_AUTOSAVE_INTERVAL);
				else
					hud_add_message(id, bmfred, "BOT[%i] REC SAVING FAILED \"%s\" (%.1f)", id, F_BAQAUTOSAVE_1, BAQ_AUTOSAVE_INTERVAL);
			}
			else
			{
				if (save_queue(0, F_BAQAUTOSAVE_2))
					hud_add_message(id, bmfred, "BOT[%i] REC SAVED \"%s\" (%.1f)", id, F_BAQAUTOSAVE_2, BAQ_AUTOSAVE_INTERVAL);
				else
					hud_add_message(id, bmfred, "BOT[%i] REC SAVING FAILED \"%s\" (%.1f)", id, F_BAQAUTOSAVE_2, BAQ_AUTOSAVE_INTERVAL);
			}
		}

	//compare PAC and PA and check if some state changed
	//for every player action
	for (register int i = 0; i < NPAN; ++i)
	{
		//if state of action changed
		if (PAC[i] != p_is->PA[rec_id][i])
		{
			//convert angle data first if necessary
			//always converted to left side
			//(angle_180 doesn't change with sides)
			int	angle_left	= p_is->mm_angle[rec_id];

			//depending on who is recorded
			if (id == rec_id)
			{
				if (p_P->side != SLEFT)
				{
					//per reference
					mirror_angle(angle_left);
				}
			}
			else
			{
				if (p_P->p_opp->side != SLEFT)
				{
					//per reference
					mirror_angle(angle_left);
				}
			}

			//get time offset from last recorded event
			float	t_		= 0;
			//if not first event in queue
			if (t_lastrec != 0)
			{
				t_		= (p_time->current - t_lastrec) / (float)p_time->freq;
			}

			//add new event with data
			if (p_queue[rec_queue].add_event(t_, angle_left, p_is->mm_angle_180[rec_id], *p_P->p_distance) == false)
			{
				gf_logger(true, "bot[%i]::record add_event failed", id + 1);
				return(false);
			}

			//update last recorded event time
			t_lastrec	= p_time->current;

			//break for loop
			break;
		}
	}

	//for every player action
	for (i = 0; i < NPAN; ++i)
	{
		//if state of action changed
		if (PAC[i] != p_is->PA[rec_id][i])
		{
			//in current queue at last event add event state with data
			if (p_queue[rec_queue].p_event[p_queue[rec_queue].elements - 1].add_estate(i, p_is->PA[rec_id][i]) == false)
			{
				gf_logger(true, "bot[%i]::record add_estate failed", id + 1);
				return(false);
			}

			//if a hold animation store state of animation in PAC
			if (i == AN_WALK_FWD ||
				i == AN_WALK_BWD ||
				(i == AN_DEFEND && p_is->PA[rec_id][i] == AS_ACTIVE) ||
				i == AN_GUARD_ARMS ||
				i == AN_GUARD_LEGS ||
				i == AN_GUARD_FULL)
				//update PAC with new state
				PAC[i]	= p_is->PA[rec_id][i];
			else
				//reset PAC so that setting the state to 0 is no separate event
				PAC[i]	= 0;
		}
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_start_replay
//
//------------------------------------------------------------------------------------------------

bool bot::mr_start_replay(int queue_id)
{
	//already replaying
	if (replaying)
		return(false);

	//invalid queue index
	if (queue_id < 0 || queue_id > elements - 1)
		return(false);

	//if replaying queue is the same as the recording queue and
	//also recording
	if (recording && rep_queue == rec_queue)
		return(false);

	//queue valid but no events
	if (p_queue[queue_id].elements < 1)
		return(false);

	rep_queue			= queue_id;
	//reset replay position within queue
	rep_eposi			= 0;
	replaying			= true;

	//set start time
	t_repstart			= p_time->current;
	//reset last replay index
	t_lastrep			= 0;

	//reset walk time
	ZeroMemory(&t_walk_start, sizeof(t_walk_start));

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_stop_replay
//
//------------------------------------------------------------------------------------------------

bool bot::mr_stop_replay()
{
	//not replaying
	if (!replaying)
		return(false);
	else
	{
		replaying		= false;
		return(true);
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot mr_replay
//
//------------------------------------------------------------------------------------------------

void bot::mr_replay()
{
	//if time passed since previous update plus next update time offset reached
	//time offset adjusted to game speed
	if (t_lastrep + (p_queue[rep_queue].p_event[rep_eposi].t_ / p_option->data.speed) * (float)p_time->freq <= p_time->current)
//	if (t_lastrep + (p_queue[rep_queue].p_event[rep_eposi].t_ / p_option->data.speed) * (float)p_time->freq <= p_time->current &&
//		((int)*p_P->p_distance <= (int)p_queue[rep_queue].p_event[rep_eposi].distance + 5 &&
//		(int)*p_P->p_distance >= (int)p_queue[rep_queue].p_event[rep_eposi].distance - 5)
//		)
	{
hud_add_message(id, bmfblue, "diffdis: %i", (int)*p_P->p_distance - (int)p_queue[rep_queue].p_event[rep_eposi].distance);
		//get angle of event
		int angle_ad	= p_queue[rep_queue].p_event[rep_eposi].angle;
		//if not on left side convert angle to other side
		if (p_P->side != SLEFT)
		{
			//per reference
			mirror_angle(angle_ad);
		}

		//set angle and angle_180
		p_is->mm_angle[id]		= angle_ad;
		p_is->mm_angle_180[id]	= p_queue[rep_queue].p_event[rep_eposi].angle_180;

		//for all states within event
		for (register int s = 0; s < p_queue[rep_queue].p_event[rep_eposi].elements; ++s)
		{
			if (p_queue[rep_queue].p_event[rep_eposi].p_estate[s].action_index == AN_WALK_FWD &&
				p_queue[rep_queue].p_event[rep_eposi].p_estate[s].state == AS_ACTIVE &&
				PAY[AN_WALK_FWD] != AS_ACTIVE)
			{
				t_walk_start[1]	= p_time->current;
			}
			if (p_queue[rep_queue].p_event[rep_eposi].p_estate[s].action_index == AN_WALK_BWD &&
				p_queue[rep_queue].p_event[rep_eposi].p_estate[s].state == AS_ACTIVE &&
				PAY[AN_WALK_BWD] != AS_ACTIVE)
			{
				t_walk_start[0] = p_time->current;
			}

			//set new player action index to state
			PAY[p_queue[rep_queue].p_event[rep_eposi].p_estate[s].action_index] =
				p_queue[rep_queue].p_event[rep_eposi].p_estate[s].state;
		}

		//update last replayed event time
		t_lastrep	= p_time->current;

		//if last event
		if (rep_eposi == p_queue[rep_queue].elements - 1)
		{
			//stop replay
			mr_stop_replay();
			hud_add_message(id, bmfred, "BOT[%i] replay ENDED", id);
			//return;
		}
		else
			//increase replay event position
			++rep_eposi;
	}

	//every frame
	//set player action array in inputstate to current registered player action state
	for (register int i = 0; i < NPAN; ++i)
	{
		p_is->PA[id][i]		= PAY[i];

		//if no hold animation reset PAY so next frame that action index state
		//is also reset
		if (i == AN_WALK_FWD ||
			i == AN_WALK_BWD ||
			(i == AN_DEFEND && PAY[i] == AS_ACTIVE) ||
			i == AN_GUARD_ARMS ||
			i == AN_GUARD_LEGS ||
			i == AN_GUARD_FULL)
/*		if ((i == AN_DEFEND && PAY[i] == AS_ACTIVE) ||
			i == AN_GUARD_ARMS ||
			i == AN_GUARD_LEGS ||
			i == AN_GUARD_FULL)*/
		{
			PAY[i];
		}
		else
		{
			PAY[i]	= 0;
		}
	}

/*
//walking distance (overwrites previous setting depending on PA)
if (*p_P->p_distance > p_queue[rep_queue].p_event[rep_eposi].distance)
//	if (p_is->PA[id][AN_WALK_BWD] != AS_ACTIVE)
		p_is->PA[id][AN_WALK_FWD]	= AS_ACTIVE;
if (*p_P->p_distance < p_queue[rep_queue].p_event[rep_eposi].distance)
//	if (p_is->PA[id][AN_WALK_FWD] != AS_ACTIVE)
		p_is->PA[id][AN_WALK_BWD]	= AS_ACTIVE;
//hud_add_message("%i to %i", (int)*p_P->p_distance, (int)p_queue[rep_queue].p_event[rep_eposi].distance);
*/
	//set walking time if walking
	if (p_is->PA[id][AN_WALK_FWD] == AS_ACTIVE)
	{
		p_is->t_move[id][1]		= (p_time->current - t_walk_start[1]) / (float)p_time->freq;
	}
	if (p_is->PA[id][AN_WALK_BWD] == AS_ACTIVE)
	{
		p_is->t_move[id][0]		= (p_time->current - t_walk_start[0]) / (float)p_time->freq;
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot mirror_angle
//
//------------------------------------------------------------------------------------------------

void bot::mirror_angle(int &angle)
{
	//mirror angle
	angle		= 180 - angle;

	//check angle limits
	if (angle > 359)		angle -= 360;
	if (angle < 0)			angle += 360;
}

//------------------------------------------------------------------------------------------------
//
//	bot save_queue
//
//	saves argumented queue in argumented file
//
//------------------------------------------------------------------------------------------------

bool bot::save_queue(int q_id,							//-1 = all queues
					 char *pcfile)
{
	//no queues
	if (elements < 1)
	{
		gf_logger(true, "bot[%i]::save_queue[%i] no queues", id + 1, q_id);
		return(false);
	}

	//verify queue id
	if (q_id > elements - 1)
	{
		gf_logger(true, "bot[%i]::save_queue[%i] invalid queue", id + 1, q_id);
		return(false);
	}

	//invalid file name
	if (pcfile == NULL || pcfile == "")
	{
		gf_logger(true, "bot[%i]::save_queue[%i] invalid file name", id + 1, q_id);
		return(false);
	}

	//create bot folder
	_mkdir("bot");

	//---- get bitmap file index -----------------------------------------------------------------

/*	int		bmi				= 0;				//bitmap file index
	char	filename[27]	= "";				//filename
	char	index[4]		= "";				//file index as string

	//try to open bitmap file
	//as long as file exists, increase index
	//if 1000 files exist the last one (999) will be overwritten
	for (bmi = 0; bmi < 1000; ++bmi)
	{
		//add zeros in front
		if (bmi < 10)
			strcpy(filename, "screens/beatmaster_00");
		if (bmi > 9 && bmi < 100)
			strcpy(filename, "screens/beatmaster_0");
		if (bmi > 99)
			strcpy(filename, "screens/beatmaster_");

		//convert index integer to string
		_itoa(bmi, index, 10);
		//append index to filename
		strcat(filename, index);
		//append file ending to filename
		strcat(filename, ".bmp");

		//exit loop if no such file found
		if (fopen(filename, "rb") == NULL)
			break;
	}

	//apply screenshot file name
	if (screenshot_id)
		strcpy(screenshot_id, filename);*/

	//---------------------------------------------------------------------------------------------

	//open file (binary mode)
	FILE *f_queue	= fopen(pcfile, "wb");

	//if file successfully opened
	if (f_queue != NULL)
	{
		con_add_message("saving queue[%i]", q_id);

/*		format version 1:

		number of events
			time after last event, angle, angle_180, distance
			number of states for event
				action_index, state
				action_index, state
				action_index, state
			time after last event, angle, angle_180, distance
			number of states for event
				action_index, state
				action_index, state
				action_index, state

		bot_action_queue.elements
			bot_queue_event.t_, bot_queue_event.angle, bot_queue_event.angle_180, bot_queue_event.distance
			bot_queue_event.elements
				bot_queue_event_state.action_index,	bot_queue_event_state.state
				bot_queue_event_state.action_index,	bot_queue_event_state.state
*/

		//all queues
		if (q_id < 0)
		{
			//for all queues
			for (register int q = 0; q < elements; ++q)
			{
				//number of events
				fprintf(f_queue, "%i\n", p_queue[q].elements);

				//for every event
				for (register int e = 0; e < p_queue[q].elements; ++e)
				{
					fprintf(f_queue, "%5f %i %i %.1f\n",
							p_queue[q].p_event[e].t_,
							p_queue[q].p_event[e].angle,
							p_queue[q].p_event[e].angle_180,
							p_queue[q].p_event[e].distance);

					//number of states for event
					fprintf(f_queue, "%i\n", p_queue[q].p_event[e].elements);

					//for every event state
					for (register int s = 0; s < p_queue[q].p_event[e].elements; ++s)
					{
						fprintf(f_queue, "%i %i\n",
								p_queue[q].p_event[e].p_estate[s].action_index,
								p_queue[q].p_event[e].p_estate[s].state);
					}
				}
			}
		}
		else
		//specified queue
		{
			//number of events
			fprintf(f_queue, "%i\n", p_queue[q_id].elements);

			//for every event
			for (register int e = 0; e < p_queue[q_id].elements; ++e)
			{
				fprintf(f_queue, "%5f %.1f %i %i\n",
						p_queue[q_id].p_event[e].t_,
						p_queue[q_id].p_event[e].distance,
						p_queue[q_id].p_event[e].angle,
						p_queue[q_id].p_event[e].angle_180);

				//number of states for event
				fprintf(f_queue, "%i\n", p_queue[q_id].p_event[e].elements);

				//for every event state
				for (register int s = 0; s < p_queue[q_id].p_event[e].elements; ++s)
				{
					fprintf(f_queue, "%i %i\n",
							p_queue[q_id].p_event[e].p_estate[s].action_index,
							p_queue[q_id].p_event[e].p_estate[s].state);
				}
			}
		}

		//close file
		fclose(f_queue);

		return(true);
	}
	else
	{
		gf_logger(true, "bot[%i]::save_queue[%i] couldn't create file %s", id + 1, q_id, pcfile);
		return(false);
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot load_queue
//
//	loads queue from argumented file
//
//------------------------------------------------------------------------------------------------

bool bot::load_queue(char *pcfile)
{
	//invalid file name
	if (pcfile == NULL || pcfile == "")
	{
		gf_logger(true, "bot[%i]::load_queue invalid file name \"%s\"", id + 1, pcfile);
		return(false);
	}

	//open file (binary mode)
	FILE *f_queue	= fopen(pcfile, "rb");

	//if file sucessfully opened
	if (f_queue != NULL)
	{
		//log file access (1 is dummy)
		gf_logger(false, "accessing file: %s", pcfile, 1);

		con_add_message("loading queue from file %s", pcfile);

		/*format version 1
		number of events
			event data 0, number of states, state data 0, state data 1, ...
			event data 1, number of states, state data 0, state data 1, ...
		...
		*/

		//number of events of queue
		int events		= 0;
		//number of states of event
		int states		= 0;

		//endless loop, broken by end of file
		while (true)
		{
			//get number of events
			if (EOF == fscanf(f_queue, "%i",
							  &events))
			{
				//if end of file break loop
				break;
			}

			//create queue
			if (add_queue() == false)
			{
				gf_logger(true, "bot[%i]::load_queue from file %s add_queue failed", id + 1, pcfile);
				break;
			}

			//for all events
			for (register int e = 0; e < events; ++e)
			{
				//event data
				float _t_offset		= 0;
				int _angle			= 0;
				int _angle_180		= 0;
				float _distance		= 0;

				//get event data
				fscanf(f_queue, "%f %i %i %f",
					   &_t_offset,
					   &_angle,
					   &_angle_180,
					   &_distance);

				//add event with event data
				p_queue[elements - 1].add_event(_t_offset, _angle, _angle_180, _distance);

				//get number of event states
				fscanf(f_queue, "%i",
					   &states);

				//for all event states
				for (register int s = 0; s < states; ++s)
				{
					//state data
					int _ai		= 0;
					int _st		= 0;

					//get event state data
					fscanf(f_queue, "%i %i",
						   &_ai,
						   &_st);

					//add state with event state data
					p_queue[elements - 1].p_event[p_queue[elements - 1].elements - 1].add_estate(_ai, _st);
				}
			}
		}

		//close file
		fclose(f_queue);

		return(true);
	}
	else
	{
		gf_logger(true, "bot[%i]::load_queue couldn't open file %s", id + 1, pcfile);
		return(false);
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot process
//
//	process bot logic
//
//------------------------------------------------------------------------------------------------

void bot::process()
{
	//if not time for update (tick-rate) return
//	if (!check_update())
//		return;

	//---- bot_action_processor ------------------------------------------------------------------

	if (recording)
	{
		mr_record();
	}

	if (replaying)
	{
		mr_replay();
	}
}

//------------------------------------------------------------------------------------------------
//
//	bot con_add_message
//
//	and now for the more professional version of the same thing
//	(*weep*)
//
//------------------------------------------------------------------------------------------------

void bot::con_add_message(char *format, ...)
{
	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	//clear message dump
	con_clear();

	//print formated string in console dump message
    vsprintf(con_dumpmessage, format, ap);

	//clear up
	va_end(ap);
}

//------------------------------------------------------------------------------------------------
//
//	bot con_clear
//
//	clears console message buffer
//
//------------------------------------------------------------------------------------------------

void bot::con_clear()
{
	ZeroMemory(&con_dumpmessage, sizeof(con_dumpmessage));
}

//------------------------------------------------------------------------------------------------
//
//	bot hud_add_message
//
//------------------------------------------------------------------------------------------------

void bot::hud_add_message(int _hud_id, int color, char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "bot::hud_add_message NULL");
		return;
	}

	//verify id
	if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
	if (_hud_id < 0)				_hud_id = 0;

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	bot hud_add_message
//
//------------------------------------------------------------------------------------------------

void bot::hud_add_message(char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "bot::hud_add_message NULL");
		return;
	}

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//default values
	int _hud_id		= 0;
	int color		= bmfblack;

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}