//------------------------------------------------------------------------------------------------
//
//	master_frame class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef MASTER_FRAME_H
#define MASTER_FRAME_H					//begin MASTER_FRAME_H

#ifndef _WIN32_WINNT
#define _WIN32_WINNT			0x0501		//identify as windows xp application
											//necessary to access rawinput from user32.dll
#endif

//#include <windows.h>					//general windows header (including raw input)
#include <locale.h>						//GetLocaleInfo
#include "directdraw.h"					//directdraw class
#include "directsound.h"				//directsound class
#include "bot.h"						//bot and player and directinput class

//---- defines -----------------------------------------------------------------------------------

#define	LOVE			0

//program state
#define INACTIVE		0
#define ACTIVE			1
#define REACTIVATED		2

//intern program states
#define DEVELOPER		100
#define EXIT			0
#define STARTUP			1
#define TITLE			2
#define OPTIONS			3
#define CREDITS			4
#define INGAME			5
#define PAUSE			6
#define TEASER			15

//---- error message strings ---------------------------------------------------------------------

extern const char *gp_ErrStr;			//global error string, in winmain.cpp

const char Err_MF[]						= "FAILED";
const char Err_MFLoadAnimation[]		= "MF_LoadAnimation FAILED";

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//------------------------------------------------------------------------------------------------

class master_frame
{
//------------------------------------------------------------------------------------------------
//	private master_frame objects
//------------------------------------------------------------------------------------------------

private:

	float			version;						//version of program

	//---- windows objects -----------------------------------------------------------------------

	HWND			hwnd;							//window handle
	MSG				msg;							//stucture which contains informations about a message

	bool			program_active;					//true if program in foreground

	//---- directx objects -----------------------------------------------------------------------

	directdraw			dd;							//directdraw object
	directinput			di;							//directinput object
	directsound			ds;							//directsound object

	//---- mouse cursor data ---------------------------------------------------------------------

	cursor				mcursor[2];					//cursor for both players

	//---- game objects --------------------------------------------------------------------------

	int					program_state;				//state of programm
													//-2 = developer
													//-1 = exit
													//0 = startup
													//1 = title
													//2 = options
													//3 = ingame
													//4 = pause
	timer				time;						//timer, gets itself frequency due its constructor
	options				option;						//options of game, includes functions for file handling, etc
	int					dd_blurcounter;				//for motion blur

	program_pause		ppause;						//object to pause program

	inputstate			is;							//inputstate (kb and mice)
	LONGLONG			s_lastpan;					//time index of last pan update

	data_startup		data_su;					//data for startup sequence
	data_title			data_ti;					//data for title sequence
	data_options		data_op;					//data for options menu
	data_credits		data_cr;					//data for credits scroll
	data_ingame			data_ig;					//data for ingame
	data_teaser			data_te;					//data for teaser

	player				P[2];						//two player objects as array
	player_data			pd;							//contains pointers to player data
													//(also contains pointers to shadow data below)
	char				*panmnfile[4][NPAN];		//pointer to animation file names, initialized in constructor
	animation			anmn[4][NPAN];				//all animations for all four alignments
													//left side, left foot forward = 0
													//left side, right foot forward = 1
													//right side, left foot forward = 2
													//right side, right foot forward = 3

	result_collision_detection	rcd;				//holds results of collision detection

	float				player_distance;			//absolute distance between both players

	point				s_scale;					//shadow scale (x = shift, y = compression)
	int					s_mpy;						//shadow mirror plane (y-coordinate)

	//---- bot data ------------------------------------------------------------------------------

	bot					BOT[2];						//two bot objects

	//---- static demo data -----------------------------------------------------------------------
	//used in developer

	bool				demo_record;				//set true to record game inputs
	bool				demo_playback;				//set true if playing back demo
	FILE				*f_demo_rec;				//demo recording file
	FILE				*f_demo_pb;					//demo playback file
	int					demo_fps;					//demo fps
	LONGLONG			t_drec_start;				//time index of demo recording start
	LONGLONG			t_drec_lastframe;			//time index of last demo recording frame
	LONGLONG			t_dpb_start;				//time index of demo playback start
	LONGLONG			t_dpb_lastframe;			//time index of last demo playback frame

	//---- developer objects ---------------------------------------------------------------------

	bool				dev_s_showdata;				//show editor data
	bool				dev_s_devmode;				//developer input on/off
	bool				dev_s_showref;				//show reference skeletons
	bool				dev_s_animate;				//switch animation on/off
	int					dev_bi[2];					//current selected bone index
	bool				dev_s_ai;					//dummy-ai, number of player beeing controlled by ai

	animation			*p_dev_a[4][NPAN];			//array of pointers to all animations
													//side depending on player1 asi
	int					dev_cai;					//current animation index
	int					dev_ckf;					//current keyframe index

	rectangle			dev_hsk[19];				//hara reference skeleton
	rectangle			dev_esk[2][19];				//two editor reference skeletons
	line				dev_fadiffp[19];			//formula angle difference indicator
	line				dev_fadiffn[19];			//formula angle difference indicator

	//keyframe time (slots) keyframe index

	//---- console variables ---------------------------------------------------------------------

	console				con;							//ingame console

	char				con_dumpmessage[CON_LINEMAX];	//console dump message

	CLASS_CON_VAR(bool, walkbot);						//walks second player back to screen center
	CLASS_CON_VAR(int, host_id);						//host player id

	//---- hud text ------------------------------------------------------------------------------

	hud_text			hud_text[2];					//hud text

//------------------------------------------------------------------------------------------------
//	private master_frame functions
//------------------------------------------------------------------------------------------------

	//cleanup function
	void mf_cleanup();

//------------------------------------------------------------------------------------------------
//	public master_frame functions
//------------------------------------------------------------------------------------------------

public:

	//constructor
	master_frame(HWND hwnd);

	//initialization function called from winmain
	//sets up directx
	bool mf_initialization();

	//called by winmain
	void mainloop();

	//---- support -------------------------------------------------------------------------------

	//plays system sound
	void playsound_s(int b_index,							//index of system sound
					 bool stop = true,						//stop before playing (in case already playing)
					 bool loop = false);					//loop

	void playsound_g(int b_type,							//index of buffer type
					 int b_index,							//index of sound
					 bool stop = true,						//stop before playing (in case already playing)
					 bool loop = false);					//loop

	//processes player sounds
	void process_sound(int state = 0);						//0 = nothing
															//1 = pause all sounds
															//2 = resume all sounds

	//---- game routines -------------------------------------------------------------------------

	//startup sequence (from program start to title screen)
	void startup();

	//title screen sequence
	void title();

	//options menu
	void options();

	//credits scroll
	void credits();

	//ingame routine
	void ingame();

	//teaser sequence
	void teaser();

	//---- ChangeScreenMode ----------------------------------------------------------------------

	bool ChangeScreenMode();					//changes screen mode between fullscreen and windowed

	//---- load animations -----------------------------------------------------------------------

	bool load_animations();

	//---- ingame logic routines -----------------------------------------------------------------

	//sets additional animation game logic data
	void set_animation_gl_data();

	//help function for set_animation_gl_data()
	//for all 4 asi
	void set_agl_data(int _anmn,
					  float _damage, float _defend, float _fatigue, float _fatcancel,
					  float _fat_speed, float _fat_off,
					  float _dam_speed[19],
					  float _dam_off[19],
					  float _cd_def[19],
					  float _cd_off[19],
					  int _soundid = -1);
					  //animation index
					  //damage, defend, fatigue, fatigue cancel
					  //fatigue speed, fatigue offense
					  //damage speed all bones
					  //damage offense all bones
					  //cd state own all bones
					  //cd state opponent all bones
					  //anmn sound id

	//fills float array with 19 elemts
	void fill_farray_19(float data[19],
						float f0 = 0, float f1 = 0, float f2 = 0, float f3 = 0, float f4 = 0,
						float f5 = 0, float f6 = 0, float f7 = 0, float f8 = 0, float f9 = 0,
						float f10 = 0, float f11 = 0, float f12 = 0, float f13 = 0, float f14 = 0,
						float f15 = 0, float f16 = 0, float f17 = 0, float f18 = 0);

	//collision detection
	void collision_detection();

	//returns true if RECTS collide, else false
	bool hitboxcheck(RECT &r1, RECT &r2);

	//returns true or false for two rectangles colliding
	bool cd_rect_rect(rectangle &r1, rectangle &r2);

	//returns true or false for a circle and a rectangle colliding
	bool cd_circle_rect(point cc, float rc, rectangle &r);

	//returns angle between center of rectangle and circle of rectangle if colling
	//(-1 for no collision)
	float cd_rect_circle(rectangle &r, point cc, float rc);

	//returns angle of two circles colliding (-1 for no collision)
	float cd_circle_circle(point c1, float r1, point c2, float r2);

	//returns true if two lines collide
	bool cd_line_line(line l1, line l2);

	//overloaded cd_line_line
	//takes point as argument which stores point of collision
	//if no collision point remains unchanged and function returns false
	bool cd_line_line(line l1, line l2, point &p);

	//returns true if point lies on line
	bool cd_point_line(point p, line l);

	//returns true if the four lines of two rectangles collide
	//(tests the four edges against each other)
	//!! open:
		//if any edge (line) is just a point, or both
		//all points of collision
		//if edge or whole rectangle within other rectangle
	bool CD_rect_rect(rectangle &r1, rectangle &r2);

	//---- elemantary routines -------------------------------------------------------------------

	//calculates shadow data
	void calculate_shadows();

	//processes round time, returns false when round time up
	bool process_roundtime(bool stringonly = false);	//set true to only update round time string

	//updates winning point array
	int update_winpoints(bool final = false);		//if final = true returned value
													//is final winner
													//0 = player 1 wins
													//1 = player 2 wins
													//2 = draw

	//switch player sides
	void auto_side_switch();

	//game startup sequence with borders moving out and players zooming in
	//returns true when done
	void game_startup(float t_border,				//time of bordermove
					  float t_pause,				//pause between bordermove and zoom
					  float t_zoom);				//time of zoom

/*	//zooms players in or out
	void player_zooom(int mode,						//0 = in, 1 = out
					  float startsize,				//start and endsize (1.0f standard)
					  float endsize,
					  float time);					//time of zoom*/

	//handles mouseinput and draws cursor
	void process_mousecursor(int type = 0);	//cursor type
											//0 = standard
											//1 = rotating yinyang
											//2 = fist

	//sorts a given integer array
	void quicksort(int data[],				//array with data
				   int l,					//always 0, left border index of array
				   int r,					//right border index of array (including 0)
				   int order = 0);			//0 = lowest to largest, 1 = largest to lowest

	//sorts array of pointers to bones in z-order of bones
	void quicksort_zb(bone *pzb[],			//pointer to bones
					  int l,
					  int r,
					  int order = 0);

	//displays change of ingame options like vsync, shadows, etc.
	//if user changes them
	void ingameoptions();

	//determines exact offset point for a bitmap string to be printed screen centered
	point centerfont(char *ps, RECT screen);

	//determines exact offset point for a scanline string to be printed screen centered
	point centerfont(char *ps, RECT screen, float sizefactor);

	//same as above, but returning integer points and only receive length of the string to center
	ipoint centerfont(int stringlength, RECT screen);
	ipoint centerfont(int stringlength, RECT screen, float sizefactor);

	//returns ON/OFF string depending on argument (!0/0)
	char *getstate(float state);

	//reads keyboard and returns ascii code for key pressed
	int getinput_ascii();

	//takes direct input key as argument and returns string message describing dik
	char *getinput_char(int dik);

	//fills RECT structure (for convenience)
	RECT &fillRECT(RECT &r, int x1, int y1, int x2, int y2);

	//turns 8bit number into bitstring
	//void bitstring(char *pc, unsigned char n, bool separator = false, char sepsymbol = ' ');
	//turns length-bit number into bitstring
	void bitstring(int n, char *pc, int length = 8, bool separator = false, char sepsymbol = ' ');

	//returns random number in argumented range
	int random(int max = 1, int min = 0);

	//---- demo functions ------------------------------------------------------------------------
	//used in developer

	//state demo simply saves player state when recording and
	//sets player to recorded states when playing back

	//starts recording a demo
	bool sdemo_startrec(char *pname,			//file name to store demo in
						int fps);				//number of frames to record demo with
												//-1 no limit

	//stops recording a demo started with sdemo_start()
	//or stops playback of demo
	bool sdemo_stop(int stop);					//0 = stop recording
												//1 = stop playback

	//records demo started with sdemo_start()
	bool sdemo_record();

	//starts demo playback
	bool sdemo_startplay(char *pname);

	//plays specified demo
	bool sdemo_playback();

	//---- new ingame demo functions --------------------------------------------------------------

	game_recorder		recorder;				//manages demo recording/replay

	//---- console -------------------------------------------------------------------------------

	//checks messages of all objects
	void con_check_dumpmessages();

	//registers console variable
	void RegisterConVars(console *pcon);

	//dumps message in console
	void con_add_message(char *format, ...);

	//clear console message string
	void con_clear();

	//---- hud text ------------------------------------------------------------------------------

	//writes message on hud
	void hud_add_message(int _hud_id, int color, char *format, ...);
	void hud_add_message(char *format, ...);

	//---- friend declarations -------------------------------------------------------------------

	friend struct console;

	//---- developer routines --------------------------------------------------------------------

	void dev_showdata();					//displays animation data

	void dev_edit();						//skeleton and animation editor

	void dev_input();						//checks developer input

	void dev_ingame();						//ingame input
};

#endif										//end MASTER_FRAME_H