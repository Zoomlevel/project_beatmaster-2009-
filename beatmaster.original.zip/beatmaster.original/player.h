//------------------------------------------------------------------------------------------------
//
//	player class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef PLAYER_H
#define PLAYER_H							//begin PLAYER_H

#include "structs.h"						//own structs (bones, skeleton, etc.)
#include "directinput.h"					//inputstate for bot class

//------------------------------------------------------------------------------------------------

//directsound.h
#define	NSBP								20				//number of soundbuffers

//sound buffer status
#define		SB_OFF							0
#define		SB_PLAY							1				//play (restart if already playing)
#define		SB_PLAY_NP						2				//play if not already playing
#define		SB_PAUSE						3
#define		SB_STOP							4

//player sound indices
//directsound.h
#define		S_ERROR							0

#define		S_JAB							1
#define		S_CROSS							2
#define		S_KICK_FWD						3
#define		S_KICK_SWD						4

#define		S_TAP							5

#define		S_HIT_STD						6
#define		S_HIT_DPART						7
#define		S_HIT_TAP						8
#define		S_HIT_RET						9
#define		S_HIT_BLOOD						10
#define		S_HIT_KO						11
#define		S_HIT_CANCEL					12

#define		S_ATT_LOCKED					13

#define		S_HEALTH						14

#define		S_AGA1							15
#define		S_AGA2							16
#define		S_UHU							17

#define		S_TAUNT1						18
#define		S_TAUNT2						19

//---- error message strings ---------------------------------------------------------------------

extern const char *gp_ErrStr;					//global error string, in winmain.cpp

//const char Err_DIDirectInputCreateEx[]		= "DirectInputCreateEx FAILED";
//const char Err_DICreateDeviceExKB[]			= "DI_CreateDeviceEx_KB FAILED";

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//------------------------------------------------------------------------------------------------

class player
{
//------------------------------------------------------------------------------------------------
//	private player objects
//------------------------------------------------------------------------------------------------

private:

	//---- timer/option data ---------------------------------------------------------------------

	const options	*p_option;						//pointer to options
	const timer		*p_time;						//pointer to timer
	float			t_sca_sf;						//passed time adjusted to subframes

	result_collision_detection		*p_rcd;			//pointer to object for master_frame

	int				*p_angle;						//pointer to inputstate angle, to reset angles
	int				*p_angle180;

	//---- hud text data -------------------------------------------------------------------------

	hud_text		*p_hud_text;					//pointer to hud text

//------------------------------------------------------------------------------------------------
//	private player functions
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//	public player objects
//------------------------------------------------------------------------------------------------

public:

	//---- general program data ------------------------------------------------------------------

	int								id;					//player id (0 = player 1, 1 = player 2)

	skeleton						sk;					//skeleton including bones
	int								dst_index[NODS][5];	//damage slot transfer indices
														//indicates for each damage slot the
														//damage slot it transfers exceeding damage to

	player							*p_opp;				//pointer to opponent

	//---- skills and game logic data ------------------------------------------------------------

	int								side;				//0 = left of other player
														//1 = right of other player
	int								asi;				//animation side index
														//left side, left foot forward = 0
														//left side, right foot forward = 1
														//right side, left foot forward = 2
														//right side, right foot forward = 3
	int								stance_feet;		//left, right side forward
	int								stance_arms;		//guard position
														//0 = lowest
														//1 = highest


	float							fatigue;			//fatigue from 0 to 100
	float							fatigue_buff;		//cumulative fatigue to apply
	float							fatigue_delay;		//holds delayed fatigue
	LONGLONG						t_fat_delay_start;	//fatigue delay start time
	LONGLONG						t_fatdam_last;		//fatigue to damage last poll time
	float							skill_freg;			//fatigue regeneration skill in units per second
	float							skill_freg_ad;		//regeneration skill adjusted to damage taken

	float							walk_fwd_ad;		//adjusted walking speed
	float							walk_bwd_ad;
	float							walk_fwd_rush;		//rush speed
	float							walk_bwd_rush;
	int								walk_lock;			//walk action at start of an action
														//0 = not valid
														//-1 = no movement
														//1 = move fwd
														//2 = move bwd
	int								walk_kftb_fwd[4][21];	//walking time keyframe backup
	int								walk_kftb_bwd[4][21];

	int								power_attack[2];	//if power attack possible
														//(arms and legs)
	LONGLONG						t_power_attack[2];	//start of valid power attack

	int								cd_bh_force[19];	//force in degree with which bhi indexed bone is hit

	LONGLONG						cd_t_pushhit;		//time index when player gets pushed back due hit
	int								cd_push_type;		//type of push back
														//0 = stop player forward movement
														//1 = push player backward, may be canceled to stop
														//when player hits forward
														//2 = push player backwards, no canceling possible
	float							cd_push_force;		//force of push in seconds
	float							cd_push_speed;		//adjusts walk speed when hit
	int								cd_cancel_action;	//0 = don't cancel action
														//1 = cancel action

	lock_data						gl_lock;			//holds lock data

	float							*p_distance;		//pointer to distance between players

	int								damage_dealt_last;	//last net damage to opponent

	//---- combo data ----------------------------------------------------------------------------

	LONGLONG						t_combo_lasthit;		//time index of last hit
	int								combo_counter;			//combo counter
	int								combo_damage;			//cumulative combo damage

	//--------------------------------------------------------------------------------------------

	float							gl_score;						//score of player
	float							gl_score_multiplier_off[19];	//holds score multipliers for damage done
	float							gl_score_multiplier_def[19];	//holds score multipliers for damage taken

	int								gl_ko;							//knockout flag
	int								gl_ko_pending;					//if ko_limit set and nearly ko

	int								active_off[6];					//attacking limbs
	bool							gl_def_success;					//indicates if defense animation
																	//was hit by attack (so no def lock set)

	//---- fx ------------------------------------------------------------------------------------

	particle_heap			blood_fx[2];						//2 blood particle heaps
	int						blood_active[2];					//indicates which heap is active
	int						blood_size[2];						//number of particles to draw
	point					blood_force[2];						//min and max force for both heaps
	float					blood_angle_h[2];					//angle between head and attacking limb
	point					blood_angle[2];						//min and max angle for both heaps

	bool					blood_gammaflash;					//set true if to gamma flash screen

	player_message			pmessage;							//player message displayed above head

	//---- animation data ------------------------------------------------------------------------

	animation				*p_anmn[4][NPAN];					//pointer to all animations (both stances, both sides)
																//assigned in master_frame initialization
	animation				*p_aslot[3];						//animation slots
																//0 for idling/walking
																//1 for actions
																//2 for hit animations

	LONGLONG				opp_time[2];						//holds time index of oppenents attacks for both slots

	int						last_anmn[2];						//index of last animations for both slots
																//if non-idle animation and new idle animation
																//gets assigned, first keyframe of it will be a fast
																//one so that the figure will move quicker into its
																//default postion
	int						advance_slot[2];					//for both slots, if action animation hits
																//the advance_slot is set to 1 so the animation
																//cki gets advanced by 1
																//flag is set during subframes but first applied
																//in the next real frame else the animation could
																//be on the way back before beeing drawn as hit
	LONGLONG				t_advanceslot_start[2];				//start time for slot advance

																//adjust animation after specified amount of time and
																//animation then is still moving forward
	LONGLONG				t_animation_adj_start[2];			//start time (both slots)
	int						t_animation_adj_delay[2];			//time in milliseconds after start when animation to adjust
	int						animation_adj_type[2];				//type of adjustment

	int						casi[21];							//current animation slot index for all bones and hara
	int						cki[21];							//current keyframe index for all bones and hara
																//in reference to casi

	//---- al runtime data -----------------------------------------------------------------------

	int						bpc[2][22];							//for both slots holds for each index/prioritiy the
																//number of bones with this priority
																//bpc[][21] is the number of all bones in this slot
	int						bdc[2][22];							//number of bones of indexed priority which are done
																//bdc[][21] is the number of bones of the animation slot done

	int						bhi[22];							//bone hit indicator
																//0 = not hit
																//1 = hit
																//19, 20, 21 = head, fist left, fist right

	int						al_legtap_last_a[4];				//last angle and angle_180 for leg tap
	int						al_legtap_last_a_180[4];			//(to lock angle if def_lock on)
																//for all 4 asi
	LONGLONG				t_last_tap_arms;					//time index of last tap_arms and legs
	LONGLONG				t_last_tap_legs;

	//---- sound data ----------------------------------------------------------------------------

	char							s_buffer[NSBP];				//soundbuffer array indicating sound-fx status
																//0 = not playing (not TO BE stopped)
																//1 = play
																//2	= pause
																//3 = stop

	int								s_pan;						//sound pan of player in dependance of position
																//gets calculated in process_bones()

	//---- console variables ---------------------------------------------------------------------

	char							con_dumpmessage[CON_LINEMAX];	//console dump message

//	CLASS_CON_VAR(float, fatigue);

	//---- developer data ------------------------------------------------------------------------

	int								dev_i;						//can be filled with various data
	float							dev_f;						//just used to check certain values

	int								*dev_pi;
	float							*dev_pf;

//------------------------------------------------------------------------------------------------
//	public player functions
//------------------------------------------------------------------------------------------------

	//constructor
	player();

	//!!
	//cleanup
	void pl_cleanup();

	//reset values before new round
	void reset(int pos);										//0 = P1 left, P2 right
																//!0 = P1 right, P2 left

	//player initialization
	bool pl_initialization(int player);							//player 1 starts left, p2 right

	//sets pointers to data of opponent
	void set_opp_data(player *_opp);

	//set pointer to timer and option data
	void set_data_pointer(options *_options, timer *_timer, hud_text *_hud,
						  result_collision_detection *p_rcd_,
						  int *p_a, int *p_a180,
						  float *p_dist);

	//sets z-order of player
	void set_z_order(int _tll, int _tlr, int _tul, int _tur, int _n,
					 int _sl, int _aul, int _all,
					 int _sr, int _aur, int _alr,
					 int _hl, int _lul, int _lll, int _fl,
					 int _hr, int _lur, int _llr, int _fr);

	//sets player feet stance and changes all skeleton values in accordance
	void set_stance(int stance);						//0 = left, 1 = right

	//sets player to side given in argument
	void set_side(int _side);							//0 = left, 1 = right

	//calculates player bones, shadows, hitboxes
	void process_bones(point s_scale,					//shadow scale
					   int s_mpy);						//shadow plane

	//---- animation -----------------------------------------------------------------------------

	//sets skeleton to argumented animations keyframe
	void set_keyframe(int anmn_index, int keyframe, float s_zoom = 1.0f);

	//overloaded
	//sets only specified bones to keyframe
	void set_keyframe(int anmn_index, int keyframe, float s_zoom, bool _b[19]);

	//activates animation slot
	void al_activate_slot(int slot,
						  int player_action,
						  int angle = -1,					//angle of action
						  int angle_180 = -1,				//default - 1 (not valid)
						  bool sf = true);					//sf if to apply speedfactor

	//deactivates animation slot
	void al_deactivate_slot(int slot,						//slot to be deactivated
							bool fat = true);				//false if not to apply fatigue

	//assigns bone according to priority
	void al_set_priority();

	//creates idle cycle depending on fatigue out of idle sets
	void al_create_idle_cycle(int type,						//0 = for upper body
															//1 = for lower body
							  int fast_kf);					//if > 0 it's the time in milliseconds
															//the first keyframe of the idle animation
															//is set to
															//used to show guard changes immediatley
															//and revert to idling after an action

	//adjusts positions of arms in walk animation according to stance_arms
	void al_create_walk_cycle(int direction,				//forward or backward walking
															//(index of animation)
							  float speedfactor);			//speedfactor to adjust keyframe timing
															//depending on walk speed of player
															//(which is affected by damage, etc.)

	//adjusts speed of walking animation keyframes during acceleration
	void al_adjust_walk_cycle(int direction, float speedfactor);

	void al_animate(bool set_zoom);							//if true, sets player to s_zoom without interpolating

	//sets freeze frame
	void al_SetFreezeFrame(int slot, int t_freeze);

	//sets delayed animation adjustment
	void al_SetDelayedAnimationAdj(int slot, int t_delay, int type);	//slot and delay time in milliseconds, time of adjustment
	//resets delayed animation adjustment data
	void al_ResetDelayedAnimationAdj(int slot);
	//checks and executes delayed animation adjustment
	void al_ProcessDelayAnimationAdj();

	//--------------------------------------------------------------------------------------------

	//updates particle arrays
	void al_update_particles(int shadows, point s_scale, int s_mpy, float s_speed, float s_zoom);

	//---- game logic ----------------------------------------------------------------------------

	//called once per frame, handles user input
	void gl_process_input(int PA[2][NPAN],					//inputstate data
						  int angle[2],
						  int angle_180[2],
						  float t_move[2][2]);

	//game logic main routine, called every subframe
	void gl_process_game_logic(float t_move[2][2]);

	//sets speedfactor of animation depending on fatigue and bone damage
	//called by function pointer within animator	
	void gl_set_speedfactor(int slot);						//slot to apply speedfactor to

	//sets cd_state of bones according to data in animation with higher priority
	void gl_set_cd_state();

	//adds fatigue value from animation to fatigue buffer
	void gl_fatigue_add(int slot, int type,					//0 = standard, 1 = cancel fatigue, 2 = air attack, increased, 3 = power attack, more increased
						float instant = 0);					//if != 0 this value gets applied, ignoring the value of animation

	//fatigue interpolator
	void gl_fatigue_interpolator();

	//calculate and apply damage taken
	void gl_process_damage_def(int _bone,					//index of bone which takes the damage
							   float _dam,					//damage
							   int &_defbi,					//bone index with defense bonus
							   float t_move[2][2],			//move time
							   bool retdamage = false,		//return damage
							   bool fatdamage = false);		//fatigue damage

	//applies damage to argumented damage slot
	//returns applied damage
	int gl_apply_damage(int ds, int* p_damage, bool first = false);
															//first: if damage to apply is more
															//than bone can take and damage
															//transfer is on this function gets
															//called multiple times til no damage
															//left. for every call after the first
															//the bones of the damage slot the
															//damage is transfered to will flash.
															//to not flash the whole damage slot
															//of the bone which is originally hit
															//this flag is set true.

	//set bones to hit slot
	//called by gl_process_damage_def
	void gl_SetHitBone(int _bone,							//bone which is hit
					   float dam_final);					//applied damage

	//calculate offensive damage done to opponent, returns damage
	float gl_process_damage_off(float t_move[2][2]);

	//returns animation index of evade action depending on opponents attack and attack heigth
	int gl_GetAutoEvade();

	//selects auto tapping action depening on
	//lock state of limbs
	//stance_arms
	//distance to opponent
	//opponents attack and attack height
	//values returned as argumented pointers
	//
	//in dm_sim ptap has to hold pressed tap button (punches or kick)
	//if wrong button, tap type gets changed but is locked
	void gl_GetAutoTap(int *ptap, int *pangle, int *pangle_180);

	//new version of gl_SetSolidTapData() for new tap animation variations
	void gl_SetTapArmsAnmn();
	//sets leg tap animation depending on height of opponents attack
	void gl_SetTapLegAnmn(int *pangle, int *pangle_180);	//arguments get pointer to angle data

	//sets push
	void gl_SetPush(int type,							//0 = stop player forward movement
														//1 = push player backward, may be canceled
														//to stop when player walks forward
														//2 = push player backward, no canceling
														//3 = drag player forward
														//increases fwd speed, decreases bwd speed
														//4 = drag player forward, no canceling
					float force,						//time of push in seconds
					float speed);						//(additional) walking speed

	//reverse push
	void gl_ReversePush();								//reverses push (for side change)

	//stops and resets push
	void gl_ResetPush();

	//sets handicap data
	void gl_SetHandicap();

	//sets bone lock state
	void gl_SetBoneLockState(bool reset = false);

	//---- sound ---------------------------------------------------------------------------------

	//reset soundbuffer
	void s_reset_soundbuffer();

	//sets soundbuffer of argumented slot to argumented state
	//returns false if slot not valid/active or slot has no valid sound id
	bool s_set_slotsound(int slot,								//slot with animation with sound-id
						 int SC);								//sound command, defined

	//sets argumented sound to argumented state
	void s_set_sound(int soundid, int SC = SB_PLAY);	//#defined sound id and state (default = play)

	//---- console -------------------------------------------------------------------------------

	//registers console variable
	void RegisterConVars(console *pcon);

	//dumps message in console
	void con_add_message(char *format, ...);

	//clear console message string
	void con_clear();

	//---- hud text ------------------------------------------------------------------------------

	//writes message on hud
	void hud_add_message(int _hud_id, int color, char *format, ...);
	void hud_add_message(char *format, ...);

	//---- elemantary routines -------------------------------------------------------------------

	//converts float into string which gets stored in argumented character array
	//(number as double because float seems unsupported by va_arg and co.)
	void float_string(char numberstring[], int precision, double number);

	//sorts a given float array
	void quicksort(float data[],			//array with data
				   int l,					//always 0, left border index of array
				   int r,					//right border index of array (including 0)
				   int order = 0);			//0 = lowest to largest, 1 = largest to lowest
};

#endif										//end PLAYER_H
