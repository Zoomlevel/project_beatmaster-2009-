//---- old insert developer code ------------------------------------------------------------------

//particle_heap ph;
//ph.pp = dd.font_pfx_32(LABEL, ph.size, 100, 100);
//dd.drawparticles(ph.pp, ph.size, OFF, 3, 0);

/*if (is.dimouse1D[1].rgbButtons[0] & 0x80)
{
	SHELLEXECUTEINFO sei;
	sei.cbSize = sizeof(sei);
	sei.lpDirectory = FERROR;
	if (!ShellExecuteEx(&sei))
		hud_add_message(0, bmfred, "!0");
	int ser = 0;
//	ser = (int)ShellExecute(NULL, "open", FERROR, NULL, NULL, SW_MINIMIZE);
//	hud_add_message(1, bmfgreen, "%i", ser);
//	if (ser == ERROR_FILE_NOT_FOUND)
//		hud_add_message(1, bmfgreen, "ERROR_FILE_NOT_FOUND");
//	ShellExecute(NULL, "open", U_BITMAP, NULL, NULL, SW_SHOWNORMAL);
}*/

/*						static int drawtype = -1;
						if (is.key1D(DIK_W))
						{
							if (drawtype < 2)
								++drawtype;
						}
						if (is.key1D(DIK_S))
						{
							if (drawtype > -1)
								--drawtype;
						}
						dd.drawtest(drawtype);
						dd.typebmf(10, 42, bmfred, "DRAWTYPE %i", drawtype);*/

//shadow edit
if (true)
{
point	center	= P[P1].sk.b[0].v.p[0];
static float	length	= 100.0f;
static float	sangle	= 90.0f;

float	angle_rad	= sangle / 180.0f * 3.14;
point	pend;
pend.x	= center.x + length * cos(angle_rad);
pend.y	= center.y + length * sin(angle_rad);

line	lsu;
lsu.set_line(center.x, center.y, pend.x, pend.y);

dd.drawline(lsu, black);

sangle	+= is.dimouse[0].lX;
if (is.dimouse1D[0].rgbButtons[0] & 0x80)
	sangle	= 0;

s_scale.x	= (pend.x - center.x) / 100.0f;
s_scale.y	= (pend.y - center.y) / 200.0f;

dd.typebmf(10, 164, bmfblue, "x, y: %.1f  %.1f", s_scale.x, s_scale.y);
}

//fatigue hold
/*
static int fhold = 0;
static LONGLONG t_fholdstart = 0;
dd.typebmf(10, 116, bmfblack, "fhold: %i (%.1f)", fhold, (float)((float)(time.current - t_fholdstart) / time.freq));

if (is.dikey[DIK_A] & 0x80 &&
	is.dikey[DIK_D] & 0x80 &&
	is.dikey1D[DIK_S] & 0x80)
{
	fhold = !fhold;

	if (fhold)
		t_fholdstart = time.current;
	else
		t_fholdstart = 0;
}

if (fhold &&
	(float)(time.current - t_fholdstart) / time.freq > 1.5f)
{
	fhold = 0;
	P[P1].fatigue_buff += 40;
//	if (P[P1].fatigue > 100)
//		P[P1].fatigue = 100;
}

if (is.dikey1D[DIK_X] & 0x80)
	P[P1].fatigue_buff += 100;

if (fhold)
{
	P[P1].fatigue_buff = 0;
	dd.drawcircle((int)P[P1].sk.chead.x, (int)P[P1].sk.chead.y, 5, red);
}*/

////push/pull (p + k) + mx
/*
if (is.dimouse[0].rgbButtons[0] & 0x80 &&
	is.dimouse[0].rgbButtons[1] & 0x80)
//if (is.dikey[DIK_S] & 0x80)
{
	if (is.dimouse[0].lX > 10)
//	if (is.dimouse1D[0].rgbButtons[0] & 0x80)
	{
		if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_PUSH_ARMS])
		{
			P[P1].al_activate_slot(aslot_action, AN_PUSH_ARMS, 0, 90);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}
	}
	if (is.dimouse[0].lX < -10)
//	if (is.dimouse1D[0].rgbButtons[1] & 0x80)
	{
		if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_PULL_ARMS])
		{
			P[P1].al_activate_slot(aslot_action, AN_PULL_ARMS, 0, 90);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}
	}
}*/

//---- non linear color table change ----
/*
static double var_1 = 1.0;
static double var_2 = 1.0;

if (is.dikey[DIK_W] & 0x80)
{
	var_1 += is.dimouse[0].lY * 0.01;
	if (is.dimouse1D[0].rgbButtons[0] & 0x80)
		var_1 = 1.0;
}
if (is.dikey[DIK_E] & 0x80)
{
	var_2 += is.dimouse[0].lY * 0.01;
	if (is.dimouse1D[0].rgbButtons[0] & 0x80)
		var_2 = 1.0;
}

dd.typebmf(10, 100, bmfblack, "var_1 %.3f", (float)var_1);
dd.typebmf(10, 116, bmfblack, "var_2 %.3f", (float)var_2);

//assign
if (false)
if (is.dikey1D[DIK_F] & 0x80)
{
	playsound_s(S_ERROR);

	float f_index	= 0.0f;
	WORD i_index	= 0;

	for (register int i = 0; i < 50; ++i)
	{
//f_index	= 0.0255f * i * i;
f_index		= pow (i, var_2) * (255.0 / pow(49, var_2));

if (f_index > 255)	f_index = 255;
if (f_index < 0)	f_index = 0;

		//round index to one place behind point
		i_index		= (WORD)(f_index);
		dd.p_bluewhiteLUT[i][0]	= 0;
		dd.p_bluewhiteLUT[i][1]	= i_index;
		dd.p_bluewhiteLUT[i][2]	= 255;
	}
}

/*
line x_axis(100, 500,
			200, 500);
line y_axis(100, 500,
			100, 500 - 255);
dd.drawline(y_axis, black);
dd.drawline(x_axis, black);
line x_axis_s(200, 500,
			  300, 500);
dd.drawline(x_axis_s, blue);
static point lastpoint(100, 500);
for (register int x = 0; x < 50; ++x)
{
//	float y = x * 5.020f;
//	ax2 + bc + c
	float y = 0.1f * x * x;// - 0.1f * x;

//y = 0.0255f * x * x;
//y = x hoch p/q (p >= 1, q >= 2)
//y = pow(x, 1.0 / 2.0) * 25.5;
//y = pow(0.5 * x, 0.5) * 36;
y = (
	 pow(1.0 * x, var_2)
	)*(
	255.0 / pow(1.0 * 49, var_2)
	);

	point coord(2 * x + 100, 500 - y);

//	dd.drawpoint(coord, red);
	line l(lastpoint.x, lastpoint.y, coord.x, coord.y);
	if (0)
		dd.drawline(l, red);
	lastpoint = coord;

	if (x == 0)
		dd.typebmf(10, 200, bmfblack, "x = 0,   y = %.2f", y);
	if (x == 49)
		dd.typebmf(10, 216, bmfblack, "x = 49,  y = %.2f (%i %i %i)", y, dd.p_blackwhiteLUT[49][0], dd.p_blackwhiteLUT[49][1], dd.p_blackwhiteLUT[49][2]);
	if (x == 74)
		dd.typebmf(10, 232, bmfblack, "x = 74,  y = %.2f (%i %i %i)", y, dd.p_blackwhiteLUT[74][0], dd.p_blackwhiteLUT[74][1], dd.p_blackwhiteLUT[74][2]);
	if (x == 100)
		dd.typebmf(10, 248, bmfblack, "x = 100, y = %.2f", y);
}

//color table
if (0)
for (register int i = 0; i < 101; ++i)
{
	rectangle r;
	r.fill_rectangle(100 + i * 4, 100,
					 100 + i * 4 + 4, 100,
					 100 + i * 4 + 4, 120,
					 100 + i * 4, 120);
	RGBcolor c(dd.p_greenredLUT[i][0],
			   dd.p_greenredLUT[i][1],
			   dd.p_greenredLUT[i][2]);
	dd.drawrectangle_f(r, c);
//	if (i == 49)
//		dd.drawrectangle_uf(r, black);

	r.fill_rectangle(100 + i * 4, 121,
					 100 + i * 4 + 4, 121,
					 100 + i * 4 + 4, 141,
					 100 + i * 4, 141);
	c.setcolor(dd.p_bluewhiteLUT[100 - i][0],
			   dd.p_bluewhiteLUT[100 - i][1],
			   dd.p_bluewhiteLUT[100 - i][2]);
	dd.drawrectangle_f(r, c);
//	if (i == 49)
//		dd.drawrectangle_uf(r, black);
}*/

/*static LONGLONG		t_cflashstart = 0;
static circle		circleflash;
static bool			cf_active = false;

if (is.dikey1D[DIK_F] & 0x80)
{
	t_cflashstart	= time.current;
	cf_active		= true;
	circleflash.c.x		= P[P1].sk.chead.x + 15;
	circleflash.c.y		= P[P1].sk.chead.y;
}

for (register int b = 0; b < 19; ++b)
{
//	if (rcd.bone[P2][b])
	if (P[P2].sk.b[b].hit_state)
	{
		playsound_s(S_ERROR);
		t_cflashstart	= time.current;
		cf_active		= true;
		circleflash.c.x		= P[P2].sk.b[b].v.p[0].x;;
		circleflash.c.y		= P[P2].sk.b[b].v.p[0].y;;
	}
}

float tf = 0.1f;

if (cf_active)
{
	if ((float)(time.current - t_cflashstart) / time.freq < tf)
	{
//	circleflash.c.x		= P[P1].sk.chead.x + 15;
//	circleflash.c.y		= P[P1].sk.chead.y;
		circleflash.radius = 200.0f * ((float)(time.current - t_cflashstart) / time.freq);
		dd.drawcircle((int)circleflash.c.x, (int)circleflash.c.y, (int)circleflash.radius, red);
	}
	else
		cf_active = false;
}

dd.typebmf(100, 100, bmfblack, "%i %i %i", (int)circleflash.c.x, (int)circleflash.c.y, (int)circleflash.radius);
dd.typebmf(100, 116, bmfblack, "%.2f", (float)(time.current - t_cflashstart) / time.freq);
*/


/*
dd.typebmf(100, 100, bmfblack, "lock: %i", (int)P[P1].gl_lock.get_lockstate(baul, P[P1].asi));
if (P[P1].p_aslot[aslot_action] != NULL)
	dd.typebmf(100, 116, bmfblack, "action: %i", P[P1].p_aslot[aslot_action]->id);
else
	dd.typebmf(100, 116, bmfblack, "action: NULL");

static point pfocus;

if (P[P1].p_aslot[aslot_action] == NULL ||
	P[P1].p_aslot[aslot_action]->id == 3)
	if (is.dimouse[P1].lX < 3 && is.dimouse[P1].lX > -3)
		if (is.dimouse[P1].lY)
			pfocus.y += is.dimouse[P1].lY;
if (pfocus.y < P[P1].sk.r_hbp.top)
	pfocus.y = (float)P[P1].sk.r_hbp.top;
if (pfocus.y > P[P1].sk.r_hbp.bottom)
	pfocus.y = (float)P[P1].sk.r_hbp.bottom;
if (P[P1].side == SLEFT)
	pfocus.x = (float)P[P1].sk.r_hbp.right + 20;
else
	pfocus.x = (float)P[P1].sk.r_hbp.left - 20;

dd.drawcircle((int)pfocus.x, (int)pfocus.y, 5, red);

/////////

line visor;

visor.p[0] = P[P1].sk.chead;
visor.p[1].x	= visor.p[0].x + 13;
visor.p[1].y	= visor.p[0].y;

dd.drawline(visor, black);*/

/*dd.typebmf(100, 100, bmfblack, "cmessages: %i %i", P[P1].pmessage.cmessages, P[P2].pmessage.cmessages);

for (register int m = 0; m < NPMESSAGES; ++m)
{
	dd.typebmf(100 + (16 * m), 116, bmfblack, "%i", (int)P[P2].pmessage.pm[m].active);
	dd.typebmf(100 + (16 * m), 132, bmfblack, "%i", (int)P[P2].pmessage.pm_sorted[m]);
	dd.typebmf(100 + (100 * m), 148, bmfblack, "%i", (int)P[P2].pmessage.pm[m].t_start);
}
dd.typebmf(500, 164, bmfblack, "%i", (int)time.current);*/

//if (is.dikey1D[DIK_S] & 0x80)
//	dd.gamma_set(1.0f, 0.5f, 1.0f);
//if (is.dikey1D[DIK_D] & 0x80)
//	dd.gamma_set(1.0f, 1.0f, 1.0f);

/*for (register int m = 0; m < NPMESSAGES; ++m)
{
	dd.typebmf(100, 100 + (16 * m), bmfblack, "[%i] %.1f %s",
			   P[P1].pmessage.pm[m].active,
			   P[P1].pmessage.pm[m].cpos.y,
			   P[P1].pmessage.pm[m].message);

	dd.typebmf(500, 100 + (16 * m), bmfblack, "[%i] %.1f %s",
			   P[P2].pmessage.pm[m].active,
			   P[P2].pmessage.pm[m].cpos.y,
			   P[P2].pmessage.pm[m].message);
}

dd.typebmf(100, 80, bmfblack, "%.10f", (float)time.sca);*/

/*if (P[P1].p_aslot[aslot_action] == NULL ||
	P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_IDLE_LO])
{
	if (is.dimouse[P1].lY < -10)
	{
		if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_TAP_ARMS])
		{
			P[P1].gl_SetSolidTapData();
			P[P1].al_activate_slot(aslot_action, AN_TAP_ARMS);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}
		else
		{
			//set defense lock on
			//gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
			//if not in guard or in guard but at least 0.03 sec passed (adjusted to game speed)
			if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_GUARD_ARMS] ||
				(P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_GUARD_ARMS] &&
				P[P1].p_aslot[aslot_action]->gl_time[P1] + (0.12f / option.data.speed) * time.freq <= time.current))
			{
				P[P1].al_activate_slot(aslot_action, AN_GUARD_ARMS);
				P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
			}
		}
	}
	if (is.dimouse[P1].lY > 10)
	{
		if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_TAP_LEG])
		{
			P[P1].gl_SetSolidTapData();
			P[P1].al_activate_slot(aslot_action, AN_TAP_LEG);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}
		else
		{
			//set defense lock on
			//if (asi == 0 || asi == 2)	gl_lock.set_lockstate(DEFENSIVE, 2, 0, ON, 0, p_time->current);
			//else						gl_lock.set_lockstate(DEFENSIVE, 3, 0, ON, 0, p_time->current);
			//if not in guard or in guard but at least 0.03 sec passed (adjusted to game speed)
			if (P[P1].p_aslot[aslot_action] != P[P1].p_anmn[P[P1].asi][AN_GUARD_LEGS] ||
				(P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_GUARD_LEGS] &&
				P[P1].p_aslot[aslot_action]->gl_time[P1] + (0.12f / option.data.speed) * time.freq <= time.current))
			{
				P[P1].al_activate_slot(aslot_action, AN_GUARD_LEGS);
				P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
			}
		}
	}
}

dd.typebmf(100, 100, bmfblack, "y: %i", is.dimouse[P1].lY);*/

/*
if (P[P1].p_aslot[aslot_cycle] != NULL)
{
	dd.typebmf(100, 100, bmfblack, "cycle: %i", P[P1].p_aslot[aslot_cycle]->id);
}
if (P[P1].p_aslot[aslot_action] != NULL)
{
	dd.typebmf(100, 116, bmfblack, "action: %i", P[P1].p_aslot[aslot_action]->id);
}
if (P[P2].p_aslot[aslot_cycle] != NULL)
{
	dd.typebmf(200, 100, bmfblack, "%i", P[P2].p_aslot[aslot_cycle]->id);
}
if (P[P2].p_aslot[aslot_action] != NULL)
{
	dd.typebmf(200, 116, bmfblack, "%i", P[P2].p_aslot[aslot_action]->id);
}

dd.typebmf(100, 116 + 50, bmfblack, "s: %i d: %i", P[P1].t_animation_adj_start[aslot_action],
		   P[P1].t_animation_adj_delay[aslot_action]);

dd.typebmf(100, 132 + 50, bmfblack, "fat: %.1f", (float)P[P1].fatigue);*/

//dd.typebmf(100, 116 + 50, bmfblack, "stance: %i", P[P1].stance_arms);
//dd.typebmf(100, 132 + 50, bmfblack, "skill_freg_ad: %.1f", P[P1].skill_freg_ad);
//dd.typebmf(100, 148 + 50, bmfblack, "defbi: %i %i", (int)P[P1].dev_i, (int)P[P2].dev_i);

/*
dd.typebmf(100, 100, bmfblack, "dam dealt: %i %i", P[P1].damage_dealt_last, P[P2].damage_dealt_last);
dd.typebmf(100, 116, bmfblue, "as: %i %i", P[P1].advance_slot[0], P[P1].advance_slot[1]);
dd.typebmf(100, 132, bmfblack, "lo %i %i %i %i",
		   P[P1].gl_lock.lock_off[0],
		   P[P1].gl_lock.lock_off[1],
		   P[P1].gl_lock.lock_off[2],
		   P[P1].gl_lock.lock_off[3]);
dd.typebmf(100, 148, bmfblack, "ld %i %i %i %i",
		   P[P1].gl_lock.lock_def[0],
		   P[P1].gl_lock.lock_def[1],
		   P[P1].gl_lock.lock_def[2],
		   P[P1].gl_lock.lock_def[3]);

dd.typebmf(100, 80, bmfblue, "fat: %.1f (%.1f)", P[P1].fatigue, P[P1].fatigue_buff);

dd.typebmf(100, 164, bmfblack, "pre %i    %i", is.mm_angle_pre[P1], is.mm_angle_180_pre[P1]);
dd.typebmf(100, 180, bmfblack, "fin %i    %i", is.mm_angle[P1], is.mm_angle_180[P1]);

dd.typebmf(100, 500, bmfblack, "def: %i %i", P[P1].gl_def_success, P[P2].gl_def_success);
*/
//dd.drawrectangle_uf(hud_text[0].rdim, red);
//dd.drawrectangle_uf(hud_text[1].rdim, blue);

/*if (is.key1D(DIK_SPACE))
{
	int length = 5 + (rand() % (40 - 5 + 1));
	char *pc = new char[length];
	for (register int i = 0; i < length - 1; ++i)
	{
		pc[i] = 48 + (rand() % (90 - 48 + 1));
	}
	pc[length - 1] = 0;
	hud_add_message(0, bmfred, pc);
	delete []	pc;
	pc			= NULL;
//	hud_add_message(0, bmfred, "TEST_TEXT %i", hud_text[0].entries);
}*/
//if (is.key1D(DIK_D))
//	hud_add_message(1, bmfblue, "TEST_TEXT %i", hud_text[1].entries);

//dd.typebmf(100, 550, bmfyellow, "entries: %i", hud_text[0].entries);
//dd.typebmf(400, 550, bmfyellow, "entries: %i", hud_text[1].entries);

//----

//dd.typebmf(100, 100, bmfblue, "distance: %.1f", player_distance);

/*dd.typebmf(100, 100, bmfred, "DAMAGE %i",
		   11 * 100 -
		   (P[P1].sk.damage[0] +
		   P[P1].sk.damage[1] +
		   P[P1].sk.damage[2] +
		   P[P1].sk.damage[3] +
		   P[P1].sk.damage[4] +
		   P[P1].sk.damage[5] +
		   P[P1].sk.damage[6] +
		   P[P1].sk.damage[7] +
		   P[P1].sk.damage[8] +
		   P[P1].sk.damage[9] +
		   P[P1].sk.damage[10]));*/

//if (is.dimouse1D[1].rgbButtons[1] & 0x80)
//	playsound_s(S_ERROR);

/*
static int mx = 0;

if (is.dimouse[1].rgbButtons[0] & 0x80)
{
	mx += is.dimouse[1].lX;
}
else
	mx = 0;

dd.typebmf(100, 100, 0, "mouse movement %i", mx);

static int counter = 0;

if (is.PA[P1][AN_TAUNT1] == 1)
	++counter;
if (is.key1D(DIK_RETURN))
	counter = 0;
dd.typebmf(100, 116, 0, "counter %i", counter);

dd.typebmf(100, 132, 0, "stance %i", P[P1].stance_arms);

dd.typebmf(100, 148, 0, "lX %i lY %i", is.dimouse[1].lX, is.dimouse[1].lY);

dd.typebmf(100, 164, 0, "fat: %.1f", P[P1].fatigue);

dd.typebmf(100, 180, 0, "t: %.1f m: %i",
		   is.t_ui_assigned[P1][DEFEND],
		   (int)is.mm_t_start[P1]);



dd.typebmf(500, 100, 0, "pa %i pa180 %i",
		   is.mm_angle_pre[P1],
		   is.mm_angle_180_pre[P1]);
dd.typebmf(500, 116, 0, " a %i  a180 %i",
		   is.mm_angle[P1],
		   is.mm_angle_180[P1]);

dd.typebmf(500, 132, 0, "mm_button %i flag %i", is.mm_button[P1], is.mm_button_flag[P1]);
dd.typebmf(500, 148, 0, "mm_length_c %.1f", is.mm_length_c[P1]);
dd.typebmf(500, 164, 0, "mcx %i mcy %i", is.mcx[P1], is.mcy[P1]);
dd.typebmf(500, 180, 0, "mmx %i mmy %i", is.mmx[P1], is.mmy[P1]);

if (P[P1].p_aslot[aslot_action] != NULL)
	dd.typebmf(100, 400, 0, "aslot_action: %i",
			   P[P1].p_aslot[aslot_action]->id);
dd.typebmf(100, 416, 0, "%i %i", is.PA[P1][AN_GUARD_FULL], is.PA[P1][AN_DEFEND]);
*/

/*dd.typebmf(500, 100, 0, "lock def: %i %i %i %i",
		   P[P1].gl_lock.lock_def[0],
		   P[P1].gl_lock.lock_def[1],
		   P[P1].gl_lock.lock_def[2],
		   P[P1].gl_lock.lock_def[3]);
dd.typebmf(500, 116, 0, "lock off: %i %i %i %i",
		   P[P1].gl_lock.lock_off[0],
		   P[P1].gl_lock.lock_off[1],
		   P[P1].gl_lock.lock_off[2],
		   P[P1].gl_lock.lock_off[3]);
dd.typebmf(500, 132, 0, "lock defc: %i %i %i %i",
		   P[P1].gl_lock.lock_defc[0],
		   P[P1].gl_lock.lock_defc[1],
		   P[P1].gl_lock.lock_defc[2],
		   P[P1].gl_lock.lock_defc[3]);
dd.typebmf(500, 148, 0, "lock offc: %i %i %i %i",
		   P[P1].gl_lock.lock_offc[0],
		   P[P1].gl_lock.lock_offc[1],
		   P[P1].gl_lock.lock_offc[2],
		   P[P1].gl_lock.lock_offc[3]);
dd.typebmf(500, 164, 0, "lock ang: %i %i %i %i",
		   P[P1].gl_lock.angle_off[0],
		   P[P1].gl_lock.angle_off[1],
		   P[P1].gl_lock.angle_off[2],
		   P[P1].gl_lock.angle_off[3]);

dd.typebmf(100, 148, 0, "%i %i", (int)P[P1].gl_lock.ts_def[0], (int)P[P1].gl_lock.ts_def[1]);*/

//color table
/*
static int ymin	= 0;
static int ymax = 50;
static int rmin	= 50;
static int rmax = 101;


//if (is.key1D(DIK_Y))
if (false)
{
	delete []	dd.p_greenredLUT;
	dd.p_greenredLUT	= NULL;

	dd.p_greenredLUT	= dd.cgreenred_LUT(ymin, ymax, rmin, rmax);
}

if (is.key(DIK_Q))
{
	ymin += is.dimouse[0].lX;
	if (ymin < 0)		ymin	= 0;
	if (ymin > 101)		ymin	= 101;
}
if (is.key(DIK_W))
{
	ymax += is.dimouse[0].lX;
	if (ymax < 0)		ymax	= 0;
	if (ymax > 101)		ymax	= 101;
}
if (is.key(DIK_A))
{
	rmin += is.dimouse[0].lX;
	if (rmin < 0)		rmin	= 0;
	if (rmin > 101)		rmin	= 101;
}
if (is.key(DIK_S))
{
	rmax += is.dimouse[0].lX;
	if (rmax < 0)		rmax	= 0;
	if (rmax > 101)		rmax	= 101;
}

dd.typebmf(100, 200, 0, "ymin: %i ymax: %i", ymin, ymax);
dd.typebmf(100, 216, 0, "rmin: %i rmax: %i", rmin, rmax);


for (register int c = 0; c < 256; ++c)
{
	rectangle r(c * 3, 100, c * 3 + 3, 100,
				c * 3 + 3, 120, c * 3, 120);
	RGBcolor cl;
	cl.r = dd.p_greenredLUT[(int)(c / 2.55f)][0];
	cl.g = dd.p_greenredLUT[(int)(c / 2.55f)][1];
	cl.b = dd.p_greenredLUT[(int)(c / 2.55f)][2];
	dd.drawrectangle_f(r, cl);

	rectangle r2(c * 3, 120, c * 3 + 3, 120,
				c * 3 + 3, 140, c * 3, 140);
	RGBcolor cl2;
	cl2.r = dd.p_blackwhiteLUT[100 - (int)(c / 2.55f)][0];
	cl2.g = dd.p_blackwhiteLUT[100 - (int)(c / 2.55f)][1];
	cl2.b = dd.p_blackwhiteLUT[100 - (int)(c / 2.55f)][2];
	dd.drawrectangle_f(r2, cl2);
}*/

//stop walking
//if (is.key(DIK_S))		P[P1].dev_i = 1;
//else					P[P1].dev_i = 0;

//dd.typebmf(100, 100, 0, "%i", (int)P[P1].stance_arms);

//bind
//dd.typebmf(100, 100, 0, "%i %i", (int)option.data.CBT[cPAUSE], (int)option.data.CBT[cP1PUNCH]);
//dd.typebmf(100, 116, 0, "%s %s", is.p_lutDIK_DESC[(int)option.data.CBT[cPAUSE]], is.p_lutDIK_DESC[(int)option.data.CBT[cP1PUNCH]]);

//angle
//dd.typebmf(100, 132, 0, "a180 a360: %i %i     %i %i", is.mm_angle_180[P1], is.mm_angle[P1], is.mm_angle_180[P2], is.mm_angle[P2]);
//dd.typebmf(100, 148, 0, "p180 p360: %i %i     %i %i", is.mm_angle_180_pre[P1], is.mm_angle_pre[P1], is.mm_angle_180_pre[P2], is.mm_angle_pre[P2]);

/*/controller data
dd.typebmf(100, 100, 0, "%i %i %i %i %i %i %i %i %i %i",
		   (int)is.dicon[0].rgbButtons[0],
		   (int)is.dicon[0].rgbButtons[1],
		   (int)is.dicon[0].rgbButtons[2],
		   (int)is.dicon[0].rgbButtons[3],
		   (int)is.dicon[0].rgbButtons[4],
		   (int)is.dicon[0].rgbButtons[5],
		   (int)is.dicon[0].rgbButtons[6],
		   (int)is.dicon[0].rgbButtons[7],
		   (int)is.dicon[0].rgbButtons[8],
		   (int)is.dicon[0].rgbButtons[9]);
dd.typebmf(100, 116, 0, "%i %i",
		   is.dicon[0].lX,
		   is.dicon[0].lY);

/*
//cs
dd.typebmf(100, 164, 0, "%i %i %i %i %i %i %i %i",
		   (int)is.COM(cP1PUNCH),
		   (int)is.COM(cP1KICK),
		   (int)is.COM(cP1DEFEND),
		   (int)is.COM(cP1LEFT),
		   (int)is.COM(cP1RIGHT),
		   (int)is.COM(cP1SPECIAL),
		   (int)is.COM(cP1STANCEUP),
		   (int)is.COM(cP1STANCEDOWN));*/

/*int angle_bone[2] = {0};
angle_bone[0]	= blul;
angle_bone[1]	= blll;
int angle_attack = (int)(P[P1].sk.b[angle_bone[0]].angle - P[P1].sk.b[angle_bone[1]].angle);
if (angle_attack < 0)
	angle_attack += 360;
//shortest direction
if (angle_attack > 180)
	angle_attack = 360 - angle_attack;
dd.typebmf(100, 100, 0, "angle: %i", angle_attack);*/

//last animation
//dd.typebmf(100, 100, 0, "lastanmn %i %i", P[P1].last_anmn[0], P[P1].last_anmn[1]);
//tmove
//dd.typebmf(100, 116, 0, "t_move bwd fwd %.1f %.1f", is.t_move[P1][0], is.t_move[P1][1]);

//speedfactor
//if (P[P1].p_aslot[aslot_cycle] != NULL)
//	dd.typebmf(100, 100, 0, "speedfactor: %.3f", P[P1].p_aslot[aslot_cycle]->speedfactor[P1]);

//dd.typebmf(100, 100, 0, "fwd_ad: %.3f", P[P1].walk_fwd_ad);
//dd.typebmf(100, 116, 0, "bwd_ad: %.3f", P[P1].walk_bwd_ad);

/*//dd.typebmf(100, 100, 0, "fwd_rush[P1] %.1f", P[P1].walk_fwd_rush);
dd.typebmf(100, 116, 0, "mcx/mcy[P1]  %d, %d", is.mcx[P1], is.mcy[P1]);
dd.typebmf(100, 132, 0, "mm_angle:    %d", is.mm_angle[P1]);
dd.typebmf(100, 148, 0, "angle180:    %d", is.mm_angle_180[P1]);
dd.typebmf(100, 164, 0, "mm_length_c: %.1f", is.mm_length_c[P1]);
dd.typebmf(100, 180, 0, "mm_length_m: %.1f", is.mm_length_m[P1]);

dd.typebmf(400, 100, 0, "fatigue %.1f", P[P1].fatigue);
dd.typebmf(400, 116, 0, "fatbuff %.1f", P[P1].fatigue_buff);
dd.typebmf(400, 132, 0, "fat_del %.1f", P[P1].fatigue_delay);
dd.typebmf(400, 148, 0, "walklck %i", P[P1].walk_lock);
//dd.typebmf(400, 164, 0, "def_butt %i", (int)is.def_button[P1]);

//fatigue_

/*dd.typefont(100, 100, "", P[P1].fatigue, 2, 0, 1.0f, -1);
dd.typefont(100, 116, "", P[P1].fatigue_buff, 2, 0, 1.0f, -1);
if (P[P1].p_aslot[aslot_action])
{
	dd.typefont(100, 200, "", P[P1].p_aslot[aslot_action]->gl_attack[P1], 0, 0, 1.0f, -1);
	dd.typefont(100, 216, "", P[P1].p_aslot[aslot_action]->gl_fat[P1], 0, 0, 1.0f, -1);
}
dd.typefont(100, 232, "", P[P1].skill_freg_ad, 2, 0, 1.0f, -1);
if (P[P1].p_aslot[aslot_cycle])
{
	dd.typefont(100, 300, "", P[P1].p_aslot[aslot_cycle]->gl_fat[P1], 0, 0, 1.0f, -1);
}

//mouse buffer
dd.typefont(200, 100, "", is.mcx[P1], 0, 0, 1.0f, -1);
dd.typefont(200, 116, "", is.mcy[P1], 0, 0, 1.0f, -1);

static point cur(399, 299);
static LONGLONG t_curstart = 0;
static line cl[500];
static int cli = 0;
static int cflag = 1;
//if (is.dimouse[1].rgbButtons[1] & 0x80)
//if (is.dimouse[1].rgbButtons[0] == 0)
if (t_curstart + time.freq * 1.0f < time.current ||
//	is.dimouse[1].rgbButtons[0] == 0)
	is.dikey[DIK_SPACE] == 0)
{
	cur.x = 399;
	cur.y = 299;
	for (register int i = 0; i < 500; ++i)
	{
		cl[i].p[0].x = -1;
		cl[i].p[0].y = -1;
		cl[i].p[1].x = -1;
		cl[i].p[1].y = -1;
	}
	cli = 0;
	t_curstart = 0;
//	cflag = 0;
}

//if (is.dimouse[1].rgbButtons[0] & 0x80 && cflag == 1)
if (is.dikey[DIK_SPACE] & 0x80 && cflag == 1)
{
	if (t_curstart == 0)
		t_curstart = time.current;
	cl[cli].p[0].x = cur.x;
	cl[cli].p[0].y = cur.y;
	cl[cli].p[1].x = cur.x + is.dimouse[1].lX;
	cl[cli].p[1].y = cur.y + is.dimouse[1].lY;
//	line l(cur.x, cur.y, cur.x + is.dimouse[1].lX, cur.y + is.dimouse[1].lY);

	cur.x += is.dimouse[1].lX;
	cur.y += is.dimouse[1].lY;

	if (cli < 500)
		++cli;
}
for (register int i = 0; i < cli; ++i)
{
	if (cl[i].p[0].x != -1)
	{
		dd.drawline(cl[i], red);
	}
}*/

/*/dd.typebmf(200, 418, 0, "%i %i %i", is.PA[P1][AC_JAB], is.PA[P1][AC_TAP_JAB], (int)is.mm_button[P1]);
//dd.typebmf(200, 434, 0, "power_attack: %i %i", P[P1].power_attack[0], P[P1].power_attack[1]);
//lock states
dd.typebmf(200, 450, 0, "lock_def %i%i%i%i", P[P1].gl_lock.lock_def[0], P[P1].gl_lock.lock_def[1], P[P1].gl_lock.lock_def[2], P[P1].gl_lock.lock_def[3]);
dd.typebmf(200, 466, 0, "lock_off %i%i%i%i", P[P1].gl_lock.lock_off[0], P[P1].gl_lock.lock_off[1], P[P1].gl_lock.lock_off[2], P[P1].gl_lock.lock_off[3]);
dd.typebmf(200, 482, 0, "angle %i %i %i %i", P[P1].gl_lock.angle_off[0], P[P1].gl_lock.angle_off[1], P[P1].gl_lock.angle_off[2], P[P1].gl_lock.angle_off[3]);
//dd.typebmf(200, 498, 0, "lock_con %i%i%i%i", P[P1].gl_lock.lock_offc[0], P[P1].gl_lock.lock_offc[1], P[P1].gl_lock.lock_offc[2], P[P1].gl_lock.lock_offc[3]);
//dd.typebmf(200, 498, 0, "gl_def %i %i", (int)P[P1].gl_def_success, (int)P[P2].gl_def_success);

dd.typebmf(500, 450, 0, "%i%i%i%i", P[P2].gl_lock.lock_def[0], P[P2].gl_lock.lock_def[1], P[P2].gl_lock.lock_def[2], P[P2].gl_lock.lock_def[3]);
dd.typebmf(500, 466, 0, "%i%i%i%i", P[P2].gl_lock.lock_off[0], P[P2].gl_lock.lock_off[1], P[P2].gl_lock.lock_off[2], P[P2].gl_lock.lock_off[3]);
dd.typebmf(500, 482, 0, "%i %i %i %i", P[P2].gl_lock.angle_off[0], P[P2].gl_lock.angle_off[1], P[P2].gl_lock.angle_off[2], P[P2].gl_lock.angle_off[3]);
//dd.typebmf(500, 498, 0, "%i%i%i%i", P[P2].gl_lock.lock_offc[0], P[P2].gl_lock.lock_offc[1], P[P2].gl_lock.lock_offc[2], P[P2].gl_lock.lock_offc[3]);

dd.typebmf(200, 400, 0, "length_m: %i", (int)is.mm_length_m[P1]);

//fatigue
/*dd.typefont(200, 8, "", P[P1].fatigue, 2, 0);
dd.typefont(500, 8, "", P[P2].fatigue, 2, 0);*/

//if (P[P1].gl_ko)
//{
//	P[P1].pmessage.set_message("I am K.O.", 0, 0, 0, 0, 255, 0, 0.35f, -1, time.current);
//	P[P1].pmessage.update(time.current, time.freq, P[P1].sk.chead);

//	if (option.data.speed -= 0.5f * time.sca >= 0.0f)
//		option.data.speed -= 0.5f * time.sca;
//	else
//		option.data.speed = 0;
//}
//if (P[P2].gl_ko)
//{
//	P[P2].pmessage.set_message("I am K.O.", 0, 0, 0, 0, 255, 0, 0.35f, -1, time.current);
//	P[P2].pmessage.update(time.current, time.freq, P[P2].sk.chead);

//	if (option.data.speed -= 0.5f * time.sca >= 0.0f)
//		option.data.speed -= 0.5f * time.sca;
//	else
//		option.data.speed = 0;
//}

//if (is.dikey1D[DIK_G] & 0x80)
//	ppause.set_pause(1.0f);

//dd.typefont(550, 100, "", rcd.defend[P1], 0, 0, 1.0f, -1);
//dd.typefont(650, 100, "", rcd.defend[P2], 0, 0, 1.0f, -1);
//if (P[P1].p_aslot[aslot_cycle] == P[P1].p_anmn[P[P1].asi][AN_WALK_FWD])
//	dd.typefont(600, 132, "", P[P1].p_aslot[aslot_cycle]->pkf[0].t_frame_ad[

/*dd.typefont(400, 400, "", is.dikey[DIK_SPACE], 0, 0, 1.0f, -1);
dd.typefont(400, 416, "", is.dikey1D[DIK_SPACE], 0, 0, 1.0f, -1);
dd.typefont(400, 432, "", is.dikeyUP[DIK_SPACE], 0, 0, 1.0f, -1);
dd.typefont(400, 448, "", is.dikeyLD[DIK_SPACE], 0, 0, 1.0f, -1);
dd.typefont(400, 464, "", is.dikey1DU[DIK_SPACE], 0, 0, 1.0f, -1);*/

//dd.typefont(200, 100, "", is.ycontext_up[P1], 0, 0, 1.0f, -1);
//dd.typefont(300, 100, "", is.mchx[P1][(int)(is.mcc[P1] / 2.0f)], 0, 0, 1.0f, -1);
//dd.typefont(300, 116, "", is.mchy[P1][(int)(is.mcc[P1] / 2.0f)], 0, 0, 1.0f, -1);
/*if (is.ycontext_up[P1])
	playsound(S_MENTER);
if (is.ycontext_do[P1])
	playsound(S_MSELECT);
dd.typefont(100, 100, "", is.mcx[P1], 0, 0, 1.0f, -1);
dd.typefont(100, 116, "", is.mcy[P1], 0, 0, 1.0f, -1);
dd.typefont(150, 100, "", is.mmx[P1], 0, 0, 1.0f, -1);
dd.typefont(150, 116, "", is.mmy[P1], 0, 0, 1.0f, -1);
dd.typefont(100, 132, "", is.mm_length_c[P1], 1, 0, 1.0f, -1);
dd.typefont(100, 132, "", is.mm_length_c[P1], 1, 0, 1.0f, -1);
dd.typefont(100, 148, "", is.mm_angle[P1], 1, 0, 1.0f, -1);
dd.typefont(150, 148, "", is.mm_angle_180[P1], 0, 0, 1.0f, -1);
dd.typefont(400, 148, "", is.mm_angle[P2], 1, 0, 1.0f, -1);
dd.typefont(450, 148, "", is.mm_angle_180[P2], 0, 0, 1.0f, -1);*/
//dd.typefont(100, 164, "", is.mm_state[P1], 0, 0, 1.0f, -1);
//dd.typefont(100, 180, "", is.mm_t_start[P1], 0, 0, 1.0f, -1);

//dd.typefont(100, 180, "", is.PA[P1][AN_DEFEND], 0, 0, 1.0f, -1);

//dd.typefont(100, 500, "", option.data.defense_mode[P1], 0, 0, 1.0f, -1);

/*dd.typefont(100, 400, "", P[P1].blood_size[0], 0, 0, 1.0f, -1);
dd.typefont(100, 416, "", P[P1].blood_size[1], 0, 0, 1.0f, -1);
dd.typefont(100, 432, "", P[P2].blood_size[0], 0, 0, 1.0f, -1);
dd.typefont(100, 448, "", P[P2].blood_size[1], 0, 0, 1.0f, -1);*/
//dd.typefont(200, 400, "", ds.getcurrentposition(-1), 0, 0, 1.0f, -1);
//dd.typefont(200, 416, "", (double)time.current, 0, 0, 1.0f, -1);

//angle
//dd.typefont(100, 100, "", is.mm_angle[P1], 1, 0, 1.0f, -1);
//dd.typefont(100, 116, "", is.mm_angle_180[P1], 1, 0, 1.0f, -1);
//dd.typefont(500, 100, "", is.mm_angle[P2], 1, 0, 1.0f, -1);
//dd.typefont(500, 116, "", is.mm_angle_180[P2], 1, 0, 1.0f, -1);

//dd.typefont(100, 566, "", rcd.defend[P1], 1);
//dd.typefont(500, 566, "", rcd.defend[P2], 1);
//dd.typefont(100, 566, "", P[P1].walk_fwd_ad, 1);
//dd.typefont(500, 566, "", P[P1].walk_bwd_ad, 1);
//dd.typefont(100, 534, "", option.data.sensitivity[P1], 1);
//if (P[P1].p_aslot[aslot_cycle] != NULL)
//	dd.typefont(500, 534, "", (double)is.mm_t_start[P1], 1);
//if (is.dikey1D[DIK_BACKSPACE] & 0x80)
//	P[P1].fatigue_buff -= 20;

//if (is.dikey1D[DIK_F9] & 0x80 && is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_LCONTROL] & 0x80)
//	option.data.sensitivity[P1] -= 0.1f;
//if (is.dikey1D[DIK_F10] & 0x80 && is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_LCONTROL] & 0x80)
//	option.data.sensitivity[P1] += 0.1f;

/*for (register int s = 0; s < 19; ++s)
{
	dd.typefont(100 + s * 8, 550, "", P[P1].sk.b[s].cd_state, 0);
	if (P[P1].p_aslot[aslot_action] != NULL)
		dd.typefont(100 + s * 8, 566, "", P[P1].p_aslot[aslot_action]->gl_bcds_off[P[P2].asi][s], 0);
	dd.typefont(500 + s * 8, 550, "", P[P2].sk.b[s].cd_state, 0);
	if (P[P2].p_aslot[aslot_action] != NULL)
		dd.typefont(500 + s * 8, 566, "", P[P2].p_aslot[aslot_action]->gl_bcds_off[P[P1].asi][s], 0);
}
for (register int a = 0; a < 6; ++a)
{
	dd.typefont(100 + a * 8, 534, "", P[P1].active[a], 0);
	dd.typefont(500 + a * 8, 534, "", P[P2].active[a], 0);
}

dd.typefont(100, 582, "", rcd.damage[P1], 0);
dd.typefont(500, 582, "", rcd.damage[P2], 0);

for (a = 0; a < 22; ++a)
{
	dd.typefont(10 + a * 16, 100, "", rcd.bone[P1][a], 0, 0, 1.0f, -1);
	dd.typefont(10 + a * 16, 132, "", rcd.bone[P2][a], 0, 0, 1.0f, -1);
	dd.typefont(10 + a * 16, 116, "", (bool)rcd.time[P1][a], 0, 0, 1.0f, -1);
	dd.typefont(10 + a * 16, 148, "", (bool)rcd.time[P2][a], 0, 0, 1.0f, -1);
}*/




//-------------------------------------------------------------------------------------------------

	//set position depending on number of entry and empty lines before it
	void set_position(int e = -1, int bottom = 1)		//-1 == all, else specified entry
														//reset to bottom or top
	{
set_temp_pos();
return;
		int offset;
		if (bottom)		offset = 600;
		else			offset = 0;

		//all entries
		if (e == -1)
		{
			//set credit entries position
			for (int i = 0, l = 0; i < NOC; ++i)
			{
				//increase empty lines
				l				+= pcq[i].el;

				//calculate position
				pcq[i].pos.y	= (float)(offset + 16 * (i + l));
			}
		}
		else
		//specified entry
		{
			if (e >= 0 && e < NOC)
			{
				//set credit entry position
				for (int i = 0, l = 0; i < NOC; ++i)
				{
					//increase empty lines
					l				+= pcq[i].el;
					//calculate position for specified entry and break
					if (i == e)
					{
						pcq[i].pos.y	= (float)(offset + 16 * (i + l));
					}
				}
			}
		}
	};

//-------------------------------------------------------------------------------------------------

	//fade in from white
	//dd.gamma_fade(1, 1, 0.5f);
	dd.gamma_set();

	if (is.dikey1D[SYS_ESC] & 0x80)
	{
		//play sound
		playsound_s(S_MCANCEL);

		//if not within subselection reset selections and exit to main menu
		if (data_op.sub_selection == 0)
		{
			//reset selection
			data_op.reset_SELOPT();
			//reset state
			data_op.state = 0;

			//fade to white
			dd.gamma_fade(0, 1, 0.5f);
			program_state = TITLE;
			return;
		}
	}

	//---- idling --------------------------------------------------------------------------------

	if (true)
	{
		//draw background
		dd.drawbackground(option.data.cbackground.r,
						  option.data.cbackground.g,
						  option.data.cbackground.b);

		static bool set = false;
		if (!set)
		{
			set = true;

			//set data
			data_op.initialize(is.p_lutDIK_DESC, di.RI.RIMn);

			//set option data
/*data_op.set_option(0, 4, "TEST ConCol", 0,
				   &option.data.con_color,
				   &option.dataDEF.con_color,
				   &option.dataMIN.con_color,
				   &option.dataMAX.con_color,
				   OT_RGB, ODT_RGB, OIT_FIVE, OCS_BGN,
//				   OT_ONOFF, ODT_BOOL, OIT_DEF, OCS_DEF,
//				   OT_INT, ODT_INT, OIT_SINGLE, OCS_DEF,
//				   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
				   25, 0, 100, 0);*/
			data_op.set_option(0, 0, "Sound", !option.dataDEF.sound,
							   &option.data.sound, &option.dataDEF.sound, &option.dataMIN.sound, &option.dataMAX.sound,
							   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 1, "VSync", 0,
							   &option.data.vsync, &option.dataDEF.vsync, &option.dataMIN.vsync, &option.dataMAX.vsync,
							   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 2, "Maximum FPS", 1,
							   &option.data.fps_max, &option.dataDEF.fps_max, &option.dataMIN.fps_max, &option.dataMAX.fps_max,
							   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 3, "Show FPS", 0,
							   &option.data.show_fps, &option.dataDEF.show_fps, &option.dataMIN.show_fps, &option.dataMAX.show_fps,
							   OT_ONOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 5, "Shadows", 0,
							   &option.data.shadows, &option.dataDEF.shadows, &option.dataMIN.shadows, &option.dataMAX.shadows,
							   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 6, "MotionBlur", 0,
							   &option.data.mblur, &option.dataDEF.mblur, &option.dataMIN.mblur, &option.dataMAX.mblur,
							   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 7, "Black&White Mode", 0,
							   &option.data.bw_mode, &option.dataDEF.bw_mode, &option.dataMIN.bw_mode, &option.dataMAX.bw_mode,
							   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 8, "Background RGB", 0,
							   &option.data.cbackground, &option.dataDEF.cbackground, &option.dataMIN.cbackground, &option.dataMAX.cbackground,
							   OT_RGB, ODT_RGB, OIT_FIVE, OCS_BGN,
							   0, 0, 100, 0);
			data_op.set_option(0, 10, "Rounds", 0,
							   &option.data.rounds, &option.dataDEF.rounds, &option.dataMIN.rounds, &option.dataMAX.rounds,
							   OT_INT, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 11, "Round Time", 0,
							   &option.data.roundtime, &option.dataDEF.roundtime, &option.dataMIN.roundtime, &option.dataMAX.roundtime,
							   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 100, 0);
			data_op.set_option(0, 12, "Speed", 0,
							   &option.data.speed, &option.dataDEF.speed, &option.dataMIN.speed, &option.dataMAX.speed,
							   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
							   0, 0, 100, 0);
			//----
			data_op.set_option(2, 0, "Left P1", 0,
							   &option.data.CBT[cP1LEFT], &option.dataDEF.CBT[cP1LEFT], &option.dataMIN.CBT[cP1LEFT], &option.dataMAX.CBT[cP1LEFT],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 1, "Right P1", 1,
							   &option.data.CBT[cP1RIGHT], &option.dataDEF.CBT[cP1RIGHT], &option.dataMIN.CBT[cP1RIGHT], &option.dataMAX.CBT[cP1RIGHT],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 2, "Punch P1", 0,
							   &option.data.CBT[cP1PUNCH], &option.dataDEF.CBT[cP1PUNCH], &option.dataMIN.CBT[cP1PUNCH], &option.dataMAX.CBT[cP1PUNCH],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 3, "Kick P1", 0,
							   &option.data.CBT[cP1KICK], &option.dataDEF.CBT[cP1KICK], &option.dataMIN.CBT[cP1KICK], &option.dataMAX.CBT[cP1KICK],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 4, "Defend P1", 0,
							   &option.data.CBT[cP1DEFEND], &option.dataDEF.CBT[cP1DEFEND], &option.dataMIN.CBT[cP1DEFEND], &option.dataMAX.CBT[cP1DEFEND],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 5, "Spec P1", 0,
							   &option.data.CBT[cP1SPECIAL], &option.dataDEF.CBT[cP1SPECIAL], &option.dataMIN.CBT[cP1SPECIAL], &option.dataMAX.CBT[cP1SPECIAL],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			//data_op.set_option(2, 6, "StanceUp P1", 0,
			data_op.set_option(2, 6, "Guard+ P1", 0,
							   &option.data.CBT[cP1STANCEUP], &option.dataDEF.CBT[cP1STANCEUP], &option.dataMIN.CBT[cP1STANCEUP], &option.dataMAX.CBT[cP1STANCEUP],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			//data_op.set_option(2, 7, "StanceDown P1", 0,
			data_op.set_option(2, 7, "Guard- P1", 0,
							   &option.data.CBT[cP1STANCEDOWN], &option.dataDEF.CBT[cP1STANCEDOWN], &option.dataMIN.CBT[cP1STANCEDOWN], &option.dataMAX.CBT[cP1STANCEDOWN],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(2, 8, "Mouse P1", 0,
							   &option.data.player_mouse[P1], &option.dataDEF.player_mouse[P1], &option.dataMIN.player_mouse[P1], &option.dataMAX.player_mouse[P1],
							   OT_MOUSE, ODT_INT, OIT_SINGLE, OCS_DEF);
			data_op.set_option(3, 0, "Left P2", 0,
							   &option.data.CBT[cP2LEFT], &option.dataDEF.CBT[cP2LEFT], &option.dataMIN.CBT[cP2LEFT], &option.dataMAX.CBT[cP2LEFT],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 1, "Right P2", 0,
							   &option.data.CBT[cP2RIGHT], &option.dataDEF.CBT[cP2RIGHT], &option.dataMIN.CBT[cP2RIGHT], &option.dataMAX.CBT[cP2RIGHT],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 2, "Punch P2", 0,
							   &option.data.CBT[cP2PUNCH], &option.dataDEF.CBT[cP2PUNCH], &option.dataMIN.CBT[cP2PUNCH], &option.dataMAX.CBT[cP2PUNCH],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 3, "Kick P2", 0,
							   &option.data.CBT[cP2KICK], &option.dataDEF.CBT[cP2KICK], &option.dataMIN.CBT[cP2KICK], &option.dataMAX.CBT[cP2KICK],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 4, "Defend P2", 0,
							   &option.data.CBT[cP2DEFEND], &option.dataDEF.CBT[cP2DEFEND], &option.dataMIN.CBT[cP2DEFEND], &option.dataMAX.CBT[cP2DEFEND],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 5, "Spec P2", 0,
							   &option.data.CBT[cP2SPECIAL], &option.dataDEF.CBT[cP2SPECIAL], &option.dataMIN.CBT[cP2SPECIAL], &option.dataMAX.CBT[cP2SPECIAL],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			//data_op.set_option(3, 6, "StanceUp P2", 0,
			data_op.set_option(3, 6, "Guard+ P2", 0,
							   &option.data.CBT[cP2STANCEUP], &option.dataDEF.CBT[cP2STANCEUP], &option.dataMIN.CBT[cP2STANCEUP], &option.dataMAX.CBT[cP2STANCEUP],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			//data_op.set_option(3, 7, "StanceDown P2", 0,
			data_op.set_option(3, 7, "Guard- P2", 0,
							   &option.data.CBT[cP2STANCEDOWN], &option.dataDEF.CBT[cP2STANCEDOWN], &option.dataMIN.CBT[cP2STANCEDOWN], &option.dataMAX.CBT[cP2STANCEDOWN],
							   OT_INPUT, ODT_DEF, OIT_DEF, OCS_DEF);
			data_op.set_option(3, 8, "Mouse P2", 0,
							   &option.data.player_mouse[P2], &option.dataDEF.player_mouse[P2], &option.dataMIN.player_mouse[P2], &option.dataMAX.player_mouse[P2],
							   OT_MOUSE, ODT_INT, OIT_SINGLE, OCS_DEF);

			data_op.set_option(2, 10, "Name P1", 0,
							   &option.data.name[P1], &option.dataDEF.name[P1], &option.dataMIN.name[P1], &option.dataMAX.name[P1],
							   OT_STRING, ODT_CHAR, OIT_DEF, OCS_DEF,
							   0, 0, 25, 0);
			data_op.set_option(2, 11, "Name P2", 0,
							   &option.data.name[P2], &option.dataDEF.name[P2], &option.dataMIN.name[P2], &option.dataMAX.name[P2],
							   OT_STRING, ODT_CHAR, OIT_DEF, OCS_DEF,
							   0, 0, 25, 0);
			data_op.set_option(2, 12, "Fistcolor P1 RGB", 1,
							   &option.data.fistcolor[P1], &option.dataDEF.fistcolor[P1], &option.dataMIN.fistcolor[P1], &option.dataMAX.fistcolor[P1],
							   OT_RGB, ODT_RGB, OIT_FIVE, OCS_FIST,
							   0, 0, 100, 0);
			data_op.set_option(2, 13, "Fistcolor P2 RGB", 0,
							   &option.data.fistcolor[P2], &option.dataDEF.fistcolor[P2], &option.dataMIN.fistcolor[P2], &option.dataMAX.fistcolor[P2],
							   OT_RGB, ODT_RGB, OIT_FIVE, OCS_FIST,
							   0, 0, 100, 0);
			//---
			data_op.set_option(2, 15, "Subframes", 0,
							   &option.data.subframes, &option.dataDEF.subframes, &option.dataMIN.subframes, &option.dataMAX.subframes,
							   OT_INT, ODT_INT, OIT_SINGLE, OCS_DEF,
							   0, 0, 120, 0);
			data_op.set_option(2, 16, "Damage Multiplier", 0,
							   &option.data.damage_multiplier, &option.dataDEF.damage_multiplier, &option.dataMIN.damage_multiplier, &option.dataMAX.damage_multiplier,
							   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
							   0, 0, 120, 0);
			data_op.set_option(2, 17, "Fatigue Multiplier", 0,
							   &option.data.fom_multiplier, &option.dataDEF.fom_multiplier, &option.dataMIN.fom_multiplier, &option.dataMAX.fom_multiplier,
							   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
							   0, 0, 120, 0);
			//---
			data_op.set_option(1, 19, "CREDITS", 0,
							   NULL, NULL, NULL, NULL,
							   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
							   200, 0);
			data_op.set_option(2, 19, "DEFAULT", 1,
							   NULL, NULL, NULL, NULL,
							   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
							   150, 0);
			data_op.set_option(3, 19, "DONE", 0,
							   NULL, NULL, NULL, NULL,
							   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
							   100, 0);

			//set initial bounding boxes
			data_op.set_bounding_box(option.data.shadows);
		}

		//set current bounding boxes (updated to current data)
		data_op.set_bounding_box(option.data.shadows);

//dd.typebmf(50, 400, bmfblack, "%i", is.ascii);

if (false)
{
RGBcolor bg = green;
dd.typebmf((int)mcursor[0].pos.x, (int)mcursor[0].pos.y - 32, bmfblack, "Zoom!");
dd.typebmf((int)mcursor[0].pos.x, (int)mcursor[0].pos.y - 16, bmfblack, bg, "Zoom!");
dd.typebmf((int)mcursor[0].pos.x, (int)mcursor[0].pos.y - 0, bmfblack, .5f, "Zoom!");
dd.typebmf((int)mcursor[0].pos.x, (int)mcursor[0].pos.y + 16, bmfblack, blue, 2.5f, "Zoom!");
	dd.typebmf((int)mcursor[0].pos.x + 50, (int)mcursor[0].pos.y + 50, bmfblack, white, "ZOOM!");
	dd.typefont((int)mcursor[0].pos.x - 32, (int)mcursor[0].pos.y, "JESUS!", 0, 5, 0, 2.0f, 1);
	dd.typefont((int)mcursor[0].pos.x - 32, (int)mcursor[0].pos.y + 50, "JESUS 1.0", 0, 5, 0, 1.0f, 4);
	dd.typefont((int)mcursor[0].pos.x - 32, (int)mcursor[0].pos.y - 50, "JESUS 0.9", 0, 5, 0, 0.9f, 3);
	dd.typebmf(100, 216, bmfblack, "STRONGER THAN");
}
if (false)
{
	static float zoom = 1.0f;
	if (is.dimouse[0].lZ > 0)		zoom += .1f;
	if (is.dimouse[0].lZ < 0)		zoom -= .1f;
	if (is.dimouse1D[0].rgbButtons[2] & 0x80)		zoom = 1.0f;
	if (zoom < 0) zoom = 0;
	dd.typebmf(50, 100, bmfblack, "zoom: %.1f", zoom);
	RECT rs = dd.rSCREEN;rs.left = 100;rs.right = 500;rs.top = 100;rs.bottom = 400;
	RECT co = mcursor[0].r_off;
	fillRECT(co, 780, 0, 791, 19);
	RECT cs = mcursor[0].r_scr;
	fillRECT(cs, (int)mcursor[0].pos.x, (int)mcursor[0].pos.y + 50,
						 (int)(mcursor[0].pos.x + 11.0f * zoom), (int)((mcursor[0].pos.y + 50) + 19.0f * zoom));
	dd.blitrect(rs, co, cs);
	dd.drawrectangle_uf(rs, blue);
	dd.drawrectangle_uf(co, yellow);
	dd.drawrectangle_uf(cs, red);
}

if (false)
{
int op = 8;
if (!option.data.shadows)
{
if (is.dimouse[0].lZ > 0)						data_op.slot[0][op].bmf_size += .1f;
if (is.dimouse[0].lZ < 0)						data_op.slot[0][op].bmf_size -= .1f;
if (is.dimouse1D[0].rgbButtons[3] & 0x80)		data_op.slot[0][op].bmf_size = 1.0f;

	RECT tempdest, csource, cdest;
	tempdest.left = data_op.slot[0][0].pos_qual.x;	tempdest.top = data_op.slot[0][0].pos_qual.y;
	float sizefactor = data_op.slot[0][0].bmf_size;
	//set right and bottom members of tempdest
	tempdest.right = tempdest.left + (long)(8 * sizefactor);
	tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

	//assign RECTS to temp RECTS so the originals don't get clipped
	//(especially the LUT)
	cdest	= tempdest;

	int color = bmfblack;
	//offscreen surface offset depending on color
	csource.left	= dd.p_cfontbm_LUT[0].left + (long)dd.bmfs_offset[color].x;
	csource.top		= dd.p_cfontbm_LUT[0].top + (long)dd.bmfs_offset[color].y;
	csource.right	= dd.p_cfontbm_LUT[0].right + (long)dd.bmfs_offset[color].x;
	csource.bottom	= dd.p_cfontbm_LUT[0].bottom + (long)dd.bmfs_offset[color].y;

	dd.blitrect(dd.rSCREEN, csource, cdest);
}
else
{
if (is.dimouse[0].lZ > 0)						data_op.slot[0][op].slf_size += .1f;
if (is.dimouse[0].lZ < 0)						data_op.slot[0][op].slf_size -= .1f;
if (is.dimouse1D[0].rgbButtons[3] & 0x80)		data_op.slot[0][op].slf_size = .35f;

	RECT tempdest;
	tempdest.left = data_op.slot[0][0].pos_qual.x;	tempdest.top = data_op.slot[0][0].pos_qual.y;
	float sizefactor = data_op.slot[0][0].slf_size;
	//set right and bottom members of tempdest
	tempdest.right = tempdest.left + (long)(32 * sizefactor);
	tempdest.bottom = tempdest.top + (long)(58 * sizefactor);

	dd.drawrectangle_f(tempdest, green);
}
}

//---- selection start

static ipoint selection;
if (data_op.last_input == 0 && (selection.x == -1 || selection.y == -1))
	selection.setpoint(0, 0);
//if (is.key1D(DIK_LEFT))
if (is.mouse(0, true, true, false))
{
	bool mc_so = false;
	for (int x = 0; x < OS_X; ++x)
		for (int y = 0; y < OS_Y; ++y)
			if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_qual))
				mc_so = true;
	if (mc_so)
		data_op.last_input = 1;
	else
		if (data_op.last_input == 1)
			selection.setpoint(-1, -1);
}
if (time.fps < 100)
	dd.typebmf(10, 74, bmfblue, "FPS:  %i  [%i, %i] last_input: %i", time.fps, selection.x, selection.y, data_op.last_input);
else
	dd.typebmf(10, 74, bmfblue, "FPS: %i  [%i, %i] last_input: %i", time.fps, selection.x, selection.y, data_op.last_input);
dd.typebmf(400, 74, bmfblue, "mouse: (%i, %i)", (int)mcursor[0].pos.x, (int)mcursor[0].pos.y);
for (int x = 0; x < OS_X; ++x)
	for (int y = 0; y < OS_Y; ++y)
		//slot valid and not locked
		if (data_op.slot[x][y].set && !data_op.slot[x][y].locked)
		{
			data_op.slot[x][y].set_selection(0);

			//qualifier
			if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_qual) && data_op.last_input == 1)
			{
				data_op.slot[x][y].set_selection(1);
				selection.setpoint(x, y);
				//dd.drawrectangle_uf(data_op.slot[selection.x][selection.y].r_pos_qual, red);
				//qualifier
/*				if (!option.data.shadows)
					dd.typebmf(data_op.slot[x][y].pos_qual.x - 1, data_op.slot[x][y].pos_qual.y, bmfblack, "%s", data_op.slot[x][y].qualifier);
				else
					dd.typeSLF(data_op.slot[x][y].pos_qual.x - 2, data_op.slot[x][y].pos_qual.y, 0, 0, 0, 0, 255, 0, 0.35f, "%s", data_op.slot[x][y].qualifier);
					*/
			}
			//data
			for (int s = 0; s < 3; ++s)
				if (data_op.slot[x][y].r_pos_data[s].left != -1)
					//!! && lastinput 1
					if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_data[s]))
					{
						data_op.slot[x][y].set_selection(s + 2);
						selection.setpoint(x, y);
						//dd.drawrectangle_uf(data_op.slot[selection.x][selection.y].r_pos_data[s], red);
						break;
					}
		}

static int senter = 0;
static ipoint lastpoint;
//if (selection.x == -1 || selection.y == -1)
if (lastpoint.x != selection.x || lastpoint.y != selection.y)
{
	if (senter)
	{
		senter = 0;
		if (option.data.name[P1][data_op.s_index] == 95)
			option.data.name[P1][data_op.s_index] = 0;
		if (option.data.name[P2][data_op.s_index] == 95)
			option.data.name[P2][data_op.s_index] = 0;

		option.verify_player_names();
		playsound_s(S_MCANCEL);
	}
}
lastpoint = selection;

if (selection.x != -1 && selection.y != -1)
{
if (is.mouse1DU(0, 0) && !strcmp(data_op.slot[selection.x][selection.y].qualifier, "DONE"))
{
	//exit
	//play sound
	playsound_s(S_MCANCEL);

	//if not within subselection reset selections and exit to main menu
	if (data_op.sub_selection == 0)
	{
		//reset selection
		data_op.reset_SELOPT();
		//reset state
		data_op.state = 0;

		//fade to white
		dd.gamma_fade(0, 1, 0.5f);
		program_state = TITLE;
		return;
	}
}
	//controls test

	//!! unterscheidung input und mouse
	//!! verify_key im prinzip fuer alle...
	if (data_op.slot[selection.x][selection.y].o_type == OT_INPUT)
	{
		//for every key
		for (int i = 0; i < 256; ++i)
			if (is.dikey1D[i] & 0x80)
			{
				if (!option.verify_key(i))
				{
					playsound_s(S_MCANCEL);
				}
				else
				{
					playsound_s(S_MENTER);
					data_op.slot[selection.x][selection.y].set_input(i);
					//!! danach den string neu setzen sofort?
					//mouse?
				}
			}

		//both mice/controller
		for (int d = 0; d < 2; ++d)
		{
			//mouse wheel up/down
			if (is.dimouse[d + 1].lZ > 0)
			{
				playsound_s(S_MENTER);
				data_op.slot[selection.x][selection.y].set_input(5, d + 1);
				break;
			}
			if (is.dimouse[d + 1].lZ < 0)
			{
				playsound_s(S_MENTER);
				data_op.slot[selection.x][selection.y].set_input(6, d + 1);
				break;
			}

			//all buttons
			for (int b = 0; b < 21; ++b)
			{
				//mice
				if (b < 4)
					if (is.dimouse1D[d + 1].rgbButtons[b] & 0x80)
					{
						playsound_s(S_MENTER);
						data_op.slot[selection.x][selection.y].set_input(b, d + 1);
						break;
					}

				//controller buttons
				if (is.dicon1D[d].rgbButtons[b] & 0x80)
				{
					playsound_s(S_MENTER);
					data_op.slot[selection.x][selection.y].set_input(b, d + 3);
					break;
				}
			}
		}
	}

	//name input
	if (data_op.slot[selection.x][selection.y].o_type == OT_STRING)
	{
		if (senter == 0)
		//if (lastpoint.x != selection.x || lastpoint.y != selection.y)
		{
			playsound_s(S_MENTER);
			data_op.s_index = strlen((char*)data_op.slot[selection.x][selection.y].p_data);
			//gf_logger(true, "strlen: %i", data_op.s_index);
			data_op.s_index > 19 ? data_op.s_index = 19 : data_op.s_index;
			for (register int i = data_op.s_index + 1; i < 21; ++i)
				((char*)data_op.slot[selection.x][selection.y].p_data)[i] = 0;
			senter		= 1;
		}
		int length	= 20;
		int ascii	= 0;

		if (data_op.s_index < length - 1)
		{
			((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = 95;
		}
		else
		{
			if (((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] == 0)
				((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = 95;
		}

		ascii = getinput_ascii();

		if (ascii != 0)
		{
			playsound_s(S_MSELECT);

			((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = ascii;
			if (data_op.s_index < length - 1)
				++data_op.s_index;
		}

		if (is.dikey1D[SYS_BACK] & 0x80 && data_op.s_index > 0)
		{
			playsound_s(S_MENTER);

			if (data_op.s_index != length - 1)
			{
				((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = 0;
				--data_op.s_index;
			}
			else
			{
				if (((char*)data_op.slot[selection.x][selection.y].p_data)[length - 1] != 0 &&
					((char*)data_op.slot[selection.x][selection.y].p_data)[length - 1] != 95)
				{
					((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = 0;
				}
				else
				{
					((char*)data_op.slot[selection.x][selection.y].p_data)[data_op.s_index] = 0;
					--data_op.s_index;
				}
			}
		}
	}
	else
	{
		senter = 0;
	}

float freq_inc = 1.2f;
float freq_dec = 0.8f;

	if ((is.mouse1D(0, 0) || is.mousehold(0, 0, 10, 0.75f) || is.dimouse[0].lZ > 0) &&
		!is.mouse(0, 1))
		if (data_op.slot[selection.x][selection.y].increase_data())
		{
			ds.setfrequency(BT_SYS, S_MSELECT, freq_inc);
			playsound_s(S_MSELECT);
//			ds.setfrequency(BT_SYS, S_MSELECT, option.data.speed);
		}
		else
			playsound_s(S_MCANCEL);
	if ((is.mouse1D(0, 1) || is.mousehold(0, 1, 10, 0.75) || is.dimouse[0].lZ < 0) &&
		!is.mouse(0, 0))
		if (data_op.slot[selection.x][selection.y].decrease_data())
		{
			ds.setfrequency(BT_SYS, S_MSELECT, freq_dec);
			playsound_s(S_MSELECT);
//			ds.setfrequency(BT_SYS, S_MSELECT, option.data.speed);
		}
		else
			playsound_s(S_MCANCEL);
	//reset
	if ((is.mouse1D(0, 0) && is.mouse(0, 1)) ||
		(is.mouse1D(0, 1) && is.mouse(0, 0)) ||
		is.mouse1D(0, 2))
		if (data_op.slot[selection.x][selection.y].reset_data())
			playsound_s(S_MENTER);
		else
			playsound_s(S_MCANCEL);
}

//---- selection end

/*
//wenn das sofort wieder reset wird, passiert das quasi waehrend des abspielens und
//ueberschreibt die erstgesetzte frequenz
float freq_inc = 1.2f;
float freq_dec = 0.8f;

if (is.mouse1D(0, 0))
{
	ds.setfrequency(BT_ALL, S_MSELECT, freq_inc);
	playsound_s(S_MSELECT);
//	ds.setfrequency(BT_ALL, S_MSELECT, option.data.speed);
}
if (is.mouse1D(0, 1))
{
	ds.setfrequency(BT_ALL, S_MSELECT, freq_dec);
	playsound_s(S_MSELECT);
//	ds.setfrequency(BT_ALL, S_MSELECT, option.data.speed);
}*/

//---- drawing

//!!
//calculate and draw yinyang if shadows on
if (option.data.shadows == 1)
{
	//draw yinyang from title (data_ti) but different position
	data_op.yy.set_position(400, 300);

	//decrease angle by 45 degrees/second times user speed
//	data_ti.yy_angle -= (float)(45 * time.sca * option.data.speed);
	data_ti.yy.angle -= (float)(45 * time.sca * (option.data.speed * 0.5f));
	data_ti.yy.check_angle();
//data_ti.yy_angle = 45;
data_ti.yy.set_size(0.75f);
	//lighter colors
	RGBcolor ycyi, ycya;
	ycyi.setcolor(255 - option.data.cbackground.r, 255 - option.data.cbackground.g, 255 - option.data.cbackground.b);
	ycya.setcolor(option.data.cbackground.r, option.data.cbackground.g, option.data.cbackground.b);
	data_ti.yy.set_colors(ycyi, ycya);

	//calculate yinyang symbol
	//data_ti.yy.calculate();

	//draw yinyang symbol
	dd.drawyinyang(data_ti.yy);
}
dd.draw_options_menu(&data_op, option.data.shadows);
if (false)
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				if (x == 0)
				{
					//dd.drawpoint(data_op.slot[x][y].pos, red);
					//dd.drawpoint(data_op.slot[x][y].pos_data, red);
				}
				//if (data_op.slot[x][y].set)
				if (data_op.slot[x][y].qualifier)
				{
					RGBcolor c = green;
					int bc = bmfblack;
					if (!strcmp(data_op.slot[x][y].qualifier, "Bnd RGB"))
					{
						c.setcolor(option.data.cbackground);
					}
					if (option.data.shadows)
					{
//						dd.typeSLF(data_op.slot[x][y].pos_qual.x, data_op.slot[x][y].pos_qual.y, 0, 0, 0, c.r, c.g, c.b, data_op.font_size, "%s", data_op.slot[x][y].qualifier);
//						dd.typeSLF(data_op.slot[x][y].pos_data.x, data_op.slot[x][y].pos_data.y, 0, 0, 0, c.r, c.g, c.b, data_op.font_size, "%s", data_op.slot[x][y].get_data_string());
					}
					else
					{
						dd.typebmf(data_op.slot[x][y].pos_qual.x, data_op.slot[x][y].pos_qual.y, bc, "%s", data_op.slot[x][y].qualifier);
						dd.typebmf(data_op.slot[x][y].pos_data.x, data_op.slot[x][y].pos_data.y, bc, "%s", data_op.slot[x][y].get_data_string());
					}
					//drawing
					//if (data_op.slot[x][y].o_type == OT_RGB)
					if (x < 1)
					{
						dd.drawrectangle_uf(data_op.slot[x][y].r_pos_qual, red);
						for (int s = 0; s < 3; ++s)
						{
							//if rectangle valid
							if (data_op.slot[x][y].r_pos_data[s].left != -1)
							{
								RGBcolor c(s * 100, y * 12, 255 - s * 125);
								dd.drawrectangle_uf(data_op.slot[x][y].r_pos_data[s], c);
							}
						}
					}
				}
			}

		//mouse cursor
		process_mousecursor(option.data.shadows);
	}

	return;

//-------------------------------------------------------------------------------------------------

//point line cd
if (false)
{
	static point P(100, 200);
	static line L(100, 100, 200, 100);
	circle C(P.x, P.y, 10);
	rectangle r;
	r.fill_rectangle(L.p[0].x, L.p[0].y, L.p[1].x, L.p[1].y,
					 L.p[1].x, L.p[1].y + 80, L.p[0].x, L.p[0].y + 80);

	if (!is.key(DIK_LSHIFT))
	{
		if (is.dimouse[1].rgbButtons[0] & 0x80)
		{
			L.p[0].x += is.dimouse[1].lX;
			L.p[0].y += is.dimouse[1].lY;
		}
		if (is.dimouse[1].rgbButtons[1] & 0x80)
		{
			L.p[1].x += is.dimouse[1].lX;
			L.p[1].y += is.dimouse[1].lY;
		}
	}
	else
	{
		if (is.dimouse[1].rgbButtons[0] & 0x80)
		{
			P.x += is.dimouse[1].lX;
			P.y += is.dimouse[1].lY;
		}
	}

	point coll(0, 0);
//	if (cd_line_line(A, B, coll))
//	if (cd_point_line(P, L))
//	if (cd_circle_rect(C.c, C.radius, r))
	float ff = cd_rect_circle(r, C.c, C.radius);
	dd.typebmf(400, 116, bmfred, "%.2f", ff);
	if (cd_rect_circle(r, C.c, C.radius) != -1)
	{
		playsound_s(S_MSELECT);
		line X(0, coll.y, 799, coll.y);
		line Y(coll.x, 0, coll.x, 599);
		dd.typebmf(400, 100, bmfblack, "COLLIDE %i %i", (int)coll.x, (int)coll.y);
		dd.drawline(X, green);
		dd.drawline(Y, green);
	}

	float dy = L.p[0].y - L.p[1].y;
	float dx = L.p[0].x - L.p[1].x;

	float slope = dy / dx;

	dd.typebmf(400, 184, bmfblack, "dx: %.1f dy: %.1f", dx, dy);
	dd.typebmf(400, 200, bmfblack, "slope: %.2f", slope);
	//dd.typebmf(400, 216, 0, "p0 p1: %.2f %.2f, %.2f %.2f", dd.dev_p[0].x, dd.dev_p[0].y, dd.dev_p[1].x, dd.dev_p[1].y);

	dd.drawline(L, red);
	dd.drawpoint(P, blue);
	dd.drawrectangle_uf(r, green);
	dd.drawcircle((int)C.c.x, (int)C.c.y, (int)C.radius, blue);

//	dd.drawpoint(A.p[0], black);
//	dd.drawpoint(A.p[1], black);
}

//2line cd
if (false)
{
	//cursor on/off
	if (is.key1D(DIK_SPACE))
	{
		mcursor[P1].toggle_cursor();
		mcursor[P2].toggle_cursor();
	}

	static line A(100, 100, 200, 100);
	static line B(100, 200, 200, 200);

	if (!is.key(DIK_LSHIFT))
	{
		if (is.dimouse[1].rgbButtons[0] & 0x80)
		{
			A.p[0].x += is.dimouse[1].lX;
			A.p[0].y += is.dimouse[1].lY;
		}
		if (is.dimouse[1].rgbButtons[1] & 0x80)
		{
			A.p[1].x += is.dimouse[1].lX;
			A.p[1].y += is.dimouse[1].lY;
		}
	}
	else
	{
		if (is.dimouse[1].rgbButtons[0] & 0x80)
		{
			B.p[0].x += is.dimouse[1].lX;
			B.p[0].y += is.dimouse[1].lY;
		}
		if (is.dimouse[1].rgbButtons[1] & 0x80)
		{
			B.p[1].x += is.dimouse[1].lX;
			B.p[1].y += is.dimouse[1].lY;
		}
	}

	point coll(0, 0);
	if (cd_line_line(A, B, coll))
	{
		playsound_s(S_MSELECT);
		line X(0, coll.y, 799, coll.y);
		line Y(coll.x, 0, coll.x, 599);
		dd.typebmf(400, 100, bmfblack, "COLLIDE %i %i", (int)coll.x, (int)coll.y);
		dd.drawline(X, green);
		dd.drawline(Y, green);
	}

	float dy = A.p[0].y - A.p[1].y;
	float dx = A.p[0].x - A.p[1].x;

	float slope = dy / dx;

	dd.typebmf(400, 184, bmfblack, "dx: %.1f dy: %.1f", dx, dy);
	dd.typebmf(400, 200, bmfblack, "slope: %.2f", slope);
	//dd.typebmf(400, 216, 0, "p0 p1: %.2f %.2f, %.2f %.2f", dd.dev_p[0].x, dd.dev_p[0].y, dd.dev_p[1].x, dd.dev_p[1].y);

	dd.drawline(A, red);
	dd.drawline(B, blue);

	dd.drawpoint(A.p[0], black);
	dd.drawpoint(A.p[1], black);
}


//show data
/*if (data_op.last_input == -1)
	dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: none", time.fps, data_op.selection);
if (data_ti.last_input == 0)
	dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: keyboard", time.fps, data_op.selection);
if (data_ti.last_input == 1)
	dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: mouse", time.fps, data_op.selection);
*/
//selection
/*
if (data_op.last_input == 0 && data_op.slot_set())
{
	data_op.set_selection(0, 0);
	playsound_s(S_MCANCEL);
}
//if (is.key1D(DIK_LEFT))
/*if (is.mouse(0, true, true, false))
{
	bool mc_so = false;
	for (int x = 0; x < OS_X; ++x)
		for (int y = 0; y < OS_Y; ++y)
			if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_qual))
				mc_so = true;
	if (mc_so)
		data_op.last_input = 1;
	else
		if (data_op.last_input == 1)
			data_op.set_selection(-1, -1);
}*/



//keyboard selection
/*
if (is.key1D(DIK_UPARROW) || is.keyhold(DIK_UPARROW, 8))
{
	if (data_op.decrease_SELOPT(0, 1))
		playsound_s(S_MSELECT);
}
if (is.key1D(DIK_DOWNARROW) || is.keyhold(DIK_DOWNARROW, 8))
{
	if (data_op.increase_SELOPT(0, 1))
		playsound_s(S_MSELECT);
}
if (is.key1D(DIK_LEFT) || is.keyhold(DIK_LEFT, 8))
{
	if (data_op.decrease_SELOPT(1, 0))
		playsound_s(S_MSELECT);
}
if (is.key1D(DIK_RIGHT) || is.keyhold(DIK_RIGHT, 8))
{
	if (data_op.increase_SELOPT(1, 0))
		playsound_s(S_MSELECT);
}*/




//-------------------------------------------------------------------------------------------------

//option entries
enum op_entry {oe_sound, oe_vsync, oe_fps_max, oe_show_fps, oe_shadows, oe_mblur, oe_bw_mode,
			   oe_cbackground, oe_subframes, oe_rounds, oe_speed,
			   oe_name_p1, oe_name_p2, oe_fistcolor_p1, oe_fistcolor_p2,
			   oe_damage, oe_fom,
			   oe_left_p1, oe_right_p1, oe_punch_p1, oe_kick_p1, oe_defend_p1, oe_special_p1,
			   oe_left_p2, oe_right_p2, oe_punch_p2, oe_kick_p2, oe_defend_p2, oe_special_p2,
			   oe_def, oe_credits, oe_done};

	//---- OLD VERSION ---------------------------------------------------------------------------

	//---- user input ----------------------------------------------------------------------------

	//---- mouse input ---------------------------------------------------------------------------

	//reset selection
//	data_op.selection_m = -1;
	//for all selections
	for (register int s = 0; s < NOOE; ++s)
		//if cursor in selection area and selection not already selected
//		if (hitboxcheck(cursor_pos_rect, data_op.c_selection[s]) && data_op.selection_m != s)
		{
			//set selection
//			data_op.selection_m = s;
			//play sound
			//playsound_s(S_MSELECT);
			break;
		}

	//if mouse selection valid, set keyboard selection to it
//	if (data_op.selection_m != -1)
//		data_op.selection = data_op.selection_m;

	//---- escape --------------------------------------------------------------------------------

	if (is.dikey1D[SYS_ESC] & 0x80)
	{
		//play sound
		playsound_s(S_MCANCEL);

		//if not within subselection reset selections and exit to main menu
		if (data_op.sub_selection == 0)
		{
			//reset selection, subselection
			data_op.selection = 0;
			data_op.sub_selection = 0;
			//reset state
			data_op.state = 0;

			//fade to white
			dd.gamma_fade(0, 1, 0.5f);
			program_state = TITLE;
			return;
		}
		//else exit subselection
		else
		{
			//if within name change p1 or p2
			if (data_op.selection == oe_name_p1 && data_op.sub_selection == 1)
			{
				//if character at current index is _ change it to zero
				//(_ acts as cursor)
				if (option.data.name[P1][data_op.s_index] == 95)
					option.data.name[P1][data_op.s_index] = 0;

				option.verify_player_names();
			}
	
			if (data_op.selection == oe_name_p2 && data_op.sub_selection == 1)
			{
				//if character at current index is _ change it to zero
				//(_ acts as cursor)
				if (option.data.name[P2][data_op.s_index] == 95)
					option.data.name[P2][data_op.s_index] = 0;

				option.verify_player_names();
			}

			//reset subselection
			data_op.sub_selection = 0;
		}
	}

	//---- read in names -------------------------------------------------------------------------

	//if subseleciton is 1 and option selection is either name[P1] or name[P2]
	//read in namestring
	if (data_op.sub_selection == 1 &&
		(data_op.selection == oe_name_p1 || data_op.selection == oe_name_p2))
	{
		//maximum length of string without NULL
		int length	= 20;
		//ascii code of current character
		int ascii	= 0;

		//if index is not at last character
		if (data_op.s_index < length - 1)
		{
			//character at index is _ (works as cursor)
			//either p1/p2
			if (data_op.selection == oe_name_p1)
				option.data.name[P1][data_op.s_index] = 95;
			else
				option.data.name[P2][data_op.s_index] = 95;
		}
		else
		{
			//either p1/p2
			if (data_op.selection == oe_name_p1)
			{
				//if at last character
				//if character is empty print _ else don't
				if (option.data.name[P1][data_op.s_index] == 0)
					option.data.name[P1][data_op.s_index] = 95;
			}
			else
			{
				//if at last character
				//if character is empty print _ else don't
				if (option.data.name[P2][data_op.s_index] == 0)
					option.data.name[P2][data_op.s_index] = 95;
			}
		}

		//get keyboard input
		ascii = getinput_ascii();

		//if input is not NULL (no input) assign character to namestring
		if (ascii != 0)
		{
			//either p1/p2
			if (data_op.selection == oe_name_p1)
				option.data.name[P1][data_op.s_index] = ascii;
			else
				option.data.name[P2][data_op.s_index] = ascii;

			//if index not at max length increase index
			if (data_op.s_index < length - 1)
				++data_op.s_index;
		}

		//if user hits backspace and index is bigger than zero
		if (is.dikey1D[SYS_BACK] & 0x80 && data_op.s_index > 0)
		{
			//if index not at last character
			if (data_op.s_index != length - 1)
			{
				//either p1/p2
				if (data_op.selection == oe_name_p1)
					//decrease index and set character at new index to 0
					option.data.name[P1][data_op.s_index] = 0;
				else
					option.data.name[P2][data_op.s_index] = 0;

				--data_op.s_index;
			}
			else
			//if index is at last character
			{
				//either p1/p2
				if (data_op.selection == oe_name_p1)
				{
					//if character at last index is not zero
					if (option.data.name[P1][length - 1] != 0 &&
						option.data.name[P1][length - 1] != 95)
					{
						//set last character to zero, index remains
						option.data.name[P1][data_op.s_index] = 0;
					}
					else
					{
						//decrease index and set character at new index to 0
						option.data.name[P1][data_op.s_index] = 0;
						--data_op.s_index;
					}
				}
				else
				{
					//if character at last index is not zero
					if (option.data.name[P2][length - 1] != 0 &&
						option.data.name[P2][length - 1] != 95)
					{
						//set last character to zero, index remains
						option.data.name[P2][data_op.s_index] = 0;
					}
					else
					{
						//decrease index and set character at new index to 0
						option.data.name[P2][data_op.s_index]= 0;
						--data_op.s_index;
					}
				}
			}
		}
	}

	//---- read in controls ----------------------------------------------------------------------

	//if subselection is 1
	if (data_op.sub_selection == 1)
	{
		//if current selection is control
		if (data_op.selection >= oe_left_p1 &&
			data_op.selection <= oe_special_p2)
		{
			//for every key
			for (register int i = 0; i < 256; ++i)
			{
				//if button is pressed, assign it and reset subselection
				if (is.dikey1D[i] & 0x80)
				{
					//locked keys
					//on invalid keys break loop (reserved for system commands)
					if (!option.verify_key(i))
					{
						//play cancel sound
						playsound_s(S_MCANCEL);

						data_op.sub_selection = 0;
						return;
					}

					//play sound
					playsound_s(S_MENTER);

					//assign button to command according to selection
					//also assign new value to option entry with help of
					//getinput_char which returns a string with the describtion
					//of button of DIK argument
					/* //!!
					if (data_op.selection == oe_left_p1){
						option.data.ckey[P1][LEFT] = i;
						data_op.oe[oe_left_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_right_p1){
						option.data.ckey[P1][RIGHT] = i;
						data_op.oe[oe_right_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_punch_p1){
						option.data.ckey[P1][PUNCH] = i;
						data_op.oe[oe_punch_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_kick_p1){
						option.data.ckey[P1][KICK] = i;
						data_op.oe[oe_kick_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_defend_p1){
						option.data.ckey[P1][DEFEND] = i;
						data_op.oe[oe_defend_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_special_p1){
						option.data.ckey[P1][SPECIAL] = i;
						data_op.oe[oe_special_p1].s_value = getinput_char(i);}
					if (data_op.selection == oe_left_p2){
						option.data.ckey[P2][LEFT] = i;
						data_op.oe[oe_left_p2].s_value = getinput_char(i);}
					if (data_op.selection == oe_right_p2){
						option.data.ckey[P2][RIGHT] = i;
						data_op.oe[oe_right_p2].s_value = getinput_char(i);}
					if (data_op.selection == oe_punch_p2){
						option.data.ckey[P2][PUNCH] = i;
						data_op.oe[oe_punch_p2].s_value = getinput_char(i);}
					if (data_op.selection == oe_kick_p2){
						option.data.ckey[P2][KICK] = i;
						data_op.oe[oe_kick_p2].s_value = getinput_char(i);}
					if (data_op.selection == oe_defend_p2){
						option.data.ckey[P2][DEFEND] = i;
						data_op.oe[oe_defend_p2].s_value = getinput_char(i);}
					if (data_op.selection == oe_special_p2){
						option.data.ckey[P2][SPECIAL] = i;
						data_op.oe[oe_special_p2].s_value = getinput_char(i);}*/
					
					data_op.sub_selection = 0;

					return;
				}
			}

			//for every mousebutton of mouse 1
			for (i = 0; i < 4; ++i)
			{
				//if button is pressed, assign it and reset subselection
				//mouse 1
				if (is.dimouse1D[1].rgbButtons[i] & 0x80)
				{
					//play sound
					playsound_s(S_MENTER);

					//assign button to command according to selection
					/* //!!
					if (data_op.selection == oe_left_p1){
						option.data.ckey[P1][LEFT] = -i;
						data_op.oe[oe_left_p1].s_value = getinput_char(-i);}
					if (data_op.selection == oe_right_p1){
						option.data.ckey[P1][RIGHT] = -i;
						data_op.oe[oe_right_p1].s_value = getinput_char(-i);}
					if (data_op.selection == oe_punch_p1){
						option.data.ckey[P1][PUNCH] = -i;
						data_op.oe[oe_punch_p1].s_value = getinput_char(-i);}
					if (data_op.selection == oe_kick_p1){
						option.data.ckey[P1][KICK] = -i;
						data_op.oe[oe_kick_p1].s_value = getinput_char(-i);}
					if (data_op.selection == oe_defend_p1){
						option.data.ckey[P1][DEFEND] = -i;
						data_op.oe[oe_defend_p1].s_value = getinput_char(-i);}
					if (data_op.selection == oe_special_p1){
						option.data.ckey[P1][SPECIAL] = -i;
						data_op.oe[oe_special_p1].s_value = getinput_char(-i);}*/

					data_op.sub_selection = 0;
					return;
				}

				//mouse 2
				if (is.dimouse1D[2].rgbButtons[i] & 0x80)
				{
					//play sound
					playsound_s(S_MENTER);

					//assign button to command according to selection
					/* //!!
					if (data_op.selection == oe_left_p2){
						option.data.ckey[P2][LEFT] = -i;
						data_op.oe[oe_left_p2].s_value = getinput_char(-i);}
					if (data_op.selection == oe_right_p2){
						option.data.ckey[P2][RIGHT] = -i;
						data_op.oe[oe_right_p2].s_value = getinput_char(-i);}
					if (data_op.selection == oe_punch_p2){
						option.data.ckey[P2][PUNCH] = -i;
						data_op.oe[oe_punch_p2].s_value = getinput_char(-i);}
					if (data_op.selection == oe_kick_p2){
						option.data.ckey[P2][KICK] = -i;
						data_op.oe[oe_kick_p2].s_value = getinput_char(-i);}
					if (data_op.selection == oe_defend_p2){
						option.data.ckey[P2][DEFEND] = -i;
						data_op.oe[oe_defend_p2].s_value = getinput_char(-i);}
					if (data_op.selection == oe_special_p2){
						option.data.ckey[P2][SPECIAL] = -i;
						data_op.oe[oe_special_p2].s_value = getinput_char(-i);}*/

					data_op.sub_selection = 0;
					return;
				}
			}
		}
	}

	//---- uparrow -------------------------------------------------------------------------------

	if (is.dikey1D[SYS_UP] & 0x80)
	{
		//play sound
		playsound_s(S_MSELECT);

		switch (data_op.sub_selection)
		{
		//no subselection
//		case (oe_sound):
		case (0):
			{
				//if default move cursor to special_p1
				if (data_op.selection == oe_def)
				{
					data_op.selection = oe_special_p1;
					break;
				}

				if (data_op.selection > 0)
					--data_op.selection;
				else
					data_op.selection = data_op.noe - 1;

				break;
			}

		//first subselection
		case (1):
			{
				switch (data_op.selection)
				{
				//fps_max
				case (oe_fps_max):
					{
						if (option.data.fps_max == 0)
						{
							option.data.fps_max = option.dataMIN.fps_max;
							time.set_fps_max(option.data.fps_max);
							break;
						}

						//increase in steps of 10fps
						if (option.data.fps_max < option.dataMAX.fps_max)
							option.data.fps_max += 10;
						else
							option.data.fps_max = 0;

						time.set_fps_max(option.data.fps_max);

						break;
					}

				//mblur
				case (oe_mblur):
					{
						//increase in steps of 1fps
						if (option.data.mblur < option.dataMAX.mblur)
							++option.data.mblur;
						else
							option.data.mblur = option.dataMIN.mblur;

						break;
					}

				//cbackground
				case (oe_cbackground):
					{
						//increase in steps of 5
						if (option.data.cbackground.r < option.dataMAX.cbackground.r)
							option.data.cbackground.r += 5;
						else
							option.data.cbackground.r = option.dataMIN.cbackground.r;

						break;
					}

				//subframes
				case (oe_subframes):
					{
						if (option.data.subframes < option.dataMAX.subframes)
							++option.data.subframes;
						else
							option.data.subframes = option.dataMIN.subframes;

						break;
					}

				//rounds
				case (oe_rounds):
					{
						if (option.data.rounds < option.dataMAX.rounds)
							++option.data.rounds;
						else
							option.data.rounds = option.dataMIN.rounds;

						break;
					}

				//speed
				case (oe_speed):
					{
						if (option.data.speed <= option.dataMAX.speed - 0.1f)
							option.data.speed += 0.1f;
						else
							option.data.speed = option.dataMIN.speed;

						//set frequency of soundbuffers
						ds.setfrequency(BT_P1, -1, option.data.speed);
						ds.setfrequency(BT_P2, -1, option.data.speed);
						//!!ds.setfrequency(option.data.speed);

						break;
					}

				//damage multiplier
				case (oe_damage):
					{
						if (option.data.damage_multiplier <= option.dataMAX.damage_multiplier - 0.1f)
							option.data.damage_multiplier += 0.1f;
						else
							option.data.damage_multiplier = option.dataMIN.damage_multiplier;

						break;
					}

				//fom multiplier
				case (oe_fom):
					{
						if (option.data.fom_multiplier <= option.dataMAX.fom_multiplier - 0.1f)
							option.data.fom_multiplier += 0.1f;
						else
							option.data.fom_multiplier = option.dataMIN.fom_multiplier;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P1].r < option.dataMAX.fistcolor[P1].r)
							option.data.fistcolor[P1].r += 5;
						else
							option.data.fistcolor[P1].r = option.dataMIN.fistcolor[P1].r;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P2].r < option.dataMAX.fistcolor[P2].r)
							option.data.fistcolor[P2].r += 5;
						else
							option.data.fistcolor[P2].r = option.dataMIN.fistcolor[P2].r;

						break;
					}
				}

				break;
			}

		//second subselection
		case (2):
			{
				switch (data_op.selection)
				{
				//cbackground
				case (oe_cbackground):
					{
						//increase in steps of 5
						if (option.data.cbackground.g < option.dataMAX.cbackground.g)
							option.data.cbackground.g += 5;
						else
							option.data.cbackground.g = option.dataMIN.cbackground.g;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P1].g < option.dataMAX.fistcolor[P1].g)
							option.data.fistcolor[P1].g += 5;
						else
							option.data.fistcolor[P1].g = option.dataMIN.fistcolor[P1].g;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P2].g < option.dataMAX.fistcolor[P2].g)
							option.data.fistcolor[P2].g += 5;
						else
							option.data.fistcolor[P2].g = option.dataMIN.fistcolor[P2].g;

						break;
					}
				}

				break;
			}

		//third subselection
		case (3):
			{
				switch (data_op.selection)
				{
				//cbackground
				case (oe_cbackground):
					{
						//increase in steps of 5
						if (option.data.cbackground.b < option.dataMAX.cbackground.b)
							option.data.cbackground.b += 5;
						else
							option.data.cbackground.b = option.dataMIN.cbackground.b;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P1].b < option.dataMAX.fistcolor[P1].b)
							option.data.fistcolor[P1].b += 5;
						else
							option.data.fistcolor[P1].b = option.dataMIN.fistcolor[P1].b;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//increase in steps of 5
						if (option.data.fistcolor[P2].b < option.dataMAX.fistcolor[P2].b)
							option.data.fistcolor[P2].b += 5;
						else
							option.data.fistcolor[P2].b = option.dataMIN.fistcolor[P2].b;

						break;
					}
				}

				break;
			}
		}
	}

	//---- downarrow -----------------------------------------------------------------------------

	if (is.dikey1D[SYS_DOWN] & 0x80)
	{
		//play sound
		playsound_s(S_MSELECT);

		switch (data_op.sub_selection)
		{
		//no subselection
//		case (oe_sound):
		case (0):
			{
				//if special_p1 move cursor to default
				if (data_op.selection == oe_special_p1)
				{
					data_op.selection = oe_def;
					break;
				}

				if (data_op.selection < data_op.noe - 1)
					++data_op.selection;
				else
					data_op.selection = 0;

				break;
			}

		//first subselection
		case (1):
			{
				switch (data_op.selection)
				{
				//fps_max
				case (oe_fps_max):
					{
						if (option.data.fps_max == option.dataMIN.fps_max)
						{
							option.data.fps_max = 0;
							time.set_fps_max(option.data.fps_max);

							break;
						}

						//decrease in steps of 10fps
						if (option.data.fps_max > option.dataMIN.fps_max)
							option.data.fps_max -= 10;
						else
							option.data.fps_max = option.dataMAX.fps_max;

						time.set_fps_max(option.data.fps_max);

						break;
					}

				//mblur
				case (oe_mblur):
					{
						//decrease in steps of 100ms
						if (option.data.mblur > option.dataMIN.mblur)
							--option.data.mblur;
						else
							option.data.mblur = option.dataMAX.mblur;

						break;
					}

				//cbackground
				case (oe_cbackground):
					{
						//decrease in steps of 5
						if (option.data.cbackground.r > option.dataMIN.cbackground.r)
							option.data.cbackground.r -= 5;
						else
							option.data.cbackground.r = option.dataMAX.cbackground.r;

						break;
					}

				//subframes
				case (oe_subframes):
					{
						if (option.data.subframes > option.dataMIN.subframes)
							--option.data.subframes;
						else
							option.data.subframes = option.dataMAX.subframes;

						break;
					}

				//rounds
				case (oe_rounds):
					{
						if (option.data.rounds > option.dataMIN.rounds)
							--option.data.rounds;
						else
							option.data.rounds = option.dataMAX.rounds;

						break;
					}

				//speed
				case (oe_speed):
					{
						if (option.data.speed >= option.dataMIN.speed + 0.1f)
							option.data.speed -= 0.1f;
						else
							option.data.speed = option.dataMAX.speed;

						//set frequency of soundbuffers
						ds.setfrequency(BT_P1, -1, option.data.speed);
						ds.setfrequency(BT_P2, -1, option.data.speed);
						//ds.setfrequency(option.data.speed);

						break;
					}

				//damage multiplier
				case (oe_damage):
					{
						if (option.data.damage_multiplier >= option.dataMIN.damage_multiplier + 0.1f)
							option.data.damage_multiplier -= 0.1f;
						else
							option.data.damage_multiplier = option.dataMAX.damage_multiplier;

						break;
					}

				//fom multiplier
				case (oe_fom):
					{
						if (option.data.fom_multiplier >= option.dataMIN.fom_multiplier + 0.1f)
							option.data.fom_multiplier -= 0.1f;
						else
							option.data.fom_multiplier = option.dataMAX.fom_multiplier;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P1].r > option.dataMIN.fistcolor[P1].r)
							option.data.fistcolor[P1].r -= 5;
						else
							option.data.fistcolor[P1].r = option.dataMAX.fistcolor[P1].r;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P2].r > option.dataMIN.fistcolor[P2].r)
							option.data.fistcolor[P2].r -= 5;
						else
							option.data.fistcolor[P2].r = option.dataMAX.fistcolor[P2].r;

						break;
					}
				}

				break;
			}

		//second subselection
		case (2):
			{
				switch (data_op.selection)
				{
				//cbackground
				case (oe_cbackground):
					{
						//decrease in steps of 5
						if (option.data.cbackground.g > option.dataMIN.cbackground.g)
							option.data.cbackground.g -= 5;
						else
							option.data.cbackground.g = option.dataMAX.cbackground.g;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P1].g > option.dataMIN.fistcolor[P1].g)
							option.data.fistcolor[P1].g -= 5;
						else
							option.data.fistcolor[P1].g = option.dataMAX.fistcolor[P1].g;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P2].g > option.dataMIN.fistcolor[P2].g)
							option.data.fistcolor[P2].g -= 5;
						else
							option.data.fistcolor[P2].g = option.dataMAX.fistcolor[P2].g;

						break;
					}
				}

				break;
			}

		//third subselection
		case (3):
			{
				switch (data_op.selection)
				{
				//cbackground
				case (oe_cbackground):
					{
						//decrease in steps of 5
						if (option.data.cbackground.b > option.dataMIN.cbackground.b)
							option.data.cbackground.b -= 5;
						else
							option.data.cbackground.b = option.dataMAX.cbackground.b;

						break;
					}

				//fistcolor[P1]
				case (oe_fistcolor_p1):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P1].b > option.dataMIN.fistcolor[P1].b)
							option.data.fistcolor[P1].b -= 5;
						else
							option.data.fistcolor[P1].b = option.dataMAX.fistcolor[P1].b;

						break;
					}

				//fistcolor[P2]
				case (oe_fistcolor_p2):
					{
						//decrease in steps of 5
						if (option.data.fistcolor[P2].b > option.dataMIN.fistcolor[P2].b)
							option.data.fistcolor[P2].b -= 5;
						else
							option.data.fistcolor[P2].b = option.dataMAX.fistcolor[P2].b;

						break;
					}
				}

				break;
			}
		}
	}

	//---- leftarrow -----------------------------------------------------------------------------

	if (is.dikey1D[SYS_LEFT] & 0x80)
	{
		switch (data_op.selection)
		{
		//sound to background color horizontal selection movement
		//!! anpassen und statt zahlen oe_entries benutzen
		case (0):
		case (1):
		case (2):
		case (3):
		case (4):
		case (5):
		case (6):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection = oe_left_p2;
			}
			break;

		//background
		case (oe_cbackground):
			{
				//if not within subselection
				if (data_op.sub_selection == 0)
				{
					//play sound
					playsound_s(S_MSELECT);
					data_op.selection = oe_left_p2;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection > 1)
						--data_op.sub_selection;
					else
						data_op.sub_selection = 3;
				}

				break;
			}

		//vertical movement subframes to speed
		case (8):
		case (9):
		case (10):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection += 13;
			}
			break;

		//vertical movement names
		case (11):
		case (12):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection += 14;
			}
			break;

		//fistcolor[P1]
		case (oe_fistcolor_p1):
			{
				//if not within subselection
				if (data_op.sub_selection == 0)
				{
					//play sound
					playsound_s(S_MSELECT);
					data_op.selection += 14;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection > 1)
						--data_op.sub_selection;
					else
						data_op.sub_selection = 3;
				}

				break;
			}

		//fistcolor[P2]
		case (oe_fistcolor_p2):
			{
				//if not within subselection
				if (data_op.sub_selection == 0)
				{
					//play sound
					playsound_s(S_MSELECT);
					data_op.selection += 14;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection > 1)
						--data_op.sub_selection;
					else
						data_op.sub_selection = 3;
				}

				break;
			}

		//vertical movement left_p1 to punch_p1
		case (oe_left_p1):
		case (oe_right_p1):
		case (oe_punch_p1):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 7;
			break;

		case (oe_kick_p1):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection += 6;
			break;

		//defend, special
		case (oe_defend_p1):
		case (oe_special_p1):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 8;
			break;

		//player_2
		case (oe_left_p2):
		case (oe_right_p2):
		case (oe_punch_p2):
		case (oe_kick_p2):
		case (oe_defend_p2):
		case (oe_special_p2):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 6;
			break;

		//default, credits
		case (oe_def):
		case (oe_credits):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 14;
			break;
		}
	}

	//---- rightarrow ----------------------------------------------------------------------------

	if (is.dikey1D[SYS_RIGHT] & 0x80)
	{
		switch (data_op.selection)
		{
		//sound to background color horizontal selection movement
		case (0):
		case (1):
		case (2):
		case (3):
		case (4):
		case (5):
		case (6):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection = oe_left_p1;
			}
			break;

		//background
		case (oe_cbackground):
			{
				//if not within subselection
				//play sound
				if (data_op.sub_selection == 0)
				{
					playsound_s(S_MSELECT);
					data_op.selection = oe_left_p1;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection < 3)
						++data_op.sub_selection;
					else
						data_op.sub_selection = 1;
				}

				break;
			}

		//vertical movement subframes to speed
		case (8):
		case (9):
		case (10):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection += 7;
			}
			break;

		//vertical movement names
		case (11):
		case (12):
			if (data_op.sub_selection == 0)
			{
				//play sound
				playsound_s(S_MSELECT);
				data_op.selection += 8;
			}
			break;

		//fistcolor[P1]
		case (oe_fistcolor_p1):
			{
				//if not within subselection
				if (data_op.sub_selection == 0)
				{
					//play sound
					playsound_s(S_MSELECT);
					data_op.selection += 14;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection < 3)
						++data_op.sub_selection;
					else
						data_op.sub_selection = 1;
				}

				break;
			}

		//fistcolor[P2]
		case (oe_fistcolor_p2):
			{
				//if not within subselection
				if (data_op.sub_selection == 0)
				{
					//play sound
					playsound_s(S_MSELECT);
					data_op.selection += 14;
					break;
				}

				//if within subselection
				if (data_op.sub_selection != 0)
				{
					//play sound
					playsound_s(S_MSELECT);

					//circle through subselections
					if (data_op.sub_selection < 3)
						++data_op.sub_selection;
					else
						data_op.sub_selection = 1;
				}

				break;
			}

		//vertical movement left_p1 to kick_p1
		case (oe_left_p1):
		case (oe_right_p1):
		case (oe_punch_p1):
		case (oe_kick_p1):
		case (oe_defend_p1):
		case (oe_special_p1):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection += 6;
			break;

		//player_2
		case (oe_left_p2):
		case (oe_right_p2):
		case (oe_punch_p2):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 13;
			break;

		case (oe_kick_p2):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 6;
			break;

		case (oe_defend_p2):
		case (oe_special_p2):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 14;
			break;

		//default, credits
		case (oe_def):
		case (oe_credits):
			//play sound
			playsound_s(S_MSELECT);
			data_op.selection -= 14;
			break;
		}
	}

	//---- enter ---------------------------------------------------------------------------------

	if (is.dikey1D[SYS_RETURN] & 0x80)
	{
		//play sound
		playsound_s(S_MENTER);

		switch (data_op.selection)
		{
		//sound
		case (oe_sound):
			{
				//change sound if sound option available
				if (option.dataDEF.sound == 1)
				{
					//turn on/off
					option.data.sound	= !option.data.sound;
					//change user setting in ds object
					//ds.sound_set		= option.data.sound;
				}

				break;
			}

		//vsync
		case (oe_vsync):
			{
				//reverse vsync
				option.data.vsync = !option.data.vsync;
				break;
			}

		//fps_max
		case (oe_fps_max):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//show_fps
		case (oe_show_fps):
			{
				//change show_fps
				option.data.show_fps = !option.data.show_fps;
				break;
			}

		//shadows
		case (oe_shadows):
			{
				//change shadows
				option.data.shadows = !option.data.shadows;
				break;
			}

		//mblur
		case (oe_mblur):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//bw_mode
		case (oe_bw_mode):
			{
				//change vsync
				option.data.bw_mode = !option.data.bw_mode;
				break;
			}

		//cbackground
		case (oe_cbackground):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//subframes
		case (oe_subframes):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//rounds
		case (oe_rounds):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//speed
		case (oe_speed):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//damage multiplier
		case (oe_damage):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//fom multiplier
		case (oe_fom):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//name[P1]
		case (oe_name_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				//if entered subselection
				if (data_op.sub_selection == 1)
				{
					//set current string index to length of current name
					data_op.s_index = strlen(option.data.name[P1]);
					//if index greater than max length, index is max length
					data_op.s_index > 19 ? data_op.s_index = 19 : data_op.s_index;

					//fill rest of string with zeros
					for (register int i = data_op.s_index + 1; i < 21; ++i)
						option.data.name[P1][i] = 0;

				}
				else
				//if left subselection
				{
					//if character at current index is _ change it to zero
					//(_ acts as cursor)
					if (option.data.name[P1][data_op.s_index] == 95)
						option.data.name[P1][data_op.s_index] = 0;

					option.verify_player_names();
				}

				break;
			}

		//name[P2]
		case (oe_name_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				//if entered subselection
				if (data_op.sub_selection == 1)
				{
					//set current string index to length of current name
					data_op.s_index = strlen(option.data.name[P2]);
					//if index greater than max length, index is max length
					data_op.s_index > 19 ? data_op.s_index = 19 : data_op.s_index;

					//fill rest of string with zeros
					for (register int i = data_op.s_index + 1; i < 21; ++i)
						option.data.name[P2][i] = 0;

				}
				else
				//if left subselection
				{
					//if character at current index is _ change it to zero
					//(_ acts as cursor)
					if (option.data.name[P2][data_op.s_index] == 95)
						option.data.name[P2][data_op.s_index] = 0;

					option.verify_player_names();
				}

				break;
			}

		//fistcolor[P1]
		case (oe_fistcolor_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//fistcolor[P2]
		case (oe_fistcolor_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//left_p1
		case (oe_left_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//right_p1
		case (oe_right_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//punch_p1
		case (oe_punch_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//kick_p1
		case (oe_kick_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//defend_p1
		case (oe_defend_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//special_p1
		case (oe_special_p1):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//left_p2
		case (oe_left_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//right_p2
		case (oe_right_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//punch_p2
		case (oe_punch_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//kick_p2
		case (oe_kick_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//defend_p2
		case (oe_defend_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//special_p2
		case (oe_special_p2):
			{
				//change subselection
				data_op.sub_selection = !data_op.sub_selection;

				break;
			}

		//default
		case (oe_def):
			{
				//set current options to default options
				option.reset();
				//ds.sound_set		= option.dataDEF.sound;
				time.set_fps_max(option.data.fps_max);
				//reset option entry player commands
				/* //!!
				data_op.oe[oe_left_p1].s_value = getinput_char(option.data.ckey[P1][LEFT]);
				data_op.oe[oe_right_p1].s_value = getinput_char(option.data.ckey[P1][RIGHT]);
				data_op.oe[oe_punch_p1].s_value = getinput_char(option.data.ckey[P1][PUNCH]);
				data_op.oe[oe_kick_p1].s_value = getinput_char(option.data.ckey[P1][KICK]);
				data_op.oe[oe_defend_p1].s_value = getinput_char(option.data.ckey[P1][DEFEND]);
				data_op.oe[oe_special_p1].s_value = getinput_char(option.data.ckey[P1][SPECIAL]);
				data_op.oe[oe_left_p2].s_value = getinput_char(option.data.ckey[P2][LEFT]);
				data_op.oe[oe_right_p2].s_value = getinput_char(option.data.ckey[P2][RIGHT]);
				data_op.oe[oe_punch_p2].s_value = getinput_char(option.data.ckey[P2][PUNCH]);
				data_op.oe[oe_kick_p2].s_value = getinput_char(option.data.ckey[P2][KICK]);
				data_op.oe[oe_defend_p2].s_value = getinput_char(option.data.ckey[P2][DEFEND]);
				data_op.oe[oe_special_p2].s_value = getinput_char(option.data.ckey[P2][SPECIAL]);*/
				break;
			}

		//credits
		case (oe_credits):
			{
				//reset options menu states
				data_op.state			= 0;
				data_op.selection		= 0;
				data_op.sub_selection	= 0;

				//fade to black
				dd.gamma_fade(0, 0, 0.5f);
				program_state			= CREDITS;
				return;
			}

		//done
		case (oe_done):
			{
				//reset selection, subselection
				data_op.selection		= 0;
				data_op.sub_selection	= 0;
				//reset state
				data_op.state			= 0;

				//set cursor pos
				mcursor[0].set_pos(345, 90);

				//fade to white
				dd.gamma_fade(0, 1, 0.5f);
				program_state			= TITLE;
				return;
			}
		}
	}

	//reset all selections
	for (register int i = 0; i < data_op.noe; ++i)
		data_op.oe[i].selection = 0;

	//if option available
	if (data_op.oe[data_op.selection].available == 1)
	{
		//if type -1 (system) select qualifier
		if (data_op.oe[data_op.selection].type == -1)
			data_op.oe[data_op.selection].selection = 1;

		//if type 0 (on/off) select qualifier and value
		if (data_op.oe[data_op.selection].type == 0)
			data_op.oe[data_op.selection].selection = 2;
		else
		//else select value depending on subselection (only qualifier or subvalues)
		{
			if (data_op.sub_selection == 0)
				data_op.oe[data_op.selection].selection = 1;
			if (data_op.sub_selection == 1)
				data_op.oe[data_op.selection].selection = 2;
			if (data_op.sub_selection == 2)
				data_op.oe[data_op.selection].selection = 3;
			if (data_op.sub_selection == 3)
				data_op.oe[data_op.selection].selection = 4;
		}
	}
	else
		//only mark qualifier
		data_op.oe[data_op.selection].selection = 1;

	//---- initialization ------------------------------------------------------------------------

	if (data_op.state == 0)
	{
		//initialize and set state to 1
		data_op.state = 1;

		//draw screen while faded to white and than fade back to standard
		//draw background
		dd.drawbackground(option.data.cbackground.r,
						  option.data.cbackground.g,
						  option.data.cbackground.b);

		//draw lines
		RGBcolor		temp_c;
		line l1(0, 299, 799, 299),	l2(399, 75, 399, 524);
		dd.drawline(l1, temp_c);	dd.drawline(l2, temp_c);

		//calculate and draw yinyang if shadows on
		if (option.data.shadows == 1)
		{
			//draw yinyang from title (data_ti) but different position
			data_op.yy.set_position(400, 300);

			//lighter colors
			RGBcolor ycyi, ycya;
			ycyi.setcolor(255 - option.data.cbackground.r, 255 - option.data.cbackground.g, 255 - option.data.cbackground.b);
			ycya.setcolor(option.data.cbackground.r, option.data.cbackground.g, option.data.cbackground.b);
			data_ti.yy.set_colors(ycyi, ycya);

			//calculate yinyang symbol
			//data_ti.yy.calculate();

			//draw yinyang symbol
			dd.drawyinyang(data_ti.yy);
		}

		//---- intitialize all option entries ----------------------------------------------------

		//---- sound -----------------------------------------------------------------------------

		//if sound available
		if (option.dataDEF.sound == 1)
		{
			data_op.oe[oe_sound].fill_entry("Sound",				//qualifier
											&option.data.sound,		//i_value[0]
											NULL,					//i_value[1]
											NULL,					//i_value[2]
											NULL,					//f_value
											NULL,					//s_value
											0,						//precision
											0,						//type
											2,						//selection
											option.dataDEF.sound,	//available
											10, 90,					//qualifier position
											270, 90);				//value position
		}
		else
		{
			data_op.oe[oe_sound].fill_entry("Sound",				//qualifier
											&option.dataDEF.sound,	//i_value[0]
											NULL,					//i_value[1]
											NULL,					//i_value[2]
											NULL,					//f_value
											NULL,					//s_value
											0,						//precision
											0,						//type
											0,						//selection
											option.dataDEF.sound,	//available
											10, 90,					//qualifier position
											270, 90);				//value position
		}

		//---- vsync -----------------------------------------------------------------------------

		data_op.oe[oe_vsync].fill_entry("VSync", &option.data.vsync, NULL, NULL, NULL, NULL,
										0, 0, 0, 1, 10, 110, 270, 110);
		//---- fps_max ---------------------------------------------------------------------------

		data_op.oe[oe_fps_max].fill_entry("Maximum FPS", &option.data.fps_max, NULL, NULL, NULL, NULL,
										  0, 1, 0, 1, 10, 130, 270, 130);

		//---- show_fps --------------------------------------------------------------------------

		data_op.oe[oe_show_fps].fill_entry("Show FPS", &option.data.show_fps, NULL, NULL, NULL, NULL,
										   0, 0, 0, 1, 10, 150, 270, 150);

		//---- shadows ---------------------------------------------------------------------------

		data_op.oe[oe_shadows].fill_entry("Shadows", &option.data.shadows, NULL, NULL, NULL, NULL,
										  0, 0, 0, 1, 10, 190, 270, 190);

		//---- mblur -----------------------------------------------------------------------------

		data_op.oe[oe_mblur].fill_entry("MotionBlur", &option.data.mblur, NULL, NULL, NULL, NULL,
										0, 1, 0, 1, 10, 210, 270, 210);

		//---- bw_mode ---------------------------------------------------------------------------

		data_op.oe[oe_bw_mode].fill_entry("Black&White Mode", &option.data.bw_mode, NULL, NULL, NULL, NULL,
										  0, 0, 0, 1, 10, 230, 270, 230);

		//---- cbackground -----------------------------------------------------------------------

		data_op.oe[oe_cbackground].fill_entry("Background RGB", &option.data.cbackground.r, &option.data.cbackground.g, &option.data.cbackground.b, NULL, NULL,
											  0, 4, 0, 1, 10, 250, 220, 250);

		//---- subframes -------------------------------------------------------------------------

		data_op.oe[oe_subframes].fill_entry("Subframes", &option.data.subframes, NULL, NULL, NULL, NULL,
											0, 1, 0, 1, 10, 315, 270, 315);

		//---- rounds ----------------------------------------------------------------------------

		data_op.oe[oe_rounds].fill_entry("Rounds", &option.data.rounds, NULL, NULL, NULL, NULL,
										 0, 2, 0, 1, 10, 335, 270, 335);

		//---- speed -----------------------------------------------------------------------------

		data_op.oe[oe_speed].fill_entry("Speed", NULL, NULL, NULL, &option.data.speed, NULL,
										1, 2, 0, 1, 10, 355, 270, 355);

		//---- damage_multiplier -----------------------------------------------------------------

		data_op.oe[oe_damage].fill_entry("Damage Multiplier", NULL, NULL, NULL, &option.data.damage_multiplier, NULL,
										 1, 2, 0, 1, 410, 90, 720, 90);

		//---- fom_multiplier --------------------------------------------------------------------

		//!! 1
		data_op.oe[oe_fom].fill_entry("Fatigue Multiplier", NULL, NULL, NULL, &option.data.fom_multiplier, NULL,
										 1, 1, 0, 1, 410, 110, 720, 110);

		//---- name[P1] ---------------------------------------------------------------------------

		data_op.oe[oe_name_p1].fill_entry("Name P1", NULL, NULL, NULL, NULL, option.data.name[P1],
										  0, 3, 0, 1, 10, 395, 134, 395);

		//---- name[P2] ---------------------------------------------------------------------------

		data_op.oe[oe_name_p2].fill_entry("Name P2", NULL, NULL, NULL, NULL, option.data.name[P2],
										  0, 3, 0, 1, 10, 415, 134, 415);

		//---- fistcolor[P1] ----------------------------------------------------------------------

		data_op.oe[oe_fistcolor_p1].fill_entry("Fistcolor P1 RGB", &option.data.fistcolor[P1].r, &option.data.fistcolor[P1].g, &option.data.fistcolor[P1].b, NULL, NULL,
											   0, 4, 0, 1, 10, 455, 220, 455);

		//---- fistcolor[P2] ----------------------------------------------------------------------

		data_op.oe[oe_fistcolor_p2].fill_entry("Fistcolor P2 RGB", &option.data.fistcolor[P2].r, &option.data.fistcolor[P2].g, &option.data.fistcolor[P2].b, NULL, NULL,
											   0, 4, 0, 1, 10, 475, 220, 475);

		//---- left_p1 ---------------------------------------------------------------------------

		data_op.oe[oe_left_p1].fill_entry("Left P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1LEFT]),
										  0, 3, 0, 1, 410, 315, 530, 315);

		//---- right_p1 --------------------------------------------------------------------------

		data_op.oe[oe_right_p1].fill_entry("Right P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1RIGHT]),
										   0, 3, 0, 1, 410, 335, 530, 335);

		//---- punch_p1 --------------------------------------------------------------------------

		data_op.oe[oe_punch_p1].fill_entry("Punch P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1PUNCH]),
										   0, 3, 0, 1, 410, 355, 530, 355);

		//---- kick_p1 ---------------------------------------------------------------------------

		data_op.oe[oe_kick_p1].fill_entry("Kick P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1KICK]),
										  0, 3, 0, 1, 410, 375, 530, 375);

		//---- defend_p1 -------------------------------------------------------------------------

		data_op.oe[oe_defend_p1].fill_entry("Def P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1DEFEND]),
											0, 3, 0, 1, 410, 395, 530, 395);

		//---- special_p1 ------------------------------------------------------------------------

		data_op.oe[oe_special_p1].fill_entry("Spec P1", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP1SPECIAL]),
											 0, 3, 0, 1, 410, 415, 530, 415);

		//---- left_p2 ---------------------------------------------------------------------------

		data_op.oe[oe_left_p2].fill_entry("Left P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2LEFT]),
										  0, 3, 0, 1, 600, 315, 720, 315);

		//---- right_p2 --------------------------------------------------------------------------

		data_op.oe[oe_right_p2].fill_entry("Right P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2RIGHT]),
										   0, 3, 0, 1, 600, 335, 720, 335);

		//---- punch_p2 --------------------------------------------------------------------------

		data_op.oe[oe_punch_p2].fill_entry("Punch P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2PUNCH]),
										   0, 3, 0, 1, 600, 355, 720, 355);

		//---- kick_p2 ---------------------------------------------------------------------------

		data_op.oe[oe_kick_p2].fill_entry("Kick P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2KICK]),
										  0, 3, 0, 1, 600, 375, 720, 375);

		//---- defend_p2 -------------------------------------------------------------------------

		data_op.oe[oe_defend_p2].fill_entry("Def P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2DEFEND]),
											0, 3, 0, 1, 600, 395, 720, 395);

		//---- special_p2 ------------------------------------------------------------------------

		data_op.oe[oe_special_p2].fill_entry("Spec P2", NULL, NULL, NULL, NULL, getinput_char(option.data.CBT[cP2SPECIAL]),
											 0, 3, 0, 1, 600, 415, 720, 415);

		//---- default ---------------------------------------------------------------------------

		data_op.oe[oe_def].fill_entry("DEFAULT", NULL, NULL, NULL, NULL, NULL,
									  0, -1, 0, 1, 410, 455, 0, 0);

		//---- credits ---------------------------------------------------------------------------

		data_op.oe[oe_credits].fill_entry("CREDITS", NULL, NULL, NULL, NULL, NULL,
										  0, -1, 0, 1, 410, 475, 0, 0);

		//---- done ------------------------------------------------------------------------------

		data_op.oe[oe_done].fill_entry("DONE", NULL, NULL, NULL, NULL, NULL,
									   0, -1, 0, 1, 410, 495, 0, 0);

		//draw all option entries
		draw_option_entries(data_op.oe);

		//show it
		dd.flip(option.data.vsync);

		//fade in from white
		dd.gamma_fade(1, 1, 0.5f);

		//reset timer
		time.get_tfr();
		time.sca = 0.0f;

		//set mouse cursor selection areas
		fillRECT(data_op.c_selection[oe_sound], 267, 87, 307, 107);
		fillRECT(data_op.c_selection[oe_vsync], 355, 425, 450, 445);
		fillRECT(data_op.c_selection[oe_fps_max], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_show_fps], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_shadows], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_mblur], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_bw_mode], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_cbackground], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_subframes], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_rounds], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_speed], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_damage], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_fom], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_name_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_name_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_fistcolor_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_fistcolor_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_left_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_right_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_punch_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_kick_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_defend_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_special_p1], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_left_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_right_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_punch_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_kick_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_defend_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_special_p2], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_def], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_credits], 355, 450, 415, 475);
		fillRECT(data_op.c_selection[oe_done], 355, 450, 415, 475);
		//set cursor pos
		mcursor[0].set_pos(345, 90);
	}

	//---- idling --------------------------------------------------------------------------------

	if (data_op.state == 1)
	{
		//draw background
		dd.drawbackground(option.data.cbackground.r,
						  option.data.cbackground.g,
						  option.data.cbackground.b);

		//draw lines
		RGBcolor		temp_c;
		line l1(0, 299, 799, 299),	l2(399, 75, 399, 524);
		dd.drawline(l1, temp_c);	dd.drawline(l2, temp_c);

		//calculate and draw yinyang if shadows on
		if (option.data.shadows == 1)
		{
			//draw yinyang from title (data_ti) but different position
			data_op.yy.set_position(400, 300);

			//decrease angle by 45 degrees/second times user speed
			data_ti.yy.angle -= (float)(45 * time.sca * option.data.speed);
			data_ti.yy.check_angle();

			//lighter colors
			RGBcolor ycyi, ycya;
			ycyi.setcolor(255 - option.data.cbackground.r, 255 - option.data.cbackground.g, 255 - option.data.cbackground.b);
			ycya.setcolor(option.data.cbackground.r, option.data.cbackground.g, option.data.cbackground.b);
			data_ti.yy.set_colors(ycyi, ycya);

			//calculate yinyang symbol
			//data_ti.yy.calculate();

			//draw yinyang symbol
			dd.drawyinyang(data_ti.yy);
		}

		//draw all option entries
		draw_option_entries(data_op.oe);

		//mouse cursor
		process_mousecursor(option.data.shadows);
	}


//-------------------------------------------------------------------------------------------------
	//---- idling --------------------------------------------------------------------------------
//old test
//	if (data_op.state == 1)
	if (false)
	{
		//draw background
		dd.drawbackground(option.data.cbackground.r,
						  option.data.cbackground.g,
						  option.data.cbackground.b);

		//draw lines
		RGBcolor		temp_c;
		line l1(0, 299, 799, 299),	l2(399, 75, 399, 524);
		dd.drawline(l1, temp_c);	dd.drawline(l2, temp_c);

		//calculate and draw yinyang if shadows on
		if (option.data.shadows == 1)
		{
			//draw yinyang from title (data_ti) but different position
			data_op.yy.set_position(400, 300);

			//decrease angle by 45 degrees/second times user speed
			data_ti.yy.angle -= (float)(45 * time.sca * option.data.speed);
			data_ti.yy.check_angle();

			//lighter colors
			RGBcolor ycyi, ycya;
			ycyi.setcolor(255 - option.data.cbackground.r, 255 - option.data.cbackground.g, 255 - option.data.cbackground.b);
			ycya.setcolor(option.data.cbackground.r, option.data.cbackground.g, option.data.cbackground.b);
			data_ti.yy.set_colors(ycyi, ycya);

			//calculate yinyang symbol
			//data_ti.yy.calculate();

			//draw yinyang symbol
			dd.drawyinyang(data_ti.yy);
		}

		//draw all option entries
//		draw_option_entries(data_op.oe);

		if (true)
		{
			//spalten, zeilen
			//x, y
			static int slot[4][20] = {0};
			ipoint slot_pos[4][20]	= {0};
			for (register int x = 0; x < 4; ++x)
				for (register int y = 0; y < 20; ++y)
				{
					slot_pos[x][y].x = x * 200 + 10;
					slot_pos[x][y].y = y * 20 + 90;
					if (y > 9)
						slot_pos[x][y].y = y * 20 + 90 + 20;
				}
			//mouse selection areas
			RECT m_pos[4][20]		= {0};
			for (x = 0; x < 4; ++x)
				for (register int y = 0; y < 20; ++y)
				{
					m_pos[x][y].left	= slot_pos[x][y].x - 8;
					m_pos[x][y].top		= slot_pos[x][y].y - 2;
					m_pos[x][y].right	= m_pos[x][y].left + 180;
					m_pos[x][y].bottom	= m_pos[x][y].top + 19;
				}

			static bool set = false;
			const int noo	= 39;
			static option_	opt[noo];
			if (!set)
			{
				set = true;
//				for (register int y = 0; y < 4; ++y)
					for (register int y = 0; y < 20; ++y)
					{
						gf_logger(true, "%i %i	%i %i	%i %i	%i %i",
								  (int)slot_pos[0][y].x, (int)slot_pos[0][y].y,
								  (int)slot_pos[1][y].x, (int)slot_pos[1][y].y,
								  (int)slot_pos[2][y].x, (int)slot_pos[2][y].y,
								  (int)slot_pos[3][y].x, (int)slot_pos[3][y].y);

//						gf_logger(true, "%i/%i	 x = %i		y = %i",
//								  x, y,
//								  (int)slot_pos[y][x].x, (int)slot_pos[y][x].y);
					}

				//---- ini ----
				//on/off
				//off/int
				//rgb
				//int
				//float
				//string
				//input
				//(confirm)

				opt[0].fill_entry(0, 0, "Sound", ODT_INT, OIT_SINGLE, &option.data.sound, &option.dataDEF.sound, &option.dataMIN.sound, &option.dataMAX.sound);
				opt[1].fill_entry(0, 1, "VSync", ODT_INT, OIT_SINGLE, &option.data.vsync, &option.dataDEF.vsync, &option.dataMIN.vsync, &option.dataMAX.vsync);
				opt[2].fill_entry(0, 2, "Maximum FPS", ODT_INT, OIT_SINGLE, &option.data.fps_max, &option.dataDEF.fps_max, &option.dataMIN.fps_max, &option.dataMAX.fps_max);
				opt[3].fill_entry(0, 3, "Show FPS", ODT_INT, OIT_SINGLE, &option.data.show_fps, &option.dataDEF.show_fps, &option.dataMIN.show_fps, &option.dataMAX.show_fps);
				opt[4].fill_entry(0, 5, "Shadows", ODT_INT, OIT_SINGLE, &option.data.shadows, &option.dataDEF.shadows, &option.dataMIN.shadows, &option.dataMAX.shadows);
				opt[5].fill_entry(0, 6, "MotionBlur", ODT_INT, OIT_SINGLE, &option.data.mblur, &option.dataDEF.mblur, &option.dataMIN.mblur, &option.dataMAX.mblur);
				opt[6].fill_entry(0, 7, "Black&White Mode", ODT_INT, OIT_SINGLE, &option.data.bw_mode, &option.dataDEF.bw_mode, &option.dataMIN.bw_mode, &option.dataMAX.bw_mode);
				opt[7].fill_entry(0, 8, "Background RGB", ODT_RGB, OIT_FIVE, &option.data.cbackground, &option.dataDEF.cbackground, &option.dataMIN.cbackground, &option.dataMAX.cbackground);
				opt[8].fill_entry(0, 10, "Rounds", ODT_INT, OIT_SINGLE, &option.data.rounds, &option.dataDEF.rounds, &option.dataMIN.rounds, &option.dataMAX.rounds);
				opt[9].fill_entry(0, 11, "Roundtime", ODT_INT, OIT_SINGLE, &option.data.roundtime, &option.dataDEF.roundtime, &option.dataMIN.roundtime, &option.dataMAX.roundtime);
//				opt[10].fill_entry(0, 12, "Speed", ODT_FLOAT, OIT_PSINGLE, &option.data.speed, &option.dataDEF.speed, &option.dataMIN.speed, &option.dataMAX.speed);
				opt[11].fill_entry(2, 0, "Left P1", ODT_INT, 0, &option.data.CBT[cP1LEFT], &option.dataDEF.CBT[cP1LEFT], &option.dataMIN.CBT[cP1LEFT], &option.dataMAX.CBT[cP1LEFT]);
				opt[12].fill_entry(2, 1, "Right P1", ODT_INT, 0, &option.data.CBT[cP1RIGHT], &option.dataDEF.CBT[cP1RIGHT], &option.dataMIN.CBT[cP1RIGHT], &option.dataMAX.CBT[cP1RIGHT]);
				opt[13].fill_entry(2, 2, "Punch P1", ODT_INT, 0, &option.data.CBT[cP1PUNCH], &option.dataDEF.CBT[cP1PUNCH], &option.dataMIN.CBT[cP1PUNCH], &option.dataMAX.CBT[cP1PUNCH]);
				opt[14].fill_entry(2, 3, "Kick P1", ODT_INT, 0, &option.data.CBT[cP1KICK], &option.dataDEF.CBT[cP1KICK], &option.dataMIN.CBT[cP1KICK], &option.dataMAX.CBT[cP1KICK]);
				opt[15].fill_entry(2, 4, "Defend P1", ODT_INT, 0, &option.data.CBT[cP1DEFEND], &option.dataDEF.CBT[cP1DEFEND], &option.dataMIN.CBT[cP1DEFEND], &option.dataMAX.CBT[cP1DEFEND]);
				opt[16].fill_entry(2, 5, "Special P1", ODT_INT, 0, &option.data.CBT[cP1SPECIAL], &option.dataDEF.CBT[cP1SPECIAL], &option.dataMIN.CBT[cP1SPECIAL], &option.dataMAX.CBT[cP1SPECIAL]);
				opt[17].fill_entry(2, 6, "StanceUp P1", ODT_INT, 0, &option.data.CBT[cP1STANCEUP], &option.dataDEF.CBT[cP1STANCEUP], &option.dataMIN.CBT[cP1STANCEUP], &option.dataMAX.CBT[cP1STANCEUP]);
				opt[18].fill_entry(2, 7, "StanceLo P1", ODT_INT, 0, &option.data.CBT[cP1STANCEDOWN], &option.dataDEF.CBT[cP1STANCEDOWN], &option.dataMIN.CBT[cP1STANCEDOWN], &option.dataMAX.CBT[cP1STANCEDOWN]);
				opt[19].fill_entry(2, 8, "Mouse P1", ODT_INT, OIT_SINGLE, &option.data.player_mouse[P1], &option.dataDEF.player_mouse[P1], &option.dataMIN.player_mouse[P1], &option.dataMAX.player_mouse[P1]);
				opt[20].fill_entry(3, 0, "Left P2", ODT_INT, 0, &option.data.CBT[cP2LEFT], &option.dataDEF.CBT[cP2LEFT], &option.dataMIN.CBT[cP2LEFT], &option.dataMAX.CBT[cP2LEFT]);
				opt[21].fill_entry(3, 1, "Right P2", ODT_INT, 0, &option.data.CBT[cP2RIGHT], &option.dataDEF.CBT[cP2RIGHT], &option.dataMIN.CBT[cP2RIGHT], &option.dataMAX.CBT[cP2RIGHT]);
				opt[22].fill_entry(3, 2, "Punch P2", ODT_INT, 0, &option.data.CBT[cP2PUNCH], &option.dataDEF.CBT[cP2PUNCH], &option.dataMIN.CBT[cP2PUNCH], &option.dataMAX.CBT[cP2PUNCH]);
				opt[23].fill_entry(3, 3, "Kick P2", ODT_INT, 0, &option.data.CBT[cP2KICK], &option.dataDEF.CBT[cP2KICK], &option.dataMIN.CBT[cP2KICK], &option.dataMAX.CBT[cP2KICK]);
				opt[24].fill_entry(3, 4, "Defend P2", ODT_INT, 0, &option.data.CBT[cP2DEFEND], &option.dataDEF.CBT[cP2DEFEND], &option.dataMIN.CBT[cP2DEFEND], &option.dataMAX.CBT[cP2DEFEND]);
				opt[25].fill_entry(3, 5, "Special P2", ODT_INT, 0, &option.data.CBT[cP2SPECIAL], &option.dataDEF.CBT[cP2SPECIAL], &option.dataMIN.CBT[cP2SPECIAL], &option.dataMAX.CBT[cP2SPECIAL]);
				opt[26].fill_entry(3, 6, "StanceUp P2", ODT_INT, 0, &option.data.CBT[cP2STANCEUP], &option.dataDEF.CBT[cP2STANCEUP], &option.dataMIN.CBT[cP2STANCEUP], &option.dataMAX.CBT[cP2STANCEUP]);
				opt[27].fill_entry(3, 7, "StanceLo P2", ODT_INT, 0, &option.data.CBT[cP2STANCEDOWN], &option.dataDEF.CBT[cP2STANCEDOWN], &option.dataMIN.CBT[cP2STANCEDOWN], &option.dataMAX.CBT[cP2STANCEDOWN]);
				opt[28].fill_entry(3, 8, "Mouse P2", ODT_INT, OIT_SINGLE, &option.data.player_mouse[P2], &option.dataDEF.player_mouse[P2], &option.dataMIN.player_mouse[P2], &option.dataMAX.player_mouse[P2]);
				opt[29].fill_entry(2, 10, "Name P1", ODT_CHAR, 0, &option.data.name[P1], &option.dataDEF.name[P1], &option.dataMIN.name[P1], &option.dataMAX.name[P1]);
				opt[30].fill_entry(2, 11, "Name P2", ODT_CHAR, 0, &option.data.name[P2], &option.dataDEF.name[P2], &option.dataMIN.name[P2], &option.dataMAX.name[P2]);
				opt[31].fill_entry(2, 12, "Fistcolor P1 RGB", ODT_RGB, OIT_FIVE, &option.data.fistcolor[P1], &option.dataDEF.fistcolor[P1], &option.dataMIN.fistcolor[P1], &option.dataMAX.fistcolor[P1]);
				opt[32].fill_entry(2, 13, "Fistcolor P2 RGB", ODT_RGB, OIT_FIVE, &option.data.fistcolor[P2], &option.dataDEF.fistcolor[P2], &option.dataMIN.fistcolor[P2], &option.dataMAX.fistcolor[P2]);
				opt[33].fill_entry(2, 15, "Subframes", ODT_INT, OIT_SINGLE, &option.data.subframes, &option.dataDEF.subframes, &option.dataMIN.subframes, &option.dataMAX.subframes);
//				opt[34].fill_entry(2, 16, "Damage Multiplier", ODT_FLOAT, OIT_PSINGLE, &option.data.damage_multiplier, &option.dataDEF.damage_multiplier, &option.dataMIN.damage_multiplier, &option.dataMAX.damage_multiplier);
//				opt[35].fill_entry(2, 17, "Fatigue Multiplier", ODT_FLOAT, OIT_PSINGLE, &option.data.fom_multiplier, &option.dataDEF.fom_multiplier, &option.dataMIN.fom_multiplier, &option.dataMAX.fom_multiplier);
				opt[36].fill_entry(3, 19, "DONE", ODT_INT, 0, NULL, NULL, NULL, NULL);
				opt[37].fill_entry(2, 19, "DEFAULT", ODT_INT, 0, NULL, NULL, NULL, NULL);
				opt[38].fill_entry(1, 19, "CREDITS", ODT_INT, 0, NULL, NULL, NULL, NULL);

				slot[0][0]	= 1;	slot[1][0]	= 0;	slot[2][0]	= 1;	slot[3][0]	= 1;
				slot[0][1]	= 1;	slot[1][1]	= 0;	slot[2][1]	= 1;	slot[3][1]	= 1;
				slot[0][2]	= 1;	slot[1][2]	= 0;	slot[2][2]	= 1;	slot[3][2]	= 1;
				slot[0][3]	= 1;	slot[1][3]	= 0;	slot[2][3]	= 1;	slot[3][3]	= 1;
				slot[0][4]	= 0;	slot[1][4]	= 0;	slot[2][4]	= 1;	slot[3][4]	= 1;
				slot[0][5]	= 1;	slot[1][5]	= 0;	slot[2][5]	= 1;	slot[3][5]	= 1;
				slot[0][6]	= 1;	slot[1][6]	= 0;	slot[2][6]	= 1;	slot[3][6]	= 1;
				slot[0][7]	= 1;	slot[1][7]	= 0;	slot[2][7]	= 1;	slot[3][7]	= 1;
				slot[0][8]	= 1;	slot[1][8]	= 0;	slot[2][8]	= 1;	slot[3][8]	= 1;
				slot[0][9]	= 0;	slot[1][9]	= 0;	slot[2][9]	= 0;	slot[3][9]	= 0;
				slot[0][10]	= 1;	slot[1][10]	= 0;	slot[2][10]	= 1;	slot[3][10]	= 0;
				slot[0][11]	= 1;	slot[1][11]	= 0;	slot[2][11]	= 1;	slot[3][11]	= 0;
				slot[0][12]	= 1;	slot[1][12]	= 0;	slot[2][12]	= 1;	slot[3][12]	= 0;
				slot[0][13]	= 0;	slot[1][13]	= 0;	slot[2][13]	= 1;	slot[3][13]	= 0;
				slot[0][14]	= 0;	slot[1][14]	= 0;	slot[2][14]	= 0;	slot[3][14]	= 0;
				slot[0][15]	= 0;	slot[1][15]	= 0;	slot[2][15]	= 1;	slot[3][15]	= 0;
				slot[0][16]	= 0;	slot[1][16]	= 0;	slot[2][16]	= 1;	slot[3][16]	= 0;
				slot[0][17]	= 0;	slot[1][17]	= 0;	slot[2][17]	= 1;	slot[3][17]	= 0;
				slot[0][18]	= 0;	slot[1][18]	= 0;	slot[2][18]	= 0;	slot[3][18]	= 0;
				slot[0][19]	= 0;	slot[1][19]	= 1;	slot[2][19]	= 1;	slot[3][19]	= 1;

				if (false)
				for (register int e = 0; e < noo; ++e)
					if (opt[e].qualifier != NULL)
					{
						gf_logger(true, "%s %i %i", opt[e].qualifier, opt[e].slot.x, opt[e].slot.y);
						if (opt[e].p_data != NULL)
						{
							if (opt[e].d_type == ODT_INT)		gf_logger(true, "%i", *(int*)opt[e].p_data);
							if (opt[e].d_type == ODT_FLOAT)		gf_logger(true, "%.1f", *(float*)opt[e].p_data);
							if (opt[e].d_type == ODT_RGB)		gf_logger(true, "%i", *(int*)opt[e].p_data);
							if (opt[e].d_type == ODT_CHAR)		gf_logger(true, "%s", (char*)opt[e].p_data);
						}
					}
			}

			static ipoint selection;
			if (data_op.last_input == 0 && (selection.x == -1 || selection.y == -1))
				selection.setpoint(0, 0);
ipoint scope(1, 9);
			if (is.key1D(DIK_LEFT))
			{
				data_op.last_input	= 0;
//----
				if (selection.x > 0)	--selection.x;
				else
				{
					selection.x = 3;
//					if (selection.y > 0)		--selection.y;
//					else						selection.y = 19;
				}
				//new slot empty
				while (slot[selection.x][selection.y] == 0)
				{
					for (int i = 0; i < scope.y; ++i)
					{
						if (selection.y - i >= 0)
						{
							if (slot[selection.x][selection.y - i] != 0)
							{
								selection.y = selection.y - i;
								break;
							}
						}
						if (selection.y + i <= 19)
						{
							if (slot[selection.x][selection.y + i] != 0)
							{
								selection.y = selection.y + i;
								break;
							}
						}
					}
					if (slot[selection.x][selection.y] == 0)
					{
						if (selection.x > 0)	--selection.x;
						else					selection.x = 3;
					}
				}
//----
/*				while (slot[selection.x][selection.y] == 0)
				{
					if (selection.x > 0)	--selection.x;
					else
					{
						selection.x = 3;
						if (selection.y > 0)		--selection.y;
						else						selection.y = 19;
					}
				}*/
/*				if (slot[selection.x][selection.y] == 0)
				{
					for (int i = 0; i < 4; ++i)
					{
						if (slot[selection.x][selection.y] == 0)
						{
							if (selection.x > 0)	--selection.x;
							else					selection.x = 3;
						}
						else
							break;
					}
				}*/
			}
			if (is.key1D(DIK_RIGHT))
			{
				data_op.last_input	= 0;
				if (selection.x < 3)	++selection.x;
				else
				{
					selection.x = 0;
//					if (selection.y < 19)	++selection.y;
//					else					selection.y = 0;
				}
				while (slot[selection.x][selection.y] == 0)
				{
					//for complete row
//					int seln	= selection.y;
//					int selp	= selection.y;
//					int sel = 0;
					for (int i = 0; i < scope.y; ++i)
					{
						if (selection.y - i >= 0)
						{
							if (slot[selection.x][selection.y - i] != 0)
							{
								selection.y = selection.y - i;
								break;
							}
						}
						if (selection.y + i <= 19)
						{
							if (slot[selection.x][selection.y + i] != 0)
							{
								selection.y = selection.y + i;
								break;
							}
						}

/*						seln = selection.y - (i);
						if (seln < 0)	seln = 0;
						if (slot[selection.x][seln] != 0)
						{
							selection.y = seln;
							break;
						}
						selp = selection.y + (i);
						if (selp > 19)	selp = 19;
						if (slot[selection.x][selp] != 0)
						{
							selection.y = selp;
							break;
						}*/
					}
					if (slot[selection.x][selection.y] == 0)
					{
						if (selection.x < 3)	++selection.x;
						else					selection.x = 0;
					}
/*					for (int i = 0; i < 19; ++i)
					{
						selection.y = selection.y - (i + 1);
						if (selection.y < 0)
							selection.y = 19;
						if (slot[selection.x][selection.y] != 0)
							break;
						selection.y = selection.y + (i + 2);
						if (selection.y > 19)
							selection.y = 0;
						if (slot[selection.x][selection.y] != 0)
							break;
					}
					selection.y = 0;*/
				}
/*				if (slot[selection.x][selection.y] == 0)
				{
					for (int i = 0; i < 4; ++i)
					{
						if (slot[selection.x][selection.y] == 0)
						{
							if (selection.x < 3)	++selection.x;
							else					selection.x = 0;
						}
						else
							break;
					}
				}*/
			}
			if (is.key1D(DIK_UP))
			{
				data_op.last_input	= 0;
				if (selection.y > 0)		--selection.y;
				else
				{
					selection.y = 19;
					if (selection.x > 0)	--selection.x;
					else					selection.x = 3;
				}
				while (slot[selection.x][selection.y] == 0)
				{
					if (selection.y > 0)		--selection.y;
					else
					{
						selection.y = 19;
						if (selection.x > 0)	--selection.x;
						else					selection.x = 3;
					}
				}
/*				if (slot[selection.x][selection.y] == 0)
				{
					for (int i = 0; i < 20; ++i)
					{
						if (slot[selection.x][selection.y] == 0)
						{
							if (selection.y > 0)	--selection.y;
							else					selection.y = 19;
						}
						else
							break;
					}
				}*/
			}
			if (is.key1D(DIK_DOWN))
			{
				data_op.last_input	= 0;
				if (selection.y < 19)	++selection.y;
				else
				{
					selection.y = 0;
					if (selection.x < 3)	++selection.x;
					else					selection.x = 0;
				}
				while (slot[selection.x][selection.y] == 0)
				{
					if (selection.y < 19)	++selection.y;
					else
					{
						selection.y = 0;
						if (selection.x < 3)	++selection.x;
						else					selection.x = 0;
					}
				}
/*				if (slot[selection.x][selection.y] == 0)
				{
					for (int i = 0; i < 20; ++i)
					{
						if (slot[selection.x][selection.y] == 0)
						{
							if (selection.y < 19)	++selection.y;
							else					selection.y = 0;
						}
						else
							break;
					}
				}*/
			}

			if (is.mouse(0, true, true, false))
			{
				bool mc_so	= false;
				for (register int x = 0; x < 4; ++x)
					for (register int y = 0; y < 20; ++y)
						if (hitboxcheck(mcursor[0].r_pos, m_pos[x][y]))
							mc_so = true;
				if (mc_so)
					data_op.last_input = 1;
				else
					if (data_op.last_input == 1)
						selection.setpoint(-1, -1);
			}
			int minfps = 120;
			if (time.fps < 100)
				dd.typebmf(10, 74, bmfblue, "FPS:  %i  [%i, %i] last_input: %i", time.fps, selection.x, selection.y, data_op.last_input);
			else
				dd.typebmf(10, 74, bmfblue, "FPS: %i  [%i, %i] last_input: %i", time.fps, selection.x, selection.y, data_op.last_input);

			rectangle r[4 * 20];
			int selection_xoff = 5;
			//
			for (x = 0; x < 4; ++x)
				for (register int y = 0; y < 20; ++y)
				{
					//mouse selection
					if (hitboxcheck(mcursor[0].r_pos, m_pos[x][y]) && data_op.last_input == 1)
					{
						selection.setpoint(x, y);
					}

/*					if (time.fps < 600)
						if (selection.x == x && selection.y == y)
							dd.typebmf(slot_pos[x][y].x - selection_xoff, slot_pos[x][y].y, bmfred, "SET");
						else
							dd.typebmf(slot_pos[x][y].x, slot_pos[x][y].y, bmfblack, "SET");
					else
						if (selection.x == x && selection.y == y)
							dd.typefont(slot_pos[x][y].x - selection_xoff, slot_pos[x][y].y, "SET", 0, 0, 1, data_op.font_size,
										0, 0, 0, 255, 0, 0);
						else
							dd.typefont(slot_pos[x][y].x, slot_pos[x][y].y, "SET", 0, 0, 1, data_op.font_size,
										0, 0, 0, 0, 255, 0);*/

					if (slot[x][y])
					{
						point p;
						p.x = (float)slot_pos[x][y].x - 5;
						p.y = (float)slot_pos[x][y].y;
						//dd.drawfist((int)slot_pos[x][y].x, (int)slot_pos[x][y].y, red);;
						//dd.drawpoint(p, red);
					}
					r[x + 4 * y]	= m_pos[x][y];
					if (selection.x == x && selection.y == y)
					{
						r[x + 4 * y].p[0].x -= selection_xoff;
						r[x + 4 * y].p[1].x -= selection_xoff;
						r[x + 4 * y].p[2].x -= selection_xoff;
						r[x + 4 * y].p[3].x -= selection_xoff;
						//dd.drawrectangle_uf(r[x + 4 * y], red);
						//dd.drawrectangle_f(r[x + 4 * y], red);
						//dd.typebmf((int)slot_pos[x][y].x - selection_xoff, (int)slot_pos[x][y].y, bmfblack, "SET");
						r[x + 4 * y].fill_rectangle();
					}
				}
			//dd.drawrectangle_array(r, 4 * 20, black);

			//selected option
			int op_select = -1;
			//if valid
			for (register int e = 0; e < noo; ++e)
			{
				if (opt[e].qualifier != NULL)
				{
					ipoint pos;
					pos.setpoint(slot_pos[opt[e].slot.x][opt[e].slot.y].x, slot_pos[opt[e].slot.x][opt[e].slot.y].y);

					//if (time.fps < minfps)
					if (!option.data.shadows)
						if (opt[e].slot.x == selection.x && opt[e].slot.y == selection.y)
						{
							op_select = e;
							dd.typebmf(pos.x - selection_xoff, pos.y, bmfred, opt[e].qualifier);
						}
						else
							dd.typebmf(pos.x, pos.y, bmfblack, opt[e].qualifier);
					else
						if (opt[e].slot.x == selection.x && opt[e].slot.y == selection.y)
						{
							op_select = e;
							dd.typefont(pos.x - selection_xoff, pos.y, opt[e].qualifier, 0, 0, 1, data_op.font_size,
										0, 0, 0, 255, 0, 0);
						}
						else
							dd.typefont(pos.x, pos.y, opt[e].qualifier, 0, 0, 1, data_op.font_size,
										0, 0, 0, 0, 255, 0);

					//data valid
					if (opt[e].p_data != NULL)
					{
						int offsetx = 0;
						if ((opt[e].slot.x == 2 || opt[e].slot.x == 3) &&
							opt[e].slot.y <= 9)
							offsetx = 150;
						else
							offsetx = 200;
						//if (time.fps < minfps)
						if (!option.data.shadows)
						{
							if (opt[e].d_type == ODT_INT)		dd.typebmf(pos.x + offsetx, pos.y, bmfblack, "%i", *(int*)opt[e].p_data);
							if (opt[e].d_type == ODT_FLOAT)		dd.typebmf(pos.x + offsetx, pos.y, bmfblack, "%.1f", *(float*)opt[e].p_data);
							if (opt[e].d_type == ODT_RGB)		dd.typebmf(pos.x + offsetx, pos.y, bmfblack, "%i %i %i", ((int*)opt[e].p_data)[0], ((int*)opt[e].p_data)[1], ((int*)opt[e].p_data)[2]);
							if (opt[e].d_type == ODT_CHAR)		dd.typebmf(pos.x + offsetx, pos.y, bmfblack, "%s", (char*)opt[e].p_data);
						}
						else
						{
							if (opt[e].d_type == ODT_INT)		dd.typeSLF(pos.x + offsetx, pos.y, 0, 0, 0, 0, 255, 0, data_op.font_size, "%i", *(int*)opt[e].p_data);
							if (opt[e].d_type == ODT_FLOAT)		dd.typeSLF(pos.x + offsetx, pos.y, 0, 0, 0, 0, 255, 0, data_op.font_size, "%.1f", *(float*)opt[e].p_data);
							if (opt[e].d_type == ODT_RGB)		dd.typeSLF(pos.x + offsetx, pos.y, 0, 0, 0, 0, 255, 0, data_op.font_size, "%i %i %i", ((int*)opt[e].p_data)[0], ((int*)opt[e].p_data)[1], ((int*)opt[e].p_data)[2]);
							if (opt[e].d_type == ODT_CHAR)		dd.typeSLF(pos.x + offsetx, pos.y, 0, 0, 0, 0, 255, 0, data_op.font_size, "%s", (char*)opt[e].p_data);
						}
					}
				}
			}

			if (op_select != -1)
			{
				if (is.dimouse1D[0].rgbButtons[0] & 0x80)
					//!! opt selection
					if (opt[op_select].increase_data())
					{
						ds.setfrequency(BT_SYS, S_MSELECT, 1.5f);
						playsound_s(S_MSELECT);
						ds.setfrequency(BT_SYS, S_MSELECT, option.data.speed);
					}
					else
						playsound_s(S_MCANCEL);
				if (is.dimouse1D[0].rgbButtons[1] & 0x80)
					//!! opt selection
					if (opt[op_select].decrease_data())
					{
						ds.setfrequency(BT_SYS, S_MSELECT, 0.5f);
						playsound_s(S_MSELECT);
						ds.setfrequency(BT_SYS, S_MSELECT, option.data.speed);
					}
					else
						playsound_s(S_MCANCEL);
			}
		}

		//mouse cursor
		process_mousecursor(option.data.shadows);
	}

	return;

//-------------------------------------------------------------------------------------------------

//draws all option entries for options menu
void draw_option_entries(option_entry oe[]);

//------------------------------------------------------------------------------------------------
//
//	master_frame draw_option_entries
//
//	draws all options menu entries
//
//------------------------------------------------------------------------------------------------

void master_frame::draw_option_entries(option_entry oe[])
{
	//offset to x-position if marked
	int			offset = 0;
	//colors for qualifier and value
	RGBcolor	cq, cv;
	//color schemes for unmarked, marked and inactive
	RGBcolor	cu, cm, ci;
	cq.setcolor(black);
//!!	cu.setcolor(green);
	//192, 192, 255
	//192, 255, 255
	if (option.data.bw_mode)
		cu.setcolor(white);
	else
		cu.setcolor(green);
	cm.setcolor(255, 50, 50);
	ci.setcolor(lightgray);

	//---- color indicators ----------------------------------------------------------------------

	//draw fists with each players color
	dd.drawfist(371, 457, option.data.fistcolor[P1]);
	dd.drawfist(371, 477, option.data.fistcolor[P2]);

	//for every entry
	for (register int i = 0; i < data_op.noe; ++i)
	{
		switch (oe[i].selection)
		{
		//not selected
		case (0):
			{
				//if option available
				if (oe[i].available == 1)
				{
					offset	= 0;		cq	= cu;		cv	= cu;
				}
				else
				{
					offset	= 0;		cq	= ci;		cv	= ci;
				}

				break;
			}

		//qualifier selected
		case (1):
			{
				//if option available
				if (oe[i].available == 1)
				{
					offset	= 5;		cq	= cm;		cv	= cu;
				}
				else
				{
					offset	= 5;		cq	= ci;		cv	= ci;
				}

				break;
			}

		//qualifier and value selected
		case (2):
		case (3):
		case (4):
			{
				offset	= 5;
				cq		= cm;			cv	= cm;

				break;
			}
		}

		//---- qualifier -------------------------------------------------------------------------

		dd.typefont((int)oe[i].pos_q.x - offset, (int)oe[i].pos_q.y,
					oe[i].qualifier, 0, 0, 1, data_op.font_size, 0, 0, 0, cq.r, cq.g, cq.b);

		//---- value -----------------------------------------------------------------------------

		//if value is either on/off convert number into string (ON/OFF)
		if (oe[i].type == 0)
		{
			//on/off type is always int
			dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
//						getstate(*oe[i].i_value[0]), 0, 0, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
						getstate((float)*oe[i].i_value[0]), 0, 0, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
		}

		//if value is either value or off print either value or off
		if (oe[i].type == 1)
		{
			//if data type is integer (cause pointer is not NULL)
			if (oe[i].i_value[0] != NULL)
			{
				//if value is 0 print "OFF", else print value
				if (*oe[i].i_value[0] == 0)
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"OFF", 0, 0, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
				else
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
			}

			//if data type is float (cause pointer is not NULL)
			if (oe[i].f_value != NULL)
			{
				//if value is 0 print "OFF", else print value
				if (*oe[i].f_value == 0)
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"OFF", 0, 0, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
					else
						dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
									"", *oe[i].f_value, oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
			}
		}

		//if value is value only print value (no "OFF")
		if (oe[i].type == 2)
		{
			//if data type is integer (cause pointer is not NULL)
			if (oe[i].i_value[0] != NULL)
				dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
							"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);

			//if data type is float (cause pointer is not NULL)
			if (oe[i].f_value != NULL)
				dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
							"", *oe[i].f_value, oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
		}

		//if value is a string print string
		if (oe[i].type == 3)
		{
			dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
						oe[i].s_value, 0, 0, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);
		}

		//if value is triple integer (only value)
		if (oe[i].type == 4)
		{
			//mark value depending of selection
			switch (oe[i].selection)
			{
			//first marked
			case (2):
				{
					//first value
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cm.r, cm.g, cm.b);

					//second value
					dd.typefont((int)oe[i].pos_v.x + 50, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[1], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					//third value
					dd.typefont((int)oe[i].pos_v.x + 100, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[2], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					break;
				}

			//second marked
			case (3):
				{
					//first value
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					//second value
					dd.typefont((int)oe[i].pos_v.x + 50, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[1], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cm.r, cm.g, cm.b);

					//third value
					dd.typefont((int)oe[i].pos_v.x + 100, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[2], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					break;
				}

			//third marked
			case (4):
				{
					//first value
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					//second value
					dd.typefont((int)oe[i].pos_v.x + 50, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[1], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cu.r, cu.g, cu.b);

					//third value
					dd.typefont((int)oe[i].pos_v.x + 100, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[2], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cm.r, cm.g, cm.b);

					break;
				}

			//not marked/not available
			default:
				{
					//first value
					dd.typefont((int)oe[i].pos_v.x, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[0], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);

					//second value
					dd.typefont((int)oe[i].pos_v.x + 50, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[1], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);

					//third value
					dd.typefont((int)oe[i].pos_v.x + 100, (int)oe[i].pos_v.y,
								"", *oe[i].i_value[2], oe[i].precision, 1, data_op.font_size, 0, 0, 0, cv.r, cv.g, cv.b);

					break;
				}
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	option_entry
//
//	defines option entry in options menu
//
//------------------------------------------------------------------------------------------------

struct option_entry
{
	char					*qualifier;		//name of option
	int						*i_value[3];	//pointers to value if option is integer
											//(up to three values per option entry)
	float					*f_value;		//pointer to value if option is float
	char					*s_value;		//pointer to string
	int						precision;		//precision of value

	int						type;			//-1 = system (default, credits, exit)
											//0 = on/off
											//1 = value/off
											//2 = value
											//3 = string
											//4 = triple value

	BYTE					selection;		//0 = not selected
											//1 = qualifier selected
											//2 = qualifier and first value selected
											//3 = qualifier and second value selected
											//4 = qualifier and third value selected

	BYTE					available;		//0 = no, 1 = yes

	point					pos_q;			//position of qualifier
	point					pos_v;			//position of value (if entry has more than one
											//value, the positions of the other values get
											//an automatic offset)

	//---- constructor ---------------------------------------------------------------------------

	option_entry()
	{
		qualifier			= NULL;
	
		i_value[0]			= NULL;
		i_value[1]			= NULL;
		i_value[2]			= NULL;
		f_value				= NULL;
		s_value				= NULL;

		precision			= 0;
		type				= 0;
		selection			= 0;
		available			= 0;
	};

	//---- fill entry ----------------------------------------------------------------------------
	//fills entry with given data

	void fill_entry(char *qual, int *iv1, int *iv2, int *iv3, float *fv, char *sv,
					int prec, int tpe, BYTE sel, BYTE avl, int pqx, int pqy, int pvx, int pvy)
	{
		qualifier		= qual;

		i_value[0]		= iv1;
		i_value[1]		= iv2;
		i_value[2]		= iv3;
		f_value			= fv;
		s_value			= sv;

		precision		= prec;
		type			= tpe;

		selection		= sel;
		available		= avl;

		pos_q.x			= (float)pqx;
		pos_q.y			= (float)pqy;
		pos_v.x			= (float)pvx;
		pos_v.y			= (float)pvy;
	};
};

//------------------------------------------------------------------------------------------------
//
//	option_ (slot test)
//
//------------------------------------------------------------------------------------------------

struct option_
{
	ipoint					slot;			//slot(!) position in options menue
	ipoint					data_offset;	//data offset as x, y coordinates
											//default:
	int						selection;		//0 = not selected
											//1 = qualifier selected
											//2 = qualifier and first value selected
											//3 = qualifier and second value selected
											//4 = qualifier and third value selected
	int						available;		//0 = no, 1 = yes

	char					*qualifier;		//displayed name of option

	void					*p_data;		//pointer to option data, default, min and max
	void					*p_dataDEF;
	void					*p_dataMIN;
	void					*p_dataMAX;

	int						o_type;			//option type, defined
	int						d_type;			//data type, defined
	int						inc_type;		//data incrementation type, defined

	//---- constructor ---------------------------------------------------------------------------

	option_()
	{
		qualifier			= NULL;

		p_data				= NULL;
		p_dataDEF			= NULL;
		p_dataMIN			= NULL;
		p_dataMAX			= NULL;

		d_type				= 0;
		inc_type			= 0;
	};

	//---- fill entry ----------------------------------------------------------------------------
	//fills entry with given data

	void fill_entry(int sx, int sy, char *qual,
					int dtype, int itype, void *pd, void *pddef, void *pdmin, void *pdmax)
	{
		slot.x			= sx;
		slot.y			= sy;

		qualifier		= qual;

		d_type			= dtype;
		inc_type		= itype;

		//data pointer
		p_data			= pd;
		p_dataDEF		= pddef;
		p_dataMIN		= pdmin;
		p_dataMAX		= pdmax;

	};

	//---- enter subselection --------------------------------------------------------------------

	//---- exit subselection ---------------------------------------------------------------------

	//---- increase data -------------------------------------------------------------------------

//(subselection) quatsch, die subselection bei der auswahl im entry setzen und hier
//dann die entsprechende subselection, falls verfuegbar, aendern

	bool increase_data()
	{
		if (p_data == NULL || p_dataDEF == NULL || p_dataMIN == NULL || p_dataMAX == NULL)
			return(false);

		//!! subseleciton (rgb)
		if (d_type == ODT_INT || d_type == ODT_RGB)
		{
			int *pd		= (int*)p_data;
			int *pdDEF	= (int*)p_dataDEF;
			int *pdMIN	= (int*)p_dataMIN;
			int *pdMAX	= (int*)p_dataMAX;

			//incrementation type
			int inc		= 0;
			if (inc_type == OIT_SINGLE)		inc = 1;
			if (inc_type == OIT_FIVE)		inc = 5;
			if (inc_type == OIT_TEN)		inc = 10;

			if (*pd + inc <= *pdMAX)	*pd += inc;
			else						*pd = *pdMIN;

			return(true);
		}

		if (d_type == ODT_FLOAT)
		{
			float *pd		= (float*)p_data;
			float *pdDEF	= (float*)p_dataDEF;
			float *pdMIN	= (float*)p_dataMIN;
			float *pdMAX	= (float*)p_dataMAX;

			//incrementation type
			float inc		= 0;
			if (inc_type == OIT_PSINGLE)	inc = 0.1f;
			if (inc_type == OIT_PFIVE)		inc = 0.5f;
			if (inc_type == OIT_PTEN)		inc = 1.0f;

			if (*pd + inc <= *pdMAX)	*pd += inc;
			else						*pd = *pdMIN;

			return(true);
		}

		return(false);
	};

	//---- decrease data -------------------------------------------------------------------------

	bool decrease_data()
	{
		if (p_data == NULL || p_dataDEF == NULL || p_dataMIN == NULL || p_dataMAX == NULL)
			return(false);

		//!! subselection
		if (d_type == ODT_INT || d_type == ODT_RGB)
		{
			int *pd		= (int*)p_data;
			int *pdDEF	= (int*)p_dataDEF;
			int *pdMIN	= (int*)p_dataMIN;
			int *pdMAX	= (int*)p_dataMAX;

			//incrementation type
			int inc		= 0;
			if (inc_type == OIT_SINGLE)		inc = 1;
			if (inc_type == OIT_FIVE)		inc = 5;
			if (inc_type == OIT_TEN)		inc = 10;

			if (*pd - inc >= *pdMIN)	*pd -= inc;
			else						*pd = *pdMAX;

			return(true);
		}

		if (d_type == ODT_FLOAT)
		{
			float *pd		= (float*)p_data;
			float *pdDEF	= (float*)p_dataDEF;
			float *pdMIN	= (float*)p_dataMIN;
			float *pdMAX	= (float*)p_dataMAX;

			//incrementation type
			float inc		= 0;
			if (inc_type == OIT_PSINGLE)	inc = 0.1f;
			if (inc_type == OIT_PFIVE)		inc = 0.5f;
			if (inc_type == OIT_PTEN)		inc = 1.0f;

			if (*pd - inc >= *pdMIN)	*pd -= inc;
			else						*pd = *pdMAX;

			return(true);
		}

		return(false);
	};
};

	/*
		how to add entry:
		- increase NOOE
		- add entry in op_entry (order!)
		- initialize option_entry (fill_entry)
		- adjust up/down (value change), left/right (selection change), enter
	*/


	//---- old mouse cursor process ---------------------------------------------------------------
	//---------------------------------------------------------------------------------------------

	//apply input mouse data (system mouse)
	//not if button is pressed
	//if (!is.mouseALL())
	{
		cursor_pos.x += is.dimouse[0].lX;
		cursor_pos.y += is.dimouse[0].lY;
	}

	//cursor screen limits
	if (cursor_pos.x < 0)		cursor_pos.x = 0;
	if (cursor_pos.x > 799)		cursor_pos.x = 799;
	if (cursor_pos.y < 75)		cursor_pos.y = 75;
	if (cursor_pos.y > 525)		cursor_pos.y = 525;

	//cursortip as RECT
	fillRECT(cursor_pos_rect, (int)cursor_pos.x, (int)cursor_pos.y, (int)cursor_pos.x, (int)cursor_pos.y);

	//draw cursor depending on type
	//standard
	if (type == 0)
	{
		//offscreen surface bitmap
		//fillRECT(cursor_off, 0, 140, 11, 159);
		fillRECT(cursor_off, 780, 0, 791, 19);

		//onscreen cursor
		fillRECT(cursor_scr, (int)cursor_pos.x, (int)cursor_pos.y,
							 (int)cursor_pos.x + 11, (int)cursor_pos.y + 19);

		//draw
		dd.blitrect(dd.rSCREEN169, cursor_off, cursor_scr);
	}

	//fist
	if (type == 2)
	{
		//draw
		dd.drawfist((int)cursor_pos.x, (int)cursor_pos.y, red);
	}

	//yinyang
	if (type == 1)
	{
		//fun
/*		static point yy_mvector;
		yy_mvector.y += 50.0f * (float)time.sca;
		if (yy_mvector.x > 0)	yy_mvector.x *= 0.99f;// * (float)time.sca;
		if (yy_mvector.x < 0)	yy_mvector.x *= 0.99f;// * (float)time.sca;
		if (yy_mvector.y > 0)	yy_mvector.y *= 0.99f;// * (float)time.sca;
		if (yy_mvector.y < 0)	yy_mvector.y *= 0.99f;// * (float)time.sca;
		if (is.dimouse[0].lX)
			yy_mvector.x += is.dimouse[0].lX * 0.1f;
		if (is.dimouse[0].lY)
			yy_mvector.y += is.dimouse[0].lY * 0.1f;
		cursor_pos.x += yy_mvector.x;
		cursor_pos.y += yy_mvector.y;
		if (cursor_pos.x < 0)		yy_mvector.x = -yy_mvector.x * .9f;
		if (cursor_pos.x > 799)		yy_mvector.x = -yy_mvector.x * .9f;
		if (cursor_pos.y < 75)		yy_mvector.y = -yy_mvector.y * .9f;
		if (cursor_pos.y > 525)		yy_mvector.y = -yy_mvector.y * .9f;
		dd.typebmf(50, 400, bmfblack, "%.2f, %.2f", yy_mvector.x, yy_mvector.y);*/

		//as rotating yinyang sybmol
		color				ydark		= black;
		color				ylight		= white;

		//speed equal to mouse movement
		mc_yy_speed += (is.dimouse[0].lX + is.dimouse[0].lY) * 1.2f;

//!! in cursor struct
//mcursor[P1].yy.speed += (is.dimouse[0].lX + is.dimouse[0].lY) * 1.2f;

		//slowly decrease rotating speed
		if (mc_yy_speed > 45)		mc_yy_speed -= 50.0f * (float)time.sca;
		if (mc_yy_speed < -45)		mc_yy_speed += 50.0f * (float)time.sca;
		//but increase if slower than |45|
		if (mc_yy_speed < 45 && mc_yy_speed >= 0)		mc_yy_speed += 10.0f * (float)time.sca;
		if (mc_yy_speed > -45 && mc_yy_speed <= 0)		mc_yy_speed -= 10.0f * (float)time.sca;

		//speed limit
		if (mc_yy_speed > 4000.0f)		mc_yy_speed = 4000.0f;
		if (mc_yy_speed < -4000.0f)		mc_yy_speed = -4000.0f;

		//stop on (main) button press
		if (is.dimouse[0].rgbButtons[0] & 0x80 ||
			is.dimouse[0].rgbButtons[1] & 0x80)
		{
			mc_yy_speed	= 0;
			//color change
			ydark		= red;
			ylight		= white;

			//change size with mousewheel
			if (is.dimouse[0].lZ > 0)		mc_yy_size += 0.025f;
			if (is.dimouse[0].lZ < 0)		mc_yy_size -= 0.025f;

			//size limit
			if (mc_yy_size > 2.0f)		mc_yy_size = 2.0f;
			if (mc_yy_size < 0)			mc_yy_size = 0;
		}
		else
		{
			//reset data
			mc_yy_size	= 0.075f;
			ydark	= black;
			ylight	= white;
		}

		//rotate
		mc_yy_angle += mc_yy_speed * (float)time.sca;

		//angle limit
		while (mc_yy_angle < 0)		mc_yy_angle += 360;
		while (mc_yy_angle > 360)	mc_yy_angle -= 360;

		//calculate symbol
		//mc_yy.calculate(cursor_pos, mc_yy_angle, mc_yy_size);
		mc_yy.set_position((int)cursor_pos.x, (int)cursor_pos.y);
		mc_yy.set_angle(mc_yy_angle);
		mc_yy.set_size(mc_yy_size);
		//mc_yy.calculate();
		//draw symbol
		mc_yy.set_colors(ydark, ylight);
		dd.drawyinyang(mc_yy);
	}

/*	OLD VERSION
	char		message[101];				//message string
	point		pos;						//position of string
	RGBcolor	b_color;					//border color of message
	RGBcolor	f_color;					//fill color of message
	float		size;						//size of message

	float		time;						//display time of message

	LONGLONG	t_start;					//start time of displaying message
	bool		active;

	//---- constructor ---------------------------------------------------------------------------

	player_message()
	{
		ZeroMemory(&message, sizeof(message));
		size			= 0;
		time			= 0;
		t_start			= 0;
	};

	//---- reset ---------------------------------------------------------------------------------

	void reset()
	{
		message[0]	= 0;
		time		= 0;
		t_start		= 0;
		active		= false;
	};

	//---- set_message ---------------------------------------------------------------------------

	void set_message(char string[101],
					 int br, int bg, int bb,
					 int fr, int fg, int fb,
					 float _size,
					 float _time,
					 LONGLONG _t_curr)
	{
		//for every letter
		for (register int i = 0; i < 101; ++i)
		{
			//copy into message string
			message[i] = string[i];
			if (string[i] == 0)
				i = 101;
		}

		b_color.r	= br;		b_color.g	= bg;		b_color.b	= bb;
		f_color.r	= fr;		f_color.g	= fg;		f_color.b	= fb;

		size		= _size;
		time		= _time;
		t_start		= _t_curr;
	};

	//---- set_message ---------------------------------------------------------------------------
	//formated text

	void set_message(int br, int bg, int bb,
					 int fr, int fg, int fb,
					 float _size,
					 float _time,
					 LONGLONG _t_curr,
					 char *format, ...)
	{
		//---- copy string or number into new buffer -------------------------------------------------

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		//unsigned, else you get negativ values for the LUT
		unsigned char wordstring[101] = "";
		//copy message into buffer
		vsprintf((char *)wordstring, format, ap);

		//clear up
		va_end(ap);

		//----------------------------------------------------------------------------------------

		//for every letter
		for (register int i = 0; i < 101; ++i)
		{
			//copy into message string
			message[i] = wordstring[i];
			if (wordstring[i] == 0)
				i = 101;
		}

		b_color.r	= br;		b_color.g	= bg;		b_color.b	= bb;
		f_color.r	= fr;		f_color.g	= fg;		f_color.b	= fb;

		size		= _size;
		time		= _time;
		t_start		= _t_curr;
	};

	//---- change_format -------------------------------------------------------------------------
	//changes message format if there is a message and returns true, else returns false

	bool change_format(int br, int bg, int bb,
					   int fr, int fg, int fb,
					   float _size = -1)
	{
		//if message
		if (message[0] == 0)
			return(false);

		b_color.r	= br;		b_color.g	= bg;		b_color.b	= bb;
		f_color.r	= fr;		f_color.g	= fg;		f_color.b	= fb;

		if (_size != -1)
			size		= _size;

		return(true);
	};

	//---- update --------------------------------------------------------------------------------

	void update(LONGLONG t_current, LONGLONG t_freq, point _chead)
	{
		//set text position
		pos.y	= _chead.y - 50;
		pos.x	= _chead.x -
				  (strlen(message) * 32.0f * size + (strlen(message) - 1.0f) * 3.0f * size) / 2.0f;

		//if time -1 permanent message
		if (time == -1)
		{
			active		= true;
			return;
		}

		//active state
		if (t_current <= t_start + (t_freq * time))
		{
			active		= true;
		}
		else
		{
			active		= false;
			time		= 0;
			t_start		= 0;
		}
	};

	//---- compare message -----------------------------------------------------------------------
	//returns true if argumented string is message else false

	bool compare_message(char *cmpstring)
	{
		if (!_stricmp(message, cmpstring))
			return(true);
		else
			return(false);
	};*/

////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
//OLD player_message.set_message all parameters
/*	void set_message(int br, int bg, int bb,
					 int fr, int fg, int fb,
					 float _size,
					 float _time,
					 LONGLONG _t_curr,
					 int _colorfading, float _t_colorfade,
					 int _bfr, int _bfg, int _bfb,
					 int _ffr, int _ffg, int _ffb,
					 int _stype, float _t_scroll, float _sspeed,
					 point _chead,
					 char *format, ...)
	{
		//---- copy string or number into new buffer -------------------------------------------------

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		//unsigned, else you get negativ values for the LUT
		unsigned char wordstring[101] = "";
		//copy message into buffer
		vsprintf((char *)wordstring, format, ap);

		//clear up
		va_end(ap);

		//----------------------------------------------------------------------------------------

//!!
//compare strings
char *pc_string = "!";
int del = 0;
int mslot = 0;
for (register int m = 0; m < NPMESSAGES; ++m)
{
	if (pm[m].active)
	{
		//
		if (!strcmp((const char*)wordstring, pc_string) || strstr((const char*)wordstring, pc_string) != NULL)
		{
			reset(m);
			mslot	= m;
			del = 1;
			break;
		}
	}
}

//muss geflagged sein, sonst werden auch zahlen verglichen

///////////////////

if (!del)
	mslot = get_message_slot();
		//get free slot index
//		int mslot = get_message_slot();

		//increase message counter
		++cmessages;

		//----------------------------------------------------------------------------------------

		//for every letter
		for (register int i = 0; i < 101; ++i)
		{
			//copy into message string
			pm[mslot].message[i] = wordstring[i];
			if (wordstring[i] == 0)
				i = 101;
		}

		pm[mslot].b_color.r	= br;		pm[mslot].b_color.g	= bg;		pm[mslot].b_color.b	= bb;
		pm[mslot].f_color.r	= fr;		pm[mslot].f_color.g	= fg;		pm[mslot].f_color.b	= fb;
		pm[mslot].b_color_adj		= pm[mslot].b_color;
		pm[mslot].f_color_adj		= pm[mslot].f_color;

		pm[mslot].size		= _size;
		pm[mslot].time		= _time;
		pm[mslot].t_start	= _t_curr;

		pm[mslot].colorfading		= _colorfading;
		pm[mslot].t_colorfade		= _t_colorfade;
		pm[mslot].b_color_fade.r	= _bfr;		pm[mslot].b_color_fade.g	= _bfg;		pm[mslot].b_color_fade.b	= _bfb;
		pm[mslot].f_color_fade.r	= _ffr;		pm[mslot].f_color_fade.g	= _ffg;		pm[mslot].f_color_fade.b	= _ffb;

		pm[mslot].scrolltype		= _stype;
		pm[mslot].t_scrollswitch	= _t_scroll;
		pm[mslot].scrollspeed		= _sspeed;

		//set original text position
		pm[mslot].opos.y	= _chead.y - 50;
		pm[mslot].opos.x	= _chead.x -
							  (strlen(pm[mslot].message) * 32.0f * pm[mslot].size + (strlen(pm[mslot].message) - 1.0f) * 3.0f * pm[mslot].size) / 2.0f;
		//current pos is original pos
		pm[mslot].cpos		= pm[mslot].opos;

		//activate message
		pm[mslot].active	= true;
	};
*/
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////


//------------------------------------------------------------------------------------------------

			if (hRet == DDERR_INCOMPATIBLEPRIMARY)
				gf_logger(true, "hRet = DDERR_INCOMPATIBLEPRIMARY"); else
			if (hRet == DDERR_INVALIDCAPS)
				gf_logger(true, "hRet = DDERR_INVALIDCAPS"); else
			if (hRet == DDERR_INVALIDPARAMS)
				gf_logger(true, "hRet = DDERR_INVALIDPARAMS"); else
			if (hRet == DDERR_INVALIDPIXELFORMAT)
				gf_logger(true, "hRet = DDERR_INVALIDPIXELFORMAT"); else
			if (hRet == DDERR_NOALPHAHW)
				gf_logger(true, "hRet = DDERR_NOALPHAHW"); else
			if (hRet == DDERR_NOCOOPERATIVELEVELSET)
				gf_logger(true, "hRet = DDERR_NOCOOPERATIVELEVELSET"); else
			if (hRet == DDERR_NODIRECTDRAWHW)
				gf_logger(true, "hRet = DDERR_NODIRECTDRAWHW"); else
			if (hRet == DDERR_NOEMULATION)
				gf_logger(true, "hRet = DDERR_NOEMULATION"); else
			if (hRet == DDERR_NOEXCLUSIVEMODE)
				gf_logger(true, "hRet = DDERR_NOEXCLUSIVEMODE"); else
			if (hRet == DDERR_NOFLIPHW)
				gf_logger(true, "hRet = DDERR_NOFLIPHW"); else
			if (hRet == DDERR_NOMIPMAPHW)
				gf_logger(true, "hRet = DDERR_NOMIPMAPHW"); else
			if (hRet == DDERR_NOOVERLAYHW)
				gf_logger(true, "hRet = DDERR_NOOVERLAYHW"); else
			if (hRet == DDERR_NOZBUFFERHW)
				gf_logger(true, "hRet = DDERR_NOZBUFFERHW"); else
			if (hRet == DDERR_OUTOFMEMORY)
				gf_logger(true, "hRet = DDERR_OUTOFMEMORY"); else
			if (hRet == DDERR_OUTOFVIDEOMEMORY)
				gf_logger(true, "hRet = DDERR_OUTOFVIDEOMEMORY"); else
			if (hRet == DDERR_PRIMARYSURFACEALREADYEXISTS)
				gf_logger(true, "hRet = DDERR_PRIMARYSURFACEALREADYEXISTS"); else
			if (hRet == DDERR_UNSUPPORTEDMODE)
				gf_logger(true, "hRet = DDERR_UNSUPPORTEDMODE"); else
				gf_logger(true, "hRet = Unknown");

//------------------------------------------------------------------------------------------------
			
			//if not locked
	if (!gl_lock.get_lockstate(asi, 0, 0, angle_180[id], 30))
	{
		if (PA[id][AN_JAB] == AS_PRE)
		{
			al_activate_slot(aslot_action, AN_JAB, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
		}
		if (PA[id][AN_JAB] == AS_FINAL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//power jab
			//not while moving or sliding backwards
			if (PA[id][AN_WALK_BWD] != AS_ACTIVE &&
				p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_SLIDE_BWD] &&
				power_attack[0] == 1 &&
				p_time->current <= t_power_attack[0] + p_time->freq * (0.5f / p_option->data.speed))
			{
				//reset power flag data
				power_attack[0]		= power_attack[1]		= 0;
				t_power_attack[0]	= t_power_attack[1]		= 0;
				//set flag in animation
				p_aslot[aslot_action]->power_attack[id]		= 1;
				//sound and player message
				s_set_sound(S_AGA1);
				if (p_option->data.show_pmessages)
					pmessage.set_message("Power JAB!", 0, 0, 0, 0, 255, 0, 0.35f, 1.0f / p_option->data.speed, p_time->current);
			}
		}
	}

	//---- jab hook ------------------------------------------------------------------------------

	//if not locked
	if (!gl_lock.get_lockstate(asi, 0, 1, angle_180[id], 30))
	{
		if (PA[id][AN_JAB] == AS_CONTEXT && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
		{
			//set jab fatigue flag, deactivate jab and activate jab hook
			p_aslot[aslot_action]->gl_fat[id]	= 1;
			al_deactivate_slot(aslot_action);
			al_activate_slot(aslot_action, AN_JAB_HOOK, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}
/*	else
	{
		//if locked cancel hook
		PA[id][AN_JAB]	= AS_CANCEL;
	}*/

	//---- jab cancel ----------------------------------------------------------------------------

	if (PA[id][AN_JAB] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
	{
		//if punch was only in pre-state
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0 &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0)
		{
			//set power kick active
			power_attack[1]			= 1;
			//start time of canceling, bonus valid only for limited amount of time
			t_power_attack[1]		= p_time->current;
		}
		al_deactivate_slot(aslot_action);

//------------------------------------------------------------------------------------------------
	
	static LONGLONG t_lastaction = 0;
	static float	t_nextaction = 2.0f;
	static int		state = 0;
	static int		arch_dist = -1;
	static LONGLONG t_walk_start = 0;
	static int		action = 0;
	static int		fatflag = 0;
	static bool		learning = true;
	static int		rc = 0;
	static int		distance = 0;

//	p_P->pmessage.set_message(0, 0, 0, 0, 255, 0, 0.35f, 0.8f / p_option->data.speed, p_time->current,
//							  "%.1f", *p_P->p_distance);

	if (p_P->fatigue > 50)
	{
		//idle
		state = 0;
		fatflag = 1;
	}
	else
		if (state == 0 && !fatflag)
			state	= 1;

	if (fatflag)
		if (p_P->fatigue < 10)
			fatflag = 0;

/*	if (t_lastaction + (p_time->freq * t_nextaction) <= p_time->current &&
		p_P->fatigue <= 50)
	{
		//get new nextaction
		t_nextaction	= (float)(500 + (rand() % (2500 - 500 + 1)));
		t_nextaction	= t_nextaction / 1000.0f;

		t_lastaction	= p_time->current;

		action = 1;
	}*/

	//walking
	if (state == 1)
	{
		//not initialized
		if (arch_dist == -1)
		{
			//random if learning
			if (learning)
			{
				//arch_dist	= 0 + (rand() % (700 - 0 + 1));
				//get best damage distance and vary from there
				int maxdam		= -1;
				int maxdam_i	= 0;

				for (register int i = 0; i < NBE; ++i)
				{
					if (memory.bot_exp[i].damage > maxdam)
					{
						maxdam		= memory.bot_exp[i].damage;
						maxdam_i	= i;
					}
				}

				if (0 + (rand() % (1 - 0 + 1)))
					arch_dist = memory.bot_exp[maxdam_i].distance + (0 + (rand() % (100 - 0 + 1)));
				else
					arch_dist = memory.bot_exp[maxdam_i].distance - (0 + (rand() % (100 - 0 + 1)));

				if (arch_dist < 0)
					arch_dist = 0;
			}
			else
			{
				int maxdam	= -1;
				arch_dist	= 200;//0 + (rand() % (700 - 0 + 1));
				int dist_min	= memory.bot_exp[0].distance;
				int dist_max	= memory.bot_exp[0].distance;

				for (register int i = 0; i < NBE; ++i)
				{
					if (memory.bot_exp[i].distance < dist_min)
						dist_min	= memory.bot_exp[i].distance;
					if (memory.bot_exp[i].distance > dist_max)
						dist_max	= memory.bot_exp[i].distance;
/*					if (memory.bot_exp[i].damage > maxdam)
					{
						maxdam		= memory.bot_exp[i].damage;
						arch_dist	= memory.bot_exp[i].distance;
					}*/
				}

				arch_dist	= dist_min + (rand() % (dist_max - dist_min + 1));
			}
			//t_walk_start	= p_time->current;
		}

		if ((int)*p_P->p_distance >= arch_dist - 1 &&
			(int)*p_P->p_distance <= arch_dist + 1)
		{
			arch_dist	= -1;

			//time to punch
			state		= 2;
		}

		if ((int)*p_P->p_distance < arch_dist)
		{
			//walk bwd
			p_is->PA[id][AC_WALK_BWD]	= AS_ACTIVE;
			p_is->t_move[id][0]			= 1.0f;//(float)(p_time->current - t_walk_start) / p_time->freq;
		}
		if (p_P->sk.p_ref->v.p[0].x >= 700 ||
			p_P->sk.p_ref->v.p[0].x <= 100)
			arch_dist = -1;

		if ((int)*p_P->p_distance > arch_dist)
		{
			//walk fwd
			p_is->PA[id][AC_WALK_FWD]	= AS_ACTIVE;
			p_is->t_move[id][1]			= 1.0f;//(float)(p_time->current - t_walk_start) / p_time->freq;
		}
	}

//	wenn ereignisflag

//	if (action)
	if (state == 2)
	{
		if (!learning)
		{
			++rc;
			if (rc == NBE)
			{
				learning = true;
				rc = 0;
			}
		}

//		action = 0;
		state = 3;

		//save distance at execution time
		distance = (int)*p_P->p_distance;

		//left
		if (p_P->side == 0)
		{
			p_is->mm_angle[id]		= 0;
			p_is->mm_angle_180[id]	= 90;
		}
		else
		{
			p_is->mm_angle[id]		= 180;
			p_is->mm_angle_180[id]	= 90;
		}

		p_P->al_activate_slot(aslot_action, AN_JAB, p_is->mm_angle[id], p_is->mm_angle_180[id]);
		p_P->p_aslot[aslot_action]->state[id]	= AS_PRE;
		p_is->PA[id][AC_JAB]	= AS_FINAL;

		return;
	}

	if (state == 3)
	{
		if (p_P->p_aslot[aslot_action] == p_P->p_anmn[p_P->asi][AN_IDLE_LO])
		{
			state = 0;

			//save data
			if (learning)
			{
				memory.add_experience(distance, p_P->damage_dealt_last);
				p_P->damage_dealt_last = 0;

				++rc;

				if (rc == NBE)
				{
					rc			= 0;
					learning	= false;
				}
			}
		}
	}

	if (learning)
		p_P->pmessage.set_message(0, 0, 0, 0, 255, 0, 0.35f, 0.8f / p_option->data.speed, p_time->current,
		"LEARNING");
	else
		p_P->pmessage.set_message(0, 0, 0, 255, 0, 0, 0.35f, 0.8f / p_option->data.speed, p_time->current,
		"NOT LEARNING");
	
//------------------------------------------------------------------------------------------------
//
//	bot_experience
//
//	experience of bot
//
//------------------------------------------------------------------------------------------------

struct bot_experience
{
	int						distance;						//(absolute) distance to opponent
	int						damage;							//damage done

	//---- constructor ---------------------------------------------------------------------------

	bot_experience()
	{
		distance			= 0;
		damage				= 0;
	};

	//---- set_experience ------------------------------------------------------------------------

	void set_experience(int _dist, int _dam)
	{
		distance			= _dist;
		damage				= _dam;
	};
};

//------------------------------------------------------------------------------------------------
//
//	bot_memory
//
//	memory of bot
//
//------------------------------------------------------------------------------------------------

#define NBE 5

struct bot_memory
{
	bot_experience			bot_exp[NBE];					//experience

	int						cei;							//current experience index

	//---- constructor ---------------------------------------------------------------------------

	bot_memory()
	{
		ZeroMemory(&bot_exp, sizeof(bot_exp));

		cei					= 0;
	};

	//---- add_experience ------------------------------------------------------------------------

	void add_experience(int _dist, int _dam)
	{
		//first check if same experience already exists
		for (register int i = 0; i < NBE; ++i)
		{
			if (_dist == bot_exp[i].distance &&
				_dam == bot_exp[i].damage)
				return;
		}

		//get experience with lowest value
		int damlow		= bot_exp[0].damage;
		int damlow_i	= 0;

		for (i = 0; i < NBE; ++i)
		{
			if (bot_exp[i].damage < damlow)
			{
				damlow		= bot_exp[i].damage;
				damlow_i	= i;
			}
		}

		//if new experience is lower don't replace
		if (_dam < damlow)
			return;

		//replace experience with lowest value
		bot_exp[damlow_i].set_experience(_dist, _dam);

/*		if (cei < NBE)
		{
			bot_exp[cei].set_experience(_dist, _dam);
			++cei;
		}
		else
		{
			cei = 0;
			bot_exp[cei].set_experience(_dist, _dam);
		}*/
	};
};


/*	//if close together
	if (fabs(P[P1].sk.p_ref->v.p[0].x - P[P2].sk.p_ref->v.p[0].x) < 85)
	{
		//both players
		for (register int p = 0; p < 2; ++p)
		{
			//punch and kick hold
//			if ((is.ui_state1D[p][PUNCH] & 0x80 && is.ui_state[p][KICK] & 0x80) ||
//				(is.ui_state[p][PUNCH] & 0x80 && is.ui_state1D[p][KICK] & 0x80) ||
//				P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_TAP_JAB] ||
//				P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_TAP_CROSS] ||
//				P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_TAP_ARMS] ||
//				P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_TAP_LEG])
			if (P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_PUSH_ARMS])
			{
				//push other player
				P[!p].gl_SetPush(2, 0.3f, 95);

				//push yourself a little (might be cancelled)
				//P[p].gl_SetPush(1, 0.3f, 25);

				//push message
				if (option.data.show_pmessages)
					P[!p].pmessage.set_message("Pushed!", 0, 0, 0, 0, 255, 0, 0.35f, 1.0f / option.data.speed, time.current);
			}
		}
	}*/

/*		//if either player is tapping
		if (P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_TAP_JAB] ||
			P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_TAP_CROSS] ||
			P[P2].p_aslot[aslot_action] == P[P2].p_anmn[P[P2].asi][AN_TAP_JAB] ||
			P[P2].p_aslot[aslot_action] == P[P2].p_anmn[P[P2].asi][AN_TAP_CROSS])
		{
			//push them apart (no canceling)
			P[P1].cd_t_pushhit	=	P[P2].cd_t_pushhit	=	time.current;
			P[P1].cd_push_force	=	P[P2].cd_push_force	=	0.45f;
			P[P1].cd_push_type	=	P[P2].cd_push_type	=	2;

			//push message
			if (P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_TAP_JAB] ||
				P[P1].p_aslot[aslot_action] == P[P1].p_anmn[P[P1].asi][AN_TAP_CROSS])
				P[P2].pmessage.set_message("Pushed!", 0, 0, 0, 0, 255, 0, 0.35f, 1.0f / option.data.speed, time.current);
			else
				P[P1].pmessage.set_message("Pushed!", 0, 0, 0, 0, 255, 0, 0.35f, 1.0f / option.data.speed, time.current);
		}*/
		
/*	//!!

	//!!slot oder fastactivate, anhalten, resetten, fortsetzen (playbackfunktion in ds �berarbeiten)
	//hit-sounds

	void s_activate_sound(int slot,							//anmn slot with sound id
						  int type = 0);					//0 =
															//1 =

	void s_deactivate_sound(int slot, int type = 0);

	void s_set_soundplayback(int slot, int playback);		//-1 = reset*/

dd.typebmf(100, 132, bmfblack, "cki ht %i %i %i %i %i",
		   P[P1].cki[bn], P[P1].cki[btul], P[P1].cki[btur], P[P1].cki[btll], P[P1].cki[btlr]);
dd.typebmf(100, 148, bmfblack, "cki rarm %i %i %i larm %i %i %i",
		   P[P1].cki[bsr], P[P1].cki[baur], P[P1].cki[balr],
		   P[P1].cki[bsl], P[P1].cki[baul], P[P1].cki[ball]);
dd.typebmf(100, 164, bmfblack, "cki rleg %i %i %i %i",
		   P[P1].cki[bhr], P[P1].cki[blur], P[P1].cki[bllr], P[P1].cki[bfr]);
dd.typebmf(100, 180, bmfblack, "cki lleg %i %i %i %i",
		   P[P1].cki[bhl], P[P1].cki[blul], P[P1].cki[blll], P[P1].cki[bfl]);

dd.typebmf(500, 132, bmfblack, "bhi ht %i %i %i %i %i",
		   P[P1].bhi[bn], P[P1].bhi[btul], P[P1].bhi[btur], P[P1].bhi[btll], P[P1].bhi[btlr]);
dd.typebmf(500, 164, bmfblack, "bhi rleg %i %i %i %i",
		   P[P1].bhi[bhr], P[P1].bhi[blur], P[P1].bhi[bllr], P[P1].bhi[bfr]);
dd.typebmf(500, 180, bmfblack, "bhi lleg %i %i %i %i",
		   P[P1].bhi[bhl], P[P1].bhi[blul], P[P1].bhi[blll], P[P1].bhi[bfl]);

dd.typebmf(300, 164, bmfblack, "casi rleg %i %i %i %i",
		   P[P1].casi[bhr], P[P1].casi[blur], P[P1].casi[bllr], P[P1].casi[bfr]);
dd.typebmf(300, 180, bmfblack, "casi lleg %i %i %i %i",
		   P[P1].casi[bhl], P[P1].casi[blul], P[P1].casi[blll], P[P1].casi[bfl]);

/*if (P[P1].p_aslot[P[P1].casi[bhr]] != 0)
	dd.typebmf(300, 164, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[bhr]]->pkf[P[P1].cki[bhr]].state[P1][bhr]);
if (P[P1].p_aslot[P[P1].casi[blur]] != 0)
	dd.typebmf(330, 164, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[blur]]->pkf[P[P1].cki[blur]].state[P1][blur]);
if (P[P1].p_aslot[P[P1].casi[bllr]] != 0)
	dd.typebmf(360, 164, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[bllr]]->pkf[P[P1].cki[bllr]].state[P1][bllr]);
if (P[P1].p_aslot[P[P1].casi[bfr]] != 0)
	dd.typebmf(390, 164, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[bfr]]->pkf[P[P1].cki[bfr]].state[P1][bfr]);
if (P[P1].p_aslot[P[P1].casi[bhl]] != 0)
	dd.typebmf(300, 180, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[bhl]]->pkf[P[P1].cki[bhl]].state[P1][bhl]);
if (P[P1].p_aslot[P[P1].casi[blul]] != 0)
	dd.typebmf(330, 180, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[blul]]->pkf[P[P1].cki[blul]].state[P1][blul]);
if (P[P1].p_aslot[P[P1].casi[blll]] != 0)
	dd.typebmf(360, 180, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[blll]]->pkf[P[P1].cki[blll]].state[P1][blll]);
if (P[P1].p_aslot[P[P1].casi[bfl]] != 0)
	dd.typebmf(390, 180, bmfblack, "%i", P[P1].p_aslot[P[P1].casi[bfl]]->pkf[P[P1].cki[bfl]].state[P1][bfl]);
*/
		//highest priority (for both slots)
		int	hp[2]		= {0};
		//current keyframe index of bone(s) with highest priority
		int cki_p[2]	= {0};

		//for cycle and action slot
if (P[P1].p_aslot[aslot_action] != 0)
{
		for (register int s = 0; s < 2; ++s)
			//get bone with highest priority
			for (b = 0; b < 21; ++b)
				//if bone not hit
				if (P[P1].bhi[b] != 1)
					if (s == aslot_cycle)
					{
						//if (casi[b] == s &&
						//	cki[b] > hp[s])
						//	cki_p[s] = cki[b];
					}
					else
					{
						//if bone belongs to current slot and
						//bones priority is higher than highest registered priority
//						if (P[P1].casi[b] == s &&
//							p_aslot[casi[b]]->priority[b] > hp[s])
//							P[P1].p_aslot[s]->priority[b] > hp[s])
						if (P[P1].casi[b] == s &&
//							p_aslot[casi[b]]->priority[b] > hp[s])
							(P[P1].p_aslot[s]->priority[b] > hp[s] ||
							(P[P1].p_aslot[s]->priority[b] == hp[s] && P[P1].cki[b] > cki_p[s])))
						{
							//get new highest priority
							hp[s]		= P[P1].p_aslot[s]->priority[b];
							//get current keyframe index of bone
							cki_p[s]	= P[P1].cki[b];
						}
					}
}

dd.typebmf(500, 200, bmfblack, "hp[1] %i cki_p[1] %i",
		   hp[1], cki_p[1]);

if (P[P1].p_aslot[aslot_cycle] != 0)
	dd.typebmf(100, 100, bmfblack, "cycle: %i",
			   P[P1].p_aslot[aslot_cycle]->id);
if (P[P1].p_aslot[aslot_action] != 0)
	dd.typebmf(100, 116, bmfblack, "action: %i",
			   P[P1].p_aslot[aslot_action]->id);


if (is.key1D(DIK_R))
{
	int	hi	= bhl;
	P[P1].gl_SetHitBone(hi, 20.0f);
}
if (is.key1D(DIK_F))
{
	int	hi	= blul;
	P[P1].gl_SetHitBone(hi, 20.0f);
	P[P1].gl_SetPush(2, 20.0f / option.data.damage_multiplier / 100.0f * 1.2f, 75);
}
if (is.key1D(DIK_V))
{
	int	hi	= blll;
	P[P1].gl_SetHitBone(hi, 20.0f);
}
if (is.key1D(DIK_B))
{
	int	hi	= bn;
	P[P1].gl_SetHitBone(hi, 20.0f);
}*/






										if (!ycontext_up[p] && !ycontext_do[p])

											/*old logic
										//mirror final angle
										mm_angle[p] = 180 - mm_angle[p];
										//check angle doesn't exceed its limit
										if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										if (mm_angle[p] < 0)		mm_angle[p] += 360;*/
									
//------------------------------------------------------------------------------------------------
//
//	player gl_GetAutoEvade
//
//	returns animation index of evade action depending on opponents attack and attack height
//	called by player::gl_process_input
//
//------------------------------------------------------------------------------------------------

int player::gl_GetAutoEvade()
{
	//opponent jab or cross
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 75)
			return(AN_DUCK);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 75 &&
			p_opp->p_aslot[aslot_action]->angle_180[!id] < 110)
			return(AN_EVADE_HI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 110)
			return(AN_EVADE_MI);
	}

	//opponent jab hook or cross hook
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB_HOOK] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS_HOOK])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 110)
			return(AN_EVADE_HI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 110)
			return(AN_EVADE_MI);
	}

	//opponent kick_fwd or kick_swd
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_FWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_SWD])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 75)
			return(AN_EVADE_HI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 75 &&
			p_opp->p_aslot[aslot_action]->angle_180[!id] < 90)
			return(AN_EVADE_MI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 90)
			return(AN_EVADE_LO);
	}

	//opponent knee
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_KNEE])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 100)
			return(AN_EVADE_MI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 100)
			return(AN_EVADE_LO);
	}

	//default evade
	//!! depening on arm stance?
	return(AN_EVADE_HI);
}


	//---- manual evade --------------------------------------------------------------------------

	if (p_option->data.defense_mode[id] == DM_mTmE ||
		p_option->data.defense_mode[id] == DM_aTmE)
	{
		if (PA[id][AN_DEFEND] == AS_FINAL)
			if (side == SLEFT)
			{
				if (angle[id] >= 225 && angle[id] < 315)
				{
					al_activate_slot(aslot_action, AN_EVADE_HI, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 157 && angle[id] < 225)
				{
					al_activate_slot(aslot_action, AN_EVADE_MI, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 112 && angle[id] < 157)
				{
					al_activate_slot(aslot_action, AN_EVADE_LO, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 45 && angle[id] < 112)
				{
					al_activate_slot(aslot_action, AN_DUCK, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
					//angle for lower walking animation
					angle_180[id]	= 160;
				}
			}
			else
			{
				if (angle[id] >= 225 && angle[id] < 315)
				{
					al_activate_slot(aslot_action, AN_EVADE_HI, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 315 || angle[id] < 23)
				{
					al_activate_slot(aslot_action, AN_EVADE_MI, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 23 && angle[id] < 68)
				{
					al_activate_slot(aslot_action, AN_EVADE_LO, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 68 && angle[id] < 135)
				{
					al_activate_slot(aslot_action, AN_DUCK, 0, 90);
					p_aslot[aslot_action]->ui_valid[id]	= 1;
					//angle for lower walking animation
					angle_180[id]	= 160;
				}
			}
	}
	
	
		//---- stance arms -----------------------------------------------------------------------

		for (p = 0; p < 2; ++p)
		{
			//no other action
			if (mm_button[p] == 0)
			{
				//stanceup/down button
				if (ui_state1D[p][STANCEUP] & 0x80)
				{
					PA[p][AC_STANCE_ARMS]	= -1000;
					break;
				}
				if (ui_state1D[p][STANCEDOWN] & 0x80)
				{
					PA[p][AC_STANCE_ARMS]	= 1000;
					break;
				}

				//!!ui_state[p][LEFT] == 0 && ui_state[p][RIGHT] == 0

				//special button down
				//but not walking
				if (ui_state[p][SPECIAL] & 0x80 &&
					ui_state[p][LEFT] == 0 &&
					ui_state[p][RIGHT] == 0)
				{
					//mouse input
					if (p_option->data.inputdevice[p] == DCD_MOUSE1 ||
						p_option->data.inputdevice[p] == DCD_MOUSE2)
					{
						//y-axis movement
						//int lY	= dimouse[1 + p_option->data.inputdevice[p]].lY;

						//min y threshold
						//if (lY > 5)			PA[p][AC_STANCE_ARMS]	= (lY - 5) * 50;
						//if (lY < -5)		PA[p][AC_STANCE_ARMS]	= (lY + 5) * 50;

						//y-axis movement
						if (dimouse[1 + p_option->data.inputdevice[p]].lY != 0)
						{
							PA[p][AC_STANCE_ARMS]	= dimouse[1 + p_option->data.inputdevice[p]].lY * 50;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}

					//digital controller input
					if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_DIG ||
						p_option->data.inputdevice[p] == DCD_CONTROLLER2_DIG)
					{
						//y-axis movement
						if (dicon[p_option->data.inputdevice[p] - 2].lY != 0)
						{
							//PA[p][AC_STANCE_ARMS]	= dicon[p_option->data.inputdevice[p] - 2].lY;
							if (dicon[p_option->data.inputdevice[p] - 2].lY < 0)
								PA[p][AC_STANCE_ARMS]	= -200;
							if (dicon[p_option->data.inputdevice[p] - 2].lY > 0)
								PA[p][AC_STANCE_ARMS]	= 200;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}

					//analog controller input
					if (p_option->data.inputdevice[p] == DCD_CONTROLLER1_ANA ||
						p_option->data.inputdevice[p] == DCD_CONTROLLER2_ANA)
					{
						//y-axis movement
						if (dicon[p_option->data.inputdevice[p] - 4].lY != 0)
						{
							//PA[p][AC_STANCE_ARMS]	= dicon[p_option->data.inputdevice[p] - 2].lY;
							if (dicon[p_option->data.inputdevice[p] - 4].lY < 0)
								PA[p][AC_STANCE_ARMS]	= -200;
							if (dicon[p_option->data.inputdevice[p] - 4].lY > 0)
								PA[p][AC_STANCE_ARMS]	= 200;
							//halt mouse movement
							//special key has to be released before processing mouse movement
							mm_button_flag[p]		= 6;
						}
					}
				}
			}
		}
		
		//---- pushing ---------------------------------------------------------------------------

/*		//special key plus forward
		if (sip1 == 0)
		{
			if (ui_state[P1][SPECIAL] & 0x80)
			{
				if (p_option->data.inputdevice[P1] == DCD_MOUSE1 ||
					p_option->data.inputdevice[P1] == DCD_MOUSE2)
				{
					if (dimouse[1 + p_option->data.inputdevice[P1]].lX > 10)
						PA[P1][AC_PUSH_ARMS]	= AS_FINAL;
					if (dimouse[1 + p_option->data.inputdevice[P1]].lX < -10)
						PA[P1][AC_PULL_ARMS]	= AS_FINAL;
				}
			}

//			if ((ui_state1D[P1][SPECIAL] & 0x80 &&
//				PA[P1][AC_WALK_FWD] == AS_ACTIVE) ||
//				(ui_state[P1][SPECIAL] & 0x80 &&
//				ui_state1D[P1][RIGHT] & 0x80))
//				PA[P1][AC_PUSH_ARMS]	= AS_FINAL;
		}
/*		else
		{
			if ((ui_state1D[P1][SPECIAL] & 0x80 &&
				PA[P1][AC_WALK_FWD] == AS_ACTIVE) ||
				(ui_state[P1][SPECIAL] & 0x80 &&
				ui_state1D[P1][LEFT] & 0x80))
				PA[P1][AC_PUSH_ARMS]	= AS_FINAL;
		}
		if (sip2 == 0)
		{
			if ((ui_state1D[P2][SPECIAL] & 0x80 &&
				PA[P2][AC_WALK_FWD] == AS_ACTIVE) ||
				(ui_state[P2][SPECIAL] & 0x80 &&
				ui_state1D[P2][RIGHT] & 0x80))
				PA[P2][AC_PUSH_ARMS]	= AS_FINAL;
		}
		else
		{
			if ((ui_state1D[P2][SPECIAL] & 0x80 &&
				PA[P2][AC_WALK_FWD] == AS_ACTIVE) ||
				(ui_state[P2][SPECIAL] & 0x80 &&
				ui_state1D[P2][LEFT] & 0x80))
				PA[P2][AC_PUSH_ARMS]	= AS_FINAL;
		}*/

		//---- pulling ---------------------------------------------------------------------------

		//special key plus backward
		/*if (sip1 == 0)
		{
			if ((ui_state1D[P1][SPECIAL] & 0x80 &&
				PA[P1][AC_WALK_BWD] == AS_ACTIVE) ||
				(ui_state[P1][SPECIAL] & 0x80 &&
				ui_state1D[P1][LEFT] & 0x80))
				PA[P1][AC_PULL_ARMS]	= AS_FINAL;
		}
		else
		{
			if ((ui_state1D[P1][SPECIAL] & 0x80 &&
				PA[P1][AC_WALK_BWD] == AS_ACTIVE) ||
				(ui_state[P1][SPECIAL] & 0x80 &&
				ui_state1D[P1][RIGHT] & 0x80))
				PA[P1][AC_PULL_ARMS]	= AS_FINAL;
		}
		if (sip2 == 0)
		{
			if ((ui_state1D[P2][SPECIAL] & 0x80 &&
				PA[P2][AC_WALK_BWD] == AS_ACTIVE) ||
				(ui_state[P2][SPECIAL] & 0x80 &&
				ui_state1D[P2][LEFT] & 0x80))
				PA[P2][AC_PULL_ARMS]	= AS_FINAL;
		}
		else
		{
			if ((ui_state1D[P2][SPECIAL] & 0x80 &&
				PA[P2][AC_WALK_BWD] == AS_ACTIVE) ||
				(ui_state[P2][SPECIAL] & 0x80 &&
				ui_state1D[P2][RIGHT] & 0x80))
				PA[P2][AC_PULL_ARMS]	= AS_FINAL;
		}*/




							//defend only
							case (3):
								{
									if (si[p] == SLEFT)
									{
										PA[p][AC_DEFEND]	= AS_FINAL;
										//stop jab
										//!! vorsicht wegen reihenfolge und winkelumkehrung
										//if (mm_angle[p] >= 270 ||
										//	mm_angle[p] <= 67)
										//	PA[p][AC_STOP_JAB] = AS_FINAL;

										//tapping
										//only tap_jab gets activated, player selects
										//further details itself (which hand or leg, etc.)
	/*									if (mm_angle[p] > 90 &&
											mm_angle[p] <= 270)
										{
											PA[p][AC_TAP_JAB] = AS_FINAL;
											//mirror final angle
											mm_angle[p] = 180 - mm_angle[p];
											//check angle doesn't exceed its limit
											if (mm_angle[p] > 359)		mm_angle[p] -= 360;
											if (mm_angle[p] < 0)		mm_angle[p] += 360;
										}*/
									}
									else
									{
										//stop jab
										//!! vorsicht wegen reihenfolge und winkelumkehrung
										//if (mm_angle[p] > 90 &&
										//	mm_angle[p] <= 270)
										//	PA[p][AC_STOP_JAB] = AS_FINAL;

										//tapping
										//only tap_jab gets activated, player selects
										//further details itself (which hand or leg, etc.)
										//if (mm_angle[p] >= 270 ||
										//	mm_angle[p] < 90)
										//{
										//	PA[p][AC_TAP_JAB] = AS_FINAL;
										//	//mirror final angle
										//	mm_angle[p] = 180 - mm_angle[p];
										//	//check angle doesn't exceed its limit
										//	if (mm_angle[p] > 359)		mm_angle[p] -= 360;
										//	if (mm_angle[p] < 0)		mm_angle[p] += 360;
										//}
									}

									break;
								}
								
								
								
								
								
if (P[P1].p_aslot[aslot_cycle] != NULL)		dd.typebmf(100, 100, 0, "cycle:  %i", P[P1].p_aslot[aslot_cycle]->id);
else										dd.typebmf(100, 100, 0, "cycle:  NONE");
if (P[P1].p_aslot[aslot_action] != NULL)	dd.typebmf(100, 116, 0, "action: %i", P[P1].p_aslot[aslot_action]->id);
else										dd.typebmf(100, 116, 0, "action: NONE");

if (P[P2].p_aslot[aslot_cycle] != NULL)		dd.typebmf(200, 100, 0, "cycle:  %i", P[P2].p_aslot[aslot_cycle]->id);
else										dd.typebmf(200, 100, 0, "cycle:  NONE");
if (P[P2].p_aslot[aslot_action] != NULL)	dd.typebmf(200, 116, 0, "action: %i", P[P2].p_aslot[aslot_action]->id);
else										dd.typebmf(200, 116, 0, "action: NONE");

dd.typebmf(500, 100, 0, "pa: %i a: %i pa180 %i a180 %i",
		   is.mm_angle_pre[P1],
		   is.mm_angle[P1],
		   is.mm_angle_180_pre[P1],
		   is.mm_angle_180[P1]);
dd.typebmf(500, 116, 0, "mcx: %i mcy: %i",
		   is.mcx[P1], is.mcy[P1]);
dd.typebmf(500, 132, 0, "mmx: %i mmy: %i",
		   is.mmx[P1], is.mmy[P1]);

dd.typebmf(500, 148, 0, "%i %i", is.dimouse[1].lX, is.dimouse[1].lY);
dd.typebmf(500, 162, 0, "mmstate: %i mmbutton: %i mmbflag: %i",
		   is.mm_state[P1],
		   is.mm_button[P1],
		   is.mm_button_flag[P1]);

//if (is.key1D(DIK_S))	is.dev_i = 0;
//dd.typebmf(100, 150, 0, "%i", is.dev_i);

if (P[P1].p_aslot[aslot_action] != NULL)
	dd.typebmf(100, 150, 0, "%i %i", P[P1].p_aslot[aslot_action]->angle[P1], P[P1].p_aslot[aslot_action]->angle_180[P1]);
dd.typebmf(100, 166, 0, "%i", is.PA[P1][AN_PUSH_ARMS]);
if (is.PA[P1][AN_PUSH_ARMS] == 1)
	playsound_s(S_ERROR);
if (is.PA[P1][AN_PUSH_ARMS] == 2)
	playsound_s(S_MENTER);

static int counter = 0;
if (is.key1D(DIK_X))
	counter = 0;
if (is.PA[P1][AN_PUSH_ARMS] == 2)
	++counter;
dd.typebmf(100, 182, 0, "counter: %i", counter);

static line lc;
static line lm;
//if (is.mcx != 0 && is.mcy != 0)
	lc.set_line(400, 300, 400 + (float)is.mcx[P1], 300 + (float)is.mcy[P1]);
//if (is.mmx != 0 && is.mmy != 0)
	lm.set_line(400, 300, 400 + (float)is.mmx[P1], 300 + (float)is.mmy[P1]);

//dd.drawline(lc, red);
//dd.drawline(lm, blue);

static line lpre;
static line lfin;

float rad_ = (float)is.mm_angle_pre[P1] / 180.0f * PI;
point tmp;
tmp.x = 400 + (25 + is.mm_length_c[P1]) * (float)cos(rad_);
tmp.y = 300 + (25 + is.mm_length_c[P1]) * (float)sin(rad_);
lpre.set_line(400, 300, tmp.x, tmp.y);
rad_ = (float)is.mm_angle[P1] / 180.0f * PI;
tmp.x = 400 + (25 + is.mm_length_c[P1]) * (float)cos(rad_);
tmp.y = 300 + (25 + is.mm_length_c[P1]) * (float)sin(rad_);
lfin.set_line(400, 300, tmp.x, tmp.y);

dd.drawline(lfin, red);
dd.drawline(lpre, blue);




//		if (((asi == 0 || asi == 2) &&
//			(gl_lock.lock_off[0] != 1 || gl_lock.lock_offc[0] == 1 || abs(angle_180[id] - gl_lock.angle_off[0]) > 20)) ||
//			((asi == 1 || asi == 3) &&
//			(gl_lock.lock_off[1] != 1 || gl_lock.lock_offc[1] == 1 || abs(angle_180[id] - gl_lock.angle_off[1]) > 20)))



	//---- get_lockstate -------------------------------------------------------------------------
	//for offense state
	//return true if attack locked, false if not

	bool get_lockstate(int asi,							//current asi of player
					   int limb,						//attacking limb with asi 0
					   int context,						//context of attack
					   int angle_180,					//angle_180 of attack
					   int angle_diff)					//angle difference to lock to be not locked
	{
		//limb index
		int lindex = limb;

/*		//!! falsch, wieso sollte das vom asi abhaengig sein? limbs und bones sind absolut
		//left hand forward
		if (asi == 0 || asi == 2)
		{
			//limb index is same as argument
			lindex			= limb;
		}
		else
		//right hand forward
		{
			//select limb
			if (limb == 0)			lindex	= 1;
			if (limb == 1)			lindex	= 0;
			if (limb == 2)			lindex	= 3;
			if (limb == 3)			lindex	= 2;
		}*/

		//if limb not locked or different context locked or difference between locked angle and new angle >= argument
		if (lock_off[lindex] != 1 || lock_offc[lindex] != context || abs(angle_180 - angle_off[lindex]) >= angle_diff)
		{
			//if angle difference big enough also unlock previously locked limb
			if (abs(angle_180 - angle_off[lindex]) >= angle_diff)
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);

			return false;
		}
		else
			return true;

//		if (((asi == 0 || asi == 2) &&
//			(gl_lock.lock_off[0] != 1 || gl_lock.lock_offc[0] == 1 || abs(angle_180[id] - gl_lock.angle_off[0]) > 20)) ||
//			((asi == 1 || asi == 3) &&
//			(gl_lock.lock_off[1] != 1 || gl_lock.lock_offc[1] == 1 || abs(angle_180[id] - gl_lock.angle_off[1]) > 20)))
	};

	if (advance_slot[0] == 1)
	{
		if (p_time->current <= t_advanceslot_start[0] + p_time->freq * (0.1f / p_option->data.speed))
		{
			//set target angle of all bones to current position
			for (register int b = 0; b < 19; ++b)
				if (casi[b] == 0)
					p_aslot[0]->pkf[cki[b]].angle_ad[id][b] = sk.b[b].angle;
		}
		else
		{
			//reset advance flag
			advance_slot[0]		= 0;

			//for all bones and hara
			for (register int b = 0; b < 21; ++b)
				//if not already reached last keyframe
				if (casi[b] == 0 && cki[b] < p_aslot[0]->nokf - 1)
				{
					//reset state of current keyframe, increase keyframe
					p_aslot[0]->pkf[cki[b]].state[id][b] = 0;
					++cki[b];
				}
		}
	}
	if (advance_slot[1] == 1)
	{
//		if (p_time->current <= t_advanceslot_start[1] + p_time->freq * (0.1f / p_option->data.speed))
		{
			//set target angle of all bones to current position
//			for (register int b = 0; b < 19; ++b)
//				if (casi[b] == 1)
//					p_aslot[1]->pkf[cki[b]].angle_ad[id][b] = sk.b[b].angle;
		}
//		else
		{
			//reset advance flag
			advance_slot[1]		= 0;

			for (register int b = 0; b < 21; ++b)
				if (casi[b] == 1 && cki[b] < p_aslot[1]->nokf - 1)
				{
					p_aslot[1]->pkf[cki[b]].state[id][b] = 0;
					++cki[b];
				}
		}
	}
	
	
	
	
	
//!! shadow_c
RGBcolor x = bc;
int tol = 50;
if (0 + (rand() % (1 - 0 + 1)))		x.r	+=	0 + (rand() % (tol - 0 + 1));
else								x.r	-=	0 + (rand() % (tol - 0 + 1));
if (0 + (rand() % (1 - 0 + 1)))		x.g	+=	0 + (rand() % (tol - 0 + 1));
else								x.g	-=	0 + (rand() % (tol - 0 + 1));
if (0 + (rand() % (1 - 0 + 1)))		x.b	+=	0 + (rand() % (tol - 0 + 1));
else								x.b	-=	0 + (rand() % (tol - 0 + 1));
if (x.r < 0)	x.r = 0;
if (x.r > 255)	x.r = 255;
if (x.g < 0)	x.g = 0;
if (x.g > 255)	x.g = 255;
if (x.b < 0)	x.b = 0;
if (x.b > 255)	x.b = 255;
pixelf = WORD(p_rLUT[x.r] | p_gLUT[x.g] | p_bLUT[x.b]);

//---- manuel taps -------------------------------------------------------------------------------

//*		//---- tap jab ---------------------------------------------------------------------------

		if (PA[id][AN_TAP_JAB] == AS_FINAL)
		{
			//angle limits
			if (side == SLEFT)
			{
				if (angle[id] > 35 && angle[id] <= 90)			angle[id]	= 35;
				if (angle[id] < 350 && angle[id] >= 270)		angle[id]	= 350;
			}
			else
			{
				if (angle[id] < 145)							angle[id]	= 145;
				if (angle[id] > 190)							angle[id]	= 190;
			}
			//set 180 angle
			if (angle[id] > 270)							angle_180[id] = angle[id] - 271;
			if (angle[id] >= 0 && angle[id] <= 90)			angle_180[id] = angle[id] + 89;
			if (angle[id] > 90 && angle[id] <= 270)			angle_180[id] = 270 - angle[id];

			//if previous animation jab (pre-state)
			//deactivate it without applying fatige
			if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
				al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_TAP_JAB);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;
		}
		if (PA[id][AN_TAP_JAB] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}

		//---- tap cross -------------------------------------------------------------------------

		if (PA[id][AN_TAP_CROSS] == AS_FINAL)
		{
			//reverse angle (x and y)
			angle[id]	+= 180;
			//angle limits
			if (angle[id] > 359)	angle[id] -= 360;
			if (angle[id] < 0)		angle[id] += 360;

			if (side == SLEFT)
			{
				if (angle[id] > 60 && angle[id] <= 90)			angle[id]	= 60;
				if (angle[id] < 5 || angle[id] >= 270)			angle[id]	= 5;
			}
			else
			{
				if (angle[id] < 120)							angle[id]	= 120;
				if (angle[id] > 185)							angle[id]	= 185;
			}
			//set 180 angle
			if (angle[id] > 270)							angle_180[id] = angle[id] - 271;
			if (angle[id] >= 0 && angle[id] <= 90)			angle_180[id] = angle[id] + 89;
			if (angle[id] > 90 && angle[id] <= 270)			angle_180[id] = 270 - angle[id];

			if (p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
				al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;
		}
		if (PA[id][AN_TAP_CROSS] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}

		//---- tap leg ---------------------------------------------------------------------------

		if (PA[id][AN_TAP_LEG] == AS_FINAL)
		{
			if (side == SLEFT)
			{
				if (angle[id] > 50 && angle[id] <= 90)			angle[id]	= 50;
				if (angle[id] < 330 && angle[id] >= 270)		angle[id]	= 330;
			}
			else
			{
				if (angle[id] < 130)							angle[id]	= 130;
				if (angle[id] > 210)							angle[id]	= 210;
			}
			//set 180 angle
			if (angle[id] > 270)							angle_180[id] = angle[id] - 271;
			if (angle[id] >= 0 && angle[id] <= 90)			angle_180[id] = angle[id] + 89;
			if (angle[id] > 90 && angle[id] <= 270)			angle_180[id] = 270 - angle[id];

			if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
				al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_TAP_LEG);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;
		}
		if (PA[id][AN_TAP_LEG] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}*/

	//!!!
	*ptap = AN_TAP_CROSS;
	if (side == SLEFT)				*pangle	= 0;
	else							*pangle	= 180;
	//set 180 angle
	if (*pangle > 270)							*pangle_180 = *pangle - 271;
	if (*pangle >= 0 && *pangle <= 90)			*pangle_180 = *pangle + 89;
	if (*pangle > 90 && *pangle <= 270)			*pangle_180 = 270 - *pangle;

/*		if (PA[id][AN_TAP_CROSS] == AS_FINAL)
		{
			//reverse angle (x and y)
			angle[id]	+= 180;
			//angle limits
			if (angle[id] > 359)	angle[id] -= 360;
			if (angle[id] < 0)		angle[id] += 360;

			//angle limits
			if (side == SLEFT)				angle[id]	= 0;
			else							angle[id]	= 180;
			//set 180 angle
			if (angle[id] > 270)							angle_180[id] = angle[id] - 271;
			if (angle[id] >= 0 && angle[id] <= 90)			angle_180[id] = angle[id] + 89;
			if (angle[id] > 90 && angle[id] <= 270)			angle_180[id] = 270 - angle[id];


	jab		//angle limits
			if (side == SLEFT)				angle[id]	= 0;
			else							angle[id]	= 180;
			//set 180 angle
			if (angle[id] > 270)							angle_180[id] = angle[id] - 271;
			if (angle[id] >= 0 && angle[id] <= 90)			angle_180[id] = angle[id] + 89;
			if (angle[id] > 90 && angle[id] <= 270)			angle_180[id] = 270 - angle[id];


			if (p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
				al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;
		}*/

	//---- auto tap/evade ------------------------------------------------------------------------

/*		if (angle[id] > 270 || angle[id] < 90)
		{
			if (angle[id] > 270)
			{
				angle[id] = 0;
				al_activate_slot(aslot_action, AN_TAP_JAB);
				p_aslot[aslot_action]->state[id]	= AS_FINAL;
				p_aslot[aslot_action]->ui_valid[id]	= 1;
			}
			else
			{
				angle[id] = 0;
				al_activate_slot(aslot_action, AN_TAP_LEG);
				p_aslot[aslot_action]->state[id]	= AS_FINAL;
				p_aslot[aslot_action]->ui_valid[id]	= 1;
			}
		}
		else
		{
			angle[id] = 0;
			al_activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;*/

/*			if (angle[id] > 180)

				al_activate_slot(aslot_action, AN_EVADE_HI);
			else
				al_activate_slot(aslot_action, AN_EVADE_HI);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id]	= 1;*/
//		}

	//defense is context sensitive and depending on opponents action and attack/defend angels
/*//	if (PA[id][AN_DEFEND] == AS_ACTIVE)
//		gl_fatigue_add(0, 0, p_anmn[asi][AN_DEFEND]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
//		fatigue_buff += (float)p_anmn[asi][AN_DEFEND]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed;

	if (PA[id][AN_TAP_JAB] == AS_ACTIVE)
	{
		if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB_HOOK] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS_HOOK] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_JAB] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_CROSS] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD_KNEE] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD_KNEE] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_KICK])
		{
			//zeitindex bei animation setzen
			//hier zeitindex speichern, vergleichen

			//hi guard
			if (stance_arms > 70)
				if (p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_MI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_DUCK] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_JAB] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_CROSS] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG])
				{
					//only evade once for an opponents attack
					if (opp_time[aslot_action] != pp_anmn_opp[aslot_action]->gl_time[!id])
					{
						al_activate_slot(aslot_action, AN_EVADE_HI);
						opp_time[aslot_action] = pp_anmn_opp[aslot_action]->gl_time[!id];
					}
				}

			//mi guard
			if (stance_arms > 30 && stance_arms <= 70)
				if (p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_MI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_DUCK] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_JAB] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_CROSS] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG])
					al_activate_slot(aslot_action, AN_EVADE_MI);
			
			//lo guard
			if (stance_arms <= 30)
				if (p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_MI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_DUCK] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_JAB] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_CROSS] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG])
					al_activate_slot(aslot_action, AN_EVADE_LO);
		}
	}*/

	//---- tapping -------------------------------------------------------------------------------
/*
//!! test
if (PA[id][AN_TAP_JAB] == AS_ACTIVE)
{
	angle_180[id] = 0;
	if (id == P2)	angle_180[id] = 180;
	al_activate_slot(aslot_action, AN_TAP_JAB);
}
if (PA[id][AN_TAP_LEG] == AS_ACTIVE)
{
	angle_180[id] = 0;
	if (id == P2)	angle_180[id] = 180;
	al_activate_slot(aslot_action, AN_TAP_LEG);
}

	if (PA[id][AN_DEFEND] == AS_ACTIVE)
	{
		//set angle
		//always facing forward so take opponents angle and adjust it if necessary

		//!! wenn winkel tief, anpassen wegen jab/cross art oder anmn anpassen
		if (side == SLEFT)
			if (angle[!id] < 270 && angle[!id] > 90)
			{
				angle[id] = 180 - angle[!id];
				//limits
				if (angle[id] < 0)		angle[id] += 360;
				if (angle[id] > 360)	angle[id] -= 360;
			}
			else
				angle[id] = angle[!id];
		else
			if (angle[!id] > 270 || angle[!id] < 90)
			{
				angle[id] = 180 - angle[!id];
				if (angle[id] < 0)		angle[id] += 360;
				if (angle[id] > 360)	angle[id] -= 360;
			}
			else
				angle[id] = angle[!id];

		//angle 180
		angle_180[id] = angle_180[!id];

		//type of defense
		//TAP_JAB
		//TAP_CROSS
		//TAP_LEG
		//-2 = evading punch
		//-3 = evading kick
		int defense_type = -1;
*/
/*		//---- set defense lock ------------------------------------------------------------------

		//if current running animation is defense and didn't block an attack set defense lock
		if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_JAB] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_TAP_CROSS] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_TAP_LEG])
		{
			if (p_aslot[aslot_action]->gl_def[id] != 1)
			{
				//index of limb to lock
				int lindex;
				if (asi == 0 || asi == 2)
				{
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_JAB])		lindex = 0;
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_CROSS])		lindex = 1;
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_LEG])		lindex = 2;
				}
				else
				{
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_JAB])		lindex = 1;
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_CROSS])		lindex = 0;
					if (p_aslot[aslot_action] == p_anmn[asi][AN_TAP_LEG])		lindex = 3;
				}

				//set lock and lock start time
				gl_set_lockstate(DEFENSIVE, lindex, ON);
				//lock_def[lindex]			= 1;
				t_ld_start[lindex]			= p_time->current;
			}
		}

		//---- punches ---------------------------------------------------------------------------

		if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB_HOOK] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS_HOOK] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_JAB] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_CROSS])
			{
				//!! in abh�ngigkeit von
				//angriffsart
				//angriffsh�he
				//guard h�he
				//entfernung (cross tap) 80
				//lock state

				/*
					prinzipiell immer vordere hand
					ausser wenn deckung unten und angriff oben, dann hintere
					oder wenn nahe beieinander

					set_defense_lock muss nur einmal und am anfang hiervon gemacht werden
					stance_arms an 180 anpassen
				*/

/*				//lower guard and attack high
				if (stance_arms < 65 && angle_180[id] <= 105)
					defense_type = AN_TAP_CROSS;
				else
					defense_type = AN_TAP_JAB;

/*				//upper guard with tap jab
				if (stance_arms > 65)
				{
					//!!
					if (lock_def[0] != 1)
					{
						al_activate_slot(aslot_action, AN_TAP_JAB);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
				}
				else
				//lower guard with tap cross
				{
				}*/

/*				//---- distance ------------------------------------------------------------------
				//if players too close use back hand to tap

				if (*p_distance <= 100)
					defense_type		= AN_TAP_CROSS;
			}

		//kicks
		if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD_KNEE] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD_KNEE] ||
			pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_KICK])
		{
			//on high foot attack use arms
			if (angle_180[!id] < 80)
			{
				al_activate_slot(aslot_action, AN_TAP_JAB);
				p_aslot[aslot_action]->state[id]	= AS_FINAL;
				p_aslot[aslot_action]->ui_valid[id] = 1;

				//set angle (which is already in right direction)
				if (side == SLEFT)
					angle[id] = 180 - (angle[!id] - 40);
				else
					angle[id] = 180 - (angle[!id] + 40);
				if (angle[id] < 0)		angle[id] += 360;
				if (angle[id] > 360)	angle[id] -= 360;
				angle_180[id] = angle_180[!id] + 40;
			}
			else
			//else use leg
			{
				al_activate_slot(aslot_action, AN_TAP_LEG);
				p_aslot[aslot_action]->state[id]	= AS_FINAL;
				p_aslot[aslot_action]->ui_valid[id] = 1;
			}
		}*/

		//---- defense locks ---------------------------------------------------------------------
		//defense may be locked so adjust type of defense here

/*		if (asi == 0 || asi == 2)
		{
			if (defense_type == AN_TAP_JAB && lock_def[0] == 1)
//				if (lock_def[1] != 1)
//					defense_type = AN_TAP_CROSS;
//				else
					defense_type = -2;

			if (defense_type == AN_TAP_CROSS && lock_def[1] == 1)
//				if (lock_def[0] != 1)
//					defense_type = AN_TAP_JAB;
//				else
					defense_type = -2;

			if (defense_type == AN_TAP_LEG && lock_def[2] == 1)
				defense_type = -3;
		}
		else
		{
			if (defense_type == AN_TAP_JAB && lock_def[1] == 1)
//				if (lock_def[0] != 1)
//					defense_type = AN_TAP_CROSS;
//				else
					defense_type = -2;

			if (defense_type == AN_TAP_CROSS && lock_def[0] == 1)
//				if (lock_def[1] != 1)
//					defense_type = AN_TAP_JAB;
//				else
					defense_type = -2;

			if (defense_type == AN_TAP_LEG && lock_def[3] == 1)
				defense_type = -3;
		}

		//!!
		dev_i = defense_type;

		//if defense type valid
		if (defense_type >= 0)
		{
			al_activate_slot(aslot_action, defense_type);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id] = 1;
		}
		else
		//defense not valid get evade type
		{
			if (defense_type != -1)
			{
				al_activate_slot(aslot_action, AN_DUCK);
			}
		}
	}*/

	//---- duck ----------------------------------------------------------------------------------

//	if (PA[id][AN_DUCK] == AS_ACTIVE)
//		al_activate_slot(aslot_action, AN_DUCK);

	//--------------------------------------------------------------------------------------------

/*	if (PA[id][AN_TAP_JAB] == AS_FINAL)
	{
		al_activate_slot(aslot_action, AN_TAP_JAB);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}*/

/*	if (PA[id][AN_DEFEND] == AS_ACTIVE)
	{
		al_activate_slot(aslot_action, AN_TAP_JAB);
//		al_activate_slot(aslot_action, AN_TAP_CROSS);
//		al_activate_slot(aslot_action, AN_TAP_LEG);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}*/

	//defense button only
/*	if (PA[id][AN_DEFEND] == AS_ACTIVE)
	{
		//---- auto defense evading --------------------------------------------------------------
		if (s_d_mode == 0)
		{
			//default evade
			al_activate_slot(aslot_action, AN_EVADE_HI);

			//select opponents attack
			//arm attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_CROSS])
			{
				//height of attack
				if (angle_180[!id] <= 80)
					al_activate_slot(aslot_action, AN_DUCK);
				if (angle_180[!id] > 80 && angle_180[!id] <= 110)
					al_activate_slot(aslot_action, AN_EVADE_HI);
				if (angle_180[!id] > 110)
					al_activate_slot(aslot_action, AN_EVADE_MI);
			}

			//foot attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_KICK])
			{
				//height of attack
				if (angle_180[!id] >= 100)
					al_activate_slot(aslot_action, AN_EVADE_LO);
				if (angle_180[!id] < 100 && angle_180[!id] >= 80)
					al_activate_slot(aslot_action, AN_EVADE_MI);
				if (angle_180[!id] < 80)
					al_activate_slot(aslot_action, AN_EVADE_HI);
			}
		}
		else
		//---- auto defense tapping --------------------------------------------------------------
		{
			//default tapping
			al_activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id] = 1;

			//set angle (which is already in right direction)
			angle[id] = 180 - angle[!id];
			if (angle[id] < 0)		angle[id] += 360;
			if (angle[id] > 360)	angle[id] -= 360;
			angle_180[id] = angle_180[!id];

			//select opponents attack
			//arm attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_CROSS])
			{
				//select tap depending on angle and stance
				if (angle_180[!id] <= 100)
				{
					if (stance_arms < 60)
					{
						al_activate_slot(aslot_action, AN_TAP_CROSS);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
					else
					{
						al_activate_slot(aslot_action, AN_TAP_JAB);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
				}
				else
				{
					if (stance_arms < 60)
					{
						al_activate_slot(aslot_action, AN_TAP_JAB);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
					else
					{
						al_activate_slot(aslot_action, AN_TAP_CROSS);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
				}
			}

			//foot attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_KICK])
			{
				//on high foot attack use arms
				if (angle_180[!id] < 80)
				{
					al_activate_slot(aslot_action, AN_TAP_JAB);
					p_aslot[aslot_action]->state[id]	= AS_FINAL;
					p_aslot[aslot_action]->ui_valid[id] = 1;

					//set angle (which is already in right direction)
					if (side == SLEFT)
						angle[id] = 180 - (angle[!id] - 40);
					else
						angle[id] = 180 - (angle[!id] + 40);
					if (angle[id] < 0)		angle[id] += 360;
					if (angle[id] > 360)	angle[id] -= 360;
					angle_180[id] = angle_180[!id] + 40;
				}
				else
				//else use leg
				{
					al_activate_slot(aslot_action, AN_TAP_LEG);
					p_aslot[aslot_action]->state[id]	= AS_FINAL;
					p_aslot[aslot_action]->ui_valid[id] = 1;
				}
			}
		}
	}

	//defense button and direction
	if (PA[id][AN_TAP_JAB] == AS_FINAL)
	{
		//---- manuel defense tapping ------------------------------------------------------------
		if (s_d_mode == 0)
		{
			//default
			al_activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id] = 1;

			//select opponents attack
			//arm attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_JAB_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_CROSS_HOOK] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_JAB] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_CROSS])
			{
				//select tap depending on angle and stance
				if (angle_180[id] <= 90)
				{
					if (stance_arms < 65)
					{
						al_activate_slot(aslot_action, AN_TAP_CROSS);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
					else
					{
						al_activate_slot(aslot_action, AN_TAP_JAB);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
				}
				else
				{
					if (stance_arms < 65)
					{
						al_activate_slot(aslot_action, AN_TAP_JAB);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
					else
					{
						al_activate_slot(aslot_action, AN_TAP_CROSS);
						p_aslot[aslot_action]->state[id]	= AS_FINAL;
						p_aslot[aslot_action]->ui_valid[id] = 1;
					}
				}
			}

			//foot attack
			if (pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_FWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_KICK_SWD_KNEE] ||
				pp_anmn_opp[aslot_action] == p_anmn[*p_asi_opp][AN_STOP_KICK])
			{
				//on high foot attack use arms
				if (angle_180[!id] < 80)
				{
					al_activate_slot(aslot_action, AN_TAP_JAB);
					p_aslot[aslot_action]->state[id]	= AS_FINAL;
					p_aslot[aslot_action]->ui_valid[id] = 1;
				}
				else
				//else use leg
				{
					al_activate_slot(aslot_action, AN_TAP_LEG);
					p_aslot[aslot_action]->state[id]	= AS_FINAL;
					p_aslot[aslot_action]->ui_valid[id] = 1;
				}
			}
		}
		else
		//---- manuel defense evading ------------------------------------------------------------
		{
		}

	}*/

	//---- stopping ------------------------------------------------------------------------------

/*	//stop jab
	if (PA[id][AN_STOP_JAB] == AS_FINAL)
	{
		al_activate_slot(aslot_action, AN_STOP_JAB);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}*/
/*		if (PA[id][AN_STOP_JAB] == AS_PRE)
		{
			activate_slot(aslot_action, AN_STOP_JAB);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[id] = 0;
		}
		if (PA[id][AN_STOP_JAB] == AS_FINAL && p_aslot[aslot_action] == p_anmn[asi][AN_STOP_JAB])
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id] = 1;
		}
		if (PA[id][AN_STOP_JAB] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_STOP_JAB])
		{
			deactivate_slot(aslot_action);
		}*/
			
			
	//---- walking -------------------------------------------------------------------------------

	//!! create backups
	static wini = 1;
	if (wini)
	{
		wini = 0;

		//for all bones and hara
		for (register int b = 0; b < 21; ++b)
		{
			walk_kftb_fwd[b][0]	= p_anmn[0][AN_WALK_FWD]->pkf[0].t_frame[b];
			walk_kftb_fwd[b][1]	= p_anmn[0][AN_WALK_FWD]->pkf[1].t_frame[b];
			walk_kftb_fwd[b][2]	= p_anmn[0][AN_WALK_FWD]->pkf[2].t_frame[b];
			walk_kftb_fwd[b][3]	= p_anmn[0][AN_WALK_FWD]->pkf[3].t_frame[b];
			walk_kftb_fwd[b][4]	= p_anmn[0][AN_WALK_FWD]->pkf[4].t_frame[b];
			walk_kftb_bwd[b][0]	= p_anmn[0][AN_WALK_BWD]->pkf[0].t_frame[b];
			walk_kftb_bwd[b][1]	= p_anmn[0][AN_WALK_BWD]->pkf[1].t_frame[b];
			walk_kftb_bwd[b][2]	= p_anmn[0][AN_WALK_BWD]->pkf[2].t_frame[b];
			walk_kftb_bwd[b][3]	= p_anmn[0][AN_WALK_BWD]->pkf[3].t_frame[b];
			walk_kftb_bwd[b][4]	= p_anmn[0][AN_WALK_BWD]->pkf[4].t_frame[b];
		}
	}

	//walking lock
	//the movement at movement start can't be changed till animation done
	//(except for stopping)
	if (walk_lock)
	{
		//if current animation walking
		if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
		{
			//non power attack
			if (!p_aslot[aslot_action]->power_attack[id])
			{
				//until on way back
	//			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0)
				//until before last keyframe
				if (cki[p_aslot[aslot_action]->ui_index] < p_aslot[aslot_action]->nokf - 1)
				{
					//fwd, no bwd
					if (walk_lock == 1)					PA[id][AN_WALK_BWD] = AS_INACTIVE;

					//bwd, no fwd
					if (walk_lock == 2)					PA[id][AN_WALK_FWD] = AS_INACTIVE;

					//not walking
					if (walk_lock == -1)
					{
						//change lock when starting to walk
						if (PA[id][AN_WALK_FWD] == AS_ACTIVE)	walk_lock = 1;
						if (PA[id][AN_WALK_BWD] == AS_ACTIVE)	walk_lock = 2;
						//reset move time
						t_move[id][0] = t_move[id][1] = 0;
					}
				}
				else
					walk_lock = 0;
			}
			else
			//power attack
			{
				//until on way back
	//			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0)
				//until before last keyframe
				if (cki[p_aslot[aslot_action]->ui_index] < p_aslot[aslot_action]->nokf - 1)
				{
					//fwd, no bwd, cont fwd
					if (walk_lock == 1)
					{
						PA[id][AN_WALK_BWD] = AS_INACTIVE;
						PA[id][AN_WALK_FWD]	= AS_ACTIVE;
						t_move[id][0]		= 0;
						t_move[id][1]		= 1.0f;
					}

					//bwd, no fwd, cont bwd
					if (walk_lock == 2)
					{
						PA[id][AN_WALK_BWD] = AS_ACTIVE;
						PA[id][AN_WALK_FWD] = AS_INACTIVE;
						t_move[id][0]		= 1.0f;
						t_move[id][1]		= 0;
					}

					//not walking
					if (walk_lock == -1)
					{
						PA[id][AN_WALK_BWD] = AS_INACTIVE;
						PA[id][AN_WALK_FWD] = AS_INACTIVE;
						t_move[id][0] = t_move[id][1] = 0;
					}
				}
				else
					walk_lock = 0;
			}
		}
		else
			walk_lock = 0;
	}

	//push back
	//if pushtime valid
	if (cd_t_pushhit + p_time->freq * (cd_push_force / p_option->data.speed) >= p_time->current)
	{
		//0 = stop player forward movement
		if (cd_push_type == 0)
			PA[id][AN_WALK_FWD] = AS_INACTIVE;

		//1 = push player backward, may be canceled to stop
		//when player hits forward
		if (cd_push_type == 1)
		{
			PA[id][AN_WALK_BWD] = AS_ACTIVE;
			//also set move time
			t_move[id][0] = 1.0f;

			//if player moving forward
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE)
			{
				//set to stop
				PA[id][AN_WALK_BWD] = AS_INACTIVE;
				PA[id][AN_WALK_FWD] = AS_INACTIVE;
			}
		}

		//2 = push player backwards, no canceling possible
		if (cd_push_type == 2)
		{
			//also set move time
			t_move[id][0] = 1.0f;
			PA[id][AN_WALK_BWD] = AS_ACTIVE;
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
		}
	}
	else
	{
		//reset push time
		cd_t_pushhit	= 0;
		//reset push type
		cd_push_type	= -1;
		//reset push force
		cd_push_force	= 0;
		//reset push speed
		cd_push_speed	= 0;
	}

	//rushing
	//increase forward speed while attacking
	if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_CROSS] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
	{
		//if action keyframe
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action != act_none &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action != act_def)
		{
			//increase forward walking speed
			walk_fwd_rush = 50;
		}

		//if animation on way back decrease forward walking speed
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 1)
		{
			//walk_fwd_rush = -50;
		}
	}
	else
		walk_fwd_rush = 0;

	//screen boundaries
/*	if (side == SLEFT)
	{
		if (sk.p_ref->v.p[0].x <= S_LBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x <= S_LBOUND + 3))
			PA[id][AN_WALK_BWD] = AS_INACTIVE;

		if (sk.p_ref->v.p[0].x >= S_RBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x >= S_LBOUND - 3))
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
	}
	else
	{
		if (sk.p_ref->v.p[0].x <= S_LBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x <= S_LBOUND + 3))
			PA[id][AN_WALK_FWD] = AS_INACTIVE;

		if (sk.p_ref->v.p[0].x >= S_RBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x >= S_LBOUND - 3))
			PA[id][AN_WALK_BWD] = AS_INACTIVE;
	}*/
	if (sk.p_ref->v.p[0].x <= S_LBOUND)
		if (side == SLEFT)
			PA[id][AN_WALK_BWD] = AS_INACTIVE;
		else
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
	if (sk.p_ref->v.p[0].x >= S_RBOUND)
		if (side == SLEFT)
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
		else
			PA[id][AN_WALK_BWD] = AS_INACTIVE;

	//time in seconds until full walking speed
	//adjusted to user set speed
	float waf = SKILL_WALK_ACC / p_option->data.speed;
//!! bei push-back setzen, sonst keine bewegung
//!! von fatigue abh�ngig

	//actual player movement
	//calculate movement speed depending on fatigue and bone damage
	if (PA[id][AN_WALK_BWD])
	{
		//!!
		walk_bwd_ad		= 1.0f

		if (t_move[id][0] < waf)
			x;
		else
			x;

		//calculate walking speed
		walk_bwd_ad		= SKILL_WALK_BWD + cd_push_speed + walk_bwd_rush;

		//for all bones
		for (register int i = 0; i < 19; ++i)
		{
			//if damage of bone has affect on speed
			if (p_anmn[asi][AN_WALK_BWD]->gl_eff_dam_speed[i] >= 1.0f)
				//reduce walking speed
				walk_bwd_ad -= (int)(SKILL_WALK_BWD * (sk.b[i].damage / 100.0f / p_anmn[asi][AN_WALK_BWD]->gl_eff_dam_speed[i]));
		}

		//if fatigue effects speed
		if (p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed >= 1)
			walk_bwd_ad -= (int)(SKILL_WALK_BWD * (fatigue / 100.0f / p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed));

//!!
if (!dev_i)
{
		if (side == SLEFT)
			if (t_move[id][0] < waf)
				sk.p_ref->v.p[0].x -= walk_bwd_ad * (t_move[id][0] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x -= walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			if (t_move[id][0] < waf)
				sk.p_ref->v.p[0].x += walk_bwd_ad * (t_move[id][0] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x += walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
}

		//!!
//		if (t_move[id][0] < waf)
//			walk_bwd_ad = walk_bwd_ad / (waf / t_move[id][0]);
/*		if (side == SLEFT)
			sk.p_ref->v.p[0].x -= walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			sk.p_ref->v.p[0].x += walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;*/
	}

	if (PA[id][AN_WALK_FWD])
	{
		walk_fwd_ad		= SKILL_WALK_FWD + walk_fwd_rush;

		for (register int i = 0; i < 19; ++i)
		{
			if (p_anmn[asi][AN_WALK_FWD]->gl_eff_dam_speed[i] >= 1.0f)
				walk_fwd_ad -= (int)(SKILL_WALK_FWD * (sk.b[i].damage / 100.0f / p_anmn[asi][AN_WALK_FWD]->gl_eff_dam_speed[i]));
		}

		if (p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed >= 1)
			walk_fwd_ad -= (int)(SKILL_WALK_FWD * (fatigue / 100.0f / p_anmn[asi][AN_WALK_FWD]->gl_eff_fat_speed));

//!!
if (!dev_i)
{
		if (side == SLEFT)
			if (t_move[id][1] < waf)
				sk.p_ref->v.p[0].x += walk_fwd_ad * (t_move[id][1] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x += walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			if (t_move[id][1] < waf)
				sk.p_ref->v.p[0].x -= walk_fwd_ad * (t_move[id][1] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x -= walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
}
		//!!
//		if (t_move[id][1] < waf)
//			walk_fwd_ad = walk_fwd_ad / (waf / t_move[id][1]);
/*		if (side == SLEFT)
			sk.p_ref->v.p[0].x += walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			sk.p_ref->v.p[0].x -= walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;*/
	}

	//input and animation
	//deactivate walking if button no longer down
	if (PA[id][AN_WALK_FWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
		al_deactivate_slot(aslot_cycle);
	if (PA[id][AN_WALK_BWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
		al_deactivate_slot(aslot_cycle);
	if (PA[id][AN_WALK_FWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_FWD])
	{
		//create walk cycle in depedence of stance_arms
		al_create_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
		//don't apply speedfactor while activating the slot because
		//this is already done in al_create_walk_cycle
		al_activate_slot(aslot_cycle, AN_WALK_FWD, false);
	}
	//if already running update keyframe speed if necessary
/*	if (PA[id][AN_WALK_FWD] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
	{
		if (t_move[id][1] < waf)
			al_adjust_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
	}*/
	if (PA[id][AN_WALK_BWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_BWD])
	{
		//create walk cycle in depedence of stance_arms
		al_create_walk_cycle(AN_WALK_BWD, walk_bwd_ad / SKILL_WALK_BWD);
		al_activate_slot(aslot_cycle, AN_WALK_BWD, false);
	}
/*	if (PA[id][AN_WALK_BWD] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
	{
		if (t_move[id][0] < waf)
			al_adjust_walk_cycle(AN_WALK_BWD, walk_bwd_ad / SKILL_WALK_BWD);
	}*/

	//walking fatigue
	//since most of the time the fatigue value for walking is lower than the
	//fatigue regeneration all walking does is slowing down the regeneration
	if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
		//fatigue_buff += (float)p_anmn[asi][AN_WALK_FWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed;
		gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_WALK_FWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
	if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
		//fatigue_buff += (float)p_anmn[asi][AN_WALK_BWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed;
		gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_WALK_BWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);


//------------------------------------------------------------------------------------------------
//
//	master_frame dev_showdata
//
//	shows all relevant animation data on screen
//
//------------------------------------------------------------------------------------------------

void master_frame::dev_showdata()
{
	//print showdata, devmode state, showref, animate
	dd.typefont(1 * 8, 1 * 16 + 8, "show/dm:");		dd.typefont(10 * 8, 1 * 16 + 8, "", dev_s_showdata, 0);
													dd.typefont(13 * 8, 1 * 16 + 8, "", dev_s_devmode, 0);
	dd.typefont(1 * 8, 2 * 16 + 8, "showref:");		dd.typefont(10 * 8, 2 * 16 + 8, "", dev_s_showref, 0);
	dd.typefont(1 * 8, 3 * 16 + 8, "animate:");		dd.typefont(10 * 8, 3 * 16 + 8, "", dev_s_animate, 0);

	//draw extra bars
	RECT		eb;
	fillRECT(eb, 0, 75, 800, 150);		dd.colorfill(eb, blue);
	fillRECT(eb, 0, 450, 800, 525);		dd.colorfill(eb, blue);

	//draw floor lines
	line	floor_up(0, S_FLOOR, 799, S_FLOOR),
			floor_lo(0, S_FLOOR + 10, 799, S_FLOOR + 10);
	dd.drawline(floor_up, green);
	dd.drawline(floor_lo, blue);

	//print current bone index
	dd.typefont(1 * 8, 33 * 16, "", dev_bi[P1], 0);
	dd.typefont(17 * 8, 33 * 16, "", dev_bi[P2], 0);

	//print angle, length width and position of selected bone for both players
	dd.typefont(1 * 8, 34 * 16, "angle:");		dd.typefont(8 * 8, 34 * 16, "", P[P1].sk.b[dev_bi[P1]].angle, 1);
	dd.typefont(1 * 8, 35 * 16, "lengt:");		dd.typefont(8 * 8, 35 * 16, "", P[P1].sk.b[dev_bi[P1]].length, 1);
	dd.typefont(1 * 8, 36 * 16, "width:");		dd.typefont(8 * 8, 36 * 16, "", P[P1].sk.b[dev_bi[P1]].width, 1);
	dd.typefont(5 * 8, 33 * 16, "", P[P1].sk.b[dev_bi[P1]].v.p[0].x, 0);
	dd.typefont(9 * 8, 33 * 16, "", P[P1].sk.b[dev_bi[P1]].v.p[0].y, 0);

	dd.typefont(17 * 8, 34 * 16, "angle:");		dd.typefont(24 * 8, 34 * 16, "", P[P2].sk.b[dev_bi[P2]].angle, 1);
	dd.typefont(17 * 8, 35 * 16, "lengt:");		dd.typefont(24 * 8, 35 * 16, "", P[P2].sk.b[dev_bi[P2]].length, 1);
	dd.typefont(17 * 8, 36 * 16, "width:");		dd.typefont(24 * 8, 36 * 16, "", P[P2].sk.b[dev_bi[P2]].width, 1);
	dd.typefont(21 * 8, 33 * 16, "", P[P2].sk.b[dev_bi[P2]].v.p[0].x, 0);
	dd.typefont(25 * 8, 33 * 16, "", P[P2].sk.b[dev_bi[P2]].v.p[0].y, 0);

	//damage, fatigue, arm stance
	dd.typefont(1 * 8, 5 * 16, "fatigue:");		dd.typefont(10 * 8, 5 * 16, "", P[P1].fatigue, 2);
	dd.typefont(1 * 8, 6 * 16, "damage:");		dd.typefont(10 * 8, 6 * 16, "", P[P1].sk.b[dev_bi[P1]].damage, 2);
	dd.typefont(1 * 8, 7 * 16, "arms:");		dd.typefont(10 * 8, 7 * 16, "", P[P1].stance_arms, 0);

	dd.typefont(17 * 8, 5 * 16, "", P[P2].fatigue, 2);
	dd.typefont(17 * 8, 6 * 16, "", P[P2].sk.b[dev_bi[P2]].damage, 2);
	dd.typefont(17 * 8, 7 * 16, "", P[P2].stance_arms, 0);

	//---- reference skeletons -------------------------------------------------------------------

	if (dev_s_showref)
		for (register int i = 0; i < 19; ++i)
		{
			//skeletons (if set)
			if (dev_hsk[0].p[0].x != 0 && dev_hsk[0].p[1].x != 0)
				dd.drawrectangle_uf(dev_hsk[i], red);
			if (dev_esk[0][0].p[0].x != 0 && dev_esk[0][0].p[1].x != 0)
				dd.drawrectangle_uf(dev_esk[0][i], blue);
			if (dev_esk[1][0].p[0].x != 0 && dev_esk[1][0].p[1].x != 0)
				dd.drawrectangle_uf(dev_esk[1][i], green);
		}

	//---- animation data ------------------------------------------------------------------------

	//mark cai, ckfi
	RECT	r;	fillRECT(r, 31 * 8, 33 * 16, 40 * 8, 34 * 16);	dd.drawrectangle_f(r, blue);
	fillRECT(r, 31 * 8, 35 * 16, 40 * 8, 36 * 16);				dd.drawrectangle_f(r, red);

	//mark data of current bone index
	fillRECT(r, (dev_bi[P1] * 4 + 13) * 8 - 2, 450, (dev_bi[P1] * 4 + 13) * 8 + 24, 525);
	dd.drawrectangle_f(r, green);

	//mark hara data
	fillRECT(r, 735, 450, 799, 525);							dd.drawrectangle_f(r, darkgreen);
	fillRECT(r, 735, 466, 799, 482),							dd.drawrectangle_f(r, green);

	//current animation index, number of keyframes, current keyframe index
	dd.typefont(32 * 8, 33 * 16, "cai:");		dd.typefont(38 * 8, 33 * 16, "", dev_cai, 0);
	dd.typefont(32 * 8, 34 * 16, "nokf:");		dd.typefont(38 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->nokf, 0);
	dd.typefont(32 * 8, 35 * 16, "ckfi:");		dd.typefont(38 * 8, 35 * 16, "", dev_ckf, 0);

	//keyframe time
	dd.typefont(1 * 8, 32 * 16, "t_frame[b]:");
	for (register int i = 0; i < 19; ++i)
		dd.typefont((i * 4 + 13) * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[i], 0);
	//hara x, y time
	dd.typefont(92 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19], 0);
	dd.typefont(96 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20], 0);

	//animation priority
	dd.typefont(1 * 8, 31 * 16, "priority:");
	for (i = 0; i < 19; ++i)
		dd.typefont((i * 4 + 13) * 8, 31 * 16, "", p_dev_a[P[P1].asi][dev_cai]->priority[i], 0);
	//hara x, y priority
	dd.typefont(92 * 8, 31 * 16, "", p_dev_a[P[P1].asi][dev_cai]->priority[19], 0);
	dd.typefont(96 * 8, 31 * 16, "", p_dev_a[P[P1].asi][dev_cai]->priority[20], 0);

	//angle current
	dd.typefont(1 * 8, 28 * 16, "angle_cu:");
	for (i = 0; i < 19; ++i)
		dd.typefont((i * 4 + 13) * 8, 28 * 16, "", P[P1].sk.b[i].angle, 0);
	//angle in keyframe
	dd.typefont(1 * 8, 29 * 16, "angle_kf:");
	for (i = 0; i < 19; ++i)
		dd.typefont((i * 4 + 13) * 8, 29 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[i], 0);

	//mode_a
	dd.typefont(1 * 8, 30 * 16, "mode_a:");
	for (i = 0; i < 19; ++i)
		dd.typefont((i * 4 + 13) * 8, 30 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[i], 0);
	//mode_h
//	dd.typefont(92 * 8, 30 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.x, 0);
//	dd.typefont(96 * 8, 30 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.y, 0);

	//hara x, y
	dd.typefont(92 * 8, 29 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x, 0);
	dd.typefont(96 * 8, 29 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y, 0);
	//hara x, y offset in reference to hara reference position
	if (P[P1].stance_feet == SLEFT)
	{
		dd.typefont(92 * 8, 28 * 16, "", P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x, 0);
		dd.typefont(96 * 8, 28 * 16, "", P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y, 0);
	}
	else
	{
		dd.typefont(92 * 8, 28 * 16, "", P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x, 0);
		dd.typefont(96 * 8, 28 * 16, "", P[P1].sk.p_ref->v.p[1].y - dev_hsk[1].p[0].y, 0);
	}

	//keyframe type, action, dir
	dd.typefont(44 * 8, 33 * 16, "tpe:");
	dd.typefont(44 * 8, 34 * 16, "act:");
	dd.typefont(44 * 8, 35 * 16, "dir:");
	dd.typefont(49 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].type, 0);
	dd.typefont(49 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].action, 0);
	dd.typefont(49 * 8, 35 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir, 0);

	//animation id, cycle, ui_index, ui_bias
	dd.typefont(53 * 8, 33 * 16, "id:");
//	dd.typefont(53 * 8, 34 * 16, "cyc:");
	dd.typefont(53 * 8, 35 * 16, "uii:");
	dd.typefont(53 * 8, 36 * 16, "uib:");
	dd.typefont(58 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->id, 0);
//	dd.typefont(58 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->cycle, 0);
	dd.typefont(58 * 8, 35 * 16, "", p_dev_a[P[P1].asi][dev_cai]->ui_index, 0);
	dd.typefont(58 * 8, 36 * 16, "", p_dev_a[P[P1].asi][dev_cai]->ui_bias, 0);

	//formula
	dd.typefont(66 * 8, 33 * 16, "h Xpn Ypn");
	dd.typefont(85 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->h_diffp.x, 0);
	dd.typefont(89 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->h_diffn.x, 0);
	dd.typefont(93 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->h_diffp.y, 0);
	dd.typefont(96 * 8, 33 * 16, "", p_dev_a[P[P1].asi][dev_cai]->h_diffn.y, 0);
	dd.typefont(66 * 8, 34 * 16, "a p/n:");
	dd.typefont(85 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->a_diffp[dev_bi[P1]], 0);
	dd.typefont(89 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->a_diffn[dev_bi[P1]], 0);
	dd.typefont(66 * 8, 35 * 16, "l p/n:");
	dd.typefont(85 * 8, 35 * 16, "", p_dev_a[P[P1].asi][dev_cai]->l_diffp[dev_bi[P1]], 0);
	dd.typefont(89 * 8, 35 * 16, "", p_dev_a[P[P1].asi][dev_cai]->l_diffn[dev_bi[P1]], 0);
	dd.typefont(66 * 8, 36 * 16, "w p/n:");
	dd.typefont(85 * 8, 36 * 16, "", p_dev_a[P[P1].asi][dev_cai]->w_diffp[dev_bi[P1]], 0);
	dd.typefont(89 * 8, 36 * 16, "", p_dev_a[P[P1].asi][dev_cai]->w_diffn[dev_bi[P1]], 0);

	//!!
	//valid_combo (nur extern)
	//sound_id
	//fatigue
	//fatigue_c
	//damage

/*	//sound id, fatigue, damage, special
	dd.typefont(1 * 8, 31 * 16, "sound-id fatigue damage special");
	dd.typefont(1 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->sound_id, 0);
	dd.typefont(10 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->fatigue, 0);
	dd.typefont(18 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->damage, 0);
//	dd.typefont(25 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->special, 0);*/
};

	//---- jab_hook ------------------------------------------------------------------------------

/*	if (PA[id][AN_JAB_HOOK] == AS_PRE)
	{
		al_activate_slot(aslot_action, AN_JAB_HOOK);
		p_aslot[aslot_action]->state[id]	= AS_PRE;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}
	if (PA[id][AN_JAB_HOOK] == AS_FINAL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK])
	{
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}
	if (PA[id][AN_JAB_HOOK] == AS_FINAL && p_aslot[aslot_action] != p_anmn[asi][AN_JAB_HOOK])
	{
		al_activate_slot(aslot_action, AN_JAB_HOOK);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
		p_aslot[aslot_action]->ui_valid[id] = 1;
	}
	if (PA[id][AN_JAB_HOOK] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK])
	{
		al_deactivate_slot(aslot_action);
	}*/
				//punches
				//only valid for limited amount of time
				if ((p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
					p_aslot[aslot_action] == p_anmn[asi][AN_CROSS]) &&
					power_attack[0] == 1 &&
					p_time->current <= t_power_attack[0] + p_time->freq * (0.5f / p_option->data.speed))
				{
					dam_final		+= dam_basic * 1.0f;

					//add additional fatigue
					//wird schon woanders applied
					//gl_fatigue_add(0, 0, 20.0f * p_option->data.fom_multiplier);

					//reset
					power_attack[0]		= power_attack[1]	= 0;
					t_power_attack[0]	= t_power_attack[1]	= 0;
				}
				else
				{
					//reset
					power_attack[0]		= 0;
					t_power_attack[0]	= 0;
				}

				//kicks
				if ((p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
					p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD]) &&
					power_attack[1] == 1 &&
					p_time->current <= t_power_attack[1] + p_time->freq * (0.5f / p_option->data.speed))
				{
					dam_final		+= dam_basic * 1.0f;

					//add additional fatigue
					//wird schon woanders applied
					//gl_fatigue_add(0, 0, 20.0f * p_option->data.fom_multiplier);

					//reset
					power_attack[1]		= power_attack[0]	= 0;
					t_power_attack[1]	= t_power_attack[0]	= 0;
				}
				else
				{
					//reset
					power_attack[1]		= 0;
					t_power_attack[1]	= 0;
				}


/*		//---- taunting --------------------------------------------------------------------------
		//hold special and push punch/kick

		for (p = 0; p < 2; ++p)
		{
			if (ui_state[p][SPECIAL] & 0x80)				mm_button_flag[p]		= 6;

			if (ui_state[p][SPECIAL] & 0x80 && ui_state1D[p][PUNCH] & 0x80)
//			if (ui_state1D[p][SPECIAL] & 0x80 && ui_state[p][PUNCH] & 0x80)
			{
				//so taunting isn't interrupted by simple defense
				if (ui_state[p][SPECIAL] & 0x80)
					mm_button_flag[p]		= 6;

				PA[p][AC_TAUNT1]			= AS_ACTIVE;
			}
			//taunt2
			if (ui_state[p][SPECIAL] & 0x80 && ui_state1D[p][KICK] & 0x80)
			{
				if (ui_state[p][SPECIAL] & 0x80)
					mm_button_flag[p]		= 6;

				PA[p][AC_TAUNT2]			= AS_ACTIVE;
			}
		}*/


/*			//if no other button pressed
			if ((mm_button[p] == 0) &&
				((ui_state[p][SPECIAL] & 0x80 && dimouse[p + 1].lY != 0) ||
				dimouse[p + 1].lZ != 0))
			{
				PA[p][AC_STANCE_ARMS]		= AS_ACTIVE;

				//mousewheel
				if (dimouse[p + 1].lZ)
				{
//					if (dimouse[p + 1].lZ > 0)			mm_angle_180[p]			= -2;
//					if (dimouse[p + 1].lZ < 0)			mm_angle_180[p]			= -1;
					mm_angle_180[p]				= dimouse[p + 1].lZ;
				}
				else
				{
					mm_angle[p]					= dimouse[p + 1].lY;
					//halt mouse movement
					//special key has to be released before processing mouse movement
					mm_button_flag[p]		= 6;
				}
			}*/
/*			if ((mm_button[p] == 0) &&
				((ui_state[p][SPECIAL] & 0x80 && dimouse[p + 1].lY != 0) ||
				dimouse[p + 1].lZ != 0))
			{
				mm_angle[p]					= dimouse[p + 1].lY;
				mm_angle_180[p]				= dimouse[p + 1].lZ;
				PA[p][AC_STANCE_ARMS]		= AS_ACTIVE;

				//halt mouse movement
				//special key has to be released before processing mouse movement
				if (!dimouse[p + 1].lZ)
					mm_button_flag[p]		= 6;
			}*/

/*	if (PA[id][AN_STANCE_ARMS] == AS_ACTIVE)
	{
		//if angle valid which means dimouse.lY was moved
		//angle stores value of lY
		//else angle_180 is used which holds value of lZ
		if (angle[id] != 0)
			//!! mal/durch sensitivity?
			stance_arms -= (int)(angle[id] * 0.5f);
		else
		{
			//mousewheel up
			if (angle_180[id] < 0)
			{
				if (stance_arms > 70)							stance_arms = 100;
				if (stance_arms > 30 && stance_arms <= 70)		stance_arms = 100;
				if (stance_arms <= 30)							stance_arms = 65;
			}

			//mousewheel down
			if (angle_180[id] > 0)
			{
				if (stance_arms <= 30)							stance_arms = 15;
				if (stance_arms > 30 && stance_arms <= 70)		stance_arms = 15;
				if (stance_arms > 70)							stance_arms = 65;
			}
		}

		//limit
		if (stance_arms > 100)		stance_arms = 100;
		if (stance_arms < 0)		stance_arms = 0;
	}

	//create new idle cycle for upper body with updated arm stance
	//if stance changed with lY, create cycle which first keyframe
	//is executed almost immediately to show change of arm stance
	//if stance changed with lZ, create standard (slow) cycle
	if (PA[id][AN_STANCE_ARMS] == AS_ACTIVE && angle[id] != 0 &&
		p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
	{
		al_create_idle_cycle(0, 10);
		al_activate_slot(aslot_cycle, AN_IDLE_HI);
	}
	if (PA[id][AN_STANCE_ARMS] == AS_ACTIVE && angle_180[id] != 0 &&
		p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
	{
		al_create_idle_cycle(0, 0);
		al_activate_slot(aslot_cycle, AN_IDLE_HI);
	}
	//also while walking
	if (PA[id][AN_STANCE_ARMS] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
		al_create_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
	if (PA[id][AN_STANCE_ARMS] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
		al_create_walk_cycle(AN_WALK_BWD, walk_fwd_ad / SKILL_WALK_BWD);*/

//defense
		//!!
//		if (ui_state1D[P1][DEFEND] & 0x80)
//			PA[P1][AC_DEFEND] = AS_ACTIVE;
//		if (ui_state1D[P2][DEFEND] & 0x80)
//			PA[P2][AC_DEFEND] = AS_ACTIVE;

		//!!
		//holding defend
//		if (ui_state1D[P1][DEFEND] == 0 && ui_state[P1][DEFEND] & 0x80)
//			PA[P1][AC_TAP_JAB] = AS_ACTIVE;
//		if (ui_state1D[P2][DEFEND] == 0 && ui_state[P2][DEFEND] & 0x80)
//			PA[P2][AC_TAP_JAB] = AS_ACTIVE;

//		if (ui_state1D[P1][PUNCH] & 0x80)
//			PA[P1][AC_TAP_JAB]	= AS_FINAL;
//		if (ui_state1D[P1][KICK] & 0x80)
//			PA[P1][AC_TAP_LEG]	= AS_FINAL;
		//!!! wenn nach 20ms kein winkel, dann final
		//wenn taste unten, setze startzeit
		//wenn nach t_x mm_t_start noch 0 (kein mouse input)
		//tap_jab final (bzw. active)
		//damit kein mousemovement: xxx...
		//!! bzw. wenig movement? (p_option->data.mrad_fwd)
//		if (t_ui_assigned[P1][PUNCH] >= 0.05f)
//		{
//			PA[P1][AC_TAP_JAB]			= AS_FINAL;
//		}
//		if (t_ui_assigned[P1][KICK] >= 0.05f)
//			PA[P1][AC_TAP_LEG]	= AS_FINAL;
/*		if (ui_state1D[P1][PUNCH] & 0x80 && mm_button_flag[P1] == 0)
		{
			_ts	= p_time->current;
		}

		if (_ts)
		{
			//movement kills
			if (mcx[P1] || mcy[P1])
			{
				_ts						= 0;
			}

			//release or time up
			if (_ts &&
				(ui_state[P1][PUNCH] == 0 ||
				p_time->current >= _ts + p_time->freq * _tbt))
			{
				mm_angle[P1]			= 0;
				mm_angle_180[P1]			= 89;
				PA[P1][AC_TAP_CROSS]	= AS_FINAL;
				_ts						= 0;
				mm_button_flag[P1]		= 1;
			}
		}
		if (ui_state1D[P1][KICK] & 0x80 && mm_button_flag[P1] == 0)
		{
			_ts2	= p_time->current;
		}

		if (_ts2)
		{
			//movement kills
			if (mcx[P1] || mcy[P1])
			{
				_ts2						= 0;
			}

			//release or time up
			if (_ts2 &&
				(ui_state[P1][KICK] == 0 ||
				p_time->current >= _ts2 + p_time->freq * _tbt))
			{
				mm_angle[P1]			= 0;
				mm_angle_180[P1]			= 89;
				PA[P1][AC_TAP_LEG]		= AS_FINAL;
				_ts2					= 0;
				mm_button_flag[P1]		= 2;
			}
		}*/
							//!! option.data.zoomfactor
							//set context sensitive action
							//if punch and near player and moving forward for certain amount of time
/*							if (mm_action[p] == AC_JAB &&
								abs(px[0] - px[1]) <= 87 &&
								t_move[p][1] != 0)
								mm_action[p] = AC_JAB_HOOK;
							if (mm_action[p] == AC_CROSS &&
								abs(px[0] - px[1]) <= 85 &&
								t_move[p][1] != 0)
								mm_action[p] = AC_CROSS_HOOK;*/
							//set context sensitive action
							//if kick and near player and moving forward for certain amount of time
/*							if (mm_action[p] == AC_KICK_FWD &&
								abs(px[0] - px[1]) <= 70 &&
								t_move[p][1] != 0)
								mm_action[p] = AC_KICK_FWD_KNEE;
							if (mm_action[p] == AC_KICK_SWD &&
								abs(px[0] - px[1]) <= 70 &&
								t_move[p][1] != 0)
								mm_action[p] = AC_KICK_SWD_KNEE;*/



	if (PA[id][AN_JAB] == AS_PRE)
	{
		//!!
		if (angle_180[id] <= 10)
{
			angle_180[id] = 90;
			al_activate_slot(aslot_action, AN_TAP_JAB);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[id] = 1;
}
else
{
		al_activate_slot(aslot_action, AN_JAB);
		p_aslot[aslot_action]->state[id]	= AS_PRE;
		p_aslot[aslot_action]->ui_valid[id] = 1;
}
	}

		console_r				= con_dim;

		if (con_style == 0)
		{
			console_r.p[2].y		= (float)con_dim.top;
			console_r.p[3].y		= (float)con_dim.top;
		}
		if (con_style == 1)
		{
			console_r.p[1].x		= (float)con_dim.left;
			console_r.p[2].x		= (float)con_dim.left;
		}

	//numbers
	if (dik == DIK_0)	return("0");
	if (dik == DIK_1)	return("1");
	if (dik == DIK_2)	return("2");
	if (dik == DIK_3)	return("3");
	if (dik == DIK_4)	return("4");
	if (dik == DIK_5)	return("5");
	if (dik == DIK_6)	return("6");
	if (dik == DIK_7)	return("7");
	if (dik == DIK_8)	return("8");
	if (dik == DIK_9)	return("9");

	//letters
	if (dik == DIK_A)	return("A");
	if (dik == DIK_B)	return("B");
	if (dik == DIK_C)	return("C");
	if (dik == DIK_D)	return("D");
	if (dik == DIK_E)	return("E");
	if (dik == DIK_F)	return("F");
	if (dik == DIK_G)	return("G");
	if (dik == DIK_H)	return("H");
	if (dik == DIK_I)	return("I");
	if (dik == DIK_J)	return("J");
	if (dik == DIK_K)	return("K");
	if (dik == DIK_L)	return("L");
	if (dik == DIK_M)	return("M");
	if (dik == DIK_N)	return("N");
	if (dik == DIK_O)	return("O");
	if (dik == DIK_P)	return("P");
	if (dik == DIK_Q)	return("Q");
	if (dik == DIK_R)	return("R");
	if (dik == DIK_S)	return("S");
	if (dik == DIK_T)	return("T");
	if (dik == DIK_U)	return("U");
	if (dik == DIK_V)	return("V");
	if (dik == DIK_W)	return("W");
	if (dik == DIK_X)	return("X");
	if (dik == DIK_Y)	return("Y");
	if (dik == DIK_Z)	return("Z");

	if (dik == DIK_MINUS)		return("MINUS");
	if (dik == DIK_PERIOD)		return("PERIOD");
	if (dik == DIK_SPACE)		return("SPACE");
	if (dik == DIK_ESCAPE)		return("ESC");
	if (dik == DIK_EQUALS)		return("EQU");
	if (dik == DIK_BACK)		return("BACK");
	if (dik == DIK_TAB)			return("TAB");
	if (dik == DIK_LBRACKET)	return("LBRA");
	if (dik == DIK_RBRACKET)	return("RBRA");
	if (dik == DIK_RETURN)		return("RET");
	if (dik == DIK_LCONTROL)	return("LCON");
	if (dik == DIK_RCONTROL)	return("RCON");
	if (dik == DIK_SEMICOLON)	return("SEM");
	if (dik == DIK_APOSTROPHE)	return("APOS");
	if (dik == DIK_GRAVE)		return("GRAVE");
	if (dik == DIK_LSHIFT)		return("LSHI");
	if (dik == DIK_RSHIFT)		return("RSHI");
	if (dik == DIK_BACKSLASH)	return("BSLA");
	if (dik == DIK_COMMA)		return("COMMA");
	if (dik == DIK_SLASH)		return("SLASH");
	if (dik == DIK_MULTIPLY)	return("MULTI");
	if (dik == DIK_LMENU)		return("LALT");
	if (dik == DIK_RMENU)		return("RALT");
	if (dik == DIK_CAPITAL)		return("CAP");
	if (dik == DIK_F1)	return("F1");
	if (dik == DIK_F2)	return("F2");
	if (dik == DIK_F3)	return("F3");
	if (dik == DIK_F4)	return("F4");
	if (dik == DIK_F5)	return("F5");
	if (dik == DIK_F6)	return("F6");
	if (dik == DIK_F7)	return("F7");
	if (dik == DIK_F8)	return("F8");
	if (dik == DIK_F9)	return("F9");
	if (dik == DIK_F10)	return("F10");
	if (dik == DIK_NUMLOCK)		return("NUM");
	if (dik == DIK_SCROLL)		return("SCR");
	if (dik == DIK_NUMPAD7)		return("NP7");
	if (dik == DIK_NUMPAD8)		return("NP8");
	if (dik == DIK_NUMPAD9)		return("NP9");
	if (dik == DIK_SUBTRACT)	return("NP-");
	if (dik == DIK_NUMPAD4)		return("NP4");
	if (dik == DIK_NUMPAD5)		return("NP5");
	if (dik == DIK_NUMPAD6)		return("NP6");
	if (dik == DIK_ADD)			return("NP+");
	if (dik == DIK_NUMPAD1)		return("NP1");
	if (dik == DIK_NUMPAD2)		return("NP2");
	if (dik == DIK_NUMPAD3)		return("NP3");
	if (dik == DIK_NUMPAD0)		return("NP0");
	if (dik == DIK_DECIMAL)		return("NP.");
	if (dik == DIK_OEM_102)			return("GARR");
	if (dik == DIK_F11)				return("F11");
	if (dik == DIK_F12)				return("F12");
	if (dik == DIK_NUMPADEQUALS)	return("NP=");
	if (dik == DIK_NUMPADENTER)		return("NPRET");
	if (dik == DIK_NUMPADCOMMA)		return("NP,");
	if (dik == DIK_DIVIDE)			return("NPDIV");
	if (dik == DIK_SYSRQ)			return("SYSRQ");
	if (dik == DIK_PAUSE)			return("PAUSE");
	if (dik == DIK_HOME)			return("HOME");
	if (dik == DIK_UP)				return("UP");
	if (dik == DIK_DOWN)			return("DOWN");
	if (dik == DIK_LEFT)			return("LEFT");
	if (dik == DIK_RIGHT)			return("RIGHT");
	if (dik == DIK_PRIOR)			return("PGUP");
	if (dik == DIK_END)				return("END");
	if (dik == DIK_NEXT)			return("PGDN");
	if (dik == DIK_INSERT)			return("INS");
	if (dik == DIK_DELETE)			return("DEL");
	if (dik == DIK_LWIN)			return("LWIN");
	if (dik == DIK_RWIN)			return("RWIN");
	if (dik == DIK_APPS)			return("APPS");

	//else return DEF
	return("DEF");


	//---- getinput_ascii ------------------------------------------------------------------------

	int getinput_ascii(int key, int lshift, int rshift)
	{
		//ascii code of button
		int ascii = 0;

		//space
		if (key == DIK_SPACE)	ascii = 32;

		//letters
		//if lowercase
		if (!lshift && !rshift)
		{
			//numbers
			if (key == DIK_0)	ascii = 48;
			if (key == DIK_1)	ascii = 49;
			if (key == DIK_2)	ascii = 50;
			if (key == DIK_3)	ascii = 51;
			if (key == DIK_4)	ascii = 52;
			if (key == DIK_5)	ascii = 53;
			if (key == DIK_6)	ascii = 54;
			if (key == DIK_7)	ascii = 55;
			if (key == DIK_8)	ascii = 56;
			if (key == DIK_9)	ascii = 57;

			//letters
			if (key == DIK_A)	ascii = 97;
			if (key == DIK_B)	ascii = 98;
			if (key == DIK_C)	ascii = 99;
			if (key == DIK_D)	ascii = 100;
			if (key == DIK_E)	ascii = 101;
			if (key == DIK_F)	ascii = 102;
			if (key == DIK_G)	ascii = 103;
			if (key == DIK_H)	ascii = 104;
			if (key == DIK_I)	ascii = 105;
			if (key == DIK_J)	ascii = 106;
			if (key == DIK_K)	ascii = 107;
			if (key == DIK_L)	ascii = 108;
			if (key == DIK_M)	ascii = 109;
			if (key == DIK_N)	ascii = 110;
			if (key == DIK_O)	ascii = 111;
			if (key == DIK_P)	ascii = 112;
			if (key == DIK_Q)	ascii = 113;
			if (key == DIK_R)	ascii = 114;
			if (key == DIK_S)	ascii = 115;
			if (key == DIK_T)	ascii = 116;
			if (key == DIK_U)	ascii = 117;
			if (key == DIK_V)	ascii = 118;
			if (key == DIK_W)	ascii = 119;
			if (key == DIK_X)	ascii = 120;
			if (key == DIK_Y)	ascii = 121;
			if (key == DIK_Z)	ascii = 122;

			//symbols
			if (key == DIK_COMMA)		ascii = 44;
			if (key == DIK_PERIOD)		ascii = 46;
			if (key == DIK_SLASH)		ascii = 47;
			if (key == DIK_SEMICOLON)	ascii = 59;
			if (key == DIK_MINUS)		ascii = 45;
			if (key == DIK_EQUALS)		ascii = 61;
		}
		else
		//if uppercase
		{
			//numbers
			if (key == DIK_0)	ascii = 48;
				if (key == DIK_1)	ascii = 33;
				if (key == DIK_2)	ascii = 34;
			if (key == DIK_3)	ascii = 51;
			if (key == DIK_4)	ascii = 52;
				if (key == DIK_5)	ascii = 37;
				if (key == DIK_6)	ascii = 94;
				if (key == DIK_7)	ascii = 38;
				if (key == DIK_8)	ascii = 42;
			if (key == DIK_9)	ascii = 57;

			//letters
			if (key == DIK_A)	ascii = 65;
			if (key == DIK_B)	ascii = 66;
			if (key == DIK_C)	ascii = 67;
			if (key == DIK_D)	ascii = 68;
			if (key == DIK_E)	ascii = 69;
			if (key == DIK_F)	ascii = 70;
			if (key == DIK_G)	ascii = 71;
			if (key == DIK_H)	ascii = 72;
			if (key == DIK_I)	ascii = 73;
			if (key == DIK_J)	ascii = 74;
			if (key == DIK_K)	ascii = 75;
			if (key == DIK_L)	ascii = 76;
			if (key == DIK_M)	ascii = 77;
			if (key == DIK_N)	ascii = 78;
			if (key == DIK_O)	ascii = 79;
			if (key == DIK_P)	ascii = 80;
			if (key == DIK_Q)	ascii = 81;
			if (key == DIK_R)	ascii = 82;
			if (key == DIK_S)	ascii = 83;
			if (key == DIK_T)	ascii = 84;
			if (key == DIK_U)	ascii = 85;
			if (key == DIK_V)	ascii = 86;
			if (key == DIK_W)	ascii = 87;
			if (key == DIK_X)	ascii = 88;
			if (key == DIK_Y)	ascii = 89;
			if (key == DIK_Z)	ascii = 90;

			//symbols
			if (key == DIK_SLASH)		ascii = 63;
			if (key == DIK_SEMICOLON)	ascii = 58;
			if (key == DIK_MINUS)		ascii = 95;
			if (key == DIK_EQUALS)		ascii = 43;
		}

		return(ascii);
	};


//------------------------------------------------------------------------------------------------
//
//	player con_add_message
//
//	appends 2 strings to console message string
//
//------------------------------------------------------------------------------------------------

void player::con_add_message(char *pc1, char *pc2)
{
	//valid size (plus whitespace)
	if (strlen(pc1) + strlen(pc2) + 1 > CON_LINEMAX)
		return;
	else
	//clear cdump message
		con_clear();

	//if valid
	if (pc1)
	{
		//append string 1
		strcat(con_dumpmessage, pc1);

		//2nd string only if first too
		if (pc2)
		{
			//append string 2 plus whitespace
			strcat(con_dumpmessage, " ");
			strcat(con_dumpmessage, pc2);
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player con_add_message
//
//	appends string and float to console message string
//
//------------------------------------------------------------------------------------------------

void player::con_add_message(char *pc, float f, int precision)
{
	//clear cdump message
	con_clear();

	//check precision for validity
	if (precision < 0 || precision > 12)
		precision = 2;

	//convert float into string
	int decimal		= 0;		int sign = 0;
	char *ws;
	//convert number in ws char pointer, store decimal and sign in temporary variables
	ws = _fcvt(f, precision, &decimal, &sign);

	//number string
	char numberstring[101] = "";

	//if length of ws is zero, assign '0' and null to string
	if (strlen(ws) == 0)
	{
		numberstring[0] = 48;
		numberstring[1] = 0;
	}

	//format string using decimal and sign and store it in wordstring buffer
	for (register int i = 0, k = 0; i < 101 && ws[k] != 0; ++i, ++k)
	{
		if (k == 0 && sign != 0)
		{
			numberstring[i] = '-';
			++i;
		}

		if (k == 0 && decimal <= 0)
		{
			numberstring[i] = '0';
			numberstring[i + 1] = '.';
			i += 2;

			for (register int d = 0; d < -decimal; ++d)
			{
				numberstring[i] = '0';
				++i;
			}
		}

		if (k != 0 && decimal == k)
		{
			numberstring[i] = '.';
			++i;
		}

		numberstring[i] = ws[k];
	}

	//valid size (plus whitespace)
	if (strlen(pc) + strlen(numberstring) + 1 > CON_LINEMAX)
		return;

	//if valid
	if (pc)
	{
		//append string
		strcat(con_dumpmessage, pc);
		//plus whitespace
		strcat(con_dumpmessage, " ");
	}

	//if valid
	if (numberstring)
	{
		//append float
		strcat(con_dumpmessage, numberstring);
	}
}

//------------------------------------------------------------------------------------------------
//
//	player con_add_message
//
//	appends string to message buffer
//	either with or without prespace
//
//------------------------------------------------------------------------------------------------

void player::con_add_message(char *pc, bool prespace)
{
	//valid size (plus whitespace)
	if (strlen(pc) + 1 > CON_LINEMAX)
		return;

	//whitespace
	if (prespace)
		strcat(con_dumpmessage, " ");

	//if valid
	if (pc)
	{
		//append string
		strcat(con_dumpmessage, pc);
	}
}

//------------------------------------------------------------------------------------------------
//
//	player con_add_message
//
//	appends float to message buffer
//	either with or without prespace
//
//------------------------------------------------------------------------------------------------

void player::con_add_message(float f, int precision, bool prespace)
{
	//check precision for validity
	if (precision < 0 || precision > 12)
		precision = 2;

	//convert float into string
	int decimal		= 0;		int sign = 0;
	char *ws;
	//convert number in ws char pointer, store decimal and sign in temporary variables
	ws = _fcvt(f, precision, &decimal, &sign);

	//number string
	char numberstring[101] = "";

	//if length of ws is zero, assign '0' and null to string
	if (strlen(ws) == 0)
	{
		numberstring[0] = 48;
		numberstring[1] = 0;
	}

	//format string using decimal and sign and store it in wordstring buffer
	for (register int i = 0, k = 0; i < 101 && ws[k] != 0; ++i, ++k)
	{
		if (k == 0 && sign != 0)
		{
			numberstring[i] = '-';
			++i;
		}

		if (k == 0 && decimal <= 0)
		{
			numberstring[i] = '0';
			numberstring[i + 1] = '.';
			i += 2;

			for (register int d = 0; d < -decimal; ++d)
			{
				numberstring[i] = '0';
				++i;
			}
		}

		if (k != 0 && decimal == k)
		{
			numberstring[i] = '.';
			++i;
		}

		numberstring[i] = ws[k];
	}

	//valid size (plus whitespace)
	if (strlen(numberstring) + 1 > CON_LINEMAX)
		return;

	//whitespace
	if (prespace)
		strcat(con_dumpmessage, " ");

	//if valid
	if (numberstring)
	{
		//append float
		strcat(con_dumpmessage, numberstring);
	}
}


		//update seconds
		if (current >= last_sec + freq)
		{
			++cs;
			//set last second time stamp to current time stamp
			last_sec = current;
		}


				//update winning points depending on player score
				if (P[P1].gl_score > P[P2].gl_score)
				{
					P[P1].winloss[data_ig.round - 1] = 1;
					P[P2].winloss[data_ig.round - 1] = -1;
				}
				else
				{
					//draw
					if (P[P1].gl_score == P[P2].gl_score)
					{
						P[P1].winloss[data_ig.round - 1] = 1;
						P[P2].winloss[data_ig.round - 1] = 1;
					}
					else
					//player 2 wins
					{
						P[P1].winloss[data_ig.round - 1] = -1;
						P[P2].winloss[data_ig.round - 1] = 1;
					}
				}



//------------------------------------------------------------------------------------------------
//
//	anmn_slot
//
//!!
//
//------------------------------------------------------------------------------------------------
/*
struct anmn_slot
{
	animation	*p_anmn;							//pointer to animation
	int			state;								//state of slot
													//0 = 

	//---- constructor ---------------------------------------------------------------------------

	anmn_slot()
	{
		p_anmn		= NULL;
		state		= 0;
	};
};*/

//------------------------------------------------------------------------------------------------
//
//	anmn_buffer_entry
//
//	animation buffer entry
//
//------------------------------------------------------------------------------------------------
/*
struct anmn_buffer_entry
{
	animation	*p_anmn;							//pointer to animation
	int			state[21];							//initialization state of all bones and hara
													//0 = uninitialized
													//1 = initialized

	//---- constructor ---------------------------------------------------------------------------

	anmn_buffer_entry(animation *p_anmn_ = NULL)
	{
		p_anmn	= p_anmn_;
		ZeroMemory(&state, sizeof(state));
	};

	//---- copy constructor ----------------------------------------------------------------------

	anmn_buffer_entry(const anmn_buffer_entry &aqe)
	{
		//!! correct?
		p_anmn			= aqe.p_anmn;
		for (register int i = 0; i < 21; ++i)
			state[i]	= aqe.state[i];
	};

	//---- destructor ----------------------------------------------------------------------------

	~anmn_buffer_entry()
	{
		p_anmn	= NULL;
	};
};*/

//------------------------------------------------------------------------------------------------
//
//	animation_buffer
//
//	contains pointer to animation entry array, number of entries
//	and some support functions
//
//------------------------------------------------------------------------------------------------
/*
struct animation_buffer
{
	anmn_buffer_entry	*pab;						//pointer to animation buffer array
	int					noe;						//number of entries

	//---- constructor ---------------------------------------------------------------------------

	animation_buffer()
	{
		pab		= NULL;
		noe		= 0;
	};

	//---- destructor ----------------------------------------------------------------------------

	~animation_buffer()
	{
		//delete allocated animation buffer array
		if (pab != NULL)
		{
			delete [] pab;
			pab		= NULL;
		}

		noe		= 0;
	};

	//---- add_entry -----------------------------------------------------------------------------

	bool add_entry(animation *p_a, int index = -1)			//pointer to animation to add
															//index to be new entry (including 0)
															//-1 = add to end (default)
	{
		//pointer to old animation buffer array
		anmn_buffer_entry	*poab = pab;

		//allocate new array with size + 1
		pab					= new anmn_buffer_entry[noe + 1];

		//return false if allocation fails, else true
		if (pab == NULL)
		{
			//redirect pointer to old array
			pab				= poab;
			poab			= NULL;
			return false;
		}
		else
		{
			//index of new entry, index modificator
			int ine, im = 0;
			//check index for validity
			if (index < 0 || index > noe)	ine	= noe;
			else							ine = index;

			//copy old anmn entry array data into new one
			for (register int i = 0; i < noe; ++i)
				//if index to add animation entry is reached copy data into entry
				//else copy data from old array into new one
				if (i == ine)
				{
					pab[i].p_anmn	= p_a;
					//set index modificator to 1 so that the one index which is new
					//is skipped
					im = 1;
				}
				else
					//copy data of old array into new one
					pab[i + im]		= poab[i];
					//copy state array data into new array
//					for (register int d = 0; d < 5; ++d)
//						pab[i + im].state[d]	= poab[i].state[d];

			//increase number of entries
			++noe;

			//delete old array and NULL the pointer to it
			delete	[] poab;
			poab	= NULL;

			return true;
		}
	};

	//---- del_entry -----------------------------------------------------------------------------

	//!! nicht das erste wegen idling?
	bool del_entry(int index = 0)						//including index of entry to delete
														//0 = first entry (default)
	{
		//if number of entries is only 1 delete array and NULL pointer to it
		if (noe <= 1)
		{
			if (pab != NULL)
			{
				delete [] pab;
				pab		= NULL;
				noe		= 0;
			}

			return true;
		}

		//point to old animation buffer array
		anmn_buffer_entry	*poab = pab;

		//allocate new array with size - 1
		pab					= new anmn_buffer_entry[noe - 1];

		//return false if allocation fails, else true
		if (pab == NULL)
		{
			//redirect pointer to old array
			pab				= poab;
			poab			= NULL;
			return false;
		}
		else
		{
			//index of entry to delete, index modificator
			int ide, im = 0;
			//check index for validity
			if (index < 0 || index > noe - 1)	ide = noe - 1;
			else								ide = index;

			//copy old anmn entry array data into new one
			for (register int i = 0; i < noe - 1; ++i)
			{
				//if index to delete animation entry is reached
				if (i == ide)
					//set index modificator to 1 so that the one index which is to
					//be deleted is skipped
					im = 1;

				//copy data of old array into new one
				pab[i]		= poab[i + im];

				//copy state array data into new array
//				for (register int d = 0; d < 5; ++d)
//					pab[i].state[d]	= poab[i + im].state[d];
			}

			//decrease number of entries
			--noe;

			//delete old array and NULL the pointer to it
			delete	[] poab;
			poab	= NULL;

			return true;
		}
	};
};*/


DONE:
- damage, status LUT (green-red, blue-white, var-var), for particles
schwarz-weiss: rgb in 2.55 schritten 000 000 000 - 255 255 255
gr�n-rot: 000 255 000 - 255 255 000 - 255 000 000 5.1 schritte
blau-weiss: 000 000 255 - 000 255 255 - 255 255 255 5.1 schritte

- file handling (options) open file, create if not exist, read infos from it into file-object (consists of file data), options (data) structure

	�ffne datei
	wenn nicht vorhanden --> option.data = option.dataDEF
	wenn vorhanden --> lies werte aus datei --> verify data

	am ende des programs: schreibe data object in datei, schliesse datei

options:

red on/off:
sound, vsync, show fps, shadows, bw-mode

red on sub/off:
maximum fps (off), motionblur (off)

red on sub:
background rgb, subframes, rounds, speed, fc1, fc2

red string:
n1, n2

- cursortasten w�hlen option
- enter schaltet 0/1-optionen on/off
- bei zahl-optionen schaltet enter auf den wert
- cursor hoch/runter �ndert den wert schleifenartig und im abstand von der kleinsm�glichen ver�nderung (wiederholung, sonst zu langsam?)
- links/rechts wechselt schleifenartig auf den n�chsten eintrag, falls vorhanden
- enter best�tigt den wert
- bei string geht enter rein und enter schliesst den string ab
- wenn string k�rzer als 1, dann default wert
- default setzt alle werte zur�ck auf default
- done kehrt zum titelschirm zur�ck
- credits entweder im options- oder titelmen�, scroll-fx
- & "
- title fade in

- rotating yinyang (gleich als colorindikator?)
- credits
- done
- default
sound 0/1 (nur wenn dataDEF.sound != 0) grau
vsync 0/1
fps_max 30-1000
shadows 0/1
blurtime 0 (off) - 1000 (0 als OFF)
show_fps 0/1
bw_mode 0/1
background r g b (direkt anzeigen?)
subframes

rounds
speed

name_p1
name_p2
fist_1 rgb
fist_2 rgb

/*							//load state
							FILE		*f_state = NULL;
							bone		b_def[2][19];

							f_state = fopen("animation_dev/current_sleft.amn", "rb");
							if (f_state != NULL)
							{
								//read file data into default skeleton
								for (register int i = 0; i < 19; ++i)
								{
									fscanf(f_state,
										   "%f %f %f",
										   &b_def[0][i].angle,
										   &b_def[0][i].length,
										   &b_def[0][i].width);
								}

								//close file
								fclose(f_state);
							}

							f_state = fopen("animation_dev/current_sright.amn", "rb");
							if (f_state != NULL)
							{
								//read file data into default skeleton
								for (register int i = 0; i < 19; ++i)
								{
									fscanf(f_state,
										   "%f %f %f",
										   &b_def[1][i].angle,
										   &b_def[1][i].length,
										   &b_def[1][i].width);
								}

								//close file
								fclose(f_state);
							}

							//for both players
							for (register int p = 0; p < 2; ++p)
							{
								if (P[p].side == SLEFT)
									if (P[p].stance_feet == SLEFT)
									{
										for (register int i = 0; i < 19; ++i)
										{
											P[p].sk.b[i].angle	= b_def[0][i].angle;
											P[p].sk.b[i].length	= b_def[0][i].length;
											P[p].sk.b[i].width	= b_def[0][i].width;
										}
									}
									else
									{
										for (register int i = 0; i < 19; ++i)
										{
											P[p].sk.b[i].angle	= b_def[1][i].angle;
											P[p].sk.b[i].length	= b_def[1][i].length;
											P[p].sk.b[i].width	= b_def[1][i].width;
										}
									}
								else
									if (P[p].stance_feet == SLEFT)
									{
										for (register int i = 0; i < 19; ++i)
										{
											P[p].sk.b[i].angle	= b_def[1][i].angle;
											P[p].sk.b[i].length	= b_def[1][i].length;
											P[p].sk.b[i].width	= b_def[1][i].width;
										}

										P[p].sk.b[bn].angle				= 180 - b_def[1][bn].angle;

										P[p].sk.b[btul].angle			= 180 - b_def[1][btur].angle;
										P[p].sk.b[btul].length			= b_def[1][btur].length;
										P[p].sk.b[btul].width			= b_def[1][btur].width;

										P[p].sk.b[btur].angle			= 180 - b_def[1][btul].angle;
										P[p].sk.b[btur].length			= b_def[1][btul].length;
										P[p].sk.b[btur].width			= b_def[1][btul].width;

										P[p].sk.b[btll].angle			= 180 - b_def[1][btlr].angle;
										P[p].sk.b[btll].length			= b_def[1][btlr].length;
										P[p].sk.b[btll].width			= b_def[1][btlr].width;

										P[p].sk.b[btlr].angle			= 180 - b_def[1][btll].angle;
										P[p].sk.b[btlr].length			= b_def[1][btll].length;
										P[p].sk.b[btlr].width			= b_def[1][btll].width;

										P[p].sk.b[bsl].angle			= 180 - b_def[1][bsr].angle;
										P[p].sk.b[baul].angle			= 180 - b_def[1][baur].angle;
										P[p].sk.b[ball].angle			= 180 - b_def[1][balr].angle;

										P[p].sk.b[bsr].angle			= 180 - b_def[1][bsl].angle;
										P[p].sk.b[baur].angle			= 180 - b_def[1][baul].angle;
										P[p].sk.b[balr].angle			= 180 - b_def[1][ball].angle;

										P[p].sk.b[bhl].angle			= 180 - b_def[1][bhr].angle;
										P[p].sk.b[blul].angle			= 180 - b_def[1][blur].angle;
										P[p].sk.b[blll].angle			= 180 - b_def[1][bllr].angle;
										P[p].sk.b[bfl].angle			= 180 - b_def[1][bfr].angle;

										P[p].sk.b[bhr].angle			= 180 - b_def[1][bhl].angle;
										P[p].sk.b[blur].angle			= 180 - b_def[1][blul].angle;
										P[p].sk.b[bllr].angle			= 180 - b_def[1][blll].angle;
										P[p].sk.b[bfr].angle			= 180 - b_def[1][bfl].angle;
									}
									else
									{
										for (register int i = 0; i < 19; ++i)
										{
											P[p].sk.b[i].angle	= b_def[0][i].angle;
											P[p].sk.b[i].length	= b_def[0][i].length;
											P[p].sk.b[i].width	= b_def[0][i].width;
										}

										P[p].sk.b[bn].angle				= 180 - b_def[0][bn].angle;

										P[p].sk.b[btul].angle			= 180 - b_def[0][btur].angle;
										P[p].sk.b[btul].length			= b_def[0][btur].length;
										P[p].sk.b[btul].width			= b_def[0][btur].width;

										P[p].sk.b[btur].angle			= 180 - b_def[0][btul].angle;
										P[p].sk.b[btur].length			= b_def[0][btul].length;
										P[p].sk.b[btur].width			= b_def[0][btul].width;

										P[p].sk.b[btll].angle			= 180 - b_def[0][btlr].angle;
										P[p].sk.b[btll].length			= b_def[0][btlr].length;
										P[p].sk.b[btll].width			= b_def[0][btlr].width;

										P[p].sk.b[btlr].angle			= 180 - b_def[0][btll].angle;
										P[p].sk.b[btlr].length			= b_def[0][btll].length;
										P[p].sk.b[btlr].width			= b_def[0][btll].width;

										P[p].sk.b[bsl].angle			= 180 - b_def[0][bsr].angle;
										P[p].sk.b[baul].angle			= 180 - b_def[0][baur].angle;
										P[p].sk.b[ball].angle			= 180 - b_def[0][balr].angle;

										P[p].sk.b[bsr].angle			= 180 - b_def[0][bsl].angle;
										P[p].sk.b[baur].angle			= 180 - b_def[0][baul].angle;
										P[p].sk.b[balr].angle			= 180 - b_def[0][ball].angle;

										P[p].sk.b[bhl].angle			= 180 - b_def[0][bhr].angle;
										P[p].sk.b[blul].angle			= 180 - b_def[0][blur].angle;
										P[p].sk.b[blll].angle			= 180 - b_def[0][bllr].angle;
										P[p].sk.b[bfl].angle			= 180 - b_def[0][bfr].angle;

										P[p].sk.b[bhr].angle			= 180 - b_def[0][bhl].angle;
										P[p].sk.b[blur].angle			= 180 - b_def[0][blul].angle;
										P[p].sk.b[bllr].angle			= 180 - b_def[0][blll].angle;
										P[p].sk.b[bfr].angle			= 180 - b_def[0][bfl].angle;
									}
							}*/
keyframe:

	int			t_frame[21];
	point			hara;
	float		angle[19];						//destination angle for all bones
	float		length[19];						//destination length for all bones
	float		width[19];						//destination width for all bones
	int			mode_a[19];						//mode of angle
	int			type;							//0 = standard keyframe
												//1 = buffer keyframe
												//2 = stance_feet change
												//3 = side change

	int			action;							//0 = passive
												//1 = active

	int			dir;							//0 = forward
												//1 = backward

	//---- runtime data --------------------------------------------------------------------------
	//for both players

	float		*p_pba[2][19];					//const pointer to adjusted angle of parent bone

	LONGLONG	t_kfstart[2][21];				//start time of keyframe for both players, each bone and hara

	int			state[2][21];					//state of keyframe for both players for all bones and hara
												//0 = uninitialized
												//1 = initialized
												//2 = done

	float		angle_ad[2][19];				//adjusted angle/length/width in reference to
	float		length_ad[2][19];				//animation side index and formula
	float		width_ad[2][19];

	point		hara_ad[2];						//same for hara
	point		hara_r[2];						//holds to covered distance of hara.x

	point		speed_h[2];						//hara speed in pixel per second

	float		speed_a[2][19];					//speed of angle change in degrees per second
	float		speed_l[2][19];					//speed of length change in pixel per second
	float		speed_w[2][19];					//speed of width change in pixel per second


ANIMATION:
	int			id;								//id of animation

	keyframe	*pkf;							//pointer to array of keyframes
	int			nokf;							//number of keyframes of animation

//	int			valid_combo[NPAN];				//0 = void
												//1 = valid
												//2 = valid if active and backwards

	int			priority[21];					//priority level for all bones plus hara (x, y)

	//!!! repeat
	int			type;							//type of animation
												//0 = standard
												//1 = cycling (idling, walking)

	int			ui_index;						//index of bone which gets user input value
												//if negative the positive index counts
												//but the user input angle gets mirrored

	//---- formula -------------------------------------------------------------------------------
	//the end position of a bone sometimes depends on the user input
	//_ri is the index of the keyframe which bone acts as reference
	//this bones data is used either as minimum or maximum data value
	//_diffp is the positive maximum difference from the reference position
	//_diffn is the negtaive maximum difference from the reference position
	//the runtime _ad data of each keyframe holds the adjusted position
	//of each bone in reference to the user input
	//the formula is used for every keyframe of the animation
	//
	//formula:
	//kf[_ri].pos +/- (_diff.pos / max_value (= 90)) * value
	//neg: value = value
	//pos: value = value - 90

	int			a_ri[19];						//formula reference keyframe index
												//takes value of this bone as minimum/maximum
	int			a_diffp[19];					//positve difference to reference value for every bone
												//0 = formula not used (default)
	int			a_diffn[19];					//negtaive difference to reference value for every bone

	int			l_ri[19];						//same for length and width, hara
	int			l_diffp[19];
	int			l_diffn[19];
	int			w_ri[19];
	int			w_diffp[19];
	int			w_diffn[19];

	int			h_ri;
	point		h_diffp;
	point		h_diffn;

	//---- gameplay data -------------------------------------------------------------------------

	int			sound_id;						//sound id to be played (starting when animation starts)
	int			fatigue;						//basic fatigue the animation causes, applied either after animation
												//is done (non-attacking) or on the way back (attacking)
	int			fatigue_c;						//applied fatigue if animation canceled (punch, kick, etc.)
	int			damage;							//basic damage the animation causes

	//---- runtime data --------------------------------------------------------------------------

	int		state[2];							//state of animation in animation buffer
												//0			= uninitialized
												//1			= initialized
												//AS_DONE	= done

	int		ui_valid[2];						//if angle/angle_180 valid
	int		angle[2];							//inputstate angle
	int		angle_180[2];						//inputstate angle with values from 0 to 179 only//------------------------------------------------------------------------------------------------
//
//	keyframe_ old version
//
//------------------------------------------------------------------------------------------------

struct keyframe_
{
	/*
	int			t_frame;						//still required?
	LONGLONG	t_kfstart;						//still required?

	point		hara;							//hara destination offset
	point		hara_t;							//adjusted hara target for forward/backward animation
	point		hara_r;							//hara reference position
	point		speed_h;						//speed of hara position change in pixel per second
												//(for both axis)
	int			priority_h;						//hara priority
//	point		hara_absolut?

	float		angle[19];						//destination angle of all bones
	float		length[19];						//destination length of all bones
	float		width[19];						//destination width of all bones

	float		speed_a[19];					//speed of angle change in degrees per second
	float		speed_l[19];					//speed of length change in pixel per second
	float		speed_w[19];					//speed of width change in pixel per second

	int			mode_a[19];						//mode of angle
												//0 = absolute
												//1 = relative to parent bone
												//2 = relative to current angle

	int			type;							//0 = standard
												//1 = buffer keyframe for attacks
												//2 = x

	int			state;							//0 = passive
												//1 = active
	int			dir;							//direction, 0 = forward, 1 = backward
	*/
	int			id;								//id of animation (defined)
	int			index;							//number of keyframes per animation, excluding 0
	int			state;							//0 = uninitialized (to calculate speed of changes)
												//1 = initialized
												//2 = keyframe done
	int			dir;							//direction of keyframe, 0 = forward, 1 = backward

	int			t_frame;						//time in milliseconds for duration of keyframe
	LONGLONG	t_kfstart;						//starttime of keyframe

	point		hara;							//hara destination offset
	point		hara_t;							//adjusted hara target for forward/backward animation
	point		hara_r;							//hara reference position
	point		speed_h;						//speed of hara position change in pixel per second
												//(for both axis)

	float		angle[19];						//destination angle of all bones
	float		length[19];						//destination length of all bones
	float		width[19];						//destination width of all bones
	float		speed_a[19];					//speed of angle change in degrees per second
	float		speed_l[19];					//speed of length change in pixel per second
	float		speed_w[19];
	int			mode_a[19];						//angle relativ to parent bone (1) or absolute (0)

	//---- constructor ---------------------------------------------------------------------------

	keyframe_()
	{
		id			= 0;
		index		= 0;
		state		= 0;
		dir			= 0;
		//default to 100 so no dividing through 0 if animator is callid with empty keyframe
		t_frame		= 100;
		t_kfstart	= 0;

		speed_h		= 0;

		for (register int i = 0; i < 19; ++i)
		{
			angle[i]		= 0;		speed_a[i]		= 0;
			length[i]		= 0;		speed_l[i]		= 0;
			width[i]		= 0;		speed_w[i]		= 0;

			mode_a[i]		= 0;
		}
	};

	//load
};

//------------------------------------------------------------------------------------------------
//
//	player animator
//
//	!!!!
//	interpolates angle, length and width of bone between current
//	position and keyframe target position
//	rotates bones in shortest direction
//
//------------------------------------------------------------------------------------------------

/*void player::animator(LONGLONG t_freq,
					  LONGLONG t_current,
					  float t_sca,
					  float s_speed)
{
	/*
		animation state: uninitialized (0), initilized (1)
		f�r jedes keyframe den stated

};*/

//------------------------------------------------------------------------------------------------
//
//	player animator_ old version
//
//	interpolates angle, length and width of bone between current
//	position and keyframe target position
//	rotates bones in shortest direction
//
//------------------------------------------------------------------------------------------------
//!! rausnehmen
int player::animator_(keyframe_ *kf,						//pointer to keyframe
					 LONGLONG t_freq,						//timer frequency
					 LONGLONG t_current,					//current time
					 float t_sca,							//passed time since last update
					 float s_speed)							//user defined speed of game
/*
	- umrechnen der stellung, seitenwechsel inmitten eines keyframes?
	- zur�ckschleudern
	- keyframe/animation abgeschlossen
	- animation fx ausl�sen (aktiv, fatigue)
- enth�lt member variablen f�r:
  status der animation (hin/zur�ck/buffer, wieviel von wieviel frames)
  status der slots (ini, running, idling, done)
  geschwindigkeit der bones wird durch aom und zustand beeinflusst und nur pro animation berechnet (nicht zwischen keyframes), daten werden in den member variablen abgelegt
- addiert gewicht und l�ngenmodifikator zu den werten
- 6 unabh�ngige slots f�r 4 gliedmassen, torso inklusive kopf und haraposition
- ist ein keyframe komplett (winkel, l�nge und breite entsprechen den vorgaben) wird das n�chste keyframe der animation ausgef�hrt (f�r jeden slot unabh�ngig voneinander). ist eine animation abgeschlossen, wird die n�chste animation im animation-queue ausgef�hrt
*/
{
	//animation referenz �bergabe
	//5 slots (enum)
	//state of slots (6), r�ckgabewert
	//bone zur�ckschleudern
	//animation in abh�ngigkeit von seite
	//kopie von keyframe-daten zur manipulation (auch zur �nderung der seite)
	//
	//in bone schreiben, wenn aktiv?

	//---- initializing --------------------------------------------------------------------------

	//if not yet initialized
	if (kf->state == 0)
	{
		//set to initialized
		kf->state = 1;

		//set start time of keyframe
		kf->t_kfstart = t_current;

		//player 1
		if (id == 0)
		{
		//for every bone calculate speed of change
		//use speed-arrays to store difference int angle, lenght and width
		for (register int i = 0; i < 19; ++i)
		{
			//current angle <= target angle
			//ac <= at
			if (sk.b[i].angle <= kf->angle[i])
			{
				//distance in positive direction smaller/equal to 180
				//rotate angle in positive direction
				//ac=====>at
				if (kf->angle[i] - sk.b[i].angle <= 180)
					kf->speed_a[i] = kf->angle[i] - sk.b[i].angle;
				else
					//rotate in negativ direction
					//<==ac-----at<==
					kf->speed_a[i] = sk.b[i].angle + (360 - kf->angle[i]);
			}
			else
			//current angle > target angle
			//ac > at
			{
				//distance in positive direction smaller
				//==>at-----ac==>
				if (sk.b[i].angle - kf->angle[i] > 180)
					kf->speed_a[i] = (360 - sk.b[i].angle) + kf->angle[i];
				else
					//rotate in negative direction
					//at<=====ac
					kf->speed_a[i] = sk.b[i].angle - kf->angle[i];
			}

			//angle change speed is difference times keyframe time
			kf->speed_a[i] = kf->speed_a[i] * (1000 / kf->t_frame);

			//length change speed
			kf->speed_l[i] = -(sk.b[i].length - kf->length[i]) * (1000 / kf->t_frame);

			//width change speed
			kf->speed_w[i] = -(sk.b[i].width - kf->width[i]) * (1000 / kf->t_frame);
		}

		//hara reference
		kf->hara_r.x = 0;
		kf->hara_r.y = 0;

		//forward animation
		if (kf->dir == 0)
			kf->hara_t = kf->hara;
		else
		{
			//backward animation
			kf->hara_t.x = -kf->hara.x;
			kf->hara_t.y = -kf->hara.y;
		}

		//hara position change speed
		kf->speed_h.x = ((sk.p_ref->v.p[0].x + kf->hara_t.x) - sk.p_ref->v.p[0].x) * (1000 / kf->t_frame);
		kf->speed_h.y = ((sk.p_ref->v.p[0].y + kf->hara_t.y) - sk.p_ref->v.p[0].y) * (1000 / kf->t_frame);
		}
		else
		//player 2
		{
		//for every bone calculate speed of change
		//use speed-arrays to store difference int angle, lenght and width
		for (register int i = 0; i < 19; ++i)
		{
			//current angle <= target angle
			//ac <= at
			if (sk.b[i].angle <= 180 - kf->angle[i])
			{
				//distance in positive direction smaller/equal to 180
				//rotate angle in positive direction
				//ac=====>at
				if ((180 - kf->angle[i]) - sk.b[i].angle <= 180)
					kf->speed_a[i] = (180 - kf->angle[i]) - sk.b[i].angle;
				else
					//rotate in negativ direction
					//<==ac-----at<==
					kf->speed_a[i] = sk.b[i].angle + (360 - (180 - kf->angle[i]));
			}
			else
			//current angle > target angle
			//ac > at
			{
				//distance in positive direction smaller
				//==>at-----ac==>
				if (sk.b[i].angle - (180 - kf->angle[i]) > 180)
					kf->speed_a[i] = (360 - sk.b[i].angle) + (180 - kf->angle[i]);
				else
					//rotate in negative direction
					//at<=====ac
					kf->speed_a[i] = sk.b[i].angle - (180 - kf->angle[i]);
			}

			//angle change speed is difference times keyframe time
			kf->speed_a[i] = kf->speed_a[i] * (1000 / kf->t_frame);

			//length change speed
			kf->speed_l[i] = -(sk.b[i].length - kf->length[i]) * (1000 / kf->t_frame);

			//width change speed
			kf->speed_w[i] = -(sk.b[i].width - kf->width[i]) * (1000 / kf->t_frame);
		}

		//hara reference
		kf->hara_r.x = 0;
		kf->hara_r.y = 0;

		//forward animation
		if (kf->dir == 0)
			kf->hara_t = kf->hara;
		else
		{
			//backward animation
			kf->hara_t.x = -kf->hara.x;
			kf->hara_t.y = -kf->hara.y;
		}

		//hara position change speed
		kf->speed_h.x = ((sk.p_ref->v.p[0].x + kf->hara_t.x) - sk.p_ref->v.p[0].x) * (1000 / kf->t_frame);
		kf->speed_h.y = ((sk.p_ref->v.p[0].y + kf->hara_t.y) - sk.p_ref->v.p[0].y) * (1000 / kf->t_frame);
		}
	}

	//---- interpolation -------------------------------------------------------------------------

	//!! der ganze else shit kann raus, wenn es am ende eh neu gemacht wird
	//!! genauso wie der int scheiss
	//!!! temp variable zum ergebniss speichern, damit nur einmal berechnet?
	//for every bone
	if (id == P1)
	{
	for (register int i = 0; i < 19; ++i)
	{
		//if current angle is not target angle (integer precision)
		if ((int)sk.b[i].angle != (int)kf->angle[i])
		{
			//ac <= at
			if (sk.b[i].angle <= kf->angle[i])
			{
				if (kf->angle[i] - sk.b[i].angle <= 180)
				{
					//ac=====>at
					if (sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= kf->angle[i])
						sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
				else
				{
					//<==ac-----at<==
					if (sk.b[i].angle < kf->angle[i] || sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= kf->angle[i])
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
			}
		else
		{
			//at > ac
			if (sk.b[i].angle - kf->angle[i] > 180)
			{
				//==>at-----ac==>
				if (sk.b[i].angle > kf->angle[i] || sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= kf->angle[i])
					sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = kf->angle[i];
			}
			else
			{
				//at<=====ac
				if (sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= kf->angle[i])
					sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = kf->angle[i];
			}
		}

		//check angle for limits
		if (sk.b[i].angle < 0)		sk.b[i].angle += 360;
		if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;

		//length
		if (kf->speed_l[i] > 0)
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed <= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];
		else
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed >= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];

		//width
		if (kf->speed_w[i] > 0)
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed <= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		else
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed >= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		}
	}
	}
	else
	//player 2
	{
	for (register int i = 0; i < 19; ++i)
	{
		//if current angle is not target angle (integer precision)
		if ((int)sk.b[i].angle != (int)(180 - kf->angle[i]))
		{
			//ac <= at
			if (sk.b[i].angle <= 180 - kf->angle[i])
			{
				if ((180 - kf->angle[i]) - sk.b[i].angle <= 180)
				{
					//ac=====>at
					if (sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= 180 - kf->angle[i])
							sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = 180 - kf->angle[i];
				}
				else
				{
					//<==ac-----at<==
					if (sk.b[i].angle < 180 - kf->angle[i] || sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= 180 - kf->angle[i])
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = 180 - kf->angle[i];
				}
			}
		else
		{
			//at > ac
			if (sk.b[i].angle - (180 - kf->angle[i]) > 180)
			{
				//==>at-----ac==>
				if (sk.b[i].angle > 180 - kf->angle[i] || sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= 180 - kf->angle[i])
					sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = 180 - kf->angle[i];
			}
			else
			{
				//at<=====ac
				if (sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= 180 - kf->angle[i])
					sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = 180 - kf->angle[i];
			}
		}

		//check angle for limits
		if (sk.b[i].angle < 0)		sk.b[i].angle += 360;
		if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;

		//length
		if (kf->speed_l[i] > 0)
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed <= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];
		else
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed >= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];

		//width
		if (kf->speed_w[i] > 0)
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed <= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		else
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed >= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		}
	}
	}

	//hara x-axis
	if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed != kf->hara_t.x)
	{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
	}

	//hara y-axis
	if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed != kf->hara_t.y)
	{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
	}

/*	if (kf->speed_h.x > 0)
		if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed <= kf->hara_t.x)
		{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
		}
	else
		if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed >= kf->hara_t.x)
		{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
		}*/

/*	//hara y-axis
	if (kf->speed_h.y > 0)
		if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed <= kf->hara_t.y)
		{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
		}
	else
		if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed >= kf->hara_t.y)
		{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
		}*/

	//--------------------------------------------------------------------------------------------

	//return 0 if keyframe is not done and 1 if so
	if (t_current <= kf->t_kfstart + (t_freq / (1000 / kf->t_frame) / s_speed))
		//keyframe not done
		return(0);
	else
	{
		//reset state
		kf->state = 0;

		//set hara to target
		kf->hara_r.x		= kf->hara_t.x - kf->hara_r.x;
		sk.p_ref->v.p[0].x	+= kf->hara_r.x;
		kf->hara_r.y		= kf->hara_t.y - kf->hara_r.y;
		sk.p_ref->v.p[0].y	+= kf->hara_r.y;

		if (id == P1)
		{
		//set all bones to target positions
		for (register int i = 0; i < 19; ++i)
		{
			//angle
			sk.b[i].angle = kf->angle[i];
			//length
			sk.b[i].length = kf->length[i];
			//width
			sk.b[i].width = kf->width[i];
		}
		}
		else
		{
		//set all bones to target positions
		for (register int i = 0; i < 19; ++i)
		{
			//angle
			sk.b[i].angle = 180 - kf->angle[i];
			//length
			sk.b[i].length = kf->length[i];
			//width
			sk.b[i].width = kf->width[i];
		}
		}

		//keyframe done
		return(1);
	}
}

/*	//!! ats raus
	//for every bone
	for (i = 0; i < 19; ++i)
	{
		float ac = sk.b[i].angle;
		float at = kf->angle[i];

		if ((int)ac != (int)at)
		{
			//ac-----at
			if (sk.b[i].angle <= kf->angle[i])
			{
				if (kf->angle[i] - sk.b[i].angle <= 180)
				{
					//ac=====>at
					if (ac + kf->speed_a[i] * t_sca * s_speed <= at)
							sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
				else
				{
					//<==ac-----at<==
					if (ac < at || ac - kf->speed_a[i] * t_sca * s_speed >= at)
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
			}
			else
			//at-----ac
			{
				if (sk.b[i].angle - kf->angle[i] > 180)
				{
					//==>at-----ac==>
					if (ac > at || ac + kf->speed_a[i] * t_sca * s_speed <= at)
						sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
				else
				{
					//at<=====ac
					if (ac - kf->speed_a[i] * t_sca * s_speed >= at)
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
			}

			if (sk.b[i].angle < 0)		sk.b[i].angle += 360;
			if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;
		}
	}*/
	
/*		for (register int b = 0; b < 19; ++b)
			if (sk.b[b].angle == p_aslot[casi[b]]->pkf[cki[b]].angle_ad[id][b] &&
				sk.b[b].length == p_aslot[casi[b]]->pkf[cki[b]].length_ad[id][b] &&
				sk.b[b].width == p_aslot[casi[b]]->pkf[cki[b]].width_ad[id][b])
				if (cki[b] < p_aslot[casi[b]]->nokf - 1)
				{
					//reset keyframe state for this bone, increase keyframe
					p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
					++cki[b];
				}
				else
				{
					//reset keyframe for this bone, set keyframe to first
//					p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
//					cki[b] = 0;
				}
		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x == 0)
			if (cki[IHX] < p_aslot[casi[IHX]]->nokf - 1)
			{
				//reset keyframe state for this bone, increase keyframe
				p_aslot[casi[IHX]]->pkf[cki[IHX]].state[id][IHX] = 0;
				++cki[IHX];
			}
			else
			{
				//reset keyframe for this bone, set keyframe to first
//				p_aslot[casi[IHX]]->pkf[cki[IHX]].state[id][IHX] = 0;
//				cki[IHX] = 0;
			}
		if (sk.p_ref->v.p[0].y == S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y)
			if (cki[IHY] < p_aslot[casi[IHY]]->nokf - 1)
			{
				//reset keyframe state for this bone, increase keyframe
				p_aslot[casi[IHY]]->pkf[cki[IHY]].state[id][IHY] = 0;
				++cki[IHY];
			}
			else
			{
				//reset keyframe for this bone, set keyframe to first
//				p_aslot[casi[IHY]]->pkf[cki[IHY]].state[id][IHY] = 0;
//				cki[IHY] = 0;
			}*/




/*		//for both slots
		for (s = 0; s < 2; ++s)
			//for all priorities
			for (register int p = 0; p < 21; ++p)
				//for all bones
				for (register int b = 0; b < 21; ++b)
					//if prioritiy of slot s to advance
					//and current bone is of this slot
					//and priority of current bone is of current priority
					if (bac[s][p] == true &&
						casi[b] == p &&
						p_aslot[casi[b]]->priority[b] == p)
					{
						//if current keyframe index of bone is smaller than number of kf in this animation
						if (cki[b] < p_aslot[casi[b]]->nokf - 1)
						{
							//reset keyframe state for this bone, increase keyframe
							p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
							++cki[b];
						}
						else
						{
							//reset keyframe state for this bone, increase keyframe
							p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
						}

						bac[s][p] = false;
					}*/
/*			//for all priorities
			for (register int p = 0; p < 21; ++p)
				//for all bones
				for (register int b = 0; b < 21; ++b)
					//if slot valid pointer to animation
					if (p_aslot[casi[b]] != NULL)
						//if all bones with this prioritiy in this slot are done
						//and this bone is of this priority and slot
						if (bpc[casi[b]][p] == bdc[casi[b]][p] &&
							p_aslot[casi[b]]->priority[b] == p &&
							casi[b] == s)
							//if current keyframe index of bone is smaller than number of
							//keyframes in this animation
							if (cki[b] < p_aslot[casi[b]]->nokf - 1)
							{
								//reset keyframe state for this bone, increase keyframe
								p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
								++cki[b];
							}
							else
							{
								//reset keyframe for this bone, set keyframe to first
								//p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
								//cki[b] = 0;

								//!!
								//p_aslot[0] = NULL;
							}*/

		//!!
		//animation states setzen
		//keyframe done: alle bones derselben animation und derselben priorit�t abgeschlossen

/*		//for all priorities
		for (p = 0; p < 21; ++p)
		{
			//if number of bones with prioritiy p is same as number of bones with priority p
			//which are done
			if (bpc[0][p] == bdc[0][p])
			{
				//for every bone and hara.x/y
				for (register int i = 0; i < 21; ++i)
				{
					//if priority of bone is current priority
					if (p_aslot[casi[i]]->priority[i] == p)
					{
						if (cki[i] < p_aslot[casi[i]]->nokf - 1)
						{
							p_aslot[casi[i]]->pkf[cki[i]].state[id][i] = 0;
							++cki[i];
						}
						else
						{
							p_aslot[casi[i]]->pkf[cki[i]].state[id][i] = 0;
							cki[i] = 0;
							p_aslot[casi[i]]->pkf[cki[i]].state[id][i] = 0;
						}
					}
				}
			}

			bdc[0][p] = 0;
		}*/

		//---- advance animation -----------------------------------------------------------------
/*
		//check priority
		//for every bone and hara.x/y
		for (register int i = 0; i < 21; ++i)
		{
			//if priority of cylce slot is bigger than priority of action slot
			if (p_aslot[aslot_cycle]->priority[i] >
				p_aslot[aslot_action]->priority[i])
				//assign bone to cylce slot, else to action slot
				casi[i] = aslot_cycle;
			else
				casi[i] = aslot_action;
		}

		//for every priority
		for (i = 0
			//for every bone
			for (i = 0; i < 19; ++i)
			{
				if (sk.b[i].angle == panmn[ai]->pkf[cki[0]].angle_ad[id][i])
					if (sk.b[i].length == panmn[ai]->pkf[cki[0]].length_ad[id][i])
						if (sk.b[i].width == panmn[ai]->pkf[cki[0]].width_ad[id][i])
						{
							++cki[1];
							//sk.b[i].damage = 50;
						}
/*						else
							sk.b[i].damage = 0;
					else
						sk.b[i].damage = 0;
				else
					sk.b[i].damage = 0;*/
//			}
//			if (cki[1] != 19)
//				cki[1] = 0;

			//!!! hara
/*			if (cki[1] == 19 &&
//				panmn[ai]->pkf[cki[0]].hara_r[id].x == 0 &&
				sk.p_ref->v.p[0].y == 298 + panmn[ai]->pkf[cki[0]].hara_ad[id].y)
			{
		//nach check der neuen animatioenen: nna = 0;*/



						//---- first keyframe ------------------------------------------------------------

		/*				if (cki[i] == 0)
		//!!			if (false)
						{
							//---- angle -----------------------------------------------------------------

							//current angle <= target angle
							//ac <= at
		/*					if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i])
							{
								//distance in positive direction is smaller/equal to 180 degree
								//rotate angle in positive direction
								//ac====>at
								if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i];
								else
								//rotate in negative direction
								//<==ac----at<==
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i]);
							}
							else
							//current angle > target angle
							//ac > at
							{
								//distance in positive direction smaller
								//==>at----ac==>
								if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] > 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = (360 - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i];
								else
								//rotate in negative direction
								//at<====ac
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i];
							}*/
		/*					if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
							{
								//distance in positive direction is smaller/equal to 180 degree
								//rotate angle in positive direction
								//ac====>at
								if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i];
								else
								//rotate in negative direction
								//<==ac----at<==
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]);
							}
							else
							//current angle > target angle
							//ac > at
							{
								//distance in positive direction smaller
								//==>at----ac==>
								if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = (360 - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
								else
								//rotate in negative direction
								//at<====ac
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
							}

							//angle change speed is difference times keyframe time
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

							//---- length, width ---------------------------------------------------------

							//!!
							//dasselbe problem bei winkel?
							p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].length[i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].length[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
							//if speed is 0 calculate speed with adjusted data
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] == 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].length[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
							p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].width[i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].width[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] == 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].width[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

							//---- check speed -----------------------------------------------------------
							//if speed smaller than 1 | -1 set speed to 90 | 5

							if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] < 1)
								p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = 90;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] < 1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] >= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = 5;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] > -1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] <= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = -5;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] < 1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] >= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = 5;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] > -1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] <= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = -5;
						}
						else
						//---- not first keyframe --------------------------------------------------------
						{
							//---- angle -----------------------------------------------------------------

							//current angle <= target angle
							//ac <= at
		/*					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i])
							{
								//distance in positive direction is smaller/equal to 180 degree
								//rotate angle in positive direction
								//ac====>at
								if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] - sk.b[i].angle <= 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] - sk.b[i].angle;
								else
								//rotate in negative direction
								//<==ac----at<==
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i]);
							}
							else
							//current angle > target angle
							//ac > at
							{
								//distance in positive direction smaller
								//==>at----ac==>
								if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i] > 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = (360 - sk.b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i];
								else
								//rotate in negative direction
								//at<====ac
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_def[id][i];
							}*/
		/*					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
							{
								//distance in positive direction is smaller/equal to 180 degree
								//rotate angle in positive direction
								//ac====>at
								if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle <= 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle;
								else
								//rotate in negative direction
								//<==ac----at<==
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]);
							}
							else
							//current angle > target angle
							//ac > at
							{
								//distance in positive direction smaller
								//==>at----ac==>
								if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 180)
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = (360 - sk.b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
								else
								//rotate in negative direction
								//at<====ac
									p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
							}

							//angle change speed is difference times keyframe time
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

							//---- length, width ---------------------------------------------------------

							p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].length[i] - sk.b[i].length) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
							p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].width[i] - sk.b[i].width) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

							//---- check speed -----------------------------------------------------------
							//if speed smaller than 1 | -1 set speed to 90 | 5

							if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] < 1)
								p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = 90;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] < 1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] >= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = 5;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] > -1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] <= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = -5;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] < 1 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] >= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = 1;
							if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] > -5 &&
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] <= 0)
								p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = -5;
						}*/

//old animator
/*	//---- player data ---------------------------------------------------------------------------

	int						*P;									//pointer to player id (0 = P1, 1 = P2)
	int						*p_asi;								//pointer to animation side index
																//left side, left foot forward = 0
																//left side, right foot forward = 1
																//right side, left foot forward = 2
																//right side, right foot forward = 3

	skeleton				*p_sk;								//pointer to player skeleton


	//---- constructor ---------------------------------------------------------------------------

	player_animator()
	{
		P				= NULL;
		p_asi			= NULL;

		p_sk			= NULL;

		for (register int s = 0; s < 2; ++s)
			for (register int i = 0; i < NPAN; ++i)
				p_anmn[s][i]	= NULL;
		p_aslot[0]		= p_aslot[1]	= NULL;

		t_freq			= 0;

		new_anmn		= -1;

		ZeroMemory(&casi, sizeof(casi));
		ZeroMemory(&cki, sizeof(cki));

		//!! reset runtime data
		ZeroMemory(&bpc, sizeof(bpc));
		ZeroMemory(&bdc, sizeof(bdc));
		ZeroMemory(&bhi, sizeof(bhi));
	};

	//---- initialization ------------------------------------------------------------------------

	void initialization(LONGLONG _t_freq,
						int *_p,
						int *_p_asi,
						skeleton *psk)
	{
		t_freq	= _t_freq;

		P			= _p;
		p_asi		= _p_asi;

		p_sk		= psk;
	};

	//---- reset_runtime_data --------------------------------------------------------------------

	void reset_runtime_data(int p)
	{
	};

	//---- animate -------------------------------------------------------------------------------
	//main function of the animator

	int animate(LONGLONG t_current,						//current time index
				float t_sca,								//time passed since last update
				float s_speed,								//user set speed factor
				float s_zoom)								//user set zoom factor
	{
		//!!
		if (p_aslot[aslot_cycle] == NULL &&	p_aslot[aslot_action] == NULL)
			return(0);

		//for every bone
		for (register int i = 0; i < 19; ++i)
		{
			//---- initialization ----------------------------------------------------------------

			//if uninitialized, initialize
			if (p_aslot[casi[i]]->pkf[cki[i]].state[*P][i] == 0)
			{
				//set keyframe state of bone to initialized
				p_aslot[casi[i]]->pkf[cki[i]].state[*P][i] = 1;

				//set start time of keyframe for bone
				p_aslot[casi[i]]->pkf[cki[i]].t_kfstart[*P][i] = t_current;

				//---- set adjusted data ---------------------------------------------------------

				//set to default angle, length, width
				p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]	= p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i]
																= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].angle[i];
				//if not first keyframe also create angle_def of previous keyframe (could be
				//it doesn't already exist)
				if (cki[i] != 0)	p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] = (float)(int)p_aslot[casi[i]]->pkf[cki[i] - 1].angle[i];

				p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].length[i];
				p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].width[i];

				//apply zoom factor
				p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i]	*= s_zoom;
				p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i]	*= s_zoom;

				//set mode_a for default speed angle
				//(relative to parent)
				if (p_aslot[casi[i]]->pkf[cki[i]].mode_a[i] == 1)
					//pointer to adjusted angle of parent bone not NULL (lower torso)
					if (p_aslot[casi[i]]->pkf[cki[i]].p_pba[i] != NULL)
					{
						//set default speed angle
						p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] +=
							*p_aslot[casi[i]]->pkf[cki[i]].p_pba[*P][i];
					}
				//same for previous keyframe
				if (cki[i] != 0)
					if (p_aslot[casi[i]]->pkf[cki[i] - 1].mode_a[i] == 1)
						//pointer to adjusted angle of parent bone not NULL (lower torso)
						if (p_aslot[casi[i]]->pkf[cki[i] - 1].p_pba[i] != NULL)
						{
							//set default speed angle
							p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] +=
								*p_aslot[casi[i]]->pkf[cki[i] - 1].p_pba[*P][i];
						}

				if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] -= 360;
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] += 360;

				//apply diff angle
				//if diffn not 0 and user input angle lower than 90 degree
				if (p_aslot[casi[i]]->a_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[*P] < 90)
				{
					//adjusted angle is max difference from absolute angle position
					//factored by user input angle
					p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] =
						p_aslot[casi[i]]->pkf[cki[i]].angle[i] +
						(p_aslot[casi[i]]->a_diffn[i] / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[*P]);
				}
				if (p_aslot[casi[i]]->a_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[*P] >= 90)
				{
					p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] =
						p_aslot[casi[i]]->pkf[cki[i]].angle[i] +
						(p_aslot[casi[i]]->a_diffp[i] / 89.0f) * (p_aslot[casi[i]]->angle_180[*P] - 90);
				}
				//check angle_ad doesn't exceed its limit
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] -= 360;
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] += 360;

				//apply diff length
				if (p_aslot[casi[i]]->l_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[*P] < 90)
				{
					p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i] =
						(p_aslot[casi[i]]->pkf[cki[i]].length[i] * s_zoom) +
						(p_aslot[casi[i]]->l_diffn[i] * s_zoom / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[*P]);
				}
				if (p_aslot[casi[i]]->l_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[*P] >= 90)
				{
					p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i] =
						(p_aslot[casi[i]]->pkf[cki[i]].length[i] * s_zoom) +
						(p_aslot[casi[i]]->l_diffp[i] * s_zoom / 89.0f) * (p_aslot[casi[i]]->angle_180[*P] - 90);
				}

				//apply diff width
				if (p_aslot[casi[i]]->w_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[*P] < 90)
				{
					p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i] =
						(p_aslot[casi[i]]->pkf[cki[i]].width[i] * s_zoom) +
						(p_aslot[casi[i]]->w_diffn[i] * s_zoom / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[*P]);
				}
				if (p_aslot[casi[i]]->w_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[*P] >= 90)
				{
					p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i] =
						(p_aslot[casi[i]]->pkf[cki[i]].width[i] * s_zoom) +
						(p_aslot[casi[i]]->w_diffp[i] * s_zoom / 89.0f) * (p_aslot[casi[i]]->angle_180[*P] - 90);
				}

				//adjust to angle mode
				//0 = absolute
				//1 = relative to parent bone
				//2 = relative to current angle
				//3 = relative to default keyframe
				switch (p_aslot[casi[i]]->pkf[cki[i]].mode_a[i])
				{
				//absolute
				case (0):
					{
						break;
					};
				//relative to parent bone
				case (1):
					{
						//pointer to adjusted angle of parent bone not NULL (lower torso)
						if (p_aslot[casi[i]]->pkf[cki[i]].p_pba[i] != NULL)
						{
							//adjusted angle is adjusted parent bone angle plus own offset
							//(represented by its angle or angle_ad, which is either still
							//default or modified by a_diff)
							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] +=
								*p_aslot[casi[i]]->pkf[cki[i]].p_pba[*P][i];
						}

						break;
					}
				//relative to current angle
				case (2):
					{
						break;
					}
				}
				//check angle_ad doesn't exceed its limit
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] -= 360;
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] += 360;

				//user input angle
				if ((p_aslot[casi[i]]->pkf[cki[i]].action == 1 ||
					p_aslot[casi[i]]->pkf[cki[i]].action == 2) &&
					p_aslot[casi[i]]->ui_valid[*P] == 1 &&
					p_aslot[casi[i]]->ui_index == i)
				{
					//set ui_indexed bone to user input angel plus bias
					p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] =
						(float)p_aslot[casi[i]]->angle[*P] + p_aslot[casi[i]]->ui_bias;
				}
				//check angle_ad doesn't exceed its limit
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] -= 360;
				if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] += 360;

				//convert adjusted data into integer
				p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
				p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i];
				p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i];

				//---- calculate speed of changes ------------------------------------------------

				//if first keyframe of animation caluclate speed of change for angle/length/width
				//using the data from default keyframe
				//for every other keyframe use standard values of keyframe (adjusted only
				//for mode_a)

				//!!
				//difference between default current pos (either default keyframe pos
				//or if first keyframe default animation) and next default keyframe pos
				//difference between actual current position and fully adjusted keyframe pos
				//adjust t_frame

				//set adjusted keyframe time to default keyframe time
				p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].t_frame[i];

				//calculate difference in degree between current default position and target default position
				//if first keyframe, cdp is from default animation else it's angle_def of previous keyframe
				float angle_diff_dd, angle_diff_ca;

				if (cki[i] == 0)
					if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i])
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
							angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i];
						else
							angle_diff_dd = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i]);
					else
						if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] > 180)
							angle_diff_dd = (360 - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
						else
							angle_diff_dd = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
				else
					if (p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i])
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] <= 180)
							angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i];
						else
							angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i]);
					else
						if (p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] > 180)
							angle_diff_dd = (360 - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
						else
							angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[*P][i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
				//absolute difference
				if (angle_diff_dd < 0)		angle_diff_dd = -angle_diff_dd;

				//calculate difference between current position and adjusted target position
				//calculate difference between the two differences
				if (p_sk->b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
						angle_diff_ca = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle;
					else
						angle_diff_ca = p_sk->b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]);
				else
					if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 180)
						angle_diff_ca = (360 - p_sk->b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
					else
						angle_diff_ca = p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
				//absolute difference
				if (angle_diff_ca < 0)		angle_diff_ca = -angle_diff_ca;

				//set t_frame_ad, defaultspeed is 90 degree in 100ms
				//only adjust of way increases, decreases stay the same
				if (angle_diff_ca - angle_diff_dd > 0)
					p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[*P][i] += (int)((angle_diff_ca - angle_diff_dd) / 90.0f * 100.0f);

				//current angle <= target angle
				//ac <= at
				if (p_sk->b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
				{
					//distance in positive direction is smaller/equal to 180 degree
					//rotate angle in positive direction
					//ac====>at
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle;
					else
					//rotate in negative direction
					//<==ac----at<==
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]);
				}
				else
				//current angle > target angle
				//ac > at
				{
					//distance in positive direction smaller
					//==>at----ac==>
					if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 180)
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = (360 - p_sk->b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
					else
					//rotate in negative direction
					//at<====ac
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
				}

				//angle change speed is difference times keyframe time
				p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[*P][i]);
//!!				p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

				//---- length, width ---------------------------------------------------------

				//!!! using default speed
//				p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].length[i] - p_sk->b[i].length) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
//				p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].width[i] - p_sk->b[i].width) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
				p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i] - p_sk->b[i].length) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
				p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i] - p_sk->b[i].width) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

				//---- check speed -----------------------------------------------------------
				//if speed smaller than 1 | -1 set speed to 90 | 5

				if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] < 1)
					p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = 90;
				if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] < 1 &&
					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] >= 0)
					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = 5;
				if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] > -1 &&
					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] <= 0)
					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = -5;
				if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] < 1 &&
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] >= 0)
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = 1;
				if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] > -5 &&
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] <= 0)
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = -5;

					//---- first keyframe ------------------------------------------------------------

/*				if (cki[i] == 0)
//!!			if (false)
				{
					//---- angle -----------------------------------------------------------------

					//current angle <= target angle
					//ac <= at
/*					if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i];
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] > 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = (360 - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
					}*/
/*					if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i];
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = (360 - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
					}

					//angle change speed is difference times keyframe time
					p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

					//---- length, width ---------------------------------------------------------

					//!!
					//dasselbe problem bei winkel?
					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].length[i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].length[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
					//if speed is 0 calculate speed with adjusted data
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] == 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].length[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].width[i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].width[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] == 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i] - p_anmn[*p_asi][AN_DEFAULT]->pkf[DKFI].width[i]) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

					//---- check speed -----------------------------------------------------------
					//if speed smaller than 1 | -1 set speed to 90 | 5

					if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] < 1)
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = 90;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = 5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] > -1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = -5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = 5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] > -1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = -5;
				}
				else
				//---- not first keyframe --------------------------------------------------------
				{
					//---- angle -----------------------------------------------------------------

					//current angle <= target angle
					//ac <= at
/*					if (p_sk->b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_sk->b[i].angle <= 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] - p_sk->b[i].angle;
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i] > 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = (360 - p_sk->b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_def[*P][i];
					}*/
/*					if (p_sk->b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle;
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = (360 - p_sk->b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
					}

					//angle change speed is difference times keyframe time
					p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

					//---- length, width ---------------------------------------------------------

					p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].length[i] - p_sk->b[i].length) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = (p_aslot[casi[i]]->pkf[cki[i]].width[i] - p_sk->b[i].width) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame[i]);

					//---- check speed -----------------------------------------------------------
					//if speed smaller than 1 | -1 set speed to 90 | 5

					if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] < 1)
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] = 90;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = 5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] > -1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] = -5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = 1;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] > -5 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] = -5;
				}*/
/*			}
			else
			//---- interpolate -------------------------------------------------------------------
			{
				//---- angle ---------------------------------------------------------------------

				//if current angle is not target angle
				if (p_sk->b[i].angle != p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
				{
					//ac <= at
					if (p_sk->b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
					{
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
						{
							if (p_sk->b[i].angle + p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
								p_sk->b[i].angle += p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						}
						else
						//<==ac----at<==
						{
							if (p_sk->b[i].angle < p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] ||
								p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed >= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
								p_sk->b[i].angle -= p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						}
					}
/*					else
					//at > ac
					{
						//==>at----ac==>
						if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] > 180)
						{
							if (p_sk->b[i].angle > p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] ||
								p_sk->b[i].angle + p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
								p_sk->b[i].angle += p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						}
						else
						//at<====ac
						{
							if (p_sk->b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed >= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i])
								p_sk->b[i].angle -= p_aslot[casi[i]]->pkf[cki[i]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i];
						}
					}
				}

				//---- length --------------------------------------------------------------------

				//if current length not target length
				if (p_sk->b[i].length != p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i])
				{
					//positive speed
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] > 0)
						if (p_sk->b[i].length + p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] * t_sca * s_speed <= p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i])
							p_sk->b[i].length += p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].length = p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i];
					else
					//negative speed
						if (p_sk->b[i].length + p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] * t_sca * s_speed >= p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i])
							p_sk->b[i].length += p_aslot[casi[i]]->pkf[cki[i]].speed_l[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].length = p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i];
				}

				//---- width ---------------------------------------------------------------------

				//if current width not target width
				if (p_sk->b[i].width != p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i])
				{
					//positive speed
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] > 0)
						if (p_sk->b[i].width + p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] * t_sca * s_speed <= p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i])
							p_sk->b[i].width += p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].width = p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i];
					else
					//negative speed
						if (p_sk->b[i].width + p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] * t_sca * s_speed >= p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i])
							p_sk->b[i].width += p_aslot[casi[i]]->pkf[cki[i]].speed_w[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].width = p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i];
				}
			}
		}

		//---- hara initializing/interpolation ---------------------------------------------------

		//---- hara.x ----------------------------------------------------------------------------
		//---- initialize ------------------------------------------------------------------------
		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].state[*P][IHX] == 0)
		{
			//set keyframe state of bone to initialized
			p_aslot[casi[IHX]]->pkf[cki[IHX]].state[*P][IHX] = 1;

			//set start time of keyframe for bone
			p_aslot[casi[IHX]]->pkf[cki[IHX]].t_kfstart[*P][IHX] = t_current;

			//set adjusted data
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x = p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x;
			//apply zoom factor
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x *= s_zoom;

			//apply diff pos
			if (p_aslot[casi[IHX]]->h_diffn.x != 0 && p_aslot[casi[IHX]]->angle_180[*P] < 90)
			{
				//adjusted hara.x is max difference from absolute hara.x offset
				//factored by user input angle
				p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x =
					(p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x * s_zoom) +
					(p_aslot[casi[IHX]]->h_diffn.x * s_zoom / 89.0f) * (89 - p_aslot[casi[IHX]]->angle_180[*P]);
			}
			if (p_aslot[casi[IHX]]->h_diffp.x != 0 && p_aslot[casi[IHX]]->angle_180[*P] >= 90)
			{
				p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x =
					(p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x * s_zoom) +
					(p_aslot[casi[IHX]]->h_diffp.x * s_zoom / 89.0f) * (p_aslot[casi[IHX]]->angle_180[*P] - 90);
			}

			//convert to integer to avoid rounding errors (will be integer onscreen anyway)
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x = (float)(int)p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x;
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x = (float)(int)p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x;

			//calculate speed of change
			p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x = p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x * (1000 / p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame[IHX]);
			//set hara.x reference
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x	= p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[*P].x;

			//check speed
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x < 1 &&
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x >= 0)
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x = 5;
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x > -1 &&
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x <= 0)
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x = -5;
		}
		else
		//---- interpolate ----------------------------------------------------------------------
		{
			//if reference counter is not 0
			//(holds length of movement and gets decreased for every movement till 0)
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x != 0)
			{
				//adjust reference counter of x movement
				if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x > 0)
					if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x - p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed >= 0)
					{
						//adjust reference counter
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x -= p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed;
						//also apply movement to player
						p_sk->p_ref->v.p[0].x += p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed;
					}
					else
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x = 0;
				else
					if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x - p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed <= 0)
					{
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x -= p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed;
						p_sk->p_ref->v.p[0].x += p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[*P].x * t_sca * s_speed;
					}
					else
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x = 0;
			}
		}
		//---- hara.y ----------------------------------------------------------------------------
		//---- initialize ------------------------------------------------------------------------
		if (p_aslot[casi[IHY]]->pkf[cki[IHY]].state[*P][IHY] == 0)
		{
			//set keyframe state of bone to initialized
			p_aslot[casi[IHY]]->pkf[cki[IHY]].state[*P][IHY] = 1;

			//set start time of keyframe for bone
			p_aslot[casi[IHY]]->pkf[cki[IHY]].t_kfstart[*P][IHY] = t_current;

			//set adjusted data
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y = p_aslot[casi[IHY]]->pkf[cki[IHY]].hara.y;
			//apply zoom factor
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y *= s_zoom;

			//apply diff pos
			if (p_aslot[casi[IHY]]->h_diffn.y != 0 && p_aslot[casi[IHY]]->angle_180[*P] < 90)
			{
				//adjusted hara.y is max difference from absolute hara.y offset
				//factored by user input angle
				p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y =
					p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y +
					(p_aslot[casi[IHY]]->h_diffn.y * s_zoom / 89.0f) * (89 - p_aslot[casi[IHY]]->angle_180[*P]);
			}
			if (p_aslot[casi[IHY]]->h_diffp.y != 0 && p_aslot[casi[IHY]]->angle_180[*P] >= 90)
			{
				p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y =
					p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y +
					(p_aslot[casi[IHY]]->h_diffp.y * s_zoom / 89.0f) * (p_aslot[casi[IHY]]->angle_180[*P] - 90);
			}

			//convert to integer to avoid rounding errors
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y = (float)(int)p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y;

			//!!! default keyframe?

			//calculate speed of change
			p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y =
				((S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y) - p_sk->p_ref->v.p[0].y) *
				(1000 / p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame[IHY]);

			//check speed
			if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y < 1 &&
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y >= 0)
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y = 5;
			if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y > -1 &&
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y <= 0)
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y = -5;
		}
		else
		//---- interpolate ----------------------------------------------------------------------
		{
			//if current hara.y position is not absolute position
			if (p_sk->p_ref->v.p[0].y != S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y)
			{
				if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y > 0)
					if (p_sk->p_ref->v.p[0].y + p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y * t_sca * s_speed <= S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y;
				else
					if (p_sk->p_ref->v.p[0].y + p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y * t_sca * s_speed >= S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y;
			}
		}

		//---- advance keyframe ------------------------------------------------------------------
		//the current keyframe index (cki) of a bone is advanced (if not last keyframe of
		//animtion) as soon as this bone has reached its position (angle, length, width)
		//and all other bones with same current animation slot index (casi) and same
		//priority have reached their positions
		//
		//for example:
		//left arm and right arm use same animation slot and each bone has the same priority
		//as soon as all bones have reached their positions, they get advanced to the next keyframe

		//reset bone done counter
		ZeroMemory(&bdc, sizeof(bdc));

		//check bones if done
		for (i = 0; i < 19; ++i)
			if (p_sk->b[i].angle == p_aslot[casi[i]]->pkf[cki[i]].angle_ad[*P][i] &&
				p_sk->b[i].length == p_aslot[casi[i]]->pkf[cki[i]].length_ad[*P][i] &&
				p_sk->b[i].width == p_aslot[casi[i]]->pkf[cki[i]].width_ad[*P][i])
			{
				//increase number of bones done with this priority
				++bdc[casi[i]][p_aslot[casi[i]]->priority[i]];
				//if last keyframe of animation also increase number of bones in this slot done
				if (cki[i] == p_aslot[casi[i]]->nokf - 1)
					++bdc[casi[i]][21];
				//!!
				//p_sk->b[i].damage = 50;
			}
			//!!
			else
			{
				p_sk->b[i].damage = 0;
			}

		//check hara if done
		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x == 0)
		{
			++bdc[casi[IHX]][p_aslot[casi[IHX]]->priority[IHX]];
			//if last keyframe of animation also increase number of bones in this slot done
			if (cki[IHX] == p_aslot[casi[IHX]]->nokf - 1)
				++bdc[casi[IHX]][21];
		}
		if (p_sk->p_ref->v.p[0].y == S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y)
		{
			++bdc[casi[IHY]][p_aslot[casi[IHY]]->priority[IHY]];
			//if last keyframe of animation also increase number of bones in this slot done
			if (cki[IHY] == p_aslot[casi[IHY]]->nokf - 1)
				++bdc[casi[IHY]][21];
		}

		//!!
		//gehe alle bones und hara durch, wenn done, erh�he

/*		for (register int b = 0; b < 19; ++b)
			if (p_sk->b[b].angle == p_aslot[casi[b]]->pkf[cki[b]].angle_ad[*P][b] &&
				p_sk->b[b].length == p_aslot[casi[b]]->pkf[cki[b]].length_ad[*P][b] &&
				p_sk->b[b].width == p_aslot[casi[b]]->pkf[cki[b]].width_ad[*P][b])
				if (cki[b] < p_aslot[casi[b]]->nokf - 1)
				{
					//reset keyframe state for this bone, increase keyframe
					p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
					++cki[b];
				}
				else
				{
					//reset keyframe for this bone, set keyframe to first
//					p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
//					cki[b] = 0;
				}
		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[*P].x == 0)
			if (cki[IHX] < p_aslot[casi[IHX]]->nokf - 1)
			{
				//reset keyframe state for this bone, increase keyframe
				p_aslot[casi[IHX]]->pkf[cki[IHX]].state[*P][IHX] = 0;
				++cki[IHX];
			}
			else
			{
				//reset keyframe for this bone, set keyframe to first
//				p_aslot[casi[IHX]]->pkf[cki[IHX]].state[*P][IHX] = 0;
//				cki[IHX] = 0;
			}
		if (p_sk->p_ref->v.p[0].y == S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[*P].y)
			if (cki[IHY] < p_aslot[casi[IHY]]->nokf - 1)
			{
				//reset keyframe state for this bone, increase keyframe
				p_aslot[casi[IHY]]->pkf[cki[IHY]].state[*P][IHY] = 0;
				++cki[IHY];
			}
			else
			{
				//reset keyframe for this bone, set keyframe to first
//				p_aslot[casi[IHY]]->pkf[cki[IHY]].state[*P][IHY] = 0;
//				cki[IHY] = 0;
			}*/

/*		//for all bones
		for (register int b = 0; b < 21; ++b)
			//if bpc of this bones slot and this bones priority is
			//same as bdc of this bones slot and this bones priority
			if (bpc[casi[b]][p_aslot[casi[b]]->priority[b]] ==
				bdc[casi[b]][p_aslot[casi[b]]->priority[b]])
			{
				//if type not buffer keyframe
				if (p_aslot[casi[b]]->pkf[cki[b]].type == 0 ||
					(p_aslot[casi[b]]->pkf[cki[b]].type == 1 &&
					p_aslot[casi[b]]->state[*P] == AS_FINAL))
				{
					//if current keyframe index of bone is smaller than number of kf in this animation
					if (cki[b] < p_aslot[casi[b]]->nokf - 1)
					{
						//reset keyframe state for this bone, increase keyframe
						p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
						++cki[b];
					}
				}
/*				else
				{
					//reset keyframe state for this bone, increase keyframe
					p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
					if (p_aslot[casi[b]] == p_anmn[*p_asi][AN_WALK_FWD] ||
						p_aslot[casi[b]] == p_anmn[*p_asi][AN_WALK_BWD])
						cki[b] = 0;
				}*/
/*			}

/*		//for both slots
		for (s = 0; s < 2; ++s)
			//for all priorities
			for (register int p = 0; p < 21; ++p)
				//for all bones
				for (register int b = 0; b < 21; ++b)
					//if prioritiy of slot s to advance
					//and current bone is of this slot
					//and priority of current bone is of current priority
					if (bac[s][p] == true &&
						casi[b] == p &&
						p_aslot[casi[b]]->priority[b] == p)
					{
						//if current keyframe index of bone is smaller than number of kf in this animation
						if (cki[b] < p_aslot[casi[b]]->nokf - 1)
						{
							//reset keyframe state for this bone, increase keyframe
							p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
							++cki[b];
						}
						else
						{
							//reset keyframe state for this bone, increase keyframe
							p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
						}

						bac[s][p] = false;
					}*/
/*			//for all priorities
			for (register int p = 0; p < 21; ++p)
				//for all bones
				for (register int b = 0; b < 21; ++b)
					//if slot valid pointer to animation
					if (p_aslot[casi[b]] != NULL)
						//if all bones with this prioritiy in this slot are done
						//and this bone is of this priority and slot
						if (bpc[casi[b]][p] == bdc[casi[b]][p] &&
							p_aslot[casi[b]]->priority[b] == p &&
							casi[b] == s)
							//if current keyframe index of bone is smaller than number of
							//keyframes in this animation
							if (cki[b] < p_aslot[casi[b]]->nokf - 1)
							{
								//reset keyframe state for this bone, increase keyframe
								p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
								++cki[b];
							}
							else
							{
								//reset keyframe for this bone, set keyframe to first
								//p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
								//cki[b] = 0;

								//!!
								//p_aslot[0] = NULL;
							}*/

/*		int ret = 0;
		//!! flag setzen in player auslesen, reagieren (subframes?)
		//activate/deaktivate doch hier und von player aus aufrufen?
		//animationen f�hren aktionen aus

		//!!
		//for both slots
		for (register int s = 0; s < 2; ++s)
			//if all bones of slot done
			if (bpc[s][21] == bdc[s][21])
			{
				//set animation to done oder resette, wenn cylce animation
				//!!
				//deactivate_slot
				if (s == 0)
					ret = 1;
				if (s == 1)
				{
					if (ret == 0)
						ret = 2;
					if (ret == 1)
						ret = 3;
				}
				//al_deactivate_slot(s);
			}

		return(ret);

		//!!
		//animation states setzen
		//keyframe done: alle bones derselben animation und derselben priorit�t abgeschlossen

/*		//for all priorities
		for (p = 0; p < 21; ++p)
		{
			//if number of bones with prioritiy p is same as number of bones with priority p
			//which are done
			if (bpc[0][p] == bdc[0][p])
			{
				//for every bone and hara.x/y
				for (register int i = 0; i < 21; ++i)
				{
					//if priority of bone is current priority
					if (p_aslot[casi[i]]->priority[i] == p)
					{
						if (cki[i] < p_aslot[casi[i]]->nokf - 1)
						{
							p_aslot[casi[i]]->pkf[cki[i]].state[*P][i] = 0;
							++cki[i];
						}
						else
						{
							p_aslot[casi[i]]->pkf[cki[i]].state[*P][i] = 0;
							cki[i] = 0;
							p_aslot[casi[i]]->pkf[cki[i]].state[*P][i] = 0;
						}
					}
				}
			}

			bdc[0][p] = 0;
		}*/

		//---- advance animation -----------------------------------------------------------------
/*
		//check priority
		//for every bone and hara.x/y
		for (register int i = 0; i < 21; ++i)
		{
			//if priority of cylce slot is bigger than priority of action slot
			if (p_aslot[aslot_cycle]->priority[i] >
				p_aslot[aslot_action]->priority[i])
				//assign bone to cylce slot, else to action slot
				casi[i] = aslot_cycle;
			else
				casi[i] = aslot_action;
		}

		//for every priority
		for (i = 0
			//for every bone
			for (i = 0; i < 19; ++i)
			{
				if (p_sk->b[i].angle == panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
					if (p_sk->b[i].length == panmn[ai]->pkf[cki[0]].length_ad[*P][i])
						if (p_sk->b[i].width == panmn[ai]->pkf[cki[0]].width_ad[*P][i])
						{
							++cki[1];
							//p_sk->b[i].damage = 50;
						}
/*						else
							p_sk->b[i].damage = 0;
					else
						p_sk->b[i].damage = 0;
				else
					p_sk->b[i].damage = 0;*/
//			}
//			if (cki[1] != 19)
//				cki[1] = 0;

			//!!! hara
/*			if (cki[1] == 19 &&
//				panmn[ai]->pkf[cki[0]].hara_r[*P].x == 0 &&
				p_sk->p_ref->v.p[0].y == 298 + panmn[ai]->pkf[cki[0]].hara_ad[*P].y)
			{
		//nach check der neuen animatioenen: nna = 0;*/
	};

	//---- new_action ----------------------------------------------------------------------------

/*	bool new_action(int i, int astate)
/*	{
		//
		if (astate == AS_FINAL ||
			astate == AS_CANCEL)
		{
			//
			//advance_action(i, astate);
		}
		else
		{
			//!!! evlt. den zeiger auf NULL testen (unterschied zwischen action und animation)?
			//verify animation
			//!! verschiedene r�ckgabetypen
//			if (p_anmn[asi][i]->verify_animation(pca, asi) == 1)
			if (true)
			{
				//if verified add animation to current actions
//				pca[asi][i]		= p_anmn[asi][i];

				//reset runtime animation/keyframe data
//				pca[asi][i].reset_state(id);

				//add animation to animation buffer (-1 = to end)
//				anmn_buffer.add_entry(pca[asi][i], -1);

				//!! increase number of new animations (resten nicht vergessen)
//				++nna;

				return true;
			}
			else
				//animation not valid with current running animations, return false
				return false;
		}
	};*/

	//---- xxxx ----------------------------------------------------------------------------------

	/*
		function: check highest priority (bei gleichheit?)
		function: seitenanpassung
		function: advance
		function: advance_keyframe
		function: advance_animation
		function: apply_damage_fatique_special

		pca und
		anmn queure hier rein
		pcancel action an inputstate

		check is.PA[i]
	*/

	//---- dev_animate_single --------------------------------------------------------------------
	//animates single animation

/*	bool dev_animate_single(LONGLONG t_current,			//current time index
							float t_sca,				//time since last update
							float s_speed,				//user set speed
							animation *panmn[],			//pointer to animation array
														//first index is animation to animate
														//last holds default keyframe
							int ai,						//index of panmn which holds animation to animate
							int di,						//index of panmn which holds default animation
							bool loop)					//false = don't loop, true = loop
	{
		//default			panmn[di]->pkf[0].angle[i]
		//current			p_sk->b[i].angle
		//keyframe			panmn[ai]->pkf[cki[0]].angle[i]
		//current kf index	cki[0]

		//!!
		//keyframe index erh�hen
		//wenn ablauf auf loop testen, sonst reset
		//reset der runtime daten
		//anpassen an asi (auch innerhalb von keyframes
		//testen aller bones auf done (wie particle?)

		//if keyframe not yet initialized
		//only use first index of state of each keyframe
		//while cki[0] holds the current keyframe of animation
		if (panmn[ai]->pkf[cki[0]].state[*P][0] == 0)
		{
			//---- initialization ----------------------------------------------------------------

			//set state to initialized
			panmn[ai]->pkf[cki[0]].state[*P][0] = 1;

			//set start time of keyframe
//			panmn[ai]->pkf[cki[0]].t_kfstart = t_current;

			//set adjusted data
			//reihenfolge f�r mode_a ist okay, da die bones in der richtigen
			//sequenz angegangen werden, was parent bones betrifft, so das
			//child bones stets nach ihren parent bones berechnet werden
			for (register int i = 0; i < 19; ++i)
			{
				panmn[ai]->pkf[cki[0]].angle_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].angle[i];
				panmn[ai]->pkf[cki[0]].length_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].length[i];
				panmn[ai]->pkf[cki[0]].width_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].width[i];

				//diff
				if (panmn[ai]->a_diffn[i] != 0 ||
					panmn[ai]->a_diffp[i] != 0)
				{
//					panmn[ai]->pkf[cki[0]].angle_ad[*P][i] = (float)panmn[ai]->angle_180[*P];
					if (panmn[ai]->angle_180[*P] < 90 && panmn[ai]->a_diffn[i] != 0)
					{
						panmn[ai]->pkf[cki[0]].angle_ad[*P][i] =
						panmn[ai]->pkf[cki[0]].angle[i] +
						((float)panmn[ai]->a_diffn[i] / 89.0f) * (89 - panmn[ai]->angle_180[*P]);
					}
					//angle_180 >= 90
					if (panmn[ai]->angle_180[*P] >= 90 && panmn[ai]->a_diffp[i] != 0)
					{
						panmn[ai]->pkf[cki[0]].angle_ad[*P][i] =
						panmn[ai]->pkf[cki[0]].angle[i] +
						((float)panmn[ai]->a_diffp[i] / 90.0f) * (panmn[ai]->angle_180[*P] - 89);
					}
				}
				//check angle doesn't exceed its limit
				if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] > 359)		panmn[ai]->pkf[cki[0]].angle_ad[*P][i] -= 360;
				if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] < 0)			panmn[ai]->pkf[cki[0]].angle_ad[*P][i] += 360;

				//user input angle
				if (panmn[ai]->pkf[cki[0]].action == 1 &&
					panmn[ai]->ui_valid[*P] == 1)
				{
					panmn[ai]->pkf[cki[0]].angle_ad[*P][panmn[ai]->ui_index] =
					(float)panmn[ai]->angle[*P];
				}

				//angle mode
				//relative to parent
				if (panmn[ai]->pkf[cki[0]].mode_a[i] == 1)
				{
					if (panmn[ai]->pkf[cki[0]].p_pba[i] != NULL)
					{
						//!!!
						panmn[ai]->pkf[cki[0]].angle_ad[*P][i] +=
						*panmn[ai]->pkf[cki[0]].p_pba[*P][i];

						//check angle doesn't exceed its limit
						if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] > 359)		panmn[ai]->pkf[cki[0]].angle_ad[*P][i] -= 360;
						if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] < 0)			panmn[ai]->pkf[cki[0]].angle_ad[*P][i] += 360;
					}
				}
			}

			//for all bones
			for (i = 0; i < 19; ++i)
			{
				//calculate speed of change for angle, length, width using either default
				//keyframe or last keyframe if current keyframe index is bigger than 0
				//use keyframe runtime data to store results

				//if first keyframe of animation use default keyframe data as reference
				//else use current state as reference
				//
				//rotation direction of first keyframe is nontheless determined by the
				//default keyframe, not the actual position of the bone
//				if (cki[0] == 0)

				//!!! length, width in richtige klammerung
				if (false)
				{
					//current angle <= target angle
					//ac <= at
					if (panmn[di]->pkf[0].angle[i] <= panmn[ai]->pkf[cki[0]].angle[i])
					{
						//distance in positive direction is smaller/etual to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (panmn[ai]->pkf[cki[0]].angle[i] - panmn[di]->pkf[0].angle[i] <= 180)
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[ai]->pkf[cki[0]].angle[i] - panmn[di]->pkf[0].angle[i];
						else
						//rotate in negative direction
						//<==ac----at<==
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[di]->pkf[0].angle[i] + (360 - panmn[ai]->pkf[cki[0]].angle[i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (panmn[di]->pkf[0].angle[i] - panmn[ai]->pkf[cki[0]].angle[i] > 180)
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = (360 - panmn[di]->pkf[0].angle[i]) + panmn[ai]->pkf[cki[0]].angle[i];
						else
						//rotate in negative direction
						//at<====ac
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[di]->pkf[0].angle[i] - panmn[ai]->pkf[cki[0]].angle[i];
					}

					//!! formel anpassen
					//angle change speed is difference times keyframe time
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[ai]->pkf[cki[0]].speed_a[*P][i] * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);

					//length change speed
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] = -(panmn[di]->pkf[0].length[i] - panmn[ai]->pkf[cki[0]].length[i]) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);

					//width change speed
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] = -(panmn[di]->pkf[0].width[i] - panmn[ai]->pkf[cki[0]].width[i]) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);
				}
				else
				//use current position as reference
				{
					//current angle <= target angle
					//ac <= at
					if (p_sk->b[i].angle <= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
					{
						//distance in positive direction is smaller/etual to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[ai]->pkf[cki[0]].angle_ad[*P][i] - p_sk->b[i].angle;
						else
						//rotate in negative direction
						//<==ac----at<==
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = p_sk->b[i].angle + (360 - panmn[ai]->pkf[cki[0]].angle_ad[*P][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (p_sk->b[i].angle - panmn[ai]->pkf[cki[0]].angle_ad[*P][i] > 180)
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = (360 - p_sk->b[i].angle) + panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
						else
						//rotate in negative direction
						//at<====ac
							panmn[ai]->pkf[cki[0]].speed_a[*P][i] = p_sk->b[i].angle - panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
					}

					//angle change speed is difference times keyframe time
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] = panmn[ai]->pkf[cki[0]].speed_a[*P][i] * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);

					//length change speed
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] = (panmn[ai]->pkf[cki[0]].length[i] - p_sk->b[i].length) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);

					//width change speed
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] = (panmn[ai]->pkf[cki[0]].width[i] - p_sk->b[i].width) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[i]);
				}

				//!!
				/*if (panmn[ai]->pkf[cki[0]].speed_a[*P][i] == 0)
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] = 359;
				if (panmn[ai]->pkf[cki[0]].speed_l[*P][i] == 0)
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] = 359;
				if (panmn[ai]->pkf[cki[0]].speed_w[*P][i] == 0)
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] = 359;*/
/*				if (panmn[ai]->pkf[cki[0]].speed_a[*P][i] < 1 &&
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] > 0)
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] = 1;
				if (panmn[ai]->pkf[cki[0]].speed_a[*P][i] > -1 &&
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] < 0)
					panmn[ai]->pkf[cki[0]].speed_a[*P][i] = -1;
				if (panmn[ai]->pkf[cki[0]].speed_l[*P][i] < 1 &&
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] > 0)
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] = 1;
				if (panmn[ai]->pkf[cki[0]].speed_l[*P][i] > -1 &&
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] < 0)
					panmn[ai]->pkf[cki[0]].speed_l[*P][i] = -1;
				if (panmn[ai]->pkf[cki[0]].speed_w[*P][i] < 1 &&
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] > 0)
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] = 1;
				if (panmn[ai]->pkf[cki[0]].speed_w[*P][i] > -1 &&
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] < 0)
					panmn[ai]->pkf[cki[0]].speed_w[*P][i] = -1;
			}

			//hara.x change speed
			panmn[ai]->pkf[cki[0]].speed_h[*P].x = panmn[ai]->pkf[cki[0]].hara.x * (1000 / panmn[ai]->pkf[cki[0]].t_frame[19]);
			//hara.x reference
			panmn[ai]->pkf[cki[0]].hara_r[*P].x = panmn[ai]->pkf[cki[0]].hara.x;

			//hara.y change speed
			panmn[ai]->pkf[cki[0]].speed_h[*P].y = ((S_PYDEF + panmn[ai]->pkf[cki[0]].hara.y) - p_sk->p_ref->v.p[0].y) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[20]);

			if (panmn[ai]->pkf[cki[0]].speed_h[*P].x < 1 &&
				panmn[ai]->pkf[cki[0]].speed_h[*P].x > 0)
				panmn[ai]->pkf[cki[0]].speed_h[*P].x = 1;
			if (panmn[ai]->pkf[cki[0]].speed_h[*P].x > -1 &&
				panmn[ai]->pkf[cki[0]].speed_h[*P].x < 0)
				panmn[ai]->pkf[cki[0]].speed_h[*P].x = -1;
			if (panmn[ai]->pkf[cki[0]].speed_h[*P].y < 1 &&
				panmn[ai]->pkf[cki[0]].speed_h[*P].y > 0)
				panmn[ai]->pkf[cki[0]].speed_h[*P].y = 1;
			if (panmn[ai]->pkf[cki[0]].speed_h[*P].y > -1 &&
				panmn[ai]->pkf[cki[0]].speed_h[*P].y < 0)
				panmn[ai]->pkf[cki[0]].speed_h[*P].y = -1;

//			kf->speed_h.x = ((sk.p_ref->v.p[0].x + kf->hara_t.x) - sk.p_ref->v.p[0].x) * (1000 / kf->t_frame);
//			kf->speed_h.y = ((sk.p_ref->v.p[0].y + kf->hara_t.y) - sk.p_ref->v.p[0].y) * (1000 / kf->t_frame);

/*			//hara position change speed
			//hara.x always has current position as reference
			panmn[ai]->pkf[cki[0]].speed_h[*P].x =
				((p_sk->p_ref->v.p[0].x + panmn[ai]->pkf[cki[0]].hara.x)
				- p_sk->p_ref->v.p[0].x) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[19]);
			//hara.y always uses default keyframe as reference
			panmn[ai]->pkf[cki[0]].speed_h[*P].y =
				((panmn[di]->pkf[0].hara.y + panmn[ai]->pkf[cki[0]].hara.y)
				- panmn[di]->pkf[0].hara.y) * (1000 / panmn[ai]->pkf[cki[0]].t_frame[20]);*/

			//set adjusted data
			//set_adjusted_data(ai, di, _asi);
			//for every bone
/*			for (i = 0; i < 19; ++i)
			{
//				panmn[ai]->pkf[cki[0]].angle_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].angle[i];
//				panmn[ai]->pkf[cki[0]].length_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].length[i];
//				panmn[ai]->pkf[cki[0]].width_ad[*P][i]	= (float)(int)panmn[ai]->pkf[cki[0]].width[i];
			}
			//hara adjusted
			panmn[ai]->pkf[cki[0]].hara_ad[*P].x	= (float)(int)panmn[ai]->pkf[cki[0]].hara.x;
			panmn[ai]->pkf[cki[0]].hara_ad[*P].y	= (float)(int)panmn[ai]->pkf[cki[0]].hara.y;

			//animation not done yet
			return false;
		}
		else
		//animation initialization done
		{
			//---- interpolation -----------------------------------------------------------------

			//for all bones
			for (register int i = 0; i < 19; ++i)
			{
				//---- angle ---------------------------------------------------------------------

				//if current angle is not target angle
				if (p_sk->b[i].angle != panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
				{
					//ac <= at
					if (p_sk->b[i].angle <= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
					{
						//ac====>at
						if (panmn[ai]->pkf[cki[0]].angle_ad[*P][i] - p_sk->b[i].angle <= 180)
						{
							if (p_sk->b[i].angle + panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed <= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
								p_sk->b[i].angle += panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
						}
						else
						//<==ac----at<==
						{
							if (p_sk->b[i].angle < panmn[ai]->pkf[cki[0]].angle_ad[*P][i] ||
								p_sk->b[i].angle - panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed >= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
								p_sk->b[i].angle -= panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
						}
					}
					else
					//at > ac
					{
						//==>at----ac==>
						if (p_sk->b[i].angle - panmn[ai]->pkf[cki[0]].angle_ad[*P][i] > 180)
						{
							if (p_sk->b[i].angle > panmn[ai]->pkf[cki[0]].angle_ad[*P][i] ||
								p_sk->b[i].angle + panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed <= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
								p_sk->b[i].angle += panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
						}
						else
						//at<====ac
						{
							if (p_sk->b[i].angle - panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed >= panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
								p_sk->b[i].angle -= panmn[ai]->pkf[cki[0]].speed_a[*P][i] * t_sca * s_speed;
							else
								//set to target angle
								p_sk->b[i].angle = panmn[ai]->pkf[cki[0]].angle_ad[*P][i];
						}
					}

					//!! maybe check angle for limits (already done in processing?)
				}

				//---- length --------------------------------------------------------------------

				//if current length not target length
				if (p_sk->b[i].length != panmn[ai]->pkf[cki[0]].length_ad[*P][i])
				{
					if (panmn[ai]->pkf[cki[0]].speed_l[*P][i] > 0)
						if (p_sk->b[i].length + panmn[ai]->pkf[cki[0]].speed_l[*P][i] * t_sca * s_speed <= panmn[ai]->pkf[cki[0]].length_ad[*P][i])
							p_sk->b[i].length += panmn[ai]->pkf[cki[0]].speed_l[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].length = panmn[ai]->pkf[cki[0]].length_ad[*P][i];
					else
						if (p_sk->b[i].length + panmn[ai]->pkf[cki[0]].speed_l[*P][i] * t_sca * s_speed >= panmn[ai]->pkf[cki[0]].length_ad[*P][i])
							p_sk->b[i].length += panmn[ai]->pkf[cki[0]].speed_l[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].length = panmn[ai]->pkf[cki[0]].length_ad[*P][i];
				}

				//---- width ---------------------------------------------------------------------

				//if current width not target width
				if (p_sk->b[i].width != panmn[ai]->pkf[cki[0]].width_ad[*P][i])
				{
					if (panmn[ai]->pkf[cki[0]].speed_w[*P][i] > 0)
						if (p_sk->b[i].width + panmn[ai]->pkf[cki[0]].speed_w[*P][i] * t_sca * s_speed <= panmn[ai]->pkf[cki[0]].width_ad[*P][i])
							p_sk->b[i].width += panmn[ai]->pkf[cki[0]].speed_w[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].width = panmn[ai]->pkf[cki[0]].width_ad[*P][i];
					else
						if (p_sk->b[i].width + panmn[ai]->pkf[cki[0]].speed_w[*P][i] * t_sca * s_speed >= panmn[ai]->pkf[cki[0]].width_ad[*P][i])
							p_sk->b[i].width += panmn[ai]->pkf[cki[0]].speed_w[*P][i] * t_sca * s_speed;
						else
							p_sk->b[i].width = panmn[ai]->pkf[cki[0]].width_ad[*P][i];
				}
			}

			//---- hara.x ------------------------------------------------------------------------

			if (panmn[ai]->pkf[cki[0]].hara_r[*P].x != 0)
			{
				if (panmn[ai]->pkf[cki[0]].speed_h[*P].x > 0)
					panmn[ai]->pkf[cki[0]].hara_r[*P].x -= panmn[ai]->pkf[cki[0]].speed_h[*P].x * t_sca * s_speed;
				else
					panmn[ai]->pkf[cki[0]].hara_r[*P].x += panmn[ai]->pkf[cki[0]].speed_h[*P].x * t_sca * s_speed;

				p_sk->p_ref->v.p[0].x += panmn[ai]->pkf[cki[0]].speed_h[*P].x * t_sca * s_speed;
			}

			//---- hara.y ------------------------------------------------------------------------

			//if current hara.y position is not
			if (p_sk->p_ref->v.p[0].y != panmn[di]->pkf[0].hara_ad[*P].y)
			{
//default kf
/*				if (panmn[ai]->pkf[cki[0]].speed_h[*P].y > 0)
					if (p_sk->p_ref->v.p[0].y + panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed <= 298 + panmn[di]->pkf[0].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = 298 + panmn[di]->pkf[0].hara_ad[*P].y;
				else
					if (p_sk->p_ref->v.p[0].y + panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed >= 298 + panmn[di]->pkf[0].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = 298 + panmn[di]->pkf[0].hara_ad[*P].y;*/
/*				if (panmn[ai]->pkf[cki[0]].speed_h[*P].y > 0)
					if (p_sk->p_ref->v.p[0].y + panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed <= S_PYDEF + panmn[ai]->pkf[cki[0]].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = S_PYDEF + panmn[ai]->pkf[cki[0]].hara_ad[*P].y;
				else
					if (p_sk->p_ref->v.p[0].y + panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed >= S_PYDEF + panmn[ai]->pkf[cki[0]].hara_ad[*P].y)
						p_sk->p_ref->v.p[0].y += panmn[ai]->pkf[cki[0]].speed_h[*P].y * t_sca * s_speed;
					else
						p_sk->p_ref->v.p[0].y = S_PYDEF + panmn[ai]->pkf[cki[0]].hara_ad[*P].y;
			}

			//---- check if done -----------------------------------------------------------------

			//for every bone
			for (i = 0; i < 19; ++i)
			{
				if (p_sk->b[i].angle == panmn[ai]->pkf[cki[0]].angle_ad[*P][i])
					if (p_sk->b[i].length == panmn[ai]->pkf[cki[0]].length_ad[*P][i])
						if (p_sk->b[i].width == panmn[ai]->pkf[cki[0]].width_ad[*P][i])
						{
							++cki[1];
							//p_sk->b[i].damage = 50;
						}
/*						else
							p_sk->b[i].damage = 0;
					else
						p_sk->b[i].damage = 0;
				else
					p_sk->b[i].damage = 0;*/
/*			}
//			if (cki[1] != 19)
//				cki[1] = 0;

			//!!! hara
/*			if (cki[1] == 19 &&
//				panmn[ai]->pkf[cki[0]].hara_r[*P].x == 0 &&
				p_sk->p_ref->v.p[0].y == S_PYDEF + panmn[ai]->pkf[cki[0]].hara_ad[*P].y)
			{
				if (panmn[ai]->pkf[cki[0]].type == 1)
					//set speed to 0
					panmn[ai]->pkf[cki[0]].speed_h[*P].x = 0;

				//panmn[ai]->pkf[cki[0]].state[*P][0] = 1;
				//advance keyframe or reset
				if (cki[0] < panmn[ai]->nokf - 1)
				{
					//if buffer keyframe and valid direction
					if (panmn[ai]->pkf[cki[0]].type == 0)
					{
						//set initialization state of current keyframe back to 0
						panmn[ai]->pkf[cki[0]].state[*P][0] = 0;
						//increase current keyframe index
						++cki[0];
					}
					if (panmn[ai]->pkf[cki[0]].type == 1 && panmn[ai]->ui_valid[P1] == 1)
					{
						//set initialization state of current keyframe back to 0
						panmn[ai]->pkf[cki[0]].state[*P][0] = 0;
						//increase current keyframe index
						++cki[0];
					}
					else
						return false;
				}
				else
				{
					//set initialization state of current keyframe back to 0
					panmn[ai]->pkf[cki[0]].state[*P][0] = 0;
					//reset current keyframe index to 0
					cki[0] = 0;

					if (loop)	return false;
					else		return true;
				}
			}
			else
			{
				cki[1] = 0;

				//not done yet
				return false;
			}
		}

		//not done yet
		return false;
	};

	//---- set_adjusted_data ---------------------------------------------------------------------

	void set_adjusted_data(int ai, int di, int asi)
	{
		//for every animation in animation buffer
//		for (register int q = 0; q < anmn_buffer.noe; ++q)
		{
			//for every bone
			for (register int i = 0; i < 19; ++i)
			{
				//
				if (true)
				{
				}
				else
				{
				}
			}
		}

		/*
			f�r die rechte seite gilt:
			angle = 180 - angle (danach auf 0-359 anpassen)
			length und width bleiben gleich
			angle_ad 
		*/

		//!! asi gibt doch �berhaupt nicht an, inwiefern die seitenanpassung eines
		//keyframes an die spielerposition vorzunehmen ist?!

		//asi
		//left side, left foot forward = 0		standard
		//left side, right foot forward = 1		standard
		//right side, left foot forward = 1		s
		//right side, right foot forward = 0

/*		//for every bone
		for (register int i = 0; i < 19; ++i)
		{
			panmn[ai]->pkf[cki[0]].angle_ad[*P][i]	= panmn[ai]->pkf[cki[0]].angle[i];
			panmn[ai]->pkf[cki[0]].length_ad[*P][i]	= panmn[ai]->pkf[cki[0]].length[i];
			panmn[ai]->pkf[cki[0]].width_ad[*P][i]	= panmn[ai]->pkf[cki[0]].width[i];
		}

		//hara
		//panmn[ai]->pkf[cki[0]].hara_ad[*P].x		=
		panmn[ai]->pkf[cki[0]].hara_ad[*P].y		= panmn[ai]->pkf[cki[0]].hara.y;*/
/*	};

	//---- dev_animate ---------------------------------------------------------------------------

/*	void dev_animate(LONGLONG t_current,				//current time index
					 float t_sca,						//time in seconds passed since last update
					 float s_speed,						//user set speed
					 animation *panmn[],				//pointer to animation array
														//(also holds default keyframe in last index)
					 int entries,						//number of valid animation array entries
					 bool loop,							//0 = don't loop animation, 1 = loop
					 int asi)							//animation side index
	{
		//!! reset runtime data mit index
		//!! evtl. alles subfunktionen mit einer masterfunktion?

		//auch zwischen keyframes anpassen an seite
		//state (animation) f�r jeden bone?

		//kf state initialisiert? wenn nicht, dann
			//initialisieren
	//animation referenz �bergabe
	//5 slots (enum)
	//state of slots (6), r�ckgabewert
	//bone zur�ckschleudern
	//animation in abh�ngigkeit von seite
	//kopie von keyframe-daten zur manipulation (auch zur �nderung der seite)
	//
	//in bone schreiben, wenn aktiv?

		//---- keyframe initializing -------------------------------------------------------------

	//---- keyframe specific data ----------------------------------------------------------------

	//for all bones at cai/cki des bones
	//hara-zu-zur�cklegender-weg
	//hara-zur�ckgelegter-weg
	//hara speed
	//angle, length, width speed
	//direction?
	//!!
	//pointer to player data of player (constructor)

	/*		//for every bone and hara
		for (register int i = 0; i < 21; ++i)
		{
			//if not yet initialized
			if (panmn[cai[i]]->pkf[cki[i]].state[*P] == 0)
			{
				//set to initialized
				*panmn[cai[i]]->pkf[cki[i]].state[*P] = 1;
			}
		}*/

	//if not yet initialized
/*	if (kf->state == 0)
	{
		//set to initialized
		kf->state = 1;

		//set start time of keyframe
		kf->t_kfstart = t_current;

		//player 1
		if (id == 0)
		{
		//for every bone calculate speed of change
		//use speed-arrays to store difference int angle, lenght and width
		for (register int i = 0; i < 19; ++i)
		{
			//current angle <= target angle
			//ac <= at
			if (sk.b[i].angle <= kf->angle[i])
			{
				//distance in positive direction smaller/equal to 180
				//rotate angle in positive direction
				//ac=====>at
				if (kf->angle[i] - sk.b[i].angle <= 180)
					kf->speed_a[i] = kf->angle[i] - sk.b[i].angle;
				else
					//rotate in negativ direction
					//<==ac-----at<==
					kf->speed_a[i] = sk.b[i].angle + (360 - kf->angle[i]);
			}
			else
			//current angle > target angle
			//ac > at
			{
				//distance in positive direction smaller
				//==>at-----ac==>
				if (sk.b[i].angle - kf->angle[i] > 180)
					kf->speed_a[i] = (360 - sk.b[i].angle) + kf->angle[i];
				else
					//rotate in negative direction
					//at<=====ac
					kf->speed_a[i] = sk.b[i].angle - kf->angle[i];
			}

			//angle change speed is difference times keyframe time
			kf->speed_a[i] = kf->speed_a[i] * (1000 / kf->t_frame);

			//length change speed
			kf->speed_l[i] = -(sk.b[i].length - kf->length[i]) * (1000 / kf->t_frame);

			//width change speed
			kf->speed_w[i] = -(sk.b[i].width - kf->width[i]) * (1000 / kf->t_frame);
		}

		//hara reference
		kf->hara_r.x = 0;
		kf->hara_r.y = 0;

		//forward animation
		if (kf->dir == 0)
			kf->hara_t = kf->hara;
		else
		{
			//backward animation
			kf->hara_t.x = -kf->hara.x;
			kf->hara_t.y = -kf->hara.y;
		}

		//hara position change speed
		kf->speed_h.x = ((sk.p_ref->v.p[0].x + kf->hara_t.x) - sk.p_ref->v.p[0].x) * (1000 / kf->t_frame);
		kf->speed_h.y = ((sk.p_ref->v.p[0].y + kf->hara_t.y) - sk.p_ref->v.p[0].y) * (1000 / kf->t_frame);
		}
		else
		//player 2
		{
		//for every bone calculate speed of change
		//use speed-arrays to store difference int angle, lenght and width
		for (register int i = 0; i < 19; ++i)
		{
			//current angle <= target angle
			//ac <= at
			if (sk.b[i].angle <= 180 - kf->angle[i])
			{
				//distance in positive direction smaller/equal to 180
				//rotate angle in positive direction
				//ac=====>at
				if ((180 - kf->angle[i]) - sk.b[i].angle <= 180)
					kf->speed_a[i] = (180 - kf->angle[i]) - sk.b[i].angle;
				else
					//rotate in negativ direction
					//<==ac-----at<==
					kf->speed_a[i] = sk.b[i].angle + (360 - (180 - kf->angle[i]));
			}
			else
			//current angle > target angle
			//ac > at
			{
				//distance in positive direction smaller
				//==>at-----ac==>
				if (sk.b[i].angle - (180 - kf->angle[i]) > 180)
					kf->speed_a[i] = (360 - sk.b[i].angle) + (180 - kf->angle[i]);
				else
					//rotate in negative direction
					//at<=====ac
					kf->speed_a[i] = sk.b[i].angle - (180 - kf->angle[i]);
			}

			//angle change speed is difference times keyframe time
			kf->speed_a[i] = kf->speed_a[i] * (1000 / kf->t_frame);

			//length change speed
			kf->speed_l[i] = -(sk.b[i].length - kf->length[i]) * (1000 / kf->t_frame);

			//width change speed
			kf->speed_w[i] = -(sk.b[i].width - kf->width[i]) * (1000 / kf->t_frame);
		}

		//hara reference
		kf->hara_r.x = 0;
		kf->hara_r.y = 0;

		//forward animation
		if (kf->dir == 0)
			kf->hara_t = kf->hara;
		else
		{
			//backward animation
			kf->hara_t.x = -kf->hara.x;
			kf->hara_t.y = -kf->hara.y;
		}

		//hara position change speed
		kf->speed_h.x = ((sk.p_ref->v.p[0].x + kf->hara_t.x) - sk.p_ref->v.p[0].x) * (1000 / kf->t_frame);
		kf->speed_h.y = ((sk.p_ref->v.p[0].y + kf->hara_t.y) - sk.p_ref->v.p[0].y) * (1000 / kf->t_frame);
		}
	}

	//---- interpolation -------------------------------------------------------------------------

	//!! der ganze else shit kann raus, wenn es am ende eh neu gemacht wird
	//!! genauso wie der int scheiss
	//!!! temp variable zum ergebniss speichern, damit nur einmal berechnet?
	//for every bone
	if (id == P1)
	{
	for (register int i = 0; i < 19; ++i)
	{
		//if current angle is not target angle (integer precision)
		if ((int)sk.b[i].angle != (int)kf->angle[i])
		{
			//ac <= at
			if (sk.b[i].angle <= kf->angle[i])
			{
				if (kf->angle[i] - sk.b[i].angle <= 180)
				{
					//ac=====>at
					if (sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= kf->angle[i])
							sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
				else
				{
					//<==ac-----at<==
					if (sk.b[i].angle < kf->angle[i] || sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= kf->angle[i])
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = kf->angle[i];
				}
			}
		else
		{
			//at > ac
			if (sk.b[i].angle - kf->angle[i] > 180)
			{
				//==>at-----ac==>
				if (sk.b[i].angle > kf->angle[i] || sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= kf->angle[i])
					sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = kf->angle[i];
			}
			else
			{
				//at<=====ac
				if (sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= kf->angle[i])
					sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = kf->angle[i];
			}
		}

		//check angle for limits
		if (sk.b[i].angle < 0)		sk.b[i].angle += 360;
		if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;

		//length
		if (kf->speed_l[i] > 0)
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed <= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];
		else
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed >= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];

		//width
		if (kf->speed_w[i] > 0)
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed <= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		else
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed >= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		}
	}
	}
	else
	//player 2
	{
	for (register int i = 0; i < 19; ++i)
	{
		//if current angle is not target angle (integer precision)
		if ((int)sk.b[i].angle != (int)(180 - kf->angle[i]))
		{
			//ac <= at
			if (sk.b[i].angle <= 180 - kf->angle[i])
			{
				if ((180 - kf->angle[i]) - sk.b[i].angle <= 180)
				{
					//ac=====>at
					if (sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= 180 - kf->angle[i])
							sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = 180 - kf->angle[i];
				}
				else
				{
					//<==ac-----at<==
					if (sk.b[i].angle < 180 - kf->angle[i] || sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= 180 - kf->angle[i])
						sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
					else
						//set to target angle
						sk.b[i].angle = 180 - kf->angle[i];
				}
			}
		else
		{
			//at > ac
			if (sk.b[i].angle - (180 - kf->angle[i]) > 180)
			{
				//==>at-----ac==>
				if (sk.b[i].angle > 180 - kf->angle[i] || sk.b[i].angle + kf->speed_a[i] * t_sca * s_speed <= 180 - kf->angle[i])
					sk.b[i].angle += kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = 180 - kf->angle[i];
			}
			else
			{
				//at<=====ac
				if (sk.b[i].angle - kf->speed_a[i] * t_sca * s_speed >= 180 - kf->angle[i])
					sk.b[i].angle -= kf->speed_a[i] * t_sca * s_speed;
				else
					//set to target angle
					sk.b[i].angle = 180 - kf->angle[i];
			}
		}

		//check angle for limits
		if (sk.b[i].angle < 0)		sk.b[i].angle += 360;
		if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;

		//length
		if (kf->speed_l[i] > 0)
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed <= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];
		else
			if ((int)sk.b[i].length + kf->speed_l[i] * t_sca * s_speed >= (int)kf->length[i])
				sk.b[i].length += kf->speed_l[i] * t_sca * s_speed;
			else
				sk.b[i].length = kf->length[i];

		//width
		if (kf->speed_w[i] > 0)
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed <= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		else
			if ((int)sk.b[i].width + kf->speed_w[i] * t_sca * s_speed >= (int)kf->width[i])
				sk.b[i].width += kf->speed_w[i] * t_sca * s_speed;
			else
				sk.b[i].width = kf->width[i];
		}
	}
	}

	//hara x-axis
	if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed != kf->hara_t.x)
	{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
	}

	//hara y-axis
	if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed != kf->hara_t.y)
	{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
	}

/*	if (kf->speed_h.x > 0)
		if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed <= kf->hara_t.x)
		{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
		}
	else
		if (kf->hara_r.x + kf->speed_h.x * t_sca * s_speed >= kf->hara_t.x)
		{
			kf->hara_r.x		+= kf->speed_h.x * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].x	+= kf->speed_h.x * t_sca * s_speed;
		}*/

/*	//hara y-axis
	if (kf->speed_h.y > 0)
		if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed <= kf->hara_t.y)
		{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
		}
	else
		if (kf->hara_r.y + kf->speed_h.y * t_sca * s_speed >= kf->hara_t.y)
		{
			kf->hara_r.y		+= kf->speed_h.y * t_sca * s_speed;
			//apply offset to player position
			sk.p_ref->v.p[0].y	+= kf->speed_h.y * t_sca * s_speed;
		}*/

	//--------------------------------------------------------------------------------------------

/*	//return 0 if keyframe is not done and 1 if so
	if (t_current <= kf->t_kfstart + (t_freq / (1000 / kf->t_frame) / s_speed))
		//keyframe not done
		return(0);
	else
	{
		//reset state
		kf->state = 0;

		//set hara to target
		kf->hara_r.x		= kf->hara_t.x - kf->hara_r.x;
		sk.p_ref->v.p[0].x	+= kf->hara_r.x;
		kf->hara_r.y		= kf->hara_t.y - kf->hara_r.y;
		sk.p_ref->v.p[0].y	+= kf->hara_r.y;

		if (id == P1)
		{
		//set all bones to target positions
		for (register int i = 0; i < 19; ++i)
		{
			//angle
			sk.b[i].angle = kf->angle[i];
			//length
			sk.b[i].length = kf->length[i];
			//width
			sk.b[i].width = kf->width[i];
		}
		}
		else
		{
		//set all bones to target positions
		for (register int i = 0; i < 19; ++i)
		{
			//angle
			sk.b[i].angle = 180 - kf->angle[i];
			//length
			sk.b[i].length = kf->length[i];
			//width
			sk.b[i].width = kf->width[i];
		}
		}

		//keyframe done
		return(1);
	}*/
/*	};

	//---- create_idle_cycle ---------------------------------------------------------------------

	//!!
	void create_idle_cycle()
	{
		IHX; IHY;

		//vielleicht mit diffn/diffp und ui dann von fatigue abh�ngig machen?
		//kompletten cycle erstellen
		//zufallszahlen
		//return in idle position zu langsam, deshalb vorher default?
		//idle und default(?) anpassen an armhaltung
		//neu erstellen, wenn stance_arms change
		//kopf immer im winkel richtung gegner? (wenn geduckt?)
		//
		//zeitmodifikator f�r alle aktionen f�r damage?
		//f�r gesamte animation?#
		//quadratisch?

		//daten f�r gamelogic:
		//schaden
		//effizienz_speed, damage
		//
	};*/


/*	animator member functions
	//---- activate_slot -------------------------------------------------------------------------

	void activate_slot(int slot, int player_action)
	{
		//if slot already active delete it first
		if (p_aslot[slot] != NULL)
			deactivate_slot(slot);

		//assign animation
		p_aslot[slot] = p_anmn[*p_asi][player_action];

		//set prioritiy
		set_priority();
	};

	//---- deactivate_slot -----------------------------------------------------------------------

	void deactivate_slot(int slot)
	{
		//if slot is valid
		if (p_aslot[slot] != NULL)
		{
			//!!
			//call player function which sets fatigue if
			//action is overwritten (need flag to indicate that fatigue not alreay applied)

			//for all bones
			for (register int b = 0; b < 21; ++b)
			{
				//reset current keyframe index of bone of slot to delete
				if (casi[b] == slot)
					cki[b] = 0;
			}

			//reset runtime data of animation and of all its keyframes
			p_aslot[slot]->reset_runtime_data(*P);
			//clear slot
			p_aslot[slot] = NULL;
			//set prioritiy
			set_priority();
		}
	};

	//---- set_priority --------------------------------------------------------------------------
	//called whenever an animation is activated or deactivated
	//sets casi and cki of animator depending on priorities of animation

	void set_priority()
	{
		//!!
		if (p_aslot[aslot_cycle] == NULL &&	p_aslot[aslot_action] == NULL)
			return;

		//reset bone priority counter
		ZeroMemory(&bpc, sizeof(bpc));
		//reset bone done counter
		ZeroMemory(&bdc, sizeof(bdc));

		//---- both slots active -----------------------------------------------------------------

		if (p_aslot[aslot_cycle] != NULL &&
			p_aslot[aslot_action] != NULL)
		{
			//for every bone
			for (register int b = 0; b < 21; ++b)
				//if priority of bone in slot 0 is bigger than priority of bone in slot 1
				if (p_aslot[aslot_cycle]->priority[b] > p_aslot[aslot_action]->priority[b])
				{
					//if assigned animation of bone changed
					if (casi[b] != aslot_cycle)
					{
						//reset keyframe state for this bone
						p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
						//reset cki of bone
						cki[b] = 0;
					}

					//assign bone to slot 0
					casi[b] = aslot_cycle;
					//increase number of bones in slot 0 with priority of priority of bone
					++bpc[aslot_cycle][p_aslot[aslot_cycle]->priority[b]];
					//increase number of bones in slot 0
					++bpc[aslot_cycle][21];
				}
				else
				{
					//if assigned animation of bone changed
					if (casi[b] != aslot_action)
					{
						//reset keyframe state for this bone
						p_aslot[casi[b]]->pkf[cki[b]].state[*P][b] = 0;
						//reset cki of bone
						cki[b] = 0;
					}

					//assign bone to slot 1
					casi[b] = aslot_action;
					//increase number of bones in slot 1 with priority of priority of bone
					++bpc[aslot_action][p_aslot[aslot_action]->priority[b]];
					//increase number of bones in slot 1
					++bpc[aslot_action][21];
				}

			//holds most advanced keyframe for both slots
			int makf[2] = {0};
			//for both slots
			for (register int s = 0; s < 2; ++s)
				//for every bone
				for (b = 0; b < 21; ++b)
					//set highest cki
					if (casi[b] == s && cki[b] > makf[s])
						makf[s] = cki[b];
			//set cki of all bones to highest cki in slot
			for (s = 0; s < 2; ++s)
				for (b = 0; b < 21; ++b)
					if (casi[b] == s)
						cki[b] = makf[s];

			return;
		}

		//---- only one slot active --------------------------------------------------------------

		//holds active slot
		int slot = 0;
		if (p_aslot[aslot_cycle] != NULL)	slot = aslot_cycle;
		if (p_aslot[aslot_action] != NULL)	slot = aslot_action;

		//for all bones
		for (register int b = 0; b < 21; ++b)
		{
			//set casi to active slot
			casi[b] = slot;

			//increase number of bones in active slot with priority of priority of bone
			++bpc[slot][p_aslot[slot]->priority[b]];
			//increase number of bones in active slot
			++bpc[slot][21];
		}

		//holds most advanced keyframe in active slot
		int makf = 0;
		for (b = 0; b < 21; ++b)
			if (cki[b] > makf)
				makf = cki[b];
		//set cki of all bones to highest cki in slot
		for (b = 0; b < 21; ++b)
			cki[b] = makf;

		return;
	};

	//---- process_input -------------------------------------------------------------------------

	void process_input(int PA[2][NPAN], int angle[2], int angle_180[2])
	{
		//----------------------------------------------------------------------------------------

		//if asi changes cancel all slots
		//!! �berfl�ssig
		//!! ans ende
		if (PA[*P][AN_STANCE_FEET] == AS_ACTIVE ||
			PA[*P][AN_CHANGE_SIDE] == AS_ACTIVE)
		{
			deactivate_slot(aslot_action);
			deactivate_slot(aslot_cycle);
			return;
		}

		//!! neue slots z�hlen und am ende priority setzen?

		//----------------------------------------------------------------------------------------

		//!!
		if (PA[*P][AN_WALK_FWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[*p_asi][AN_WALK_FWD])
			deactivate_slot(aslot_cycle);
		if (PA[*P][AN_WALK_BWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[*p_asi][AN_WALK_BWD])
			deactivate_slot(aslot_cycle);
		if (PA[*P][AN_WALK_FWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[*p_asi][AN_WALK_FWD])
			activate_slot(aslot_cycle, AN_WALK_FWD);
		if (PA[*P][AN_WALK_BWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[*p_asi][AN_WALK_BWD])
			activate_slot(aslot_cycle, AN_WALK_BWD);

		if (PA[*P][AN_JAB] == AS_PRE)
		{
			activate_slot(aslot_action, AN_JAB);
			p_aslot[aslot_action]->state[*P]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}
		if (PA[*P][AN_JAB] == AS_FINAL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_JAB])
		{
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}
		if (PA[*P][AN_JAB] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_JAB])
		{
			//!! entweder advance keyframe bis zur ersten r�ckdirection oder
			//einfach nur canceln
			deactivate_slot(aslot_action);
		}

		if (PA[*P][AN_CROSS] == AS_PRE)
		{
			activate_slot(aslot_action, AN_CROSS);
			p_aslot[aslot_action]->state[*P]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[*P] = 0;
		}
		if (PA[*P][AN_CROSS] == AS_FINAL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_CROSS])
		{
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}
		if (PA[*P][AN_CROSS] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_CROSS])
		{
			deactivate_slot(aslot_action);
		}

		if (PA[*P][AN_KICK_SWD] == AS_PRE)
		{
			activate_slot(aslot_action, AN_KICK_SWD);
			p_aslot[aslot_action]->state[*P]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[*P] = 0;
		}
		if (PA[*P][AN_KICK_SWD] == AS_FINAL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_KICK_SWD])
		{
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P]	= 1;
		}
		if (PA[*P][AN_KICK_SWD] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_KICK_SWD])
		{
			deactivate_slot(aslot_action);
		}

		if (PA[*P][AN_KICK_FWD] == AS_PRE)
		{
			activate_slot(aslot_action, AN_KICK_FWD);
			p_aslot[aslot_action]->state[*P]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[*P] = 0;
		}
		if (PA[*P][AN_KICK_FWD] == AS_FINAL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_KICK_FWD])
		{
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P]	= 1;
		}
		if (PA[*P][AN_KICK_FWD] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_KICK_FWD])
		{
			deactivate_slot(aslot_action);
		}

		if (PA[*P][AN_DEFEND] == AS_ACTIVE)
		{
			if (0 + (rand() & (1 - 0 + 1)) == 0)
				activate_slot(aslot_action, AN_EVADE_HI);
//				activate_slot(aslot_action, AN_TAP_JAB);
			else
				activate_slot(aslot_action, AN_EVADE_MI);
//				activate_slot(aslot_action, AN_TAP_CROSS);
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}

		if (PA[*P][AN_TAP_JAB] == AS_FINAL)
		{
			activate_slot(aslot_action, AN_TAP_JAB);
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}

		if (PA[*P][AN_TAP_LEG] == AS_FINAL)
		{
			activate_slot(aslot_action, AN_TAP_LEG);
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}

		if (PA[*P][AN_EVADE_MI] == AS_FINAL)
			activate_slot(aslot_action, AN_EVADE_MI);

		if (PA[*P][AN_EVADE_HI] == AS_FINAL)
			activate_slot(aslot_action, AN_EVADE_HI);

		if (PA[*P][AN_DUCK] == AS_FINAL)
			activate_slot(aslot_action, AN_DUCK);

		//stop jab
		if (PA[*P][AN_STOP_JAB] == AS_FINAL)
		{
			activate_slot(aslot_action, AN_STOP_JAB);
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}
/*		if (PA[*P][AN_STOP_JAB] == AS_PRE)
		{
			activate_slot(aslot_action, AN_STOP_JAB);
			p_aslot[aslot_action]->state[*P]	= AS_PRE;
			p_aslot[aslot_action]->ui_valid[*P] = 0;
		}
		if (PA[*P][AN_STOP_JAB] == AS_FINAL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_STOP_JAB])
		{
			p_aslot[aslot_action]->state[*P]	= AS_FINAL;
			p_aslot[aslot_action]->ui_valid[*P] = 1;
		}
		if (PA[*P][AN_STOP_JAB] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[*p_asi][AN_STOP_JAB])
		{
			deactivate_slot(aslot_action);
		}*/
/*
		//!! default
		if (p_aslot[aslot_cycle] == NULL && p_aslot[aslot_action] == NULL)
//			activate_slot(aslot_cycle, AN_IDLE);
			activate_slot(aslot_cycle, AN_DEFAULT);

		//---- assign user input values ----------------------------------------------------------

		if (p_aslot[aslot_cycle] != NULL)
		{
			p_aslot[aslot_cycle]->angle[*P]			= angle[*P];
			p_aslot[aslot_cycle]->angle_180[*P]		= angle_180[*P];
		}
		if (p_aslot[aslot_action] != NULL)
		{
			p_aslot[aslot_action]->angle[*P]		= angle[*P];
			p_aslot[aslot_action]->angle_180[*P]	= angle_180[*P];
		}

//		//for all actions
//		for (register int i = 0; i < NPAN; ++i)
//		{
/*			//!!
			//bestimmte kombis sind ung�ltig
			//laufen beispielsweise kann nur dann neu belegt werden
			//wenn im entsprechenden slot kein action cancel animation ist

			//---- action deactivated ------------------------------------------------------------

			if (PA[*P][i] == AS_INACTIVE)
			{
				//---- walking -------------------------------------------------------------------

				//???
				if (p_aslot[aslot_cycle] == p_anmn[*p_asi][AN_WALK_FWD] ||
					p_aslot[aslot_cycle] == p_anmn[*p_asi][AN_WALK_BWD])
					deactivate_slot(aslot_cycle);
			}

			//---- action activated --------------------------------------------------------------

			if (PA[*P][i] == AS_ACTIVE || PA[*P][i] == AS_PRE)
			{
				//---- walking -------------------------------------------------------------------

				//fwd and not already running
				if (i == AN_WALK_FWD && p_aslot[1] != p_anmn[*p_asi][AN_WALK_FWD])
					//add animation to slot 0
					p_aslot[aslot_cycle] = p_anmn[*p_asi][i];

				//bwd and not already running
				if (i == AN_WALK_BWD && p_aslot[1] != p_anmn[*p_asi][AN_WALK_BWD])
					//add animation to slot 0
					p_aslot[aslot_cycle] = p_anmn[*p_asi][i];

				//---- cancel actions ------------------------------------------------------------

				//!!
				if (i == AN_STANCE_ARMS || i == AN_CHANGE_SIDE)
					p_aslot[aslot_action] = NULL;

				if (i == AN_STANCE_FEET)
					p_aslot[aslot_cycle] = p_aslot[aslot_action] = NULL;

				//---- actions -------------------------------------------------------------------

				if (i == AN_JAB ||
					i == AN_CROSS ||
					i == AN_KICK_SWD ||
					i == AN_KICK_FWD ||
					i == AN_EVADE_HI ||
					i == AN_EVADE_MI ||
					i == AN_EVADE_LO ||
					i == AN_DUCK ||
					i == AN_TAP_JAB ||
					i == AN_TAP_CROSS ||
					i == AN_TAP_LEG ||
					i == AN_STOP_JAB ||
					i == AN_STOP_CROSS ||
					i == AN_STOP_KICK)
					p_aslot[aslot_action] = p_anmn[*p_asi][i];
			}*/
//		}

		//---- action done -----------------------------------------------------------------------

//		if (p_aslot[aslot_cycle]->state[*P] == AS_DONE)
//			;
//		if (p_aslot[aslot_cycle]->state[*P] == AS_DONE)
//			;

			//---- action deactivated ------------------------------------------------------------

/*			if (PA[*P][i] == AS_INACTIVE)
			{
				//if cycle animation
				//if (
			}

			//!!
			//animation in slot �berpr�fen

			if (PA[*P][i] == 0)
			{
				//if action running and action type is cycling
//				if (pca[asi][i] != NULL && pca[asi][i]->type == 1)
				{
					//if animation to delete from buffer is not at
					//the end of the buffer (index: noe - 1)
//					if (pca[asi][i]->buffer_index < noe - 1)
						//for all current animation indices of all bones and hara
//						for (register int i = 0; i < 21; ++i)
							//if index is next buffer after buffer to delete
//							if (cai[i] == pca[asi][i]->buffer_index + 1)
								//set animation index to one slot below current index
//								--cai[i];


					//delete animation from buffer
					//anmn_buffer.del_entry(pca[asi][i]->buffer_index)

					//delete animation from current action array
//					pca[asi][i] = NULL;
				}

				//!!! auch alle anderen animationen l�schen, falls inaktive
				//und pca pointer nicht null?
			}

			//---- new action activated ----------------------------------------------------------
			//!!
			/*
				0 wenn action nicht aktive
				1 wenn ausgel�st
				1 wenn pre ausgel�st
				2 wenn final ausgel�st
				3 wenn cancel ausgel�st
				(4 wenn done)

				wenn 0 und cycling und l�uft = animation deleten
				wenn 0 und nicht cycling und l�uft = keine ver�nderung
				wenn 1 und cycling und l�uft = keine �ndererung
				wenn 1 und cycling und l�uft nicht = adden
				wenn 1 und nicht cycling und l�uft = resetten
				wenn 1 und nicht cycling und l�uft nicht = adden
				wenn 2 = state advancen, abschliessen
				wenn 3 = deleten

				wenn animation fertig = 4 = deleten

				wenn neue animation -> alle buffer auf priorit�t testen
				und cai zuweisen

				welche animationen werden gel�scht, wenn neue dazukommen? wegen
				sequenzieller abfrage? k�nnen im PA �berhaupt mehr als zwei
				aktionen gleichzeitig aktiv sein (walking, action)?
				aktionen, die alle canceln

				direction und value
				zur�ckgeworfene bones (flag, funktion?)

				pr�fe alle animationen, die in pca nicht NULL sind
				wenn nicht default/idle/walk/etc., dann cancel
				
				x
			*/

/*			if (PA[*P][i] == AS_ACTIVE || PA[*P][i] == AS_PRE)
			{
				//if animation not yet initialized add as new animation to buffer

				//if animation already in buffer
				if (pca[asi][i] != NULL)
				{
					//reset and restart animation
				}
				else
				//not already in buffer, add
				{
					//add animation to buffer
					anmn_buffer.add_entry(panmn[asi][i]);

					//set current animation index to new animation in buffer

					//add animation to current running animations
					pca[asi][i]	= panmn[asi][i];
				}
			}*/
/*	};*/
/*
			//torso
			if (dev_bi[P1] == btul || dev_bi[P1] == btur || dev_bi[P1] == bn)
				if (p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_t] > 10)
					p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_t] -= 10;

			//left arm
			if (dev_bi[P1] == bsl || dev_bi[P1] == baul || dev_bi[P1] == ball)
				if (p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_al] > 10)
					p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_al] -= 10;

			//right arm
			if (dev_bi[P1] == bsr || dev_bi[P1] == baur || dev_bi[P1] == balr)
				if (p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ar] > 10)
					p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ar] -= 10;

			//left leg
			if (dev_bi[P1] == bhl || dev_bi[P1] == blul || dev_bi[P1] == blll || dev_bi[P1] == bfl)
				if (p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ll] > 10)
					p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ll] -= 10;

			//right leg
			if (dev_bi[P1] == bhr || dev_bi[P1] == blur || dev_bi[P1] == bllr || dev_bi[P1] == bfr)
				if (p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_lr] > 10)
					p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_lr] -= 10;


			//torso
			if (dev_bi[P1] == btul || dev_bi[P1] == btur || dev_bi[P1] == bn)
				p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_t] += 10;

			//left arm
			if (dev_bi[P1] == bsl || dev_bi[P1] == baul || dev_bi[P1] == ball)
				p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_al] += 10;

			//right arm
			if (dev_bi[P1] == bsr || dev_bi[P1] == baur || dev_bi[P1] == balr)
				p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ar] += 10;

			//left leg
			if (dev_bi[P1] == bhl || dev_bi[P1] == blul || dev_bi[P1] == blll || dev_bi[P1] == bfl)
				p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_ll] += 10;

			//right leg
			if (dev_bi[P1] == bhr || dev_bi[P1] == blur || dev_bi[P1] == bllr || dev_bi[P1] == bfr)
				p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[slot_lr] += 10;
*/
/*
//!! mark current bone in t_frame and priority
	//mark cai, ckfi
	RECT	r;	fillRECT(r, 34 * 8, 33 * 16, 43 * 8, 34 * 16);	dd.drawrectangle_f(r, blue);
	fillRECT(r, 34 * 8, 35 * 16, 43 * 8, 36 * 16);				dd.drawrectangle_f(r, red);

	//current animation index, number of keyframes, current keyframe index
	dd.typefont(35 * 8, 33 * 16, "cai:");		dd.typefont(41 * 8, 33 * 16, "", dev_cai, 0);
	dd.typefont(35 * 8, 34 * 16, "nokf:");		dd.typefont(41 * 8, 34 * 16, "", p_dev_a[dev_cai]->nokf, 0);
	dd.typefont(35 * 8, 35 * 16, "ckfi:");		dd.typefont(41 * 8, 35 * 16, "", dev_ckf, 0);

	//animation priorities
	dd.typefont(1 * 8, 28 * 16, "tors arml armr legl legr hara");
	dd.typefont(1 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[0], 0);
	dd.typefont(6 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[1], 0);
	dd.typefont(11 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[2], 0);
	dd.typefont(16 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[3], 0);
	dd.typefont(21 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[4], 0);
	dd.typefont(26 * 8, 29 * 16, "", p_dev_a[dev_cai]->priority[5], 0);

	//animation time
	dd.typefont(1 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[0], 0);
	dd.typefont(6 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[1], 0);
	dd.typefont(11 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[2], 0);
	dd.typefont(16 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[3], 0);
	dd.typefont(21 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[4], 0);
	dd.typefont(26 * 8, 30 * 16, "", p_dev_a[dev_cai]->pkf[dev_ckf].t_frame[5], 0);

	//sound id, fatigue, damage, special
	dd.typefont(1 * 8, 31 * 16, "sound-id fatigue damage special");
	dd.typefont(1 * 8, 32 * 16, "", p_dev_a[dev_cai]->sound_id, 0);
	dd.typefont(10 * 8, 32 * 16, "", p_dev_a[dev_cai]->fatigue, 0);
	dd.typefont(18 * 8, 32 * 16, "", p_dev_a[dev_cai]->damage, 0);
//	dd.typefont(25 * 8, 32 * 16, "", p_dev_a[dev_cai]->special, 0);
*/

//------------------------------------------------------------------------------------------------
//
//	keyframe__
//
//------------------------------------------------------------------------------------------------
/*
struct keyframe
{
	//!! on changes --> copy constructor!

	int			t_frame[6];						//time in milliseconds for the keyframe positions
												//to be reached, for each slot plus hara-coordinates
//	int			t_frame[21];					//time in milliseconds for the keyframe positions
												//to be reached, for ech bone plus hara
//	LONGLONG	t_kfstart;						//still required? in animator?

	//offset to absolut default position?
	point		hara;							//hara destination offset
//	point		hara_t;							//adjusted hara target for forward/backward animation
	point		hara_r;							//hara reference position
//	point		speed_h;						//speed of hara position change in pixel per second
												//(for both axis)
//	point		priority_h;						//hara priority (x and y separate)
//	point		hara_absolut?

	float		angle[19];						//destination angle of all bones
	float		length[19];						//destination length of all bones
	float		width[19];						//destination width of all bones

//	float		speed_a[19];					//speed of angle change in degrees per second
//	float		speed_l[19];					//speed of length change in pixel per second
//	float		speed_w[19];					//speed of width change in pixel per second

	int			mode_a[19];						//mode of angle
												//0 = absolute
												//1 = relative to parent bone
												//2 = relative to current angle
												//!!! bedeutet relativ zu default kf?

	int			type;							//0 = standard
												//1 = buffer keyframe for attacks
												//2 = feet stance change keyframe
												//3 = xxx

	int			action;							//0 = passive
												//1 = active (also for defence? //!!)
	int			dir;							//direction, 0 = forward, 1 = backward

	//!!!
	//special flags, die vorerst leer bleiben, aber sp�ter genutzt werden k�nnen

	//!!
	//angepasster winkel? formel?

	//---- runtime data --------------------------------------------------------------------------

	//int		state[2][21];					//state of keyframe for both players for all bones and hara
												//0 = uninitialized
												//1 = initialized

	//---- constructor ---------------------------------------------------------------------------

	keyframe()
	{
		//default time 100 milliseconds
		t_frame[0] = t_frame[1] = t_frame[2] =
		t_frame[3] = t_frame[4] = t_frame[5] = 100;

		hara.x = hara.y = 0;

		ZeroMemory(&angle, sizeof(angle));
		ZeroMemory(&length, sizeof(length));
		ZeroMemory(&width, sizeof(width));
		ZeroMemory(&mode_a, sizeof(mode_a));

		type		= 0;
		action		= 0;
		dir			= 0;
	};

	//---- copy constructor ----------------------------------------------------------------------

	keyframe(const keyframe &kf)
	{
		//copy all data

		for (register int i = 0; i < 6; ++i)
			t_frame[i]	= kf.t_frame[i];

		hara		= kf.hara;
		hara_r		= kf.hara_r;
//		speed_h		= kf.speed_h;

		for (i = 0; i < 19; ++i)
		{
			angle[i]	= kf.angle[i];
			length[i]	= kf.length[i];
			width[i]	= kf.width[i];

//			speed_a[i]	= kf.speed_a[i];
//			speed_l[i]	= kf.speed_l[i];
//			speed_w[i]	= kf.speed_w[i];

			mode_a[i]	= kf.mode_a[i];
		}

		type		= kf.type;
		action		= kf.action;
		dir			= kf.dir;
	};
};*/

//------------------------------------------------------------------------------------------------
//
//	animation_
//
//------------------------------------------------------------------------------------------------
/*
struct animation
{
	keyframe	*pkf;							//pointer to array of keyframes
	int			nokf;							//number of keyframes of animation

	//int			valid_combo[NPAN];				//0 = void
												//1 = valid
												//2 = valid if active and backwards

	int			priority[6];					//priority level of five body parts plus hara
//	int			priority[21];					//priority level for all bones plus hara (x, y)

	//float		cancel_fat_factor (oder einfach int)
	//frameindex f�r welches die formel gilt

	/*
	f�r alle bones und hara
		f�r winkel, l�nge, breite und hara position
		indikator ob genutzt oder nicht

	minimal-wert +/- (abs. differenz minimal-maximalwert / max input value) * input value

	minimalwert
	maximalwert
		dadurch errechnet sich differenz und vorzeichen
	max input value = 180
	input value = dynamisch

	minimalwert = winkel in letztem keyframe (hinrichtung)
	0/1			= -/+
	diff		=
	*/

/*	int			special;						//!!
	//!!!
	//special flags, die vorerst leer bleiben, aber sp�ter genutzt werden k�nnen
	//!!
	//int		type;							//cycling (walking)
	//ID?

	int			sound_id;						//sound id to be played (starting when animation starts)
	int			fatigue;						//fatigue the animation causes, applied either after animation
												//is done (non-attacking) or on the way back (attacking)
	int			damage;							//damage the animation causes

	//---- runtime data --------------------------------------------------------------------------

	//int		state[2];						//state of animation
												//!!
												//1 = done

	//---- constructor ---------------------------------------------------------------------------

	animation()
	{
		pkf			= NULL;
		nokf		= 0;
		sound_id	= 0;
		fatigue		= 0;
		damage		= 0;

		ZeroMemory(&priority, sizeof(priority));

		special		= 0;
	};

	//---- destructor ----------------------------------------------------------------------------

	~animation()
	{
		//delete allocated keyframe array
		if (pkf != NULL)
		{
			delete [] pkf;
			pkf		= NULL;
		}

		nokf	= 0;
	};

	//---- reset_state ---------------------------------------------------------------------------

	bool reset_state(int player)
	{
		//reset temporary animation state
		//state[player] = 0;

		//for all keyframes
		//for (register int i = 0; i < nokf; ++i)
		//	pkf.state[player] = 0;
	};

	//---- verify_animation ----------------------------------------------------------------------
	//argument is pointer to array with current running animations

	bool verify_animation(animation *pca[2][NPAN], int asi)
	{
		//for all animations
//		for (register int i = 0; i < NPAN; ++i)
			//if animation running
//			if (pca[asi][i] != NULL)
				//if animation not cycling (walking)
//				if (pca[asi][i].type != 2)
					//if not valid
//					if (valid_combo[i] == 0)
//						return false;

	//eigene direction 1 (zur�ck), immer true
	/*
		//for every action
		for (register int i = 0; i < NPAN; ++i)
			//if animation running which is not compatible return false
			if (animation.valid_combo[i] == 0 && cur_animation[i] == 1)
				if (cur_animation[i].type != continuierlich)
					return false;
	*/

/*		return true;
	};

	//---- load_animation ------------------------------------------------------------------------
	//loads specified animation from file

	bool load_animation(char *file, int version, int type)		//type 0 = animation, 1 = keyframe
	{
		switch (version)
		{
		case (0):
			{
				//open animation file
				FILE	*f_animation = fopen(file, "rb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//read animation header if type 0
					if (type == 0)
					{
						fscanf(f_animation,
							   "%i %i %i %i %i %i %i %i %i %i %i",
							   &nokf,
							   &sound_id, &fatigue, &damage,
							   &priority[0], &priority[1], &priority[2], &priority[3], &priority[4], &priority[5],
							   &special);

						//delete old keyframe array and create new one with size of nokf (at least size 1)
						//if read in nokf of animation ist at least 1
						if (nokf < 1)
						{
							//close file
							fclose(f_animation);

							return false;
						}
						else
						{
							//delete allocated keyframe array
							if (pkf != NULL)
							{
								delete [] pkf;
								pkf		= NULL;
							}

							//create array of keyframes
							pkf		= new keyframe[nokf];

							//return false if allocation fails, else true
							if (pkf == NULL)
							{
								nokf	= 0;

								//close file
								fclose(f_animation);

								return false;
							}
						}
					}

					//read keyframe data
					//number of keyframes to load, either whole animation or just one keyframe
					int nokf_r;
					type == 0 ? nokf_r = nokf : nokf_r = 1;
					for (register int kfi = 0; kfi < nokf_r; ++kfi)
					{
						fscanf(f_animation,
							   "%i %i %i %i %i %i %f %f %i %i %i",
								&pkf[kfi].t_frame[0], &pkf[kfi].t_frame[1], &pkf[kfi].t_frame[2], &pkf[kfi].t_frame[3], &pkf[kfi].t_frame[4], &pkf[kfi].t_frame[5],
								&pkf[kfi].hara.x, &pkf[kfi].hara.y,
								&pkf[kfi].type,
								&pkf[kfi].action,
								&pkf[kfi].dir);

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							fscanf(f_animation,
								"%f %f %f %i",
								&pkf[kfi].angle[b],
								&pkf[kfi].length[b],
								&pkf[kfi].width[b],
								&pkf[kfi].mode_a[b]);
						}
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;

				break;
			}

		case (1):
			{
				break;
			}
		}

		return false;
	};

	//---- save_animation ------------------------------------------------------------------------
	//saves specified animation in file

	bool save_animation(char *file, int version, int type)			//type 0 = animation, 1 = single keyframe
		//!! hara
	{
		switch (version)
		{
		case (0):
			{
				//open animation file
				FILE	*f_animation = fopen(file, "wb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//write animation header if no single keyframe
					if (type == 0)
						fprintf(f_animation,
								"%i\n %i %i %i\n %i %i %i %i %i %i\n %i\n",	//nokf, sound id, fatigue, damage, priorities, special
								nokf,
								sound_id, fatigue, damage,
								priority[0], priority[1], priority[2], priority[3], priority[4], priority[5],
								special);

					//write keyframe data
					//number of keyframes to write, either whole animation or just one keyframe
					int nokf_w;
					type == 0 ? nokf_w = nokf : nokf_w = 1;

					for (register int kfi = 0; kfi < nokf_w; ++kfi)
					{
						fprintf(f_animation,
								"%i %i %i %i %i %i\n %.f %.f\n %i\n %i\n %i\n",	//t_frame[6], hara.x/y, type, action, dir
								pkf[kfi].t_frame[0], pkf[kfi].t_frame[1], pkf[kfi].t_frame[2], pkf[kfi].t_frame[3], pkf[kfi].t_frame[4], pkf[kfi].t_frame[5],
								pkf[kfi].hara.x, pkf[kfi].hara.y,
								pkf[kfi].type,
								pkf[kfi].action,
								pkf[kfi].dir);

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							fprintf(f_animation,
									"%.f %.f %.f\n %i\n",		//angle, length, width, mode_a
									pkf[kfi].angle[b],
									pkf[kfi].length[b],
									pkf[kfi].width[b],
									pkf[kfi].mode_a[b]);
						}

						//set keyframe end sign
						if (type == 0)
							fprintf(f_animation,
									"\n\n");
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;

				break;
			}

		case (1):
			{
				break;
			}
		}

		return false;
	};

	//---- add_keyframe --------------------------------------------------------------------------

	bool add_keyframe()
	{
		//pointer to old keyframe array
		keyframe	*okf = pkf;

		//allocate new array with size + 1
		pkf			= new keyframe[nokf + 1];

		//return false if allocation fails, else true
		if (pkf == NULL)
		{
			//redirect pointer to old array
			pkf		= okf;
			okf		= NULL;
			return false;
		}
		else
		{
			//copy old keyframe array data into new one
			for (register int i = 0; i < nokf; ++i)
				pkf[i] = okf[i];

			//increase number of keyframes
			++nokf;

			//delete old array and NULL the pointer to old keyframe array
			delete [] okf;
			okf		= NULL;

			return true;
		}
	};

	//---- del_keyframe --------------------------------------------------------------------------

	bool del_keyframe()
	{
		//pointer to old keyframe array
		keyframe	*okf = pkf;

		//allocate new array with size - 1, only if array consists of more than 1 kf
		if (nokf > 1)
			pkf			= new keyframe[nokf - 1];
		else
			return false;

		//return false if allocation fails, else true
		if (pkf == NULL)
		{
			//redirect pointer to old array
			pkf		= okf;
			okf		= NULL;
			return false;
		}
		else
		{
			//copy old keyframe array data into new one
			for (register int i = 0; i < nokf - 1; ++i)
				pkf[i] = okf[i];

			//decrease number of keyframes
			--nokf;

			//delete old array and NULL the pointer to old keyframe array
			delete [] okf;
			okf		= NULL;

			return true;
		}
	};

	//---- new_animation -------------------------------------------------------------------------
	//creates new array of empty keyframes

	bool new_animation(int nkf)				//number of keyframes
	{
		//with at least size 1
		if (nkf < 1)
			return false;
		else
		{
			//number of keyframes
			nokf	= nkf;

			//create array of keyframes
			pkf		= new keyframe[nokf];

			//return false if allocation fails, else true
			if (pkf == NULL)
			{
				nokf	= 0;
				return false;
			}
			else
				return true;
		}
	};
};*/

//------------------------------------------------------------------------------------------------
//
//	developer loop
//
//------------------------------------------------------------------------------------------------
/*
//________________________________________________________________________________________________
//________________________________________________________________________________________________

						//status, help icon switch
						static int sis = 1;
						//hitboxswitch
						static int hbs = 0;
						//keyboard mode switch
						static int dmode = 0;
						if (is.dikey1D[DIK_4] & 0x80)			sis = !sis;
						if (is.dikey1D[DIK_5] & 0x80)			hbs = !hbs;
						if (is.dikey1D[DIK_6] & 0x80)			dmode = !dmode;
						if (sis == 1) {dd.typefont(144, 546, "dmode:"); dd.typefont(200, 546, "", dmode, 0);}

						//keyframe time
						//static int kftime = 100;

						//keyframes
						static keyframe_ kf[3];
						//number of keyframes
						int nokf = 3;
						//current keyframe
						static int ckf = 0;
						if (is.dikey1D[DIK_RIGHT] & 0x80 &&
							is.dikey[DIK_LSHIFT] == 0)
							if (ckf < nokf - 1)
								++ckf;
							else
								ckf = 0;
						if (is.dikey1D[DIK_LEFT] & 0x80 &&
							is.dikey[DIK_LSHIFT] == 0)
							if (ckf > 0)
								--ckf;
							else
								ckf = nokf - 1;
						if (is.dikey1D[DIK_RIGHT] & 0x80 &&
							is.dikey[DIK_LSHIFT] & 0x80)
						{
							if (ckf < nokf - 1)
								++ckf;
							else
								ckf = 0;

							for (register int b = 0; b < 19; ++b)
							{
								//angle, length, width
								P[P1].sk.b[b].angle		= kf[ckf].angle[b];
								P[P1].sk.b[b].length	= kf[ckf].length[b];
								P[P1].sk.b[b].width		= kf[ckf].width[b];
							}

							//time
							//kftime = (int)kf[ckf].t_frame;
							//center
							P[P1].sk.p_ref->v.p[0].x += kf[ckf].hara.x;
							P[P1].sk.p_ref->v.p[0].y += kf[ckf].hara.y;
						}
						if (is.dikey1D[DIK_LEFT] & 0x80 &&
							is.dikey[DIK_LSHIFT] & 0x80)
						{
							if (ckf > 0)
								--ckf;
							else
								ckf = nokf - 1;

							for (register int b = 0; b < 19; ++b)
							{
								//angle, length, width
								P[P1].sk.b[b].angle		= kf[ckf].angle[b];
								P[P1].sk.b[b].length	= kf[ckf].length[b];
								P[P1].sk.b[b].width		= kf[ckf].width[b];
							}

							//time
							//kftime = (int)kf[ckf].t_frame;
							//center
							P[P1].sk.p_ref->v.p[0].x += kf[ckf].hara.x;
							P[P1].sk.p_ref->v.p[0].y += kf[ckf].hara.y;
						}
						if (sis == 1) {dd.typefont(144, 562, "ckf:"); dd.typefont(200, 562, "", ckf, 0);}

						//kf time change
						if (is.dikey1D[DIK_UP] & 0x80)
/*							if (kftime < 1000)
								kftime += 10;
							else
								kftime = 0;*/
/*							if (kf[ckf].t_frame < 1000)
								kf[ckf].t_frame += 10;
							else
								kf[ckf].t_frame = 0;
						if (is.dikey1D[DIK_DOWN] & 0x80)
							if (kf[ckf].t_frame > 0)
								kf[ckf].t_frame -= 10;
							else
								kf[ckf].t_frame = 1000;
						if (sis == 1) {dd.typefont(144, 578, "kft:"); dd.typefont(200, 578, "", kf[ckf].t_frame, 0);}

						//animator flag
						static int af = 0;
						if (is.dikey1D[DIK_NUMPADENTER] & 0x80)
							af = !af;
						if (sis == 1) {dd.typefont(400, 530, "af:"); dd.typefont(432, 530, "", af, 0);}

						//hara reference skeleton
						static rectangle sk_href[19];
						//keyframe reference skeleton
						static rectangle sk_kref[2][19];

						if (is.dikey1D[DIK_DELETE] & 0x80)
							for (register int i = 0; i < 19; ++i)
								sk_href[i] = P[P1].sk.b[i].v;
						if (is.dikey1D[DIK_INSERT] & 0x80)
						{
							if (P[P1].stance_feet == SLEFT)
								P[P1].sk.p_ref->v.p[0].x = sk_href[0].p[0].x;
							else
								P[P1].sk.p_ref->v.p[0].x = sk_href[1].p[0].x;
						}
						if (is.dikey1D[DIK_HOME] & 0x80)
						{
							if (P[P1].stance_feet == SLEFT)
								P[P1].sk.p_ref->v.p[0].y = sk_href[0].p[0].y;
							else
								P[P1].sk.p_ref->v.p[0].y = sk_href[1].p[0].y;
						}
						if (is.dikey1D[DIK_END] & 0x80)
							for (register int i = 0; i < 19; ++i)
								sk_kref[0][i] = P[P1].sk.b[i].v;
						if (is.dikey1D[DIK_PGDN] & 0x80)
							for (register int i = 0; i < 19; ++i)
								sk_kref[1][i] = P[P1].sk.b[i].v;

						//draw reference skeletons
						if (sis == 1)
							for (register int i = 0; i < 19; ++i)
							{
								dd.drawrectangle_uf(sk_href[i], red);
								dd.drawrectangle_uf(sk_kref[0][i], blue);
								dd.drawrectangle_uf(sk_kref[1][i], lightblue);
							}

						//------------------------------------------------------------------------

						//draw floor lines (when standing on ground, feet should
						//always be between the two floor line)
						line	floor_up(0, 390, 799, 390), floor_low(0, 400, 799, 400);
						if (sis == 1) dd.drawline(floor_up, green);
						if (sis == 1) dd.drawline(floor_low, blue);

						//draw 2m and 1.9m line in center of screen
						line	r200m(399, 205, 399, 190), r185m(399, 390, 399, 205);
						if (sis == 1) dd.drawline(r200m, red);
						if (sis == 1) dd.drawline(r185m, black);

						//print player names
						RECT	r_plname1, r_plname2;
						r_plname1.left = 0;		r_plname1.right = 399;
						r_plname2.left = 400;	r_plname2.right = 799;
/*						dd.typefont((int)centerfont(option.data.name_p1, r_plname1).x,
									30,
									option.data.name_p1, 0, 0, 0, 1, 255, 255, 255, 0, 0, 0);
						dd.typefont((int)centerfont(option.data.name_p2, r_plname2).x,
									30,
									option.data.name_p2, 0, 0, 0, 1, 255, 255, 255, 0, 0, 0);
*//*						dd.typefont((int)centerfont(option.data.name_p1, r_plname1, 0.35f).x,
									29,
									option.data.name_p1, 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
						dd.typefont((int)centerfont(option.data.name_p2, r_plname2, 0.35f).x,
									29,
									option.data.name_p2, 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);

						//!!
						P[P1].winloss[0] = -1;
						P[P1].winloss[1] = 1;
						P[P1].winloss[2] = 1;
						P[P2].winloss[0] = 1;
						P[P2].winloss[1] = -1;
						P[P2].winloss[2] = -1;

						//!! nur zentriert auf bitmap font?
						//draw win points
//						dd.drawwinpoints(P[P1].wins, (int)centerfont(option.data.name_p1, r_plname1).x, P[P2].wins, (int)centerfont(option.data.name_p2, r_plname2).x);
						dd.drawwinpoints(P[P1].winloss, (int)centerfont(option.data.name_p1, r_plname1, 0.35f).x, P[P2].winloss, (int)centerfont(option.data.name_p2, r_plname2, 0.35f).x, option.data.bw_mode, option.data.rounds);

						//---- input -------------------------------------------------------------

						//bone selection
						static int bi[2] = {0};

						//reset color
						P[P1].sk.b[bi[P1]].damage = 0;		P[P2].sk.b[bi[P2]].damage = 0;
						//selection
						if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
						{
							if (is.dikey[DIK_1] & 0x80) bi[P1] = bhr;
							if (is.dikey[DIK_Q] & 0x80) bi[P1] = blur;
							if (is.dikey[DIK_A] & 0x80) bi[P1] = bllr;
							if (is.dikey[DIK_Z] & 0x80) bi[P1] = bfr;
							if (is.dikey[DIK_2] & 0x80) bi[P1] = bhl;
							if (is.dikey[DIK_W] & 0x80) bi[P1] = blul;
							if (is.dikey[DIK_S] & 0x80) bi[P1] = blll;
							if (is.dikey[DIK_X] & 0x80) bi[P1] = bfl;
							if (is.dikey[DIK_E] & 0x80) bi[P1] = bsr;
							if (is.dikey[DIK_D] & 0x80) bi[P1] = baur;
							if (is.dikey[DIK_C] & 0x80) bi[P1] = balr;
							if (is.dikey[DIK_R] & 0x80) bi[P1] = bsl;
							if (is.dikey[DIK_F] & 0x80) bi[P1] = baul;
							if (is.dikey[DIK_V] & 0x80) bi[P1] = ball;
							if (is.dikey[DIK_T] & 0x80) bi[P1] = bn;
							//lower torso in dependance of stance
							if (P[P1].stance_feet == 0)
							{
								if (is.dikey[DIK_G] & 0x80) bi[P1] = btul;
								if (is.dikey[DIK_B] & 0x80) bi[P1] = btll;
							}
							else
							{
								if (is.dikey[DIK_G] & 0x80) bi[P1] = btur;
								if (is.dikey[DIK_B] & 0x80) bi[P1] = btlr;
							}
						}
						else
						{
							if (is.dikey[DIK_1] & 0x80) bi[P2] = bhr;
							if (is.dikey[DIK_Q] & 0x80) bi[P2] = blur;
							if (is.dikey[DIK_A] & 0x80) bi[P2] = bllr;
							if (is.dikey[DIK_Z] & 0x80) bi[P2] = bfr;
							if (is.dikey[DIK_2] & 0x80) bi[P2] = bhl;
							if (is.dikey[DIK_W] & 0x80) bi[P2] = blul;
							if (is.dikey[DIK_S] & 0x80) bi[P2] = blll;
							if (is.dikey[DIK_X] & 0x80) bi[P2] = bfl;
							if (is.dikey[DIK_E] & 0x80) bi[P2] = bsr;
							if (is.dikey[DIK_D] & 0x80) bi[P2] = baur;
							if (is.dikey[DIK_C] & 0x80) bi[P2] = balr;
							if (is.dikey[DIK_R] & 0x80) bi[P2] = bsl;
							if (is.dikey[DIK_F] & 0x80) bi[P2] = baul;
							if (is.dikey[DIK_V] & 0x80) bi[P2] = ball;
							if (is.dikey[DIK_T] & 0x80) bi[P2] = bn;
							//lower torso in dependance of stance
							if (P[P2].stance_feet == 0)
							{
								if (is.dikey[DIK_G] & 0x80) bi[P2] = btul;
								if (is.dikey[DIK_B] & 0x80) bi[P2] = btll;
							}
							else
							{
								if (is.dikey[DIK_G] & 0x80) bi[P2] = btur;
								if (is.dikey[DIK_B] & 0x80) bi[P2] = btlr;
							}
						}
						//set selected bone to red
						P[P1].sk.b[bi[P1]].damage = 50;		P[P2].sk.b[bi[P2]].damage = 50;
						//print boneindex
						if (sis == 1) {dd.typefont(8, 530, "bi1:"); dd.typefont(48, 530, "", bi[P1], 0);}
						if (sis == 1) {dd.typefont(64, 530, "bi2:"); dd.typefont(104, 530, "", bi[P2], 0);}

						//print angle, length, width, pos
						if (sis == 1) {dd.typefont(8, 546, "angle:"); dd.typefont(64, 546, "", P[P1].sk.b[bi[P1]].angle, 2);}
						if (sis == 1) {dd.typefont(8, 562, "length:"); dd.typefont(72, 562, "", P[P1].sk.b[bi[P1]].length, 2);}
						if (sis == 1) {dd.typefont(8, 578, "width:"); dd.typefont(64, 578, "", P[P1].sk.b[bi[P1]].width, 2);}
						if (sis == 1) {dd.typefont(144, 530, "vp0.x:"); dd.typefont(200, 530, "", P[P1].sk.b[bi[P1]].v.p[0].x, 0);}
						if (sis == 1) {dd.typefont(240, 530, "vp0.y:"); dd.typefont(296, 530, "", P[P1].sk.b[bi[P1]].v.p[0].y, 0);}

						//change position with right mouse button
						if (is.dimouse[1].rgbButtons[1] & 0x80)
						{
							P[P1].sk.p_ref->v.p[0].x += is.dimouse[1].lX;
							P[P1].sk.p_ref->v.p[0].y += is.dimouse[1].lY;
						}
						if (is.dimouse[2].rgbButtons[1] & 0x80)
						{
							P[P2].sk.p_ref->v.p[0].x += is.dimouse[2].lX;
							P[P2].sk.p_ref->v.p[0].y += is.dimouse[2].lY;
						}

						//length and width
						if (is.dikey[DIK_LMENU] & 0x80)
						{
							//mark bone
							P[P1].sk.b[bi[P1]].damage = 100;	P[P2].sk.b[bi[P2]].damage = 100;
							P[P1].sk.b[bi[P1]].length += is.dimouse[1].lX;
							P[P2].sk.b[bi[P2]].length += is.dimouse[2].lX;
						}
						if (is.dikey[DIK_LWIN] & 0x80)
						{
							//mark bone
							P[P1].sk.b[bi[P1]].damage = 100;	P[P2].sk.b[bi[P2]].damage = 100;
							P[P1].sk.b[bi[P1]].width += is.dimouse[1].lX;
							P[P1].sk.b[bi[P2]].width += is.dimouse[2].lX;
						}

//!!						//change angle with left mouse and x-movement
//						if (is.dimouse[1].rgbButtons[0] & 0x80)
						if (is.dikey[DIK_SPACE] & 0x80)
						{
							//mark bone
							P[P1].sk.b[bi[P1]].damage = 100;
							P[P1].sk.b[bi[P1]].angle += is.dimouse[1].lX;
						}

						//copy to second player
/*						P[P2].sk.b[bn].angle			= 180 - P[P1].sk.b[bn].angle;
						P[P2].sk.b[btul].angle			= 180 - P[P1].sk.b[btur].angle;
						P[P2].sk.b[btur].angle			= 180 - P[P1].sk.b[btul].angle;
						P[P2].sk.b[btll].angle			= 180 - P[P1].sk.b[btll].angle;
						P[P2].sk.b[btlr].angle			= 180 - P[P1].sk.b[btlr].angle;

						P[P2].sk.b[bsl].angle			= 180 - P[P1].sk.b[bsr].angle;
						P[P2].sk.b[baul].angle			= 180 - P[P1].sk.b[baur].angle;
						P[P2].sk.b[ball].angle			= 180 - P[P1].sk.b[balr].angle;

						P[P2].sk.b[bsr].angle			= 180 - P[P1].sk.b[bsl].angle;
						P[P2].sk.b[baur].angle			= 180 - P[P1].sk.b[baul].angle;
						P[P2].sk.b[balr].angle			= 180 - P[P1].sk.b[ball].angle;

						P[P2].sk.b[bhl].angle			= 180 - P[P1].sk.b[bhr].angle;
						P[P2].sk.b[blul].angle			= 180 - P[P1].sk.b[blur].angle;
						P[P2].sk.b[blll].angle			= 180 - P[P1].sk.b[bllr].angle;
						P[P2].sk.b[bfl].angle			= 180 - P[P1].sk.b[bfr].angle;

						P[P2].sk.b[bhr].angle			= 180 - P[P1].sk.b[bhl].angle;
						P[P2].sk.b[blur].angle			= 180 - P[P1].sk.b[blul].angle;
						P[P2].sk.b[bllr].angle			= 180 - P[P1].sk.b[blll].angle;
						P[P2].sk.b[bfr].angle			= 180 - P[P1].sk.b[bfl].angle;
*//*						for (register int i = 0; i < 19; ++i)
						{
							P[P2].sk.b[i].length	= P[P1].sk.b[i].length;
							P[P2].sk.b[i].width		= P[P1].sk.b[i].width;
						}

						//---- keyframe loading/saving -------------------------------------------

						//load keyframe array
						if (is.dikey1D[DIK_SUBTRACT] & 0x80)
						{
							FILE *f_kf = fopen("animation_dev/keyframes.dat", "rb");

							if (f_kf != NULL)
							{
								//for every keyframe
								for (register int kfi = 0; kfi < nokf; ++kfi)
								{
									//time of keyframe, hara offset
									fscanf(f_kf,
										   "%i %f %f",
										   &kf[kfi].t_frame,
										   &kf[kfi].hara.x,
										   &kf[kfi].hara.y);

									//every bone
									for (register int b = 0; b < 19; ++b)
									{
										fscanf(f_kf,
											   "%f %f %f",
											   &kf[kfi].angle[b],
											   &kf[kfi].length[b],
											   &kf[kfi].width[b]);

										//!!! weight
										kf[kfi].width[b] = kf[kfi].width[b] * (80.0f / 80.0f);
									}
								}

								fclose(f_kf);
							}
						}

						//save keyframe array
						if (is.dikey1D[DIK_MULTIPLY] & 0x80)
						{
							FILE *f_kf = fopen("animation_dev/keyframes.dat", "wb");

							if (f_kf != NULL)
							{
								//for every keyframe
								for (register int kfi = 0; kfi < nokf; ++kfi)
								{
									//time of keyframe, hara offset
									fprintf(f_kf,
											"%i %.f %.f\n",
											kf[kfi].t_frame,
											kf[kfi].hara.x,
											kf[kfi].hara.y);

									//every bone
									for (register int b = 0; b < 19; ++b)
									{
										fprintf(f_kf,
												"%.f %.f %.f\n",
												kf[kfi].angle[b],
												kf[kfi].length[b],
												kf[kfi].width[b]);
									}
								}

								fclose(f_kf);
							}
						}

						//load current keyframe
						if (is.dikey1D[DIK_DIVIDE] & 0x80)
						{
							for (register int b = 0; b < 19; ++b)
							{
								//angle, length, width
								P[P1].sk.b[b].angle		= kf[ckf].angle[b];
								P[P1].sk.b[b].length	= kf[ckf].length[b];
								P[P1].sk.b[b].width		= kf[ckf].width[b];
							}

							//time
							//kftime = (int)kf[ckf].t_frame;
							//center
							P[P1].sk.p_ref->v.p[0].x += kf[ckf].hara.x;
							P[P1].sk.p_ref->v.p[0].y += kf[ckf].hara.y;
						}

						//save current keyframe
						if (is.dikey1D[DIK_NUMLOCK] & 0x80)
						{
							//every bone
							for (register int b = 0; b < 19; ++b)
							{
								//angle, length, width
								kf[ckf].angle[b]		= P[P1].sk.b[b].angle;
								kf[ckf].length[b]		= P[P1].sk.b[b].length;
								kf[ckf].width[b]		= P[P1].sk.b[b].width;
							}

							//time
							//kf[ckf].t_frame = kftime;
							//center
							if (P[P1].stance_feet == SLEFT)
							{
								kf[ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - sk_href[0].p[0].x;
								kf[ckf].hara.y = P[P1].sk.p_ref->v.p[0].y - sk_href[0].p[0].y;
							}
							else
							{
								kf[ckf].hara.x = P[P1].sk.p_ref->v.p[1].x - sk_href[1].p[0].x;
								kf[ckf].hara.y = P[P1].sk.p_ref->v.p[1].y - sk_href[1].p[0].y;
							}
						}

						//---- animation ---------------------------------------------------------

						//save current state
						if (is.dikey1D[DIK_7] & 0x80)
						{
							//open config file
							FILE	*f_animation = fopen("animation_dev/current.dat", "wb");

							//if file successfully opened
							if (f_animation != NULL)
							{
								//center
								//!! reference?
								fprintf(f_animation,
										"%.f %.f\n",
										P[P1].sk.b[0].v.p[0].x,
										P[P1].sk.b[0].v.p[0].y);

								//write file data from skeleton
								for (register int i = 0; i < 19; ++i)
								{
									fprintf(f_animation,
											"%.f %.f %.f\n",
											P[P1].sk.b[i].angle,
											P[P1].sk.b[i].length,
											P[P1].sk.b[i].width);
								}

								//close file
								fclose(f_animation);
							}
						}

						//load current state
						if (is.dikey1D[DIK_N] & 0x80)
						{
							FILE	*f_animation;

							if (P[P1].stance_feet == SLEFT)
								f_animation = fopen("animation_dev/current.dat", "rb");
							else
								f_animation = fopen("animation_dev/current.dat", "rb");

							//if file successfully opened
							if (f_animation != NULL)
							{
								//scan pos, but don't load
								fscanf(f_animation,
									   "%*f %*f");
/*										&pl[P1].sk.b[0].v.p[0].x,
										&pl[P1].sk.b[0].v.p[0].y);
*/

								//read file data into skeleton
/*								for (register int i = 0; i < 19; ++i)
								{
									fscanf(f_animation,
										   "%f %f %f",
										   &P[P1].sk.b[i].angle,
										   &P[P1].sk.b[i].length,
										   &P[P1].sk.b[i].width);

//									P[P2].sk.b[i].angle = 180 - P[P1].sk.b[i].angle;
/*									P[P2].sk.b[i].length = P[P1].sk.b[i].length;
									P[P2].sk.b[i].width = P[P1].sk.b[i].width;
								}

								P[P2].sk.b[bn].angle			= 180 - P[P1].sk.b[bn].angle;
								P[P2].sk.b[btul].angle			= 180 - P[P1].sk.b[btur].angle;
								P[P2].sk.b[btur].angle			= 180 - P[P1].sk.b[btul].angle;
								P[P2].sk.b[btll].angle			= 180 - P[P1].sk.b[btll].angle;
								P[P2].sk.b[btlr].angle			= 180 - P[P1].sk.b[btlr].angle;

								P[P2].sk.b[bsl].angle			= 180 - P[P1].sk.b[bsr].angle;
								P[P2].sk.b[baul].angle			= 180 - P[P1].sk.b[baur].angle;
								P[P2].sk.b[ball].angle			= 180 - P[P1].sk.b[balr].angle;

								P[P2].sk.b[bsr].angle			= 180 - P[P1].sk.b[bsl].angle;
								P[P2].sk.b[baur].angle			= 180 - P[P1].sk.b[baul].angle;
								P[P2].sk.b[balr].angle			= 180 - P[P1].sk.b[ball].angle;

								P[P2].sk.b[bhl].angle			= 180 - P[P1].sk.b[bhr].angle;
								P[P2].sk.b[blul].angle			= 180 - P[P1].sk.b[blur].angle;
								P[P2].sk.b[blll].angle			= 180 - P[P1].sk.b[bllr].angle;
								P[P2].sk.b[bfl].angle			= 180 - P[P1].sk.b[bfr].angle;

								P[P2].sk.b[bhr].angle			= 180 - P[P1].sk.b[bhl].angle;
								P[P2].sk.b[blur].angle			= 180 - P[P1].sk.b[blul].angle;
								P[P2].sk.b[bllr].angle			= 180 - P[P1].sk.b[blll].angle;
								P[P2].sk.b[bfr].angle			= 180 - P[P1].sk.b[bfl].angle;

								//close file
								fclose(f_animation);
							}
						}

						//------------------------------------------------------------------------

						//calculate shadows
						if (option.data.shadows == 1)
						{
							//day, shadow below
							if (time.ch >= 7 &&time.ch < 19)
							{
								s_scale.y	= 0.5f;
								s_scale.x	= -(((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 13) * 0.2f;
							}
							else
							{
								//night, above
								s_scale.y	= -0.4f;

								if (time.ch >= 0 && time.ch < 7)
									s_scale.x	= (((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 1) * 0.2f;
								if (time.ch >= 19 && time.ch <= 23)
									s_scale.x	= (((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 25) * 0.2f;
							}
						}
						//current time
						if (sis == 1) dd.typefont(8, 24, "", time.ch, 0);
						if (sis == 1) dd.typefont(24, 24, "", time.cm, 0);
						if (sis == 1) dd.typefont(40, 24, "", time.cs, 0);
//!!
dd.typefont(8, 40, "", time.sca);

						//---- particle ----------------------------------------------------------

						static particle_heap blood;
						static int blood_ini = 0;
						static point source;
						static int noblood = 50;

						source.x = P[P1].sk.chead.x + P[P1].sk.radius_head;
						source.y = P[P1].sk.chead.y;

						if (blood_ini == 0)
						{
							blood_ini = 1;
							blood.create_heap(time.freq,
											  time.current,
											  noblood,
											  dd.rSCREEN_ARENA_TOP);
						}

						//update particle heap
						if (blood.state == 0)
							blood.update(time.current,
										 time.sca,
										 option.data.speed,
										 option.data.shadows, s_mpy, s_scale,
										 (int)source.x, (int)source.y);

						//draw particle heap
						if (blood.state == 0)
							dd.drawparticles(blood.pp, noblood, option.data.shadows, 100);

						if (is.dimouse1D[1].rgbButtons[2] & 0x80)
						{
/*							blood.initialization(time.current,
												 0, 0,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 50, 150,
												 0, 100,
												 500, 800);*/
/*							blood.initialization(time.current,
												 1, -1,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 50, 150,
												 0, 100,
												 500, 800);

							blood.state = 0;
						}
						if (is.dimouse1D[1].rgbButtons[3] & 0x80)
						{
							blood.initialization(time.current,
												 0, 0,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 20, 150,
												 0, 100,
												 500, 800);

							blood.state = 0;
						}

						//---- animation ---------------------------------------------------------

						//---- calculate, draw players -------------------------------------------

						//subframes
						if (is.dikey1D[DIK_F10] & 0x80)
							if (option.data.subframes < option.dataMAX.subframes)
								++option.data.subframes;
							else
								option.data.subframes = option.dataMIN.subframes;

						if (is.dikey1D[DIK_F9] & 0x80)
							if (option.data.subframes > option.dataMIN.subframes)
								--option.data.subframes;
							else
								option.data.subframes = option.dataMAX.subframes;

						if (sis == 1) dd.typefont(200, 8, "", option.data.subframes, 0);
//!! all limbs active
P[P1].active[0] = 1;
P[P1].active[1] = 1;
P[P1].active[2] = 1;
P[P1].active[3] = 1;
P[P2].active[0] = 1;
P[P2].active[1] = 1;
P[P2].active[2] = 1;
P[P2].active[3] = 1;

						static bool anigo = false;
						static int lastangle = -1;

						//direction of animation
						static int dir = 0;
						if (sis == 1) {dd.typefont(400, 546, "dir:"); dd.typefont(432, 546, "", dir, 0);}

						//calculate players with subframes (subframes = whole frames)
						for (register int sf = 0; sf < option.data.subframes; ++sf)
						{
							//animate!
							if (af == 1 && anigo == true)
							{
								kf[ckf].dir = dir;
								if (1 == P[P1].animator_(&kf[ckf],
														time.freq,
														time.current,
														(float)(time.sca / (option.data.subframes)),
														option.data.speed))
								{
/*									if (ckf < nokf - 1)
										++ckf;
									else
										ckf = 0;

									if (ckf > 0)
										--ckf;
									else
										ckf = nokf - 1;*/

									//forward
/*									if (dir == 0)
										if (ckf < nokf - 1)
											++ckf;
										else
											dir = 1;

									if (dir == 1)
										if (ckf > 0)
											--ckf;
										else
										{
											dir = 0;
											ckf = 1;
											anigo = false;
											lastangle = is.angle[P1];
										}

//									kf[ckf].dir = dir;*/
/*								}
							}

							//calculate skeleton
							P[P1].process_bones(option.data.shadows, s_scale, s_mpy);
							P[P2].process_bones(option.data.shadows, s_scale, s_mpy);

							//cd
							collision_detection();
						}
						//z-sort bones (from behind to front)
						quicksort_zb(pd.pzb, 0, 37, 1);

						//print cd state
						if (sis == 1)
						{
							for (i = 0; i < 20; ++i)
							{
								dd.typefont(i * 8, 80, "", rcd.bone[P1][i], 0, 0, 1.0f, -1);
								dd.typefont(i * 8, 96, "", rcd.bone[P2][i], 0, 0, 1.0f, -1);
								if (rcd.bone[P2][i] == 1)
								{
									//play sound
									ds.stopbuffer();		sbf[S_MENTER] = ON;
									ds.playbuffer(sbf);		sbf[S_MENTER] = OFF;
								}
								//dd.typefont(i * 32, 200, "", (double)rcd.time[P1][i], 0, 0, 1.0f, -1);
								//dd.typefont(i * 32, 216, "", (double)rcd.time[P2][i], 0, 0, 1.0f, -1);

								if (i < 19)
							{
								if (rcd.time[P1][i] != 0)
								{
									if (time.current > rcd.time[P1][i] + time.freq * 0.1)
									{
										rcd.time[P1][i] = 0;
										P[P1].sk.b[i].state = 1;
									}
									else
										P[P1].sk.b[i].state = 2;
								}

								if (rcd.time[P2][i] != 0)
								{
									if (time.current > rcd.time[P2][i] + time.freq * 0.1)
									{
										rcd.time[P2][i] = 0;
										P[P2].sk.b[i].state = 1;
									}
									else
										P[P2].sk.b[i].state = 2;
								}
							}

							}
							for (i = 0; i < 4; ++i)
							{
								dd.typefont(i * 8, 112, "", rcd.attack[P1][i], 0, 0, 1.0f, -1);
								dd.typefont(i * 8, 128, "", rcd.attack[P2][i], 0, 0, 1.0f, -1);
							}
							dd.typefont(8, 144, "", rcd.head[P1], 0, 0, 1.0f, -1);
							dd.typefont(8, 160, "", rcd.head[P2], 0, 0, 1.0f, -1);
						}


						//draw hitboxes (bevor actual bones so they don't overlap)
						//only if activated
						if (hbs == 1)
						{
							for (register int i = 0; i < 19; ++i)
							{
								dd.drawrectangle_uf(P[P1].sk.b[i].hitbox, red);
								dd.drawrectangle_uf(P[P2].sk.b[i].hitbox, red);
							}
							//draw head and fist hitboxes
							dd.drawrectangle_uf(P[P1].sk.b[bn].hitbox_e, red);
							dd.drawrectangle_uf(P[P1].sk.b[ball].hitbox_e, red);
							dd.drawrectangle_uf(P[P1].sk.b[balr].hitbox_e, red);
							dd.drawrectangle_uf(P[P2].sk.b[bn].hitbox_e, red);
							dd.drawrectangle_uf(P[P2].sk.b[ball].hitbox_e, red);
							dd.drawrectangle_uf(P[P2].sk.b[balr].hitbox_e, red);
							//draw whole player hitbox
							dd.drawrectangle_uf(P[P1].sk.r_hbp, red);
							dd.drawrectangle_uf(P[P2].sk.r_hbp, red);
						}

						//draw players
						dd.drawplayers(&pd, option.data.shadows, option.data.bw_mode);

						//draw selected bone
						dd.drawrectangle_uf(P[P1].sk.b[bi[P1]].v, pink);
						dd.drawrectangle_uf(P[P2].sk.b[bi[P2]].v, pink);

						//feet-not-on-the-ground indicator
						if (P[P1].sk.b[bfl].v.p[2].y < floor_up.p[0].y ||
							P[P1].sk.b[bfl].v.p[2].y > floor_low.p[0].y)
							dd.drawrectangle_uf(P[P1].sk.b[bfl].v, red);
						if (P[P1].sk.b[bfr].v.p[2].y < floor_up.p[0].y ||
							P[P1].sk.b[bfr].v.p[2].y > floor_low.p[0].y)
							dd.drawrectangle_uf(P[P1].sk.b[bfr].v, red);

/*						//flashing bones when hit
						for (i = 0; i < 20; ++i)
						{
							if (rcd.bone[P1][i] == 1)
								if (i < 19)
									if (option.data.bw_mode == 0)
										dd.drawrectangle_bf(P[P1].sk.b[i].v, black, white);
									else
										dd.drawrectangle_bf(P[P1].sk.b[i].v, black, red);

							if (rcd.bone[P2][i] == 1)
								if (i < 19)
									if (option.data.bw_mode == 0)
										dd.drawrectangle_bf(P[P2].sk.b[i].v, black, white);
									else
										dd.drawrectangle_bf(P[P2].sk.b[i].v, black, red);
						}*/

						//---- stance ------------------------------------------------------------

						//stance change p1
/*						if (is.dikey1D[DIK_RETURN] & 0x80 && is.dikey[DIK_LSHIFT] == 0)
						{
							//change stance
							//P[P1].stance_feet = !P[P1].stance_feet;

							//reset skeleton data
							P[P1].set_stance(!P[P1].stance_feet);
						}
						//p2
						if (is.dikey1D[DIK_RETURN] & 0x80 && is.dikey[DIK_LSHIFT] & 0x80)
						{
							//P[P2].stance_feet = !P[P2].stance_feet;
							P[P2].set_stance(!P[P2].stance_feet);
						}
//						if (sis == 1) dd.typefont(600, 0, "", P[P1].stance_feet, 0);
//						if (sis == 1) dd.typefont(600, 16, "", P[P2].stance_feet, 0);

						//------------------------------------------------------------------------
dd.typefont(500, 0, "", kf[1].hara_r.x, 0);
dd.typefont(500, 16, "", kf[1].hara_r.y, 0);
dd.typefont(600, 0, "", kf[1].hara_t.x, 0);
dd.typefont(600, 16, "", kf[1].hara_t.y, 0);
dd.typefont(500, 59, "", kf[1].speed_h.x, 5);
dd.typefont(600, 59, "", kf[1].speed_h.y, 5);
dd.typefont(700, 59, "", kf[1].dir, 0);

//!!
dd.typefont(8, 450, "", dd.gcs.active, 5, 0, 1.0f, -1);
/*dd.typefont(8, 466, "", dd.gcs.time, 5, 0, 1.0f, -1);
dd.typefont(8, 482, "", dd.gcs.t_start + (dd.gcs.t_freq * dd.gcs.time), 5, 0, 1.0f, -1);
dd.typefont(8, 498, "", time.current, 5, 0, 1.0f, -1);
dd.typefont(8, 514, "", time.sca, 5, 0, 1.0f, -1);*/

						//____ aom ---------------------------------------------------------------

/*						if (is.dimouse[1].lZ < 0 && P[P1].fatigue + 5 <= 100)
							P[P1].fatigue += 5;
						if (is.dimouse[1].lZ > 0 && P[P1].fatigue - 5 >= 0)
							P[P1].fatigue -= 5;
						if (is.dimouse[2].lZ > 0 && P[P2].fatigue + 5 <= 100)
							P[P2].fatigue += 5;
						if (is.dimouse[2].lZ < 0 && P[P2].fatigue - 5 >= 0)
							P[P2].fatigue -= 5;

						static int reg = 10000;
						static float useraom = 1.0f;

						if ((is.dikey[DIK_A] & 0x80 || is.dikey[DIK_D] & 0x80) &&
							(is.dikey[DIK_A] == 0 || is.dikey[DIK_D] == 0))
							P[P1].fatigue = P[P1].fatigue + 20 * useraom * (float)time.sca * option.data.speed;

						P[P1].fatigue = P[P1].fatigue - (5 + ((5.0f / 100) * (float)sqrt(reg))) * (float)time.sca * option.data.speed;

						if (P[P1].fatigue > 100)	P[P1].fatigue = 100;
						if (P[P1].fatigue < 0)		P[P1].fatigue = 0;

						dd.typefont((int)P[P1].sk.b[0].v.p[0].x, 150, "", P[P1].fatigue, 1, 0, 1.0f, -1);

						//____ stance ____________________________________________________________

						if (is.dikey[DIK_X] & 0x80)
							P[P1].stance_arms -= is.dimouse[1].lY;
						//!! P[P1].stance_arms -= is.dimouse[1].lY * option.data.speed;
						if (P[P1].stance_arms > 100)	P[P1].stance_arms = 100;
						if (P[P1].stance_arms < 0)		P[P1].stance_arms = 0;

//						if (is.dimouse[1].lZ < 0 && P[P1].stance_arms + 5 <= 100)
//							P[P1].stance_arms += 5;
//						if (is.dimouse[1].lZ > 0 && P[P1].stance_arms - 5 >= 0)
//							P[P1].stance_arms -= 5;
						dd.typefont((int)P[P1].sk.b[0].v.p[0].x, 166, "", P[P1].stance_arms, 1, 0, 1.0f, -1);

						P[P1].sk.b[bsl].angle = 32 - (17.0 / 100.0) * P[P1].stance_arms;
						P[P1].sk.b[baul].angle = 92 - (5.0 / 100.0) * P[P1].stance_arms;
						P[P1].sk.b[ball].angle = 36 - (103.0 / 100.0) * P[P1].stance_arms;
						P[P1].sk.b[bsr].angle = 164 + (25.0 / 100.0) * P[P1].stance_arms;
						P[P1].sk.b[baur].angle = 93 - (33.0 / 100.0) * P[P1].stance_arms;
						P[P1].sk.b[balr].angle = 330 - (43.0 / 100.0) * P[P1].stance_arms;

						//____ mouse input _______________________________________________________

						if (is.angle[P1] == lastangle)
							anigo = false;
						else
							anigo = true;

//						if (is.dimouse1D[P1].rgbButtons[0] & 0x80)
//							anigo = true;
//						if (0 + (rand() % (100 - 0 + 1)) == 10)
//							anigo = true;

						dd.typefont(400, 200, "", is.angle[P1], 0, 0, 1.0f, -1);
						//shoulder
						//kf[2].angle[5] = (float)is.angle[P1];
						//kf[2].angle[6] = kf[2].angle[5];
						//kf[2].angle[7] = kf[2].angle[6] - 5;
						kf[2].angle[11] = (float)is.angle[P1];
						kf[2].angle[12] = kf[2].angle[11];
						kf[2].angle[13] = kf[2].angle[12] - 5;

						if (is.dikey[DIK_A] & 0x80)
							P[P1].sk.p_ref->v.p[0].x -= 200 * (float)time.sca * option.data.speed;
						if (is.dikey[DIK_D] & 0x80)
							P[P1].sk.p_ref->v.p[0].x += 200 * (float)time.sca * option.data.speed;

						//---- sound pan ---------------------------------------------------------

						//!!! pan nur wenn notwendig?
						//update pan every 0.1 seconds
						if (time.current > s_lastpan + time.freq * 0.1)
						{
							ds.setpan(P[P1].pan, P[P2].pan);
							s_lastpan = time.current;
						}

						static int sflag = 0;
						if (is.dikey1D[DIK_H] & 0x80)
							sflag = !sflag;

						if (sflag == 1)
						{
							ds.stopbuffer();		sbf[S_MSELECT] = ON;
							ds.playbuffer(sbf);		sbf[S_MSELECT] = OFF;
						}

						dd.typefont(400, 100, "", (P[P1].sk.p_ref->v.p[0].x * 4) - 1600,
									2, 0, 1.0f, -1);
*/

//------------------------------------------------------------------------------------------------
//
//	several
//
//------------------------------------------------------------------------------------------------
/*
		if (P[P1].side == SLEFT)
			if (P[P1].stance_feet == SLEFT)
				f_animation = fopen("animation_dev/current_sleft.dat", "rb");
			else
				f_animation = fopen("animation_dev/current_sright.dat", "rb");
		else
			if (P[P1].stance_feet == SLEFT)
				f_animation = fopen("animation_dev/current_sright.dat", "rb");
			else
				f_animation = fopen("animation_dev/current_sleft.dat", "rb");

		//if file successfully opened
		if (f_animation != NULL)
		{
			//read file data into default skeleton
			for (register int i = 0; i < 19; ++i)
			{
				fscanf(f_animation,
					   "%f %f %f",
					   &sk_def.b[i].angle;
					   &sk_def.b[i].length;
					   &sk_def.b[i].width;
//					   &P[P1].sk.b[i].angle,
//					   &P[P1].sk.b[i].length,
//					   &P[P1].sk.b[i].width);
			}

			//adapt data for side
			if (P[P1].side == SRIGHT)
			{
			}
			else
			{
			}

				P[P2].sk.b[i].length = P[P1].sk.b[i].length;
				P[P2].sk.b[i].width = P[P1].sk.b[i].width;
			//adapt for second player
			if (P[P2].stance_feet == SRIGHT)
			{
				P[P2].sk.b[bn].angle			= 180 - P[P1].sk.b[bn].angle;

				P[P2].sk.b[btul].angle			= 180 - P[P1].sk.b[btur].angle;
				P[P2].sk.b[btul].length			= P[P1].sk.b[btur].length;
				P[P2].sk.b[btul].width			= P[P1].sk.b[btur].width;

				P[P2].sk.b[btur].angle			= 180 - P[P1].sk.b[btul].angle;
				P[P2].sk.b[btur].length			= P[P1].sk.b[btul].length;
				P[P2].sk.b[btur].width			= P[P1].sk.b[btul].width;

				P[P2].sk.b[btll].angle			= 180 - P[P1].sk.b[btlr].angle;
				P[P2].sk.b[btll].length			= P[P1].sk.b[btlr].length;
				P[P2].sk.b[btll].width			= P[P1].sk.b[btlr].width;

				P[P2].sk.b[btlr].angle			= 180 - P[P1].sk.b[btll].angle;
				P[P2].sk.b[btlr].length			= P[P1].sk.b[btll].length;
				P[P2].sk.b[btlr].width			= P[P1].sk.b[btll].width;

				P[P2].sk.b[bsl].angle			= 180 - P[P1].sk.b[bsr].angle;
				P[P2].sk.b[baul].angle			= 180 - P[P1].sk.b[baur].angle;
				P[P2].sk.b[ball].angle			= 180 - P[P1].sk.b[balr].angle;

				P[P2].sk.b[bsr].angle			= 180 - P[P1].sk.b[bsl].angle;
				P[P2].sk.b[baur].angle			= 180 - P[P1].sk.b[baul].angle;
				P[P2].sk.b[balr].angle			= 180 - P[P1].sk.b[ball].angle;

				P[P2].sk.b[bhl].angle			= 180 - P[P1].sk.b[bhr].angle;
				P[P2].sk.b[blul].angle			= 180 - P[P1].sk.b[blur].angle;
				P[P2].sk.b[blll].angle			= 180 - P[P1].sk.b[bllr].angle;
				P[P2].sk.b[bfl].angle			= 180 - P[P1].sk.b[bfr].angle;

				P[P2].sk.b[bhr].angle			= 180 - P[P1].sk.b[bhl].angle;
				P[P2].sk.b[blur].angle			= 180 - P[P1].sk.b[blul].angle;
				P[P2].sk.b[bllr].angle			= 180 - P[P1].sk.b[blll].angle;
				P[P2].sk.b[bfr].angle			= 180 - P[P1].sk.b[bfl].angle;
			}
			else
			{
			}

			//close file
			fclose(f_animation);
		}
	}*/

/*						dd.typefont(32 * 0, 96, "", is.ui_state[P1][0], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 96, "", is.ui_state[P1][1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 96, "", is.ui_state[P1][2], 0, 0, 1.0f, -1);
						dd.typefont(32 * 3, 96, "", is.ui_state[P1][3], 0, 0, 1.0f, -1);
						dd.typefont(32 * 4, 96, "", is.ui_state[P1][4], 0, 0, 1.0f, -1);
						dd.typefont(32 * 5, 96, "", is.ui_state[P1][5], 0, 0, 1.0f, -1);
						dd.typefont(32 * 0, 112, "", is.ui_state1D[P1][0], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 112, "", is.ui_state1D[P1][1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 112, "", is.ui_state1D[P1][2], 0, 0, 1.0f, -1);
						dd.typefont(32 * 3, 112, "", is.ui_state1D[P1][3], 0, 0, 1.0f, -1);
						dd.typefont(32 * 4, 112, "", is.ui_state1D[P1][4], 0, 0, 1.0f, -1);
						dd.typefont(32 * 5, 112, "", is.ui_state1D[P1][5], 0, 0, 1.0f, -1);
						dd.typefont(32 * 0, 128, "", is.ui_state[P2][0], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 128, "", is.ui_state[P2][1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 128, "", is.ui_state[P2][2], 0, 0, 1.0f, -1);
						dd.typefont(32 * 3, 128, "", is.ui_state[P2][3], 0, 0, 1.0f, -1);
						dd.typefont(32 * 4, 128, "", is.ui_state[P2][4], 0, 0, 1.0f, -1);
						dd.typefont(32 * 5, 128, "", is.ui_state[P2][5], 0, 0, 1.0f, -1);
						dd.typefont(32 * 0, 144, "", is.ui_state1D[P2][0], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 144, "", is.ui_state1D[P2][1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 144, "", is.ui_state1D[P2][2], 0, 0, 1.0f, -1);
						dd.typefont(32 * 3, 144, "", is.ui_state1D[P2][3], 0, 0, 1.0f, -1);
						dd.typefont(32 * 4, 144, "", is.ui_state1D[P2][4], 0, 0, 1.0f, -1);
						dd.typefont(32 * 5, 144, "", is.ui_state1D[P2][5], 0, 0, 1.0f, -1);

						dd.typefont(128 * 0, 176, "", is.t_move[P1][0], 5, 0, 1.0f, -1);
						dd.typefont(128 * 1, 176, "", is.t_move[P1][1], 5, 0, 1.0f, -1);
						dd.typefont(128 * 2, 176, "", (double)is.t_startmove[P1][0], 0, 0, 1.0f, -1);
						dd.typefont(128 * 3, 176, "", (double)is.t_startmove[P1][1], 0, 0, 1.0f, -1);
						dd.typefont(128 * 0, 192, "", is.t_move[P2][0], 5, 0, 1.0f, -1);
						dd.typefont(128 * 1, 192, "", is.t_move[P2][1], 5, 0, 1.0f, -1);

						if (is.t_lastspecial1D[P1][0] != 0 &&
							is.t_lastspecial1D[P1][1] != 0)
							if (is.t_lastspecial1D[P1][1] - is.t_lastspecial1D[P1][0] <
								time.freq)
							{
								//dd.typefont(128 * 0, 208, "change_p1", 0, 0, 0, 1.0f, -1);
								ds.stopbuffer();		sbf[S_MENTER] = ON;
								ds.playbuffer(sbf);		sbf[S_MENTER] = OFF;
								is.t_lastspecial1D[P1][0]	= 0;
								is.t_lastspecial1D[P1][1]	= 0;
							}
						if (is.t_lastspecial1D[P2][0] != 0 &&
							is.t_lastspecial1D[P2][1] != 0)
							if (is.t_lastspecial1D[P2][1] - is.t_lastspecial1D[P2][0] <
								time.freq)
							{
								//dd.typefont(128 * 1, 208, "change_p2", 0, 0, 0, 1.0f, -1);
//								ds.stopbuffer();		sbf[S_MENTER] = ON;
//								ds.playbuffer(sbf);		sbf[S_MENTER] = OFF;
								sbf[S_MENTER] = ON;
								ds.playbuffer(sbf);
								is.t_lastspecial1D[P2][0]	= 0;
								is.t_lastspecial1D[P2][1]	= 0;
							}

						dd.typefont(32 * 0, 208, "", is.mm_angle[P1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 208, "", is.mm_angle[P2], 0, 0, 1.0f, -1);

						dd.typefont(32 * 0, 224, "", is.dimouse[1].lX, 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 224, "", is.dimouse[1].lY, 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 224, "", is.dimouse[1].lZ, 0, 0, 1.0f, -1);
						dd.typefont(32 * 0, 240, "", is.dimouse[2].lX, 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 240, "", is.dimouse[2].lY, 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 240, "", is.dimouse[2].lZ, 0, 0, 1.0f, -1);

						dd.typefont(32 * 0, 320, "", is.mm_button[P1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 320, "", is.mm_button[P2], 0, 0, 1.0f, -1);
						dd.typefont(32 * 2, 320, "", is.mm_length_c[P1], 2, 0, 1.0f, -1);
						dd.typefont(32 * 4, 320, "", is.mm_length_m[P1], 2, 0, 1.0f, -1);
						dd.typefont(32 * 6, 320, "", is.mm_button_flag[P1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 0, 336, "", is.mm_state[P1], 0, 0, 1.0f, -1);
						dd.typefont(32 * 1, 336, "", is.mm_state[P2], 0, 0, 1.0f, -1);

						if (is.mm_state[P1] == 2)
						{
							ds.stopbuffer();
							sbf[S_MENTER] = ON;
							ds.playbuffer(sbf);
							sbf[S_MENTER] = OFF;
						}
						if (is.mm_state[P1] == 3)
						{
							ds.stopbuffer();
							sbf[S_MBEAT] = ON;
							ds.playbuffer(sbf);
							sbf[S_MBEAT] = OFF;
						}

						if (is.dikey1D[DIK_SPACE] & 0x80)
							is.mm_length_m[0] = is.mm_length_c[0] = 0;*/

//------------------------------------------------------------------------------------------------
//
//	mouse degree
//
//------------------------------------------------------------------------------------------------
/*
		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//if action button is down
			if (buttonflag[p] != -1)
			{
				//set starttime only if it wasn't already set before
				if (mdstarttime[p] == 0)
					mdstarttime[p] = t_current;

				//check if mouse was moved and set flag if so
				//if it wasn't moved the flag stays set to zero
				//(p + 1 because mouse of player one is dimouse[1])
				if (dimouse[p + 1].lX != 0 || dimouse[p + 1].lY != 0)
					motionflag[p] = 1;

				//assign relative mouse movement
				mcx[p] += dimouse[p + 1].lX;
				mcy[p] += dimouse[p + 1].lY;

				//get current length of movement
				length_c[p] = (float)sqrt(mcx[p] * mcx[p] + mcy[p] * mcy[p]);

				//if necessary assign new max length and max coordinates
				if (length_c[p] > length_m[p])
				{
					length_m[p]	= length_c[p];
					mmx[p]		= mcx[p];
					mmy[p]		= mcy[p];
				}

				//if action button is held down for more than a second
				//either complete move or cancel move if mouse wasn't moved
				if (t_current >= mdstarttime[p] + t_freq)
					if (motionflag[p] != 0)
					{
						//release action button for this frame
						//so move is finished in the next if statement
						ui_state[p][buttonflag[p]] = 0;
					}
					else
					{
						//set action button flag to no button down
						buttonflag[p] = -1;
					}
				}
			else
			{
//				angle[p]					= 0;
//				buttonflag[p]				= -1;
//				motionflag[p]				= 0;
//				mdstarttime[p]				= 0;
//				mcx[p] = mcy[p] 			= 0;
//				mmx[p] = mmy[p]				= 0;
//				length_c[p] = length_m[p]	= 0;
			}

/*			//!!
			if (ui_state[p][PUNCH] & 0x80)
				buttonflag[p] = PUNCH;
			if (ui_state[p][KICK] & 0x80)
				buttonflag[p] = KICK;
			if (ui_state[p][DEFEND] & 0x80)
				buttonflag[p] = DEFEND;

			//if no action button is down but buttonflag is set
			if (ui_state[p][PUNCH] == 0 &&
				ui_state[p][KICK] == 0 &&
				ui_state[p][DEFEND] == 0 &&
				buttonflag[p] != -1)*/
/*			if (ui_state[p][PUNCH] & 0x80)
			{
				buttonflag[p] = PUNCH;
			}
			else
			{
				if (buttonflag[p] != -1)
				{
				//calculate angle of current position
				//!! and also angle of maximum position
				//integer division

				//no division through 0
				if (length_c[p] != 0)
					angle[p] = (int)(acos(mcx[p] / length_c[p]) * 180 / PI);
				else
					angle[p] = 0;

				float angle_m;
				if (length_m[p] != 0)
					angle_m = (float)acos(mmx[p] / length_m[p]) * 180 / PI;
				else
					angle_m = 0;

				//if current y-position is negativ, angle is negativ
				//so take 360 - angle
				if (mcy[p] < 0)
				{
					angle[p]	= 360 - angle[p];
					angle_m		= 360 - angle_m;
				}

				//reset data
//				angle[p]					= 0;
				buttonflag[p]				= -1;
				motionflag[p]				= 0;
				mdstarttime[p]				= 0;
				mcx[p] = mcy[p] 			= 0;
				mmx[p] = mmy[p]				= 0;
				length_c[p] = length_m[p]	= 0;
				}
			}
		}
*/

/*		//////////////////////////////////MOUSE DEGREE //////////////
		//degree per second
		//- ein flag, ob die taste mittleweile �berhaupt losgelassen
		//wurde
		//- ein motionflag, dass die mouse �berhaupt bewegt wurde, sonst
		//k�nnte 0,0 missinterpretiert werden (k�nnte ja genau dorthin
		//zur�ckbewegt worden sein
		//mouse time in seconds
		static LONGLONG mstarttime = 0;
		static double speed = 900;
		static int mbf = 0;
		static int fm = 0;
		static LONG		mbx = 0, mby = 0;
		static LONG		mbxa = 0, mbya = 0;
		static LONG		posi_x = 0, pos_y = 0, neg_x = 0, neg_y = 0;
		static LONG		abs_x = 0, abs_y = 0;
		static LONG		act_length = 0, max_length = 0;
		static double	mwink = 0;
//		mwink = 0;

		if (mbf == 1)
		{
			if (mstarttime == 0)
				mstarttime = t_current;

			//relative mousebewegung
			mbx += mouse.x_end;
			mby += mouse.y_end;

			//but squared (multiplication is always positive)
			act_length = mbx * mbx + mby * mby;
			if (act_length > max_length)
				max_length = act_length;

			//wenn positiv max erh�hen, sonst min erh�hen
//			mbx >= 0 ? pos_x += mbx : neg_x += mbx;
//			mby >= 0 ? pos_y += mby : neg_y += mby;
			mouse.x_end >= 0 ? posi_x += mouse.x_end : neg_x += mouse.x_end;
			mouse.y_end >= 0 ? pos_y += mouse.y_end : neg_y += mouse.y_end;

			//vorausgesetzt, wurde �berhaupt bewegt
			if (mbx != 0 || mby != 0)
				//0.05 seconds
				if (t_current >= mstarttime + (t_freq / 50))
					spieler1.leg_up_right.animationsflag = 1;
					//hier k�me dann die erste winkelberechnung hin
					//wobei haupts�chlich die seite (vorder/hinterer
					//arm) entscheident ist.

			//falls mousetaste l�nger als eine sekunde gehalten wird
			if (t_current >= mstarttime + (t_freq))
				if (mbx != 0 || mby != 0)
				{
					//move abschliessen
					mouse.buttonflag = 0;
				}
				else
					//alles abbreechen
					mbf = 0;
		}
		else
		{
			//hier ran liegts
			mbx = 0; mby = 0;
			mstarttime = 0;
			spieler1.leg_up_right.animationsflag = 0;
//			mbxa = 0, mbya = 0;
			posi_x = 0, pos_y = 0, neg_x = 0, neg_y = 0;
//			abs_x = 0, abs_y = 0;
			act_length = 0, max_length = 0;
		}

		if (mouse.buttonflag == 1)
			mbf = 1;
		else
		{
			if (mbf == 1)
			{
				LONG diffx, diffy;	//differenz between max and end values
				neg_x = -neg_x; //absolute values
				neg_y = -neg_y;

				if (posi_x >= neg_x)
					abs_x = posi_x;
				else
					abs_x = neg_x;
				if (pos_y >= neg_y)
					abs_y = pos_y;
				else
					abs_y = neg_y;

				mbx >= 0 ? mbxa = mbx : mbxa = -mbx;
				mby >= 0 ? mbya = mby : mbya = -mby;

				diffx = abs_x - mbxa;
				diffy = abs_y - mbya;
//				if (diffx < 0)
//					diffx = -diffx;
//				if (diffy < 0)
//					diffy = - diffy;

			mbf = 0; mouse.buttonflag = 0;

			LONG wx = mbx, wy = mby;
			double b = wx;
			double c = sqrt(wx * wx + wy * wy);
			double arcos = acos(b / c);
			if (0 > wy)
				if (0 <= wx)
					mwink = 360 - (arcos * 180 / 3.141592654);
				else
					mwink = 360 - (arcos * 180 / 3.141592654);
			else
				if (0 < wx)
					mwink = arcos * 180 / 3.141592654;
				else
					mwink = arcos * 180 / 3.141592654;

			//???
			if (mwink < 0)
				mwink = 0;

				///////////////////////

				//das && ist problematisch, wegen 0� bewegungen
				//da muss ein flag her
				//den difference-faktor extern festlegen
//				if (diffx >= mbxa / 3 &&
//					diffy >= mbya / 3)
//				if ((mbx <= abs_x / 2 && mby <= abs_y / 2) ||
//				if ((mbx <= abs_x / 2 && abs_y <= abs_x / 3) ||
//					(mby <= abs_y / 2 && abs_x <= abs_y / 3))
//					mwink = 270;

				//kreis-ansatz
				//if length of actual mouseposition is only
				//half as long or less than max mouseposition -> action interupted
//				if (mbxa * mbxa + mbya * mbya <= (abs_x * abs_x + abs_y * abs_y) / 2)
//					mwink = 270;
				//maximal ein drittel oder kleiner
				if (mbxa * mbxa + mbya * mbya <= max_length / 3)
					mwink = 270;
			}
		}

		//////////////////////////////////////////////////////////////
*/

//------------------------------------------------------------------------------------------------
//
//	message
//
//------------------------------------------------------------------------------------------------
/*
struct message
{
	//timer daten
	//message id zum removen?
	//message jedes frame??

//x, y coordinates where to draw
//charstring, since one letter is 8 pixel in width
//you get a maximum of 100 letters in 800*600 (+ null)
//default == ""
//number to display, default == 0
//color of font (0 = black, 1 = white), default  == 1
//sizefactor, default == 1;

	point		position;				//x, y position
	char		string[101];			//string message
	int			type;					//bitmap(0) or scanline(1)
	int			duration;				//duration in milliseconds
	int			red, green, blue;		//color of message
	float		sizefactor;				//size of message
	int			priority;				//priority level (z-coordinate)

	//constructor with default values
	message(int x = 0,
			int y = 0,
			char str[101] = "",
			double n = 0,
			int t = 0,
			int d = -1,
			int r = 0,
			int g = 0,
			int b = 0,
			float sf = 1.0f,
			int pr = 1)
	{
		//if no string
		if (str == "")
			//convert number (double) into string and store it in string buffer
			_gcvt(n, 10, string);
		else
			//copy str into string until null terminated
			for (register int i = 0; i < 101; ++i)
			{
				string[i]  = str[i];
				if (string[i] == 0)
					i = 101;
			}

		position.x	= (float)x;		position.y = (float)y;
		type		= t;
		duration	= d;
		red			= r;	green = g;	blue = b;
		sizefactor	= sf;
		priority	= pr;
	}
};*/

//------------------------------------------------------------------------------------------------
//
//	particles
//
//------------------------------------------------------------------------------------------------
/*
						RGBcolor white; white.setcolor(255, 255, 255);
//						dd.colorfill(dd.rSCREEN, white);

						static int phb_ini = 0;
						static particle_heap	phb;

						if (phb_ini == 0)
						{
							phb_ini = 1;
							phb.create_heap(time.freq, time.current, 25, dd.rSCREEN);
/*							phb.initialization(time.current,		//current time
											   0,					//mode (0 = no reemerging)
											   2.0f,				//active time
											   400, 300,			//posx, posy
											   0, 0,				//posx/y tolerance
											   981.0f, 0.5f, 0.0f,	//grav, dampx, dampy
											   150, 350,			//force min/max
											   0, 359,				//angle min/max
											   1000, 2500);			//lifetime min/max
						}
*/
/*						if (is.dimouse01.rgbButtons[0] & 0x80)
						{
							phb.initialization(time.current,		//current time
											   0,					//mode (0 = no reemerging)
											   -1.0f,				//active time
											   400, 300,			//posx, posy
											   0, 0,				//posx/y tolerance
											   500.0f, 0.5f, 0.0f,	//grav, dampx, dampy
											   20, 150,				//force min/max
											   0, 45,				//angle min/max
											   500, 1000);			//lifetime min/max

							phb.state = 0;
						}
						if (is.dimouse01.rgbButtons[1] & 0x80)
						{
							phb.state = 0;
							phb.mode = 1;
						}
						else
							phb.mode = 0;

						//draw only if heap active
						if (phb.state != 1)
						{
							phb.update(time.current, time.sca, 400, 300);
							dd.drawparticles(phb.pp, phb.size, 100);
						}
*/