//------------------------------------------------------------------------------------------------
//
//	directdraw class definitions
//
//------------------------------------------------------------------------------------------------

#include "directdraw.h"				//class declaration header

//------------------------------------------------------------------------------------------------
//
//	directdraw contstructor
//
//------------------------------------------------------------------------------------------------

directdraw::directdraw() : COLORDEPTH(16)
{
	//initialize directdraw objects with NULL
	lpDD7			= NULL;
	lpDDSPrimary	= NULL;
	lpDDSBack		= NULL;
	lpDDSOff		= NULL;

//	pslocked16		= NULL;

	//timer/option pointer
	p_option		= NULL;
	p_time			= NULL;

	//initialize gamma object
	lpDDGamma		= NULL;

	//set screen coordinates
	fillRECT(rSCREEN, 0, 0, WIDTH, HEIGHT);
	//set 16:9 coordinates
	fillRECT(rSCREEN169, 0, 75, WIDTH, 525);
	//set upper arena coordinates
	fillRECT(rSCREEN_ARENA_TOP, 0, 75, WIDTH, S_FLOOR);

	//initialize look up tables with NULL
	p_rLUT			= NULL;
	p_rLUT			= NULL;
	p_rLUT			= NULL;

	p_blackwhiteLUT		= NULL;
	p_bluewhiteLUT		= NULL;
	p_greenredLUT		= NULL;
	p_greenblueLUT		= NULL;
	p_yellowpinkLUT		= NULL;

	p_cfontbm_LUT	= NULL;
	p_cfontsl_LUT	= NULL;

	//set all structures to zero
	ZeroMemory(&ddsd, sizeof(ddsd));
	ZeroMemory(&ddscaps, sizeof(ddscaps));
	ZeroMemory(&ddgamma, sizeof(ddgamma));
	ZeroMemory(&ddgamma_backup, sizeof(ddgamma_backup));
	ZeroMemory(&ddpixel, sizeof(ddpixel));
	ZeroMemory(&ddcolorkey, sizeof(ddcolorkey));
	ZeroMemory(&ddbltfx, sizeof(ddbltfx));

	//---- create head and fist array data -------------------------------------------------------

	fist_a = new signed char[144];
	head_f = new signed char[676];
	head_b = new signed char[676];

	//create temporary array to create/copy/edit data more easily
	signed char temp_f[144] =
	{0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0,
	 0, 0, 1, 1, 2, 2, 2, 2, 1, 1, 0, 0,
	 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0,
	 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1,
	 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0,
	 0, 0, 1, 1, 2, 2, 2, 2, 1, 1, 0, 0,
	 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0};

	//copy fist
	for (register int i = 0; i < 144; ++i)
		fist_a[i] = temp_f[i];

	//head front
	signed char temp_hf[676] =
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0,
	 0, 0, 0, 1, 2, 2, 2, 2, 4, 4, 3, 3, 3, 3, 3, 3, 4, 4, 2, 2, 2, 2, 1, 0, 0, 0,
	 0, 0, 1, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 1, 0, 0,
	 0, 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0, 0,
	 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 1, 0,
	 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1,
	 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1,
	 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1,
	 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1,
	 0, 1, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0,
	 0, 0, 1, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 1, 0, 0,
	 0, 0, 1, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 1, 0, 0,
	 0, 0, 0, 1, 2, 2, 2, 2, 4, 4, 3, 3, 3, 3, 3, 3, 4, 4, 2, 2, 2, 2, 1, 0, 0, 0,
	 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4, 4, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	//copy front
	for (i = 0; i < 676; ++i)
		head_f[i] = temp_hf[i];

	//head back
	signed char temp_hb[676] =
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0,
	 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0,
	 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0,
	 0, 0, 1, 2, 2, 2, 2, 2, 2, 4, 4, 3, 3, 3, 3, 4, 4, 2, 2, 2, 2, 2, 2, 1, 0, 0,
	 0, 1, 2, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1, 0,
	 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1,
	 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1,
	 0, 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 1, 0,
	 0, 1, 2, 2, 2, 2, 2, 2, 4, 3, 3, 3, 3, 3, 3, 3, 3, 4, 2, 2, 2, 2, 2, 2, 1, 0,
	 0, 0, 1, 2, 2, 2, 2, 2, 2, 4, 4, 3, 3, 3, 3, 4, 4, 2, 2, 2, 2, 2, 2, 1, 0, 0,
	 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0,
	 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0,
	 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
	 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	//copy back
	for (i = 0; i < 676; ++i)
		head_b[i] = temp_hb[i];

	//---- console -------------------------------------------------------------------------------

	//clear console message buffer
	con_clear();

	//---- hud data ------------------------------------------------------------------------------

	p_hud_text				= NULL;

	//---- developer data ------------------------------------------------------------------------

	VRAM_nlocks				= 0;
	VRAM_locked				= 0;

	dev_i					= 0;
	dev_f					= 0;
	dev_pi					= NULL;
	dev_pf					= NULL;

	gf_logger(false, "directdraw::directdraw done");
}

//------------------------------------------------------------------------------------------------
//
//	directdraw initialization
//
//------------------------------------------------------------------------------------------------

bool directdraw::dd_initialization(HWND hwnd)
{
	//---- create instance of latest directdraw-object -------------------------------------------

	//HAL
	if (!gProgramOptions.HEL)
	{
		hRet = DirectDrawCreateEx(NULL,					//GUID pointer to graphic card driver, NULL == default
								 (void**)&lpDD7,		//pointer which receives object if call is ok
								 IID_IDirectDraw7,		//latest id
								 NULL);					//for future compatibility
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization HAL DDCE failed");
			gp_ErrStr = Err_DDDirectDrawCreateEx;
			dd_cleanup();
			return false;
		}
	}
	else
	//HEL
	{
		hRet = DirectDrawCreateEx((GUID FAR*)DDCREATE_EMULATIONONLY,	//GUID pointer to graphic card driver, NULL == default
								 (void**)&lpDD7,						//pointer which receives object if call is ok
								 IID_IDirectDraw7,						//latest id
								 NULL);									//for future compatibility
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization DDCE HEL failed");
			gp_ErrStr = Err_DDDirectDrawCreateEx;
			dd_cleanup();
			return false;
		}
	}

	//initialize
	if (!dd_initialization_screenmode(hwnd))
	{
		gf_logger(true, "directdraw:dd_initialization dd_initialization_screenmode FAILED");
		return(false);
	}
	else
	{
		gf_logger(false, "directdraw::dd_initialization dd_initialization_screenmode DONE");
	}

/*	//---- determine top-level behavior of application -------------------------------------------

	hRet = lpDD7->SetCooperativeLevel(hwnd,									//window handle
									  DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT);	//flags
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization SCL failed", NULL, true);
		gp_ErrStr = Err_DDSetCooperativeLevel;
		dd_cleanup();
		return false;
	}

	//---- set display mode ----------------------------------------------------------------------

	hRet = lpDD7->SetDisplayMode(rSCREEN.right,			//screen width
								 rSCREEN.bottom,		//screen height
								 COLORDEPTH,			//color depth in bits per pixel
								 NULL,					//refresh rate, NULL == default by driver
								 NULL);					//additionally options, only mode13 used
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization SDM failed", NULL, true);
		gp_ErrStr = Err_DDSetDisplayMode;
		dd_cleanup();
		return false;
	}

	//---- create primaray and backbuffer surfaces -----------------------------------------------

	//fill ddsd structure with valid information
	ZeroMemory(&ddsd, sizeof(ddsd));					//fills a block of memory with zeros
	ddsd.dwSize = sizeof(ddsd);							//sets the dwSize member to the size of the structure, also for future expansion
	ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;	//valid data of structure

	//per default in video memory
	if (!gProgramOptions.vb_sys)
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;	//sets flags of ddscaps structure
	else
	//in system memory
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX | DDSCAPS_SYSTEMMEMORY;

	ddsd.dwBackBufferCount = 2;							//sets number of backbuffers

	//create primary surface
	hRet = lpDD7->CreateSurface(&ddsd,				//ddsdesc2 structure with description of surface
								&lpDDSPrimary,		//retrieves adress of primary surface
								NULL);				//for future compatibility
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization CS PRIMARY failed", NULL, true);
		gp_ErrStr = Err_DDCreateSurfaceFB;
		dd_cleanup();
		return false;
	}

	//fill ddscaps structure with valid information
	ZeroMemory(&ddscaps, sizeof(ddscaps));					//free ddscaps structure
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;					//valid flags within structure

	//get pointer to backbuffer
	hRet = lpDDSPrimary->GetAttachedSurface(&ddscaps,		//ddsCaps2 structure
											&lpDDSBack);	//retrieves adress of backbuffer
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization GAS BB failed", NULL, true);
		gp_ErrStr = Err_DDGetAttachedSurface;
		dd_cleanup();
		return false;
	}

	//---- get pixel format of surface -----------------------------------------------------------

	ZeroMemory(&ddpixel, sizeof(ddpixel));		//clear ddpixel structure
	ddpixel.dwSize = sizeof(ddpixel);			//set ddpixel structure size

	//get pixel format
//	hRet = lpDDSOff->GetPixelFormat(&ddpixel);
	hRet = lpDDSPrimary->GetPixelFormat(&ddpixel);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization GPF PRIMARY failed", NULL, true);
		gp_ErrStr = Err_DDGetPixelFormat;
		dd_cleanup();
		return false;
	}

	//check pixel format (desktop only with 16bit or 32bit)
	if (ddpixel.dwRGBBitCount != BPP16 &&
		ddpixel.dwRGBBitCount != BPP32)
	{
		gf_logger(true, "directdraw::dd_initialization wrong pixel format (%i bit)", (int)ddpixel.dwRGBBitCount);
		dd_cleanup();
		return(false);
	}
	else
		gf_logger(false, "directdraw::dd_initialization pixel format: %i bit", (int)ddpixel.dwRGBBitCount, 0);

	//---- get gamma-control interface -----------------------------------------------------------

	//get interface to gamme control (primary surface)
	hRet = lpDDSPrimary->QueryInterface(IID_IDirectDrawGammaControl, (void**) &lpDDGamma);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization QI DDGC failed", NULL, true);
		gp_ErrStr = Err_DDQueryInterface;
		dd_cleanup();
		return false;
	}

	//back up current gamma ramp
	hRet = lpDDGamma->GetGammaRamp(NULL, &ddgamma_backup);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization GGR backup failed", NULL, true);
		gp_ErrStr = Err_DDGetGammaRamp;
		dd_cleanup();
		return false;
	}

	//also get the current values into the structure to change
	hRet = lpDDGamma->GetGammaRamp(NULL, &ddgamma);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization GGR failed", NULL, true);
		gp_ErrStr = Err_DDGetGammaRamp;
		dd_cleanup();
		return false;
	}

	//---- create offscreen surface --------------------------------------------------------------

	//fill ddscaps structure with valid information
	ZeroMemory(&ddscaps, sizeof(ddscaps));
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;	//valid flags of structure

	//default create in videomemory
	if (!gProgramOptions.off_sys)
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	else
	//create in system memory
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;

	ddsd.dwWidth = rSCREEN.right;							//set surface width/height
	ddsd.dwHeight = rSCREEN.bottom;

	//creates surface, in this case an offscreen surface for a bitmap
	hRet = lpDD7->CreateSurface(&ddsd,						//ddsdesc2 structure with description of surface
								&lpDDSOff,					//retrieves adress of primary surface
								NULL);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization CS OFFSCREEN failed", NULL, true);
		gp_ErrStr = Err_DDCreateSurfaceOSB;
		dd_cleanup();
		return false;
	}

	//---- set color key for offscreen surface ---------------------------------------------------
	//the color which not to draw in a blit (if specified)

	//only one color, bright pink rgb(255, 0, 255)
	//and only this specific color (zero tolerance)
	ddcolorkey.dwColorSpaceLowValue = ddpixel.dwRBitMask + ddpixel.dwBBitMask;
	ddcolorkey.dwColorSpaceHighValue = ddcolorkey.dwColorSpaceLowValue;

	//set color key
	hRet = lpDDSOff->SetColorKey(DDCKEY_SRCBLT, &ddcolorkey);
	if (hRet != DD_OK)
	{
		gf_logger("directdraw::dd_initialization SCK failed", NULL, true);
		gp_ErrStr = Err_DDSetColorKey;
		dd_cleanup();
		return false;
	}

	//---- load bitmap into offscreen surface ----------------------------------------------------

	if (!load_bitmap())
	{
		gf_logger("directdraw::dd_initialization load_bitmap failed", NULL, true);
		dd_cleanup();
		return false;
	}

	//---- create look up tables -----------------------------------------------------------------

	//rgb color look up table
	//4 byte * 256 = 1024 byte LUT
	p_rLUT = Create16bppLUT(ddpixel.dwRBitMask);
	//4 byte * 256 = 1024 byte LUT
	p_bLUT = Create16bppLUT(ddpixel.dwBBitMask);
	//4 byte * 256 = 1024 byte LUT = 3072 byte
	p_gLUT = Create16bppLUT(ddpixel.dwGBitMask);

	//black white color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_blackwhiteLUT = cblackwhite_LUT();
	if (p_blackwhiteLUT == NULL)
	{
		gf_logger("directdraw::dd_initialization cblackwhite_LUT failed", NULL, true);
		gp_ErrStr = "Error Creating blackwhiteLUT";
		dd_cleanup();
		return false;
	}
	//blue white color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_bluewhiteLUT = cbluewhite_LUT();
	if (p_bluewhiteLUT == NULL)
	{
		gf_logger("directdraw::dd_initialization cbluewhite_LUT failed", NULL, true);
		gp_ErrStr = "Error Creating bluewhiteLUT";
		dd_cleanup();
		return false;
	}
	//green red color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_greenredLUT = cgreenred_LUT();
	if (p_greenredLUT == NULL)
	{
		gf_logger("directdraw::dd_initialization cgreenred_LUT failed", NULL, true);
		gp_ErrStr = "Error Creating greenredLUT";
		dd_cleanup();
		return false;
	}
	//green blue color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_greenblueLUT = cgreenblue_LUT();
	if (p_greenblueLUT == NULL)
	{
		gf_logger("directdraw::dd_initialization cgreenblue_LUT failed", NULL, true);
		gp_ErrStr = "Error Creating greenblueLUT";
		dd_cleanup();
		return false;
	}
	//yellow pink color change LUT
	//2 byte * 3 * 101 = 606 byte LUT = 3030 byte
	p_yellowpinkLUT = cyellowpink_LUT();
	if (p_yellowpinkLUT == NULL)
	{
		gf_logger("directdraw::dd_initialization cyellowpink_LUT failed", NULL, true);
		gp_ErrStr = "Error Creating yellowpinkLUT";
		dd_cleanup();
		return false;
	}
*/
	//bitmap font look up table
	//4 * 4 byte * 256 = 4096 byte LUT
	p_cfontbm_LUT = cfontbm_LUT();
	if (p_cfontbm_LUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization cfontbm_LUT failed");
		gp_ErrStr = "Error Creating BM LUT";
		dd_cleanup();
		return false;
	}

	//bitmap font surface offset table
	bmfs_offset[0].x	= 0;		bmfs_offset[0].y	= 0;
	bmfs_offset[1].x	= 256;		bmfs_offset[1].y	= 0;
	bmfs_offset[2].x	= 512;		bmfs_offset[2].y	= 0;
	bmfs_offset[3].x	= 0;		bmfs_offset[3].y	= 128;
	bmfs_offset[4].x	= 256;		bmfs_offset[4].y	= 128;
	bmfs_offset[5].x	= 512;		bmfs_offset[5].y	= 128;
	bmfs_offset[6].x	= 0;		bmfs_offset[6].y	= 255;
	bmfs_offset[7].x	= 256;		bmfs_offset[7].y	= 255;
	bmfs_offset[8].x	= 512;		bmfs_offset[8].y	= 255;

	//scanline font look up table
	//4 * 4 byte * 6 * 256 = 24576 byte = 28672 byte = 33562 byte
	p_cfontsl_LUT = cfontsl_LUT();
	if (p_cfontsl_LUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization cfontsl_LUT failed");
		gp_ErrStr = "Error Creating SL LUT";
		dd_cleanup();
		return false;
	}

	//--------------------------------------------------------------------------------------------

	gf_logger(false, "directdraw::dd_initialization done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw initialization screen mode
//
//------------------------------------------------------------------------------------------------

bool directdraw::dd_initialization_screenmode(HWND hwnd)
{
	//---- reset window --------------------------------------------------------------------------

	if (!p_option->data.screenmode)
	{
//		SetWindowPos(hwnd, HWND_TOPMOST,								//window pos
//					 0, 0, WIDTH, HEIGHT,
//					 SWP_SHOWWINDOW);
 		SetWindowPos(hwnd, HWND_TOP,								//window pos
					 0, 0, WIDTH, HEIGHT,
					 SWP_SHOWWINDOW);
	}

	//---- set windowed mode ---------------------------------------------------------------------

	if (!p_option->data.screenmode)
	{
		//---- determine top-level behavior of application ---------------------------------------

		hRet = lpDD7->SetCooperativeLevel(hwnd,							//window handle
										  DDSCL_NORMAL);				//flags
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode SCL FAILED");
			dd_cleanup();
			return false;
		}

		//---- create primary surface ------------------------------------------------------------

		//fill ddsd structure with valid information
		ZeroMemory(&ddsd, sizeof(ddsd));					//fills a block of memory with zeros
		ddsd.dwSize = sizeof(ddsd);							//sets the dwSize member to the size of the structure, also for future expansion
		ddsd.dwFlags = DDSD_CAPS;							//valid data of structure

		//per default in video memory
		if (!gProgramOptions.vb_sys)
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;	//sets flags of ddscaps structure
		else
		//in system memory
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_SYSTEMMEMORY;

		//create primary surface
		hRet = lpDD7->CreateSurface(&ddsd,				//ddsdesc2 structure with description of surface
									&lpDDSPrimary,		//retrieves adress of primary surface
									NULL);				//for future compatibility
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode CS PRIMARY FAILED");
			dd_cleanup();
			return false;
		}

		//---- create clipper and attach it to window and primary surface ------------------------

		//pointer to clipper
		LPDIRECTDRAWCLIPPER		lpDDClipper	= NULL;

		hRet = lpDD7->CreateClipper(0,							//not used flags
									&lpDDClipper,				//pointer to clipper
									NULL);						//not used, NULL
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode CreateClipper FAILED");
			dd_cleanup();
			return false;
		}

		//associate clipper with window
		lpDDClipper->SetHWnd(0, hwnd);
		//attach clipper to primary surface
		//(get released when surface is released)
		lpDDSPrimary->SetClipper(lpDDClipper);
		lpDDClipper->Release();
		lpDDClipper	= NULL;

		//---- create backbuffer -----------------------------------------------------------------

		//fill ddscaps structure with valid information
		ZeroMemory(&ddscaps, sizeof(ddscaps));
		ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;	//valid flags of structure

		//default create in videomemory
		if (!gProgramOptions.off_sys)
			ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
		else
		//create in system memory
			ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;

		ddsd.dwWidth = rSCREEN.right;							//set surface width/height
		ddsd.dwHeight = rSCREEN.bottom;

		//create backbuffer surface
		hRet = lpDD7->CreateSurface(&ddsd,				//ddsdesc2 structure with description of surface
									&lpDDSBack,			//retrieves adress of surface
									NULL);				//for future compatibility
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode CS BACK FAILED");
			dd_cleanup();
			return(false);
		}
	}
	else
	//---- set fullscreen mode -------------------------------------------------------------------
	{
		//---- determine top-level behavior of application ---------------------------------------

		hRet = lpDD7->SetCooperativeLevel(hwnd,									//window handle
										  DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT);	//flags
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode SCL FAILED");
			dd_cleanup();
			return false;
		}

		//---- set display mode ------------------------------------------------------------------

		hRet = lpDD7->SetDisplayMode(rSCREEN.right,			//screen width
									 rSCREEN.bottom,		//screen height
									 COLORDEPTH,			//color depth in bits per pixel
									 NULL,					//refresh rate, NULL == default by driver
									 NULL);					//additionally options, only mode13 used
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode SDM FAILED");
			dd_cleanup();
			return false;
		}

		//---- create primaray and backbuffer surfaces -------------------------------------------

		//fill ddsd structure with valid information
		ZeroMemory(&ddsd, sizeof(ddsd));					//fills a block of memory with zeros
		ddsd.dwSize = sizeof(ddsd);							//sets the dwSize member to the size of the structure, also for future expansion
		ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;	//valid data of structure

		//per default in video memory
		if (!gProgramOptions.vb_sys)
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;	//sets flags of ddscaps structure
		else
		//in system memory
			ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX | DDSCAPS_SYSTEMMEMORY;

		ddsd.dwBackBufferCount = 2;							//sets number of backbuffers

		//create primary surface
		hRet = lpDD7->CreateSurface(&ddsd,				//ddsdesc2 structure with description of surface
									&lpDDSPrimary,		//retrieves adress of primary surface
									NULL);				//for future compatibility
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode CS PRIMARY FAILED");
			dd_cleanup();
			return false;
		}

		//fill ddscaps structure with valid information
		ZeroMemory(&ddscaps, sizeof(ddscaps));					//free ddscaps structure
		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;					//valid flags within structure

		//get pointer to backbuffer
		hRet = lpDDSPrimary->GetAttachedSurface(&ddscaps,		//ddsCaps2 structure
												&lpDDSBack);	//retrieves adress of backbuffer
		if (hRet != DD_OK)
		{
			gf_logger(true, "directdraw::dd_initialization_screenmode GAS BB FAILED");
			dd_cleanup();
			return false;
		}
	}

	//---- for both screen modi ------------------------------------------------------------------

	//---- get pixel format of surface -----------------------------------------------------------

	ZeroMemory(&ddpixel, sizeof(ddpixel));		//clear ddpixel structure
	ddpixel.dwSize = sizeof(ddpixel);			//set ddpixel structure size

	//get pixel format
	hRet = lpDDSPrimary->GetPixelFormat(&ddpixel);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode GPF PRIMARY FAILED");
		dd_cleanup();
		return false;
	}

	//check pixel format (desktop only with 16bit or 32bit)
	if (ddpixel.dwRGBBitCount != BPP16 &&
		ddpixel.dwRGBBitCount != BPP32)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode wrong pixel format (%i bit)", (int)ddpixel.dwRGBBitCount);
		dd_cleanup();
		return(false);
	}
	else
		gf_logger(false, "directdraw::dd_initialization_screenmode pixel format: %i bit", (int)ddpixel.dwRGBBitCount, 0);

	//---- get gamma-control interface -----------------------------------------------------------

	//get interface to gamme control (primary surface)
	hRet = lpDDSPrimary->QueryInterface(IID_IDirectDrawGammaControl, (void**) &lpDDGamma);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode QI DDGC FAILED");
		dd_cleanup();
		return false;
	}

	//back up current gamma ramp
	hRet = lpDDGamma->GetGammaRamp(NULL, &ddgamma_backup);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode GGR backup FAILED");
		dd_cleanup();
		return false;
	}

	//also get the current values into the structure to change
	hRet = lpDDGamma->GetGammaRamp(NULL, &ddgamma);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode GGR FAILED");
		dd_cleanup();
		return false;
	}

	//---- create offscreen surface --------------------------------------------------------------
	//same color depth as primary surface

	//fill ddscaps structure with valid information
	ZeroMemory(&ddscaps, sizeof(ddscaps));
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;	//valid flags of structure

	//default create in videomemory
	if (!gProgramOptions.off_sys)
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	else
	//create in system memory
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;

	ddsd.dwWidth	= rSCREEN.right;							//set surface width/height
	ddsd.dwHeight	= rSCREEN.bottom;

	//creates surface, in this case an offscreen surface for a bitmap
	hRet = lpDD7->CreateSurface(&ddsd,						//ddsdesc2 structure with description of surface
								&lpDDSOff,					//retrieves adress of primary surface
								NULL);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode CS OFFSCREEN FAILED");
		dd_cleanup();
		return false;
	}

	//---- set color key for offscreen surface ---------------------------------------------------
	//the color which not to draw in a blit (if specified)

	//only one color, bright pink rgb(255, 0, 255)
	//and only this specific color (zero tolerance)
	ddcolorkey.dwColorSpaceLowValue = ddpixel.dwRBitMask + ddpixel.dwBBitMask;
	ddcolorkey.dwColorSpaceHighValue = ddcolorkey.dwColorSpaceLowValue;

	//set color key
	hRet = lpDDSOff->SetColorKey(DDCKEY_SRCBLT, &ddcolorkey);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode SCK FAILED");
		dd_cleanup();
		return false;
	}

	//---- load bitmap into offscreen surface ----------------------------------------------------

	if (!load_bitmap())
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode load_bitmap FAILED");
//		dd_cleanup();
		return false;
	}

	//---- create look up tables -----------------------------------------------------------------

	//rgb color look up table
	//4 byte * 256 = 1024 byte LUT
	p_rLUT = Create16bppLUT(ddpixel.dwRBitMask);
	//4 byte * 256 = 1024 byte LUT
	p_bLUT = Create16bppLUT(ddpixel.dwBBitMask);
	//4 byte * 256 = 1024 byte LUT = 3072 byte
	p_gLUT = Create16bppLUT(ddpixel.dwGBitMask);

	//black white color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_blackwhiteLUT = cblackwhite_LUT();
	if (p_blackwhiteLUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode cblackwhite_LUT FAILED");
		dd_cleanup();
		return false;
	}
	//blue white color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_bluewhiteLUT = cbluewhite_LUT();
	if (p_bluewhiteLUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode cbluewhite_LUT FAILED");
		dd_cleanup();
		return false;
	}
	//green red color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_greenredLUT = cgreenred_LUT();
	if (p_greenredLUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode cgreenred_LUT FAILED");
		dd_cleanup();
		return false;
	}
	//green blue color change LUT
	//2 byte * 3 * 101 = 606 byte LUT
	p_greenblueLUT = cgreenblue_LUT();
	if (p_greenblueLUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode cgreenblue_LUT FAILED");
		dd_cleanup();
		return false;
	}
	//yellow pink color change LUT
	//2 byte * 3 * 101 = 606 byte LUT = 3030 byte
	p_yellowpinkLUT = cyellowpink_LUT();
	if (p_yellowpinkLUT == NULL)
	{
		gf_logger(true, "directdraw::dd_initialization_screenmode cyellowpink_LUT FAILED");
		dd_cleanup();
		return false;
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw restore function
//
//	restores previously created surfaces and reloades bitmaps
//
//------------------------------------------------------------------------------------------------

bool directdraw::dd_restore()
{
	//restore primary surface with two backbuffers and offscreen surface
/*	hRet = lpDD7->RestoreAllSurfaces();
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_restore RAS FAILED");
		gp_ErrStr = Err_DDRestore;
		dd_cleanup();
		return false;
	}*/

	//restore all surfaces explicitly
	hRet = lpDDSPrimary->Restore();
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_restore RSPrim FAILED");
		dd_cleanup();
		return false;
	}
	hRet = lpDDSBack->Restore();
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_restore RSBack FAILED");
		dd_cleanup();
		return false;
	}
	hRet = lpDDSOff->Restore();
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::dd_restore RSOff FAILED");
		dd_cleanup();
		return false;
	}

	//reload offscreen surface bitmap
	if (!load_bitmap())
	{
		gf_logger(true, "directdraw::dd_restore load_bitmap FAILED");
		dd_cleanup();
		return false;
	}

	gf_logger(false, "directdraw::dd_restore done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw clean up function
//
//	frees directdraw interfaces
//
//------------------------------------------------------------------------------------------------

void directdraw::dd_cleanup()
{
	//delete allocated lut-arrays
	delete []	p_rLUT;				p_rLUT			= NULL;
	delete []	p_gLUT;				p_gLUT			= NULL;
	delete []	p_bLUT;				p_bLUT			= NULL;

	delete []	p_blackwhiteLUT;	p_blackwhiteLUT	= NULL;
	delete []	p_bluewhiteLUT;		p_bluewhiteLUT	= NULL;
	delete []	p_greenredLUT;		p_greenredLUT	= NULL;
	delete []	p_greenblueLUT;		p_greenblueLUT	= NULL;
	delete []	p_yellowpinkLUT;	p_yellowpinkLUT	= NULL;

	delete []	p_cfontbm_LUT;		p_cfontbm_LUT	= NULL;
	delete []	p_cfontsl_LUT;		p_cfontsl_LUT	= NULL;

	//delete head, fist arrays
	delete []	fist_a;				fist_a			= NULL;
	delete []	head_f;				head_f			= NULL;
	delete []	head_b;				head_b			= NULL;

	//if DD7 inferface exists
	if (lpDD7 != NULL)
	{
		//restore display mode if fullscreen
		if (p_option->data.screenmode)
			lpDD7->RestoreDisplayMode();

		if (p_option->data.screenmode)
		{
			//release primary and backbuffer
			if (lpDDSPrimary != NULL)
			{
				lpDDSPrimary->Release();
				lpDDSPrimary = NULL;
			}
		}
		else
		{
			//explicitly release back and primary buffer
			if (lpDDSBack != NULL)
			{
				lpDDSBack->Release();
				lpDDSBack	= NULL;
			}

			if (lpDDSPrimary != NULL)
			{
				lpDDSPrimary->Release();
				lpDDSPrimary	= NULL;
			}
		}

		//release offscreen surface
		if (lpDDSOff != NULL)
		{
			lpDDSOff->Release();
			lpDDSOff = NULL;
		}

		//release gamma-control
		if(lpDDGamma != NULL)
		{
			lpDDGamma->Release();
			lpDDGamma = NULL;
		}

		//release dd7-object
		lpDD7->Release();
		lpDD7 = NULL;
	}

	//release surface pointer
//	pslocked16 = NULL;

	gf_logger(false, "directdraw::dd_cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	directdraw clean up function
//
//	frees directdraw interfaces for new screen mode
//
//------------------------------------------------------------------------------------------------

bool directdraw::dd_cleanup_screenmode(HWND hwnd)
{
	//delete allocated lut-arrays
	delete []	p_rLUT;				p_rLUT			= NULL;
	delete []	p_gLUT;				p_gLUT			= NULL;
	delete []	p_bLUT;				p_bLUT			= NULL;

	delete []	p_blackwhiteLUT;	p_blackwhiteLUT	= NULL;
	delete []	p_bluewhiteLUT;		p_bluewhiteLUT	= NULL;
	delete []	p_greenredLUT;		p_greenredLUT	= NULL;
	delete []	p_greenblueLUT;		p_greenblueLUT	= NULL;
	delete []	p_yellowpinkLUT;	p_yellowpinkLUT	= NULL;

	//if DD7 inferface exists
	if (lpDD7 != NULL)
	{
		//exit from exclusive mode
		lpDD7->SetCooperativeLevel(hwnd, DDSCL_NORMAL);

		//release primary and backbuffer
		if (p_option->data.screenmode)
		{
			if (lpDDSPrimary != NULL)
			{
				hRet = lpDDSPrimary->Release();
				if (hRet != DD_OK)
				{
					gf_logger(true, "directdraw::dd_cleanup_screenmode PrimRelease FAILED");
					dd_cleanup();
					return(false);
				}
				lpDDSPrimary = NULL;
			}
		}
		else
		{
			//explicitly release back and primary buffer
			if (lpDDSBack != NULL)
			{
				lpDDSBack->Release();
				lpDDSBack	= NULL;
			}

			if (lpDDSPrimary != NULL)
			{
				lpDDSPrimary->Release();
				lpDDSPrimary	= NULL;
			}
		}

		//release gamma-control
		if(lpDDGamma != NULL)
		{
			lpDDGamma->Release();
			lpDDGamma = NULL;
		}

		//release offscreen surface
		if (lpDDSOff != NULL)
		{
			lpDDSOff->Release();
			lpDDSOff = NULL;
		}

		return(true);
	}

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw set_data_pointer
//
//	fills pointer to timer/option data
//
//------------------------------------------------------------------------------------------------

void directdraw::set_data_pointer(options *_options, timer *_timer, hud_text *_hud)
{
	p_option			= _options;
	p_time				= _timer;
	p_hud_text			= _hud;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw load_bitmap
//
//	loads bitmap from file into offscreen surface
//
//------------------------------------------------------------------------------------------------

bool directdraw::load_bitmap()
{
	HDC				hdds		= NULL;			//handle to device context
	HDC				bit_dc		= NULL;			//handle for source bitmap
	HBITMAP			hbitmap		= NULL;			//handle to bitmap
	BITMAP			bitmap;						//bitmap structure

	//get handle to bitmap
	hbitmap = (HBITMAP)LoadImage(GetModuleHandle(NULL),				//handle of the instance containing the image
								 U_BITMAP,							//filename
								 IMAGE_BITMAP,						//specifies type of image to be loaded
								 0,									//width
								 0,									//height
								 LR_DEFAULTSIZE | LR_LOADFROMFILE);	//flags
	if (!hbitmap)
	{
		gf_logger(true, "directdraw::load_bitmap LI failed %s", U_BITMAP);
		//gp_ErrStr = Err_DDLoadBMP;
		gp_ErrStr = U_BITMAP;
		DeleteObject(hbitmap);
		return false;
	}

	//fill BITMAP structure
	if (!GetObject(hbitmap,							//handle to object
				   sizeof(BITMAP),					//size of buffer for object information
				   &bitmap))						//pointer to buffer for object information
	{
		gf_logger(true, "directdraw::load_bitmap GO failed");
		gp_ErrStr = Err_DDLoadBMP;
		DeleteObject(hbitmap);
		return false;
	}

	//create GDI-compatible handle to a device context for offscreen surface
	lpDDSOff->GetDC(&hdds);

	//create dc for source bitmap
	bit_dc = CreateCompatibleDC(hdds);

	//select object into the specified device context
	SelectObject(bit_dc, hbitmap);
	
	//copy bitmap into offscreen surface
	BitBlt(hdds,							//destination device context
		   rSCREEN.left,					//xmin ddc
		   rSCREEN.top,						//ymin ddc
		   rSCREEN.right,					//width ddc
		   rSCREEN.bottom,					//heigth ddc
		   bit_dc,							//source device context
		   0,								//xmin sdc
		   0,								//ymin sdc
		   SRCCOPY);						//copyflag

	//---- cleanup -------------------------------------------------------------------------------

	//release ofs-dc, bit_dc and hbitmap
	lpDDSOff->ReleaseDC(hdds);
	DeleteDC(bit_dc);
	DeleteObject(hbitmap);

	gf_logger(false, "directdraw::load_bitmap done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw save_bitmap
//
//	saves frontbuffer in bitmap file
//	argument is char array which gets screenshot file name applied
//
//------------------------------------------------------------------------------------------------

bool directdraw::save_bitmap(char screenshot_id[256])
{
	//create screen folder
	_mkdir("screens");

	//---- get bitmap file index -----------------------------------------------------------------

	int		bmi				= 0;				//bitmap file index
	char	filename[27]	= "";				//filename
	char	index[4]		= "";				//file index as string

	//try to open bitmap file
	//as long as file exists, increase index
	//if 1000 files exist the last one (999) will be overwritten
	for (bmi = 0; bmi < 1000; ++bmi)
	{
		//create file names to open
		//add zeros in front
		if (bmi < 10)
			strcpy(filename, "screens/beatmaster_00");
		if (bmi > 9 && bmi < 100)
			strcpy(filename, "screens/beatmaster_0");
		if (bmi > 99)
			strcpy(filename, "screens/beatmaster_");

		//convert index integer to string
		_itoa(bmi, index, 10);
		//append index to filename
		strcat(filename, index);
		//append file ending to filename
		strcat(filename, ".bmp");

		//exit loop if no such file found
		//(read, binary)
		FILE *f = fopen(filename, "rb");
		//if (fopen(filename, "rb") == NULL)
		if (f == NULL)
			break;
		else
			//close file
			//(unassigned pointer to file of previous versions causes remaining unclosed files)
			fclose(f);
	}

	//apply screenshot file name
	if (screenshot_id)
		strcpy(screenshot_id, filename);

	//--------------------------------------------------------------------------------------------

	HRESULT			hRet			= 0;					//return values
	HDC				hdds			= NULL;					//handle to device context
	HDC				bit_dc			= NULL;					//handle to dd surface compatible dc
	HBITMAP			hGDIbitmap		= NULL;					//handle to GDI compatible bitmap
	HBITMAP			hGDIbitmap_old	= NULL;					//unselected GID bitmap
	LPBITMAPINFO	lpbi			= NULL;					//bitmap info structure
	HANDLE			hbmf			= INVALID_HANDLE_VALUE;	//handle to file
	DWORD			Written			= 0;					//written bytes
	int				PalEntries		= 0;					//palette entries

	//get GDI-compatible device context handle for primary surface
	hRet = lpDDSPrimary->GetDC(&hdds);
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::save_bitmap GDC PRIMARY failed");
		return false;
	}

	//create GDI compatible bitmap with right size
	hGDIbitmap = CreateCompatibleBitmap(hdds, rSCREEN.right, rSCREEN.bottom);
	if (hGDIbitmap == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap CCB failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		return false;
	}

	//create device context which is compatible to dd surface
	bit_dc = CreateCompatibleDC(hdds);
	if (bit_dc == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap GCDC failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		return false;
	}

	//select bitmap into the specified device context
	//the return value is the handle of the object being replaced
	hGDIbitmap_old = (HBITMAP)SelectObject(bit_dc, hGDIbitmap);

	//copy primary surface bitmap into GDI bitmap
	hRet = BitBlt(bit_dc,							//destination device context
				  rSCREEN.left,						//xmin ddc
				  rSCREEN.top,						//ymin ddc
				  rSCREEN.right,					//width ddc
				  rSCREEN.bottom,					//heigth ddc
				  hdds,								//source device context
				  0,								//xmin sdc
				  0,								//ymin sdc
				  SRCCOPY);							//copyflag
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap BitBlt failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		return false;
	}

	//--- converting from DDB to DIB -------------------------------------------------------------

	//create bitmap info header
	lpbi = (LPBITMAPINFO)(new char[sizeof(BITMAPINFOHEADER) + 256 * sizeof(RGBQUAD)]);
	//set to zero
	ZeroMemory(&lpbi->bmiHeader, sizeof(BITMAPINFOHEADER));

	//reserve palette memory
	lpbi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);

	//deselect bitmap
	if (SelectObject(bit_dc, hGDIbitmap_old) == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap SO failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		return false;
	}

	//query bitmap info
	hRet = GetDIBits(bit_dc, hGDIbitmap, 0, rSCREEN.bottom, NULL, lpbi, DIB_RGB_COLORS);
	if (hRet == NULL || hRet == GDI_ERROR)
	{
		gf_logger(true, "directdraw::save_bitmap GDIBits failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		return false;
	}

	//allocate memory for the bitmap bits
	//required size is returned in the biSizeImage member of the info header
	LPVOID lpvBits = new char[lpbi->bmiHeader.biSizeImage];

	//convert DDB into DIB
	hRet = GetDIBits(bit_dc, hGDIbitmap, 0, rSCREEN.bottom, lpvBits, lpbi, DIB_RGB_COLORS);
	if (hRet == NULL || hRet == GDI_ERROR)
	{
		gf_logger(true, "directdraw::save_bitmap GDIBits failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		return false;
	}

	//---- saving bitmap -------------------------------------------------------------------------

	//create bitmap file with above determined file name and get handle to it
	hbmf = CreateFile(filename, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hbmf == INVALID_HANDLE_VALUE)
	{
		gf_logger(true, "directdraw::save_bitmap CreateFile failed %s", filename);
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		return false;
	}

	//file header
	BITMAPFILEHEADER	bmfh;
	bmfh.bfType			= 19778;					//always the same, 'BM'
	//bmfh.bfSize		= ???						//we'll write that later
	bmfh.bfReserved1	= bmfh.bfReserved2 = 0;		// must be zero
	//bmfh.bfOffBits	= ???						// we'll write that later

	//write file header into file
	hRet = WriteFile(hbmf, &bmfh, sizeof(bmfh), &Written, NULL);
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap WF failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		if (hbmf != INVALID_HANDLE_VALUE)
			CloseHandle(hbmf);
		return false;
	}

	//write bitmap file header into file
	hRet = WriteFile(hbmf, &lpbi->bmiHeader, sizeof(BITMAPINFOHEADER), &Written, NULL);
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap WF HEADER failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		if (hbmf != INVALID_HANDLE_VALUE)
			CloseHandle(hbmf);
		return false;
	}

	//add palette if needed
	if (lpbi->bmiHeader.biCompression == BI_BITFIELDS)
		PalEntries = 3;
	else
		PalEntries = (lpbi->bmiHeader.biBitCount <= 8) ? (int)(1 << lpbi->bmiHeader.biBitCount) : 0;

	//check biClrUsed
	if (lpbi->bmiHeader.biClrUsed)
		PalEntries = lpbi->bmiHeader.biClrUsed;

	//store palette entries
	if (PalEntries)
		hRet = WriteFile(hbmf, &lpbi->bmiColors, PalEntries * sizeof(RGBQUAD), &Written, NULL);
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap WF PE failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		if (hbmf != INVALID_HANDLE_VALUE)
			CloseHandle(hbmf);
		return false;
	}

	//save current position of the file pointer in the biOffBits member of the file header
	bmfh.bfOffBits = SetFilePointer(hbmf, 0, 0, FILE_CURRENT);

	//the (optional) palette is the array of bitmap bits
	hRet = WriteFile(hbmf, lpvBits, lpbi->bmiHeader.biSizeImage, &Written, NULL);
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap WF P failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		if (hbmf != INVALID_HANDLE_VALUE)
			CloseHandle(hbmf);
		return false;
	}

	//current position of the file header is the biSize member of the file header
	//overwrite the file header that we have stored before
	bmfh.bfSize = SetFilePointer(hbmf, 0, 0, FILE_CURRENT);
	SetFilePointer(hbmf, 0, 0, FILE_BEGIN);
	hRet = WriteFile(hbmf, &bmfh, sizeof(bmfh), &Written, NULL);
	if (hRet == NULL)
	{
		gf_logger(true, "directdraw::save_bitmap WF failed");
		if (hdds)
			lpDDSPrimary->ReleaseDC(hdds);
		if (hGDIbitmap)
			DeleteObject(hGDIbitmap);
		if (bit_dc)
			DeleteDC(bit_dc);
		if (hGDIbitmap_old)
			DeleteObject(hGDIbitmap_old);
		if (lpbi)
			delete [] lpbi;
		if (lpvBits)
			delete [] lpvBits;
		if (hbmf != INVALID_HANDLE_VALUE)
			CloseHandle(hbmf);
		return false;
	}

	//---- cleanup -------------------------------------------------------------------------------

	//release file, 
	if (hdds)
		lpDDSPrimary->ReleaseDC(hdds);
	if (bit_dc)
		DeleteDC(bit_dc);
	if (hGDIbitmap)
		DeleteObject(hGDIbitmap);
	if (hGDIbitmap_old)
		DeleteObject(hGDIbitmap_old);
	if (lpbi)
		delete [] lpbi;
	if (lpvBits)
		delete [] lpvBits;
	if (hbmf != INVALID_HANDLE_VALUE)
		CloseHandle(hbmf);

	gf_logger(false, "directdraw::save_bitmap done %s", filename);
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw flip
//
//	flips surfaces
//
//------------------------------------------------------------------------------------------------

void directdraw::flip(int vsync)
{
	//flip in fullscreen, blit in windowed mode
	if (p_option->data.screenmode)
	{
		//vsync
		if (vsync)
			lpDDSPrimary->Flip(NULL,				//NULL == default flipping chain, else the surface to flip
							   0);					//flags
		else
		//async
			lpDDSPrimary->Flip(NULL,
							   DDFLIP_NOVSYNC);
	}
	else
	{
		lpDDSPrimary->Blt(&rSCREEN,			//destination RECT, NULL for entire surface
						  lpDDSBack,		//dd surface which is source of blit
						  NULL,				//source RECT, NULL for entire surface
						  DDBLT_WAIT,		//flags
						  NULL);			//address of DDBLTFX structure
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw Create16bppLUT
//
//	creates 16bit look up table for RGB values
//
//------------------------------------------------------------------------------------------------

DWORD *directdraw::Create16bppLUT(DWORD bitMask)
{
	DWORD *p_lut = new DWORD[256];
	if (p_lut == NULL)
		return NULL;

	for (register __int64 i = 0; i < 256; ++i)
	{
		p_lut[i] = DWORD(((i * __int64(bitMask)) / 255) & bitMask);
	}
	
	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cblackwhite_LUT()
//
//	creates black to white color change LUT
//
//------------------------------------------------------------------------------------------------

WORD (*directdraw::cblackwhite_LUT())[3]
{
	//create WORD array which hold the appropriate colors
	WORD (*p_lut)[3] = new WORD[101][3];
	if (p_lut == NULL)
		return NULL;

	float f_index	= 0.0f;
	WORD i_index	= 0;
	//non linear factor
	float nlf		= 0.4f;

	//change from white to black
	for (register int i = 0; i < 101; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		//linear
//		f_index		= i * 2.55f;
		//non linear
		f_index		= (float)pow(i, nlf) * (255.0f / (float)pow(100, nlf));

		//check limits
		if (f_index < 0)	f_index = 0;
		if (f_index > 255)	f_index = 255;

		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= i_index;
		p_lut[i][1]	= i_index;
		p_lut[i][2]	= i_index;
	}
	
	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cbluewhite_LUT()
//
//	creates blue to white color change LUT
//
//------------------------------------------------------------------------------------------------

WORD (*directdraw::cbluewhite_LUT())[3]
{
	//create WORD array which hold the appropriate colors
	WORD (*p_lut)[3] = new WORD[101][3];
	if (p_lut == NULL)
		return NULL;

	float f_index	= 0.0f;
	WORD i_index	= 0;
	//non linear factor
	float nlf		= 0.4f;

	//change from dark blue to light blue
	for (register int i = 0; i < 50; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		//linear
//		f_index		= i * 5.2040f;
		//non linear
		f_index		= (float)pow(i, nlf) * (255.0f / (float)pow(49, nlf));
		//check limits
		if (f_index < 0)	f_index = 0;
		if (f_index > 255)	f_index = 255;

		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= 0;
		//0 * 5.2040 = 0
		//49 * 5.2040 = (rounded)255
		p_lut[i][1]	= i_index;
		p_lut[i][2]	= 255;
	}

	//non linear factor
	nlf		= 0.4f;

	//change from light blue to white
//	for (i = 50; i < 101; ++i)
	for (i = 0; i < 51; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		//linear
//		f_index		= i * 5.1f;
		//non linear
		f_index		= (float)pow(i, nlf) * (255.0f / (float)pow(50, nlf));
		//check limits
		if (f_index < 0)	f_index = 0;
		if (f_index > 255)	f_index = 255;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		//50 * 5.1 = 255 - 255 = 0
		//100 * 5.1 = 510 - 255 = 255
//		p_lut[i][0]	= i_index - 255;
//		p_lut[i][1]	= 255;
//		p_lut[i][2]	= 255;
		p_lut[i + 50][0]	= i_index;
		p_lut[i + 50][1]	= 255;
		p_lut[i + 50][2]	= 255;
	}

//!!
/*
p_lut[0][0]	= 0;
p_lut[0][1]	= 0;
p_lut[0][2]	= 220;

for (i = 95; i < 101; ++i)
{
	p_lut[i][0]	= 255 - (100 - i);
	p_lut[i][1]	= 0;
	p_lut[i][2]	= 0;
}

	p_lut[95][0]	= 255;
	p_lut[95][1]	= 255;
	p_lut[95][2]	= 255;
	p_lut[96][0]	= 255;
	p_lut[96][1]	= 0;
	p_lut[96][2]	= 0;
	p_lut[97][0]	= 255;
	p_lut[97][1]	= 255;
	p_lut[97][2]	= 255;
	p_lut[98][0]	= 255;
	p_lut[98][1]	= 0;
	p_lut[98][2]	= 0;
	p_lut[99][0]	= 255;
	p_lut[99][1]	= 255;
	p_lut[99][2]	= 255;
	p_lut[100][0]	= 255;
	p_lut[100][1]	= 0;
	p_lut[100][2]	= 0;*/

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cgreenred_LUT()
//
//	creates green to red color change LUT
//
//------------------------------------------------------------------------------------------------

WORD (*directdraw::cgreenred_LUT())[3]
{
	//create WORD array which hold the appropriate colors
	WORD (*p_lut)[3] = new WORD[101][3];
	if (p_lut == NULL)
		return NULL;

	float f_index	= 0.0f;
	WORD i_index	= 0;
	//non linear factor
	float nlf		= 0.3f;

	//change green to yellow
	for (register int i = 0; i < 50; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		//linear
//		f_index		= i * 5.2040f;
		//non linear 50 steps (0 to 49) from 0 to 255
		f_index		= (float)pow(i, nlf) * (255.0f / (float)pow(49, nlf));
		//check limits
		if (f_index < 0)	f_index = 0;
		if (f_index > 255)	f_index = 255;

		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		//0 * 5.2040 = 0
		//49 * 5.2040 = (rounded)255
		p_lut[i][0]	= i_index;
		p_lut[i][1]	= 255;
		p_lut[i][2]	= 0;
	}

	//non linear factor
	nlf		= 2.0f;

	//change yellow to red
//	for (i = 50; i < 101; ++i)
	for (i = 0; i < 51; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		//linear
//		f_index		= i * 5.1f;
//		//round index to one place behind point
//		i_index		= (WORD)round_fi(f_index);
//		p_lut[i][0]	= 255;
//		//50 * 5.1 = 255, 510 - 255 = 255
//		//100 * 5.1 = 510, 510 - 510 = 0
//		p_lut[i][1]	= 510 - i_index;
//		p_lut[i][2]	= 0;

		//non linear from 0 to 50 for 0 to 255
		f_index		= (float)pow(i, nlf) * (255.0f / (float)pow(50, nlf));
		//check limits
		if (f_index < 0)	f_index = 0;
		if (f_index > 255)	f_index = 255;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i + 50][0]	= 255;
		p_lut[i + 50][1]	= 255 - i_index;
		p_lut[i + 50][2]	= 0;
	}

//!!
//p_lut[0][0]	= 150;
//p_lut[0][1]	= 255;
//p_lut[0][2]	= 150;

//p_lut[100][0]	= 255;
//p_lut[100][1]	= 0;
//p_lut[100][2]	= 200;

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cgreenblue_LUT()
//
//	creates green to blue color change LUT
//
//------------------------------------------------------------------------------------------------

WORD (*directdraw::cgreenblue_LUT())[3]
{
	//create WORD array which hold the appropriate colors
	WORD (*p_lut)[3] = new WORD[101][3];
	if (p_lut == NULL)
		return NULL;

	float f_index	= 0.0f;
	WORD i_index	= 0;

	//change green to light blue
	for (register int i = 0; i < 50; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		f_index		= i * 5.2040f;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= 0;
		p_lut[i][1]	= 255;
		//0 * 5.2040 = 0
		//49 * 5.2040 = (rounded)255
		p_lut[i][2]	= i_index;
	}
	
	//change light blue to blue
	for (i = 50; i < 101; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		f_index		= i * 5.1f;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= 0;
		//50 * 5.1 = 255, 510 - 255 = 255
		//100 * 5.1 = 510, 510 - 510 = 0
		p_lut[i][1]	= 510 - i_index;
		p_lut[i][2]	= 255;
	}

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cyellowpink_LUT()
//
//	creates yellow to pink color change LUT
//
//------------------------------------------------------------------------------------------------

WORD (*directdraw::cyellowpink_LUT())[3]
{
	//create WORD array which hold the appropriate colors
	WORD (*p_lut)[3] = new WORD[101][3];
	if (p_lut == NULL)
		return NULL;

	float f_index	= 0.0f;
	WORD i_index	= 0;

	//change yellow to red
	for (register int i = 0; i < 50; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		f_index		= i * 5.2040f;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= 255;
		//0 * 5.2040 = 0, 255 - 0 = 255
		//49 * 5.2040 = (rounded)255, 255 - 255 = 0
		p_lut[i][1]	= 255 - i_index;
		p_lut[i][2]	= 0;
	}
	
	//change red to pink
	for (i = 50; i < 101; ++i)
	{
		//so that between the 100 values of the array
		//the color increase is spread equally
		f_index		= i * 5.1f;
		//round index to one place behind point
		i_index		= (WORD)round_fi(f_index);
		p_lut[i][0]	= 255;
		//50 * 5.1 = 255, 255 - 255 = 0
		//100 * 5.1 = 510, 510 - 255 = 255
		p_lut[i][1]	= 0;
		p_lut[i][2]	= i_index - 255;
	}

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cfontbm_LUT
//
//	creates LUT for custom bitmap font
//	ascii code index points to right offscreen-surface coordinates
//
//------------------------------------------------------------------------------------------------

RECT *directdraw::cfontbm_LUT()
{
	//create RECT array which holds data of offscreensurface font
	RECT *p_lut = new RECT[256];
	if (p_lut == NULL)
		return NULL;

	int asciicode = 0;

	for (register int column = 0; column < 8; ++column)
	{
		for (register int line = 0; line < 32; ++line)
		{
			//every letter is 8 * 16 pixels in size
			p_lut[asciicode].top = column * 16;
			p_lut[asciicode].bottom = column * 16 + 16;
			p_lut[asciicode].left = line * 8;
			p_lut[asciicode].right = line * 8 + 8;

			++asciicode;
		}
	}

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw cfontsl_LUT
//
//	creates LUT for custom scanline font
//	ascii code index points to right array[6] of RECTS describing each letter
//	defaultsize of each letter is 32 * 48 pixels, some (g for example) are
//	32 * 58 pixels
//
//------------------------------------------------------------------------------------------------

RECT (*directdraw::cfontsl_LUT())[6]
{
	//create RECT array which holds data of scanline font
	//256 letters (ascii code), each letter consists of 6 RECTS
	RECT (*p_lut)[6] = new RECT[256][6];
	if (p_lut == NULL)
		return NULL;

	//set every value to -1 indicating it is not used
	//(for example if a letter only uses 5 RECTS instead of 6)
	for (register int column = 0; column < 256; ++column)
		for (register int line = 0; line < 6; ++line)
		{
			p_lut[column][line].left = p_lut[column][line].right =
			p_lut[column][line].top = p_lut[column][line].bottom = -1;
		}

	//---- the font definition -------------------------------------------------------------------

	//yinyang
	fillRECT(p_lut[2][0], 0, 8, 32, 40);	fillRECT(p_lut[2][1], 0, 24, 20, 40);
	fillRECT(p_lut[2][2], 12, 8, 32, 24);	fillRECT(p_lut[2][3], 8, 29, 14, 35);
	fillRECT(p_lut[2][4], 18, 13, 24, 19);	fillRECT(p_lut[2][5], -1, -1, -1, -1);

	//!
	fillRECT(p_lut[33][0], 10, 1, 22, 31);	fillRECT(p_lut[33][1], 10, 36, 22, 48);
	fillRECT(p_lut[33][2], -1, -1, -1, -1);	fillRECT(p_lut[33][3], -1, -1, -1, -1);
	fillRECT(p_lut[33][4], -1, -1, -1, -1);	fillRECT(p_lut[33][5], -1, -1, -1, -1);

	//"
	fillRECT(p_lut[34][0], 6, 3, 14, 15);	fillRECT(p_lut[34][1], 18, 3, 26, 15);
	fillRECT(p_lut[34][2], -1, -1, -1, -1);	fillRECT(p_lut[34][3], -1, -1, -1, -1);
	fillRECT(p_lut[34][4], -1, -1, -1, -1);	fillRECT(p_lut[34][5], -1, -1, -1, -1);

	//#
	fillRECT(p_lut[35][0], 0, 12, 32, 20);	fillRECT(p_lut[35][1], 0, 28, 32, 36);
	fillRECT(p_lut[35][2], 5, 8, 13, 40);	fillRECT(p_lut[35][3], 19, 8, 27, 40);
	fillRECT(p_lut[35][4], -1, -1, -1, -1);	fillRECT(p_lut[35][5], -1, -1, -1, -1);

	//$
	fillRECT(p_lut[36][0], 6, 4, 26, 12);	fillRECT(p_lut[36][1], 2, 7, 10, 23);
	fillRECT(p_lut[36][2], 6, 21, 26, 29);	fillRECT(p_lut[36][3], 22, 26, 30, 42);
	fillRECT(p_lut[36][4], 4, 36, 24, 44);	fillRECT(p_lut[36][5], 12, 0, 20, 48);

	//%
	fillRECT(p_lut[37][0], 21, 35, 29, 43);	fillRECT(p_lut[37][1], 3, 5, 11, 13);
	fillRECT(p_lut[37][2], 12, 18, 20, 30);	fillRECT(p_lut[37][3], 20, 6, 28, 18);
	fillRECT(p_lut[37][4], 4, 30, 12, 42);	fillRECT(p_lut[37][5], -1, -1, -1, -1);

	//&
	fillRECT(p_lut[38][0], 1, 5, 11, 41);	fillRECT(p_lut[38][1], 21, 5, 31, 41);
	fillRECT(p_lut[38][2], 7, 1, 25, 11);	fillRECT(p_lut[38][3], 7, 20, 25, 28);
	fillRECT(p_lut[38][4], 7, 37, 25, 47);	fillRECT(p_lut[38][5], 13, 33, 19, 53);

	//'
	fillRECT(p_lut[39][0], 12, 1, 20, 17);	fillRECT(p_lut[39][1], -1, -1, -1, -1);
	fillRECT(p_lut[39][2], -1, -1, -1, -1);	fillRECT(p_lut[39][3], -1, -1, -1, -1);
	fillRECT(p_lut[39][4], -1, -1, -1, -1);	fillRECT(p_lut[39][5], -1, -1, -1, -1);

	//(
	fillRECT(p_lut[40][0], 2, 9, 10, 39);	fillRECT(p_lut[40][1], 10, 1, 22, 9);
	fillRECT(p_lut[40][2], 10, 39, 22, 47);	fillRECT(p_lut[40][3], -1, -1, -1, -1);
	fillRECT(p_lut[40][4], -1, -1, -1, -1);	fillRECT(p_lut[40][5], -1, -1, -1, -1);

	//)
	fillRECT(p_lut[41][0], 22, 9, 30, 39);	fillRECT(p_lut[41][1], 10, 1, 22, 9);
	fillRECT(p_lut[41][2], 10, 39, 22, 47);	fillRECT(p_lut[41][3], -1, -1, -1, -1);
	fillRECT(p_lut[41][4], -1, -1, -1, -1);	fillRECT(p_lut[41][5], -1, -1, -1, -1);

	//*
	fillRECT(p_lut[42][0], 10, 18, 22, 30);	fillRECT(p_lut[42][1], 6, 14, 14, 18);
	fillRECT(p_lut[42][2], 18, 14, 26, 18);	fillRECT(p_lut[42][3], 18, 30, 26, 34);
	fillRECT(p_lut[42][4], 6, 30, 14, 34);	fillRECT(p_lut[42][5], 30, 26, 2, 22);

	//+
	fillRECT(p_lut[43][0], 4, 19, 28, 29);	fillRECT(p_lut[43][1], 11, 12, 21, 36);
	fillRECT(p_lut[43][2], -1, -1, -1, -1);	fillRECT(p_lut[43][3], -1, -1, -1, -1);
	fillRECT(p_lut[43][4], -1, -1, -1, -1);	fillRECT(p_lut[43][5], -1, -1, -1, -1);

	//,
	fillRECT(p_lut[44][0], 12, 32, 20, 48);	fillRECT(p_lut[44][1], -1, -1, -1, -1);
	fillRECT(p_lut[44][2], -1, -1, -1, -1);	fillRECT(p_lut[44][3], -1, -1, -1, -1);
	fillRECT(p_lut[44][4], -1, -1, -1, -1);	fillRECT(p_lut[44][5], -1, -1, -1, -1);

	//-
	fillRECT(p_lut[45][0], 4, 19, 28, 29);	fillRECT(p_lut[45][1], -1, -1, -1, -1);
	fillRECT(p_lut[45][2], -1, -1, -1, -1);	fillRECT(p_lut[45][3], -1, -1, -1, -1);
	fillRECT(p_lut[45][4], -1, -1, -1, -1);	fillRECT(p_lut[45][5], -1, -1, -1, -1);

	//.
	fillRECT(p_lut[46][0], 10, 36, 22, 48);	fillRECT(p_lut[46][1], -1, -1, -1, -1);
	fillRECT(p_lut[46][2], -1, -1, -1, -1);	fillRECT(p_lut[46][3], -1, -1, -1, -1);
	fillRECT(p_lut[46][4], -1, -1, -1, -1);	fillRECT(p_lut[46][5], -1, -1, -1, -1);

	///
	fillRECT(p_lut[47][0], 12, 16, 20, 32);	fillRECT(p_lut[47][1], 20, 1, 28, 16);
	fillRECT(p_lut[47][2], 4, 32, 12, 47);	fillRECT(p_lut[47][3], -1, -1, -1, -1);
	fillRECT(p_lut[47][4], -1, -1, -1, -1);	fillRECT(p_lut[47][5], -1, -1, -1, -1);

	//0
	fillRECT(p_lut[48][0], 1, 5, 11, 43);	fillRECT(p_lut[48][1], 21, 5, 31, 43);
	fillRECT(p_lut[48][2], 7, 1, 25, 11);	fillRECT(p_lut[48][3], 7, 37, 25, 47);
	fillRECT(p_lut[48][4], 13, 21, 19, 27);	fillRECT(p_lut[48][5], -1, -1, -1, -1);

	//1
	fillRECT(p_lut[49][0], 12, 1, 24, 37);	fillRECT(p_lut[49][1], 5, 37, 29, 47);
	fillRECT(p_lut[49][2], 5, 8, 17, 19);	fillRECT(p_lut[49][3], -1, -1, -1, -1);
	fillRECT(p_lut[49][4], -1, -1, -1, -1);	fillRECT(p_lut[49][5], -1, -1, -1, -1);

	//2
	fillRECT(p_lut[50][0], 2, 1, 27, 11);	fillRECT(p_lut[50][1], 21, 7, 31, 25);
	fillRECT(p_lut[50][2], 3, 18, 23, 28);	fillRECT(p_lut[50][3], 1, 24, 11, 42);
	fillRECT(p_lut[50][4], 6, 37, 30, 47);	fillRECT(p_lut[50][5], -1, -1, -1, -1);

	//3
	fillRECT(p_lut[51][0], 1, 1, 27, 11);	fillRECT(p_lut[51][1], 19, 8, 31, 42);
	fillRECT(p_lut[51][2], 1, 37, 25, 47);	fillRECT(p_lut[51][3], 9, 19, 23, 29);
	fillRECT(p_lut[51][4], -1, -1, -1, -1);	fillRECT(p_lut[51][5], -1, -1, -1, -1);

	//4
	fillRECT(p_lut[52][0], 1, 1, 11, 27);	fillRECT(p_lut[52][1], 6, 21, 31, 31);
	fillRECT(p_lut[52][2], 15, 9, 25, 47);	fillRECT(p_lut[52][3], -1, -1, -1, -1);
	fillRECT(p_lut[52][4], -1, -1, -1, -1);	fillRECT(p_lut[52][5], -1, -1, -1, -1);

	//5
	fillRECT(p_lut[53][0], 6, 1, 30, 11);	fillRECT(p_lut[53][1], 1, 5, 11, 25);
	fillRECT(p_lut[53][2], 6, 18, 26, 28);	fillRECT(p_lut[53][3], 21, 24, 31, 44);
	fillRECT(p_lut[53][4], 1, 38, 25, 48);	fillRECT(p_lut[53][5], -1, -1, -1, -1);

	//6
	fillRECT(p_lut[54][0], 3, 1, 29, 11);	fillRECT(p_lut[54][1], 1, 7, 11, 45);
	fillRECT(p_lut[54][2], 6, 37, 26, 47);	fillRECT(p_lut[54][3], 7, 18, 27, 28);
	fillRECT(p_lut[54][4], 21, 23, 31, 43);	fillRECT(p_lut[54][5], -1, -1, -1, -1);

	//7
	fillRECT(p_lut[55][0], 2, 1, 30, 11);	fillRECT(p_lut[55][1], 15, 11, 25, 21);
	fillRECT(p_lut[55][2], 11, 31, 21, 47);	fillRECT(p_lut[55][3], 5, 21, 29, 31);
	fillRECT(p_lut[55][4], -1, -1, -1, -1);	fillRECT(p_lut[55][5], -1, -1, -1, -1);

	//8
	fillRECT(p_lut[56][0], 1, 5, 11, 43);	fillRECT(p_lut[56][1], 21, 5, 31, 43);
	fillRECT(p_lut[56][2], 7, 1, 25, 11);	fillRECT(p_lut[56][3], 7, 37, 25, 47);
	fillRECT(p_lut[56][4], 8, 19, 24, 29);	fillRECT(p_lut[56][5], -1, -1, -1, -1);

	//9
	fillRECT(p_lut[57][0], 5, 1, 27, 11);	fillRECT(p_lut[57][1], 0, 6, 10, 24);
	fillRECT(p_lut[57][2], 2, 37, 26, 47);	fillRECT(p_lut[57][3], 21, 6, 31, 40);
	fillRECT(p_lut[57][4], 5, 20, 25, 29);	fillRECT(p_lut[57][5], -1, -1, -1, -1);

	//:
	fillRECT(p_lut[58][0], 10, 9, 22, 21);	fillRECT(p_lut[58][1], 10, 27, 22, 39);
	fillRECT(p_lut[58][2], -1, -1, -1, -1);	fillRECT(p_lut[58][3], -1, -1, -1, -1);
	fillRECT(p_lut[58][4], -1, -1, -1, -1);	fillRECT(p_lut[58][5], -1, -1, -1, -1);

	//;
	fillRECT(p_lut[59][0], 12, 32, 20, 48);	fillRECT(p_lut[59][1], 12, 20, 20, 28);
	fillRECT(p_lut[59][2], -1, -1, -1, -1);	fillRECT(p_lut[59][3], -1, -1, -1, -1);
	fillRECT(p_lut[59][4], -1, -1, -1, -1);	fillRECT(p_lut[59][5], -1, -1, -1, -1);

	//<
	fillRECT(p_lut[60][0], 0, 20, 10, 28);	fillRECT(p_lut[60][1], 10, 12, 22, 20);
	fillRECT(p_lut[60][2], 10, 28, 22, 36);	fillRECT(p_lut[60][3], 22, 4, 30, 12);
	fillRECT(p_lut[60][4], 22, 36, 30, 44);	fillRECT(p_lut[60][5], -1, -1, -1, -1);

	//=
	fillRECT(p_lut[61][0], 6, 14, 28, 22);	fillRECT(p_lut[61][1], 6, 26, 28, 34);
	fillRECT(p_lut[61][2], -1, -1, -1, -1);	fillRECT(p_lut[61][3], -1, -1, -1, -1);
	fillRECT(p_lut[61][4], -1, -1, -1, -1);	fillRECT(p_lut[61][5], -1, -1, -1, -1);

	//>
	fillRECT(p_lut[62][0], 22, 20, 32, 28);	fillRECT(p_lut[62][1], 10, 12, 22, 20);
	fillRECT(p_lut[62][2], 10, 28, 22, 36);	fillRECT(p_lut[62][3], 2, 4, 10, 12);
	fillRECT(p_lut[62][4], 2, 36, 10, 44);	fillRECT(p_lut[62][5], -1, -1, -1, -1);

	//?
	fillRECT(p_lut[63][0], 19, 6, 29, 22);	fillRECT(p_lut[63][1], 6, 1, 26, 11);
	fillRECT(p_lut[63][2], 11, 18, 21, 31);	fillRECT(p_lut[63][3], 10, 36, 22, 48);
	fillRECT(p_lut[63][4], -1, -1, -1, -1);	fillRECT(p_lut[63][5], -1, -1, -1, -1);

	//@
	fillRECT(p_lut[64][0], 16, 17, 30, 31);	fillRECT(p_lut[64][1], 21, 7, 29, 17);
	fillRECT(p_lut[64][2], 4, 2, 24, 10);	fillRECT(p_lut[64][3], 0, 8, 9, 37);
	fillRECT(p_lut[64][4], 5, 36, 27, 44);	fillRECT(p_lut[64][5], -1, -1, -1, -1);

	//A
	fillRECT(p_lut[65][0], 1, 5, 11, 47);	fillRECT(p_lut[65][1], 21, 5, 31, 47);
	fillRECT(p_lut[65][2], 7, 1, 25, 11);	fillRECT(p_lut[65][3], 7, 21, 25, 31);
	fillRECT(p_lut[65][4], -1, -1, -1, -1);	fillRECT(p_lut[65][5], -1, -1, -1, -1);

	//B
	fillRECT(p_lut[66][0], 1, 1, 29, 11);	fillRECT(p_lut[66][1], 1, 37, 29, 47);
	fillRECT(p_lut[66][2], 4, 11, 14, 37);	fillRECT(p_lut[66][3], 21, 7, 31, 21);
	fillRECT(p_lut[66][4], 21, 26, 31, 40);	fillRECT(p_lut[66][5], 10, 19, 24, 27);

	//C
	fillRECT(p_lut[67][0], 1, 6, 11, 40);	fillRECT(p_lut[67][1], 6, 1, 30, 11);
	fillRECT(p_lut[67][2], 6, 36, 30, 46);	fillRECT(p_lut[67][3], -1, -1, -1, -1);
	fillRECT(p_lut[67][4], -1, -1, -1, -1);	fillRECT(p_lut[67][5], -1, -1, -1, -1);

	//D
	fillRECT(p_lut[68][0], 4, 11, 14, 37);	fillRECT(p_lut[68][1], 1, 1, 27, 11);
	fillRECT(p_lut[68][2], 1, 37, 27, 47);	fillRECT(p_lut[68][3], 20, 8, 31, 41);
	fillRECT(p_lut[68][4], -1, -1, -1, -1);	fillRECT(p_lut[68][5], -1, -1, -1, -1);

	//E
	fillRECT(p_lut[69][0], 3, 11, 15, 37);	fillRECT(p_lut[69][1], 1, 1, 30, 11);
	fillRECT(p_lut[69][2], 1, 37, 30, 47);	fillRECT(p_lut[69][3], 10, 19, 26, 29);
	fillRECT(p_lut[69][4], -1, -1, -1, -1);	fillRECT(p_lut[69][5], -1, -1, -1, -1);

	//F
	fillRECT(p_lut[70][0], 3, 11, 15, 47);	fillRECT(p_lut[70][1], 1, 1, 30, 11);
	fillRECT(p_lut[70][2], 9, 19, 27, 29);	fillRECT(p_lut[70][3], -1, -1, -1, -1);
	fillRECT(p_lut[70][4], -1, -1, -1, -1);	fillRECT(p_lut[70][5], -1, -1, -1, -1);

	//G
	fillRECT(p_lut[71][0], 1, 6, 11, 42);	fillRECT(p_lut[71][1], 6, 35, 26, 47);
	fillRECT(p_lut[71][2], 6, 1, 30, 11);	fillRECT(p_lut[71][3], 20, 24, 31, 40);
	fillRECT(p_lut[71][4], -1, -1, -1, -1);	fillRECT(p_lut[71][5], -1, -1, -1, -1);

	//H
	fillRECT(p_lut[72][0], 1, 2, 11, 47);	fillRECT(p_lut[72][1], 21, 2, 31, 47);
	fillRECT(p_lut[72][2], 7, 19, 25, 29);	fillRECT(p_lut[72][3], -1, -1, -1, -1);
	fillRECT(p_lut[72][4], -1, -1, -1, -1);	fillRECT(p_lut[72][5], -1, -1, -1, -1);

	//I
	fillRECT(p_lut[73][0], 11, 10, 21, 37);	fillRECT(p_lut[73][1], 7, 2, 25, 10);
	fillRECT(p_lut[73][2], 7, 37, 25, 47);	fillRECT(p_lut[73][3], -1, -1, -1, -1);
	fillRECT(p_lut[73][4], -1, -1, -1, -1);	fillRECT(p_lut[73][5], -1, -1, -1, -1);

	//J
	fillRECT(p_lut[74][0], 11, 2, 29, 12);	fillRECT(p_lut[74][1], 15, 12, 25, 42);
	fillRECT(p_lut[74][2], 1, 32, 11, 42);	fillRECT(p_lut[74][3], 6, 37, 18, 47);
	fillRECT(p_lut[74][4], -1, -1, -1, -1);	fillRECT(p_lut[74][5], -1, -1, -1, -1);

	//K
	fillRECT(p_lut[75][0], 3, 1, 13, 47);	fillRECT(p_lut[75][1], 10, 18, 21, 28);
	fillRECT(p_lut[75][2], 20, 1, 30, 18);	fillRECT(p_lut[75][3], 20, 28, 30, 47);
	fillRECT(p_lut[75][4], -1, -1, -1, -1);	fillRECT(p_lut[75][5], -1, -1, -1, -1);

	//L
	fillRECT(p_lut[76][0], 2, 1, 12, 43);	fillRECT(p_lut[76][1], 6, 35, 30, 47);
	fillRECT(p_lut[76][2], -1, -1, -1, -1);	fillRECT(p_lut[76][3], -1, -1, -1, -1);
	fillRECT(p_lut[76][4], -1, -1, -1, -1);	fillRECT(p_lut[76][5], -1, -1, -1, -1);

	//M
	fillRECT(p_lut[77][0], 1, 11, 10, 47);	fillRECT(p_lut[77][1], 22, 11, 31, 47);
	fillRECT(p_lut[77][2], 12, 12, 20, 26);	fillRECT(p_lut[77][3], 4, 1, 14, 17);
	fillRECT(p_lut[77][4], 18, 1, 28, 17);	fillRECT(p_lut[77][5], -1, -1, -1, -1);

	//N
	fillRECT(p_lut[78][0], 1, 2, 11, 47);	fillRECT(p_lut[78][1], 21, 2, 31, 47);
	fillRECT(p_lut[78][2], 7, 6, 16, 24);	fillRECT(p_lut[78][3], 16, 24, 25, 42);
	fillRECT(p_lut[78][4], -1, -1, -1, -1);	fillRECT(p_lut[78][5], -1, -1, -1, -1);

	//O
	fillRECT(p_lut[79][0], 1, 5, 11, 43);	fillRECT(p_lut[79][1], 21, 5, 31, 43);
	fillRECT(p_lut[79][2], 7, 1, 25, 11);	fillRECT(p_lut[79][3], 7, 37, 25, 47);
	fillRECT(p_lut[79][4], -1, -1, -1, -1);	fillRECT(p_lut[79][5], -1, -1, -1, -1);

	//P
	fillRECT(p_lut[80][0], 2, 4, 12, 47);	fillRECT(p_lut[80][1], 6, 1, 28, 11);
	fillRECT(p_lut[80][2], 7, 23, 27, 33);	fillRECT(p_lut[80][3], 21, 6, 31, 27);
	fillRECT(p_lut[80][4], -1, -1, -1, -1);	fillRECT(p_lut[80][5], -1, -1, -1, -1);

	//Q
	fillRECT(p_lut[81][0], 1, 8, 11, 40);	fillRECT(p_lut[81][1], 21, 8, 31, 40);
	fillRECT(p_lut[81][2], 7, 1, 25, 11);	fillRECT(p_lut[81][3], 7, 37, 25, 47);
	fillRECT(p_lut[81][4], 13, 32, 19, 52);	fillRECT(p_lut[81][5], -1, -1, -1, -1);

	//R
	fillRECT(p_lut[82][0], 2, 11, 12, 47);	fillRECT(p_lut[82][1], 1, 1, 27, 11);
	fillRECT(p_lut[82][2], 21, 6, 31, 22);	fillRECT(p_lut[82][3], 8, 18, 24, 28);
	fillRECT(p_lut[82][4], 12, 28, 20, 36);	fillRECT(p_lut[82][5], 20, 36, 31, 47);

	//S
	fillRECT(p_lut[83][0], 6, 1, 28, 11);	fillRECT(p_lut[83][1], 1, 5, 11, 23);
	fillRECT(p_lut[83][2], 1, 35, 27, 47);	fillRECT(p_lut[83][3], 21, 24, 31, 42);
	fillRECT(p_lut[83][4], 6, 19, 24, 29);	fillRECT(p_lut[83][5], -1, -1, -1, -1);

	//T
	fillRECT(p_lut[84][0], 1, 1, 31, 11);	fillRECT(p_lut[84][1], 11, 11, 21, 47);
	fillRECT(p_lut[84][2], -1, -1, -1, -1);	fillRECT(p_lut[84][3], -1, -1, -1, -1);
	fillRECT(p_lut[84][4], -1, -1, -1, -1);	fillRECT(p_lut[84][5], -1, -1, -1, -1);

	//U
	fillRECT(p_lut[85][0], 1, 2, 11, 40);	fillRECT(p_lut[85][1], 21, 2, 31, 40);
	fillRECT(p_lut[85][2], 7, 37, 25, 47);	fillRECT(p_lut[85][3], -1, -1, -1, -1);
	fillRECT(p_lut[85][4], -1, -1, -1, -1);	fillRECT(p_lut[85][5], -1, -1, -1, -1);

	//V
	fillRECT(p_lut[86][0], 1, 2, 11, 36);	fillRECT(p_lut[86][1], 21, 2, 31, 36);
	fillRECT(p_lut[86][2], 9, 34, 23, 48);	fillRECT(p_lut[86][3], -1, -1, -1, -1);
	fillRECT(p_lut[86][4], -1, -1, -1, -1);	fillRECT(p_lut[86][5], -1, -1, -1, -1);

	//W
	fillRECT(p_lut[87][0], 1, 1, 10, 39);	fillRECT(p_lut[87][1], 22, 1, 31, 39);
	fillRECT(p_lut[87][2], 12, 22, 20, 42);	fillRECT(p_lut[87][3], 3, 37, 13, 47);
	fillRECT(p_lut[87][4], 19, 37, 29, 47);	fillRECT(p_lut[87][5], -1, -1, -1, -1);

	//X
	fillRECT(p_lut[88][0], 10, 16, 23, 29);	fillRECT(p_lut[88][1], 1, 1, 13, 19);
	fillRECT(p_lut[88][2], 19, 1, 31, 19);	fillRECT(p_lut[88][3], 2, 25, 14, 47);
	fillRECT(p_lut[88][4], 19, 25, 31, 47);	fillRECT(p_lut[88][5], -1, -1, -1, -1);

	//Y
	fillRECT(p_lut[89][0], 7, 19, 25, 27);	fillRECT(p_lut[89][1], 2, 2, 12, 22);
	fillRECT(p_lut[89][2], 20, 2, 30, 22);	fillRECT(p_lut[89][3], 11, 27, 21, 47);
	fillRECT(p_lut[89][4], -1, -1, -1, -1);	fillRECT(p_lut[89][5], -1, -1, -1, -1);

	//Z
	fillRECT(p_lut[90][0], 2, 1, 30, 11);	fillRECT(p_lut[90][1], 16, 11, 27, 24);
	fillRECT(p_lut[90][2], 5, 24, 16, 37);	fillRECT(p_lut[90][3], 2, 37, 30, 47);
	fillRECT(p_lut[90][4], -1, -1, -1, -1);	fillRECT(p_lut[90][5], -1, -1, -1, -1);

	//[
	fillRECT(p_lut[91][0], 3, 8, 11, 40);	fillRECT(p_lut[91][1], 3, 0, 19, 8);
	fillRECT(p_lut[91][2], 3, 40, 19, 48);	fillRECT(p_lut[91][3], -1, -1, -1, -1);
	fillRECT(p_lut[91][4], -1, -1, -1, -1);	fillRECT(p_lut[91][5], -1, -1, -1, -1);

	//"\\"
	fillRECT(p_lut[92][0], 4, 1, 12, 16);	fillRECT(p_lut[92][1], 20, 32, 28, 47);
	fillRECT(p_lut[92][2], 12, 16, 20, 32);	fillRECT(p_lut[92][3], -1, -1, -1, -1);
	fillRECT(p_lut[92][4], -1, -1, -1, -1);	fillRECT(p_lut[92][5], -1, -1, -1, -1);

	//]
	fillRECT(p_lut[93][0], 21, 8, 29, 40);	fillRECT(p_lut[93][1], 13, 0, 29, 8);
	fillRECT(p_lut[93][2], 13, 40, 29, 48);	fillRECT(p_lut[93][3], -1, -1, -1, -1);
	fillRECT(p_lut[93][4], -1, -1, -1, -1);	fillRECT(p_lut[93][5], -1, -1, -1, -1);

	//^
	fillRECT(p_lut[94][0], 12, 1, 20, 13);	fillRECT(p_lut[94][1], 4, 13, 12, 25);
	fillRECT(p_lut[94][2], 20, 13, 28, 25);	fillRECT(p_lut[94][3], -1, -1, -1, -1);
	fillRECT(p_lut[94][4], -1, -1, -1, -1);	fillRECT(p_lut[94][5], -1, -1, -1, -1);

	//_
	fillRECT(p_lut[95][0], 4, 37, 28, 47);	fillRECT(p_lut[95][1], -1, -1, -1, -1);
	fillRECT(p_lut[95][2], -1, -1, -1, -1);	fillRECT(p_lut[95][3], -1, -1, -1, -1);
	fillRECT(p_lut[95][4], -1, -1, -1, -1);	fillRECT(p_lut[95][5], -1, -1, -1, -1);

	//a
	fillRECT(p_lut[97][0], 4, 10, 28, 19);	fillRECT(p_lut[97][1], 4, 38, 27, 47);
	fillRECT(p_lut[97][2], 21, 17, 31, 42);	fillRECT(p_lut[97][3], 0, 28, 10, 42);
	fillRECT(p_lut[97][4], 4, 24, 24, 32);	fillRECT(p_lut[97][5], -1, -1, -1, -1);

	//b
	fillRECT(p_lut[98][0], 1, 1, 11, 43);	fillRECT(p_lut[98][1], 21, 21, 31, 41);
	fillRECT(p_lut[98][2], 7, 16, 25, 26);	fillRECT(p_lut[98][3], 6, 37, 24, 47);
	fillRECT(p_lut[98][4], -1, -1, -1, -1);	fillRECT(p_lut[98][5], -1, -1, -1, -1);

	//c
	fillRECT(p_lut[99][0], 2, 16, 12, 43);	fillRECT(p_lut[99][1], 6, 13, 28, 23);
	fillRECT(p_lut[99][2], 6, 37, 28, 47);	fillRECT(p_lut[99][3], -1, -1, -1, -1);
	fillRECT(p_lut[99][4], -1, -1, -1, -1);	fillRECT(p_lut[99][5], -1, -1, -1, -1);

	//d
	fillRECT(p_lut[100][0], 21, 1, 31, 43);	fillRECT(p_lut[100][1], 4, 37, 25, 47);
	fillRECT(p_lut[100][2], 4, 15, 25, 25);	fillRECT(p_lut[100][3], 1, 21, 11, 41);
	fillRECT(p_lut[100][4], -1, -1, -1, -1);	fillRECT(p_lut[100][5], -1, -1, -1, -1);

	//e
	fillRECT(p_lut[101][0], 1, 18, 11, 42);	fillRECT(p_lut[101][1], 22, 15, 31, 31);
	fillRECT(p_lut[101][2], 6, 11, 26, 20);	fillRECT(p_lut[101][3], 6, 26, 25, 34);
	fillRECT(p_lut[101][4], 6, 38, 28, 47);	fillRECT(p_lut[101][5], -1, -1, -1, -1);

	//f
	fillRECT(p_lut[102][0], 11, 1, 26, 11);	fillRECT(p_lut[102][1], 11, 11, 20, 47);
	fillRECT(p_lut[102][2], 7, 18, 25, 28);	fillRECT(p_lut[102][3], -1, -1, -1, -1);
	fillRECT(p_lut[102][4], -1, -1, -1, -1);	fillRECT(p_lut[102][5], -1, -1, -1, -1);

	//g
	fillRECT(p_lut[103][0], 5, 12, 27, 22);	fillRECT(p_lut[103][1], 1, 18, 11, 38);
	fillRECT(p_lut[103][2], 21, 18, 31, 53);	fillRECT(p_lut[103][3], 6, 32, 21, 42);
	fillRECT(p_lut[103][4], 1, 48, 25, 58);	fillRECT(p_lut[103][5], -1, -1, -1, -1);

	//h
	fillRECT(p_lut[104][0], 1, 1, 11, 47);	fillRECT(p_lut[104][1], 6, 17, 28, 27);
	fillRECT(p_lut[104][2], 21, 21, 31, 47);	fillRECT(p_lut[104][3], -1, -1, -1, -1);
	fillRECT(p_lut[104][4], -1, -1, -1, -1);	fillRECT(p_lut[104][5], -1, -1, -1, -1);

	//i
	fillRECT(p_lut[105][0], 11, 19, 21, 47);	fillRECT(p_lut[105][1], 11, 2, 21, 12);
	fillRECT(p_lut[105][2], -1, -1, -1, -1);	fillRECT(p_lut[105][3], -1, -1, -1, -1);
	fillRECT(p_lut[105][4], -1, -1, -1, -1);	fillRECT(p_lut[105][5], -1, -1, -1, -1);

	//j
	fillRECT(p_lut[106][0], 11, 1, 21, 11);	fillRECT(p_lut[106][1], 11, 17, 21, 53);
	fillRECT(p_lut[106][2], 4, 45, 16, 57);	fillRECT(p_lut[106][3], -1, -1, -1, -1);
	fillRECT(p_lut[106][4], -1, -1, -1, -1);	fillRECT(p_lut[106][5], -1, -1, -1, -1);

	//k
	fillRECT(p_lut[107][0], 1, 1, 11, 47);	fillRECT(p_lut[107][1], 9, 23, 20, 34);
	fillRECT(p_lut[107][2], 18, 12, 28, 26);	fillRECT(p_lut[107][3], 18, 31, 30, 47);
	fillRECT(p_lut[107][4], -1, -1, -1, -1);	fillRECT(p_lut[107][5], -1, -1, -1, -1);

	//l
	fillRECT(p_lut[108][0], 9, 1, 19, 44);	fillRECT(p_lut[108][1], 15, 35, 27, 47);
	fillRECT(p_lut[108][2], -1, -1, -1, -1);	fillRECT(p_lut[108][3], -1, -1, -1, -1);
	fillRECT(p_lut[108][4], -1, -1, -1, -1);	fillRECT(p_lut[108][5], -1, -1, -1, -1);

	//m
	fillRECT(p_lut[109][0], 1, 17, 10, 47);	fillRECT(p_lut[109][1], 22, 17, 31, 47);
	fillRECT(p_lut[109][2], 12, 22, 20, 33);	fillRECT(p_lut[109][3], 4, 13, 14, 23);
	fillRECT(p_lut[109][4], 18, 13, 28, 23);	fillRECT(p_lut[109][5], -1, -1, -1, -1);

	//n
	fillRECT(p_lut[110][0], 1, 17, 11, 47);	fillRECT(p_lut[110][1], 21, 19, 31, 47);
	fillRECT(p_lut[110][2], 7, 14, 25, 24);	fillRECT(p_lut[110][3], -1, -1, -1, -1);
	fillRECT(p_lut[110][4], -1, -1, -1, -1);	fillRECT(p_lut[110][5], -1, -1, -1, -1);

	//o
	fillRECT(p_lut[111][0], 1, 17, 11, 41);	fillRECT(p_lut[111][1], 21, 17, 31, 41);
	fillRECT(p_lut[111][2], 7, 11, 25, 21);	fillRECT(p_lut[111][3], 7, 37, 25, 47);
	fillRECT(p_lut[111][4], -1, -1, -1, -1);	fillRECT(p_lut[111][5], -1, -1, -1, -1);

	//p
	fillRECT(p_lut[112][0], 1, 15, 11, 57);	fillRECT(p_lut[112][1], 21, 18, 31, 39);
	fillRECT(p_lut[112][2], 7, 12, 25, 22);	fillRECT(p_lut[112][3], 7, 35, 25, 45);
	fillRECT(p_lut[112][4], -1, -1, -1, -1);	fillRECT(p_lut[112][5], -1, -1, -1, -1);

	//q
	fillRECT(p_lut[113][0], 21, 16, 31, 57);	fillRECT(p_lut[113][1], 1, 17, 11, 41);
	fillRECT(p_lut[113][2], 7, 12, 25, 22);	fillRECT(p_lut[113][3], 7, 35, 25, 45);
	fillRECT(p_lut[113][4], -1, -1, -1, -1);	fillRECT(p_lut[113][5], -1, -1, -1, -1);

	//r
	fillRECT(p_lut[114][0], 3, 17, 13, 47);	fillRECT(p_lut[114][1], 9, 13, 25, 23);
	fillRECT(p_lut[114][2], -1, -1, -1, -1);	fillRECT(p_lut[114][3], -1, -1, -1, -1);
	fillRECT(p_lut[114][4], -1, -1, -1, -1);	fillRECT(p_lut[114][5], -1, -1, -1, -1);

	//s
	fillRECT(p_lut[115][0], 6, 9, 26, 19);	fillRECT(p_lut[115][1], 1, 14, 11, 29);
	fillRECT(p_lut[115][2], 1, 37, 23, 47);	fillRECT(p_lut[115][3], 20, 29, 30, 44);
	fillRECT(p_lut[115][4], 7, 25, 23, 33);	fillRECT(p_lut[115][5], -1, -1, -1, -1);

	//t
	fillRECT(p_lut[116][0], 11, 2, 21, 44);	fillRECT(p_lut[116][1], 5, 11, 27, 21);
	fillRECT(p_lut[116][2], 15, 35, 27, 47);	fillRECT(p_lut[116][3], -1, -1, -1, -1);
	fillRECT(p_lut[116][4], -1, -1, -1, -1);	fillRECT(p_lut[116][5], -1, -1, -1, -1);

	//u
	fillRECT(p_lut[117][0], 1, 13, 11, 43);	fillRECT(p_lut[117][1], 21, 13, 31, 43);
	fillRECT(p_lut[117][2], 7, 37, 25, 47);	fillRECT(p_lut[117][3], -1, -1, -1, -1);
	fillRECT(p_lut[117][4], -1, -1, -1, -1);	fillRECT(p_lut[117][5], -1, -1, -1, -1);

	//v
	fillRECT(p_lut[118][0], 2, 13, 12, 38);	fillRECT(p_lut[118][1], 20, 13, 30, 38);
	fillRECT(p_lut[118][2], 10, 31, 22, 47);	fillRECT(p_lut[118][3], -1, -1, -1, -1);
	fillRECT(p_lut[118][4], -1, -1, -1, -1);	fillRECT(p_lut[118][5], -1, -1, -1, -1);

	//w
	fillRECT(p_lut[119][0], 1, 13, 11, 41);	fillRECT(p_lut[119][1], 13, 25, 19, 42);
	fillRECT(p_lut[119][2], 21, 13, 31, 41);	fillRECT(p_lut[119][3], 6, 37, 14, 47);
	fillRECT(p_lut[119][4], 18, 37, 26, 47);	fillRECT(p_lut[119][5], -1, -1, -1, -1);

	//x
	fillRECT(p_lut[120][0], 11, 25, 21, 35);	fillRECT(p_lut[120][1], 2, 14, 13, 27);
	fillRECT(p_lut[120][2], 19, 14, 30, 27);	fillRECT(p_lut[120][3], 2, 31, 14, 47);
	fillRECT(p_lut[120][4], 18, 31, 30, 47);	fillRECT(p_lut[120][5], -1, -1, -1, -1);

	//y
	fillRECT(p_lut[121][0], 1, 14, 11, 42);	fillRECT(p_lut[121][1], 21, 14, 31, 57);
	fillRECT(p_lut[121][2], 6, 35, 24, 45);	fillRECT(p_lut[121][3], -1, -1, -1, -1);
	fillRECT(p_lut[121][4], -1, -1, -1, -1);	fillRECT(p_lut[121][5], -1, -1, -1, -1);

	//z
	fillRECT(p_lut[122][0], 3, 12, 29, 22);	fillRECT(p_lut[122][1], 3, 37, 29, 47);
	fillRECT(p_lut[122][2], 5, 29, 16, 37);	fillRECT(p_lut[122][3], 16, 22, 27, 29);
	fillRECT(p_lut[122][4], -1, -1, -1, -1);	fillRECT(p_lut[122][5], -1, -1, -1, -1);

	//{
	fillRECT(p_lut[123][0], 4, 9, 12, 39);	fillRECT(p_lut[123][1], 12, 1, 24, 9);
	fillRECT(p_lut[123][2], 12, 39, 24, 47);	fillRECT(p_lut[123][3], 0, 20, 8, 29);
	fillRECT(p_lut[123][4], -1, -1, -1, -1);	fillRECT(p_lut[123][5], -1, -1, -1, -1);

	//|
	fillRECT(p_lut[124][0], 12, 0, 20, 24);	fillRECT(p_lut[124][1], 12, 24, 20, 48);
	fillRECT(p_lut[124][2], -1, -1, -1, -1);	fillRECT(p_lut[124][3], -1, -1, -1, -1);
	fillRECT(p_lut[124][4], -1, -1, -1, -1);	fillRECT(p_lut[124][5], -1, -1, -1, -1);

	//}
	fillRECT(p_lut[125][0], 20, 9, 28, 39);	fillRECT(p_lut[125][1], 8, 1, 20, 9);
	fillRECT(p_lut[125][2], 8, 39, 20, 47);	fillRECT(p_lut[125][3], 24, 19, 32, 28);
	fillRECT(p_lut[125][4], 1, 1, 1, 1);	fillRECT(p_lut[125][5], -1, -1, -1, -1);

/*
	//!
	fillRECT(p_lut[33][0], 9, 1, 21, 31); fillRECT(p_lut[33][1], 9, 36, 21, 47);

	//&
	fillRECT(p_lut[38][0], 2, 5, 10, 41); fillRECT(p_lut[38][1], 22, 5, 30, 41);
	fillRECT(p_lut[38][2], 5, 1, 27, 8); fillRECT(p_lut[38][3], 6, 19, 26, 26);
	fillRECT(p_lut[38][4], 5, 37, 27, 44); fillRECT(p_lut[38][5], 13, 34, 20, 47);

	//+
	fillRECT(p_lut[43][0], 5, 20, 29, 30); fillRECT(p_lut[43][1], 11, 14, 23, 36);

	//,
	fillRECT(p_lut[44][0], 11, 32, 19, 47);

	//-
	fillRECT(p_lut[45][0], 4, 19, 27, 28);

	//.
	fillRECT(p_lut[46][0], 10, 35, 22, 47);

	//0
	fillRECT(p_lut[48][0], 1, 5, 10, 42); fillRECT(p_lut[48][1], 21, 5, 31, 42);
	fillRECT(p_lut[48][2], 5, 0, 28, 10); fillRECT(p_lut[48][3], 5, 37, 27, 47);
	fillRECT(p_lut[48][4], 13, 20, 18, 26);

	//1
	fillRECT(p_lut[49][0], 15, 2, 28, 36); fillRECT(p_lut[49][1], 7, 36, 31, 47);
	fillRECT(p_lut[49][2], 5, 7, 18, 18);

	//2
	fillRECT(p_lut[50][0], 2, 1, 29, 10); fillRECT(p_lut[50][1], 19, 4, 29, 21);
	fillRECT(p_lut[50][2], 4, 17, 27, 27); fillRECT(p_lut[50][3], 2, 21, 13, 43);
	fillRECT(p_lut[50][4], 6, 35, 29, 46);

	//3
	fillRECT(p_lut[51][0], 3, 1, 29, 10); fillRECT(p_lut[51][1], 19, 8, 31, 42);
	fillRECT(p_lut[51][2], 3, 37, 25, 47); fillRECT(p_lut[51][3], 10, 20, 24, 29);

	//4
	fillRECT(p_lut[52][0], 2, 1, 13, 27); fillRECT(p_lut[52][1], 5, 18, 31, 29);
	fillRECT(p_lut[52][2], 17, 9, 28, 47);

	//5
	fillRECT(p_lut[53][0], 3, 1, 30, 10); fillRECT(p_lut[53][1], 1, 5, 11, 24);
	fillRECT(p_lut[53][2], 5, 18, 29, 28); fillRECT(p_lut[53][3], 19, 23, 31, 44);
	fillRECT(p_lut[53][4], 2, 35, 27, 47);

	//6
	fillRECT(p_lut[54][0], 4, 1, 28, 9); fillRECT(p_lut[54][1], 2, 3, 12, 46);
	fillRECT(p_lut[54][2], 6, 36, 29, 47); fillRECT(p_lut[54][3], 8, 17, 28, 25);
	fillRECT(p_lut[54][4], 22, 22, 31, 41);

	//7
	fillRECT(p_lut[55][0], 2, 1, 30, 11); fillRECT(p_lut[55][1], 18, 11, 27, 21);
	fillRECT(p_lut[55][2], 8, 32, 17, 47); fillRECT(p_lut[55][3], 5, 21, 29, 32);

	//8
	fillRECT(p_lut[56][0], 1, 5, 10, 43); fillRECT(p_lut[56][1], 22, 5, 31, 43);
	fillRECT(p_lut[56][2], 5, 1, 26, 9); fillRECT(p_lut[56][3], 5, 39, 27, 47);
	fillRECT(p_lut[56][4], 7, 21, 26, 30);

	//9
	fillRECT(p_lut[57][0], 3, 1, 30, 10); fillRECT(p_lut[57][1], 0, 4, 9, 26);
	fillRECT(p_lut[57][2], 4, 38, 29, 47); fillRECT(p_lut[57][3], 20, 7, 31, 44);
	fillRECT(p_lut[57][4], 4, 19, 25, 29);

	//:
	fillRECT(p_lut[58][0], 10, 10, 22, 22); fillRECT(p_lut[58][1], 10, 29, 22, 41);

	//=
	fillRECT(p_lut[61][0], 5, 17, 27, 24); fillRECT(p_lut[61][1], 5, 28, 27, 35);

	//?
	fillRECT(p_lut[63][0], 18, 5, 27, 18); fillRECT(p_lut[63][1], 4, 1, 24, 9);
	fillRECT(p_lut[63][2], 9, 14, 21, 28); fillRECT(p_lut[63][3], 10, 36, 20, 46);

	//A
	fillRECT(p_lut[65][0], 1, 5, 12, 46); fillRECT(p_lut[65][1], 19, 5, 30, 46);
	fillRECT(p_lut[65][2], 4, 1, 28, 12); fillRECT(p_lut[65][3], 6, 23, 27, 32);

	//B
	fillRECT(p_lut[66][0], 1, 1, 29, 11); fillRECT(p_lut[66][1], 1, 36, 29, 47);
	fillRECT(p_lut[66][2], 4, 11, 14, 36); fillRECT(p_lut[66][3], 22, 10, 31, 21);
	fillRECT(p_lut[66][4], 20, 27, 31, 40); fillRECT(p_lut[66][5], 11, 20, 25, 29);

	//C
	fillRECT(p_lut[67][0], 1, 6, 13, 41); fillRECT(p_lut[67][1], 6, 1, 30, 13);
	fillRECT(p_lut[67][2], 7, 35, 30, 47);

	//D
	fillRECT(p_lut[68][0], 2, 11, 13, 33); fillRECT(p_lut[68][1], 1, 1, 27, 11);
	fillRECT(p_lut[68][2], 1, 33, 27, 46); fillRECT(p_lut[68][3], 20, 10, 31, 37);

	//E
	fillRECT(p_lut[69][0], 3, 11, 16, 36); fillRECT(p_lut[69][1], 1, 1, 29, 11);
	fillRECT(p_lut[69][2], 1, 36, 30, 46); fillRECT(p_lut[69][3], 10, 19, 26, 29);

	//F
	fillRECT(p_lut[70][0], 3, 13, 15, 45); fillRECT(p_lut[70][1], 1, 1, 30, 13);
	fillRECT(p_lut[70][2], 9, 21, 27, 31);

	//G
	fillRECT(p_lut[71][0], 1, 5, 12, 45); fillRECT(p_lut[71][1], 6, 34, 29, 47);
	fillRECT(p_lut[71][2], 3, 2, 29, 11); fillRECT(p_lut[71][3], 20, 24, 31, 40);

	//H
	fillRECT(p_lut[72][0], 1, 2, 11, 46); fillRECT(p_lut[72][1], 21, 2, 31, 46);
	fillRECT(p_lut[72][2], 5, 19, 27, 28);

	//I
	fillRECT(p_lut[73][0], 9, 10, 21, 37); fillRECT(p_lut[73][1], 6, 2, 24, 10);
	fillRECT(p_lut[73][2], 6, 37, 24, 47);

	//J
	fillRECT(p_lut[74][0], 11, 2, 29, 13); fillRECT(p_lut[74][1], 15, 13, 26, 42);
	fillRECT(p_lut[74][2], 2, 33, 11, 43); fillRECT(p_lut[74][3], 7, 38, 24, 47);

	//K
	fillRECT(p_lut[75][0], 3, 3, 14, 45); fillRECT(p_lut[75][1], 10, 20, 21, 30);
	fillRECT(p_lut[75][2], 20, 3, 28, 20); fillRECT(p_lut[75][3], 20, 30, 28, 45);

	//L
	fillRECT(p_lut[76][0], 2, 2, 14, 43); fillRECT(p_lut[76][1], 4, 35, 30, 47);

	//M
	fillRECT(p_lut[77][0], 1, 11, 10, 46); fillRECT(p_lut[77][1], 22, 11, 31, 46);
	fillRECT(p_lut[77][2], 12, 12, 20, 26); fillRECT(p_lut[77][3], 4, 2, 15, 18);
	fillRECT(p_lut[77][4], 18, 2, 28, 19);

	//N
	fillRECT(p_lut[78][0], 1, 2, 11, 46); fillRECT(p_lut[78][1], 22, 2, 31, 46);
	fillRECT(p_lut[78][2], 7, 6, 16, 25); fillRECT(p_lut[78][3], 16, 25, 24, 43);

	//O
	fillRECT(p_lut[79][0], 1, 5, 12, 45); fillRECT(p_lut[79][1], 21, 5, 31, 45);
	fillRECT(p_lut[79][2], 5, 1, 27, 13); fillRECT(p_lut[79][3], 6, 34, 27, 47);

	//P
	fillRECT(p_lut[80][0], 2, 4, 12, 46); fillRECT(p_lut[80][1], 4, 2, 27, 12);
	fillRECT(p_lut[80][2], 7, 23, 27, 32); fillRECT(p_lut[80][3], 18, 10, 29, 26);

	//Q
	fillRECT(p_lut[81][0], 1, 8, 10, 39); fillRECT(p_lut[81][1], 23, 8, 31, 39);
	fillRECT(p_lut[81][2], 7, 2, 27, 13); fillRECT(p_lut[81][3], 6, 34, 28, 45);
	fillRECT(p_lut[81][4], 13, 30, 20, 47);

	//R
	fillRECT(p_lut[82][0], 2, 11, 12, 46); fillRECT(p_lut[82][1], 1, 2, 27, 11);
	fillRECT(p_lut[82][2], 23, 7, 31, 23); fillRECT(p_lut[82][3], 9, 18, 25, 26);
	fillRECT(p_lut[82][4], 12, 26, 20, 34); fillRECT(p_lut[82][5], 20, 34, 31, 46);

	//S
	fillRECT(p_lut[83][0], 2, 1, 30, 11); fillRECT(p_lut[83][1], 1, 4, 12, 24);
	fillRECT(p_lut[83][2], 1, 35, 24, 47); fillRECT(p_lut[83][3], 20, 23, 31, 45);
	fillRECT(p_lut[83][4], 6, 18, 29, 30);

	//T
	fillRECT(p_lut[84][0], 1, 2, 31, 12); fillRECT(p_lut[84][1], 10, 12, 21, 46);

	//U
	fillRECT(p_lut[85][0], 1, 3, 12, 40); fillRECT(p_lut[85][1], 20, 3, 30, 40);
	fillRECT(p_lut[85][2], 5, 35, 26, 47);

	//V
	fillRECT(p_lut[86][0], 1, 2, 11, 36); fillRECT(p_lut[86][1], 22, 2, 31, 36);
	fillRECT(p_lut[86][2], 9, 34, 24, 47);
	
	//W
	fillRECT(p_lut[87][0], 1, 1, 10, 39); fillRECT(p_lut[87][1], 23, 1, 31, 40);
	fillRECT(p_lut[87][2], 13, 22, 21, 42); fillRECT(p_lut[87][3], 4, 37, 15, 47);
	fillRECT(p_lut[87][4], 19, 37, 29, 47);
	
	//X
	fillRECT(p_lut[88][0], 10, 16, 24, 29); fillRECT(p_lut[88][1], 1, 1, 13, 19);
	fillRECT(p_lut[88][2], 20, 1, 31, 20); fillRECT(p_lut[88][3], 2, 25, 14, 47);
	fillRECT(p_lut[88][4], 19, 25, 31, 47);
	
	//Y
	fillRECT(p_lut[89][0], 6, 18, 26, 26); fillRECT(p_lut[89][1], 2, 2, 13, 23);
	fillRECT(p_lut[89][2], 21, 2, 31, 24); fillRECT(p_lut[89][3], 12, 26, 23, 47);
	
	//Z
	fillRECT(p_lut[90][0], 2, 1, 30, 11); fillRECT(p_lut[90][1], 18, 11, 29, 24);
	fillRECT(p_lut[90][2], 4, 24, 17, 36); fillRECT(p_lut[90][3], 2, 36, 31, 47);

	//_
	fillRECT(p_lut[95][0], 2, 40, 29, 47);

	//a
	fillRECT(p_lut[97][0], 3, 13, 28, 22); fillRECT(p_lut[97][1], 3, 38, 28, 47);
	fillRECT(p_lut[97][2], 21, 17, 31, 42); fillRECT(p_lut[97][3], 1, 30, 10, 43);
	fillRECT(p_lut[97][4], 4, 26, 24, 33);

	//b
	fillRECT(p_lut[98][0], 2, 2, 10, 43); fillRECT(p_lut[98][1], 21, 22, 31, 41);
	fillRECT(p_lut[98][2], 7, 16, 26, 25); fillRECT(p_lut[98][3], 6, 37, 26, 47);

	//c
	fillRECT(p_lut[99][0], 2, 16, 12, 43); fillRECT(p_lut[99][1], 6, 13, 28, 23);
	fillRECT(p_lut[99][2], 6, 36, 28, 47);

	//d
	fillRECT(p_lut[100][0], 21, 1, 30, 43); fillRECT(p_lut[100][1], 4, 38, 27, 47);
	fillRECT(p_lut[100][2], 4, 18, 26, 28); fillRECT(p_lut[100][3], 1, 22, 11, 42);

	//e
	fillRECT(p_lut[101][0], 1, 18, 10, 42); fillRECT(p_lut[101][1], 24, 18, 31, 29);
	fillRECT(p_lut[101][2], 4, 13, 28, 22); fillRECT(p_lut[101][3], 6, 26, 26, 33);
	fillRECT(p_lut[101][4], 5, 37, 29, 47);

	//f
	fillRECT(p_lut[102][0], 11, 2, 25, 10); fillRECT(p_lut[102][1], 11, 10, 19, 47);
	fillRECT(p_lut[102][2], 6, 15, 24, 23);

	//g
	fillRECT(p_lut[103][0], 4, 14, 26, 22); fillRECT(p_lut[103][1], 1, 17, 9, 40);
	fillRECT(p_lut[103][2], 21, 17, 30, 54); fillRECT(p_lut[103][3], 5, 35, 20, 44);
	fillRECT(p_lut[103][4], 1, 48, 27, 57);

	//h
	fillRECT(p_lut[104][0], 2, 1, 10, 47); fillRECT(p_lut[104][1], 6, 15, 28, 23);
	fillRECT(p_lut[104][2], 20, 19, 28, 47);

	//i
	fillRECT(p_lut[105][0], 10, 16, 20, 47); fillRECT(p_lut[105][1], 10, 2, 20, 11);

	//j
	fillRECT(p_lut[106][0], 11, 1, 22, 11); fillRECT(p_lut[106][1], 11, 14, 22, 53);
	fillRECT(p_lut[106][2], 5, 47, 18, 57);

	//k
	fillRECT(p_lut[107][0], 2, 1, 10, 47); fillRECT(p_lut[107][1], 9, 25, 19, 33);
	fillRECT(p_lut[107][2], 18, 13, 28, 27); fillRECT(p_lut[107][3], 18, 31, 30, 47);

	//l
	fillRECT(p_lut[108][0], 10, 2, 20, 47); fillRECT(p_lut[108][1], 15, 35, 28, 47);

	//m
	fillRECT(p_lut[109][0], 1, 13, 10, 47); fillRECT(p_lut[109][1], 21, 18, 31, 47);
	fillRECT(p_lut[109][2], 12, 22, 19, 34); fillRECT(p_lut[109][3], 5, 16, 15, 26);
	fillRECT(p_lut[109][4], 17, 16, 28, 27);

	//n
	fillRECT(p_lut[110][0], 2, 12, 12, 47); fillRECT(p_lut[110][1], 22, 20, 31, 47);
	fillRECT(p_lut[110][2], 9, 16, 27, 26);

	//o
	fillRECT(p_lut[111][0], 2, 17, 10, 41); fillRECT(p_lut[111][1], 23, 17, 31, 41);
	fillRECT(p_lut[111][2], 6, 13, 27, 21); fillRECT(p_lut[111][3], 6, 38, 27, 47);

	//p
	fillRECT(p_lut[112][0], 2, 15, 11, 57); fillRECT(p_lut[112][1], 23, 18, 31, 39);
	fillRECT(p_lut[112][2], 6, 12, 28, 22); fillRECT(p_lut[112][3], 8, 35, 27, 45);

	//q
	fillRECT(p_lut[113][0], 22, 16, 30, 57); fillRECT(p_lut[113][1], 2, 17, 10, 43);
	fillRECT(p_lut[113][2], 5, 13, 27, 24); fillRECT(p_lut[113][3], 6, 37, 27, 47);

	//r
	fillRECT(p_lut[114][0], 4, 13, 14, 47); fillRECT(p_lut[114][1], 11, 16, 25, 27);

	//s
	fillRECT(p_lut[115][0], 5, 11, 25, 20); fillRECT(p_lut[115][1], 2, 14, 11, 29);
	fillRECT(p_lut[115][2], 3, 38, 25, 47); fillRECT(p_lut[115][3], 20, 28, 28, 43);
	fillRECT(p_lut[115][4], 6, 25, 24, 33);

	//t
	fillRECT(p_lut[116][0], 11, 2, 21, 47); fillRECT(p_lut[116][1], 5, 11, 27, 20);
	fillRECT(p_lut[116][2], 16, 39, 26, 47);

	//u
	fillRECT(p_lut[117][0], 2, 13, 12, 42); fillRECT(p_lut[117][1], 21, 13, 31, 43);
	fillRECT(p_lut[117][2], 6, 34, 27, 47);

	//v
	fillRECT(p_lut[118][0], 3, 13, 13, 38); fillRECT(p_lut[118][1], 20, 13, 29, 38);
	fillRECT(p_lut[118][2], 10, 31, 22, 47);

	//w
	fillRECT(p_lut[119][0], 1, 13, 10, 41); fillRECT(p_lut[119][1], 13, 25, 19, 42);
	fillRECT(p_lut[119][2], 22, 13, 31, 41); fillRECT(p_lut[119][3], 6, 37, 14, 47);
	fillRECT(p_lut[119][4], 18, 37, 25, 47);

	//x
	fillRECT(p_lut[120][0], 11, 24, 22, 35); fillRECT(p_lut[120][1], 3, 14, 13, 27);
	fillRECT(p_lut[120][2], 19, 14, 30, 27); fillRECT(p_lut[120][3], 3, 31, 14, 47);
	fillRECT(p_lut[120][4], 18, 31, 30, 47);

	//y
	fillRECT(p_lut[121][0], 2, 13, 13, 40); fillRECT(p_lut[121][1], 21, 13, 31, 57);
	fillRECT(p_lut[121][2], 7, 32, 26, 45);

	//z
	fillRECT(p_lut[122][0], 2, 12, 29, 21); fillRECT(p_lut[122][1], 2, 38, 29, 47);
	fillRECT(p_lut[122][2], 6, 29, 17, 38); fillRECT(p_lut[122][3], 17, 21, 27, 29);*/

	return p_lut;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typefont
//
//	draws wordstring using bitmap or scanline font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typefont(int x,							//x-coordinate
						  int y,							//y-coordinate
						  char string[101],					//string to display
						  double number,					//or number to display
						  int precision,					//after decimal point, 5 default
						  int type,							//0 = bitmap, 1 = scanline
						  float sizefactor,					//size
						  int bred, int bgreen, int bblue,	//border color
						  int fred, int fgreen, int fblue)	//fill color
															//bred -1 for bitmap black, else white
															//bred -1 and scanline: unfilled
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(typefont_16(x, y, string, number, precision, type, sizefactor,
						   bred, bgreen, bblue,
						   fred, fgreen, fblue));
	else
		return(typefont_32(x, y, string, number, precision, type, sizefactor,
						   bred, bgreen, bblue,
						   fred, fgreen, fblue));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typeSLF
//
//	draws wordstring using scanline font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typeSLF(int x, int y,
						 int bred, int bgreen, int bblue,
						 int fred, int fgreen, int fblue,
						 float sizefactor,
						 char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- auto backbuffer lock version ----------------------------------------------------------

	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(typeSLF_16(x, y,
						  bred, bgreen, bblue,
						  fred, fgreen, fblue,
						  sizefactor,
						  (char*)wordstring));
	else
		return(typeSLF_32(x, y,
						  bred, bgreen, bblue,
						  fred, fgreen, fblue,
						  sizefactor,
						  (char*)wordstring));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typeSLF_ML
//
//	draws wordstring using scanline font, manual lock version
//
//------------------------------------------------------------------------------------------------

bool directdraw::typeSLF_ML(int x, int y,
							int bred, int bgreen, int bblue,
							int fred, int fgreen, int fblue,
							float sizefactor,
							char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- manuel backbuffer lock version ---------------------------------------------------------

	//call 16bit or 32bit color mode function
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(typeSLF_16_ML(x, y,
							 bred, bgreen, bblue,
							 fred, fgreen, fblue,
							 sizefactor,
							 (char*)wordstring));
	else
		return(typeSLF_32_ML(x, y,
							 bred, bgreen, bblue,
							 fred, fgreen, fblue,
							 sizefactor,
							 (char*)wordstring));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typebmf
//
//	draw unscaled bitmap font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typebmf(int x, int y,
						 int color,
						 char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- bitmap font ---------------------------------------------------------------------------

	//no scaling yet
	float sizefactor = 1.0f;

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;
	tempdest.left = x;	tempdest.top = y;

	//verify color
	if (color < 0)			color	= 0;
	if (color > bmfMAX)		color	= bmfMAX;

	//for every letter while not null (end of string)
	for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//set right and bottom members of tempdest
		tempdest.right = tempdest.left + (long)(8 * sizefactor);
		tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

		//assign RECTS to temp RECTS so the originals don't get clipped
		//(especially the LUT)
		cdest	= tempdest;

		//offscreen surface offset depending on color
		csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[color].x;
		csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[color].y;
		csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[color].x;
		csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[color].y;

		//if clipper returns true which means dest RECT is within screen (and clipped),
		//blit letter
		if (clipper(rSCREEN, csource, cdest))
			lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
						   lpDDSOff,					//dd surface which is source of blit
						   &csource,					//source rect, NULL for entire surface
						   DDBLT_KEYSRC,				//flags
						   NULL);						//address of DDBLTFX structure
//			else
			//if letter completely out of screen
			//- and so every following - end loop
			//!! wrongo --> not true for left screen side, following letters may be within screen
//				i = 101;

		//set new tempdest left
		tempdest.left += (long)(8 * sizefactor);
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typebmf
//
//	draw unscaled bitmap font
//	draws additional rectangle background
//
//------------------------------------------------------------------------------------------------

bool directdraw::typebmf(int x, int y,
						 int color,
						 RGBcolor background,
						 char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- bitmap font ---------------------------------------------------------------------------

	//no scaling yet
	float sizefactor = 1.0f;

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;
	tempdest.left = x;	tempdest.top = y;

	//verify color
	if (color < 0)			color	= 0;
	if (color > bmfMAX)		color	= bmfMAX;

	//draw background
	for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
		i;
	RECT	r, s;
	fillRECT(r, x, y, x + i * 8, y + 16);
	//clip
	if (clipper(rSCREEN, s, r))
		colorfill(r, background);
	else
		//not visible on screen
		return(false);

	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//set right and bottom members of tempdest
		tempdest.right = tempdest.left + (long)(8 * sizefactor);
		tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

		//assign RECTS to temp RECTS so the originals don't get clipped
		//(especially the LUT)
		cdest	= tempdest;

		//offscreen surface offset depending on color
		csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[color].x;
		csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[color].y;
		csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[color].x;
		csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[color].y;

		//if clipper returns true which means dest RECT is within screen (and clipped),
		//blit letter
		if (clipper(rSCREEN, csource, cdest))
			lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
						   lpDDSOff,					//dd surface which is source of blit
						   &csource,					//source rect, NULL for entire surface
						   DDBLT_KEYSRC,				//flags
						   NULL);						//address of DDBLTFX structure
//			else
			//if letter completely out of screen
			//- and so every following - end loop
			//!! wrongo --> not true for left screen side, following letters may be within screen
//				i = 101;

		//set new tempdest left
		tempdest.left += (long)(8 * sizefactor);
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typebmf
//
//	draw scaled bitmap font
//
//------------------------------------------------------------------------------------------------

bool directdraw::typebmf(int x, int y,
						 int color,
						 float sizefactor,
						 char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- bitmap font ---------------------------------------------------------------------------

	//verify scale
	if (sizefactor <= 0)
		return(true);

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;
	tempdest.left = x;	tempdest.top = y;

	//verify color
	if (color < 0)			color	= 0;
	if (color > bmfMAX)		color	= bmfMAX;

	//for every letter while not null (end of string)
	for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//set right and bottom members of tempdest
		tempdest.right = tempdest.left + (long)(8 * sizefactor);
		tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

		//assign RECTS to temp RECTS so the originals don't get clipped
		//(especially the LUT)
		cdest	= tempdest;

		//offscreen surface offset depending on color
		csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[color].x;
		csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[color].y;
		csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[color].x;
		csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[color].y;

		//if clipper returns true which means dest RECT is within screen (and clipped),
		//blit letter
		if (clipper(rSCREEN, csource, cdest))
			lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
						   lpDDSOff,					//dd surface which is source of blit
						   &csource,					//source rect, NULL for entire surface
						   DDBLT_KEYSRC,				//flags
						   NULL);						//address of DDBLTFX structure
//			else
			//if letter completely out of screen
			//- and so every following - end loop
			//!! wrongo --> not true for left screen side, following letters may be within screen
//				i = 101;

		//set new tempdest left
		tempdest.left += (long)(8 * sizefactor);
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw typebmf
//
//	draw scaled bitmap font
//	draws additional rectangle background
//
//------------------------------------------------------------------------------------------------

bool directdraw::typebmf(int x, int y,
						 int color,
						 RGBcolor background,
						 float sizefactor,
						 char *format, ...)
{
	//verify
	if (format == NULL)
		format = "NULLSTRING";

	//---- copy string or number into new buffer -------------------------------------------------

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
	//unsigned, else you get negativ values for the LUT
	unsigned char wordstring[101] = "";
	//copy message into buffer
	vsprintf((char *)wordstring, format, ap);

	//clear up
	va_end(ap);

	//---- bitmap font ---------------------------------------------------------------------------

	//verify scale
	if (sizefactor <= 0)
		return(true);

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;
	tempdest.left = x;	tempdest.top = y;

	//verify color
	if (color < 0)			color	= 0;
	if (color > bmfMAX)		color	= bmfMAX;

	//draw background
	for (register int i = 0; i < 101 && wordstring[i] != 0; ++i)
		i;
	RECT	r, s;
	fillRECT(r, x, y, x + i * (int)(8.0f * sizefactor), y + (int)(16.0f * sizefactor));
	//clip
	if (clipper(rSCREEN, s, r))
		colorfill(r, background);
	else
		//not visible on screen
		return(false);

	//for every letter while not null (end of string)
	for (i = 0; i < 101 && wordstring[i] != 0; ++i)
	{
		//set right and bottom members of tempdest
		tempdest.right = tempdest.left + (long)(8 * sizefactor);
		tempdest.bottom = tempdest.top + (long)(16 * sizefactor);

		//assign RECTS to temp RECTS so the originals don't get clipped
		//(especially the LUT)
		cdest	= tempdest;

		//offscreen surface offset depending on color
		csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[color].x;
		csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[color].y;
		csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[color].x;
		csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[color].y;

		//if clipper returns true which means dest RECT is within screen (and clipped),
		//blit letter
		if (clipper(rSCREEN, csource, cdest))
			lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
						   lpDDSOff,					//dd surface which is source of blit
						   &csource,					//source rect, NULL for entire surface
						   DDBLT_KEYSRC,				//flags
						   NULL);						//address of DDBLTFX structure
//			else
			//if letter completely out of screen
			//- and so every following - end loop
			//!! wrongo --> not true for left screen side, following letters may be within screen
//				i = 101;

		//set new tempdest left
		tempdest.left += (long)(8 * sizefactor);
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw font_pfx
//
//	locks offscreen surface and reads each letter of a string
//	off the surface according to the look up table and the appropriate
//	RECT, scanning each letter for its pixels and assigning the
//	offset position as particle origin
//	returns pointer to partical array
//
//------------------------------------------------------------------------------------------------

particle *directdraw::font_pfx(char string[101],			//fx-string
							   int &size,					//size of array as reference
															//so that pa_heap knows its size
							   int x, int y)				//offset coordinates
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(font_pfx_16(string, size, x, y));
	else
		return(font_pfx_32(string, size, x, y));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawpoint
//
//	draws a single point with specified color (black by default) given by value
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawpoint(point p, RGBcolor c, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawpoint_16(p, c, ml));
	else
		return(drawpoint_32(p, c, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawline
//
//	draws a single line with specified color (black by default) given by value
//	uses bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawline(line l, RGBcolor c)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawline_16(l, c));
	else
		return(drawline_32(l, c));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawline
//
//	draws a single line with specified color (black by default) given by value
//	uses bresenhams line algorithm
//	manual lock
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawline_ML(line l, RGBcolor c)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawline_16_ML(l, c));
	else
		return(drawline_32_ML(l, c));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawcircle
//
//	draws a single circle with specified color (black by default)
//	useing bresenhams circle algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawcircle(int cx, int cy, int radius, RGBcolor c, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawcircle_16(cx, cy, radius, c, ml));
	else
		return(drawcircle_32(cx, cy, radius, c, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawcircle_array
//
//	draws several unfilled circles with specified bordercolor given by argument
//	using bresenhams circle algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawcircle_array(circle c[], int elements, RGBcolor bc)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawcircle_array_16(c, elements, bc));
	else
		return(drawcircle_array_32(c, elements, bc));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_uf
//
//	draws a single unfilled rectangle with specified bordercolor given by value
//	using bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_uf(rectangle r, RGBcolor bc, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawrectangle_uf_16(r, bc, ml));
	else
		return(drawrectangle_uf_32(r, bc, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_array
//
//	draws several unfilled rectangle with specified bordercolor given by value
//	using bresenhams line algorithm
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_array(rectangle r[], int elements, RGBcolor bc)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawrectangle_array_16(r, elements, bc));
	else
		return(drawrectangle_array_32(r, elements, bc));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_f
//
//	draws a single filled rectangle without border
//	using polygon scanline algorithm to fill it
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_f(rectangle r, RGBcolor fc, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawrectangle_f_16(r, fc, ml));
	else
		return(drawrectangle_f_32(r, fc, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawrectangle_bf
//
//	draws a single filled rectangle with specified colored border
//	using bresenhams line algorithm and polygon scanline algorithm to fill it
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawrectangle_bf(rectangle r, RGBcolor bc, RGBcolor fc, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawrectangle_bf_16(r, bc, fc, ml));
	else
		return(drawrectangle_bf_32(r, bc, fc, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawplayers
//
//	draws both players with or without shadows in correct z-order
//	blackwhite mode colorflag as argument
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawplayers(player_data *pd, int shadows, int bwmode, float s_zoom)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawplayers_16(pd, shadows, bwmode, s_zoom));
	else
		return(drawplayers_32(pd, shadows, bwmode, s_zoom));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawscene
//
//	draws whole scene in one lock
//	including both players with or without shadows in correct z-order and color mode (blackwhite)
//	winning points and names for both players
//	and blood particle arrays if active (same z-order as head)
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawscene(player_data *pd,
						   int mode_lutf,
						   int mode_lutd,
						   RGBcolor boneborder,
						   int bias_r,
						   int bias_g,
						   int bias_b)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawscene_16(pd, mode_lutf, mode_lutd, boneborder, bias_r, bias_g, bias_b));
	else
		return(drawscene_32(pd, mode_lutf, mode_lutd, boneborder, bias_r, bias_g, bias_b));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawfist
//
//	draws fist with appropriate color for option menu
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawfist(int x, int y, RGBcolor fc, int ml)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawfist_16(x, y, fc, ml));
	else
		return(drawfist_32(x, y, fc, ml));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawyinyang
//
//	draws yin yang symbol using bresenham and scanline alogrithm
//
//------------------------------------------------------------------------------------------------

//void directdraw::drawyinyang(yinyang yy, RGBcolor cyin, RGBcolor cyang, int ml)
void directdraw::drawyinyang(yinyang &yy, int ml)
{
	//auto lock
	if (!ml)
	{
		//lock backbuffer
		if (!BBLock())
			return;
	}

	//calculate yinyang symbol with its current data
	yy.calculate();

	//draw both flicker patches
	drawrectangle_f(yy.r[7], yy.ycya, 1);
	drawrectangle_f(yy.r[8], yy.ycyi, 1);

	//draw small and big parts of yin and yang
	drawrectangle_f(yy.r[0], yy.ycya, 1);
	drawrectangle_f(yy.r[1], yy.ycya, 1);
	drawrectangle_f(yy.r[2], yy.ycyi, 1);
	drawrectangle_f(yy.r[3], yy.ycyi, 1);

	//draw both eyes
	drawrectangle_bf(yy.r[4], yy.ycborder, yy.ycya, 1);
	drawrectangle_bf(yy.r[5], yy.ycborder, yy.ycyi, 1);

	//draw outer border
	drawrectangle_uf(yy.r[6], yy.ycborder, 1);

	//draw both L lines
	for (register int i = 0; i < 4; ++i)
		drawline_ML(yy.l[i], yy.ycborder);

	//unlock backbuffer
	if (!ml)
		BBUnlock();
}

//------------------------------------------------------------------------------------------------
//
//	directdraw bordermove
//
//	moves 16:9 borders smoothly in (1) or out of (0) screen
//	either from above/below (0) or left/right (1)
//
//------------------------------------------------------------------------------------------------

void directdraw::bordermove(int mode_io, int mode_s, int mode_t,
							float time, int bgr, int bgg, int bgb, int type)
{
	//check time for validity
	time < 0.1f ? time = 0.1f : time;

	//start time
	LONGLONG t_start;

	//set start time
	t_start = p_time->current;

	//time in seconds passed since start of bordermove
	double t_pass = (p_time->current - t_start) / (double)p_time->freq;

	//static and moving borders (one background, other border itself)
	RECT b_upper, b_lower, b_mupper, b_mlower;

	//color of border (black by default), color of background (white)
	RGBcolor	bc(BORDERCOLOR);
	RGBcolor	bgc(bgr, bgg, bgb);

	//if borders to move out
	if (mode_io == 0)
	{
		//if borders to move from above/below)
		if (mode_s == 0)
		{
			//if only small borders
			if (mode_t == 0)
			{
				//set static and moving borders to "in" position
				fillRECT(b_upper, 0, 0, 800, 75);	fillRECT(b_lower, 0, 525, 800, 600);
				b_mupper = b_upper;					b_mlower = b_lower;

				//while time passed since start is <= than time of move
				while (t_start + (p_time->freq * time) >= p_time->current)
				{
					//increase, decrease y-values of moving boarders
					fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom - 75 / time * t_pass));
					fillRECT(b_mlower, 0, (int)(b_lower.top + 75 / time * t_pass), 800, 600);

					//fill area of upper border with background color
					colorfill(b_upper, bgc);
					//fill area of upper border with border
					colorfill(b_mupper, bc);

					//same with lower area
					colorfill(b_lower, bgc);
					colorfill(b_mlower, bc);

					//show change
					flip(1);

					//update p_time->current and t_pass
					QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
					t_pass = (p_time->current - t_start) / (double)p_time->freq;
				}
			}
			else
			//full screen borders
			{
				//to empty screen
				if (mode_t == 1)
				{
					//set static and moving borders to "in" position
					fillRECT(b_upper, 0, 0, 800, 300);	fillRECT(b_lower, 0, 300, 800, 600);
					b_mupper = b_upper;					b_mlower = b_lower;

					//while time passed since start is <= than time of move
					while (t_start + (p_time->freq * time) >= p_time->current)
					{
						//increase, decrease y-values of moving boarders
						fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom - 300 / time * t_pass));
						fillRECT(b_mlower, 0, (int)(b_lower.top + 300 / time * t_pass), 800, 600);

						//fill area of upper border with background color
						colorfill(b_upper, bgc);
						//fill area of upper border with border
						colorfill(b_mupper, bc);

						//same with lower area
						colorfill(b_lower, bgc);
						colorfill(b_mlower, bc);

						//show change
						flip(1);

						//update p_time->current and t_pass
						QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
						t_pass = (p_time->current - t_start) / (double)p_time->freq;
					}
				}
				//to small borders
				if (mode_t == 2)
				{
					//set static and moving borders to "in" position
					fillRECT(b_upper, 0, 0, 800, 300);	fillRECT(b_lower, 0, 300, 800, 600);
					b_mupper = b_upper;					b_mlower = b_lower;

					//while time passed since start is <= than time of move
					while (t_start + (p_time->freq * time) >= p_time->current)
					{
						//increase, decrease y-values of moving boarders
						fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom - 225 / time * t_pass));
						fillRECT(b_mlower, 0, (int)(b_lower.top + 225 / time * t_pass), 800, 600);

						//fill area of upper border with background color
						colorfill(b_upper, bgc);
						//fill area of upper border with border
						colorfill(b_mupper, bc);

						//same with lower area
						colorfill(b_lower, bgc);
						colorfill(b_mlower, bc);

						//show change
						flip(1);

						//update p_time->current and t_pass
						QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
						t_pass = (p_time->current - t_start) / (double)p_time->freq;
					}
				}
			}
		}
		else
		//if borders to move from left/right
		{
			//set static and moving borders to "in" position
			fillRECT(b_upper, 0, 0, 800, 75);	fillRECT(b_lower, 0, 525, 800, 600);
			b_mupper = b_upper;					b_mlower = b_lower;

			//while time passed since start is <= than time of move
			while (t_start + (p_time->freq * time) >= p_time->current)
			{
				//increase, decrease x-values of moving boarders
				fillRECT(b_mupper, (int)(b_upper.left + 800 / time * t_pass), 0, 800, 75);
				fillRECT(b_mlower, 0, 525, (int)(b_lower.right - 800 / time * t_pass), 600);

				//fill area of upper border with background color
				colorfill(b_upper, bgc);
				//fill area of upper border with border
				colorfill(b_mupper, bc);

				//same with lower area
				colorfill(b_lower, bgc);
				colorfill(b_mlower, bc);

				//show change
				flip(1);

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;
			}
		}
	}
	else
	//if borders to move in
	{
		//if borders to move from above/below
		if (mode_s == 0)
		{
			//if small borders
			if (mode_t == 0)
			{
				//set static and moving borders to "out" position
				fillRECT(b_upper, 0, 0, 800, 0);	fillRECT(b_lower, 0, 600, 800, 600);
				b_mupper = b_upper;					b_mlower = b_lower;

				//while time passed since start is <= than time of move
				while (t_start + (p_time->freq * time) >= p_time->current)
				{
					//increase, decrease y-values of moving boarders
					fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom + 75 / time * t_pass));
					fillRECT(b_mlower, 0, (int)(b_lower.top - 75 / time * t_pass), 800, 600);

					//fill area of upper border with border
					colorfill(b_mupper, bc);
					//same with lower area
					colorfill(b_mlower, bc);

					//show change
					flip(1);

					//update p_time->current and t_pass
					QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
					t_pass = (p_time->current - t_start) / (double)p_time->freq;
				}
			}
			else
			//full screen borders
			{
				//from empty screen
				if (mode_t == 1)
				{
					//set static and moving borders to "out" position
					fillRECT(b_upper, 0, 0, 800, 0);	fillRECT(b_lower, 0, 600, 800, 600);
					b_mupper = b_upper;					b_mlower = b_lower;

					//while time passed since start is <= than time of move
					while (t_start + (p_time->freq * time) >= p_time->current)
					{
						//increase, decrease y-values of moving boarders
						fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom + 300 / time * t_pass));
						fillRECT(b_mlower, 0, (int)(b_lower.top - 300 / time * t_pass), 800, 600);

						//fill area of upper border with border
						colorfill(b_mupper, bc);
						//same with lower area
						colorfill(b_mlower, bc);

						//show change
						flip(1);

						//update p_time->current and t_pass
						QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
						t_pass = (p_time->current - t_start) / (double)p_time->freq;
					}
				}
				//from small borders
				if (mode_t == 2)
				{
					//set static and moving borders to small borders
					fillRECT(b_upper, 0, 0, 800, 75);	fillRECT(b_lower, 0, 525, 800, 600);
					b_mupper = b_upper;					b_mlower = b_lower;

					//while time passed since start is <= than time of move
					while (t_start + (p_time->freq * time) >= p_time->current)
					{
						//increase, decrease y-values of moving boarders
						fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom + 225 / time * t_pass));
						fillRECT(b_mlower, 0, (int)(b_lower.top - 225 / time * t_pass), 800, 600);

						//fill area of upper border with border
						colorfill(b_mupper, bc);
						//same with lower area
						colorfill(b_mlower, bc);

						//show change
						flip(1);

						//update p_time->current and t_pass
						QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
						t_pass = (p_time->current - t_start) / (double)p_time->freq;
					}
				}
			}
		}
		else
		//if borders to move from left/right
		{
			//set static and moving borders to "out" position
			fillRECT(b_upper, 800, 0, 800, 75);	fillRECT(b_lower, 0, 525, 0, 600);
			b_mupper = b_upper;					b_mlower = b_lower;

			//while time passed since start is <= than time of move
			while (t_start + (p_time->freq * time) >= p_time->current)
			{
				//increase, decrease x-values of moving boarders
				fillRECT(b_mupper, (int)(b_upper.right - 800 / time * t_pass), 0, 800, 75);
				fillRECT(b_mlower, 0, 525, (int)(b_lower.left + 800 / time * t_pass), 600);

				//fill area of upper border with border
				colorfill(b_mupper, bc);
				//same with lower area
				colorfill(b_mlower, bc);

				//show change
				flip(1);

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;
			}
		}
	}

	//!!
	//redraw whole borders because sometimes they don't reach their positions 100%
//	colorfill(b_upper, bc);
//	colorfill(b_lower, bc);
//	flip(1);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw blitrect
//
//	blits (and clips) specified rectangle to specified position from source to
//	destination surface indicated by id's
//	0 = primary surface
//	1 = backbuffer (default destination)
//	2 = offscreen surface (default source)
//
//	returns true when blitted, else false (on error or when out of screen)
//
//------------------------------------------------------------------------------------------------

bool directdraw::blitrect(RECT rSCREEN,								//boundary coordinates of destination surface
						  RECT &csource,							//coordinates of source rectangle
						  RECT &cdest,								//coordinates of destination rectangle
						  int surface_source,						//source surface
						  int surface_destination)					//destination surface
{
	//if clipper returns true which means dest RECT is within screen (clipped), blit rectangle
	if (clipper(rSCREEN, csource, cdest))
	{
		//source and destination surfaces
		LPDIRECTDRAWSURFACE7	ps;
		LPDIRECTDRAWSURFACE7	pd;

		if (surface_source == 0)			ps = lpDDSPrimary;
		if (surface_source == 1)			ps = lpDDSBack;
		if (surface_source == 2)			ps = lpDDSOff;
		if (surface_destination == 0)		pd = lpDDSPrimary;
		if (surface_destination == 1)		pd = lpDDSBack;
		if (surface_destination == 2)		pd = lpDDSOff;

		pd->Blt(&cdest,
				ps,
				&csource,
				DDBLT_KEYSRC,
				NULL);

		return true;
	}
	else
		return false;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw colorfill
//
//	fills a specified area with a specified color
//
//------------------------------------------------------------------------------------------------

void directdraw::colorfill(RECT r, RGBcolor c)
{
    ddbltfx.dwSize		= sizeof(ddbltfx);
	//depending on color mode
	if (ddpixel.dwRGBBitCount == BPP16)
	    ddbltfx.dwFillColor = WORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);
	else
	    ddbltfx.dwFillColor = DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	lpDDSBack->Blt(&r,					//destination rectangle
				   NULL,				//source surface
				   NULL,				//source rectangle
				   DDBLT_COLORFILL,		//flag
				   &ddbltfx);			//address of the DDBLTFX structure
}

//------------------------------------------------------------------------------------------------
//
//	directdraw colorfill overloaded
//
//	fill entire surface by default
//
//------------------------------------------------------------------------------------------------

void directdraw::colorfill(RGBcolor c)
{
    ddbltfx.dwSize		= sizeof(ddbltfx); 
	//depending on color mode
	if (ddpixel.dwRGBBitCount == BPP16)
	    ddbltfx.dwFillColor = WORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);
	else
	    ddbltfx.dwFillColor = DWORD(p_rLUT[c.r] | p_gLUT[c.g] | p_bLUT[c.b]);

	lpDDSBack->Blt(NULL,				//desitantion rectangle
				   NULL,				//source surface
				   NULL,				//source rectangle
				   DDBLT_COLORFILL,		//flag
				   &ddbltfx);			//address of the DDBLTFX structure
}

//------------------------------------------------------------------------------------------------
//
//	directdraw colorfill overloaded
//
//	fill entire surface with enumerated color BLACK by default
//
//------------------------------------------------------------------------------------------------

void directdraw::colorfill(color ec)
{
	//set color according to ec
	RGBcolor	rgbc;
	rgbc.setcolor(ec);

	ddbltfx.dwSize		= sizeof(ddbltfx);
	//depending on color mode
	if (ddpixel.dwRGBBitCount == BPP16)
		ddbltfx.dwFillColor = WORD(p_rLUT[rgbc.r] | p_gLUT[rgbc.g] | p_bLUT[rgbc.b]);
	else
		ddbltfx.dwFillColor = DWORD(p_rLUT[rgbc.r] | p_gLUT[rgbc.g] | p_bLUT[rgbc.b]);

	lpDDSBack->Blt(NULL,				//desitantion rectangle
				   NULL,				//source surface
				   NULL,				//source rectangle
				   DDBLT_COLORFILL,		//flag
				   &ddbltfx);			//address of the DDBLTFX structure
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawbackground
//
//	draws standard background with two borders and white (default) or
//	user defined background
//
//------------------------------------------------------------------------------------------------

void directdraw::drawbackground(int r, int g, int b, int u, int m, int l)
{
	//color and fill area
//	RGBcolor	ac	= black;
	RGBcolor	ac(BORDERCOLOR);
	RECT		fa;

	//draw upper border
	if (u == 1)
	{
		fillRECT(fa, 0, 0, 800, 75);
		colorfill(fa, ac);
	}

	//draw lower border
	if (l == 1)
	{
		fillRECT(fa, 0, 525, 800, 600);
		colorfill(fa, ac);
	}

	//draw background
	if (m == 1)
	{
		ac.setcolor(r, g, b);
		fillRECT(fa, 0, 75, 800, 525);
		colorfill(fa, ac);
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawwinpoints
//
//	draws win icons for both players
//
//------------------------------------------------------------------------------------------------

void directdraw::drawwinpoints(int rounds,							//number of rounds
							   int bwmode,							//black and white mode
							   int clock,							//clock
							   int *winpoints,						//array with win data
							   RGBcolor cp1,						//fistcolor p1 and p2
							   RGBcolor cp2)
{
	//icon dimensions, icon type, 0 = unfilled, 1 = filled
	RECT		icon;
	int			icon_t;

	//color for draws
	RGBcolor	color;

	//offsets
	int x, y;

	//starting x-offsets
	//(first time i used modulo)
	if (rounds % 2)		x = 395 - (rounds / 2) * 20;
	else				x = (int)((399 - (rounds / 2.0f) * 20) + 6);

	//if round timer beneath timer else centered between names
	if (clock)			y = 55;
	else				y = 31;

	//!! halbe/halbe fuer draw?

	//for all rounds
	for (register int r = 0; r < rounds; ++r)
	{
		//color of icon
		//non black and white mode
		if (!bwmode)
		{
			if (winpoints[r] == 0)
			{
				icon_t	= 0;
				color.setcolor(white);
				fillRECT(icon, x + r * 20 + 1, y, x + r * 20 + 7, y + 12);
			}
			else
			{
				icon_t	= 1;

				if (winpoints[r] == 1)		color = cp1;
				if (winpoints[r] == 2)		color = cp2;
				if (winpoints[r] == 3)		color.setcolor(lightgray);

				fillRECT(icon, x + r * 20, y, x + r * 20 + 7, y + 13);
			}
		}
		else
		//bw mode
		{
			if (winpoints[r] == 0)
			{
				icon_t	= 0;
				color.setcolor(white);
				fillRECT(icon, x + r * 20 + 1, y, x + r * 20 + 7, y + 12);
			}
			else
			{
				icon_t	= 1;

				if (winpoints[r] == 1)		color = cp1;
				if (winpoints[r] == 2)		color = cp2;
				if (winpoints[r] == 3)		color.setcolor(lightgray);

				fillRECT(icon, x + r * 20, y, x + r * 20 + 7, y + 13);
			}
		}

		//drawtype depending on icon type
		if (icon_t == 0)			drawrectangle_uf(icon, color);
		else						drawrectangle_f(icon, color);
	}
}

//old version of drawwinpoints
void directdraw::drawwinpoints_(int *pwl_p1, int offx1, int *pwl_p2, int offx2, int bwmode, int rounds)
{
	//icon dimensions
	RECT		icon;

	//draw slots
	for (register int i = 0; i < rounds; ++i)
	{
		//player 1
		switch (pwl_p1[i])
		{
		//empty
		case (0):
			{
				fillRECT(icon, offx1 + 20 * i + 1, 54, offx1 + 7 + 20 * i, 66);
				drawrectangle_uf(icon, white);
				break;
			}

		//win
		case (1):
			{
				fillRECT(icon, offx1 + 20 * i, 54, offx1 + 7 + 20 * i, 67);

				if (bwmode == 0)
					drawrectangle_f(icon, green);
				else
					drawrectangle_f(icon, white);
				break;
			}

		//loss
		case (-1):
			{
				fillRECT(icon, offx1 + 20 * i, 54, offx1 + 7 + 20 * i, 67);

				if (bwmode == 0)
					drawrectangle_f(icon, red);
				else
					drawrectangle_f(icon, darkgray);
				break;
			}
		}

		//player 2
		switch (pwl_p2[i])
		{
		//empty
		case (0):
			{
				fillRECT(icon, offx2 + 20 * i + 1, 54, offx2 + 7 + 20 * i, 66);
				drawrectangle_uf(icon, white);
				break;
			}

		//win
		case (1):
			{
				fillRECT(icon, offx2 + 20 * i, 54, offx2 + 7 + 20 * i, 67);

				if (bwmode == 0)
					drawrectangle_f(icon, green);
				else
					drawrectangle_f(icon, white);
				break;
			}

		//loss
		case (-1):
			{
				fillRECT(icon, offx2 + 20 * i, 54, offx2 + 7 + 20 * i, 67);

				if (bwmode == 0)
					drawrectangle_f(icon, red);
				else
					drawrectangle_f(icon, darkgray);
				break;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw drawparticles
//
//	draws particles, gets array of particles, number of particles and color scheme
//
//------------------------------------------------------------------------------------------------

bool directdraw::drawparticles(particle *pa, int size, int shadows, int c_scheme, int r_no)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(drawparticles_16(pa, size, shadows, c_scheme, r_no));
	else
		return(drawparticles_32(pa, size, shadows, c_scheme, r_no));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw pixelfilter
//
//	renders whole scene with certain effect (negativ, grayscale)
//	used for pause mode
//	(used to take average of every rgb-value to determine
//	grayscale the right formula however is 0.3 * red + 0.59 * green + 0.11 * blue)
//
//------------------------------------------------------------------------------------------------

bool directdraw::pixelfilter(RECT area, int effect, WORD bred, WORD bgreen, WORD bblue)
{
	//call 16bit or 32bit color mode function
	if (ddpixel.dwRGBBitCount == BPP16)
		return(pixelfilter_16(area, effect, bred, bgreen, bblue));
	else
		return(pixelfilter_32(area, effect, bred, bgreen, bblue));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw clipper
//
//	returns true if dest RECT sill visible and clips it if necessary
//	returns false if dest RECT is completely out of screen, so it doesn't
//	have to be blitted
//
//------------------------------------------------------------------------------------------------

bool directdraw::clipper(RECT rscreen,
						 RECT &rsource,
						 RECT &rdest)
{
	//destination rectangle complete out of screen
	//return false to not clip the sprite
	if (rdest.left > rscreen.right)
		return false;
	if (rdest.right < rscreen.left)
		return false;
	if (rdest.top > rscreen.bottom)
		return false;
	if (rdest.bottom < rscreen.top)
		return false;

	//clip source and dest rectangles if necessary
	//(this version does adjust to non 1:1 ratio from source to destination)
	float xratio	= (float)(rsource.right - rsource.left) / (float)(rdest.right - rdest.left);
	float yratio	= (float)(rsource.bottom - rsource.top) / (float)(rdest.bottom - rdest.top);
	if (rdest.left < rscreen.left)
	{
		rsource.left	= rsource.left + (long)((rscreen.left - rdest.left) * xratio);
		rdest.left		= rscreen.left;
	}
	if (rdest.right > rscreen.right)
	{
		rsource.right	= rsource.right - (long)((rdest.right - rscreen.right) * xratio);
		rdest.right		= rscreen.right;
	}
	if (rdest.top < rscreen.top)
	{
		rsource.top		= rsource.top + (long)((rscreen.top - rdest.top) * yratio);
		rdest.top		= rscreen.top;
	}
	if (rdest.bottom > rscreen.bottom)
	{
		rsource.bottom	= rsource.bottom - (long)((rdest.bottom - rscreen.bottom) * yratio);
		rdest.bottom	= rscreen.bottom;
	}

/*	//clip source and dest rectangles if necessary
	//(this version doesn't adjust to non 1:1 ratio from source to destination)
	if (rdest.left < rscreen.left)
	{
		rsource.left	= rsource.left + (rscreen.left - rdest.left);
		rdest.left		= rscreen.left;
	}
	if (rdest.right > rscreen.right)
	{
		rsource.right	= rsource.right - (rdest.right - rscreen.right);
		rdest.right		= rscreen.right;
	}
	if (rdest.top < rscreen.top)
	{
		rsource.top		= rsource.top + (rscreen.top - rdest.top);
		rdest.top		= rscreen.top;
	}
	if (rdest.bottom > rscreen.bottom)
	{
		rsource.bottom	= rsource.bottom - (rdest.bottom - rscreen.bottom);
		rdest.bottom	= rscreen.bottom;
	}*/

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw rectclipper
//
//	clips the four points of a rectangle by reference
//	(the simple way)
//
//------------------------------------------------------------------------------------------------

void directdraw::rectclipper(rectangle &r)
{
	r.p[0].x < rSCREEN.left			? r.p[0].x = (float)rSCREEN.left		: r.p[0].x;
	r.p[0].x > rSCREEN.right - 1	? r.p[0].x = (float)rSCREEN.right - 1	: r.p[0].x;
	r.p[0].y < rSCREEN.top			? r.p[0].y = (float)rSCREEN.top			: r.p[0].y;
	r.p[0].y > rSCREEN.bottom - 1	? r.p[0].y = (float)rSCREEN.bottom - 1	: r.p[0].y;

	r.p[1].x < rSCREEN.left			? r.p[1].x = (float)rSCREEN.left		: r.p[1].x;
	r.p[1].x > rSCREEN.right - 1	? r.p[1].x = (float)rSCREEN.right - 1	: r.p[1].x;
	r.p[1].y < rSCREEN.top			? r.p[1].y = (float)rSCREEN.top			: r.p[1].y;
	r.p[1].y > rSCREEN.bottom - 1	? r.p[1].y = (float)rSCREEN.bottom - 1	: r.p[1].y;

	r.p[2].x < rSCREEN.left			? r.p[2].x = (float)rSCREEN.left		: r.p[2].x;
	r.p[2].x > rSCREEN.right - 1	? r.p[2].x = (float)rSCREEN.right - 1	: r.p[2].x;
	r.p[2].y < rSCREEN.top			? r.p[2].y = (float)rSCREEN.top			: r.p[2].y;
	r.p[2].y > rSCREEN.bottom - 1	? r.p[2].y = (float)rSCREEN.bottom - 1	: r.p[2].y;
	
	r.p[3].x < rSCREEN.left			? r.p[3].x = (float)rSCREEN.left		: r.p[3].x;
	r.p[3].x > rSCREEN.right - 1	? r.p[3].x = (float)rSCREEN.right - 1	: r.p[3].x;
	r.p[3].y < rSCREEN.top			? r.p[3].y = (float)rSCREEN.top			: r.p[3].y;
	r.p[3].y > rSCREEN.bottom - 1	? r.p[3].y = (float)rSCREEN.bottom - 1	: r.p[3].y;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw lineclipper
//
//	clips the two points of a line by reference
//	(the real way)
//	returns false if complete out of screen (not drawn)
//
//------------------------------------------------------------------------------------------------

bool directdraw::lineclipper(line &l)
{
	//dx	= x1 - x2
	//dy	= y1 - y2
	//m		= dy / dx
	//dx	= dy / m
	//dy	= dx * m

	//complete within screen
	if (l.p[0].x >= rSCREEN.left && l.p[0].x < rSCREEN.right &&
		l.p[1].x >= rSCREEN.left && l.p[1].x < rSCREEN.right &&
		l.p[0].y >= rSCREEN.top && l.p[0].y < rSCREEN.bottom &&
		l.p[1].y >= rSCREEN.top && l.p[1].y < rSCREEN.bottom)
		return(true);

	//complete out of screen
	if (l.p[0].x < rSCREEN.left && l.p[1].x < rSCREEN.left ||
		l.p[0].x >= rSCREEN.right && l.p[1].x >= rSCREEN.right ||
		l.p[0].y < rSCREEN.top && l.p[1].y < rSCREEN.top ||
		l.p[0].y >= rSCREEN.bottom && l.p[1].y >= rSCREEN.bottom)
		return(false);

	//slope
	float dx	= l.p[0].x - l.p[1].x;
	float dy	= l.p[0].y - l.p[1].y;
	float slope = 0;
	//no length
	if (dx == 0 && dy == 0)
		slope = 0;
	else
		//dx == 0, infinite slope (straight vertical line)
		//set slope to 1000
		if (dx == 0)
			slope	= 1000;
		else
		//standard slope
			slope = dy / dx;

	//adjusted values
	float dxn	= dx;
	float dyn	= dy;

	//for both points of line
	for (register int i = 0; i < 2; ++i)
	{
		//left screen side
		if (l.p[i].x < rSCREEN.left)
		{
			//shorten dx to screen border
//			float dxn			= dx;
			dxn					= dx;
			if (dx > 0)			dxn -= rSCREEN.left - l.p[i].x;
			else				dxn += rSCREEN.left - l.p[i].x;

			//shorten x to screen border
			l.p[i].x	= (float)rSCREEN.left;

			//get new dy
//			float dyn	= dxn * slope;
			dyn			= dxn * slope;

			//shorten y
			if (dx > 0)			l.p[i].y += dy - dyn;
			else
				if (dx < 0)			l.p[i].y -= dy - dyn;
				else
					if (dx == 0)
						if (slope > 0)
							if (dy > 0 )		l.p[i].y += dy;
							else				l.p[i].y -= dy;
						else
							if (dy > 0 )		l.p[i].y -= dy;
							else				l.p[i].y += dy;
		}

		//right screen side
		if (l.p[i].x > rSCREEN.right - 1)
		{
			//shorten dx to screen border
//			float dxn			= dx;
			dxn					= dx;
			if (dx > 0)			dxn -= l.p[i].x - (rSCREEN.right - 1);
			else				dxn += l.p[i].x - (rSCREEN.right - 1);

			//shorten x to screen border
			l.p[i].x	= (float)(rSCREEN.right - 1);

			//get new dy
//			float dyn	= dxn * slope;
			dyn			= dxn * slope;

			//shorten y
			//shorten y
			if (dx > 0)			l.p[i].y -= dy - dyn;
			else
				if (dx < 0)			l.p[i].y += dy - dyn;
				else
					if (dx == 0)
						if (slope > 0)
							if (dy > 0 )		l.p[i].y -= dy;
							else				l.p[i].y += dy;
						else
							if (dy > 0 )		l.p[i].y += dy;
							else				l.p[i].y -= dy;
		}

		//top screen side
		if (l.p[i].y < rSCREEN.top)
		{
			//shorten dy to screen border
//			float dyn			= dy;
			dyn					= dy;
			if (dy > 0)			dyn -= rSCREEN.top - l.p[i].y;
			else				dyn += rSCREEN.top - l.p[i].y;

			//shorten y to screen border
			l.p[i].y	= (float)rSCREEN.top;

			//get new dx
//			float dxn	= dyn / slope;
			dxn			= dyn / slope;

			//shorten x
			if (dy > 0)			l.p[i].x += dx - dxn;
			else
l.p[i].x -= dx - dxn;
/*				if (dy < 0)			l.p[i].x -= dx - dxn;
				else
					if (dy == 0)
						if (slope > 0)
							if (dx > 0)			l.p[i].x += dx;
							else				l.p[i].x -= dx;
						else
							if (dx > 0)			l.p[i].x -= dx;
							else				l.p[i].x += dx;*/

			//screen limits
//			if (l.p[i].x < rSCREEN.left)		l.p[i].x = (float)rSCREEN.left;
//			if (l.p[i].x > rSCREEN.right - 1)	l.p[i].x = (float)(rSCREEN.right - 1);
		}

		//bottom screen side
		if (l.p[i].y > rSCREEN.bottom - 1)
		{
			//shorten dy to screen border
//			float dyn			= dy;
			dyn					= dy;
			if (dy > 0)			dyn -= l.p[i].y - (rSCREEN.bottom - 1);
			else				dyn += l.p[i].y - (rSCREEN.bottom - 1);

			//shorten y to screen border
			l.p[i].y	= (float)(rSCREEN.bottom - 1);

			//get new dx
//			float dxn	= dyn / slope;
			dxn			= dyn / slope;

			//shorten x
			if (dy > 0)			l.p[i].x -= dx - dxn;
			else
l.p[i].x += dx - dxn;
/*		if (dy < 0)			l.p[i].x += dx - dxn;
				else
					if (dy == 0)
						if (slope > 0)
							if (dx > 0)			l.p[i].x -= dx;
							else				l.p[i].x += dx;
						else
							if (dx > 0)			l.p[i].x += dx;
							else				l.p[i].x -= dx;*/
			//screen limits
//			if (l.p[i].x < rSCREEN.left)		l.p[i].x = (float)rSCREEN.left;
//			if (l.p[i].x > rSCREEN.right - 1)	l.p[i].x = (float)(rSCREEN.right - 1);
		}
	}

	//diagonally out of screen, don't draw
	if (l.p[0].x < rSCREEN.left || l.p[0].x > rSCREEN.right - 1)
		return(false);

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw gamma_set
//
//	changes gamma setting (linear)
//
//------------------------------------------------------------------------------------------------

void directdraw::gamma_set(float factor_r, float factor_g, float factor_b)
{
	//if factor is default, reset gamma ramp using backup structure
	if (factor_r == 1.0f &&
		factor_g == 1.0f &&
		factor_b == 1.0f)
	{
		//default is 256 * index (0 to 255)
		ddgamma = ddgamma_backup;
		lpDDGamma->SetGammaRamp(0, &ddgamma);
		return;
	}

	//change color intensitiy according to factor
	for (register int i = 0; i < 256; ++i)
	{
		//intensitiy from 0 to 65280, check for validity
		ddgamma.red[i]		= (unsigned short)(256 * i * factor_r);
		ddgamma.red[i] > 65280		? ddgamma.red[i] = 65280	: ddgamma.red[i];

		ddgamma.green[i]	= (unsigned short)(256 * i * factor_g);
		ddgamma.green[i] > 65280	? ddgamma.green[i] = 65280	: ddgamma.green[i];
	
		ddgamma.blue[i]		= (unsigned short)(256 * i * factor_b);
		ddgamma.blue[i] > 65280		? ddgamma.blue[i] = 65280	: ddgamma.blue[i];
	}

	//change gamma ramp
	lpDDGamma->SetGammaRamp(0, &ddgamma);

	//reset gamma ramp to backup
	ddgamma = ddgamma_backup;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw gamma_fade
//
//	fades gamma from standard to black/white or vice versa
//	in amount of time (1.0 second per default)
//
//------------------------------------------------------------------------------------------------

void directdraw::gamma_fade(int mode_io, int mode_bw, float time, bool idle)
{
	//check time for validity
	time < 0.1f ? time = 0.1f : time;

	//start time
	LONGLONG t_start;

	//set start time
	t_start = p_time->current;

	//time passed since start of gamma fade in seconds
	double t_pass = (p_time->current - t_start) / (double)p_time->freq;

	if (idle)
	{
		while (t_start + (p_time->freq * time) > p_time->current)
		{
			//update p_time->current and t_pass
			QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
			//t_pass = (p_time->current - t_start) / (double)p_time->freq;
		}

		return;
	}

	//if fade mode is fade out (to black/white)
	if (mode_io == 0)
	{
		//if fade mode is to black
		if (mode_bw == 0)
		{
			//while time passed since start is < than time of fade
			while (t_start + (p_time->freq * time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)(i * (256 - 256 / time * t_pass));
				}

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}

			//set gamma to complete black in case it didn't work correctly
			for (register int i = 0; i < 256; ++i)
				ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] = 0;

			//change gamma ramp
			lpDDGamma->SetGammaRamp(0, &ddgamma);
		}
		else
		//if fade mode is to white
		{
			//while time passed since start is < than time of fade
			while (t_start + (p_time->freq * time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)((i - i / time * t_pass) * 256 + 65280 / time * t_pass);
				}

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}

			//set gamma to complete white in case it didn't work correctly
			for (register int i = 0; i < 256; ++i)
				ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] = 256 * 255;

			//change gamma ramp
			lpDDGamma->SetGammaRamp(0, &ddgamma);
		}
	}
	else
	//if fade mode is fade in (from black/white)
	{
		//if fade mode is from black
		if (mode_bw == 0)
		{
			//while time passed since start i < than time of fade
			while (t_start + (p_time->freq * time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i]	=
						(unsigned short)(i * 256 / time * t_pass);
				}

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}

			//set gamma to standard in case it didn't work correctly
			gamma_set();
		}
		else
		//if fade mode is from white
		{
			//while time passed since start i < than time of fade
			while (t_start + (p_time->freq * time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)(i / time * t_pass * 256 + (65280 - 65280 / time * t_pass));
				}

				//update p_time->current and t_pass
				QueryPerformanceCounter((LARGE_INTEGER*)&p_time->current);
				t_pass = (p_time->current - t_start) / (double)p_time->freq;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}

			//set gamma to standard in case it didn't work correctly
			gamma_set();
		}
	}

	//reset gamma ramp to backup
	ddgamma = ddgamma_backup;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw gamma_fade_ini
//
//	sets gamma change settings
//
//!!! new call ignorieren oder gamma reseten und neuen call ausf�hren?
//
//------------------------------------------------------------------------------------------------

void directdraw::gamma_fade_ini(int mode_fade,
								int mode_io,
								RGBcolor color,
								float time)
{
	//if no gamma change still active/in progress set settings else
	//return without activating new gamma change
	if (gcs.active != true)
	{
		//set gamma change settings

		//activate gamme change
		gcs.active			= true;
		//set fade modes
		gcs.mode_fade		= mode_fade;
		gcs.mode_io			= mode_io;
		//set RGBcolor
		gcs.color			= color;
		//validy and set time
		time < 0.1f ? time = 0.1f : time;
		gcs.time			= time;
		//set starting time
		gcs.t_start			= p_time->current;
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw gamma_fade_rt
//
//	realtime gamma fade from standard to custom color or vice versa
//	in amount of time (1.0 second per default)
//
//------------------------------------------------------------------------------------------------

void directdraw::gamma_fade_rt()
{
	//if fade mode is in one loop, do fade
	if (gcs.mode_fade == 0)
	{
		if (gcs.color == black)
			gamma_fade(gcs.mode_io, 0, gcs.time);
		if (gcs.color == white)
			gamma_fade(gcs.mode_io, 1, gcs.time);

		gcs.active = false;
		return;
	}

	//time passed since start of gamma fade
	double t_pass = (p_time->current - gcs.t_start) / (double)gcs.t_freq;

	//---- fade mode is fade out (to black/white) ------------------------------------------------

	if (gcs.mode_io == 0)
	{
		//if fade mode is to black
		//NOTE: black is enumerated (color) and RGBcolor color has an overloaded
		//comparison operator which takes an RGBcolor object as argument
		//it also has a converting constructor from enumerated color objects into
		//RGBcolor objects
		//the following comparison works in the way that it first converts the
		//enumerated color object into a RGBcolor object and than takes this
		//as argument for the overloaded comparison operator
		if (gcs.color == black)
		{
			//if time passed since start is < than time of fade
			if (gcs.t_start + (gcs.t_freq * gcs.time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)(i * (256 - 256 / gcs.time * t_pass));
				}

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
			else
			//else fade is done
			{
				//deactivate gamma change
				gcs.active = false;

				//set gamma to complete black in case it didn't work correctly
				for (register int i = 0; i < 256; ++i)
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] = 0;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
		}

		//if fade mode is to white
		if (gcs.color == white)
		{
			//if time passed since start is < than time of fade
			if (gcs.t_start + (gcs.t_freq * gcs.time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)((i - i / gcs.time * t_pass) * 256 + 65280 / gcs.time * t_pass);
				}

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
			else
			//else fade is done
			{
				//deactivate gamma change
				gcs.active = false;

				//set gamma to complete white in case it didn't work correctly
				for (register int i = 0; i < 256; ++i)
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] = 256 * 255;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
		}
	}

	//---- fade mode is fade in ------------------------------------------------------------------

	if (gcs.mode_io == 1)
	{
		//if fade mode is from black
		if (gcs.color == black)
		{
			//if time passed since start i < than time of fade
			if (gcs.t_start + (gcs.t_freq * gcs.time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i]	=
						(unsigned short)(i * 256 / gcs.time * t_pass);
				}

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
			else
			//fade is done
			{
				//deactivate gamma change
				gcs.active = false;

				//reset gamma ramp to backup
				ddgamma = ddgamma_backup;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
		}

		//if fade mode is from white
		if (gcs.color == white)
		{
			//if time passed since start < than time of fade
			if (gcs.t_start + (gcs.t_freq * gcs.time) > p_time->current)
			{
				//change color intensitiy according to passed time
				for (register int i = 0; i < 256; ++i)
				{
					ddgamma.red[i] = ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)(i / gcs.time * t_pass * 256 + (65280 - 65280 / gcs.time * t_pass));
				}

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
			else
			//fade is done
			{
				//deactivate gamma change
				gcs.active = false;

				//reset gamma ramp to backup
				ddgamma = ddgamma_backup;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
		}
	}

	//---- fade mode is fade from standard to color (red) and back to standard -------------------

	if (gcs.mode_io == 2)
	{
		//if time passed since start of fade is smaller than half of fade time
		//fade from standard to color, else fade from color to standard
		if (t_pass < gcs.time / 2)
		{
			//change color intensitiy according to passed time (in half the time)
			for (register int i = 0; i < 256; ++i)
			{
				if (gcs.color == red)
				{
					ddgamma.red[i] =
						(unsigned short)((i - i / (gcs.time / 2) * t_pass) * 256 + 65280 / (gcs.time / 2) * t_pass);
					ddgamma.green[i] = ddgamma.blue[i] =
						(unsigned short)(i * (256 - 256 / (gcs.time / 2) * t_pass));
				}

				if (gcs.color == green)
				{
					ddgamma.green[i] =
						(unsigned short)((i - i / (gcs.time / 2) * t_pass) * 256 + 65280 / (gcs.time / 2) * t_pass);
					ddgamma.red[i] = ddgamma.blue[i] =
						(unsigned short)(i * (256 - 256 / (gcs.time / 2) * t_pass));
				}

				if (gcs.color == blue)
				{
					ddgamma.blue[i] =
						(unsigned short)((i - i / (gcs.time / 2) * t_pass) * 256 + 65280 / (gcs.time / 2) * t_pass);
					ddgamma.red[i] = ddgamma.green[i] =
						(unsigned short)(i * (256 - 256 / (gcs.time / 2) * t_pass));
				}
			}

			//change gamma ramp
			lpDDGamma->SetGammaRamp(0, &ddgamma);
		}
		else
		{
			//if time passed since start i < than time of fade
			if (gcs.t_start + (gcs.t_freq * gcs.time) > p_time->current)
			{
				//change color intensitiy according to passed time (in half the time)
				for (register int i = 0; i < 256; ++i)
				{
					if (gcs.color == red)
					{
						ddgamma.red[i] =
							(unsigned short)(i / (gcs.time / 2) * t_pass * 256 + (65280 - 65280 / (gcs.time / 2) * t_pass));
						ddgamma.green[i] = ddgamma.blue[i] =
							(unsigned short)(i * 256 / (gcs.time / 2) * t_pass);
					}

					if (gcs.color == green)
					{
						ddgamma.green[i] =
							(unsigned short)(i / (gcs.time / 2) * t_pass * 256 + (65280 - 65280 / (gcs.time / 2) * t_pass));
						ddgamma.red[i] = ddgamma.blue[i] =
							(unsigned short)(i * 256 / (gcs.time / 2) * t_pass);
					}

					if (gcs.color == blue)
					{
						ddgamma.blue[i] =
							(unsigned short)(i / (gcs.time / 2) * t_pass * 256 + (65280 - 65280 / (gcs.time / 2) * t_pass));
						ddgamma.red[i] = ddgamma.green[i] =
							(unsigned short)(i * 256 / (gcs.time / 2) * t_pass);
					}
				}

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
			else
			//fade is done
			{
				//deactivate gamma change
				gcs.active = false;

				//reset gamma ramp to backup
				ddgamma = ddgamma_backup;

				//change gamma ramp
				lpDDGamma->SetGammaRamp(0, &ddgamma);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw draw_console
//
//	draws console specified by argumented pointer to console struct
//
//------------------------------------------------------------------------------------------------

void directdraw::draw_console(console *pc)
{
	//only if console active or inactive and moving
	if (!pc->state && !pc->moving)
		return;

	//console as RECT
	RECT	rtmp;

	//if console framed
	if (*pc->pcon_frame)
	{
		//draw console and frame
		//no overlays
		fillRECT(rtmp, (int)pc->console_r.p[0].x + 1, (int)pc->console_r.p[0].y + 1,
					   (int)pc->console_r.p[1].x, (int)pc->console_r.p[3].y);
		colorfill(rtmp, *pc->pcon_color);
		drawrectangle_uf(pc->console_r, *pc->pcon_fcolor);
	}
	else
	{
		//draw console only
		fillRECT(rtmp, (int)pc->console_r.p[0].x, (int)pc->console_r.p[0].y,
					   (int)pc->console_r.p[1].x, (int)pc->console_r.p[3].y);
		colorfill(rtmp, *pc->pcon_color);
	}

	//---- console output string -----------------------------------------------------------------

	//copy of output string
	//consisting of output buffer, line start character and active buffer
	unsigned char wordstring[CON_OBSTRING + 1 + CON_LINEMAX];
	ZeroMemory(&wordstring, sizeof(wordstring));
	strcpy((char*)wordstring, (char*)pc->output_buffer);
//	for (register unsigned int i = 0; i < strlen((char*)pc->output_buffer); ++i)
//		wordstring[i]	= pc->output_buffer[i];
//	wordstring[i] = 0;
	char tmp[2];
	tmp[0]	= pc->line_start;
	tmp[1]	= 0;
	strcat((char*)wordstring, tmp);
	strcat((char*)wordstring, (char*)pc->active_buffer);
//	int length = strlen((char*)wordstring);
//	for (i = length; i < length + strlen((char*)pc->active_buffer); ++i)
//		wordstring[i]	= pc->active_buffer[i + length];
//	wordstring[i] = 0;

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;

	//not scaling of console font (yet)
	float sizefactor	= 1.0f;

	//console border offsets
	RECT borderoffset;
	fillRECT(borderoffset, 8, 0, 0, 0);

	//get start coordinates
	//line break counter, line length counter
	int lbc = 0;	int llc = 0;

	//search through output string
	for (register unsigned int i = 0; i < strlen((char*)wordstring); ++i)
	{
		//for every character increase line length counter
		++llc;

		//if line length is longer then console or
		//character is new line start or
		//character is new line feed
		if (llc * 8 + borderoffset.left > (rtmp.right - rtmp.left) ||
			wordstring[i] == pc->line_start ||
			wordstring[i] == 10)
		{
			//increase line break counter and reset line length counter
			//(to 1 because this character counts as first of new line)
			++lbc;
			llc = 1;
		}
	}

	tempdest.left	= rtmp.left + borderoffset.left;
	tempdest.top	= rtmp.bottom - 16 - borderoffset.bottom - lbc * (long)(16.0f * sizefactor);

	//text color
	int color = *pc->pcon_textcolor;

	//autocolor
	//get color of font (black or white) depending of console background color
	if (color == -1)
	{
		if (pc->pcon_color->r + pc->pcon_color->g + pc->pcon_color->b > 128 * 3)
			color	= bmfblack;
		else
			color	= bmfwhite;
	}

	//verify color
	if (color < 0)			color	= 0;
	if (color > bmfMAX)		color	= bmfMAX;

	//for every letter while not null (end of string)
	for (i = 0; i <= sizeof(wordstring) && wordstring[i] != 0; ++i)
	{
		//start new line if this character is not complete within console boundaries or
		//new line character or
		//new line feed
		if (wordstring[i] == pc->line_start ||
			wordstring[i] == 10 ||
			tempdest.left + (long)(8 * sizefactor) > rtmp.right)
		{
			tempdest.left	= rtmp.left + (long)(borderoffset.left * sizefactor);
			tempdest.top	= tempdest.top + (long)(16.0f * sizefactor);
		}

		//set right and bottom members of tempdest
		tempdest.right	= tempdest.left + (long)(8 * sizefactor);
		tempdest.bottom	= tempdest.top + (long)(16 * sizefactor);

		//assign RECTS to temp RECTS so the originals don't get clipped
		//(especially the LUT)
		cdest	= tempdest;

		//if last line (current input), change color (hackiddyhack)
		//not while moving
		if (!pc->moving)
			if (tempdest.bottom	== pc->console_r.p[3].y)
				//line start symbol
				if (wordstring[i] == pc->line_start)
				{
					color	= bmfred;
				}
				else
				//regular text
				{
					if (pc->pcon_color->r + pc->pcon_color->g + pc->pcon_color->b > 128 * 3)
						color	= bmfblue;
					else
						color	= bmfyellow;
				}

		//offscreen surface offset depending on color
		csource.left	= p_cfontbm_LUT[wordstring[i]].left + (long)bmfs_offset[color].x;
		csource.top		= p_cfontbm_LUT[wordstring[i]].top + (long)bmfs_offset[color].y;
		csource.right	= p_cfontbm_LUT[wordstring[i]].right + (long)bmfs_offset[color].x;
		csource.bottom	= p_cfontbm_LUT[wordstring[i]].bottom + (long)bmfs_offset[color].y;

		//if clipper returns true which means dest RECT is within console (and clipped),
		//blit letter
		if (clipper(rtmp, csource, cdest))
			lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
						   lpDDSOff,					//dd surface which is source of blit
						   &csource,					//source rect, NULL for entire surface
						   DDBLT_KEYSRC,				//flags
						   NULL);						//address of DDBLTFX structure

		//increase to letterframe to left
		tempdest.left += (long)(8 * sizefactor);
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw draw_hud_text
//
//	draws hud_text specified by argumented pointer to hud_text struct
//
//------------------------------------------------------------------------------------------------

void directdraw::draw_hud_text(hud_text *ph)
{
	//no entries
	if (ph->entries < 1)
		return;

	//hud valid area as RECT
	RECT	rtmp	= ph->rdim;

	//destination of string, clipping source, clipping destination
	RECT tempdest, csource, cdest;

	//no scaling of hud font (yet)
	float sizefactor	= 1.0f;

	//hud border offsets
	RECT borderoffset;
	fillRECT(borderoffset, 8, 0, 0, 0);

	//get start coordinates
	//line break counter, line length counter
	int lbc = 0;	int llc = 0;

	//for every text entry
	for (register int e = 0; e < ph->entries; ++e)
	{
		//increase line break counter for each entry
		//and reset line length counter
		++lbc;
		llc = 0;

		//search through each entry
		for (register unsigned int i = 0; i < strlen((char*)ph->p_entry[e].ctext); ++i)
		{
			//for every character increase line length counter
			++llc;

			//if line length is longer then hud screen rect or
			//character is new line start or
			//character is new line feed
			if (llc * 8 + borderoffset.left > (rtmp.right - rtmp.left) ||
				ph->p_entry[e].ctext[i] == ph->line_start ||
				ph->p_entry[e].ctext[i] == 10)
			{
				//increase line break counter and reset line length counter
				//(to 1 because this character counts as first of new line)
				++lbc;
				llc	= 1;
			}
		}
	}

	//scroll
	if (ph->entries <= HUD_TEXT_MAX_ENTRIES)
	{
		lbc	+= HUD_TEXT_MAX_ENTRIES - ph->entries;
	}

	tempdest.left	= rtmp.left + borderoffset.left;
	tempdest.top	= rtmp.bottom - 16 - borderoffset.bottom - lbc * (long)(16.0f * sizefactor);

	//entry color
	int color	= 0;

	//for every text entry
	for (e = 0; e < ph->entries; ++e)
	{
		//get color
		color	= ph->p_entry[e].color;
		//verify color
		if (color < 0)			color	= 0;
		if (color > bmfMAX)		color	= bmfMAX;

		//start new line for every entry
		tempdest.left	= rtmp.left + (long)(borderoffset.left * sizefactor);
		tempdest.top	= tempdest.top + (long)(16.0f * sizefactor);

		//for every letter while not null (end of string)
		for (register unsigned int i = 0; i <= sizeof(ph->p_entry[e].ctext) && ph->p_entry[e].ctext[i] != 0; ++i)
		{
			//start new line if this character is not complete within hud bounderies or
			//new line character or
			//new line feed
			if (ph->p_entry[e].ctext[i] == ph->line_start ||
				ph->p_entry[e].ctext[i] == 10 ||
				tempdest.left + (long)(8 * sizefactor) > rtmp.right)
			{
				tempdest.left	= rtmp.left + (long)(borderoffset.left * sizefactor);
				tempdest.top	= tempdest.top + (long)(16.0f * sizefactor);
			}

			//set right and bottom members of tempdest
			tempdest.right	= tempdest.left + (long)(8 * sizefactor);
			tempdest.bottom	= tempdest.top + (long)(16 * sizefactor);

			//assign RECTS to temp RECTS so the originals don't get clipped
			//(especially the LUT)
			cdest	= tempdest;

			//offscreen surface offset depending on color
			csource.left	= p_cfontbm_LUT[ph->p_entry[e].ctext[i]].left + (long)bmfs_offset[color].x;
			csource.top		= p_cfontbm_LUT[ph->p_entry[e].ctext[i]].top + (long)bmfs_offset[color].y;
			csource.right	= p_cfontbm_LUT[ph->p_entry[e].ctext[i]].right + (long)bmfs_offset[color].x;
			csource.bottom	= p_cfontbm_LUT[ph->p_entry[e].ctext[i]].bottom + (long)bmfs_offset[color].y;

			//if clipper returns true which means dest RECT is within console (and clipped),
			//blit letter
			if (clipper(rtmp, csource, cdest))
				lpDDSBack->Blt(&cdest,						//destination rect, NULL for entire surface
							   lpDDSOff,					//dd surface which is source of blit
							   &csource,					//source rect, NULL for entire surface
							   DDBLT_KEYSRC,				//flags
							   NULL);						//address of DDBLTFX structure

			//increase to letterframe to left
			tempdest.left += (long)(8 * sizefactor);
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw draw_options_menu
//
//	draws options_menu
//
//------------------------------------------------------------------------------------------------

void directdraw::draw_options_menu(data_options *pdo, int typemode)
{
	//lock backbuffer
	if (!BBLock())
		return;

	//draw background lines
	RGBcolor		temp_c;
	line l1(0, 299, 799, 299),	l2(399, 75, 399, 524);
	drawline_ML(l1, temp_c);	drawline_ML(l2, temp_c);

	//yinyang symbol if shadow on
	if (p_option->data.shadows)
	{
		//inverted colors depending on background
		pdo->yy.ycyi.setcolor(255 - p_option->data.cbackground.r, 255 - p_option->data.cbackground.g, 255 - p_option->data.cbackground.b);
		pdo->yy.ycya.setcolor(p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b);

		//draw yinyang symbol, manual lock
		drawyinyang(pdo->yy, 1);
	}

	//draw slot selection rectangles
	//for all entries
	if (false)
	{
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				//if slot valid
				if (pdo->slot[x][y].set)
				{
					//draw unfilled qualifier rectangle
					drawrectangle_uf(pdo->slot[x][y].r_pos_qual, red, 1);
					//for all data sets
					for (int s = 0; s < 3; ++s)
					{
						//if rectangle valid
						if (pdo->slot[x][y].r_pos_data[s].left != -1)
						{
							//draw colored unfilled data rectangle(s)
							RGBcolor c(s * 100, y * 12, 255 - s * 125);
							drawrectangle_uf(pdo->slot[x][y].r_pos_data[s], c, 1);
						}
					}

					//draw point at qualifier and data position
					drawpoint(pdo->slot[x][y].pos_qual, black, 1);
					drawpoint(pdo->slot[x][y].pos_data, black, 1);
				}
			}
	}

	//unlock backbuffer for blitting
	if (typemode == 0)
		BBUnlock();

	//for all slots
	for (int x = 0; x < OS_X; ++x)
		for (int y = 0; y < OS_Y; ++y)
		{
			//if slot valid
			if (pdo->slot[x][y].set)
			{
				//colors for:
				//bitmapfont qualifier/data
				//scanlinefont qualifier/data
				//scanlinefont qualifier/data border
				int cqualBMF, cdataBMF;
				int clockedBMF;
				RGBcolor cqualSLF, cdataSLF;
				RGBcolor cqualbSLF(black), cdatabSLF(black);
				RGBcolor clockedSLF;

				//offsets for qualifier, data
				ipoint os_qual, os_data;

				//pointer to data string and UPDATE data string
				//char *pds	= pdo->slot[x][y].get_data_string();
				//pointer to data string (updated in master_frame through set_bounding_box())
				char *pds = pdo->slot[x][y].data_string;

				//if blackwhite mode draw menu in bmf, else in slf
				if (p_option->data.bw_mode)
				{
					//bitmap color depending on background color
					if (p_option->data.cbackground.r +
						p_option->data.cbackground.g +
						p_option->data.cbackground.b > 128 * 3)
					{
						cqualBMF	= bmfblack;
						cdataBMF	= bmfblack;
					}
					else
					{
						cqualBMF	= bmfwhite;
						cdataBMF	= bmfwhite;
					}

					cqualSLF.setcolor(lightgray);
					cdataSLF.setcolor(lightgray);
				}
				else
				{
					//bitmap color depending on background color
					if (p_option->data.cbackground.r +
						p_option->data.cbackground.g +
						p_option->data.cbackground.b > 128 * 3)
					{
						cqualBMF	= bmfgreen;
						cdataBMF	= bmfgreen;
					}
					else
					{
						cqualBMF	= bmfwhite;
						cdataBMF	= bmfwhite;
					}

					cqualSLF.setcolor(green);
					cdataSLF.setcolor(green);
				}
				//locked color
				//bitmap color depending on background color
				//(worst to see)
				if (p_option->data.cbackground.r +
					p_option->data.cbackground.g +
					p_option->data.cbackground.b > 128 * 3)
					clockedBMF	= bmfyellow;
				else
					clockedBMF	= bmfblue;
				//locked slf in background color
				clockedSLF.setcolor(p_option->data.cbackground);

				//pre (input, string)
				if (pdo->slot[x][y].selection & SEL_PRE)
				{
					cqualBMF	= bmfred;
					cqualSLF.setcolor(red);
					cdataBMF	= bmfred;
					cdataSLF.setcolor(red);
				}

				//if qualifier selected
				if (pdo->slot[x][y].selection & SEL_QUAL)
				{
					//set offset and color
					os_qual.x	= -5;
					os_data.x	= -5;

					cqualBMF	= bmfred;
					cqualSLF.setcolor(red);
					cdataBMF	= bmfred;
					cdataSLF.setcolor(red);
				}
				//if data selected and data not an RGB value
				if ((pdo->slot[x][y].selection & SEL_DAT1) &&
					pdo->slot[x][y].d_type != ODT_RGB)
				{
					//set offset and color
					//os_qual.x	= -5;
					os_data.x	= -5;

					cdataBMF	= bmfred;
					cdataSLF.setcolor(red);
					//highlight qualifier
					cqualBMF	= bmfred;
					cqualSLF.setcolor(red);
				}
				//if data selected and data is RGBcolor
				if (!(pdo->slot[x][y].selection & SEL_QUAL) && 
					(pdo->slot[x][y].selection & (SEL_DAT1 | SEL_DAT2 | SEL_DAT3)) &&
					pdo->slot[x][y].d_type == ODT_RGB)
				{
					//color and offset for RGB selection
					int cRGBBMF			= bmfred;
					RGBcolor cRGBSLF	= red;
					ipoint os_rgb(-5, 0);

					//highlight qualifier without offsetting it
					cqualBMF	= bmfred;
					cqualSLF.setcolor(red);

					//delete selected RGB part from data_string
					//create separate char string with same length as data string
					//but only with the selected RGB part
					//display both, the selected part colored and with offset
					//data_string	"RGB     RGB"
					//new string	"    RGB    "
					//displayed		"RGB RGB RGB"

					//new data string
					char d[12]	= "           ";
					//value offset depending on RGB selection
					int off		= 0;
					//get RGB value depending on selection
					//if (pdo->slot[x][y].selection & SEL_DAT1)	off = 0;
					if (pdo->slot[x][y].selection & SEL_DAT2)	off = 4;
					if (pdo->slot[x][y].selection & SEL_DAT3)	off = 8;
					//for three letters
					for (int i = 0; i < 3; ++i)
					{
						//copy selected "RGB" part from data string into new string at right position
						d[i + off]		= pds[i + off];
						//delete selected "RGB" part from data string
						pds[i + off]	= ' ';
					}
					//string end
					d[11] = 0;

					//display selected data
					if (typemode == 0)
						typebmf(pdo->slot[x][y].pos_data.x + os_rgb.x, pdo->slot[x][y].pos_data.y + os_rgb.y,
						cRGBBMF, pdo->slot[x][y].bmf_size, "%s", d);
					else
						typeSLF_ML(pdo->slot[x][y].pos_data.x + os_rgb.x, pdo->slot[x][y].pos_data.y + os_rgb.y,
						0, 0, 0, cRGBSLF.r, cRGBSLF.g, cRGBSLF.b,
						pdo->slot[x][y].slf_size, "%s", d);
				}

				//special color schemes
				switch (pdo->slot[x][y].color_scheme)
				{
				//background
				//background already drawn in current color
/*				case (OCS_BGN):
					{
						//if selected
						if (pdo->slot[x][y].selection & SEL_ALL)
						{
							//bmf mode
							if (typemode == 0)
							{
								//draw background rectangle in color of the data
								colorfill(pdo->slot[x][y].r_pos_qual, *(RGBcolor*)pdo->slot[x][y].p_data);
								//qualifer color depending on RGBcolor
								if ((*(RGBcolor*)pdo->slot[x][y].p_data).r + 
									(*(RGBcolor*)pdo->slot[x][y].p_data).g +
									(*(RGBcolor*)pdo->slot[x][y].p_data).b > 128 * 3)
									cqualBMF = bmfblack;
								else
									cqualBMF = bmfwhite;
							}
							else
							{
								//set qualifier of _selected_ entry to color of the data
								cqualSLF.setcolor(*(RGBcolor*)pdo->slot[x][y].p_data);
							}
						}

						break;
					}*/

				//fist
				case (OCS_FIST):
					{
						//if selected
						if (pdo->slot[x][y].selection & SEL_ALL)
						{
							//bmf mode
							if (typemode == 0)
							{
								//draw background rectangle in color of the data
								colorfill(pdo->slot[x][y].r_pos_qual, *(RGBcolor*)pdo->slot[x][y].p_data);
								//qualifer color depending on RGBcolor
								if ((*(RGBcolor*)pdo->slot[x][y].p_data).r + 
									(*(RGBcolor*)pdo->slot[x][y].p_data).g +
									(*(RGBcolor*)pdo->slot[x][y].p_data).b > 128 * 3)
									cqualBMF = bmfblack;
								else
									cqualBMF = bmfwhite;
							}
							else
							{
								//set qualifier of _selected_ entry to color of the data
								cqualSLF.setcolor(*(RGBcolor*)pdo->slot[x][y].p_data);
							}
						}

						break;
					}
				}

				//option locked change color, offset
				if (pdo->slot[x][y].locked)
				{
					cqualBMF	= clockedBMF;
					cdataBMF	= clockedBMF;
					cqualSLF.setcolor(clockedSLF);
					cdataSLF.setcolor(clockedSLF);

					os_qual.setpoint(0, 0);
					os_data.setpoint(0, 0);
				}

				//display qualifier and data
				if (typemode == 0)
				{
					//qualifier
					typebmf(pdo->slot[x][y].pos_qual.x + os_qual.x, pdo->slot[x][y].pos_qual.y + os_qual.y, cqualBMF, pdo->slot[x][y].bmf_size, "%s", pdo->slot[x][y].qualifier);
					//data
					typebmf(pdo->slot[x][y].pos_data.x + os_data.x, pdo->slot[x][y].pos_data.y + os_data.y, cdataBMF, pdo->slot[x][y].bmf_size, "%s", pds);
				}
				else
				{
					//qualifier
					typeSLF_ML(pdo->slot[x][y].pos_qual.x + os_qual.x, pdo->slot[x][y].pos_qual.y + os_qual.y, cqualbSLF.r, cqualbSLF.g, cqualbSLF.b, cqualSLF.r, cqualSLF.g, cqualSLF.b, pdo->slot[x][y].slf_size, "%s", pdo->slot[x][y].qualifier);
					//data
					typeSLF_ML(pdo->slot[x][y].pos_data.x + os_data.x, pdo->slot[x][y].pos_data.y + os_data.y, cdatabSLF.r, cdatabSLF.g, cdatabSLF.b, cdataSLF.r, cdataSLF.g, cdataSLF.b, pdo->slot[x][y].slf_size, "%s", pds);
				}

				//name string, last char blinking (by drawing over last char of name)
				//if data selected and data is string
				if ((pdo->slot[x][y].selection & SEL_DAT1) &&
					pdo->slot[x][y].d_type == ODT_CHAR)
				{
					//color and offset for string selection
					int cSTRBMF			= bmfblack;
					RGBcolor cSTRSLF(red);
					ipoint os_str(-5, 0);

					//blinking cursor
					//if (p_time->cs % 2)
					//holy shit! what kind of hocus pocus is this?!
					//since when can you not call a non constant method through a constant object pointer?
					if (((timer*)p_time)->tick(0.4f))
					{
						cSTRBMF	= bmfblack;
						cSTRSLF.setcolor(red);
					}
					else
					{
						cSTRBMF	= bmfwhite;
						cSTRSLF.setcolor(p_option->data.cbackground);
					}

					//new data string which only contains last char of name string
					//(either '_' or last letter)
					//and is drawn over last char of name string
					char d[21]	= "                    ";
					int mark	= strlen((char*)pdo->slot[x][y].p_data);
					d[mark - 1]		= pds[mark - 1];
					//string end
					d[20] = 0;

					//display last symbol
					if (typemode == 0)
						typebmf(pdo->slot[x][y].pos_data.x + os_str.x, pdo->slot[x][y].pos_data.y + os_str.y,
						cSTRBMF, pdo->slot[x][y].bmf_size, "%s", d);
					else
						typeSLF_ML(pdo->slot[x][y].pos_data.x + os_str.x, pdo->slot[x][y].pos_data.y + os_str.y,
						0, 0, 0, cSTRSLF.r, cSTRSLF.g, cSTRSLF.b,
						pdo->slot[x][y].slf_size, "%s", d);
				}
			}
		}

	//unlock backbuffer if not already unlocked
	if (typemode != 0)
		BBUnlock();
}

//------------------------------------------------------------------------------------------------
//
//	directdraw BBLock
//
//	locks backbuffer
//
//------------------------------------------------------------------------------------------------

bool directdraw::BBLock()
{
	//lock backbuffer, return false if it fails
	hRet = lpDDSBack->Lock(NULL,					//RECT of area to be locked, NULL entire surface
						   &ddsd,					//DDSURFACEDESC2 structure to be filled with all relevant details
						   DDLOCK_SURFACEMEMORYPTR,	//flags
						   NULL);					//NULL
	if (hRet != DD_OK)
	{
		gf_logger(true, "directdraw::BBLock() FAILED (%i)", hRet);

		lpDDSBack->Unlock(NULL);
		return(false);
	}

	//assign surface pitch
	ddspitch = ddsd.lPitch;

	//increase video ram lock counter and set status to locked
	++VRAM_nlocks;
	VRAM_locked		= 1;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw Unlock
//
//	unlocks backbuffer
//
//------------------------------------------------------------------------------------------------

bool directdraw::BBUnlock()
{
	//unlock backbuffer
	lpDDSBack->Unlock(NULL);

	//set status to unlocked
	VRAM_locked		= 0;

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw VRAM_show
//
//	display number of video ram access
//
//------------------------------------------------------------------------------------------------

void directdraw::VRAM_show()
{
	if (SHOWVRAM)
	{
		RGBcolor bg	= black;
		if (p_option->data.screenmode)			typebmf(8, 24, bmfwhite, bg, "VRAM: %i", VRAM_nlocks);
		else									typebmf(8, 40, bmfwhite, bg, "VRAM: %i", VRAM_nlocks);

		//reset video ram locks
		VRAM_nlocks = 0;
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw FPS_show
//
//	displays current frames per second
//
//------------------------------------------------------------------------------------------------

void directdraw::FPS_show()
{
	//show framerate if on
	if (p_option->data.show_fps == 1)
	{
		int color = bmfwhite;
		RGBcolor bc(BORDERCOLOR);
		if (bc.r + bc.g + bc.b > 128 * 3)		color = bmfblack;
		else									color = bmfwhite;

		if (p_option->data.screenmode)			typebmf(8, 8, color, "FPS: %i", p_time->fps);
		else									typebmf(8, 24, color, "FPS: %i", p_time->fps);
	}
}

//------------------------------------------------------------------------------------------------
//
//	directdraw FillRECT
//
//	fills a RECT structure (for convenience)
//
//------------------------------------------------------------------------------------------------

RECT &directdraw::fillRECT(RECT &r, int left_x1, int top_y1, int right_x2, int bottom_y2)
{
	r.left		= left_x1;		r.right		= right_x2;
	r.top		= top_y1;		r.bottom	= bottom_y2;

	return(r);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw round_fi
//
//	rounds a float into an int
//	f <= .4 == round down
//	f > .5 == round up
//
//------------------------------------------------------------------------------------------------

int directdraw::round_fi(float f)
{
	if (f > 0)
		return (int)(f + 0.5f);
	else
		return (int)(f - 0.5f);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw RegisterConVars
//
//	registers console variable
//
//------------------------------------------------------------------------------------------------

void directdraw::RegisterConVars(console *pcon)
{
//	CLASS_CVI(float, fatigue, 0, 0);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw con_add_message
//
//	adds message to console
//
//------------------------------------------------------------------------------------------------

void directdraw::con_add_message(char *format, ...)
{
	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	//clear message dump
	con_clear();

	//print formated string in console dump message
    vsprintf(con_dumpmessage, format, ap);

	//clear up
	va_end(ap);
}

//------------------------------------------------------------------------------------------------
//
//	directdraw con_clear
//
//	clears console message buffer
//
//------------------------------------------------------------------------------------------------

void directdraw::con_clear()
{
	ZeroMemory(&con_dumpmessage, sizeof(con_dumpmessage));
}

//------------------------------------------------------------------------------------------------
//
//	directdraw hud_add_message
//
//------------------------------------------------------------------------------------------------

void directdraw::hud_add_message(int _hud_id, int color, char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "directdraw::hud_add_message NULL");
		return;
	}

	//verify id
	if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
	if (_hud_id < 0)				_hud_id = 0;

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	directdraw hud_add_message
//
//------------------------------------------------------------------------------------------------

void directdraw::hud_add_message(char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "directdraw::hud_add_message NULL");
		return;
	}

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//default values
	int _hud_id		= 0;
	int color		= bmfblack;

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}


bool directdraw::drawtest(int type)
{
	if (type == -1)
		return(true);

	//---- setup ---------------------------------------------------------------------------------

	ipoint	p;
	p.x		= 0;
	p.y		= 0;

	RGBcolor	r;

	DWORD pixel32black	= DWORD(p_rLUT[0] | p_gLUT[0] | p_bLUT[0]);
	DWORD pixel32white	= DWORD(p_rLUT[255] | p_gLUT[255] | p_bLUT[255]);

	//lock backbuffer, return false if it fails
	hRet = lpDDSBack->Lock(NULL,					//RECT of area to be locked, NULL entire surface
						   &ddsd,					//DDSURFACEDESC2 structure to be filled with all relevant details
						   DDLOCK_SURFACEMEMORYPTR,	//flags
						   NULL);					//NULL
	if (hRet != DD_OK)
	{
		lpDDSBack->Unlock(NULL);
		return false;
	}

	//surface pointer
	DWORD	*pslocked32	= NULL;						//pointer is 16bit

	if (!(pslocked32 = (DWORD*) ddsd.lpSurface))
	{
		lpDDSBack->Unlock(NULL);
		pslocked32 = NULL;
		return(false);
	}

	//backup pointer so we don't have to convert ddsd.lpSurface
	//everytime we reset pslocked32
	DWORD *psbackup32	= pslocked32;

	//assign surface pitch
	ddspitch = ddsd.lPitch;

	//pre calculate y offset
	int yoffset	= ddspitch / sizeof(DWORD);

	//---- plot pixel ----------------------------------------------------------------------------
	//x = increment/decrement surface pointer by number of bytes per pixel
	//	(watch pointer surface type (size)!)
	//y = adding/subtract pitch value from current surface pointer
	//	(pitch is in byte, watch pointer surface type (size)!)

	if (type == 0)
	{
		for (p.y = 0; p.y < HEIGHT - 1; ++p.y)
			for (p.x = 0; p.x < WIDTH - 1; ++p.x)
			{
				//assign x-coordinate
				//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
				pslocked32 += (int)p.x;
				//assign y-coordinate
				//ddspitch is in byte, but since one pixel is short and pslocked32
				//is incremented by short you have to adjust the ddspitch value by
				//the size of short
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * p.y);
				pslocked32 += yoffset * p.y;
				//set pixel
//	*pslocked32 = pixel32;
				if (p.y % 2 == 0)
					if (p.x % 2 == 0)
						*pslocked32 = pixel32black;
					else
						*pslocked32 = pixel32white;
				else
					if (p.x % 2 == 0)
						*pslocked32 = pixel32white;
					else
						*pslocked32 = pixel32black;

				//reset pixel pointer
				pslocked32 = psbackup32;
			}
	}

	if (type == 1)
	{
		for (p.y = 0; p.y < HEIGHT - 1; ++p.y)
			for (p.x = 0; p.x < WIDTH - 1; ++p.x)
			{
				//assign x-coordinate
				//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
				pslocked32 += (int)p.x;
				//assign y-coordinate
				//ddspitch is in byte, but since one pixel is short and pslocked32
				//is incremented by short you have to adjust the ddspitch value by
				//the size of short
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * p.y);
				pslocked32 += yoffset * p.y;
				//set pixel
//				*pslocked16 = pixel16;
				if ((int)p.x % 2 == 0)
					*pslocked32 = pixel32black;
				else
					*pslocked32 = pixel32white;

				//reset pixel pointer
				pslocked32 = psbackup32;
			}
	}

	if (type == 2)
	{
		for (p.y = 0; p.y < HEIGHT - 1; ++p.y)
			for (p.x = 0; p.x < WIDTH - 1; ++p.x)
			{
				//assign x-coordinate
				//pslocked32 is a pointer to ushort, so incremented by sizeof(short)
				pslocked32 += (int)p.x;
				//assign y-coordinate
				//ddspitch is in byte, but since one pixel is short and pslocked32
				//is incremented by short you have to adjust the ddspitch value by
				//the size of short
//				pslocked32 += (int)((ddspitch / sizeof(DWORD)) * p.y);
				pslocked32 += yoffset * p.y;
				//set pixel
				//set pixel
//				*pslocked16 = pixel16;
				if ((int)p.y % 2 == 0)
					*pslocked32 = pixel32black;
				else
					*pslocked32 = pixel32white;

				//reset pixel pointer
				pslocked32 = psbackup32;
			}
	}

	//---- cleanup -------------------------------------------------------------------------------

	//unlock backbuffer, reset surface pointer
	lpDDSBack->Unlock(NULL);
	pslocked32 = NULL;

	return true;
}