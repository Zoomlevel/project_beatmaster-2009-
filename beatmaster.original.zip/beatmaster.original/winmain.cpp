/************************************************************************************************/
/*
/*	PROJECT_BEATMASTER
/*
/*	Killing Me Software 2009
/*
/*	Date:		17.10.2009
/*	Version:	0.100
/*
/************************************************************************************************/

//------------------------------------------------------------------------------------------------

#ifndef _WIN32_WINNT
#define _WIN32_WINNT			0x0501		//identify as windows xp application
											//necessary to access rawinput from user32.dll
#endif

#include "resource.h"
#include "master_frame.h"					//master_frame class

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

//---- defines -----------------------------------------------------------------------------------

//number of possible arguments
#define		CLA_NO							10

//command line arguments
#define		CLA_LOG							"-log"			//to create program log file
#define		CLA_HEL							"-HEL"			//deactivate hardware acceleration
#define		CLA_OFFSYS						"-off_sys"		//offscreen surface in system memory
#define		CLA_VBSYS						"-vb_sys"		//backbuffer in system memory
#define		CLA_CONSOLE						"-console"		//access to ingame console
#define		CLA_OPEN_FILE_LOG				"-oflog"		//to open FLOG file after exiting program
#define		CLA_OPEN_FILE_ERROR				"-oferror"		//to open FERROR file if a new one was created after exiting program
#define		CLA_OPEN_FILE_MLOG				"-ofmlog"		//to open FMEMORY file if created after exiting program

//---- error message strings ---------------------------------------------------------------------

const char *gp_ErrStr						= NULL;

const char Err_WMDefault[]					= "Default Error";
const char Err_WMReg_Class[]				= "Error Registering Window Class";
const char Err_WMCreate_Win[]				= "Error Creating Window";

//------------------------------------------------------------------------------------------------

//guids used in static enumeration function of directinput
GUID				guid_mouse01;
GUID				guid_mouse02;
GUID				guid_controller01;
GUID				guid_controller02;

program_options		gProgramOptions;		//global program options object

//------------------------------------------------------------------------------------------------

//global variable indicates program status
//0 == program inactive, idle
//1 == program running, resume
//2 == program reactivated, restore surfaces

int gAppState		= INACTIVE;
//windows message WM_PAINT
bool gAppRefresh	= false;

LONG glParam		= 0;					//global WndProc lParam (for RawInput)

//windows message loop prototype
long APIENTRY WndProc(HWND hwnd,
					  UINT message,
					  UINT wParam,
					  LONG lParam);

//------------------------------------------------------------------------------------------------
//
//	WinMain
//
//------------------------------------------------------------------------------------------------

int APIENTRY WinMain(HINSTANCE hInstance,			//handle of running program
					 HINSTANCE hPrevInstance,		//16-bit relic, NULL (previous instance handle)
					 LPSTR lpCmdLine,				//pointer to command line parameters
					 int nShowCmd)					//how to display main window
{
	//delete log and error file
	DeleteFile(FERROR);
	DeleteFile(FLOG);

	//---- process command line arguments --------------------------------------------------------

	//buffer to store command line arguments, argument counter, char counter
	char pcla[CLA_NO][256]	= {0};
	int clc_i				= 0;
	int cls_i				= 0;

	//while command line string pointer valid filter out arguments
	while(*lpCmdLine)
		//if no space
		if (*lpCmdLine != ' ')
		{
			//copy character into current buffer, increase command line string pointer
			pcla[clc_i][cls_i] = *lpCmdLine++;
			//increase buffer string index
			if (cls_i < 255)
				++cls_i;
		}
		else
		{
			//increase buffer index, reset buffer string index, increase command line string pointer
			if (clc_i < CLA_NO - 1)
				++clc_i;
			cls_i = 0;
			*lpCmdLine++;
		}

	//for all command line arguments
	for (register int i = 0; i < CLA_NO; ++i)
	{
		//switch event logger on
		if (!strcmp(CLA_LOG, pcla[i]))
		{
			gProgramOptions.logger = ON;
			//create log folder
			_mkdir("log");
		}
		else
		if (!strcmp(CLA_CONSOLE, pcla[i]))
			gProgramOptions._console = ON;
		else
		//no hardware acceleration
		if (!strcmp(CLA_HEL, pcla[i]))
			gProgramOptions.HEL = ON;
		else
		//offscreen surface in system memory
		if (!strcmp(CLA_OFFSYS, pcla[i]))
			gProgramOptions.off_sys = ON;
		else
		//backbuffer surfaces in system memory
		if (!strcmp(CLA_VBSYS, pcla[i]))
			gProgramOptions.vb_sys = ON;
		else
		//FLOG after exiting program
		if (!strcmp(CLA_OPEN_FILE_LOG, pcla[i]))
		{
			//and log was created
			if (gProgramOptions.logger)
				gProgramOptions.open_file_log	= true;
		}
		else
		//FERROR after exiting program
		if (!strcmp(CLA_OPEN_FILE_ERROR, pcla[i]))
		{
			//and log was created
			if (gProgramOptions.logger)
				gProgramOptions.open_file_error	= true;
		}
		else
		//FMEMORY after exiting program
		if (!strcmp(CLA_OPEN_FILE_MLOG, pcla[i]))
		{
			//and log was created
			if (gProgramOptions.logger)
				gProgramOptions.open_file_mlog	= true;
		}
		else
		if (strcmp("", pcla[i]))
			gf_logger(true, "ProgramOptions: Unknown argument %s", pcla[i]);
	}

	//log program options
	if (gProgramOptions.logger)
		gf_logger(false, "ProgramOptions: log");
	if (gProgramOptions.HEL)
		gf_logger(false, "ProgramOptions: HEL");
	else
		gf_logger(false, "ProgramOptions: HAL");
	if (gProgramOptions.off_sys)
		gf_logger(false, "ProgramOptions: Offscreen in System Memory");
	if (gProgramOptions.vb_sys)
		gf_logger(false, "ProgramOptions: Video Buffer in System Memory");
	if (gProgramOptions.open_file_log)
		gf_logger(false, "ProgramOptions: Open File \"%s\"", FLOG);
	if (gProgramOptions.open_file_error)
		gf_logger(false, "ProgramOptions: Open File \"%s\"", FERROR);
	if (gProgramOptions.open_file_mlog)
		gf_logger(false, "ProgramOptions: Open File \"%s\"", FMEMORY);

	//---- prepare window ------------------------------------------------------------------------

	//name of window/class
	static char szClassName[] =		"BMWinClass";
	static char szWindowName[] =	"beatmaster";

	//if no previous instance exists create window class
	if (!hPrevInstance)
	{
		//win class structure with window information
		WNDCLASSEX					winclassex;

		winclassex.cbSize =			sizeof(winclassex);				//size of structure
		winclassex.style =			CS_HREDRAW | CS_VREDRAW;		//hor/ver redraw
		winclassex.lpfnWndProc =	WndProc;						//pointer to window procedure
		winclassex.cbClsExtra =		0;								//extra bytes to allocate
		winclassex.cbWndExtra =		0;								//extra bytes for each instance
		winclassex.hInstance =		hInstance;						//handle of creating instance
		//default icon
//		winclassex.hIcon =			LoadIcon(NULL, IDI_APPLICATION);	//handle to window icon
		winclassex.hIcon =			LoadIcon(hInstance, (const char*)IDI_ICON1);	//handle to window icon
		winclassex.hCursor =		LoadCursor(NULL, IDC_ARROW);		//handle to window cursor
		winclassex.hbrBackground =	(HBRUSH)GetStockObject(BLACK_BRUSH);//background color
		winclassex.lpszMenuName =	NULL;
		winclassex.lpszClassName =	szClassName;
//		winclassex.hIconSm =		LoadIcon(NULL, IDI_APPLICATION);	//small icon
		winclassex.hIconSm =		LoadIcon(hInstance, (const char*)IDI_ICON1);

		//if register window class fails,
		//assign errorstring and exit program(1)
		if (!RegisterClassEx(&winclassex))
		{
			gf_logger(true, "winmain error registering window class");
			MessageBox(NULL, gp_ErrStr = Err_WMReg_Class, "Error", MB_OK);
			return(1);
		}
		else
			gf_logger(false, "winmain registered window class");
	}

	//---- create window -------------------------------------------------------------------------

	//window handle
	HWND hwnd				= NULL;

	hwnd = CreateWindowEx(0,
						  //WS_EX_TOPMOST,			//extended window style
						  szClassName,				//class name
						  szWindowName,				//window name
						  WS_POPUP | WS_BORDER,
//						  WS_POPUP | WS_VISIBLE	|	//window style
//						  WS_SYSMENU | WS_CAPTION,
						  //WS_MINIMIZEBOX,
						  0,						//horizontal position
						  0,						//vertical position
						  GetSystemMetrics(SM_CXSCREEN),	//set width to current width
						  GetSystemMetrics(SM_CYSCREEN),	//set height to current height
						  NULL,						//NULL if no child window
						  NULL,						//handle to menu
						  hInstance,				//handle to application instance
						  NULL);					//parameter passed to WM_CREATE

	//if no handle returned assign errorstring and exit program(1)
	if (!hwnd)
	{
		gf_logger(true, "winmain creating window failed");
		MessageBox(NULL, gp_ErrStr = Err_WMCreate_Win, "Error", MB_OK);
		return(1);
	}
	else
		gf_logger(false, "winmain created window");

	//---- show window, set focus ----------------------------------------------------------------

	ShowWindow(hwnd, nShowCmd);		//shows window in dependence of nShowCmd; ignored on first call
	UpdateWindow(hwnd);				//updates client area of window
	SetFocus(hwnd);					//sets keyboard focus to window
	ShowCursor(false);				//hide window cursor
	RECT rcwindow = {100, 100, 700, 500};
	ClipCursor(&rcwindow);			//restrict cursor area (or invisible cursor can move outside of window)

	//---- operating system check ------------------------------------------------------------------------------

	HMODULE user32	= LoadLibrary("user32.dll");
	if (!user32)
	{
		gf_logger(false, "winmain LoadLibrary(\"user32.dll\") FAILED");
	}
	else
	{
		gf_logger(false, "winmain LoadLibrary(\"user32.dll\") DONE");
		if (FreeLibrary(user32))
			gf_logger(false, "winmain FreeLibrary(\"user32.dll\") DONE");
		else
			gf_logger(true, "winmain FreeLibrary(\"user32.dll\") FAILED");
	}

	//----------------------------------------------------------------------------------------------------------

	//--------------------------------------------------------------------------------------------
	//
	//	master_frame
	//
	//--------------------------------------------------------------------------------------------

	//!!
	if (MF_STACK)
	{
		gf_logger(false, "MF_STACK: true");

		//master frame object for gameloop
		master_frame		mf(hwnd);

		//master frame initialization
		if (!mf.mf_initialization())
		{
			gf_logger(true, "winmain mf_initialization failed");

			//destroy window
			DestroyWindow(hwnd);

			return(1);
		}

		//run mainloop
		mf.mainloop();
	}
	else
	//!!
	{
		gf_logger(false, "MF_STACK: false");

		//create master_frame pointer and allocate object
		master_frame *pmf = new master_frame(hwnd);

		//master frame initialization
		if (!pmf->mf_initialization())
		{
			gf_logger(true, "winmain mf_initialization failed");

			//destroy window
			DestroyWindow(hwnd);

			return(1);
		}

		//run mainloop
		pmf->mainloop();

		//delete allocated object and set pointer NULL
		delete pmf;
		pmf		= NULL;
	}

	//dump text file logging unfreed memory when debug
#ifdef MEMORY_LEAK_TRACKER
	//create log folder
	_mkdir("log");
	DumpUnfreed();
#endif

	//close all open files
	if (int i = fcloseall() > 0)
	{
		gf_logger(true, "%i open file(s) closed", i);
	}

	//when it quits, destroy window
	DestroyWindow(hwnd);

	gf_logger(false, "winmain return");

	return(0);
}

//------------------------------------------------------------------------------------------------
//
//	WndProc
//
//	windows message loop
//
//------------------------------------------------------------------------------------------------

long APIENTRY WndProc(HWND hwnd,
					  UINT message,
					  UINT wParam,
					  LONG lParam)
{
	switch (message)
	{
	case WM_ACTIVATEAPP:
		{
			//if application is deactivated
			if (wParam == FALSE)
			{
				//set application state to INACTIVE
				gAppState = INACTIVE;

				//reset cursor restriction
				ClipCursor(NULL);
			}

			//if application is activated
			if (wParam == TRUE)
			{
				//set application status to REACTIVATED
				gAppState = REACTIVATED;

				//reset cursor restriction
				RECT rcwindow = {100, 100, 700, 500};
				ClipCursor(&rcwindow);
			}

			return(0);
		}

	//refresh window
	case WM_PAINT:
		{
			//gf_logger(true, "--- WM_PAINT ---");
			gAppRefresh	= true;
			return DefWindowProc(hwnd, message, wParam, lParam);
		}

	case WM_DESTROY:
		{
			//reset cursor restriction
			ClipCursor(NULL);

			//open log file if command line argument set
			//no error handling if file doesn't exist
			if (gProgramOptions.open_file_log)
				ShellExecute(NULL, "open", FLOG, NULL, NULL, SW_SHOWNORMAL);
			if (gProgramOptions.open_file_error)
				ShellExecute(NULL, "open", FERROR, NULL, NULL, SW_SHOWNORMAL);
			if (gProgramOptions.open_file_mlog)
				ShellExecute(NULL, "open", FMEMORY, NULL, NULL, SW_SHOWNORMAL);

			//show error message if one exists
			//but not if to already open FERROR
			if (gp_ErrStr && SYS_ERRORM_OP && !gProgramOptions.open_file_error)
				MessageBox(NULL, gp_ErrStr, "Error", MB_OK);
			PostQuitMessage(0);

			return(0);
		}

	default:
		{
			return DefWindowProc(hwnd, message, wParam, lParam);
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	winmain gf_logger
//
//	global logger function
//	writes message into either log.txt file (argument error = false (default))
//  or into error.txt (argument error = true)
//
//------------------------------------------------------------------------------------------------
/*
bool gf_logger(char *p_message_1, char *p_message_2, bool error)
{
	//return false if no message or logger off
	if ((p_message_1 == NULL && p_message_2 == NULL) ||
		gProgramOptions.logger == OFF)
		return false;

	FILE		*f_log;

	//open either log or error file
	if (error)					f_log = fopen(FERROR, "a");
	else						f_log = fopen(FLOG, "a");

	//if file successfully opened
	if (f_log != NULL)
	{
		//get current date and time into buffer
		char b_date[9];
		char b_time[9];
		_strdate(b_date);
		_strtime(b_time);

		//header
		//if log entry
		if (!error)
		{
			//if first entry print header
			if (!gProgramOptions.log_head)
			{
				//write header
				fprintf(f_log, "%s %s %s\n\n", "LOG CREATED:", b_date, b_time);

				//set to true
				gProgramOptions.log_head = true;
			}
		}
		else
		//error entry
		{
			//if first entry print header
			if (!gProgramOptions.err_head)
			{
				//write header
				fprintf(f_log, "%s %s %s\n\n", "ERROR LOG CREATED:", b_date, b_time);

				//set to true
				gProgramOptions.err_head = true;
			}
		}

		//if only one message
		if (p_message_1 == NULL)
			//write time and message
			fprintf(f_log, "%s - %s\n", b_time, p_message_2);
		else
			if (p_message_2 == NULL)
				fprintf(f_log, "%s - %s\n", b_time, p_message_1);
			else
				//both messages
				fprintf(f_log, "%s - %s %s\n", b_time, p_message_1, p_message_2);

		//close file
		fclose(f_log);

		return true;
	}

	//if file couldn't be opened
	return false;
}*/

//------------------------------------------------------------------------------------------------
//
//	winmain gf_logger
//
//	overloaded global logger function
//	writes message into either log.txt file (argument error = false)
//  or into error.txt (argument error = true)
//	little bit more comfortable than the other version
//
//------------------------------------------------------------------------------------------------

bool gf_logger(bool error, char *format, ...)
{
	//return if logger off
	if (gProgramOptions.logger == OFF)
		return false;

	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	FILE		*f_log;

	//open either log or error file
	if (error)
	{
		f_log = fopen(FERROR, "a");
		//assign string to error message box to show that something has been
		//written into the error log at the end of the program
		gp_ErrStr = FERROR;
	}
	else
	{
		f_log = fopen(FLOG, "a");
	}

	//if file successfully opened
	if (f_log != NULL)
	{
		//get current date and time into buffer
		char b_date[9]				= {0};
		char b_time[9]				= {0};
//		static char b_time_last[9]	= {0};
		_strdate(b_date);
		_strtime(b_time);

/*		//if last time index and current time index the same (or error message)
		//overwrite time index
		if (!strcmp(b_time, b_time_last) && !error)
		{
			strcpy(b_time, "        ");
		}
		else
			strcpy(b_time_last, b_time);*/

		//header
		//if log entry
		if (!error)
		{
			//if first entry print header
			if (!gProgramOptions.log_head)
			{
				//write header
				fprintf(f_log, "%s %s %s\n\n", "LOG CREATED:", b_date, b_time);

				//set to true
				gProgramOptions.log_head = true;
			}
		}
		else
		//error entry
		{
			//if first entry print header
			if (!gProgramOptions.err_head)
			{
				//write header
				fprintf(f_log, "%s %s %s\n\n", "ERROR LOG CREATED:", b_date, b_time);

				//set to true
				gProgramOptions.err_head = true;
			}
		}

		//print time index
		fprintf(f_log, "%s - ", b_time);

		//holds formatted message
		char buffer[2048] = "";
		//copy message into buffer
		vsprintf(buffer, format, ap);
		//print message into file
		fprintf(f_log, "%s", buffer);
		//new line
		fprintf(f_log, "\n");

		//close file
		fclose(f_log);

		//clear up
		va_end(ap);

		return true;
	}

	//if file couldn't be opened clear up and return false
	va_end(ap);
	return false;
}
