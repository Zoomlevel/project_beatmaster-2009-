//------------------------------------------------------------------------------------------------
//
//	bot class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef BOT_H
#define BOT_H								//begin BOT_H

//---- includes ----------------------------------------------------------------------------------

#include "player.h"							//player class

//---- defines -----------------------------------------------------------------------------------

//default bot action queue file
#define	F_BAQDEFAULT			"bot/default.dat"
//auto save queues for both bots
#define F_BAQAUTOSAVE_1			"bot/autosave_1.dat"
#define F_BAQAUTOSAVE_2			"bot/autosave_2.dat"

//time to save action in seconds
#define BAQ_AUTOSAVE_INTERVAL	5.0f			//0 = off

//bot_action_processor
#define MAXRECLENGTH			15.0f			//maximum recording length in seconds

#define CQVERSION				1				//current queue save/load version

/*		format version 1:

		number of events
			time after last event, angle, angle_180, distance
			number of states for event
				action_index, state
				action_index, state
				action_index, state
			time after last event, angle, angle_180, distance
			number of states for event
				action_index, state
				action_index, state
				action_index, state

		bot_action_queue.elements
			bot_queue_event.t_, bot_queue_event.angle, bot_queue_event.angle_180, bot_queue_event.distance
			bot_queue_event.elements
				bot_queue_event_state.action_index,	bot_queue_event_state.state
				bot_queue_event_state.action_index,	bot_queue_event_state.state
*/

//---- error message strings ---------------------------------------------------------------------

extern const char *gp_ErrStr;					//global error string, in winmain.cpp

//const char Err_DIDirectInputCreateEx[]		= "DirectInputCreateEx FAILED";
//const char Err_DICreateDeviceExKB[]			= "DI_CreateDeviceEx_KB FAILED";

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//------------------------------------------------------------------------------------------------

class bot
{
//------------------------------------------------------------------------------------------------
//	private bot objects
//------------------------------------------------------------------------------------------------

private:

	//---- timer/option data ---------------------------------------------------------------------

	const options	*p_option;						//pointer to options
	const timer		*p_time;						//pointer to timer
	float			t_sca_sf;						//passed time adjusted to subframes

	LONGLONG		t_lastupdate;					//time index of last update

	player			*p_P;							//pointer to player
	inputstate		*p_is;							//pointer to inputstate

//------------------------------------------------------------------------------------------------
//	private bot functions
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//	public bot objects
//------------------------------------------------------------------------------------------------

public:

	//---- general program data ------------------------------------------------------------------

	int						id;							//bot id (0 = player 1, 1 = player 2)

	//---- game logic data -----------------------------------------------------------------------

	//

	//---- bot_action_processor data -------------------------------------------------------------

	bot_action_queue		*p_queue;					//pointer to array of bot_action_queue
	int						elements;					//number of elements
	int						PAC[NPAN];					//player action state flag array
														//holds last registered state
														//to check if player PA changed and
														//to record this change
	int						PAY[NPAN];					//player action state flag array
														//holds last replayed PA state
														//to assign to player PA

	bool					recording;					//recording state
	bool					replaying;					//replaying state

	int						rec_queue;					//queue id for recording and replaying
	int						rep_queue;
	int						rep_eposi;					//queue event play index
	int						rec_id;						//player id for recording

	LONGLONG				t_recstart;					//time of record start
	LONGLONG				t_repstart;					//time of replay start

	LONGLONG				t_lastautosave;				//time stamp of last autosave

	LONGLONG				t_lastrec;					//time index of last recorded event
	LONGLONG				t_lastrep;					//time index of last replay event

	LONGLONG				t_walk_start[2];			//start time of walking, relative (for replaying)
														//0 = fwd, 1 = bwd

	//---- console variables ---------------------------------------------------------------------

	char							con_dumpmessage[CON_LINEMAX];	//console dump message

	CLASS_CON_VAR(bool, active);						//true if bot is active

	//---- hud text data -------------------------------------------------------------------------

	hud_text		*p_hud_text;						//pointer to hud text

	//---- developer data ------------------------------------------------------------------------

	int								dev_i;						//can be filled with various data
	float							dev_f;						//just used to check certain values

	int								*dev_pi;
	float							*dev_pf;

//------------------------------------------------------------------------------------------------
//	public bot functions
//------------------------------------------------------------------------------------------------

	//constructor
	bot();

	//cleanup
	void bot_cleanup();

	//reset values before new round
	void reset();

	//bot initialization
	bool bot_initialization(int _bot);

	//set pointer to timer and option data
	void set_data_pointer(options *_options, timer *_timer, hud_text *_hud, player *_player, inputstate *_is);

	//--------------------------------------------------------------------------------------------

	//toggle bot on and off
	void toggle_bot();

	//returns true if to process bot
	//processed option.data.bot_tick times per second
	bool check_update();

	//process bot logic
	void process();

	//---- bot_action_processor functions --------------------------------------------------------

	//add action queue
	//returns false if allocation failed
	bool add_queue();

	//appends queue to another queue
	bool append_queue(bot_action_queue *p_qdest,	//pointer to queue getting p_qsource appended
					  bot_action_queue *p_qsource,	//pointer to queue appended to p_qdest
					  float t_offset = 0.5f);		//time offset between the two queues

	//start recording
	bool mr_start_record(int queue_id,					//index of queue to hold recording
						 int player,					//player to record
						 bool reset = true,				//if queue already exists reset
														//deletes the old data
														//else the new recording data is appended
						 float t_offset = 0.5f);		//if reset false the time offset to the
														//previous data

	//stop recording
	bool mr_stop_record();

	//actual recording
	//returns false if failed to allocate new event/data
	bool mr_record();

	//start replaying
	bool mr_start_replay(int queue_id);				//index of queue which holds replay
													//replays always only on himself

	//stop replaying
	bool mr_stop_replay();

	//actual replaying
	void mr_replay();

	//mirrors angle to other side, per reference
	void mirror_angle(int &angle);

	//saves argumented queue in argumented file
	bool save_queue(int q_id, char *pcfile);

	//loads queues from argumented file
	bool load_queue(char *pcfile);

	//reset timers if game was paused
	void reset_timers();

	//---- console -------------------------------------------------------------------------------

	//registers console variable
	void RegisterConVars(console *pcon);

	//dumps message in console
	void con_add_message(char *format, ...);

	//clear console message string
	void con_clear();

	//---- hud text ------------------------------------------------------------------------------

	//writes message on hud
	void hud_add_message(int _hud_id, int color, char *format, ...);
	void hud_add_message(char *format, ...);

	//---- elemantary routines -------------------------------------------------------------------
	//!!

	/*
	//converts float into string which gets stored in argumented character array
	//(number as double because float seems unsupported by va_arg and co.)
	void float_string(char numberstring[], int precision, double number);

	//sorts a given float array
	void quicksort(float data[],			//array with data
				   int l,					//always 0, left border index of array
				   int r,					//right border index of array (including 0)
				   int order = 0);			//0 = lowest to largest, 1 = largest to lowest
	*/
};

#endif										//end BOT_H
