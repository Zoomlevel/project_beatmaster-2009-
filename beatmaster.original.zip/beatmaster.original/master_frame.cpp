//------------------------------------------------------------------------------------------------
//
//	master_frame class definition
//
//------------------------------------------------------------------------------------------------

#include "master_frame.h"					//class declaration header

//------------------------------------------------------------------------------------------------
//
//	master_frame constructor
//
//------------------------------------------------------------------------------------------------

master_frame::master_frame(HWND hwnd)
{
	//assign window handle
	master_frame::hwnd		= hwnd;

	program_active			= true;
	if (DEVELOPER_)
		program_state		= DEVELOPER;
	else
		program_state		= STARTUP;

	//assign version number (#defined)
	version					= VERSION;

	//--------------------------------------------------------------------------------------------

	//pointer to locale info string
	LPTSTR lpLCData		= NULL;
	//get size of abbreviated info string
	int size			= GetLocaleInfo(LOCALE_SYSTEM_DEFAULT, LOCALE_SABBREVLANGNAME, lpLCData, 0);
	if (size > 0)
	{
		//create info string buffer
		lpLCData = new char[sizeof(char) * size];

		if (lpLCData != NULL)
		{
			//get info string
			int res = GetLocaleInfo(LOCALE_SYSTEM_DEFAULT, LOCALE_SABBREVLANGNAME, lpLCData, size);
			gf_logger(false, "master_frame::master_frame GetLocaleInfo \"%s\"", lpLCData);

			//compare strings
			if (!MINE)
				option.data.pal = 1;
			for (int i = 0; i < size; ++i)
				if (lpLCData[i] != LOCALE_GER[i])
				{
					option.data.pal = 0;
					break;
				}
			if (option.data.pal)		gf_logger(false, "master_frame::master_frame PAL System set");
			else						gf_logger(false, "master_frame::master_frame NonPAL System set");

			delete [] lpLCData;
		}
		else
			gf_logger(true, "master_frame::master_frame allocate locale info string buffer FAILED");
	}
	else
		gf_logger(true, "master_frame::master_frame GetLocaleInfo size 0");
	
	//--------------------------------------------------------------------------------------------

	//reset blurcounter
	dd_blurcounter			= 0;

	//clear soundbufferflags and pan
//!	ZeroMemory(&sbf, sizeof(sbf));
	s_lastpan				= 0;

	//set shadow data
	s_mpy					= S_FLOOR;

	//player distance
	player_distance			= 0;

	//---- set player data -----------------------------------------------------------------------

	pd.set_player_data(&host_id,
					   &s_scale, &s_mpy,
					   &P[P1].sk, &P[P2].sk,
					   &P[P1].sk.r_hbp, &P[P2].sk.r_hbp,
					   data_ig.gl_winpoints,
					   data_ig.rts, &data_ig.roundtime,
					   &P[P1].gl_score, &P[P2].gl_score,
					   &P[P1].fatigue, &P[P2].fatigue,
					   P[P1].blood_active, P[P2].blood_active,
					   P[P1].blood_fx, P[P2].blood_fx,
					   P[P1].blood_size, P[P2].blood_size,
					   &P[P1].sk.chead, &P[P2].sk.chead,
					   &P[P1].sk.cfistl, &P[P1].sk.cfistr,
					   &P[P2].sk.cfistl, &P[P2].sk.cfistr,
					   &P[P1].side, &P[P2].side,
					   &P[P1].stance_feet, &P[P2].stance_feet,
					   &P[P1].pmessage, &P[P2].pmessage,
					   &BOT[B1].active, &BOT[B2].active);

	//---- set animation file names --------------------------------------------------------------

	panmnfile[0][AN_DEFAULT]			= "animation/00_default.amn";
	panmnfile[0][AN_HIT]				= "animation/00_hit.amn";
	panmnfile[0][AN_IDLE_HI]			= "animation/00_idle_hi.amn";
	panmnfile[0][AN_IDLE_LO]			= "animation/00_idle_lo.amn";
	panmnfile[0][AN_IDLE_SETS]			= "animation/00_idle_sets.amn";
	panmnfile[0][AN_STANCE_ARMS]		= "animation/00_stance_arms.amn";
	panmnfile[0][AN_STANCE_FEET]		= "animation/00_stance_feet.amn";
	panmnfile[0][AN_CHANGE_SIDE]		= "animation/00_change_side.amn";
	panmnfile[0][AN_WALK_FWD]			= "animation/00_walk_fwd.amn";
	panmnfile[0][AN_WALK_BWD]			= "animation/00_walk_bwd.amn";
	panmnfile[0][AN_WALK_SLIDE_FWD]		= "animation/00_walk_slide_fwd.amn";
	panmnfile[0][AN_WALK_SLIDE_BWD]		= "animation/00_walk_slide_bwd.amn";
	panmnfile[0][AN_JAB]				= "animation/00_jab.amn";
	panmnfile[0][AN_JAB_HOOK]			= "animation/00_jab_hook.amn";
	panmnfile[0][AN_CROSS]				= "animation/00_cross.amn";
	panmnfile[0][AN_CROSS_HOOK]			= "animation/00_cross_hook.amn";
	panmnfile[0][AN_KICK_FWD]			= "animation/00_kick_fwd.amn";
	panmnfile[0][AN_KICK_KNEE]			= "animation/00_kick_knee.amn";
	panmnfile[0][AN_KICK_SWD]			= "animation/00_kick_swd.amn";
	panmnfile[0][AN_KICK_SWD_HI]		= "animation/00_kick_swd_hi.amn";
	panmnfile[0][AN_DEFEND]				= "animation/00_defend.amn";
	panmnfile[0][AN_EVADE_HI]			= "animation/00_evade_hi.amn";
	panmnfile[0][AN_EVADE_LO]			= "animation/00_evade_lo.amn";
	panmnfile[0][AN_DUCK]				= "animation/00_duck.amn";
	panmnfile[0][AN_EVADE_HI_HOLD]		= "animation/00_evade_hi_hold.amn";
	panmnfile[0][AN_EVADE_LO_HOLD]		= "animation/00_evade_lo_hold.amn";
	panmnfile[0][AN_DUCK_HOLD]			= "animation/00_duck_hold.amn";
	panmnfile[0][AN_TAP_ARMS]			= "animation/00_tap_arms.amn";
	panmnfile[0][AN_TAP_ARMS_SET]		= "animation/00_tap_arms_set.amn";
	panmnfile[0][AN_TAP_LEG]			= "animation/00_tap_leg.amn";
	panmnfile[0][AN_GUARD_ARMS]			= "animation/00_guard_arms.amn";
	panmnfile[0][AN_GUARD_LEGS]			= "animation/00_guard_legs.amn";
	panmnfile[0][AN_GUARD_FULL]			= "animation/00_guard_full.amn";
	panmnfile[0][AN_PUSH_ARMS]			= "animation/00_push_arms.amn";
	panmnfile[0][AN_PULL_ARMS]			= "animation/00_pull_arms.amn";
	panmnfile[0][AN_TAUNT1]				= "animation/00_taunt1.amn";
	panmnfile[0][AN_TAUNT2]				= "animation/00_taunt2.amn";
	panmnfile[0][AN_TAUNT2]				= "animation/00_taunt2.amn";
	panmnfile[0][AN_TAUNT2]				= "animation/00_taunt2.amn";
	panmnfile[0][AN_KNOCKOUT]			= "animation/00_knockout.amn";

	panmnfile[1][AN_DEFAULT]			= "animation/01_default.amn";
	panmnfile[1][AN_HIT]				= "animation/01_hit.amn";
	panmnfile[1][AN_IDLE_HI]			= "animation/01_idle_hi.amn";
	panmnfile[1][AN_IDLE_LO]			= "animation/01_idle_lo.amn";
	panmnfile[1][AN_IDLE_SETS]			= "animation/01_idle_sets.amn";
	panmnfile[1][AN_STANCE_ARMS]		= "animation/01_stance_arms.amn";
	panmnfile[1][AN_STANCE_FEET]		= "animation/01_stance_feet.amn";
	panmnfile[1][AN_CHANGE_SIDE]		= "animation/01_change_side.amn";
	panmnfile[1][AN_WALK_FWD]			= "animation/01_walk_fwd.amn";
	panmnfile[1][AN_WALK_BWD]			= "animation/01_walk_bwd.amn";
	panmnfile[1][AN_WALK_SLIDE_FWD]		= "animation/01_walk_slide_fwd.amn";
	panmnfile[1][AN_WALK_SLIDE_BWD]		= "animation/01_walk_slide_bwd.amn";
	panmnfile[1][AN_JAB]				= "animation/01_jab.amn";
	panmnfile[1][AN_JAB_HOOK]			= "animation/01_jab_hook.amn";
	panmnfile[1][AN_CROSS]				= "animation/01_cross.amn";
	panmnfile[1][AN_CROSS_HOOK]			= "animation/01_cross_hook.amn";
	panmnfile[1][AN_KICK_FWD]			= "animation/01_kick_fwd.amn";
	panmnfile[1][AN_KICK_KNEE]			= "animation/01_kick_knee.amn";
	panmnfile[1][AN_KICK_SWD]			= "animation/01_kick_swd.amn";
	panmnfile[1][AN_KICK_SWD_HI]		= "animation/01_kick_swd_hi.amn";
	panmnfile[1][AN_DEFEND]				= "animation/01_defend.amn";
	panmnfile[1][AN_EVADE_HI]			= "animation/01_evade_hi.amn";
	panmnfile[1][AN_EVADE_LO]			= "animation/01_evade_lo.amn";
	panmnfile[1][AN_DUCK]				= "animation/01_duck.amn";
	panmnfile[1][AN_EVADE_HI_HOLD]		= "animation/01_evade_hi_hold.amn";
	panmnfile[1][AN_EVADE_LO_HOLD]		= "animation/01_evade_lo_hold.amn";
	panmnfile[1][AN_DUCK_HOLD]			= "animation/01_duck_hold.amn";
	panmnfile[1][AN_TAP_ARMS]			= "animation/01_tap_arms.amn";
	panmnfile[1][AN_TAP_ARMS_SET]		= "animation/01_tap_arms_set.amn";
	panmnfile[1][AN_TAP_LEG]			= "animation/01_tap_leg.amn";
	panmnfile[1][AN_GUARD_ARMS]			= "animation/01_guard_arms.amn";
	panmnfile[1][AN_GUARD_LEGS]			= "animation/01_guard_legs.amn";
	panmnfile[1][AN_GUARD_FULL]			= "animation/01_guard_full.amn";
	panmnfile[1][AN_PUSH_ARMS]			= "animation/01_push_arms.amn";
	panmnfile[1][AN_PULL_ARMS]			= "animation/01_pull_arms.amn";
	panmnfile[1][AN_TAUNT1]				= "animation/01_taunt1.amn";
	panmnfile[1][AN_TAUNT2]				= "animation/01_taunt2.amn";
	panmnfile[1][AN_KNOCKOUT]			= "animation/01_knockout.amn";

	panmnfile[2][AN_DEFAULT]			= "animation/02_default.amn";
	panmnfile[2][AN_HIT]				= "animation/02_hit.amn";
	panmnfile[2][AN_IDLE_HI]			= "animation/02_idle_hi.amn";
	panmnfile[2][AN_IDLE_LO]			= "animation/02_idle_lo.amn";
	panmnfile[2][AN_IDLE_SETS]			= "animation/02_idle_sets.amn";
	panmnfile[2][AN_STANCE_ARMS]		= "animation/02_stance_arms.amn";
	panmnfile[2][AN_STANCE_FEET]		= "animation/02_stance_feet.amn";
	panmnfile[2][AN_CHANGE_SIDE]		= "animation/02_change_side.amn";
	panmnfile[2][AN_WALK_FWD]			= "animation/02_walk_fwd.amn";
	panmnfile[2][AN_WALK_BWD]			= "animation/02_walk_bwd.amn";
	panmnfile[2][AN_WALK_SLIDE_FWD]		= "animation/02_walk_slide_fwd.amn";
	panmnfile[2][AN_WALK_SLIDE_BWD]		= "animation/02_walk_slide_bwd.amn";
	panmnfile[2][AN_JAB]				= "animation/02_jab.amn";
	panmnfile[2][AN_JAB_HOOK]			= "animation/02_jab_hook.amn";
	panmnfile[2][AN_CROSS]				= "animation/02_cross.amn";
	panmnfile[2][AN_CROSS_HOOK]			= "animation/02_cross_hook.amn";
	panmnfile[2][AN_KICK_FWD]			= "animation/02_kick_fwd.amn";
	panmnfile[2][AN_KICK_KNEE]			= "animation/02_kick_knee.amn";
	panmnfile[2][AN_KICK_SWD]			= "animation/02_kick_swd.amn";
	panmnfile[2][AN_KICK_SWD_HI]		= "animation/02_kick_swd_hi.amn";
	panmnfile[2][AN_DEFEND]				= "animation/02_defend.amn";
	panmnfile[2][AN_EVADE_HI]			= "animation/02_evade_hi.amn";
	panmnfile[2][AN_EVADE_LO]			= "animation/02_evade_lo.amn";
	panmnfile[2][AN_EVADE_HI_HOLD]		= "animation/02_evade_hi_hold.amn";
	panmnfile[2][AN_EVADE_LO_HOLD]		= "animation/02_evade_lo_hold.amn";
	panmnfile[2][AN_DUCK_HOLD]			= "animation/02_duck_hold.amn";
	panmnfile[2][AN_DUCK]				= "animation/02_duck.amn";
	panmnfile[2][AN_TAP_ARMS]			= "animation/02_tap_arms.amn";
	panmnfile[2][AN_TAP_ARMS_SET]		= "animation/02_tap_arms_set.amn";
	panmnfile[2][AN_TAP_LEG]			= "animation/02_tap_leg.amn";
	panmnfile[2][AN_GUARD_ARMS]			= "animation/02_guard_arms.amn";
	panmnfile[2][AN_GUARD_LEGS]			= "animation/02_guard_legs.amn";
	panmnfile[2][AN_GUARD_FULL]			= "animation/02_guard_full.amn";
	panmnfile[2][AN_PUSH_ARMS]			= "animation/02_push_arms.amn";
	panmnfile[2][AN_PULL_ARMS]			= "animation/02_pull_arms.amn";
	panmnfile[2][AN_TAUNT1]				= "animation/02_taunt1.amn";
	panmnfile[2][AN_TAUNT2]				= "animation/02_taunt2.amn";
	panmnfile[2][AN_KNOCKOUT]			= "animation/02_knockout.amn";

	panmnfile[3][AN_DEFAULT]			= "animation/03_default.amn";
	panmnfile[3][AN_HIT]				= "animation/03_hit.amn";
	panmnfile[3][AN_IDLE_HI]			= "animation/03_idle_hi.amn";
	panmnfile[3][AN_IDLE_LO]			= "animation/03_idle_lo.amn";
	panmnfile[3][AN_IDLE_SETS]			= "animation/03_idle_sets.amn";
	panmnfile[3][AN_STANCE_ARMS]		= "animation/03_stance_arms.amn";
	panmnfile[3][AN_STANCE_FEET]		= "animation/03_stance_feet.amn";
	panmnfile[3][AN_CHANGE_SIDE]		= "animation/03_change_side.amn";
	panmnfile[3][AN_WALK_FWD]			= "animation/03_walk_fwd.amn";
	panmnfile[3][AN_WALK_BWD]			= "animation/03_walk_bwd.amn";
	panmnfile[3][AN_WALK_SLIDE_FWD]		= "animation/03_walk_slide_fwd.amn";
	panmnfile[3][AN_WALK_SLIDE_BWD]		= "animation/03_walk_slide_bwd.amn";
	panmnfile[3][AN_JAB]				= "animation/03_jab.amn";
	panmnfile[3][AN_JAB_HOOK]			= "animation/03_jab_hook.amn";
	panmnfile[3][AN_CROSS]				= "animation/03_cross.amn";
	panmnfile[3][AN_CROSS_HOOK]			= "animation/03_cross_hook.amn";
	panmnfile[3][AN_KICK_FWD]			= "animation/03_kick_fwd.amn";
	panmnfile[3][AN_KICK_KNEE]			= "animation/03_kick_knee.amn";
	panmnfile[3][AN_KICK_SWD]			= "animation/03_kick_swd.amn";
	panmnfile[3][AN_KICK_SWD_HI]		= "animation/03_kick_swd_hi.amn";
	panmnfile[3][AN_DEFEND]				= "animation/03_defend.amn";
	panmnfile[3][AN_EVADE_HI]			= "animation/03_evade_hi.amn";
	panmnfile[3][AN_EVADE_LO]			= "animation/03_evade_lo.amn";
	panmnfile[3][AN_DUCK]				= "animation/03_duck.amn";
	panmnfile[3][AN_EVADE_HI_HOLD]		= "animation/03_evade_hi_hold.amn";
	panmnfile[3][AN_EVADE_LO_HOLD]		= "animation/03_evade_lo_hold.amn";
	panmnfile[3][AN_DUCK_HOLD]			= "animation/03_duck_hold.amn";
	panmnfile[3][AN_TAP_ARMS]			= "animation/03_tap_arms.amn";
	panmnfile[3][AN_TAP_ARMS_SET]		= "animation/03_tap_arms_set.amn";
	panmnfile[3][AN_TAP_LEG]			= "animation/03_tap_leg.amn";
	panmnfile[3][AN_GUARD_ARMS]			= "animation/03_guard_arms.amn";
	panmnfile[3][AN_GUARD_LEGS]			= "animation/03_guard_legs.amn";
	panmnfile[3][AN_GUARD_FULL]			= "animation/03_guard_full.amn";
	panmnfile[3][AN_PUSH_ARMS]			= "animation/03_push_arms.amn";
	panmnfile[3][AN_PULL_ARMS]			= "animation/03_pull_arms.amn";
	panmnfile[3][AN_TAUNT1]				= "animation/03_taunt1.amn";
	panmnfile[3][AN_TAUNT2]				= "animation/03_taunt2.amn";
	panmnfile[3][AN_KNOCKOUT]			= "animation/03_knockout.amn";

	//---- demo/recorder data ---------------------------------------------------------------------

	demo_record				= false;
	demo_playback			= false;
	f_demo_rec				= NULL;
	f_demo_pb				= NULL;
	demo_fps				= 0;
	t_drec_start			= 0;
	t_drec_lastframe		= 0;
	t_dpb_start				= 0;
	t_dpb_lastframe			= 0;

	//---- console -------------------------------------------------------------------------------

	//clear console message buffer
	con_clear();

	//---- hud data ------------------------------------------------------------------------------

	hud_text[0].rdim.left			= 0;	hud_text[0].rdim.right		= 399;
	hud_text[0].rdim.top			= 75;	hud_text[0].rdim.bottom		= 525;
	hud_text[1].rdim.left			= 400;	hud_text[1].rdim.right		= 799;
	hud_text[1].rdim.top			= 75;	hud_text[1].rdim.bottom		= 525;

	//pointer to console and current time
	hud_text[0].p_con				= &con;
	hud_text[1].p_con				= &con;
	hud_text[0].p_tcurrent			= &time.current;
	hud_text[1].p_tcurrent			= &time.current;

	//---- developer data ------------------------------------------------------------------------

	//modes
	dev_s_showdata			= true;
	dev_s_devmode			= true;
	dev_s_showref			= true;
	dev_s_animate			= false;
	dev_s_ai				= false;

	//bone indices
	dev_bi[0] = dev_bi[1]	= 0;
	dev_ckf					= 0;
	dev_cai					= 0;

	gf_logger(false, "master_frame::master_frame done");
}

//------------------------------------------------------------------------------------------------
//
//	master_frame initialization
//
//------------------------------------------------------------------------------------------------

bool master_frame::mf_initialization()
{
	//---- console data --------------------------------------------------------------------------

	//pointers to data
	con.assign_pointers(&option.data.con_color, &option.data.con_fcolor, &option.data.con_textcolor,
						&option.data.con_frame, &option.data.con_dropspeed, &option.data.con_style,
						&option.data.con_dim,
						this, &dd, &di, &ds);

	con.init(&con);

	gProgramOptions.RegisterConVars(&con);				//global program options
	RegisterConVars(&con);								//master_frame
	dd.RegisterConVars(&con);							//direct draw
//	di.RegisterConVars(&con);							//direct input
	ds.RegisterConVars(&con);							//direct sound
	P[P1].RegisterConVars(&con);						//player 1 and 2
	P[P2].RegisterConVars(&con);
	BOT[B1].RegisterConVars(&con);						//bots
	BOT[B2].RegisterConVars(&con);
	option.data.RegisterConVars(&con);					//options, for data only, not for DEF, MAX and MIN

	//set fps_max
	time.set_fps_max(option.data.fps_max);
	//set program start time
	time.set_program_starttime();

	//---- directdraw setup ----------------------------------------------------------------------

	//set timer/option/hud data pointer
	//(for right dd initialization either fullscreen or windowed according to option file)
	dd.set_data_pointer(&option, &time, hud_text);

	//if directdraw setup fails, it cleans itself up
	if (!dd.dd_initialization(hwnd))
	{
		gf_logger(true, "master_frame::mf_initialization dd.dd_initialization failed");
		return false;
	}
	else
		gf_logger(false, "master_frame::mf_initialization dd.dd_initialization done");

/*	//change to windowed mode if fullscreen in config
	if (!option.data.fullscreen)
		if (!ChangeScreenMode())
		{
			gf_logger(true, "master_frame::mf_initialization ChangeScreenMode FAILED");
			program_active	= false;
		}
		else
		{
			if (option.data.fullscreen)
				hud_add_message(0, bmfblack, "Fullscreen Mode Set");
			else
				hud_add_message(0, bmfblack, "Window Mode Set");
		}*/

	//---- directinput setup ---------------------------------------------------------------------

	//if no system mouse is found, program exits
	//if only system mouse is found and no other usb-mice or if system mouse
	//is found and only one usb-mouse, set option.data/DEF.mouseflag to 0
	//and use system mouse as gaming mouse
	//return values: 0 = ok, 1 = error (ex: no system mouse)

	//flags as reference
	int result = di.di_initialization(hwnd, option);

	//error
	if (result == 1)
	{
		gf_logger(true, "master_frame::mf_initialization di.di_initialization FAILED");
		return false;
	}
	else
		gf_logger(false, "master_frame::mf_initialization di.di_initialization DONE");

	//initialize is (inputstate) with timer frequency and input options
	if (!is.initialization(&option, &time, hud_text))
	{
		gf_logger(true, "master_frame::mf_initialization is.initialization FAILED");
		return false;
	}
	gf_logger(false, "master_frame::mf_initialization is.initialization DONE");

	//---- cursor data ---------------------------------------------------------------------------

	//mouse indices is either P1 or P2 mouse (dimouse index 1 or 2)
	//switching mice will therefore affect which cursor is controlled by which player
	mcursor[P1].mouse_index	= 1;
	mcursor[P2].mouse_index	= 2;

	//turn both on
	mcursor[P1].toggle_cursor(1);
	mcursor[P2].toggle_cursor(1);

	//turn collidability on
	mcursor[P1].toggle_collidability(1);
	mcursor[P2].toggle_collidability(1);

	//valid screen area
	mcursor[P1].set_valid_screen(dd.rSCREEN169);
	mcursor[P2].set_valid_screen(dd.rSCREEN169);

	//offscreen surface bitmap containing cursor image
//	mcursor[P1].set_offscreen_rect(780, 0, 791, 19);
//	mcursor[P2].set_offscreen_rect(780, 0, 791, 19);
//	mcursor[P1].set_offscreen_rect(24, 0, 32, 14);
//	mcursor[P2].set_offscreen_rect(278, 0, 286, 14);
	mcursor[P1].set_bm_cursor(bmfwhite);
	mcursor[P2].set_bm_cursor(bmfblack);

	//reset position
	mcursor[P1].set_pos(0, 0);
	mcursor[P2].set_pos(0, 0);

	//yy cursor size
	mcursor[P1].yy.set_size(0.075f);	mcursor[P1].yy_size = 0.075f;
	mcursor[P2].yy.set_size(0.075f);	mcursor[P2].yy_size = 0.075f;
	//yy cursor colors, default and activated
	mcursor[P1].cyidef.setcolor(black);
	mcursor[P1].cyadef.setcolor(white);
	mcursor[P1].cyiact.setcolor(red);
	mcursor[P1].cyaact.setcolor(white);
	mcursor[P2].cyidef.setcolor(blue);
	mcursor[P2].cyadef.setcolor(white);
	mcursor[P2].cyiact.setcolor(yellow);
	mcursor[P2].cyaact.setcolor(white);
	//yy cursor speed
	mcursor[P1].yy.set_speed_data(0, 4000, 45, 10, 50);
	mcursor[P2].yy.set_speed_data(0, 4000, 45, 10, 50);

	//---- directsound setup ---------------------------------------------------------------------

	//set timer/option/hud data pointer
	ds.set_data_pointer(&option, &time, hud_text);

	//directsound is also initialized when data.sound == 0
	//
	//if directsound setup fails, set option data/DEF/ds.sound_sys to zero
	//so no sound is used and continue program
	//(ds.sound_sys/set assures that no sound is played even if specific function is called
	//so if no sound is available or turned off you don't have to take care for it)
	if (!ds.ds_initialization(hwnd))
	{
		gf_logger(true, "master_frame::mf_initialization ds.ds_initialization failed, continue...");
		//option.dataDEF.sound = ds.sound_sys = 0;
		//no system sound available
		option.dataDEF.sound = 0;
	}
	else
	{
		gf_logger(false, "master_frame::mf_initialization ds.ds_initialization done");

		//done in separate function now
		//set pointer to hud
		//ds.p_hud_text		= hud_text;

		//set ds::sound_set to user option
		//ds.sound_set = option.data.sound;
		//set volume
		ds.setvolume(BT_ALL, 0, option.data.volume);
		//set frequency of soundbuffers (system sounds 1.0f default and not adjustable)
		ds.setfrequency(BT_SYS, -1, 1.0f);
		ds.setfrequency(BT_P1, -1, option.data.speed);
		ds.setfrequency(BT_P2, -1, option.data.speed);
		gf_logger(false, "master_frame::mf_initialization ds.setfrequency");

		gf_logger(false, "master_frame::mf_initialization ds.sound_set");
	}

	//---- player setup --------------------------------------------------------------------------

	//set timer and option data
	P[P1].set_data_pointer(&option, &time, hud_text,
						   &rcd,
						   is.mm_angle, is.mm_angle_180,
						   &player_distance);
	P[P2].set_data_pointer(&option, &time, hud_text,
						   &rcd,
						   is.mm_angle, is.mm_angle_180,
						   &player_distance);

	//player as argument
	P[P1].pl_initialization(P1);
	gf_logger(false, "master_frame::mf_initialization P[P1].pl_initialization");
	P[P2].pl_initialization(P2);
	gf_logger(false, "master_frame::mf_initialization P[P2].pl_initialization");

	//set pointers to opponents data
	P[P1].set_opp_data(&P[P2]);
	P[P2].set_opp_data(&P[P1]);

	//load animations, if file(s) not found exit program
	if (load_animations() == false)
	{
		gf_logger(true, "master_frame::mf_initialization load_animations failed");
		return false;
	}
	else
		gf_logger(false, "master_frame::mf_initialization load_animations done");

	//set game logic data
	set_animation_gl_data();
	gf_logger(false, "master_frame::mf_initialization set_animation_gl_data");

	//assign animations to developer pointers
	for (register int i = 0; i < NPAN; ++i)
	{
		p_dev_a[0][i]	= &anmn[0][i];
		p_dev_a[1][i]	= &anmn[1][i];
		p_dev_a[2][i]	= &anmn[2][i];
		p_dev_a[3][i]	= &anmn[3][i];
		
		if (p_dev_a[0][i] == NULL ||
			p_dev_a[1][i] == NULL ||
			p_dev_a[2][i] == NULL ||
			p_dev_a[3][i] == NULL)
		{
			gf_logger(true, "master_frame::mf_initialization p_dev_a failed");
			gp_ErrStr = "p_dev_a";
			return false;
		}
	}

	//set pointers to all animations in both player animators
	for (register int s = 0; s < 4; ++s)
		for (register int i = 0; i < NPAN; ++i)
		{
			P[P1].p_anmn[s][i]	= &anmn[s][i];
			P[P2].p_anmn[s][i]	= &anmn[s][i];
		}

	//!! set walk animation backup data
	//for all keyframes, for all bones and hara, backup t_frame data
	for (register int k = 0; k < 4; ++k)
		for (register int b = 0; b < 21; ++b)
		{
			P[P1].walk_kftb_bwd[k][b]	= P[P1].p_anmn[0][AN_WALK_BWD]->pkf[k].t_frame[b];
			P[P1].walk_kftb_fwd[k][b]	= P[P1].p_anmn[0][AN_WALK_FWD]->pkf[k].t_frame[b];
			P[P2].walk_kftb_bwd[k][b]	= P[P2].p_anmn[0][AN_WALK_BWD]->pkf[k].t_frame[b];
			P[P2].walk_kftb_fwd[k][b]	= P[P2].p_anmn[0][AN_WALK_FWD]->pkf[k].t_frame[b];
		}

	//reset players (for handicap to be applied)
	P[P1].reset(0);
	P[P2].reset(0);

	gf_logger(false, "master_frame::mf_initialization set player animation pointers done");

	//---- bot setup -----------------------------------------------------------------------------
//!!
/*
	hier ist irgendwas kaputt. mit program_state = STARTUP
	gibt es beim beenden eine access-violation, wenn bot_initialization ausgefuehrt wird...
	//!! falsch, wenn bei startup mit f11 programm beendet wird, passiert was falsches beim ~animation destruktor
*/

	//set timer and option data pointer
	BOT[B1].set_data_pointer(&option, &time, hud_text, &P[P1], &is);
	BOT[B2].set_data_pointer(&option, &time, hud_text, &P[P2], &is);

	//initialize both bots
	BOT[B1].bot_initialization(B1);
	gf_logger(false, "master_frame::bot_initialization BOT[B1].bot_initialization");
	BOT[B2].bot_initialization(B2);
	gf_logger(false, "master_frame::bot_initialization BOT[B2].bot_initialization");

	//---- recorder data --------------------------------------------------------------------------

	recorder.set_data_pointer(&time, &option, &P[P1], &P[P2]);

	//---- clear surfaces ------------------------------------------------------------------------

	dd.colorfill();	dd.flip(option.data.vsync);
	dd.colorfill();	dd.flip(option.data.vsync);
	dd.colorfill();	dd.flip(option.data.vsync);

	gf_logger(false, "master_frame::mf_initialization done");
	return true;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cleanup
//
//	calls sub directx cleanups
//
//------------------------------------------------------------------------------------------------

void master_frame::mf_cleanup()
{
	//---- developer cleanup ---------------------------------------------------------------------

	//!!
	for (register int i = 0; i < NPAN; ++i)
	{
//		delete		p_dev_a[P[P1].asi][i];
		p_dev_a[0][i]	= NULL;
		p_dev_a[1][i]	= NULL;
		p_dev_a[2][i]	= NULL;
		p_dev_a[3][i]	= NULL;
	}

	//--------------------------------------------------------------------------------------------

	//particle heap in data_su
	//?? why doesn't the destructor of data_startup work?
	//?? or the one in particle_heap?
	//!! only a problem with debug version, has something to do with memory_leak_tracker?
/*	if (data_su.pfx.pp != NULL)
	{
		delete [] data_su.pfx.pp;
		data_su.pfx.pp	= NULL;
	}*/

	//--------------------------------------------------------------------------------------------

	//directdraw cleanup
	dd.dd_cleanup();

	//directinpu cleanup
	di.di_cleanup();

	//directsound cleanup
	ds.ds_cleanup();

	//player cleanup
	P[P1].pl_cleanup();
	P[P2].pl_cleanup();

	//bot cleanup
	BOT[B1].bot_cleanup();
	BOT[B2].bot_cleanup();

	//close demos file if still open
	if (f_demo_rec)
	{
		fclose(f_demo_rec);
		f_demo_rec			= NULL;
	}
	if (f_demo_pb)
	{
		fclose(f_demo_pb);
		f_demo_pb			= NULL;
	}

	gf_logger(false, "master_frame::cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	master_frame mainloop
//
//
//
//------------------------------------------------------------------------------------------------

void master_frame::mainloop()
{
	//message loop
	while (program_active)
	{
		//reset raw input movement data
		//else last mouse movement data will be kept as last value
		if (INPUTTYPE == IP_RAW)
			is.reset_mouse_mov_data();

		//if there's a message
		while (PeekMessage(&msg,				//pointer to structure for message
						   NULL,				//handle to window
						   0,					//first message
						   0,					//last message
						   PM_REMOVE))			//remove message after processing
		{
			//if message is to quit, exit loop
			if (msg.message == WM_QUIT)
				program_active = false;

			//raw input
			if (msg.message == WM_INPUT && INPUTTYPE == IP_RAW)
				di.RI.get_input(msg, is, option);

			//tranlate and dispatch messaged
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
//		else
		//if there's no message
		{
			//WM_PAINT message, draw scene and flip in windowed mode
			if (gAppRefresh && !option.data.screenmode)
			{
				//dd.drawbackground(255, 0, 0, 1, 0, 1);
				//dd.flip(option.data.vsync);
				//playsound_s(S_ERROR);
//				dd.drawplayers(&pd, option.data.shadows, option.data.bw_mode, 1.0f);
//				dd.flip(1);
				gAppRefresh = false;
			}

			//---- if application inactive -------------------------------------------------------

			if (gAppState == INACTIVE)
			{
				//!!! dann aber nicht der test auf active
/*				//pause game if inactive
				if (program_state == INGAME || program_state == DEVELOPER)
				{
					program_state = PAUSE;
				}*/

				//relinquish the remainder of program time slice 
				Sleep(100);
			}

			//---- if reactivated ----------------------------------------------------------------

			//restore directx if application is reactivated
			if (gAppState == REACTIVATED)
			{
				//set application state to running
				gAppState = ACTIVE;

				//!!!
				//unpause game, re-initialize timer
				if (program_state == PAUSE)
				{
					//program_state = INGAME
				}
				
				//if dd restoring fails
				if (!dd.dd_restore())
				{
					gAppState = INACTIVE;
					program_active = false;
					break;
				}
				//show restored message
				//dd.typefont(640, 8, "DD_RESTORED");
				//dd.typebmf(640, 8, bmfwhite, "DD_RESTORED");
				hud_add_message(0, bmfgreen, "DD_RESTORED");

				//only restores when sound option is on
				if (!ds.ds_restore())
				{
					//if restoring fails, set sound to OFF
					//but continue program
					//option.dataDEF.sound = ds.sound_sys = 0;
					option.dataDEF.sound = 0;

					//dd.typefont(640, 24, "DS_RS FAILED");
					//dd.typebmf(640, 24, bmfred, "DS_RS FAILED");
					hud_add_message(0, bmfred, "DS_RS FAILED");
				}
				else
					//restored message
					//dd.typefont(640, 24, "DS_RESTORED");
					//dd.typebmf(640, 24, bmfwhite, "DS_RESTORED");
					hud_add_message(0, bmfgreen, "DS_RESTORED");

				//reaquire input devices (stores restored messages in argumented pointers)
				char *ptemp1	= NULL;
				char *ptemp2	= NULL;
				di.di_acquire(&ptemp1, &ptemp2, option.dataDEF.mouseflag, option.dataDEF.controllerflag);
				//if (ptemp1 != NULL)			dd.typefont(640, 40, ptemp1);
				//if (ptemp2 != NULL)			dd.typefont(640, 56, ptemp2);
				if (ptemp1 != NULL)
					//dd.typebmf(640, 40, bmfwhite, ptemp1);
					hud_add_message(0, bmfgreen, ptemp1);
				if (ptemp2 != NULL)
					//dd.typebmf(640, 56, bmfwhite, ptemp2);
					hud_add_message(0, bmfgreen, ptemp2);


				//to show restored message
				dd.flip(option.data.vsync);
				//pause to show message
				//Sleep(1000);

				//set start time
				time.set_starttime();

				//update timer so time.sca is reset (difference between now and last update,
				//if we update twice, the difference won't be unrealistic big)
				time.get_tfr();

				//reset hud text start time
				hud_text[0].reset_time();
				hud_text[1].reset_time();
			}

			//------------------------------------------------------------------------------------
			//
			//	if application is ACTIVE
			//
			//------------------------------------------------------------------------------------

			if (gAppState == ACTIVE && !ppause.update())
			{
				//---- timer ---------------------------------------------------------------------

				//update timer including framerate
				time.get_tfr();

				//---- handle input --------------------------------------------------------------

				//inputstate (is) as reference
				di.get_input(is);
				is.process(con.state,
						   P[P1].side, P[P2].side,
						   (int)P[P1].sk.p_ref->v.p[0].x,
						   (int)P[P2].sk.p_ref->v.p[0].x);
				//process sound freq change if ingame speed changed
				ds.freq_process();
				//if teaser delete real input
				if (TEASER_)
				{
/*					//for all keyboard buttons
					for (register int i = 0; i < 256; ++i)
						//except ESC
						if (i != DIK_ESCAPE)
							is.dikey[i] = 0;

					//for all mouse buttons and movement
					for (i = 0; i < 4; ++i)
					{
						is.dimouse[0].rgbButtons[i] = 0;
						is.dimouse[1].rgbButtons[i] = 0;
						is.dimouse[2].rgbButtons[i] = 0;
					}
					//movement
					is.dimouse[0].lX = is.dimouse[0].lY = is.dimouse[0].lZ = 0;
					is.dimouse[1].lX = is.dimouse[1].lY = is.dimouse[1].lZ = 0;
					is.dimouse[2].lX = is.dimouse[2].lY = is.dimouse[2].lZ = 0;*/
					for (register int i = 0; i < NPAC; ++i)
					{
						is.PA[P1][i] = AS_INACTIVE;
						is.PA[P2][i] = AS_INACTIVE;
					}
				}

				//if bot active, cancel players input
				for (register int b = 0; b < 2; ++b)
				{
					if (BOT[b].active)
					{
						ZeroMemory(&is.PA[b], sizeof(is.PA[b]));
						is.t_move[b][0] = is.t_move[b][1]	= 0;
//						for (register int i = 0; i < NPAC; ++i)
//							is.PA[b][i] = AS_INACTIVE;
					}
				}

				//take screenshot
				if (is.COM1D(cSCREENSHOT))
				{
					dd.save_bitmap(data_ig.screenshot_id);
					con_add_message(data_ig.screenshot_id);
					hud_add_message(0, bmfblue, data_ig.screenshot_id);
				}

				//console toggling
				if (gProgramOptions._console && (
					program_state != EXIT &&
					program_state != STARTUP &&
					program_state != CREDITS &&
					program_state != TEASER))
				{
					//toggle
					if (is.key1D(option.data.CBT[cCONSOLE]))
						//pause if console on and ingame/developer
						if (con.toggle_console(!con.state))
							if (program_state == INGAME ||
								program_state == DEVELOPER)
							{
								//is.CS1D[cPAUSE] = 0x80;
							}

					//!! nur der toggle key okay fuer alle arten von keyboards?
					//switch off
//					if (is.key1D(SYS_ESC))
//						con.toggle_console(OFF);
				}
				else
					//switch off if on
					if (con.state)
						con.toggle_console(OFF);
				//process console input/output
				if (con.state || con.moving)
					con.process(is.dikey, is.dikey1D, is.ascii);
				//object console dumps
				con_check_dumpmessages();
				//hud text
				//if (option.data.hud_text)
				{
					hud_text[0].process(option.data.hud_text_time, time.freq);
					hud_text[1].process(option.data.hud_text_time, time.freq);
				}

				//if paused return
//!!				if (ppause.update())
//					break;

				//if gamma fade activated, call appropriate function
				if (dd.gcs.active == true)
					dd.gamma_fade_rt();

//!!!
{
//exit program
if (is.dikey[DIK_F11] & 0x80)
	program_state = EXIT;

//gammaflash
//if (is.dimouse1D[1].rgbButtons[3] & 0x80)
//	dd.gamma_fade_ini(1, 2, red, 0.5f);

//backgroundmusic
/*if (is.dikey1D[DIK_SPACE] & 0x80)
	ds.playbgm();
if (is.dikey1D[DIK_ESCAPE] & 0x80)
	ds.stopbgm(true);*/
}

				//---- program_state -------------------------------------------------------------

				switch (program_state)
				{
				case TEASER:
					{
						//teaser sequence
						teaser();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case STARTUP:
					{
						//startup sequence
						startup();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case TITLE:
					{
						//title sequence
						title();

						//draw hud text if idling
						if (data_ti.state == 3)
							if (option.data.hud_text)
							{
								dd.draw_hud_text(&hud_text[0]);
								dd.draw_hud_text(&hud_text[1]);
							}

						//draw console
						if (gProgramOptions._console)
						{
							dd.draw_console(&con);
							//if (con.state)
							//	process_mousecursor();
						}

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case OPTIONS:
					{
						//options menu
						options();

						//draw hud text
						if (option.data.hud_text)
						{
							dd.draw_hud_text(&hud_text[0]);
							dd.draw_hud_text(&hud_text[1]);
						}

						//draw console
						if (gProgramOptions._console)
						{
							dd.draw_console(&con);
							//if (con.state)
							//	process_mousecursor();
						}

						//show framerate
						dd.FPS_show();

						//vram
						dd.VRAM_show();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case CREDITS:
					{
						//scroll credits
						credits();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case INGAME:
					{
						//redraw background every option.data.blurtime-th frame
						//always redraw upper and lower border
						++dd_blurcounter;
						dd.drawbackground(0, 0, 0, 1, 0, 1);
						if (dd_blurcounter >= option.data.mblur)
						{
							//draw background
							dd.drawbackground(option.data.cbackground.r,
											  option.data.cbackground.g,
											  option.data.cbackground.b,
											  0, 1, 0);

							//reset blurcounter
							dd_blurcounter = 0;
						}

						//check and display change of ingame options
						ingameoptions();

						//run ingame routine
						ingame();

						//------------------------------------------------------------------------

						//in bool directdraw::drawscene() now
/*						//draw player messages if active
						for (register int p = 0; p < 2; ++p)
							for (register int m = 0; m < NPMESSAGES; ++m)
							{
								if (P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].active)
								{
									dd.typefont((int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.x,
												(int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.y,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].message, 0, 0, 1,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].size,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.b,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.b);
								}
							}
*/
						//draw hud text
						if (option.data.hud_text)
						{
							dd.draw_hud_text(&hud_text[0]);
							dd.draw_hud_text(&hud_text[1]);
						}

						//draw console
						if (gProgramOptions._console)
						{
							dd.draw_console(&con);
							//if (con.state)
							//	process_mousecursor();
						}

						//show framerate if on
						dd.FPS_show();

						//vram
						dd.VRAM_show();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case PAUSE:
					{
						//redraw upper and lower border (for fps and ingame options)
						//dd.drawbackground(0, 0, 0, 1, 0, 1);

						//draw background with color bias
						RGBcolor bc(black);
						bc.r	= (int)(0.3 * option.data.cbackground.r + 0.59 * option.data.cbackground.g + 0.11 * option.data.cbackground.b) + data_ig.Pcb.r;
						bc.g	= (int)(0.3 * option.data.cbackground.r + 0.59 * option.data.cbackground.g + 0.11 * option.data.cbackground.b) + data_ig.Pcb.g;
						bc.b	= (int)(0.3 * option.data.cbackground.r + 0.59 * option.data.cbackground.g + 0.11 * option.data.cbackground.b) + data_ig.Pcb.b;
						bc.r > 255 ? bc.r = 255 : bc.r;	bc.g > 255 ? bc.g = 255 : bc.g;		bc.b > 255 ? bc.b = 255 : bc.b;

						dd.drawbackground(bc.r, bc.g, bc.b, 1, 1, 1);

						//show framerate if on
						dd.FPS_show();

						//check and display change of ingame options
						ingameoptions();

						//change color bias on button press
						//(console off)
						if (!con.state)
						{
							if (is.ui(P1, PUNCH) || is.ui(P2, PUNCH))
							{
								if (is.dimouse[0].lY < 0)
									if (data_ig.Pcb.r > 1)			--data_ig.Pcb.r;
									else							data_ig.Pcb.r = 1;
								if (is.dimouse[0].lY > 0)
									if (data_ig.Pcb.r < 255)		++data_ig.Pcb.r;
									else							data_ig.Pcb.r = 255;
							}
							if (is.ui(P1, KICK) || is.ui(P2, KICK))
							{
								if (is.dimouse[0].lY < 0)
									if (data_ig.Pcb.g > 1)			--data_ig.Pcb.g;
									else							data_ig.Pcb.g = 1;
								if (is.dimouse[0].lY > 0)
									if (data_ig.Pcb.g < 255)		++data_ig.Pcb.g;
									else							data_ig.Pcb.g = 255;
							}
							if (is.ui(P1, DEFEND) || is.ui(P2, DEFEND))
							{
								if (is.dimouse[0].lY < 0)
									if (data_ig.Pcb.b > 1)			--data_ig.Pcb.b;
									else							data_ig.Pcb.b = 1;
								if (is.dimouse[0].lY > 0)
									if (data_ig.Pcb.b < 255)		++data_ig.Pcb.b;
									else							data_ig.Pcb.b = 255;
							}
							if (is.ui1D(P1, SPECIAL) || is.ui1D(P2, SPECIAL))
							{
								data_ig.Pcb.r	= 1 + (rand() % (255 - 1 + 1));
								data_ig.Pcb.g	= 1 + (rand() % (255 - 1 + 1));
								data_ig.Pcb.b	= 1 + (rand() % (255 - 1 + 1));
							}

							//hud_text[0].clear();
							//hud_add_message(0, bmfblue, "%i %i %i", data_ig.Pcb.r, data_ig.Pcb.g, data_ig.Pcb.b);
						}

						//dd.typebmf(100, 100, 0, "%i %i %i", data_ig.Pcb.r, data_ig.Pcb.g, data_ig.Pcb.b);

						//if not already initialized
						if (data_ig.f_pause == 0)
						{
							//set to initialized
							data_ig.f_pause = 1;

							//game time
							time.get_program_time();
							con_add_message(time.cptime);
/*							if (time.ph < 10 && time.pm < 10 && time.ps < 10)		con_add_message("0%i:0%i::0%i", time.ph, time.pm, time.ps);
							if (time.ph < 10 && time.pm < 10 && time.ps >= 10)		con_add_message("0%i:0%i::%i", time.ph, time.pm, time.ps);
							if (time.ph < 10 && time.pm >= 10 && time.ps < 10)		con_add_message("0%i:%i::0%i", time.ph, time.pm, time.ps);
							if (time.ph < 10 && time.pm >= 10 && time.ps >= 10)		con_add_message("0%i:%i::%i", time.ph, time.pm, time.ps);
							if (time.ph >= 10 && time.pm < 10 && time.ps < 10)		con_add_message("%i:0%i::0%i", time.ph, time.pm, time.ps);
							if (time.ph >= 10 && time.pm < 10 && time.ps >= 10)		con_add_message("%i:0%i::%i", time.ph, time.pm, time.ps);
							if (time.ph >= 10 && time.pm >= 10 && time.ps < 10)		con_add_message("%i:%i::0%i", time.ph, time.pm, time.ps);
							if (time.ph >= 10 && time.pm >= 10 && time.ps >= 10)	con_add_message("%i:%i::%i", time.ph, time.pm, time.ps);
							*/

							//halt all player sounds
							process_sound(1);

							//random color bias
							data_ig.Pcb.r	= 1 + (rand() % (255 - 1 + 1));
							data_ig.Pcb.g	= 1 + (rand() % (255 - 1 + 1));
							data_ig.Pcb.b	= 1 + (rand() % (255 - 1 + 1));

							/*int r = 0 + (rand() % (255 - 0 + 1));
							int g = 0 + (rand() % (255 - 0 + 1));
							int b = 0 + (rand() % (255 - 0 + 1));

							//for all three buffers
							for (register int i = 0; i < 3; ++i)
							{
								//redraw upper and lower border
								dd.drawbackground(0, 0, 0, 1, 0, 1);

								//type instant pause message
								//this one gets overwritten by pixel filter
								//but for better response print it immediately
								dd.typefont((int)centerfont("PAUSE", dd.rSCREEN, 0.35f).x,
											(int)centerfont("PAUSE", dd.rSCREEN).y, "PAUSE", 0, 0, 1, 0.35f);
								dd.typefont((int)centerfont("PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", dd.rSCREEN, 0.35f).x,
											316, "PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", 0, 0, 1, 0.35f);

								//show framerate
								if (option.data.show_fps == 1)
								{
									dd.typefont(8, 8, "FPS:");	dd.typefont(48, 8, "", time.fps, 0);
								}

								//flip to show pause message
								dd.flip(option.data.vsync);

								//apply grayscale filter if not bw_mode, else negativ filter
								if (option.data.bw_mode == 0)
									//apply grayscale filter to 16:9 area
									dd.pixelfilter(dd.rSCREEN169, 1, r, g, b);
								else
									dd.pixelfilter(dd.rSCREEN169, 0);

								//retype pause message without pixel filter
								dd.typefont((int)centerfont("PAUSE", dd.rSCREEN, 0.35f).x,
											(int)centerfont("PAUSE", dd.rSCREEN).y, "PAUSE", 0, 0, 1, 0.35f);
								dd.typefont((int)centerfont("PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", dd.rSCREEN, 0.35f).x,
											316, "PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", 0, 0, 1, 0.35f);
							}*/
						}

						//render scene with color bias
						dd.drawscene(&pd, 0, 0, black, data_ig.Pcb.r, data_ig.Pcb.g, data_ig.Pcb.b);

						//draw player messages if active
						for (register int p = 0; p < 2; ++p)
							for (register int m = 0; m < NPMESSAGES; ++m)
							{
								if (P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].active)
								{
									dd.typefont((int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.x,
												(int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.y,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].message, 0, 0, 1,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].size,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.b,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.b);
								}
							}

/*						//draw player message if active
						if (P[P1].pmessage.active)
							dd.typefont((int)P[P1].pmessage.pos.x, (int)P[P1].pmessage.pos.y,
										P[P1].pmessage.message, 0, 0, 1, P[P1].pmessage.size,
										P[P1].pmessage.b_color.r, P[P1].pmessage.b_color.g, P[P1].pmessage.b_color.b,
										P[P1].pmessage.f_color.r, P[P1].pmessage.f_color.g, P[P1].pmessage.f_color.b);
						if (P[P2].pmessage.active)
							dd.typefont((int)P[P2].pmessage.pos.x, (int)P[P2].pmessage.pos.y,
										P[P2].pmessage.message, 0, 0, 1, P[P2].pmessage.size,
										P[P2].pmessage.b_color.r, P[P2].pmessage.b_color.g, P[P2].pmessage.b_color.b,
										P[P2].pmessage.f_color.r, P[P2].pmessage.f_color.g, P[P2].pmessage.f_color.b);*/

						//type pause message
//!!						dd.typefont((int)centerfont("PAUSE", dd.rSCREEN, 0.35f).x,
//									(int)centerfont("PAUSE", dd.rSCREEN).y, "PAUSE", 0, 0, 1, 0.35f);
//						dd.typefont((int)centerfont("PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", dd.rSCREEN, 0.35f).x,
//									316, "PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", 0, 0, 1, 0.35f);
						dd.typefont((int)centerfont("PAUSE", dd.rSCREEN, 0.35f).x,
									540, "PAUSE", 0, 0, 1, 0.35f, 0, 0, 0, 255, 50, 50);
						dd.typefont((int)centerfont("PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", dd.rSCREEN, 0.25f).x,
									565, "PRESS ESC TO RESUME OR F12 TO RETURN TO MAIN MENU", 0, 0, 1, 0.25f, 0, 0, 0, 255, 255, 255);

						//draw hud text
						if (option.data.hud_text)
						{
							dd.draw_hud_text(&hud_text[0]);
							dd.draw_hud_text(&hud_text[1]);
						}

						//draw console
						if (gProgramOptions._console)
						{
							dd.draw_console(&con);
							//if (con.state)
							//	process_mousecursor();
						}

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case DEVELOPER:
					{
						//redraw background every option.data.blurtime-th frame
						//always redraw upper border
						++dd_blurcounter;
						dd.drawbackground(0, 0, 0, 1, 0, 0);
						if (dd_blurcounter >= option.data.mblur)
						{
							//draw background
							dd.drawbackground(option.data.cbackground.r,
											  option.data.cbackground.g,
											  option.data.cbackground.b,
											  0, 1, 1);

							//reset blurcounter
							dd_blurcounter = 0;
						}

						//check and display change of ingame options
						ingameoptions();

						//show framerate if on
						dd.FPS_show();

						//------------------------------------------------------------------------

						static int dev_ini = 0;
						if (!dev_ini)
						{
							dev_ini = 1;

							P[P1].set_keyframe(AN_DEFAULT, 0);
							P[P2].set_keyframe(AN_DEFAULT, 0);

							//process bones
							P[P1].process_bones(s_scale, s_mpy);
							P[P2].process_bones(s_scale, s_mpy);

							//set hara reference
							for (register int i = 0; i < 19; ++i)
								dev_hsk[i] = P[P1].sk.b[i].v;

							//deactivate dev_s_devmode
							dev_s_devmode = 0;
							//deactivate dev_s_showdata
							dev_s_showdata = 0;
							//activate animator
							dev_s_animate = 1;

							//border and zoom
							game_startup(0.5f, 0, 0.5f);
						}

						//check input
						dev_input();

						//show data if on
						if (dev_s_showdata)		dev_showdata();

						//call skeleton editor if devmode else call ingame
						if (dev_s_devmode)		dev_edit();
						else					dev_ingame();

						/*//!!
							- load/save state
							- load/save keyframe
							- load/save animation
							- add/del keyframe from animation
						*/

						//------------------------------------------------------------------------

						//!! f�r developer
						P[P1].process_bones(s_scale, s_mpy);
						P[P2].process_bones(s_scale, s_mpy);
						quicksort_zb(pd.pzb, 0, 37, 1);

						//calculate shadow data
						if (option.data.shadows)
							calculate_shadows();

						//hitboxes
//						if (!dev_s_showref)
//							gProgramOptions.hitbox = ON;
//						else
//							gProgramOptions.hitbox = OFF;

						//collision detection state hack
						//cd offense state for player 1 are copied to player 2
						if (option.data.cd_state)
						{
							//slot valid
							if (P[P1].p_aslot[aslot_action])
							{
								//for every bone
								for (register int b = 0; b < 19; ++b)
								{
									P[P2].sk.b[b].cd_state =
									P[P1].p_aslot[aslot_action]->gl_bcds_off[P[P2].asi][b];
								}
							}
						}

						//horizon
						//line horizon(0, 329, 799, 329);
						//RGBcolor c_horizon(lightgray);
						//dd.drawline(horizon, c_horizon);

//						dd.drawplayers(&pd, option.data.shadows, option.data.bw_mode, option.data.zoomfactor);
						dd.drawscene(&pd, 0, 0, black, 0, 0, 0);
//						dd.drawscene(&pd, 0, 0, black, data_ig.Pcb.r, data_ig.Pcb.g, data_ig.Pcb.b);

/*						//afro
						rectangle afro1;
						afro1.p[0].x = P[P1].sk.chead.x - 10;
						afro1.p[0].y = P[P1].sk.chead.y;
						afro1.p[1].x = afro1.p[0].x ;
						afro1.p[1].y = P[P1].sk.chead.y;
						afro1.p[2].x = P[P1].sk.chead.x - 10;
						afro1.p[2].y = P[P1].sk.chead.y;
						afro1.p[3].x = P[P1].sk.chead.x - 10;
						afro1.p[3].y = P[P1].sk.chead.y;*/

						//draw player message if active
/*						if (P[P1].pmessage.active)
							dd.typefont((int)P[P1].pmessage.pos.x, (int)P[P1].pmessage.pos.y,
										P[P1].pmessage.message, 0, 0, 1, P[P1].pmessage.size,
										P[P1].pmessage.b_color.r, P[P1].pmessage.b_color.g, P[P1].pmessage.b_color.b,
										P[P1].pmessage.f_color.r, P[P1].pmessage.f_color.g, P[P1].pmessage.f_color.b);
						if (P[P2].pmessage.active)
							dd.typefont((int)P[P2].pmessage.pos.x, (int)P[P2].pmessage.pos.y,
										P[P2].pmessage.message, 0, 0, 1, P[P2].pmessage.size,
										P[P2].pmessage.b_color.r, P[P2].pmessage.b_color.g, P[P2].pmessage.b_color.b,
										P[P2].pmessage.f_color.r, P[P2].pmessage.f_color.g, P[P2].pmessage.f_color.b);*/
						//draw player messages if active
						for (register int p = 0; p < 2; ++p)
							for (register int m = 0; m < NPMESSAGES; ++m)
							{
								if (P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].active)
								{
									dd.typefont((int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.x,
												(int)P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].cpos.y,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].message, 0, 0, 1,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].size,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].b_color_adj.b,
												P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.r, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.g, P[p].pmessage.pm[P[p].pmessage.pm_sorted[m]].f_color_adj.b);
								}
							}

						/*if (is.t_move[P1][0] < wsf)
							dd.typefont(8, 100, "", 200 * (is.t_move[P1][0] / wsf) * (float)time.sca * option.data.speed, 5, 0, 1.0f, -1);
						else
							dd.typefont(8, 100, "", 200 * (float)time.sca * option.data.speed, 5, 0, 1.0f, -1);
						if (is.t_move[P1][1] < wsf)
							dd.typefont(8, 116, "", 200 * (is.t_move[P1][1] / wsf) * (float)time.sca * option.data.speed, 5, 0, 1.0f, -1);
						else
							dd.typefont(8, 116, "", 200 * (float)time.sca * option.data.speed, 5, 0, 1.0f, -1);

						for (register int pa = 0; pa < 29; ++pa)
						{
							dd.typefont(pa * 8, 132, "", is.PA[P1][pa], 0, 0, 1.0f, -1);
							dd.typefont(pa * 8, 148, "", is.PA[P2][pa], 0, 0, 1.0f, -1);
						}*/

						//switching sides
						auto_side_switch();

						//------------------------------------------------------------------------

						if (dev_s_showdata)
						{
							//feet-not-on-the-ground indicator (P1 only)
							if (P[P1].sk.b[bfl].v.p[2].y < S_FLOOR ||
								P[P1].sk.b[bfl].v.p[2].y > S_FLOOR + 10)
								dd.drawrectangle_f(P[P1].sk.b[bfl].v, blue);
							if (P[P1].sk.b[bfr].v.p[2].y < S_FLOOR ||
								P[P1].sk.b[bfr].v.p[2].y > S_FLOOR + 10)
								dd.drawrectangle_f(P[P1].sk.b[bfr].v, blue);

							//draw selected bone outline
							dd.drawrectangle_uf(P[P1].sk.b[dev_bi[P1]].v, red);
							dd.drawrectangle_uf(P[P2].sk.b[dev_bi[P2]].v, red);
						}

						//---- torso adjusting ---------------------------------------------------

						//t_frame, angle, length, mode_a
						//priority, a_ri, a_diff, l_ri, l_diff, w_ri, w_diff
						//of rear torso bone always the some as front
						if (P[P1].stance_feet == SLEFT)
						{
							//animation data
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[1]	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[0];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[3]	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[2];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[1]		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[0];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[3]		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[2];
							p_dev_a[P[P1].asi][dev_cai]->priority[1]				= p_dev_a[P[P1].asi][dev_cai]->priority[0];
							p_dev_a[P[P1].asi][dev_cai]->priority[3]				= p_dev_a[P[P1].asi][dev_cai]->priority[2];
							p_dev_a[P[P1].asi][dev_cai]->a_diffp[1]				= p_dev_a[P[P1].asi][dev_cai]->a_diffp[0];
							p_dev_a[P[P1].asi][dev_cai]->a_diffp[3]				= p_dev_a[P[P1].asi][dev_cai]->a_diffp[2];
							p_dev_a[P[P1].asi][dev_cai]->a_diffn[1]				= p_dev_a[P[P1].asi][dev_cai]->a_diffn[0];
							p_dev_a[P[P1].asi][dev_cai]->a_diffn[3]				= p_dev_a[P[P1].asi][dev_cai]->a_diffn[2];
							p_dev_a[P[P1].asi][dev_cai]->l_diffp[1]				= p_dev_a[P[P1].asi][dev_cai]->l_diffp[0];
							p_dev_a[P[P1].asi][dev_cai]->l_diffp[3]				= p_dev_a[P[P1].asi][dev_cai]->l_diffp[2];
							p_dev_a[P[P1].asi][dev_cai]->l_diffn[1]				= p_dev_a[P[P1].asi][dev_cai]->l_diffn[0];
							p_dev_a[P[P1].asi][dev_cai]->l_diffn[3]				= p_dev_a[P[P1].asi][dev_cai]->l_diffn[2];
							p_dev_a[P[P1].asi][dev_cai]->w_diffp[1]				= p_dev_a[P[P1].asi][dev_cai]->w_diffp[0];
							p_dev_a[P[P1].asi][dev_cai]->w_diffp[3]				= p_dev_a[P[P1].asi][dev_cai]->w_diffp[2];
							p_dev_a[P[P1].asi][dev_cai]->w_diffn[1]				= p_dev_a[P[P1].asi][dev_cai]->w_diffn[0];
							p_dev_a[P[P1].asi][dev_cai]->w_diffn[3]				= p_dev_a[P[P1].asi][dev_cai]->w_diffn[2];

							//realtime data
							P[P1].sk.b[1].angle							= P[P1].sk.b[0].angle;
							P[P1].sk.b[3].angle							= P[P1].sk.b[2].angle;
							P[P1].sk.b[1].length						= P[P1].sk.b[0].length;
							P[P1].sk.b[3].length						= P[P1].sk.b[2].length;
						}
						else
						{
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[0]	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[1];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[2]	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[3];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[0]		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[1];
							p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[2]		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[3];
							p_dev_a[P[P1].asi][dev_cai]->priority[0]				= p_dev_a[P[P1].asi][dev_cai]->priority[1];
							p_dev_a[P[P1].asi][dev_cai]->priority[2]				= p_dev_a[P[P1].asi][dev_cai]->priority[3];
							p_dev_a[P[P1].asi][dev_cai]->a_diffp[0]				= p_dev_a[P[P1].asi][dev_cai]->a_diffp[1];
							p_dev_a[P[P1].asi][dev_cai]->a_diffp[2]				= p_dev_a[P[P1].asi][dev_cai]->a_diffp[3];
							p_dev_a[P[P1].asi][dev_cai]->a_diffn[0]				= p_dev_a[P[P1].asi][dev_cai]->a_diffn[1];
							p_dev_a[P[P1].asi][dev_cai]->a_diffn[2]				= p_dev_a[P[P1].asi][dev_cai]->a_diffn[3];
							p_dev_a[P[P1].asi][dev_cai]->l_diffp[0]				= p_dev_a[P[P1].asi][dev_cai]->l_diffp[1];
							p_dev_a[P[P1].asi][dev_cai]->l_diffp[2]				= p_dev_a[P[P1].asi][dev_cai]->l_diffp[3];
							p_dev_a[P[P1].asi][dev_cai]->l_diffn[0]				= p_dev_a[P[P1].asi][dev_cai]->l_diffn[1];
							p_dev_a[P[P1].asi][dev_cai]->l_diffn[2]				= p_dev_a[P[P1].asi][dev_cai]->l_diffn[3];
							p_dev_a[P[P1].asi][dev_cai]->w_diffp[0]				= p_dev_a[P[P1].asi][dev_cai]->w_diffp[1];
							p_dev_a[P[P1].asi][dev_cai]->w_diffp[2]				= p_dev_a[P[P1].asi][dev_cai]->w_diffp[3];
							p_dev_a[P[P1].asi][dev_cai]->w_diffn[0]				= p_dev_a[P[P1].asi][dev_cai]->w_diffn[1];
							p_dev_a[P[P1].asi][dev_cai]->w_diffn[2]				= p_dev_a[P[P1].asi][dev_cai]->w_diffn[3];

							P[P1].sk.b[0].angle							= P[P1].sk.b[1].angle;
							P[P1].sk.b[2].angle							= P[P1].sk.b[3].angle;
							P[P1].sk.b[0].length						= P[P1].sk.b[1].length;
							P[P1].sk.b[2].length						= P[P1].sk.b[3].length;
						}

						//---- difference indicators ---------------------------------------------

						float	angle, rad;
						line	line_t;

						if (dev_s_showref && dev_s_showdata)
						{
							for (register int i = 0; i < 19; ++i)
							{
								//positive
								//angle difference, only if difference not 0
								if (p_dev_a[P[P1].asi][dev_cai]->a_diffp[i] != 0)
								{
									//first point of help line is first vertex of bone
									dev_fadiffp[i].p[0]		= P[P1].sk.b[i].v.p[0];

									//calculate x, y of help line
									//bone angle plus a_diff
									angle					= P[P1].sk.b[i].angle + p_dev_a[P[P1].asi][dev_cai]->a_diffp[i];
									//check angle doesn't exceed its limit
									if (angle > 359)		angle -= 360;
									if (angle < 0)			angle += 360;
									rad						= angle / 180 * PI;

									dev_fadiffp[i].p[1].x	= dev_fadiffp[i].p[0].x + P[P1].sk.b[i].length * (float)cos(rad);
									dev_fadiffp[i].p[1].y	= dev_fadiffp[i].p[0].y + P[P1].sk.b[i].length * (float)sin(rad);

									//angle difference indicators
									dd.drawline(dev_fadiffp[i], pink);
								}

								//negative
								//angle difference, only if difference not 0
								if (p_dev_a[P[P1].asi][dev_cai]->a_diffn[i] != 0)
								{
									//first point of help line is first vertex of bone
									dev_fadiffn[i].p[0]		= P[P1].sk.b[i].v.p[0];

									//calculate x, y of help line
									//bone angle plus a_diff
									angle					= P[P1].sk.b[i].angle + p_dev_a[P[P1].asi][dev_cai]->a_diffn[i];
									//check angle doesn't exceed its limit
									if (angle > 359)		angle -= 360;
									if (angle < 0)			angle += 360;
									rad						= angle / 180 * PI;

									dev_fadiffn[i].p[1].x	= dev_fadiffn[i].p[0].x + P[P1].sk.b[i].length * (float)cos(rad);
									dev_fadiffn[i].p[1].y	= dev_fadiffn[i].p[0].y + P[P1].sk.b[i].length * (float)sin(rad);

									//angle difference indicators
									dd.drawline(dev_fadiffn[i], pink);
								}
							}

							//hara difference, only if not 0
							if (p_dev_a[P[P1].asi][dev_cai]->h_diffp.x != 0)
							{
								line_t.set_line(P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y,
												P[P1].sk.p_ref->v.p[0].x + p_dev_a[P[P1].asi][dev_cai]->h_diffp.x,
												P[P1].sk.p_ref->v.p[0].y);
								dd.drawline(line_t, lightblue);
							}
							if (p_dev_a[P[P1].asi][dev_cai]->h_diffp.y != 0)
							{
								line_t.set_line(P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y,
												P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y + p_dev_a[P[P1].asi][dev_cai]->h_diffp.y);
								dd.drawline(line_t, green);
							}
							if (p_dev_a[P[P1].asi][dev_cai]->h_diffn.x != 0)
							{
								line_t.set_line(P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y,
												P[P1].sk.p_ref->v.p[0].x + p_dev_a[P[P1].asi][dev_cai]->h_diffn.x,
												P[P1].sk.p_ref->v.p[0].y);
								dd.drawline(line_t, blue);
							}
							if (p_dev_a[P[P1].asi][dev_cai]->h_diffn.y != 0)
							{
								line_t.set_line(P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y,
												P[P1].sk.p_ref->v.p[0].x,
												P[P1].sk.p_ref->v.p[0].y + p_dev_a[P[P1].asi][dev_cai]->h_diffn.y);
								dd.drawline(line_t, darkgreen);
							}
						}

						//---- developer insert ---------------------------------------------------

if (is.key1D(DIK_Q))
{
	if (recorder.record_start(RANDOM(9, 1)))
	{
		hud_add_message(0, bmfblue, "RECORDING STARTED:");
		hud_add_message(0, bmfblue, "\"%s\"", recorder.demo_name);
	}
}
if (recorder.recording)
	recorder.record();
if (is.key1D(DIK_E))
{
	if (recorder.stop())
	{
		hud_add_message(0, bmfblue, "RECORDING STOPPED:");
		hud_add_message(0, bmfred, "\"%s\"", recorder.demo_name);
	}
}

/*
static int filesize = 0;
//if (is.key1D(DIK_S))
if (time.tick(2.0f))
{
#define FTC	F_BAQAUTOSAVE_2

	HFILE *hf = NULL;
	hf = (int*)CreateFile(FTC, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hf == NULL)
		hud_add_message(0, bmfred, "hf == NULL");

//	FILE	*hf = fopen("text.txt", "rb");

	DWORD i = GetFileSize(hf, NULL);
	if (i == 0xFFFFFFFF)
	{
		DWORD dwError = GetLastError();
//		FormatMessage(
		hud_add_message(0, bmfred, "FILE 0xFFFFFFFF %i", (int)dwError);
	}
	else
	{
		//hud_add_message(0, bmforange, "Filesize: %i", (int)i);
		filesize = (int)i;
	}

	if (CloseHandle(hf))
	{
		//hud_add_message(0, bmfgreen, "File Closed");
	}
	else						hud_add_message(0, bmfred, "File NOT Closed");
}
dd.typebmf(100, 116, bmfblue, "filesize: %i", filesize);

if (BOT[1].p_queue != NULL)
{
	dd.typebmf(100, 100, bmfblack, "queue/elements: %i %i", (int)sizeof(BOT[1].p_queue), BOT[1].p_queue->elements);
}*/

//dd.typebmf(300, 200, bmfblack, "%.2f", P[P1].sk.b[0].v.p[0].x);
//if (is.mouse(0, 0))
//	P[P1].sk.b[0].v.p[0].x = 200;

//mouse input
if (false)
{
	dd.typebmf(10, 168, bmfblack, "dimouse[0] %i %i %i | %i %i %i %i",
			   is.dimouse[0].lX,
			   is.dimouse[0].lY,
			   is.dimouse[0].lZ,
			   is.dimouse[0].rgbButtons[0],
			   is.dimouse[0].rgbButtons[1],
			   is.dimouse[0].rgbButtons[2],
			   is.dimouse[0].rgbButtons[3]);
	dd.typebmf(10, 184, bmfblack, "dimouse[1] %i %i %i | %i %i %i %i",
			   is.dimouse[1].lX,
			   is.dimouse[1].lY,
			   is.dimouse[1].lZ,
			   is.dimouse[1].rgbButtons[0],
			   is.dimouse[1].rgbButtons[1],
			   is.dimouse[1].rgbButtons[2],
			   is.dimouse[1].rgbButtons[3]);
	dd.typebmf(10, 200, bmfblack, "dimouse[2] %i %i %i | %i %i %i %i",
			   is.dimouse[2].lX,
			   is.dimouse[2].lY,
			   is.dimouse[2].lZ,
			   is.dimouse[2].rgbButtons[0],
			   is.dimouse[2].rgbButtons[1],
			   is.dimouse[2].rgbButtons[2],
			   is.dimouse[2].rgbButtons[3]);
}

//---- prototype bot -----------------------------------------------------------------------------

if (false)
{
	#define	UNITS	20
	static int distance[UNITS]	= {0};
	static int damage[UNITS]	= {0};
	static int index			= 0;

	for (register int i = 0; i < UNITS; ++i)
	{
		dd.typebmf(10 + (i * 8 * 4), 200, bmfblack, "%i", distance[i]);
		dd.typebmf(10 + (i * 8 * 4), 216, bmfblack, "%i", damage[i]);
	}

	//player solid punch
	if (is.key1D(DIK_W))
	{
		//depending on side
		if (P[P1].side == SLEFT)
		{
			P[P1].al_activate_slot(aslot_action, AN_JAB, 340, 45);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}
		else
		{
			P[P1].al_activate_slot(aslot_action, AN_JAB, 200, 45);
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
		}

		distance[index]		= (int)player_distance;
		damage[index]		= P[P1].damage_dealt_last;

		if (index < UNITS - 1)
			index++;
		else
			index	= 0;
	}

	if (is.key1D(DIK_E))
	{
		//depending on side
		if (P[P2].side == SLEFT)
		{
			P[P2].al_activate_slot(aslot_action, AN_JAB, 340, 45);
			P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
		}
		else
		{
			P[P2].al_activate_slot(aslot_action, AN_JAB, 200, 45);
			P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
		}
	}
}

//------------------------------------------------------------------------------------------------

if (false)
{
	dd.typebmf(10, 132, bmfblack, "offlock: %i %i %i %i", P[P1].gl_lock.lock_off[0], P[P1].gl_lock.lock_off[1], P[P1].gl_lock.lock_off[2], P[P1].gl_lock.lock_off[3]);
	dd.typebmf(10, 148, bmfblack, "deflock: %i %i %i %i", P[P1].gl_lock.lock_def[0], P[P1].gl_lock.lock_def[1], P[P1].gl_lock.lock_def[2], P[P1].gl_lock.lock_def[3]);

	dd.typebmf(400, 100, bmfblack, "last: %i / %i", (int)P[P1].last_anmn[0], (int)P[P1].last_anmn[1]);

	//offlocks
	if (is.key1D(DIK_Z))
	{
		P[P1].gl_lock.set_lockstate(OFFENSIVE, 0, 0, ON, 90, time.current);
		P[P1].gl_lock.set_lockstate(OFFENSIVE, 1, 0, ON, 90, time.current);
		P[P1].gl_lock.set_lockstate(OFFENSIVE, 2, 0, ON, 90, time.current);
		P[P1].gl_lock.set_lockstate(OFFENSIVE, 3, 0, ON, 90, time.current);

		P[P1].gl_lock.stun_walk_bwd -= 0.1f;
		P[P1].gl_lock.stun_walk_fwd -= 0.1f;
		P[P1].gl_lock.t_stun_bwd	= time.current;
		P[P1].gl_lock.t_stun_fwd	= time.current;
	}
	if (P[P1].p_aslot[aslot_cycle] != NULL)
		dd.typebmf(10, 232, bmfblack, "sf cycle: %.1f", P[P1].p_aslot[aslot_cycle]->speedfactor[P1]);
	if (P[P1].p_aslot[aslot_action] != NULL)
		dd.typebmf(150, 232, bmfblack, "action: %.1f", P[P1].p_aslot[aslot_action]->speedfactor[P1]);

	dd.typebmf(10, 248, bmfblue, "adj bwd/fwd: %.1f / %.1f", P[P1].walk_bwd_ad, P[P1].walk_fwd_ad);
	dd.typebmf(10, 264, bmfblue, "%.1f / %.1f", P[P1].gl_lock.stun_walk_bwd, P[P1].gl_lock.stun_walk_fwd);
	dd.typebmf(10, 280, bmfblue, "%.1f / %.1f", P[P2].gl_lock.stun_walk_bwd, P[P2].gl_lock.stun_walk_fwd);
}

//---- move recording ----------------------------------------------------------------------------

if (true &&
	(BOT[B1].active || BOT[B2].active))
{
	//start REC
	if (is.key1D(DIK_V) && BOT[B2].active)
	{
	//	BOT[B2].start_record(-1, P1);
		if (BOT[B2].mr_start_record(0, P1))
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] recording STARTED", B2);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfred, "BOT[%i] start recording FAILED", B2);
		}
	}
	//stop REC
	if (is.key1D(DIK_B))
	{
		if (BOT[B2].mr_stop_record())
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] recording STOPPED", B2);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfred, "BOT[%i] stop recording FAILED", B2);
		}
	}
	//bot 2 REPLAY
	if (!is.key(DIK_LCONTROL) && is.key1D(DIK_N) && BOT[B2].active)
	{
//		if (BOT[B2].mr_start_replay(0))
		//always play last queue
		if (BOT[B2].mr_start_replay(BOT[B2].elements - 1))
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] replay STARTED (queue %i)", B2, BOT[B2].elements - 1);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfred, "BOT[%i] start replay FAILED (queue %i)", B2, BOT[B2].elements - 1);
		}
	}
	if (!is.key(DIK_LCONTROL) && is.key1D(DIK_M))
	{
		if (BOT[B2].mr_stop_replay())
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] replay STOPPED", B2);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfred, "BOT[%i] stop replay FAILED", B2);
		}
	}
	//bot 1 REPLAY
	if (is.key(DIK_LCONTROL) && is.key1D(DIK_N) && BOT[B1].active)
	{
		if (BOT[B1].mr_start_replay(0))
		{
			playsound_s(S_MENTER);
			hud_add_message(B1, bmfblue, "BOT[%i] replay STARTED", B1);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B1, bmfred, "BOT[%i] start replay FAILED", B1);
		}
	}
	if (is.key(DIK_LCONTROL) && is.key1D(DIK_M))
	{
		if (BOT[B1].mr_stop_replay())
		{
			playsound_s(S_MENTER);
			hud_add_message(B1, bmfblue, "BOT[%i] replay STOPPED", B1);
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B1, bmfred, "BOT[%i] stop replay FAILED", B1);
		}
	}
	//SAVE REC
	if (is.key(DIK_LSHIFT) && is.key1D(DIK_Y))
	{
	//	BOT[B2]._dump_rec_data();
		if (BOT[B2].save_queue(-1, "bot/queues.dat"))
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] queue SAVED %s", B2, "bot/queues.dat");
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfblue, "BOT[%i] queue FAILED %s", B2, "bot/queues.dat");
		}
	}
	//LOAD REPLAY
	if (is.key1D(DIK_U))
	{
		if (BOT[B2].load_queue("bot/queues.dat"))
		{
			playsound_s(S_MENTER);
			hud_add_message(B2, bmfblue, "BOT[%i] queue LOADED %s", B2, "bot/queues.dat");
		}
		else
		{
			playsound_s(S_ERROR);
			hud_add_message(B2, bmfblue, "BOT[%i] queue FAILED %s", B2, "bot/queues.dat");
		}
	}

	//display bot state data
	if (true)
	{
		if (BOT[B1].recording)
		{
			if (time.tick(0.4f))
				dd.typebmf(10, 75 + 16 * 0, bmfred, "REC.BOT1");
		}
		if (BOT[B2].recording)
		{
			if (time.tick(0.4f))
				dd.typebmf(10, 75 + 16 * 1, bmfred, "REC.BOT2");
		}
		if (BOT[B1].replaying)			dd.typebmf(10, 75 + 16 * 2, bmfblue, "REPLAYING BOT1");
		if (BOT[B2].replaying)			dd.typebmf(10, 75 + 16 * 3, bmfblue, "REPLAYING BOT2");

		ipoint os(10, 400);

		dd.typebmf(os.x, os.y, bmfblue, "fatigue: %i (%i) | %i (%i)",
				   (int)P[P1].fatigue, (int)P[P1].fatigue_buff,
				   (int)P[P2].fatigue, (int)P[P2].fatigue_buff);
		dd.typebmf(os.x, os.y + 16 * 1, bmfblue, "guard: %i | %i",
				   (int)P[P1].stance_arms, (int)P[P2].stance_arms);
		dd.typebmf(os.x, os.y + 16 * 2, bmfred, "damlast: %i %i",
				   (int)P[P1].damage_dealt_last, (int)P[P2].damage_dealt_last);

		dd.typebmf(os.x, os.y + 16 * 3, bmfblack, "t_move: %.2f %.2f          %.2f %.2f              dist: %.1f",
				   is.t_move[P1][0], is.t_move[P1][1],
				   is.t_move[P2][0], is.t_move[P2][1],
				   player_distance);
/*
		dd.typebmf(os.x, os.y + 16 * 4, bmfblack, "PA[P1]");
		dd.typebmf(os.x, os.y + 16 * 5, bmfblack, "PA[P2]");
		for (int pa = 0; pa < NPAN; ++pa)
		{
			dd.typebmf(os.x + 64 + pa * 16, os.y + 16 * 4, bmfblack, "%i", is.PA[P1][pa]);
			dd.typebmf(os.x + 64 + pa * 16, os.y + 16 * 5, bmfblack, "%i", is.PA[P2][pa]);
		}

		dd.typebmf(os.x, os.y + 16 * 6, bmfblack, "BD[P1]");
		dd.typebmf(os.x, os.y + 16 * 7, bmfblack, "BD[P2]");
		for (int b = 0; b < 19; ++b)
		{
			dd.typebmf(os.x + 64 + b * 32, os.y + 16 * 6, bmfblack, "%i", P[P1].sk.b[b].damage);
			dd.typebmf(os.x + 64 + b * 32, os.y + 16 * 7, bmfblack, "%i", P[P2].sk.b[b].damage);

			dd.typebmf(os.x + 64 + b * 32, os.y + 16 * 8, bmfwhite, "%i", P[P1].sk.b[b].lock_state);
			dd.typebmf(os.x + 64 + b * 32, os.y + 16 * 9, bmfwhite, "%i", P[P2].sk.b[b].lock_state);
		}*/
	}
}

//dd.typebmf(10, 248, bmfblue, "last tap: %.1f", (float)((float)(time.current - P[P1].t_last_tap_arms) / time.freq * option.data.speed));
//dd.typebmf(10, 264, bmfblue, "    legs: %.1f", (float)((float)(time.current - P[P1].t_last_tap_legs) / time.freq * option.data.speed));

//bot
/*
dd.typebmf(100, 80, 0, "BOT[1]: %i BOT[2]: %i", (int)BOT[B1].active, (int)BOT[B2].active);

dd.typebmf(100, 100, 0, "%.1f %.1f", is.t_move[B2][0], is.t_move[B2][1]);

for (register int e = 0; e < NBE; ++e)
	dd.typebmf(100, 100 + ((e + 1) * 16), 0, "dist: %i dam: %i", BOT[B2].memory.bot_exp[e].distance, BOT[B2].memory.bot_exp[e].damage);

dd.typebmf(500, 100, 0, "dist: %i", (int)*P[P1].p_distance);

for (register int e = 0; e < NPAC; ++e)
	dd.typebmf(100 + (e * 16), 480, 0, "%i", (int)is.PA[P1][e]);
if (P[P1].p_aslot[aslot_action] != NULL)
	dd.typebmf(100, 496, 0, "%i", (int)P[P1].p_aslot[aslot_action]->gl_time[P1]);
*/
//dd.typebmf(100, 100, 0, "mm  %i", (int)is.mm_button_flag[P1]);
//dd.typebmf(100, 116, 0, "def %i", (int)is.def_button[P1]);
//dd.typebmf(100, 132, 0, "can %i", (int)is.mm_cancel[P1]);
//dd.typebmf(100, 100, 0, "fat: %i", (int)P[P1].fatigue);
/*
dd.typebmf(100, 100, 0, "%s %s %s %s %s %s", getinput_char(option.data.CBT[cP1LEFT]),
											 getinput_char(option.data.CBT[cP1RIGHT]),
											 getinput_char(option.data.CBT[cP1PUNCH]),
											 getinput_char(option.data.CBT[cP1KICK]),
											 getinput_char(option.data.CBT[cP1DEFEND]),
											 getinput_char(option.data.CBT[cP1SPECIAL]));

dd.typebmf(100, 116, 0, "%i %i %i %i %i %i", (int)option.data.CBT[cP1LEFT],
											 (int)option.data.CBT[cP1RIGHT],
											 (int)option.data.CBT[cP1PUNCH],
											 (int)option.data.CBT[cP1KICK],
											 (int)option.data.CBT[cP1DEFEND],
											 (int)option.data.CBT[cP1SPECIAL]);*/

//---- demo recording -----------------------------------------------------------------------------

//demo recording
if (is.dikey1D[DIK_RCONTROL] & 0x80)
	if (!sdemo_startrec("demos/demo.bmd", -1))
	{
		hud_add_message(0, bmfred, "demo recording failed: demos/demo.bmd");
		playsound_s(S_ERROR);
	}
	else
	{
		hud_add_message(0, bmfgreen, "demo recording started: demos/demo.bmd");
		playsound_s(S_MENTER);
	}

if (is.dikey1D[DIK_RSHIFT] & 0x80)
	if (!sdemo_stop(0))
	{
		hud_add_message(0, bmfred, "demo recording stop failed: demos/demo.bmd");
		playsound_s(S_ERROR);
	}
	else
	{
		hud_add_message(0, bmfgreen, "demo recording stopped: demos/demo.bmd");
		playsound_s(S_MSELECT);
	}

//record if recording
if (demo_record)
	sdemo_record();

if (is.dikey1D[DIK_RMENU] & 0x80)
{
	if (demo_playback)
	{
		hud_add_message(0, bmfgreen, "demo playback stopped: demos/demo.bmd");
		demo_playback = OFF;
	}
	else
	{
		hud_add_message(0, bmfgreen, "demo playback started: demos/demo.bmd");
		sdemo_startplay("demos/demo.bmd");
	}
}

//playback if playing back
if (demo_playback)
	sdemo_playback();

//---- font editor --------------------------------------------------------------------------------
/*

static int letter = 48;
static int l_rect = 0;
static int l_corn = 0;
static float l_zoom = 4.0f;
//select ascii code
if (is.key1D(DIK_U) && letter < 255)	++letter;
if (is.key1D(DIK_J) && letter > 0)		--letter;
//select rectangle
if ((is.key1D(DIK_Y) || is.dimouse[0].lZ > 0) && l_rect < 5)		++l_rect;
if ((is.key1D(DIK_H) || is.dimouse[0].lZ < 0) && l_rect > 0)		--l_rect;
//select corner
if (is.key1D(DIK_B) || is.mouse1D(0, 3))					l_corn = !l_corn;
//if (is.key1D(DIK_B) || is.mouse1D(0, 3))					l_corn = 1;
//select zoom, reset zoom
if (is.key1D(DIK_R))					l_zoom += 0.1f;
if (is.key1D(DIK_F))					l_zoom -= 0.1f;
if (is.key1D(DIK_R) && is.key1D(DIK_F))	l_zoom = 4.0f;
//reset rectangle
if (is.key1D(DIK_SPACE))
{
	dd.p_cfontsl_LUT[letter][l_rect].left =
	dd.p_cfontsl_LUT[letter][l_rect].right =
	dd.p_cfontsl_LUT[letter][l_rect].top =
	dd.p_cfontsl_LUT[letter][l_rect].bottom = -1;
}

//drag corner
if (is.mouse(0, 0) && !is.mouse(0, 1))
{
	if (l_corn == 1)
	{
		dd.p_cfontsl_LUT[letter][l_rect].right += is.dimouse[0].lX;
		dd.p_cfontsl_LUT[letter][l_rect].bottom += is.dimouse[0].lY;
	}
	else
	{
		dd.p_cfontsl_LUT[letter][l_rect].left += is.dimouse[0].lX;
		dd.p_cfontsl_LUT[letter][l_rect].top += is.dimouse[0].lY;
	}
}
//drag rectangle
if (!is.mouse(0, 0) && is.mouse(0, 1))
{
	dd.p_cfontsl_LUT[letter][l_rect].left += is.dimouse[0].lX;
	dd.p_cfontsl_LUT[letter][l_rect].top += is.dimouse[0].lY;
	dd.p_cfontsl_LUT[letter][l_rect].right += is.dimouse[0].lX;
	dd.p_cfontsl_LUT[letter][l_rect].bottom += is.dimouse[0].lY;
}

dd.typebmf(100, 100, 0, "LTRB: %i %i %i %i",
		   dd.p_cfontsl_LUT[letter][l_rect].left,
		   dd.p_cfontsl_LUT[letter][l_rect].top,
		   dd.p_cfontsl_LUT[letter][l_rect].right,
		   dd.p_cfontsl_LUT[letter][l_rect].bottom);
dd.typebmf(100, 116, 0, "W: %i H: %i",
		   dd.p_cfontsl_LUT[letter][l_rect].right - dd.p_cfontsl_LUT[letter][l_rect].left,
		   dd.p_cfontsl_LUT[letter][l_rect].bottom - dd.p_cfontsl_LUT[letter][l_rect].top);
//dd.typefont(100, 100, "", dd.p_cfontsl_LUT[letter][l_rect].left, 0, 0, 1.0f, -1);
//dd.typefont(150, 100, "", dd.p_cfontsl_LUT[letter][l_rect].top, 0, 0, 1.0f, -1);
//dd.typefont(100, 116, "", dd.p_cfontsl_LUT[letter][l_rect].right, 0, 0, 1.0f, -1);
//dd.typefont(150, 116, "", dd.p_cfontsl_LUT[letter][l_rect].bottom, 0, 0, 1.0f, -1);
//dd.typefont(100, 132, "", dd.p_cfontsl_LUT[letter][l_rect].right - dd.p_cfontsl_LUT[letter][l_rect].left, 0, 0, 1.0f, -1);
//dd.typefont(150, 132, "", dd.p_cfontsl_LUT[letter][l_rect].bottom - dd.p_cfontsl_LUT[letter][l_rect].top, 0, 0, 1.0f, -1);
dd.typebmf(500, 100, 0, "ascii: %i", letter);
dd.typebmf(500, 116, 0, "rect:  %i", l_rect);
dd.typebmf(500, 132, 0, "zoom:	%.1f", l_zoom);
//dd.typefont(500, 100, "", letter, 0, 0, 1.0f, -1);
//dd.typefont(500, 116, "", l_rect, 0, 0, 1.0f, -1);
//dd.typefont(500, 132, "", l_zoom, 2, 0, 1.0f, -1);

//for (register int li = 0; li < 58 * l_zoom; li += 1 * l_zoom)
	for (register int c = 0; c < 32 * l_zoom / 2 + 1; c += 1 * l_zoom)
	{
//		point lp(350 + c, 100 + li);
//		dd.drawpoint(lp, red);
		RECT lr;
		fillRECT(lr, 350 + c, 100 + c, 350 + 32 * l_zoom - c, 100 + 48 * l_zoom - c);
		dd.drawrectangle_uf(lr, darkgray);
	}
rectangle l_inner(350, 100, 350 + (32 * l_zoom), 100,
				  350 + (32 * l_zoom), 100 + (48 * l_zoom), 350, 100 + (48 * l_zoom));
rectangle l_outer(350, 100, 350 + (32 * l_zoom), 100,
				  350 + (32 * l_zoom), 100 + (58 * l_zoom), 350, 100 + (58 * l_zoom));
dd.drawrectangle_uf(l_inner, red);
dd.drawrectangle_uf(l_outer, blue);
char letterchar[2] = "x";
letterchar[0] = letter;
dd.typefont(350, 100, letterchar, 0, 0, 1, l_zoom);
rectangle mark = dd.p_cfontsl_LUT[letter][l_rect];
mark.p[0].x *= l_zoom; mark.p[0].y *= l_zoom;
mark.p[1].x *= l_zoom; mark.p[1].y *= l_zoom;
mark.p[2].x *= l_zoom; mark.p[2].y *= l_zoom;
mark.p[3].x *= l_zoom; mark.p[3].y *= l_zoom;
mark.p[0].x += 350; mark.p[0].y += 100;
mark.p[1].x += 350; mark.p[1].y += 100;
mark.p[2].x += 350; mark.p[2].y += 100;
mark.p[3].x += 350; mark.p[3].y += 100;
dd.drawrectangle_bf(mark, black, red);
if (!l_corn)
	dd.drawcircle(mark.p[0].x, mark.p[0].y, 20, black);
else
	dd.drawcircle(mark.p[2].x, mark.p[2].y, 20, black);

if (is.key1D(DIK_P))
{
	FILE	*f_font = fopen("font.txt", "w");

	if (f_font != NULL)
	{
		for (register int le = 0; le < 256; ++le)
		{
			if (dd.p_cfontsl_LUT[le][0].left != -1)
			{
				char lechar[2] = "";
				lechar[0] = le;
				lechar[1] = 0;
				fprintf(f_font,
						"%s%s\n",
						"//",lechar);
				for (register int re = 0; re < 6; ++re)
				{
					//speichern
					if (re % 2)
						fprintf(f_font,
								"%s%i%s%i%s%i%s%i%s%i%s%i%s\n",
								"fillRECT(p_lut[", le,
								"][", re,
								"], ", dd.p_cfontsl_LUT[le][re].left,
								", ", dd.p_cfontsl_LUT[le][re].top,
								", ", dd.p_cfontsl_LUT[le][re].right,
								", ", dd.p_cfontsl_LUT[le][re].bottom,
								");");
					else
						fprintf(f_font,
								"%s%i%s%i%s%i%s%i%s%i%s%i%s\t",
								"fillRECT(p_lut[", le,
								"][", re,
								"], ", dd.p_cfontsl_LUT[le][re].left,
								", ", dd.p_cfontsl_LUT[le][re].top,
								", ", dd.p_cfontsl_LUT[le][re].right,
								", ", dd.p_cfontsl_LUT[le][re].bottom,
								");");
				}
				fprintf(f_font, "\n");
			}
		}

		fclose(f_font);
	}
}

float fontsize = 0.35f;

dd.typefont(10, 350, "0123456789,<.>/?;:'\"[]{}\\|!@#$%^&*()-_=+", 0, 0, 1, fontsize);
dd.typefont(200, 410, "abcdefghijklmnopqrstuvwxyz", 0, 0, 1, fontsize);
dd.typefont(200, 470, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", 0, 0, 1, fontsize);
*/

/*if (is.key1D(DIK_T))
	option.data.zoomfactor += 0.1f;
if (is.key1D(DIK_G) && option.data.zoomfactor > 0.1f)
	option.data.zoomfactor -= 0.1f;
dd.typefont(100, 100, "", option.data.zoomfactor, 2, 0, 1.0f, -1);
if (is.key1D(DIK_T) && is.key1D(DIK_G))
	option.data.zoomfactor = 1.0f;*/

//-------------------------------------------------------------------------------------------------

if (dev_s_showdata)
{
/*
	for (register int a = 0; a < 6; ++a)
	{
		//dd.typefont(a * 8 + 300, 90, "", P[P1].active[a], 0);
		//dd.typefont(a * 8 + 300, 106, "", P[P2].active[a], 0);
		//dd.typefont(a * 8 + 300, 90, "", rcd.attack[P1][a], 0);
		//dd.typefont(a * 8 + 300, 106, "", rcd.attack[P2][a], 0);
	}
//dd.typefont(34 * 8, 8, "", P[P1].sk.b[bfl].v.p[0].x);
//dd.typefont(34 * 8, 24, "", P[P1].sk.b[bfl].v.p[0].y);
//dd.typefont(38 * 8, 8, "", P[P1].sk.b[bfl].v.p[1].x);
//dd.typefont(38 * 8, 24, "", P[P1].sk.b[bfl].v.p[1].y);
dd.typefont(59 * 8, 8, "", P[P1].sk.b[bfl].v.p[2].x, 2);
dd.typefont(59 * 8, 24, "", P[P1].sk.b[bfl].v.p[2].y, 2);
//dd.typefont(46 * 8, 8, "", P[P1].sk.b[bfl].v.p[3].x);
//dd.typefont(46 * 8, 24, "", P[P1].sk.b[bfl].v.p[3].y);
//dd.typefont(51 * 8, 8, "", P[P1].sk.b[bfr].v.p[0].x);
//dd.typefont(51 * 8, 24, "", P[P1].sk.b[bfr].v.p[0].y);
//dd.typefont(55 * 8, 8, "", P[P1].sk.b[bfr].v.p[1].x);
//dd.typefont(55 * 8, 24, "", P[P1].sk.b[bfr].v.p[1].y);
dd.typefont(42 * 8, 8, "", P[P1].sk.b[bfr].v.p[2].x, 2);
dd.typefont(42 * 8, 24, "", P[P1].sk.b[bfr].v.p[2].y, 2);
//dd.typefont(63 * 8, 8, "", P[P1].sk.b[bfr].v.p[3].x);
//dd.typefont(63 * 8, 24, "", P[P1].sk.b[bfr].v.p[3].y);

dd.typefont(208, 7 * 16, "", is.mm_angle[P1], 0, 0, 1.0f, -1);
dd.typefont(264, 7 * 16, "", is.mm_angle_180[P1], 0, 0, 1.0f, -1);
dd.typefont(25 * 8, 5 * 16, "", P[P1].fatigue_buff, 2);

//bone hit state
//for (register int i = 0; i < 21; ++i)
//	dd.typefont(i * 8 * 2 + 150, 34, "", P[P1].bhi[i], 0, 0, 1.0f);
for (register int i = 0; i < 19; ++i)
{
	if (P[P1].sk.b[i].p_pb != NULL)
	{
		float angle_rp = P[P1].sk.b[i].angle - P[P1].sk.b[i].p_pb->angle;

		//set relative angle to shortest direction
		if (angle_rp > 180)			angle_rp = -(360 - angle_rp);
		if (angle_rp < -180)		angle_rp += 360;

		dd.typefont(i * 8 * 4 + 140, 34, "", angle_rp, 0, 0, 1.0f);
	}
}

for (i = 0; i < 21; ++i)
{
	dd.typefont(i * 8 * 2, 160, "", P[P1].bpc[0][i], 0, 0, 1.0f, -1);
	dd.typefont(i * 8 * 2, 176, "", P[P1].bdc[0][i], 0, 0, 1.0f, -1);
	dd.typefont(i * 8 * 2 + 400, 160, "", P[P1].bpc[1][i], 0, 0, 1.0f, -1);
	dd.typefont(i * 8 * 2 + 400, 176, "", P[P1].bdc[1][i], 0, 0, 1.0f, -1);
	dd.typefont(i * 8, 200, "", P[P1].casi[i], 0, 0, 1.0f, -1);
	dd.typefont(i * 8, 216, "", P[P1].cki[i], 0, 0, 1.0f, -1);
}
dd.typefont(360, 160, "", P[P1].bpc[0][21], 0, 0, 1.0f, -1);
dd.typefont(360, 176, "", P[P1].bdc[0][21], 0, 0, 1.0f, -1);
dd.typefont(750, 160, "", P[P1].bpc[1][21], 0, 0, 1.0f, -1);
dd.typefont(750, 176, "", P[P1].bdc[1][21], 0, 0, 1.0f, -1);
if (P[P1].p_aslot[0] != NULL)
{
	int index = P[P1].cki[dev_bi[P1]];
	for (register int i = 0; i < P[P1].p_aslot[0]->nokf; ++i)
	{
		//state of keyframes of selected bone
		dd.typefont(i * 8, 232, "", P[P1].p_aslot[0]->pkf[i].state[P1][dev_bi[P1]], 0, 0, 1.0f, -1);
		dd.typefont(i * 8 + 40, 232, "", P[P1].p_aslot[0]->pkf[i].state[P1][IHX], 0, 0, 1.0f, -1);
		dd.typefont(i * 8 + 80, 232, "", P[P1].p_aslot[0]->pkf[i].state[P1][IHY], 0, 0, 1.0f, -1);
	}
	dd.typefont(180, 132, "", P[P1].p_aslot[0]->pkf[index].t_frame_ad[P1][dev_bi[P1]], 0, 0, 1.0f, -1);

	dd.typefont(8, 16 * 16, "", P[P1].p_aslot[0]->pkf[index].angle_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(64, 16 * 16, "", P[P1].p_aslot[0]->pkf[index].angle_def[dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8, 17 * 16, "", P[P1].p_aslot[0]->pkf[index].length_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8, 18 * 16, "", P[P1].p_aslot[0]->pkf[index].width_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

	dd.typefont(8, 20 * 16, "", P[P1].p_aslot[0]->pkf[index].speed_a[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8, 21 * 16, "", P[P1].p_aslot[0]->pkf[index].speed_l[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8, 22 * 16, "", P[P1].p_aslot[0]->pkf[index].speed_w[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

	dd.typefont(8, 24 * 16, "", P[P1].p_aslot[0]->pkf[index].hara_ad[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(64, 24 * 16, "", P[P1].p_aslot[0]->pkf[index].hara_r[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(8, 25 * 16, "", P[P1].p_aslot[0]->pkf[index].hara_ad[P1].y, 6, 0, 1.0f, -1);

	dd.typefont(8, 27 * 16, "", P[P1].p_aslot[0]->pkf[index].speed_h[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(64, 27 * 16, "", P[P1].p_aslot[0]->pkf[index].speed_h[P1].y, 2, 0, 1.0f, -1);

	dd.typefont(8, 8 * 16, "", P[P1].p_aslot[0]->angle[P1], 0, 0, 1.0f, -1);
	dd.typefont(64, 8 * 16, "", P[P1].p_aslot[0]->angle_180[P1], 0, 0, 1.0f, -1);
}
if (P[P1].p_aslot[1] != NULL)
{
	int index = P[P1].cki[dev_bi[P1]];
	for (register int i = 0; i < P[P1].p_aslot[1]->nokf; ++i)
	{
		//state of keyframes of selected bone
		dd.typefont(i * 8 + 400, 232, "", P[P1].p_aslot[1]->pkf[i].state[P1][dev_bi[P1]], 0, 0, 1.0f, -1);
		dd.typefont(i * 8 + 40 + 400, 232, "", P[P1].p_aslot[1]->pkf[i].state[P1][IHX], 0, 0, 1.0f, -1);
		dd.typefont(i * 8 + 80 + 400, 232, "", P[P1].p_aslot[1]->pkf[i].state[P1][IHY], 0, 0, 1.0f, -1);
	}

	for (i = 0; i < 19; ++i)
	{
		dd.typefont(i * 8 * 4 + 150, 50, "", P[P1].p_aslot[1]->pkf[index].t_frame_ad[P1][i], 0, 0, 1.0f);
		dd.typefont(i * 8 * 4 + 150, 66, "", P[P1].p_aslot[1]->pkf[index].angle_def[i], 0, 0, 1.0f);
	}

	dd.typefont(300, 132, "", P[P1].p_aslot[1]->pkf[index].t_frame_ad[P1][dev_bi[P1]], 0, 0, 1.0f, -1);

	dd.typefont(8 + 400, 16 * 16, "", P[P1].p_aslot[1]->pkf[index].angle_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(64 + 400, 16 * 16, "", P[P1].p_aslot[1]->pkf[index].angle_def[dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8 + 400, 17 * 16, "", P[P1].p_aslot[1]->pkf[index].length_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8 + 400, 18 * 16, "", P[P1].p_aslot[1]->pkf[index].width_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

	dd.typefont(8 + 400, 20 * 16, "", P[P1].p_aslot[1]->pkf[index].speed_a[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8 + 400, 21 * 16, "", P[P1].p_aslot[1]->pkf[index].speed_l[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
	dd.typefont(8 + 400, 22 * 16, "", P[P1].p_aslot[1]->pkf[index].speed_w[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

	dd.typefont(8 + 400, 24 * 16, "", P[P1].p_aslot[1]->pkf[index].hara_ad[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(64 + 400, 24 * 16, "", P[P1].p_aslot[1]->pkf[index].hara_r[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(8 + 400, 25 * 16, "", P[P1].p_aslot[1]->pkf[index].hara_ad[P1].y, 6, 0, 1.0f, -1);

	dd.typefont(8 + 400, 27 * 16, "", P[P1].p_aslot[1]->pkf[index].speed_h[P1].x, 2, 0, 1.0f, -1);
	dd.typefont(64 + 400, 27 * 16, "", P[P1].p_aslot[1]->pkf[index].speed_h[P1].y, 2, 0, 1.0f, -1);

	dd.typefont(8 + 400, 8 * 16, "", P[P1].p_aslot[1]->angle[P1], 0, 0, 1.0f, -1);
	dd.typefont(64 + 400, 8 * 16, "", P[P1].p_aslot[1]->angle_180[P1], 0, 0, 1.0f, -1);
}
if (P[P1].p_aslot[2] != NULL)
{
	int index = P[P1].cki[dev_bi[P1]];
	if (P[P1].casi[dev_bi[P1]] == aslot_hit)
	{
		for (register int i = 0; i < P[P1].p_aslot[2]->nokf; ++i)
		{
			//state of keyframes of selected bone
			dd.typefont(i * 8 + 400, 232, "", P[P1].p_aslot[2]->pkf[i].state[P1][dev_bi[P1]], 0, 0, 1.0f, -1);
			dd.typefont(i * 8 + 40 + 400, 232, "", P[P1].p_aslot[2]->pkf[i].state[P1][IHX], 0, 0, 1.0f, -1);
			dd.typefont(i * 8 + 80 + 400, 232, "", P[P1].p_aslot[2]->pkf[i].state[P1][IHY], 0, 0, 1.0f, -1);
		}

		for (i = 0; i < 19; ++i)
		{
			dd.typefont(i * 8 * 4 + 150, 50, "", P[P1].p_aslot[2]->pkf[index].t_frame_ad[P1][i], 0, 0, 1.0f);
			dd.typefont(i * 8 * 4 + 150, 66, "", P[P1].p_aslot[2]->pkf[index].angle_def[i], 0, 0, 1.0f);
		}

		dd.typefont(300, 132, "", P[P1].p_aslot[2]->pkf[index].t_frame_ad[P1][dev_bi[P1]], 0, 0, 1.0f, -1);

		dd.typefont(8 + 400, 16 * 16, "", P[P1].p_aslot[2]->pkf[index].angle_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
		dd.typefont(64 + 400, 16 * 16, "", P[P1].p_aslot[2]->pkf[index].angle_def[dev_bi[P1]], 2, 0, 1.0f, -1);
		dd.typefont(8 + 400, 17 * 16, "", P[P1].p_aslot[2]->pkf[index].length_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
		dd.typefont(8 + 400, 18 * 16, "", P[P1].p_aslot[2]->pkf[index].width_ad[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

		dd.typefont(8 + 400, 20 * 16, "", P[P1].p_aslot[2]->pkf[index].speed_a[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
		dd.typefont(8 + 400, 21 * 16, "", P[P1].p_aslot[2]->pkf[index].speed_l[P1][dev_bi[P1]], 2, 0, 1.0f, -1);
		dd.typefont(8 + 400, 22 * 16, "", P[P1].p_aslot[2]->pkf[index].speed_w[P1][dev_bi[P1]], 2, 0, 1.0f, -1);

		dd.typefont(8 + 400, 24 * 16, "", P[P1].p_aslot[2]->pkf[index].hara_ad[P1].x, 2, 0, 1.0f, -1);
		dd.typefont(64 + 400, 24 * 16, "", P[P1].p_aslot[2]->pkf[index].hara_r[P1].x, 2, 0, 1.0f, -1);
		dd.typefont(8 + 400, 25 * 16, "", P[P1].p_aslot[2]->pkf[index].hara_ad[P1].y, 6, 0, 1.0f, -1);

		dd.typefont(8 + 400, 27 * 16, "", P[P1].p_aslot[2]->pkf[index].speed_h[P1].x, 2, 0, 1.0f, -1);
		dd.typefont(64 + 400, 27 * 16, "", P[P1].p_aslot[2]->pkf[index].speed_h[P1].y, 2, 0, 1.0f, -1);

		dd.typefont(8 + 400, 8 * 16, "", P[P1].p_aslot[2]->angle[P1], 0, 0, 1.0f, -1);
		dd.typefont(64 + 400, 8 * 16, "", P[P1].p_aslot[2]->angle_180[P1], 0, 0, 1.0f, -1);
	}
}*/
}

						//-------------------------------------------------------------------------

						//draw hud text
						if (option.data.hud_text)
						{
							dd.draw_hud_text(&hud_text[0]);
							dd.draw_hud_text(&hud_text[1]);
						}

						//draw console
						if (gProgramOptions._console)
						{
							dd.draw_console(&con);
							//if (con.state)
							//	process_mousecursor();
						}

						//vram
						dd.VRAM_show();

						//flipping
						dd.flip(option.data.vsync);

						break;
					}

				case EXIT:
					{
						//fade to black, exit all loops, exit program
						dd.gamma_fade(0, 0, 0.5f);
						program_active = false;
						break;
					}
				}
			}
		}
	}

	//free directx interfaces
	mf_cleanup();
}

//------------------------------------------------------------------------------------------------
//
//	master_frame quicksort
//
//	sorts a given array of integer data
//	either from lowest to largest value (order = 0)
//	or from largest to lowest (order = 1)
//
//------------------------------------------------------------------------------------------------

void master_frame::quicksort(int data[],		//array with data
							 int l,				//always 0, left border index of array
							 int r,				//right border index of array (including 0)
							 int order)			//0 = lowest to largest (def), 1 = largest to lowest
{
	//if right index is larger than left index
	if(r > l)
	{
		//
		int lg = l + 1, rg = r;

		int tempdata;
		int key = data[l];

		//infinite loop
		for(; ;)
		{
			//if to sort from lowest to largest
			if (order == 0)
			{
				while (data[lg] <= key && lg < r)
					++lg;

				while (data[rg] >= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}
			else
			//if to sort from largest to lowest
			{
				while (data[lg] >= key && lg < r)
					++lg;

				while (data[rg] <= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}

			//switch pointers
			tempdata	= data[lg];
			data[lg]	= data[rg];
			data[rg]	= tempdata;
		}

		tempdata	= data[rg];
		data[rg]	= data[l];
		data[l]		= tempdata;

		//recursive call of quicksort
		quicksort(data, l, rg - 1, order);
		quicksort(data, rg + 1, r, order);
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame quicksort_zb
//
//	sorts a array of pointers to bones in z-order of bones
//
//------------------------------------------------------------------------------------------------

void master_frame::quicksort_zb(bone *pzb[],		//array with pointers to bone
								int l,				//always 0, left border index of array
								int r,				//right border index of array (including 0)
								int order)			//0 = lowest to largest (def), 1 = largest to lowest
{
	//if right index is larger than left index
	if(r > l)
	{
		//
		int lg = l + 1, rg = r;

		bone *tempdata;
		int key = pzb[l]->z;

		//infinite loop
		for(; ;)
		{
			//if to sort from lowest to largest
			if (order == 0)
			{
				while (pzb[lg]->z <= key && lg < r)
					++lg;

				while (pzb[rg]->z >= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}
			else
			//if to sort from largest to lowest
			{
				while (pzb[lg]->z >= key && lg < r)
					++lg;

				while (pzb[rg]->z <= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}

			tempdata	= pzb[lg];
			pzb[lg]		= pzb[rg];
			pzb[rg]		= tempdata;
		}

		tempdata	= pzb[rg];
		pzb[rg]		= pzb[l];
		pzb[l]		= tempdata;

		//recursive call of quicksort
		quicksort_zb(pzb, l, rg - 1, order);
		quicksort_zb(pzb, rg + 1, r, order);
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame fill_farray_19
//
//	fill float array with 19 elemts
//
//------------------------------------------------------------------------------------------------

void master_frame::fill_farray_19(float data[19], float f0, float f1, float f2, float f3, float f4,
								  float f5, float f6, float f7, float f8, float f9, float f10, float f11,
								  float f12, float f13, float f14, float f15, float f16, float f17, float f18)
{
	data[0]		= f0;
	data[1]		= f1;
	data[2]		= f2;
	data[3]		= f3;
	data[4]		= f4;
	data[5]		= f5;
	data[6]		= f6;
	data[7]		= f7;
	data[8]		= f8;
	data[9]		= f9;
	data[10]	= f10;
	data[11]	= f11;
	data[12]	= f12;
	data[13]	= f13;
	data[14]	= f14;
	data[15]	= f15;
	data[16]	= f16;
	data[17]	= f17;
	data[18]	= f18;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame centerfont
//
//	determines exact offset point of a string to be printed screen centered
//	(only for bitmap font at default size)
//
//------------------------------------------------------------------------------------------------

point master_frame::centerfont(char *ps, RECT screen)
{
	point pos;
	pos.y		= (float)(screen.top + (screen.bottom - screen.top) / 2.0 - 16.0 / 2.0);
	pos.x		= (float)(screen.left + (screen.right - screen.left) / 2.0 - strlen(ps) * 4.0);

	return(pos);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame centerfont overloaded for scanline font
//
//	determines exact offset point of a string to be printed screen centered
//	(scanline with sizefactor 1.0f 32*48 pixels, between each letter 3 * sf pixels)
//
//------------------------------------------------------------------------------------------------

point master_frame::centerfont(char *ps, RECT screen, float sizefactor)
{
	point	pos;

	pos.y		= screen.top +
				  (screen.bottom - screen.top) / 2.0f - 48.0f * sizefactor / 2.0f;
				  //width of all letters times size plus
				  //space between letters times 3 pixel default times size through 2
	pos.x		= screen.left +
				  (screen.right - screen.left) / 2.0f -
				  (strlen(ps) * 32.0f * sizefactor + (strlen(ps) - 1.0f) * 3.0f * sizefactor) / 2.0f;

	return(pos);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame centerfont
//
//	returns integer point and only take length of string to center as argument
//
//------------------------------------------------------------------------------------------------

ipoint master_frame::centerfont(int stringlength, RECT screen)
{
	//verify length
	if (stringlength < 1)
		stringlength = 1;

	ipoint pos;
	pos.y		= (int)(screen.top + (screen.bottom - screen.top) / 2.0 - 16.0 / 2.0);
	pos.x		= (int)(screen.left + (screen.right - screen.left) / 2.0 - stringlength * 4.0);

	return(pos);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame centerfont overloaded for scanline font
//
//	return integer point and only take length of string to center as argument
//
//------------------------------------------------------------------------------------------------

ipoint master_frame::centerfont(int stringlength, RECT screen, float sizefactor)
{
	//verify length
	if (stringlength < 1)
		stringlength = 1;

	ipoint	pos;

	pos.y		= (int)(screen.top +
				  (screen.bottom - screen.top) / 2.0f - 48.0f * sizefactor / 2.0f);
				  //width of all letters times size plus
				  //space between letters times 3 pixel default times size through 2
	pos.x		= (int)(screen.left +
				  (screen.right - screen.left) / 2.0f -
				  (stringlength * 32.0f * sizefactor + (stringlength - 1.0f) * 3.0f * sizefactor) / 2.0f);

	return(pos);
}
//------------------------------------------------------------------------------------------------
//
//	master_frame getstate
//
//	returns ON/OFF string depending on argument (!0/0)
//
//------------------------------------------------------------------------------------------------

char *master_frame::getstate(float state)
{
	//0 and -1 count as OFF, everything else as ON
	if (state == 0 || state == -1)
		return("OFF");
	else
		return("ON");
}

//------------------------------------------------------------------------------------------------
//
//	master_frame getinput_ascii
//
//	reads keyboard and returns ascii code for key pressed
//
//------------------------------------------------------------------------------------------------

int master_frame::getinput_ascii()
{
	return(is.ascii);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame getinput_char
//
//	takes direct input key as argument and returns string message describing dik
//
//------------------------------------------------------------------------------------------------

char *master_frame::getinput_char(int dik)
{
/*	//if argument is not a keyboard button but a mouse button
	if (dik <= 0)
	{
		if (dik == 0)	return("MB0");
		if (dik == -1)	return("MB1");
		if (dik == -2)	return("MB2");
		if (dik == -3)	return("MB3");
	}

	return(is.p_lutDIK_DESC[dik]);*/

	//if argument is keyboard button
	if (dik >= 0 && dik <= 255)
	{
		return(is.p_lutDIK_DESC[dik]);
	}

	//argument is mouse/controller button
	if (dik == 300)				return("M0B0");
	if (dik == 301)				return("M0B1");
	if (dik == 302)				return("M0B2");
	if (dik == 303)				return("M0B3");
	if (dik == 400)				return("M1B0");
	if (dik == 401)				return("M1B1");
	if (dik == 402)				return("M1B2");
	if (dik == 403)				return("M1B3");
	if (dik == 305)				return("M0WU");
	if (dik == 306)				return("M0WD");
	if (dik == 405)				return("M1WU");
	if (dik == 406)				return("M1WD");
	if (dik == 500)				return("C0B0");
	if (dik == 501)				return("C0B1");
	if (dik == 502)				return("C0B2");
	if (dik == 503)				return("C0B3");
	if (dik == 504)				return("C0B4");
	if (dik == 505)				return("C0B5");
	if (dik == 506)				return("C0B6");
	if (dik == 507)				return("C0B7");
	if (dik == 508)				return("C0B8");
	if (dik == 509)				return("C0B9");
	if (dik == 510)				return("C0B10");
	if (dik == 511)				return("C0B11");
	if (dik == 512)				return("C0B12");
	if (dik == 513)				return("C0B13");
	if (dik == 514)				return("C0B14");
	if (dik == 515)				return("C0B15");
	if (dik == 516)				return("C0B16");
	if (dik == 517)				return("C0B17");
	if (dik == 518)				return("C0B18");
	if (dik == 519)				return("C0B19");
	if (dik == 520)				return("C0B20");
	if (dik == 600)				return("C1B0");
	if (dik == 601)				return("C1B1");
	if (dik == 602)				return("C1B2");
	if (dik == 603)				return("C1B3");
	if (dik == 604)				return("C1B4");
	if (dik == 605)				return("C1B5");
	if (dik == 606)				return("C1B6");
	if (dik == 607)				return("C1B7");
	if (dik == 608)				return("C1B8");
	if (dik == 609)				return("C1B9");
	if (dik == 610)				return("C1B10");
	if (dik == 611)				return("C1B11");
	if (dik == 612)				return("C1B12");
	if (dik == 613)				return("C1B13");
	if (dik == 614)				return("C1B14");
	if (dik == 615)				return("C1B15");
	if (dik == 616)				return("C1B16");
	if (dik == 617)				return("C1B17");
	if (dik == 618)				return("C1B18");
	if (dik == 619)				return("C1B19");
	if (dik == 620)				return("C1B20");

	//not found
	return(NOTAVAILABLE);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame FillRECT
//
//	fills a RECT structure (for convenience)
//
//------------------------------------------------------------------------------------------------

RECT &master_frame::fillRECT(RECT &r, int x1, int y1, int x2, int y2)
{
	r.left		= x1;		r.right		= x2;
	r.top		= y1;		r.bottom	= y2;

	return(r);
}

//-------------------------------------------------------------------------------------------------
//
//	master_frame bitstring
//
//	turns length-bit number into bitstring
//
//-------------------------------------------------------------------------------------------------

void master_frame::bitstring(int n, char *pc, int length, bool separator, char sepsymbol)
{
	//verify char pointer
	if (pc == NULL)
	{
		gf_logger(true, "master_frame::bitstring NULLPOINTER PASSED");
		return;
	}

	if (length < 1 || length > sizeof(int) * 8)
	{
		length	= 8;
	}

	//separator offset
	int sep = 0;

	//for length bits
	for (int i = 0; i < length; ++i)
	{
		//if with separator
		if (separator)
		{
			//set separator offset and write separator symbol
			if (i && !((length - i) % 4))
			{
				pc[i + sep] = sepsymbol;
				++sep;
			}
		}

		//shift bits of n ((lenght - 1) - i) times to right
		//read if this bit is 0 or 1 and set the char string accordingly
		if ((n >> ((length - 1) - i)) & 1)		pc[i + sep] = '1';
		else									pc[i + sep] = '0';
	}

	//end of string
	if (separator)
		pc[length + ((length - 1) / 4)] = 0;
	else
		pc[length] = 0;

	return;

/*	//"00000000"
	//for 8 bits
	for (int i = 0; i < 8; ++i)
	{
		//shift bits of n (7 - i) times to right
		//read if this bit is 0 or 1 and set the char string accordingly
		if ((n >> (7 - i)) & 1)		pc[i] = '1';
		else						pc[i] = '0';
	}*/

/*	//"00000000"
	char bitchar[9] = {0};

	//for 8 bits
	for (int i = 0; i < 8; ++i)
	{
		//shift bits of n (7 - i) times to right
		//read if this bit is 0 or 1 and set the char string accordingly
		if ((n >> (7 - i)) & 1)		bitchar[i] = '1';
		else						bitchar[i] = '0';
	}

	hud_add_message("%i: %s", (int)n, bitchar);*/
}

//-------------------------------------------------------------------------------------------------
//
//	master_frame random
//
//	return random integer in argumented range
//	default is between 1 and 0
//	max is first argument since most times the range is between x and 0
//
//-------------------------------------------------------------------------------------------------

int master_frame::random(int max, int min)
{
	return(min + (rand() % (max - min + 1)));
}

//------------------------------------------------------------------------------------------------
//
//	master_frame playsound_s
//
//	plays system sound
//
//------------------------------------------------------------------------------------------------

void master_frame::playsound_s(int b_index, bool stop, bool loop)
{
	//verify sound id (on error set error sound)
	if (b_index < 0 || b_index > NSBS)
		b_index = S_ERROR;

	//stop buffer
	if (stop)
		ds.stopbuffer(BT_SYS, b_index, true);

	//play buffer
	ds.playbuffer(BT_SYS, b_index, loop);

/*	//verify sound id (set error)
	if (i_sound < 0 || i_sound > NSB - 1)
		i_sound = S_ERROR;

	//activate sound
	sbf[i_sound]	= ON;

	//stop buffer
	if (stop)
		ds.stopbuffer(i_sound);

	//play buffer
	ds.playbuffer(sbf);

	//set sound off
	if (setoff)
		sbf[i_sound]	= OFF;*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame playsound_g
//
//	plays general sound
//
//------------------------------------------------------------------------------------------------

void master_frame::playsound_g(int b_type, int b_index, bool stop, bool loop)
{
	//stop buffer
	if (stop)
		ds.stopbuffer(b_type, b_index, true);

	//play buffer
	ds.playbuffer(b_type, b_index, loop);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame process_sound
//
//	calls ds-functions depending on buffers of both players
//	state = 0 default
//	state = 1 stop all player sounds
//	state = 2 resume all player sounds
//
//------------------------------------------------------------------------------------------------

void master_frame::process_sound(int state)
{
	//---- set pan -------------------------------------------------------------------------------

	//update pan every 0.1 seconds
	if (time.current > s_lastpan + time.freq * 0.1)
	{
		ds.setpan(P1, P[P1].s_pan);
		ds.setpan(P2, P[P2].s_pan);
		s_lastpan = time.current;
	}

	//---- stop/resume sounds --------------------------------------------------------------------

	if (state)
	{
		//pause if playing
		if (state == 1)
			//for both players and all soundbuffers
			for (register int p = 0; p < 2; ++p)
				for (register int b = 0; b < NSBP; ++b)
				{
					//if playing, pause
					if (ds.getcurrentposition(p, b))
						ds.stopbuffer(p, b, false);
				}
		//resume if not at start (was playing)
		if (state == 2)
			for (register int p = 0; p < 2; ++p)
				for (register int b = 0; b < NSBP; ++b)
				{
					if (ds.getcurrentposition(p, b))
						ds.playbuffer(p, b, false);
				}

		return;
	}

	//---- process sound -------------------------------------------------------------------------

	//for both players
	for (register int p = 0; p < 2; ++p)
	{
		//for all soundbuffers
		for (register int b = 0; b < NSBP; ++b)
		{
			//if sound to be played
			if (P[p].s_buffer[b] == SB_PLAY)
			{
				//stop buffer if already playing
				ds.stopbuffer(p, b, true);
				//start playing sound
				ds.playbuffer(p, b, false);
				//reset buffer
				P[p].s_buffer[b] = SB_OFF;
			}

			//if sound to be played if not already playing
			if (P[p].s_buffer[b] == SB_PLAY_NP)
			{
				//if sound not playing
				if (ds.getcurrentposition(p, b) == 0)
					//start playing sound
					ds.playbuffer(p, b, false);
				//reset buffer
				P[p].s_buffer[b]	= SB_OFF;
			}

			//if sound to be paused
			if (P[p].s_buffer[b] == SB_PAUSE)
			{
				//stop but don't reset sound
				ds.stopbuffer(p, b, false);
				//set buffer back to play
				//player re-pauses buffer if animation still not advanced
				P[p].s_buffer[b] = SB_PLAY;
			}

			//if sound to be stopped
			if (P[p].s_buffer[b] == SB_STOP)
			{
				//stop and reset sound
				ds.stopbuffer(p, b, true);
				//reset buffer
				P[p].s_buffer[b] = SB_OFF;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame teaser
//
//	teaser sequence (mf::data_te contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::teaser()
{
	//---- user input ----------------------------------------------------------------------------

	//exit teaser
	if (is.dikey1D[SYS_ESC] & 0x80)
	{
		//play sound 
		playsound_s(S_MENTER);

		program_state = EXIT;
		return;
	}

	//--------------------------------------------------------------------------------------------

	//increase speed of backgroundmusic at certain position
	if (ds.getcurrentposition(BT_BGM, -1) >= 464000)
		ds.setfrequency(BT_BGM, -1, 1.3f);

	//---- initialization ------------------------------------------------------------------------

	//if not initialized
	if (data_te.state == 0)
	{
		//set to next state
		data_te.state = 1;
//!!
//data_te.state = 3;

		//set starting time
		data_te.t_start = time.current;

		//set gamma to black
		dd.gamma_set(0.0f, 0.0f, 0.0f);
		//clear screen
		dd.colorfill();		dd.flip(option.data.vsync);
		dd.colorfill();		dd.flip(option.data.vsync);
//dd.gamma_set();
//data_te.t_start_a = time.current;

		//---- set default data ------------------------------------------------------------------

		//change default stance
		P[P2].set_stance(SRIGHT);

		//names
		strcpy(option.data.name[P1], "Expert Timing");
		strcpy(option.data.name[P2], "Fast as Lightning");
	}

	//---- logos ---------------------------------------------------------------------------------

	if (data_te.state == 1)
	{
		//start background music
		if (time.current >= data_te.t_start + (time.freq * 1.0f))
			ds.playbgm();

		//if at least 2 seconds passed since start
		if (time.current >= data_te.t_start + (time.freq * 2.0f) &&
			ds.getcurrentposition(BT_BGM, -1) >= 19700)
		{
			//start background music
			ds.playbgm();

			//fill background
			dd.colorfill();

			//"Killing Me Software�"
			char label[21]	= "Killing Me Software ";
			label[19]		= (char)169;
			dd.typefont((int)centerfont(label, dd.rSCREEN169).x,
						(int)centerfont(label, dd.rSCREEN169).y, label, 0, 0, 0, 1.0f, bmfwhite);
			//show screen
			dd.flip(option.data.vsync);

			//fade to standard
			dd.gamma_fade(1, 0, 3.0f);

			//fade to black
			dd.gamma_fade(0, 0, 2.0f);

			//pause
			ppause.sleep_pause(time.current, 1.0f);

			//fill background
			dd.colorfill();

			//"Project Beatmaster(tm) Teaser"
			char pbt[27]	= "Project Beatmaster  Teaser";
			pbt[18]			= (char)1;
			dd.typefont((int)centerfont(pbt, dd.rSCREEN169).x,
						(int)centerfont(pbt, dd.rSCREEN169).y, pbt, 0, 0, 0, 1.0f, bmfwhite);
			//show screen
			dd.flip(option.data.vsync);

			//fade to standard
			dd.gamma_fade(1, 0, 3.0f);

			//fade to black
			dd.gamma_fade(0, 0, 2.0f);

			//pause
			ppause.sleep_pause(time.current, 1.0f);

			//fill background
			dd.colorfill();

			//draw names and winning points
			RECT	r_plname1, r_plname2;
			r_plname1.left = 0;		r_plname1.right = 399;
			r_plname2.left = 400;	r_plname2.right = 799;
			dd.typefont((int)centerfont(option.data.name[P1], r_plname1, 0.35f).x,
						29,
						option.data.name[P1], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
			dd.typefont((int)centerfont(option.data.name[P2], r_plname2, 0.35f).x,
						29,
						option.data.name[P2], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
//			dd.drawwinpoints(P[P1].winloss, (int)centerfont(option.data.name[P1], r_plname1, 0.35f).x, P[P2].winloss, (int)centerfont(option.data.name[P2], r_plname2, 0.35f).x, option.data.bw_mode, option.data.rounds);
			dd.drawwinpoints(option.data.rounds, option.data.bw_mode, option.data.roundtime,
							 data_ig.gl_winpoints,
							 option.data.fistcolor[P1], option.data.fistcolor[P2]);

			//show screen
			dd.flip(option.data.vsync);

			//fade to standard
			dd.gamma_fade(1, 0, 1.0f);

			//bordermove and zoom with names and winning points
//			dd.bordermove(0, 0, 2, 2.0f, 255, 255, 255, 1);
			game_startup(2.0f, 3.0f, 2.0f);

			//increase state
			data_te.state = 2;
			//set sequence starting time
			data_te.t_start_a = time.current;
		}
	}

	//---- move sequence -------------------------------------------------------------------------

	//guard low
	if (data_te.state == 2)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 2.0f))
		if (time.current >= data_te.t_start + (time.freq * 30.0f) &&
			ds.getcurrentposition(BT_BGM, -1) >= 464000)
		{
			P[P1].stance_arms = 10;
			P[P1].al_create_idle_cycle(0, 0);
			P[P1].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 3;
		}
	}

	//guard hi
	if (data_te.state == 3)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
//			P[P1].pmessage.set_message("Different guards", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Different guards");

		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			P[P1].stance_arms = 100;
			P[P1].al_create_idle_cycle(0, 0);
			P[P1].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 4;
		}
	}

	//guard mi
	if (data_te.state == 4)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			P[P1].stance_arms = 50;
			P[P1].al_create_idle_cycle(0, 0);
			P[P1].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 5;
		}
	}

	//guard standard
	if (data_te.state == 5)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.4f))
		{
			P[P1].stance_arms = 71;
			P[P1].al_create_idle_cycle(0, 0);
			P[P1].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 6;
		}
	}

	//change stance to right
	if (data_te.state == 6)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
//			P[P1].pmessage.set_message("Stances", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Stances");

		if (time.current >= data_te.t_start_a + (time.freq * 2.0f))
		{
			is.PA[P1][AN_STANCE_FEET] = AS_ACTIVE;
			data_te.t_start_a = time.current;
			data_te.state = 7;
		}
	}

	//change stance back to left
	if (data_te.state == 7)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			is.PA[P1][AN_STANCE_FEET] = AS_ACTIVE;
			data_te.t_start_a = time.current;
			data_te.state = 8;
		}
	}

	//walk back
	if (data_te.state == 8)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			if (P[P1].sk.p_ref->v.p[0].x > 180)
			{
//				P[P1].pmessage.set_message("Walking", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
				P[P1].pmessage.set_message(PM_DEFAULT, green, "Walking");

				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 9;
			}
		}
	}

	//walk foward
	if (data_te.state == 9)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.5f))
		{
			if (P[P1].sk.p_ref->v.p[0].x < 360)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 10;
			}
		}
	}

	//walk back
	if (data_te.state == 10)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			if (P[P1].sk.p_ref->v.p[0].x > 300)
			{
				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 11;
			}
		}
	}

	//walk back
	if (data_te.state == 11)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			if (P[P1].sk.p_ref->v.p[0].x > 190)
			{
				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 12;
			}
		}
	}

	//walk forward
	if (data_te.state == 12)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			if (P[P1].sk.p_ref->v.p[0].x < 249)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 13;

//				P[P1].pmessage.set_message("Jabs in different heights", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Jabs in different heights");
			}
		}
	}

	//hi jab
	if (data_te.state == 13)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			is.mm_angle[P1]	= 350;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 14;
		}
	}

	//mi jab
	if (data_te.state == 14)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.4f))
		{
			is.mm_angle[P1]	= 0;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 15;
		}
	}

	//lower jab
	if (data_te.state == 15)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.4f))
		{
			is.mm_angle[P1]	= 15;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 16;
		}
	}

	//lowest jab
	if (data_te.state == 16)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.4f))
		{
			is.mm_angle[P1]	= 40;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 17;

//			P[P1].pmessage.set_message("Evade and counter", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Evade and counter");
		}
	}

	//evade hi
	if (data_te.state == 17)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f) &&
			P[P1].fatigue == 0)
		{
			P[P1].al_activate_slot(aslot_action, AC_EVADE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 18;
		}
	}

	//counter jab 1
	if (data_te.state == 18)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			is.mm_angle[P1]	= 345 + 0 + (rand() % (10 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 19;
		}
	}

	//counter jab 2
	if (data_te.state == 19)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			is.mm_angle[P1]	= 345 + 0 + (rand() % (10 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB_HOOK, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			//change P2 stance
			is.PA[P2][AN_STANCE_FEET] = AS_ACTIVE;

			data_te.t_start_a = time.current;
			data_te.state = 20;
		}
	}

	//kick fwd mi
	if (data_te.state == 20)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f) &&
			P[P1].fatigue == 0)
		{
			is.mm_angle[P1]	= 0;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 21;

//			P[P1].pmessage.set_message("Kicking", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Kicking");
		}
	}

	//kick fwd low
	if (data_te.state == 21)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			is.mm_angle[P1]	= 35;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 22;
		}
	}

	//kick swd
	if (data_te.state == 22)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.5f))
		{
			is.mm_angle[P1]	= 0;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_SWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 23;
		}
	}

	//jab pre
	if (data_te.state == 23)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f) &&
			P[P1].fatigue == 0)
		{
//			P[P1].pmessage.set_message("Cancel or delay actions", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Cancel or delay actions");

			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 24;
		}
	}

	//cancel pre jab
	if (data_te.state == 24)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.5f))
		{
			P[P1].al_deactivate_slot(aslot_action);

			//change P2 stance
			is.PA[P2][AN_STANCE_FEET] = AS_ACTIVE;

			data_te.t_start_a = time.current;
			data_te.state = 25;
		}
	}

	//jab pre
	if (data_te.state == 25)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f) &&
			P[P1].fatigue == 0)
		{
			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 26;
		}
	}

	//complete pre jab
	if (data_te.state == 26)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 27;
		}
	}

	//jab pre
	if (data_te.state == 27)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f) &&
			P[P1].fatigue == 0)
		{
			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 28;
		}
	}

	//cancel pre jab faster
	if (data_te.state == 28)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.2f))
		{
			P[P1].al_deactivate_slot(aslot_action);

			data_te.t_start_a = time.current;
			data_te.state = 29;
		}
	}

	//walk back
	if (data_te.state == 29)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			if (P[P1].sk.p_ref->v.p[0].x > 249)
			{
				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 30;
			}
		}
	}

	//kick fwd pre
	if (data_te.state == 30)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 31;
		}
	}

	//kick fwd cancel
	if (data_te.state == 31)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.75f))
		{
			P[P1].al_deactivate_slot(aslot_action);

			//lower P2 guard
			P[P2].stance_arms = 10;
			P[P2].al_create_idle_cycle(0, 0);
			P[P2].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 32;
		}
	}

	//kick fwd pre
	if (data_te.state == 32)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 33;
		}
	}

	//complete pre kick fwd
	if (data_te.state == 33)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 34;
		}
	}

	//kick fwd pre
	if (data_te.state == 34)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			is.mm_angle[P1]	= 0 + 0 + (rand() % (5 - 0 + 1));
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

			data_te.t_start_a = time.current;
			data_te.state = 35;
		}
	}

	//kick fwd cancel
	if (data_te.state == 35)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.4f))
		{
			P[P1].al_deactivate_slot(aslot_action);

			//lower P2 guard
			P[P2].stance_arms = 10;
			P[P2].al_create_idle_cycle(0, 0);
			P[P2].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 36;
		}
	}

	//start walking forward
	if (data_te.state == 36 ||
		data_te.state == 37)
	{
//		P[P1].pmessage.set_message("Actions while moving", 0, 0, 0, 255, 0, 0, 0.35f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Actions while moving");

		if (time.current >= data_te.t_start_a + (time.freq * 1.5f))
		{
			//raise P2 guard
			if (time.current >= data_te.t_start_a + (time.freq * 2.3f))
			{
				P[P2].stance_arms = 75;
				P[P2].al_create_idle_cycle(0, 0);
				P[P2].al_activate_slot(aslot_cycle, AN_IDLE_HI);
			}

			//jab while walking
			if (time.current >= data_te.t_start_a + (time.freq * 2.0f) &&
				data_te.state == 36)
			{
				is.mm_angle[P1]	= 345 + 0 + (rand() % (10 - 0 + 1));
				if (is.mm_angle[P1] > 270)
					is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
				if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
					is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
				if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
					is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
				P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
				P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

				data_te.state = 37;
			}

			if (P[P1].sk.p_ref->v.p[0].x < 450)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 38;
			}
		}
	}

	//start walking backward
	if (data_te.state == 38 ||
		data_te.state == 39)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.1f))
		{
			//jab while walking
			if (time.current >= data_te.t_start_a + (time.freq * 1.0f) &&
				data_te.state == 38)
			{
				is.mm_angle[P1]	= 350;
				if (is.mm_angle[P1] > 270)
					is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
				if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
					is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
				if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
					is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
				P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
				P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

				data_te.state = 39;
			}

			if (P[P1].sk.p_ref->v.p[0].x > 320)
			{
				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 40;
			}
		}
	}

	//start walking forward
	if (data_te.state == 40 ||
		data_te.state == 41 ||
		data_te.state == 42)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.5f))
		{
			//kick pre while walking
			if (time.current >= data_te.t_start_a + (time.freq * 0.8f) &&
				data_te.state == 40)
			{
				is.mm_angle[P1]	= 10;
				if (is.mm_angle[P1] > 270)
					is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
				if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
					is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
				if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
					is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
				P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
				P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

				//P2 message
//				P[P2].pmessage.set_message("Careful!", 0, 0, 0, 0, 255, 0, 0.35f, 2.0f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Careful!");

				data_te.state = 41;
			}

			//kick final while walking
			if (time.current >= data_te.t_start_a + (time.freq * 1.2f) &&
				data_te.state == 41)
			{
				is.mm_angle[P1]	= 35;
				if (is.mm_angle[P1] > 270)
					is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
				if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
					is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
				if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
					is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
				P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;
				data_te.state = 42;
			}

			if (P[P1].sk.p_ref->v.p[0].x < 470)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				//P2 message
//				P[P2].pmessage.set_message("Outch!", 0, 0, 0, 0, 255, 0, 0.35f, 2.0f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Outch!");

				data_te.t_start_a = time.current;
				data_te.state = 43;
			}
		}
	}

	//start walking backward
	if (data_te.state == 43 ||
		data_te.state == 44)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			//kick pre while walking
			if (time.current >= data_te.t_start_a + (time.freq * 1.0f) &&
				data_te.state == 43)
			{
				is.mm_angle[P1]	= 0;
				if (is.mm_angle[P1] > 270)
					is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
				if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
					is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
				if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
					is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
				P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
				P[P1].p_aslot[aslot_action]->state[P1]		= AS_PRE;

				data_te.state = 44;
			}

			if (P[P1].sk.p_ref->v.p[0].x > 400)
			{
				is.t_move[P1][0] = 1.0f;
				is.PA[P1][AN_WALK_BWD] = AS_ACTIVE;
			}
			else
			{
				//cancel kick
				P[P1].al_deactivate_slot(aslot_action);
				data_te.t_start_a = time.current;
				data_te.state = 45;
			}
		}
	}

	//walk foward
	if (data_te.state == 45)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.2f))
		{
			if (P[P1].sk.p_ref->v.p[0].x < 450)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 46;
			}
		}
	}

	//hi jab
	if (data_te.state == 46)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.8f))
		{
			is.mm_angle[P1]	= 350;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 47;
		}
	}

	//kick fwd mi
	if (data_te.state == 47)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.2f))
		{
			is.mm_angle[P1]	= 0;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 48;
		}
	}

	//guard low
	if (data_te.state == 48)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.5f))
		{
			P[P1].stance_arms = 10;
			P[P1].al_create_idle_cycle(0, 0);
			P[P1].al_activate_slot(aslot_cycle, AN_IDLE_HI);

			data_te.t_start_a = time.current;
			data_te.state = 49;
		}
	}

	//tap cross 1
	if (data_te.state == 49)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.5f))
		{
			is.mm_angle[P1]	= 340;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			//P[P1].al_activate_slot(aslot_action, AC_TAP_CROSS, is.mm_angle[P1], is.mm_angle_180[P1]);
			//P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 50;
		}
	}

	//walk foward
	if (data_te.state == 50)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			if (P[P1].sk.p_ref->v.p[0].x < 500)
			{
				is.t_move[P1][1] = 1.0f;
				is.PA[P1][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 51;
			}
		}
	}

	//tap cross 2
	if (data_te.state == 51)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 0.6f))
		{
			is.mm_angle[P1]	= 350;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			//P[P1].al_activate_slot(aslot_action, AC_TAP_CROSS, is.mm_angle[P1], is.mm_angle_180[P1]);
			//P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			data_te.t_start_a = time.current;
			data_te.state = 52;
		}
	}

	//counter jab
	if (data_te.state == 52)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.3f))
		{
			is.mm_angle[P1]	= 330;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P1], is.mm_angle_180[P1]);
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;

			//P2 message
//			P[P2].pmessage.set_message("Careful!", 0, 0, 0, 0, 255, 0, 0.35f, 2.0f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Careful!");
			//P2 duck
			P[P2].al_activate_slot(aslot_action, AC_DUCK);

			data_te.t_start_a = time.current;
			data_te.state = 53;
		}
	}

	//P2 walk foward
	if (data_te.state == 53)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.2f))
		{
			if (P[P2].sk.p_ref->v.p[0].x > 620)
			{
				is.t_move[P2][1] = 1.0f;
				is.PA[P2][AN_WALK_FWD] = AS_ACTIVE;
			}
			else
			{
				data_te.t_start_a = time.current;
				data_te.state = 54;
			}
		}
	}

	//P2 jab
	if (data_te.state == 54)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 0.12f))
		{
			//!!
//			option.data.speed = 0.5f;

			is.mm_angle[P2]	= 190;
			if (is.mm_angle[P2] > 270)
				is.mm_angle_180[P2] = is.mm_angle[P2] - 271;
			if (is.mm_angle[P2] >= 0 && is.mm_angle[P2] <= 90)
				is.mm_angle_180[P2] = is.mm_angle[P2] + 89;
			if (is.mm_angle[P2] > 90 && is.mm_angle[P2] <= 270)
				is.mm_angle_180[P2] = 270 - is.mm_angle[P2];
			P[P2].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[P2], is.mm_angle_180[P2]);
			P[P2].p_aslot[aslot_action]->state[P2]		= AS_FINAL;

			//set jab to more power
			P[P2].p_aslot[aslot_action]->gl_damage = 15;

			data_te.t_start_a = time.current;
			data_te.state = 55;
		}
	}

/*	//tap jab
	if (data_te.state == 43)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.5f))
		{
			P[P1].al_activate_slot(aslot_action, AC_TAP_JAB);
			is.mm_angle[P1]	= 350;
			if (is.mm_angle[P1] > 270)
				is.mm_angle_180[P1] = is.mm_angle[P1] - 271;
			if (is.mm_angle[P1] >= 0 && is.mm_angle[P1] <= 90)
				is.mm_angle_180[P1] = is.mm_angle[P1] + 89;
			if (is.mm_angle[P1] > 90 && is.mm_angle[P1] <= 270)
				is.mm_angle_180[P1] = 270 - is.mm_angle[P1];
			P[P1].p_aslot[aslot_action]->state[P1]		= AS_FINAL;
			P[P1].p_aslot[aslot_action]->ui_valid[P1]	= 1;

			data_te.t_start_a = time.current;
			data_te.state = 44;
		}
	}*/

	//slowdown
	if (data_te.state == 53 ||
		data_te.state == 54 ||
		data_te.state == 55)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			if (option.data.speed - 0.96f * time.sca >= 0)
				option.data.speed -= 0.96f * (float)time.sca;
			else
			{
				option.data.speed = 0;

				data_te.t_start_a = time.current;
				data_te.state = 57;
			}
		}
	}

/*	//idling
	if (data_te.state == 56)
	{
		if (time.current >= data_te.t_start_a + (time.freq * 1.0f))
		{
			data_te.t_start_a = time.current;
			data_te.state = 57;
		}
	}*/

	//reduce volume of bgm
	if (data_te.state >= 53 &&
		data_te.state < 58)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 2.0f))
		{
			//reduce volume
			ds.setvolume(BT_BGM, -1, (int)(ds.getvolume(BT_BGM, -1) - 500.0f * time.sca));

			//if off increase state
			if (ds.getvolume(BT_BGM, -1) <= -5000)
			{
				//volume off
				ds.setvolume(BT_BGM, -1, -10000);
				ds.stopbgm();
				data_te.t_start_a = time.current;
				data_te.state = 58;
			}
		}
	}

	//ending
	if (data_te.state == 58)
	{
//		if (time.current >= data_te.t_start_a + (time.freq * 2.0f))
		{
			//fade to black
			dd.gamma_fade(0, 0, 2.0f);

			//fill background
			dd.colorfill();			dd.flip(option.data.vsync);
			dd.colorfill();			dd.flip(option.data.vsync);
			dd.colorfill();
			//"When it's done"
			dd.typefont((int)centerfont("When it's done", dd.rSCREEN169).x,
						(int)centerfont("When it's done", dd.rSCREEN169).y, "When it's done", 0, 0, 0, 1.0f, bmfwhite);
			//show screen
			dd.flip(option.data.vsync);

			//fade to standard
			dd.gamma_fade(1, 0, 2.0f);

			//fade to black
			dd.gamma_fade(0, 0, 1.0f);

			dd.colorfill();
			//"Design is law!!1"
			dd.typefont((int)centerfont("Design is law!!1", dd.rSCREEN169).x,
						(int)centerfont("Design is law!!1", dd.rSCREEN169).y, "Design is law!!1", 0, 0, 0, 1.0f, bmfwhite);
			//show screen
			dd.flip(option.data.vsync);

			//fade to standard
			dd.gamma_fade(1, 0, 2.0f);

			//fade to black
			dd.gamma_fade(0, 0, 1.0f);

			data_te.t_start_a = time.current;
			data_te.state = 100;
		}
	}

	//exit
	if (data_te.state == 100)
	{
		program_state = EXIT;
		return;
	}

	//---- standard process ----------------------------------------------------------------------

	//!!
	if (data_te.state >= 2)
	{
/*		//!! geht nicht, auch nicht beim ingame zoom
		for (register int i = 0; i < 256; ++i)
		{
			if (i != DIK_ESCAPE)
				is.dikey[i] = 0;

			for (register int b = 0; b < 4; ++b)
			{
				is.dimouse[0].rgbButtons[b] = 0;
				is.dimouse[1].rgbButtons[b] = 0;
				is.dimouse[2].rgbButtons[b] = 0;
			}
		}*/

		//draw background
		dd.drawbackground(255, 255, 255, 1, 1, 1);

		//show framerate if on
		if (false)
		{
			//dd.typefont(8, 8, "FPS:");	dd.typefont(48, 8, "", time.fps, 0);
			dd.typebmf(8, 8, bmfwhite, "FPS: %i", time.fps);
		}

		//calculate shadow data
		calculate_shadows();

		//process input handling every frame
		P[P1].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
		P[P2].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);

		//for all subframes
		for (register int sf = 0; sf < option.data.subframes; ++sf)
		{
			//animate
			P[P1].al_animate(false);
			P[P2].al_animate(false);

			//calculate skeleton
			P[P1].process_bones(s_scale, s_mpy);
			P[P2].process_bones(s_scale, s_mpy);

			//switching sides
			auto_side_switch();

			//process game logic
			P[P1].gl_process_game_logic(is.t_move);
			P[P2].gl_process_game_logic(is.t_move);

			//do collision detection tests
			collision_detection();

			//handle damage
			rcd.damage[P1] = P[P1].gl_process_damage_off(is.t_move);
			rcd.damage[P2] = P[P2].gl_process_damage_off(is.t_move);
		}

		//update particle arrays
		P[P1].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);
		P[P2].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);

		//sort z
		quicksort_zb(pd.pzb, 0, 37, 1);

/*		//"I know Kung Fu"
		if (ds.getcurrentposition(-1) > 418000 &&
			ds.getcurrentposition(-1) < 437000)
			dd.typefont((int)P[P1].sk.chead.x - 80, (int)P[P1].sk.chead.y - 50,
						"I know Kung Fu...", 0, 0, 1, 0.35f, 0, 0, 0, 255, 0, 0);

		//"Show me!"
			dd.typefont((int)P[P2].sk.chead.x - 40, (int)P[P2].sk.chead.y - 50,
						"Show Me!", 0, 0, 1, 0.35f, 0, 0, 0, 0, 255, 0);

		//"?"
		if (data_te.state == 38 ||
			data_te.state == 39)
			dd.typefont((int)P[P2].sk.chead.x - 10, 170, "?", 0, 0, 1, 0.5f);

		//"!"
		if (data_te.state == 54 ||
			data_te.state == 55)
			dd.typefont((int)P[P2].sk.chead.x - 10, 170, "!", 0, 0, 1, 0.5f);*/

		//"I know Kung Fu"
		if (ds.getcurrentposition(BT_BGM, -1) > 418000 &&
			ds.getcurrentposition(BT_BGM, -1) < 437000)
//			P[P1].pmessage.set_message("I know Kung Fu...", 0, 0, 0, 255, 0, 0, 0.35f, 0.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "I know Kung Fu...");

		//"Show me!"
		if (ds.getcurrentposition(BT_BGM, -1) > 448000 &&
			ds.getcurrentposition(BT_BGM, -1) < 458000)
//			P[P2].pmessage.set_message("Show Me!", 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "Show me!");

		if (ds.getcurrentposition(BT_BGM, -1) > 1123000 &&
			ds.getcurrentposition(BT_BGM, -1) < 1200000)
//			P[P2].pmessage.set_message("da da da da!", 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "da da da da!");

		//"?"
		if (data_te.state == 38)
//			P[P2].pmessage.set_message("?", 0, 0, 0, 0, 255, 0, 0.5f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "?");

		//"!"
		if (data_te.state == 54)
//			P[P2].pmessage.set_message("!", 0, 0, 0, 0, 255, 0, 0.5f, 1.5f, time.current);
			P[P1].pmessage.set_message(PM_DEFAULT, green, "!");

		//render scene
		dd.drawscene(&pd, 0, 0, black, 0, 0, 0);

/*		//draw player message if active
		if (P[P1].pmessage.active)
			dd.typefont((int)P[P1].pmessage.pos.x, (int)P[P1].pmessage.pos.y,
						P[P1].pmessage.message, 0, 0, 1, P[P1].pmessage.size,
						P[P1].pmessage.b_color.r, P[P1].pmessage.b_color.g, P[P1].pmessage.b_color.b,
						P[P1].pmessage.f_color.r, P[P1].pmessage.f_color.g, P[P1].pmessage.f_color.b);
		if (P[P2].pmessage.active)
			dd.typefont((int)P[P2].pmessage.pos.x, (int)P[P2].pmessage.pos.y,
						P[P2].pmessage.message, 0, 0, 1, P[P2].pmessage.size,
						P[P2].pmessage.b_color.r, P[P2].pmessage.b_color.g, P[P2].pmessage.b_color.b,
						P[P2].pmessage.f_color.r, P[P2].pmessage.f_color.g, P[P2].pmessage.f_color.b);*/
	}

	//--------------------------------------------------------------------------------------------

/*
script:
+ zugehen auf p2, aktion, ps2 ausweichen, "?!"
+ konter von p2, "!", slowdown, ende

- show_restore unterdr�cken?

!! aslot_cycle deaktivieren

SCRIPT:

- black screen, gamma black
- "killing me software", gamma standard
- gamma black
- "project beatmaster teaser", gamma starndard
- gamma black
- borders off, zoom in
	- 		dd.bordermove(0, 0, 2, 1.0f, 255, 255, 255);
- kung fu fighting und "i know kung fu" "show me"
- frequency hochsetzen
- bis dahin idling, evtl. schon unterschiedliche armhaltungen

- guard change
	- von standard auf tief
	- von tief auf hoch
	- von hoch auf standard
- stellungswechsel, zur�ck
- laufen
	- zur�ck zwei, drei schritte, vorw�rts (koordinaten)
	+ mehr variationen (schnell vor zur�ck)
- jab in verschiedenen h�henstufen
	- zufallskomponente
	- gerade
	- tief
	- hoch
	+ evade hi
	- doppeljab
- kick in verschiedenen h�henstufen
	- mittel
	- tief
	- hoch
	+ zu viel fatigue, l�ngere pause
- jab ant�uschen
	+ verz�gert ausf�hren
	+ noch mal ant�uschen
- kick ant�uschen
	+ verz�gert ausf�hren
	+ noch mal ant�uschen
- jab in hinbewegungbewegung
	+ etwas fr�her schlagen
- jab in r�ckbewegung
- kick in hinbewegung
	+ muss verfeinert werden mit pre-state und allem drum und dran
+ kick anget�uscht in hinbewegung
- ausweichen
	- evade hi
	- evade mi
	- duck
- guard tief
	+ schneller
- tap cross
+ noch ein tap cross
+ schneller jab
+ evade hi und nach hinten laufen
+ nach vorn und kick
- fadeout
*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame startup
//
//	startup sequence of program (mf::data_su contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::startup()
{
	//---- user cancel ---------------------------------------------------------------------------

/*	//if user hits esc/punch button cancel startup
	if (is.dikey1D[SYS_ESC] & 0x80 ||
		is.ui_state1D[P1][PUNCH] & 0x80 ||
		is.ui_state1D[P2][PUNCH] & 0x80)*/
	//on any button
	if (is.key1DUALL() ||
		is.mouse1DUALL())
	{
		//explode particles, if not already done
		if (data_su.pfx.state < 3)
		{
			//state to initialize explosion, no idle time, assign current time
			data_su.pfx.state		= 2;
			data_su.pfx.t_idle		= 0;
			data_su.pfx.t_start_i	= time.current;

			//play sound
			playsound_s(S_MENTER);
		}

		return;

/*		//if background is black
		if (data_su.cbackground.r == 0)
			//fade to black
			dd.gamma_fade(0, 0, 1.0f);
		else
		{
			//fade to white, paint screen white and reset gamma
			dd.gamma_fade(0, 1, 1.0f);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.gamma_set();
		}

		//exit startup
		data_su.state = 3;*/
	}

	//---- initialization ------------------------------------------------------------------------

	//if not initialized
	if (data_su.state == 0)
	{
		//initialize and set state to 1
		data_su.state = 1;

		//initialize random number function
		srand((unsigned int)time.current);

		//set start time
		data_su.t_start = time.current;

		//random background color (black or white)
		//if (0 + (rand() % (1 - 0 + 1)) == 0)
		if (random())
		{
			data_su.cbackground.setcolor(black);
			//old colors
			//data_su.c_scheme	= (0 + (rand() % (6 - 0 + 1))) + 14;
			data_su.c_scheme	= random(7) + 200;
		}
		else
		{
			data_su.cbackground.setcolor(white);
			//old colors
			//data_su.c_scheme	= 0 + (rand() % (6 - 0 + 1));
			data_su.c_scheme	= random(7) + 300;
		}

		//create random number for drawparticle function used
		//for further color schemes
		//data_su.r_no			= 0 + (rand() % (1 - 0 + 1));

		//overwrite random data if it's the first time the program
		//is started (indicated if no config available by option.dataDEF.sys_first
		if (option.dataDEF.sys_first == 1)
		{
			//set background to black and colorscheme to pure yellow
			data_su.cbackground.setcolor(black);
			//data_su.c_scheme = 20;
			data_su.c_scheme = 200;
			//data_su.r_no = 0;
		}

		//create particle array of LABEL
//		char label[21]	= "Killing Me Software ";
//		label[19]		= (char)1;
//		data_su.pfx.pp = dd.font_pfx(label,
		data_su.pfx.pp = dd.font_pfx(LABEL,
									 data_su.pfx.size,
									 (int)centerfont(LABEL, dd.rSCREEN).x,
									 (int)centerfont(LABEL, dd.rSCREEN).y);
		if (data_su.pfx.pp == NULL)
		{
			gf_logger(true, "master_frame::startup dd.font_pfx == NULL");
			return;
		}

		//valid screen area
		RECT rscr; fillRECT(rscr, 0, 0, 799, 599);

		//initialize particle heap
		data_su.pfx.initialization(time.freq,			//timer frequency
								   time.current,		//current time
								   rscr,				//valid screen
								   2000, 3000,			//uneffected time
								   2.0f,				//idle time
								   0.0f, 0.5f, 0.5f,	//grav, dampx, dampy
								   50, 120,				//min, max force
								   0, 359,				//min, max angle
								   500, 3000);			//min, max lifetime

		//set gamma black, paint screen, flip it clean, show it
		dd.gamma_set(0.0f, 0.0f, 0.0f);
		dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
		dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
		dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
		//fade to standard
		dd.gamma_fade(1, 0, 1.0f);
		//!!
		//dd.gamma_fade_ini(1, 1, black, 0.5f);

		//update timer so time.sca is reset after gammafade/border move in
		//(difference between now and last update, if we update twice,
		//the difference won't be unrealistic big)
		//also set time.sca in case the next function continues with program
		time.get_tfr();
		time.sca = 0.0f;
	}

	//---- run startup ---------------------------------------------------------------------------

	//continue startup sequence if initialized
	if (data_su.state == 1 || data_su.state == 2)
	{
		//paint background
		dd.colorfill(data_su.cbackground);

		//update particle heap
		data_su.pfx.update(time.current, time.sca);

		//increase the number of particles to show
		if (data_su.pfx.state == 0)
		{
/*			//if time since start below 2 seconds increase more slowly
			if ((time.current - data_su.t_start) / time.freq < 2.0f)
				data_su.p_show += data_su.pfx.size / 20 * (float)time.sca;
			else
				data_su.p_show += data_su.pfx.size / 2 * (float)time.sca;

			//p_show maximum is size of particle heap
			if (data_su.p_show > data_su.pfx.size)
				data_su.p_show = (float)data_su.pfx.size;
				*/
			//show particles in a timeframe of 4 seconds
			data_su.p_show += (data_su.pfx.size / 4) * (float)time.sca;
			if (data_su.p_show > data_su.pfx.size)
				data_su.p_show = (float)data_su.pfx.size;
		}

		//!!! 2 or 3?
		//play jingle when fx starts idling
		if (data_su.pfx.state == 3 && data_su.soundflag == 0)
		{
			//set soundflag to played
			data_su.soundflag = 1;

			//play sound
			playsound_s(S_JINGLE);
		}

		//re-initialize color scheme if idling is done and not already reinitialized
		if (data_su.pfx.state == 3 && data_su.state != 2)
		{
			//data_su.c_scheme	+= 7;
			data_su.state		= 2;
		}

		//if fx is done, set state to 2
		if (data_su.pfx.state == 4)
			data_su.state = 3;

		//draw particle heap (no shadows)
		dd.drawparticles(data_su.pfx.pp, (int)data_su.p_show, OFF, data_su.c_scheme, data_su.r_no);
	}

	//---- exit startup --------------------------------------------------------------------------

	//if font fx is done
	if (data_su.state == 3)
	{
		//if background is black
		if(data_su.cbackground.r == 0)
		{
			//set gamma black
			dd.gamma_set(0, 0, 0);

			//paint screen white (all buffers)
			data_su.cbackground.setcolor(white);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);

			//fade in
			dd.gamma_fade(1, 0, 1.0f);
		}
		else
		{
			//paint screen white
			data_su.cbackground.setcolor(white);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
			dd.colorfill(data_su.cbackground);		dd.flip(option.data.vsync);
		}

		//set program state to title
		program_state = TITLE;
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame title
//
//	title screen sequence of program (mf::data_ti contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::title()
{
	//---- user input ----------------------------------------------------------------------------

	//do only when label moved in and console not active
	if (data_ti.state == 3 && !con.state)
	{
		//last_input none set when
			//default
		//last_input kb set when
			//input from keyboard (up, down)
		//last_input mouse set when
			//mouse moved and within options area
		//if input from keyboard and no previous selection set default selection
		if (data_ti.last_input == 0 && data_ti.selection == -1)
			data_ti.selection = 0;
		//if user hits uparrow, increase option if not already on top
		//if so, set to bottom and vice versa
		//also play sound
		if (is.dikey1D[SYS_UP] & 0x80)
		{
			if (data_ti.selection > 0)
				--data_ti.selection;
			else
				data_ti.selection = 2;

			//set last input to keyboard
			data_ti.last_input = 0;

			//play sound
			playsound_s(S_MSELECT);
		}

		if (is.dikey1D[SYS_DOWN] & 0x80)
		{
			if (data_ti.selection < 2)
				++data_ti.selection;
			else
				data_ti.selection = 0;

			//set last input to keyboard
			data_ti.last_input = 0;

			//play sound
			playsound_s(S_MSELECT);
		}
		//if mouse input
		if (is.mouse(0, true, true, false))
		{
			//if within option area
			if (hitboxcheck(mcursor[0].r_pos, data_ti.c_selection[3]) ||
				hitboxcheck(mcursor[1].r_pos, data_ti.c_selection[3]))
				//set last input to mouse
				data_ti.last_input = 1;
			else
				//not within option area, and last input from mouse set selection to none
				if (data_ti.last_input == 1)
					data_ti.selection = -1;
		}

/*		//if mouse input and within option area, set last input to mouse
		if (is.mouse(0, true, true, false) && hitboxcheck(cursor_pos_rect, data_ti.c_selection[3]))
			data_ti.last_input = 1;
		//if not within option enclosing area
		if (!hitboxcheck(cursor_pos_rect, data_ti.c_selection[3]))
		{
			//if last input was from mouse, set no selection
			if (data_ti.last_input == 1)
				data_ti.selection = -1;
		}*/

		//---- mouse input -----------------------------------------------------------------------

		//mouse cursor within option
		bool mc_so	= false;
		//for all selections
		for (register int s = 0; s < 3; ++s)
			//if cursor in selection area and last input was from mouse
			if (data_ti.last_input == 1 &&
				(hitboxcheck(mcursor[0].r_pos, data_ti.c_selection[s]) ||
				hitboxcheck(mcursor[1].r_pos, data_ti.c_selection[s])))
			{
				//play sound if not already selected
				if (data_ti.selection != s)
					playsound_s(S_MSELECT);

				//set selection
				data_ti.selection	= s;
				//cursor within option
				mc_so				= true;

				break;
			}

		//play sound when mouse button pressed
//		if (is.dimouse1D[0].rgbButtons[0] & 0x80)
//			playsound_s(S_MSELECT);

		//---- program state ---------------------------------------------------------------------

		//if something is selected
		//and user hits enter or (mouse button and within area)
		//play sound, change program state accordingly
		if (data_ti.selection != -1 &&
			(is.dikey1D[SYS_RETURN] & 0x80 ||
			(is.dimouse1DU[0].rgbButtons[0] & 0x80 && mc_so)))
		{
			//soundbufferflag array
			playsound_s(S_MENTER);

			switch (data_ti.selection)
			{
			//fight
			case (0):
				{
					//reset selection
					data_ti.selection = 0;
					//set last input to keyboard
					data_ti.last_input = 0;
					//set state to return from black
					data_ti.state = 4;

					//fade to black
					dd.gamma_fade(0, 0, 0.5f);
					program_state = INGAME;
					return;
				}

			//options
			case (1):
				{
					//keep selection for return from options menue
					//data_ti.selection = 0;
					//set last input to keyboard
					data_ti.last_input = 0;
					//set state to return from white
					data_ti.state = 5;

					//fade to white
					dd.gamma_fade(0, 1, 0.5f);
					program_state = OPTIONS;
					return;
				}

			//exit
			case (2):
				{
					program_state = EXIT;
					return;
				}
			}
		}
	}

	//---- initialization ------------------------------------------------------------------------

	//if not yet initialized
	if (data_ti.state == 0)
	{
		//initialize and set state to 1
		data_ti.state = 1;

		//initialize random number function
		srand((unsigned int)time.current);

		//type of title screen
		data_ti.style = 0 + (rand() % (1 - 0 + 1));

		//overwrite random data if it's the first time the program
		//is started (indicated if no config available by option.dataDEF.sys_first
		if (option.dataDEF.sys_first == 1)
			data_ti.style = 0;

		//initial yinyang angle is random
		data_ti.yy.set_angle(0, 1);

		//if horizontal style
		if (data_ti.style == 0)
		{
			//assign symbol position
			data_ti.yy.set_position(400, 250);

			//assign start position of "beatmaster"
			data_ti.pos_beat	= -206.0f;			data_ti.pos_master	= 800.0f;

			//assign tm position
			data_ti.tm.x		= 663;				data_ti.tm.y		= 217;
			//assign version position
			data_ti.version.x	= 544;				data_ti.version.y	= 288;
			//assign date position
			data_ti.date.x		= 400;				data_ti.date.y		= 288;
		}
		//if vertical style
		else
		{
			//assign symbol position
			data_ti.yy.set_position(400, 250);

			//assign start position of "beatmaster"
			data_ti.pos_beat	= -73.0f;			data_ti.pos_master	= 601.0f;

			//assign tm position
			data_ti.tm.x		= 556;				data_ti.tm.y		= 258;
			//assign version position
			data_ti.version.x	= 440;				data_ti.version.y	= 329;
			//assign date position
			data_ti.date.x		= 296;				data_ti.date.y		= 329;
		}

		//!! reset gamma, useful if game starts INGAME and returning to title
		dd.gamma_set();

		//move in borders either from above/below or left/right
		dd.bordermove(1, 0 + (rand() % (1 - 0 + 1)), 0, 1.0f);

		//update timer so time.sca is reset after gammafade/border move in
		//(difference between now and last update, if we update twice,
		//the difference won't be unrealistic big)
		//also set time.sca in case the next function continues with program
		time.get_tfr();
		time.sca = 0.0f;

		//set mouse cursor selection areas
		fillRECT(data_ti.c_selection[0], 355, 395, 430, 420);
		fillRECT(data_ti.c_selection[1], 355, 425, 450, 445);
		fillRECT(data_ti.c_selection[2], 355, 450, 415, 475);
		//whole option area
		fillRECT(data_ti.c_selection[3], 355, 395, 450, 475);
		//set cursor pos
		mcursor[P1].set_pos(320, 410);		mcursor[P1].yy.set_speed(0);
		mcursor[P2].set_pos(480, 410);		mcursor[P2].yy.set_speed(0);
		mcursor[P1].toggle_cursor(1);
		mcursor[P2].toggle_cursor(0);
		mcursor[P1].mouse_index	= 0;
	}
	
	//---- yinyang zoom in ------------------------------------------------------------------------

	if (data_ti.state == 1)
	{
		//draw background
		dd.drawbackground();

		//zoom in
		if (data_ti.yy.size + 0.5 * time.sca <= 0.85)
			data_ti.yy.size += (float)(0.5 * time.sca);
		else
		{
			data_ti.yy.set_size(0.85f);
			data_ti.state = 2;
		}

		//decrease angle by 90 degrees/second
		data_ti.yy.angle -= (float)(90 * time.sca);
		data_ti.yy.check_angle();

		//colors
		data_ti.yy.set_colors(red, yellow);

		//calculate yinyang symbol
		//data_ti.yy.calculate();

		//draw yinyang symbol
		dd.drawyinyang(data_ti.yy);
	}

	//---- beatmaster move in --------------------------------------------------------------------

	if (data_ti.state == 2)
	{
		//draw background
		dd.drawbackground();

		//decrease angle by 90 degrees/second
		data_ti.yy.angle -= (float)(90 * time.sca);
		data_ti.yy.check_angle();

		//colors
		data_ti.yy.set_colors(red, yellow);

		//calculate yinyang symbol
		//data_ti.yy.calculate();

		//draw yinyang symbol
		dd.drawyinyang(data_ti.yy);

		//move in
		if (data_ti.style == 0)
		{
			dd.typefont((int)data_ti.pos_beat, 214, "BEAT", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
			//only draw if beat already in position
			if (data_ti.pos_beat == 142)
				dd.typefont((int)data_ti.pos_master, 214, "MASTER", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
		}
		else
		{
			//don't draw master if beat isn't in position because it causes artifacts
			//beat first, master second
			if (data_ti.pos_beat == 173)
				dd.typefont(245, (int)data_ti.pos_master, "MASTER", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
			dd.typefont(297, (int)data_ti.pos_beat, "BEAT", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
/*			//don't draw beat if master isn't in position because it causes artifacts
			//master first, beat second
			if (data_ti.pos_master == 255)
				dd.typefont(297, (int)data_ti.pos_beat, "BEAT", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
			dd.typefont(245, (int)data_ti.pos_master, "MASTER", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);*/
		}

		//if style is horizontal move in beatmaster and play sound
		if (data_ti.style == 0)
		{
			if (data_ti.pos_beat + 348 / 0.5f * time.sca <= 142)
				data_ti.pos_beat += (float)(348 / 0.5f * time.sca);
			else
			{
				data_ti.pos_beat = 142.0f;

				//play sound
				playsound_s(S_MBEAT, false);
			}

			//if "beat" in position move "master", increase state when done
			if (data_ti.pos_beat == 142.0f)
			{
				if (data_ti.pos_master - 448 / 0.5f * time.sca >= 352)
					data_ti.pos_master -= (float)(448 / 0.5f * time.sca);
				else
				{
					data_ti.pos_master = 352.0f;
					data_ti.state = 3;

					//play sound
					playsound_s(S_MBEAT);
				}
			}
		}
		//if style is vertical
		else
		{
			//beat first, master second
			if (data_ti.pos_beat + 245 / 0.5f * time.sca <= 173)
				data_ti.pos_beat += (float)(245 / 0.5f * time.sca);
			else
			{
				data_ti.pos_beat = 173;

				//play sound
				playsound_s(S_MBEAT, false);
			}

			//if "beat" is in position, move "beat", increase state when done
			if (data_ti.pos_beat == 173)
			{
				if (data_ti.pos_master - 405 / 0.5f * time.sca >= 255)
					data_ti.pos_master -= (float)(405 / 0.5f * time.sca);
				else
				{
					data_ti.pos_master = 255;
					data_ti.state = 3;

					//play sound
					playsound_s(S_MBEAT);
				}
			}

/*			//master first, beat second

			if (data_ti.pos_master - 405 / 0.5f * time.sca >= 255)
				data_ti.pos_master -= (float)(405 / 0.5f * time.sca);
			else
			{
				data_ti.pos_master = 255;

				//play sound
				playsound_s(S_MBEAT, false);
			}

			//if "master" is in position, move "beat", increase state when done
			if (data_ti.pos_master == 255)
			{
				if (data_ti.pos_beat + 245 / 0.5f * time.sca <= 173)
					data_ti.pos_beat += (float)(245 / 0.5f * time.sca);
				else
				{
					data_ti.pos_beat = 173;
					data_ti.state = 3;

					//play sound
					playsound_s(S_MBEAT);
				}
			}*/
		}
	}

	//---- idling --------------------------------------------------------------------------------

	if (data_ti.state == 3)
	{
		//draw background
		dd.drawbackground();

		//draw selection area
		if (false)
		{
			rectangle r[4];
			r[0] = data_ti.c_selection[0];
			r[1] = data_ti.c_selection[1];
			r[2] = data_ti.c_selection[2];
			r[3] = data_ti.c_selection[3];
			dd.drawrectangle_array(r, 4, black);
		}

/*		//show data
		if (data_ti.last_input == -1)
			dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: none", time.fps, data_ti.selection);
		if (data_ti.last_input == 0)
			dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: keyboard", time.fps, data_ti.selection);
		if (data_ti.last_input == 1)
			dd.typebmf(10, 74, bmfblue, "FPS: %i  sel [%i], last_input: mouse", time.fps, data_ti.selection);*/

		//decrease angle by 90 degrees/second
		data_ti.yy.angle -= (float)(90 * time.sca);
		data_ti.yy.check_angle();

		//fix logo
		//data_ti.yy.set_angle(45);

		//colors
		data_ti.yy.set_colors(red, yellow);

		//calculate yinyang symbol
		//data_ti.yy.calculate();

		//draw yinyang symbol
		dd.drawyinyang(data_ti.yy);

		float size = 1.5f;
		
		//draw label
		if (data_ti.style == 0)
		{
			dd.typefont((int)data_ti.pos_beat, 214, "BEAT", 0, 0, 1, size, 255, 255, 255, 0, 0, 0);
			dd.typefont((int)data_ti.pos_master, 214, "MASTER", 0, 0, 1, size, 255, 255, 255, 0, 0, 0);
		}
		else
		{
			dd.typefont(297, (int)data_ti.pos_beat, "BEAT", 0, 0, 1, size, 255, 255, 255, 0, 0, 0);
			dd.typefont(245, (int)data_ti.pos_master, "MASTER", 0, 0, 1, size, 255, 255, 255, 0, 0, 0);
		}

		//draw tm
/*		RGBcolor	temp_c;
		point		tm_offset = data_ti.tm;
		dd.drawpoint(tm_offset, temp_c);
		tm_offset.x += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.x += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset	=		data_ti.tm;
		tm_offset.x += 1;	tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset	=		data_ti.tm;
		tm_offset.x += 4;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset	=		data_ti.tm;
		tm_offset.x += 5;	tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset	=		data_ti.tm;
		tm_offset.x += 6;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
		tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);*/
		char trademark[2] = " ";
		trademark[0] = (char)1;
		dd.typefont((int)data_ti.tm.x - 1, (int)data_ti.tm.y - 2, trademark, 0, 0, 0, 1.0f, bmfblack);

		//version and date
		dd.typefont((int)data_ti.version.x, (int)data_ti.version.y, "version:", 0, 0, 0, 1.0f, bmfblack);
		dd.typefont((int)data_ti.version.x + 72, (int)data_ti.version.y, "", VERSION, 3, 0, 1.0f, bmfblack);
		dd.typefont((int)data_ti.date.x, (int)data_ti.date.y, "date:", 0, 0, 0, 1.0f, bmfblack);
		dd.typefont((int)data_ti.date.x + 48, (int)data_ti.date.y, DATE, 0, 3, 0, 1.0f, bmfblack);

		//"�2004 Killing Me Software"
		char copyright[26]	= " 2009 Killing Me Software";
		copyright[0]		= (char)184;
		//dd.typefont(74 * 8, 36 * 16, copyright, 0, 0, 0, 1.0f);
		dd.typefont((int)(centerfont(copyright, dd.rSCREEN169).x), 506,
					copyright, 0, 0, 0, 1.0f, bmfblack);

		//---- options ---------------------------------------------------------------------------

		//to optimize right size
		float font_size = 0.35f;

		//draw options depending of current selection
		//FIGHT!
		if (data_ti.selection == 0) dd.typefont(358, 400, "FIGHT!", 0, 0, 1, font_size, 0, 0, 0, 255, 50, 50);
		else dd.typefont(363, 400, "FIGHT!", 0, 0, 1, font_size);
		//OPTIONS
		if (data_ti.selection == 1) dd.typefont(358, 428, "OPTIONS", 0, 0, 1, font_size, 0, 0, 0, 255, 50, 50);
		else dd.typefont(363, 428, "OPTIONS", 0, 0, 1, font_size);
		//EXIT
		if (data_ti.selection == 2) dd.typefont(358, 454, "EXIT", 0, 0, 1, font_size, 0, 0, 0, 255, 50, 50);
		else dd.typefont(363, 454, "EXIT", 0, 0, 1, font_size);

		//---- mousecursor -----------------------------------------------------------------------

		process_mousecursor(option.data.shadows);
		//dd.typefont(100, 550, "", cursor_pos.x, 1);
		//dd.typefont(100, 566, "", cursor_pos.y, 1);
	}

	//---- fade ins ------------------------------------------------------------------------------
	//after returning from game or options menu

	if (data_ti.state == 4 ||
		data_ti.state == 5)
	{
		//draw and flip it three times to clear backbuffers
		//(title screen has to be redrawn before gammafade, but than it exits this
		//loop which results in another flip which shows the previous menu screen)
		for (register int i = 0; i < 3; ++i)
		{
			//draw background
			dd.drawbackground();

			//colors
			data_ti.yy.set_colors(red, yellow);

			//calculate yinyang symbol
			//data_ti.yy.calculate();

			//draw yinyang symbol
			dd.drawyinyang(data_ti.yy);
			
			//draw label
			if (data_ti.style == 0)
			{
				dd.typefont((int)data_ti.pos_beat, 214, "BEAT", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
				dd.typefont((int)data_ti.pos_master, 214, "MASTER", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
			}
			else
			{
				dd.typefont(297, (int)data_ti.pos_beat, "BEAT", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
				dd.typefont(245, (int)data_ti.pos_master, "MASTER", 0, 0, 1, 1.5f, 255, 255, 255, 0, 0, 0);
			}

			//draw tm
			RGBcolor	temp_c;
			point		tm_offset = data_ti.tm;
			dd.drawpoint(tm_offset, temp_c);
			tm_offset.x += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.x += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset	=		data_ti.tm;
			tm_offset.x += 1;	tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset	=		data_ti.tm;
			tm_offset.x += 4;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset	=		data_ti.tm;
			tm_offset.x += 5;	tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset	=		data_ti.tm;
			tm_offset.x += 6;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);
			tm_offset.y += 1;	dd.drawpoint(tm_offset, temp_c);

			//version and date
			dd.typefont((int)data_ti.version.x, (int)data_ti.version.y, "version:", 0, 0, 0, 1.0f, bmfblack);
			dd.typefont((int)data_ti.version.x + 72, (int)data_ti.version.y, "", VERSION, 3, 0, 1.0f, bmfblack);
			dd.typefont((int)data_ti.date.x, (int)data_ti.date.y, "date:", 0, 0, 0, 1.0f, bmfblack);
			dd.typefont((int)data_ti.date.x + 48, (int)data_ti.date.y, DATE, 0, 3, 0, 1.0f, bmfblack);

			//to optimize right size
			float font_size = 0.35f;

			//draw options
			//highlight last selection
			//highlight FIGHT!
			if (data_ti.selection == 0)
			{
				dd.typefont(358, 400, "FIGHT!", 0, 0, 1, font_size, 0, 0, 0, 255, 50, 50);
				dd.typefont(363, 428, "OPTIONS", 0, 0, 1, font_size);
				//set cursor position
				mcursor[P1].set_pos(320, 410);		mcursor[P1].yy.set_speed(500);
				mcursor[P2].set_pos(480, 410);		mcursor[P2].yy.set_speed(500);
			}
			//highlight OPTIONS
			if (data_ti.selection == 1)
			{
				dd.typefont(363, 400, "FIGHT!", 0, 0, 1, font_size);
				dd.typefont(358, 428, "OPTIONS", 0, 0, 1, font_size, 0, 0, 0, 255, 50, 50);
				//set cursor position
				mcursor[P1].set_pos(320, 435);		mcursor[P1].yy.set_speed(100);
				mcursor[P2].set_pos(480, 435);		mcursor[P2].yy.set_speed(100);
			}
			dd.typefont(363, 454, "EXIT", 0, 0, 1, font_size);
			mcursor[P1].toggle_cursor(1);
			mcursor[P2].toggle_cursor(0);
			mcursor[P1].mouse_index	= 0;

			//show it
			dd.flip(option.data.vsync);
		}

		if (data_ti.state == 4)
		{
			//fade in from black
			dd.gamma_fade(1, 0, 0.5f);

			//reset timer
			time.get_tfr();
			time.sca = 0.0f;
		}
		else
		{
			//fade in from white
			dd.gamma_fade(1, 1, 0.5f);

			//reset timer
			time.get_tfr();
			time.sca = 0.0f;
		}

		//resume idling
		data_ti.state = 3;
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame options
//
//	options menu (mf::data_op contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::options()
{
	//entered from title screen, faded to white

	//---- initialization -------------------------------------------------------------------------

	if (data_op.state == 0)
	{
		//initialize and set state to 1
		data_op.state = 1;

		//reset currently selected option
		data_op.reset_SELOPT();
		//reset sub selection
		data_op.sub_selection		= SUBSEL_NONE;
		//reset selections of all slots
		data_op.SELOPT_reset_selection(0, 0, true);

		//set cursor pos
		//mcursor[P1].set_pos(120, 440);		mcursor[P1].yy.set_speed(0);
		//mcursor[P2].set_pos(225, 440);		mcursor[P2].yy.set_speed(0);
		mcursor[P1].set_pos(300, 100);			mcursor[P1].yy.set_speed(500);
		mcursor[P1].toggle_cursor(1);
		mcursor[P2].toggle_cursor(0);
		mcursor[P1].mouse_index	= 0;
		process_mousecursor(option.data.shadows);

		//draw and flip it three times to clear backbuffers
		for (int f = 0; f < 3; ++f)
		{
			//draw screen while faded to white and than fade back to standard
			//draw background
			dd.drawbackground(option.data.cbackground.r,
							  option.data.cbackground.g,
							  option.data.cbackground.b);

			//yinyang if shadows on
			if (option.data.shadows == 1)
			{
				//initial yinyang angle is random (doesn't work with triple flip
				//data_op.yy_angle = 0 + (float)(rand() % (359 - 0 + 1));
				data_op.yy.set_angle(0);
				//position
				data_op.yy.set_position(400, 300);
				//size
				data_op.yy.set_size(0.75f);
			}

			//draw options menu
			dd.draw_options_menu(&data_op, option.data.shadows);

			//show it
			dd.flip(option.data.vsync);
		}

		//fade in from white
		dd.gamma_fade(1, 1, 0.5f);

		//reset timer
		time.get_tfr();
		time.sca = 0.0f;

		//reset menu sound frequencies to default
		ds.setfrequency(BT_SYS, -1, 1.0f);

		//copy player names into editing buffer
		//destination, source
		strcpy(data_op.name_buffer[P1], option.data.name[P1]);
		strcpy(data_op.name_buffer[P2], option.data.name[P2]);

		//copy editing buffer into player names
		//strcpy(option.data.name[P1], data_op.name_buffer[P1]);
		//strcpy(option.data.name[P2], data_op.name_buffer[P2]);

		//---- intitialize all option data --------------------------------------------------------

		//set pointers look up table, number of raw input mice, player names
		data_op.initialize(is.p_lutDIK_DESC, di.RI.RIMn);

		//option slots
		data_op.set_option(0, 0, "Sound", !option.dataDEF.sound,
						   &option.data.sound, &option.dataDEF.sound, &option.dataMIN.sound, &option.dataMAX.sound,
						   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 1, "VSync", 0,
						   &option.data.vsync, &option.dataDEF.vsync, &option.dataMIN.vsync, &option.dataMAX.vsync,
						   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 2, "Maximum FPS", 0,
						   &option.data.fps_max, &option.dataDEF.fps_max, &option.dataMIN.fps_max, &option.dataMAX.fps_max,
						   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 3, "Show FPS", 0,
						   &option.data.show_fps, &option.dataDEF.show_fps, &option.dataMIN.show_fps, &option.dataMAX.show_fps,
						   OT_ONOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 5, "Shadows", 0,
						   &option.data.shadows, &option.dataDEF.shadows, &option.dataMIN.shadows, &option.dataMAX.shadows,
						   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 6, "MotionBlur", 0,
						   &option.data.mblur, &option.dataDEF.mblur, &option.dataMIN.mblur, &option.dataMAX.mblur,
						   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 7, "Black&White Mode", 0,
						   &option.data.bw_mode, &option.dataDEF.bw_mode, &option.dataMIN.bw_mode, &option.dataMAX.bw_mode,
						   OT_ONOFF, ODT_INT, OIT_DEF, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 8, "Background RGB", 0,
						   &option.data.cbackground, &option.dataDEF.cbackground, &option.dataMIN.cbackground, &option.dataMAX.cbackground,
						   OT_RGB, ODT_RGB, OIT_FIVE, OCS_BGN,
						   0, 0, 100, 0);
		data_op.set_option(0, 10, "Rounds", 0,
						   &option.data.rounds, &option.dataDEF.rounds, &option.dataMIN.rounds, &option.dataMAX.rounds,
						   OT_INT, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 11, "Round Time", 0,
						   &option.data.roundtime, &option.dataDEF.roundtime, &option.dataMIN.roundtime, &option.dataMAX.roundtime,
						   OT_INTOFF, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 100, 0);
		data_op.set_option(0, 12, "Speed", 0,
						   &option.data.speed, &option.dataDEF.speed, &option.dataMIN.speed, &option.dataMAX.speed,
						   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
						   0, 0, 100, 0);
		//----
		data_op.set_option(2, 0, "Left P1", 0,
						   &option.data.CBT[cP1LEFT], &option.dataDEF.CBT[cP1LEFT], &option.dataMIN.CBT[cP1LEFT], &option.dataMAX.CBT[cP1LEFT],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 1, "Right P1", 0,
						   &option.data.CBT[cP1RIGHT], &option.dataDEF.CBT[cP1RIGHT], &option.dataMIN.CBT[cP1RIGHT], &option.dataMAX.CBT[cP1RIGHT],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 2, "Punch P1", 0,
						   &option.data.CBT[cP1PUNCH], &option.dataDEF.CBT[cP1PUNCH], &option.dataMIN.CBT[cP1PUNCH], &option.dataMAX.CBT[cP1PUNCH],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 3, "Kick P1", 0,
						   &option.data.CBT[cP1KICK], &option.dataDEF.CBT[cP1KICK], &option.dataMIN.CBT[cP1KICK], &option.dataMAX.CBT[cP1KICK],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 4, "Defend P1", 0,
						   &option.data.CBT[cP1DEFEND], &option.dataDEF.CBT[cP1DEFEND], &option.dataMIN.CBT[cP1DEFEND], &option.dataMAX.CBT[cP1DEFEND],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 5, "Spec P1", 0,
						   &option.data.CBT[cP1SPECIAL], &option.dataDEF.CBT[cP1SPECIAL], &option.dataMIN.CBT[cP1SPECIAL], &option.dataMAX.CBT[cP1SPECIAL],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		//data_op.set_option(2, 6, "StanceUp P1", 0,
		data_op.set_option(2, 6, "Guard+ P1", 0,
						   &option.data.CBT[cP1STANCEUP], &option.dataDEF.CBT[cP1STANCEUP], &option.dataMIN.CBT[cP1STANCEUP], &option.dataMAX.CBT[cP1STANCEUP],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		//data_op.set_option(2, 7, "StanceDown P1", 0,
		data_op.set_option(2, 7, "Guard- P1", 0,
						   &option.data.CBT[cP1STANCEDOWN], &option.dataDEF.CBT[cP1STANCEDOWN], &option.dataMIN.CBT[cP1STANCEDOWN], &option.dataMAX.CBT[cP1STANCEDOWN],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(2, 8, "Mouse P1", 0,
						   &option.data.player_mouse[P1], &option.dataDEF.player_mouse[P1], &option.dataMIN.player_mouse[P1], &option.dataMAX.player_mouse[P1],
						   OT_MOUSE, ODT_INT, OIT_SINGLE, OCS_DEF);
		data_op.set_option(3, 0, "Left P2", 0,
						   &option.data.CBT[cP2LEFT], &option.dataDEF.CBT[cP2LEFT], &option.dataMIN.CBT[cP2LEFT], &option.dataMAX.CBT[cP2LEFT],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 1, "Right P2", 0,
						   &option.data.CBT[cP2RIGHT], &option.dataDEF.CBT[cP2RIGHT], &option.dataMIN.CBT[cP2RIGHT], &option.dataMAX.CBT[cP2RIGHT],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 2, "Punch P2", 0,
						   &option.data.CBT[cP2PUNCH], &option.dataDEF.CBT[cP2PUNCH], &option.dataMIN.CBT[cP2PUNCH], &option.dataMAX.CBT[cP2PUNCH],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 3, "Kick P2", 0,
						   &option.data.CBT[cP2KICK], &option.dataDEF.CBT[cP2KICK], &option.dataMIN.CBT[cP2KICK], &option.dataMAX.CBT[cP2KICK],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 4, "Defend P2", 0,
						   &option.data.CBT[cP2DEFEND], &option.dataDEF.CBT[cP2DEFEND], &option.dataMIN.CBT[cP2DEFEND], &option.dataMAX.CBT[cP2DEFEND],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 5, "Spec P2", 0,
						   &option.data.CBT[cP2SPECIAL], &option.dataDEF.CBT[cP2SPECIAL], &option.dataMIN.CBT[cP2SPECIAL], &option.dataMAX.CBT[cP2SPECIAL],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		//data_op.set_option(3, 6, "StanceUp P2", 0,
		data_op.set_option(3, 6, "Guard+ P2", 0,
						   &option.data.CBT[cP2STANCEUP], &option.dataDEF.CBT[cP2STANCEUP], &option.dataMIN.CBT[cP2STANCEUP], &option.dataMAX.CBT[cP2STANCEUP],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		//data_op.set_option(3, 7, "StanceDown P2", 0,
		data_op.set_option(3, 7, "Guard- P2", 0,
						   &option.data.CBT[cP2STANCEDOWN], &option.dataDEF.CBT[cP2STANCEDOWN], &option.dataMIN.CBT[cP2STANCEDOWN], &option.dataMAX.CBT[cP2STANCEDOWN],
						   OT_INPUT, ODT_INT, OIT_DEF, OCS_DEF);
		data_op.set_option(3, 8, "Mouse P2", 0,
						   &option.data.player_mouse[P2], &option.dataDEF.player_mouse[P2], &option.dataMIN.player_mouse[P2], &option.dataMAX.player_mouse[P2],
						   OT_MOUSE, ODT_INT, OIT_SINGLE, OCS_DEF);

		data_op.set_option(2, 10, "Name P1", 0,
//						   &option.data.name[P1], &option.dataDEF.name[P1], &option.dataMIN.name[P1], &option.dataMAX.name[P1],
						   &data_op.name_buffer[P1], &option.dataDEF.name[P1], &option.dataMIN.name[P1], &option.dataMAX.name[P1],
						   OT_STRING, ODT_CHAR, OIT_DEF, OCS_DEF,
						   0, 0, 25, 0);
		data_op.set_option(2, 11, "Name P2", 0,
//						   &option.data.name[P2], &option.dataDEF.name[P2], &option.dataMIN.name[P2], &option.dataMAX.name[P2],
						   &data_op.name_buffer[P2], &option.dataDEF.name[P2], &option.dataMIN.name[P2], &option.dataMAX.name[P2],
						   OT_STRING, ODT_CHAR, OIT_DEF, OCS_DEF,
						   0, 0, 25, 0);
		data_op.set_option(2, 12, "Fistcolor P1 RGB", 0,
						   &option.data.fistcolor[P1], &option.dataDEF.fistcolor[P1], &option.dataMIN.fistcolor[P1], &option.dataMAX.fistcolor[P1],
						   OT_RGB, ODT_RGB, OIT_FIVE, OCS_FIST,
						   0, 0, 100, 0);
		data_op.set_option(2, 13, "Fistcolor P2 RGB", 0,
						   &option.data.fistcolor[P2], &option.dataDEF.fistcolor[P2], &option.dataMIN.fistcolor[P2], &option.dataMAX.fistcolor[P2],
						   OT_RGB, ODT_RGB, OIT_FIVE, OCS_FIST,
						   0, 0, 100, 0);
		//---
		data_op.set_option(0, 14, "Subframes", 0,
						   &option.data.subframes, &option.dataDEF.subframes, &option.dataMIN.subframes, &option.dataMAX.subframes,
						   OT_INT, ODT_INT, OIT_SINGLE, OCS_DEF,
						   0, 0, 120, 0);
		data_op.set_option(0, 15, "Damage Multiplier", 0,
						   &option.data.damage_multiplier, &option.dataDEF.damage_multiplier, &option.dataMIN.damage_multiplier, &option.dataMAX.damage_multiplier,
						   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
						   0, 0, 120, 0);
		data_op.set_option(0, 16, "Fatigue Multiplier", 0,
						   &option.data.fom_multiplier, &option.dataDEF.fom_multiplier, &option.dataMIN.fom_multiplier, &option.dataMAX.fom_multiplier,
						   OT_FLOAT, ODT_FLOAT, OIT_PSINGLE, OCS_DEF,
						   0, 0, 120, 0);
		//---
		data_op.set_option(1, 19, "CREDITS", 0,
						   NULL, NULL, NULL, NULL,
						   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
						   200, 0);
		data_op.set_option(2, 19, "DEFAULT", 0,
						   NULL, NULL, NULL, NULL,
						   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
						   150, 0);
		data_op.set_option(3, 19, "DONE", 0,
						   NULL, NULL, NULL, NULL,
						   OT_SYS, ODT_DEF, OIT_DEF, OCS_DEF,
						   100, 0);

		//set initial bounding boxes
		data_op.set_bounding_box(option.data.shadows);

		//-----------------------------------------------------------------------------------------

		return;
	}

	//---- idling ---------------------------------------------------------------------------------

	if (data_op.state == 1)
	{
		//redraw background every option.data.blurtime-th frame
		//always redraw upper and lower border
		++dd_blurcounter;
		dd.drawbackground(0, 0, 0, 1, 0, 1);
		if (dd_blurcounter >= option.data.mblur)
		{
			//draw background
			dd.drawbackground(option.data.cbackground.r,
							  option.data.cbackground.g,
							  option.data.cbackground.b,
							  0, 1, 0);
			//reset blurcount
			dd_blurcounter = 0;
		}

		//calculate yinyang if shadows on
		if (option.data.shadows == 1)
		{
			//decrease angle by 45 degrees/second times half user speed
			data_op.yy.angle -= (float)(45 * time.sca * (option.data.speed * 0.5f));
			data_op.yy.check_angle();
		}

		//---- input logic ------------------------------------------------------------------------

		//not if console active
		if (!con.state)
		{
	/*
			//show data
			dd.typebmf(10, 74, bmfblue, "slot sel: [%i, %i] subsel: %i", data_op.SSELOPT().x, data_op.SSELOPT().y, data_op.sub_selection);
			dd.typebmf(400, 74, bmfblue, "mouse: (%i, %i) (%i, %i)", (int)mcursor[0].pos.x, (int)mcursor[0].pos.y, (int)mcursor[1].pos.x, (int)mcursor[1].pos.y);
			{
				const unsigned int len = 5;
				char c[len + 1 + ((len - 1) / 4)] = {0};
				bitstring(data_op.SELOPT_selection(), c, len, true, '.');
				dd.typebmf(630, 74, bmfred, "sel: %s [%i]", c, data_op.SELOPT_selection());
			}
			//dd.typebmf(8, 400, bmfblue, "%i", 0);*/

			//last selected option slot
			ipoint lastSELOPT = data_op.SSELOPT();

			//not within subselection
			if (data_op.sub_selection == SUBSEL_NONE)
			{
				//reset currently selected option
				data_op.reset_SELOPT();

				//reset selections of all slots
				data_op.SELOPT_reset_selection(0, 0, true);

				//for all option slots
				for (int x = 0; x < OS_X; ++x)
					for (int y = 0; y < OS_Y; ++y)
						//if slot valid and not locked
						if (data_op.slot[x][y].set && !data_op.slot[x][y].locked)
						{
							//qualifier
							if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_qual))
							{
								//set slot selection
								data_op.set_SELOPT(x, y);

								//input, name option, credits, default, done
								if (!stricmp(data_op.p_SELOPT->qualifier, "CREDITS") ||
									!stricmp(data_op.p_SELOPT->qualifier, "DEFAULT") ||
									!stricmp(data_op.p_SELOPT->qualifier, "DONE") ||
									data_op.slot[x][y].o_type == OT_INPUT ||
									data_op.slot[x][y].o_type == OT_STRING)
								{
									//set selected slot's selection to qualifier
									data_op.SELOPT_set_selection(SEL_PRE);

									break;
								}

								//set selected slot's selection to qualifier
								data_op.SELOPT_set_selection(SEL_QUAL);

								//draw selection rectangle
								//dd.drawrectangle_uf(data_op.p_SELOPT->r_pos_qual, red);

								//break y-loop in case of overlapping selection rectangles (scanline font)
								break;
							}
							//flag to break y-loop in case of overlapping selection rectangles
							//(only first to be selected)
							bool sel = false;
							//3 data slots
							for (int s = 0; s < 3; ++s)
								//if data slot valid
								if (data_op.slot[x][y].r_pos_data[s].left != -1)
									if (hitboxcheck(mcursor[0].r_pos, data_op.slot[x][y].r_pos_data[s]))
									{
										//set slot selection
										data_op.set_SELOPT(x, y);
										//break y-loop
										sel = true;

										//input, name option
										if (data_op.slot[x][y].o_type == OT_INPUT ||
											data_op.slot[x][y].o_type == OT_STRING)
										{
											data_op.SELOPT_set_selection(SEL_PRE);
											break;
										}

										//add(!) selected data to selected slot's selection
										if (s == 0)		data_op.SELOPT_set_selection(data_op.SELOPT_selection() | SEL_DAT1);
										if (s == 1)		data_op.SELOPT_set_selection(data_op.SELOPT_selection() | SEL_DAT2);
										if (s == 2)		data_op.SELOPT_set_selection(data_op.SELOPT_selection() | SEL_DAT3);

										//draw selection rectangle
										//dd.drawrectangle_uf(data_op.p_SELOPT->r_pos_data[s], red);

										//break data slot loop
										break;
									}
							//break y-loop
							if (sel)
								break;
						}

				//slot selection sound
				if (data_op.SELOPT() && !(lastSELOPT == data_op.SSELOPT()))
				{
					//reset sound frequency
					ds.setfrequency(BT_SYS, S_MSELECT, 1.0f);
					playsound_s(S_MSELECT);
				}
			}

			//---- mouse selection --------------------------------------------------------------------

			//sound frequency for increasing/decrease data
			float freq_inc = 1.1f;
			float freq_dec = 0.9f;

			//if slot selected
			if (data_op.SELOPT())
			{
				//not within subselection
				if (data_op.sub_selection == SUBSEL_NONE)
				{
					//no right/middle button presses for these options
					//(to suppress cancel sound)
					if (data_op.p_SELOPT->o_type == OT_INPUT ||
						data_op.p_SELOPT->o_type == OT_STRING)
					{
						is.dimouse1D[0].rgbButtons[1] = 0;
					}
					if (!stricmp(data_op.p_SELOPT->qualifier, "DEFAULT") ||
						!stricmp(data_op.p_SELOPT->qualifier, "CREDITS") ||
						!stricmp(data_op.p_SELOPT->qualifier, "DONE"))
					{
						is.dimouse1D[0].rgbButtons[0] = 0;
						is.dimouse1D[0].rgbButtons[1] = 0;
						is.dimouse1D[0].rgbButtons[2] = 0;
					}

					//mouse button 0
					if (is.mouse1D(0, 0))
					{
						//control input
						if (data_op.p_SELOPT->o_type == OT_INPUT)
						{
							//reset mouse button data
							//so the button press to enter this option isn't assigned as control
							is.dimouse1D[0].rgbButtons[0] = is.dimouse1D[1].rgbButtons[0] = is.dimouse1D[2].rgbButtons[0] = 0;
							//highlight data of this slot
							data_op.SELOPT_set_selection(SEL_DAT1);
							//set subselection
							data_op.sub_selection = SUBSEL_INPUT;
							//reset sound frequency
							ds.setfrequency(BT_SYS, S_MSELECT, 1.0f);
							playsound_s(S_MSELECT);
						}
						//name input
						if (data_op.p_SELOPT->o_type == OT_STRING)
						{
							//highlight data of this slot
							data_op.SELOPT_set_selection(SEL_DAT1);

							//set editor cursor to end of name
							data_op.s_index = strlen((char*)data_op.p_SELOPT->p_data);
							//if name at max length set editor cursor to last position
							if (data_op.s_index > 19)
								data_op.s_index = 19;
							//write 0 to every element of name after editor cursor
							for (int i = data_op.s_index + 1; i < 21; ++i)
								((char*)data_op.p_SELOPT->p_data)[i] = 0;

							//set subselection
							data_op.sub_selection = SUBSEL_NAME;
							ds.setfrequency(BT_SYS, S_MSELECT, 1.0f);
							playsound_s(S_MSELECT);
						}
					}
					//mouse button 0 downup
					if (is.mouse1DU(0, 0))
					{
						//default
						if (!stricmp(data_op.p_SELOPT->qualifier, "DEFAULT"))
						{
							//set subselection
							data_op.sub_selection = SUBSEL_DEF;
							ds.setfrequency(BT_SYS, S_MSELECT, 1.0f);
							playsound_s(S_MSELECT);
						}
						//credits
						if (!stricmp(data_op.p_SELOPT->qualifier, "CREDITS"))
						{
							//set subselection
							data_op.sub_selection = SUBSEL_CRED;
							ds.setfrequency(BT_SYS, S_MENTER, 1.0f);
							playsound_s(S_MENTER);
						}
						//exit
						if (!stricmp(data_op.p_SELOPT->qualifier, "DONE"))
						{
							//set subselection
							data_op.sub_selection = SUBSEL_EXIT;
							ds.setfrequency(BT_SYS, S_MENTER, 1.0f);
							playsound_s(S_MENTER);
						}
					}
				}

				//not within subselection
				if (data_op.sub_selection == SUBSEL_NONE)
				{
					//mouse button 0, increase option data
					//on button press, button hold or mousewheel movement, while other mouse button not pressed
					if ((is.mouse1D(0, 0) || is.mousehold_t(0, 0, 2, 15, 0.75f, 2.75f) || is.dimouse[0].lZ > 0) &&
						!is.mouse(0, 1))
						//increase data, play confirm/cancel sound
						if (data_op.SELOPT_inc_data())
						{
							ds.setfrequency(BT_SYS, S_MSELECT, freq_inc);
							playsound_s(S_MSELECT);
						}
						else
							playsound_s(S_MCANCEL);
					//mouse button 1, decrease option data
					if ((is.mouse1D(0, 1) || is.mousehold_t(0, 1, 2, 15, 0.75f, 2.75f) || is.dimouse[0].lZ < 0) &&
						!is.mouse(0, 0))
						if (data_op.SELOPT_dec_data())
						{
							ds.setfrequency(BT_SYS, S_MSELECT, freq_dec);
							playsound_s(S_MSELECT);
						}
						else
							playsound_s(S_MCANCEL);
					//both/middle mouse button, reset option data
					if ((is.mouse1D(0, 0) && is.mouse(0, 1)) ||
						(is.mouse1D(0, 1) && is.mouse(0, 0)) ||
						is.mouse1D(0, 2))
						if (data_op.SELOPT_reset_data())
						{
							playsound_s(S_MENTER);

							//hackish name verification
							if (data_op.p_SELOPT->o_type == OT_STRING)
							{
								//copy editing buffer into player names
								if (!stricmp(data_op.p_SELOPT->qualifier, "Name P1"))
									strcpy(option.data.name[P1], (char*)data_op.p_SELOPT->p_data);
								if (!stricmp(data_op.p_SELOPT->qualifier, "Name P2"))
									strcpy(option.data.name[P2], (char*)data_op.p_SELOPT->p_data);

								//verify name
								if (!option.verify_player_names())
								{
									//copy adjusted player name into editing buffer
									if (!stricmp(data_op.p_SELOPT->qualifier, "Name P1"))
										strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P1]);
									if (!stricmp(data_op.p_SELOPT->qualifier, "Name P2"))
										strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P2]);
								}
							}
						}
						else
							playsound_s(S_MCANCEL);
				}
			}

			//---- control input ----------------------------------------------------------------------

			//if option selected and sub selection
			if (data_op.SELOPT() && data_op.sub_selection == SUBSEL_INPUT)
			{
				//deactivate cursor
				mcursor[0].toggle_cursor(0);

				//button to cancel
				int dik_cancel		= DIK_ESCAPE;
				//bmf or slf
				if (!option.data.shadows)
				{
					dd.typebmf(centerfont(strlen("Press Key/Button To Assign To [xxxxxxx]"), dd.rSCREEN169).x, 540,
							   bmfwhite, "Press Key/Button To Assign To [%s]", data_op.p_SELOPT->qualifier); 
					dd.typebmf(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169).x, 556,
							   bmfwhite, "(ESC To Cancel)"); 
				}
				else
				{
					dd.typeSLF(centerfont(strlen("Press Key/Button To Assign To [xxxxxxx]"), dd.rSCREEN169, 0.35f).x, 540,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "Press Key/Button To Assign To [%s]", data_op.p_SELOPT->qualifier);
					dd.typeSLF(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169, 0.35f).x, 565,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "(ESC To Cancel)");
				}

				//for every key
				for (int i = 0; i < 256; ++i)
					//if pressed
					if (is.dikey1D[i] & 0x80)
					{
						//verify key
						if (!option.verify_key(i))
						{
							playsound_s(S_MCANCEL);
							break;
						}
						else
						{
							//set input
							data_op.p_SELOPT->set_input(i);
							playsound_s(S_MENTER);
							data_op.sub_selection = SUBSEL_NONE;
							break;
						}
					}

				//both mice/controller
				for (int d = 0; d < 2; ++d)
				{
					//mouse wheel up/down
					if (is.dimouse[d + 1].lZ > 0)
					{
						data_op.p_SELOPT->set_input(5, d + 1);
						playsound_s(S_MENTER);
						data_op.sub_selection = SUBSEL_NONE;
						break;
					}
					if (is.dimouse[d + 1].lZ < 0)
					{
						data_op.p_SELOPT->set_input(6, d + 1);
						playsound_s(S_MENTER);
						data_op.sub_selection = SUBSEL_NONE;
						break;
					}

					//all buttons
					for (int b = 0; b < 21; ++b)
					{
						//mice
						if (b < 4)
							if (is.dimouse1D[d + 1].rgbButtons[b] & 0x80)
							{
								data_op.p_SELOPT->set_input(b, d + 1);
								playsound_s(S_MENTER);
								data_op.sub_selection = SUBSEL_NONE;
								break;
							}

						//controller buttons
						if (is.dicon1D[d].rgbButtons[b] & 0x80)
						{
							data_op.p_SELOPT->set_input(b, d + 3);
							playsound_s(S_MENTER);
							data_op.sub_selection = SUBSEL_NONE;
							break;
						}
					}
				}

				//cancel button
				if (is.key1D(dik_cancel))
				{
					//already played since ESC is locked
	//				playsound_s(S_MCANCEL);
					//exit subselection
					data_op.sub_selection = SUBSEL_NONE;
				}

				//exit
				if (data_op.sub_selection == SUBSEL_NONE)
				{
					//reset key data
					//so the key press to exit this option doesn't also exit the options menu
					is.dikey1D[dik_cancel] = 0;
					//activate cursor
					mcursor[0].toggle_cursor(1);
				}
			}

			//---- name input -------------------------------------------------------------------------

			//if option selected and sub selection
			if (data_op.SELOPT() && data_op.sub_selection == SUBSEL_NAME)
			{
				//deactivate cursor
				mcursor[0].toggle_cursor(0);

				//button to confirm, cancel
				int dik_confirm		= DIK_RETURN;
				int dik_cancel		= DIK_ESCAPE;
				//bmf or slf
				if (!option.data.shadows)
				{
					dd.typebmf(centerfont(strlen("ENTER NAME"), dd.rSCREEN169).x, 540,
							   bmfwhite, "ENTER NAME", data_op.p_SELOPT->qualifier); 
					dd.typebmf(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169).x, 556,
							   bmfwhite, "(ESC To Cancel)"); 
				}
				else
				{
					dd.typeSLF(centerfont(strlen("ENTER NAME"), dd.rSCREEN169, 0.35f).x, 540,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "ENTER NAME", data_op.p_SELOPT->qualifier);
					dd.typeSLF(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169, 0.35f).x, 565,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "(ESC To Cancel)");
				}

				//max length of name
				int length	= 20;
				//ascii holding currently pressed key's ascii code
				int ascii	= 0;

				//set '_' at cursor position in name string
				//not at last position
				if (data_op.s_index < length - 1)
				{
					((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 95;
				}
				else
				//at last position
				{
					//if last position empty, insert editor cursor
					if (((char*)data_op.p_SELOPT->p_data)[data_op.s_index] == 0)
						((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 95;
				}

				//get currently pressed key's ascii code
				ascii = getinput_ascii();

				//valid key
				if (ascii != 0)
				{
					playsound_s(S_MSELECT);

					//set key
					((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = ascii;
					//increase editor write buffer if not at end of name, else overwrite last letter
					if (data_op.s_index < length - 1)
						++data_op.s_index;
				}

				//backspace at non first position, elso nothing happens
				if (is.dikey1D[SYS_BACK] & 0x80 && data_op.s_index > 0)
				{
					playsound_s(S_MENTER);

					//not at last position
					if (data_op.s_index != length - 1)
					{
						//delete letter at editor write position and decrease editor position
						((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 0;
						--data_op.s_index;
					}
					else
					//at last position
					{
						//last position not empty (or editor cursor)
						if (((char*)data_op.p_SELOPT->p_data)[length - 1] != 0 &&
							((char*)data_op.p_SELOPT->p_data)[length - 1] != 95)
						{
							//delete letter at position but keep cursor there
							((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 0;
						}
						else
						//last position empty
						{
							//delete letter at position and decrease editor write cursor
							((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 0;
							--data_op.s_index;
						}
					}
				}

				//confirmation button
				if (is.key1D(dik_confirm))
				{
					playsound_s(S_MENTER);
					//exit subselection
					data_op.sub_selection = SUBSEL_NONE;

					//delete '_' at editor cursor
					if (((char*)data_op.p_SELOPT->p_data)[data_op.s_index] == 95)
						((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 0;

					//copy editing buffer into player names
					if (!stricmp(data_op.p_SELOPT->qualifier, "Name P1"))
						strcpy(option.data.name[P1], (char*)data_op.p_SELOPT->p_data);
					if (!stricmp(data_op.p_SELOPT->qualifier, "Name P2"))
						strcpy(option.data.name[P2], (char*)data_op.p_SELOPT->p_data);

					//verify name
					if (!option.verify_player_names())
					{
						//copy adjusted player name into editing buffer
						if (!stricmp(data_op.p_SELOPT->qualifier, "Name P1"))
							strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P1]);
						if (!stricmp(data_op.p_SELOPT->qualifier, "Name P2"))
							strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P2]);
					}

					//reset key data
					//so the key press to exit this option doesn't also exit the options menu
					is.dikey1D[dik_cancel] = 0;
					//activate cursor
					mcursor[0].toggle_cursor(1);
				}

				//cancel button
				if (is.key1D(dik_cancel))
				{
					playsound_s(S_MCANCEL);
					//exit subselection
					data_op.sub_selection = SUBSEL_NONE;

					//delete '_' at editor cursor
					if (((char*)data_op.p_SELOPT->p_data)[data_op.s_index] == 95)
						((char*)data_op.p_SELOPT->p_data)[data_op.s_index] = 0;

					//reset names to unedited version
					if (!stricmp(data_op.p_SELOPT->qualifier, "Name P1"))
						strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P1]);
					if (!stricmp(data_op.p_SELOPT->qualifier, "Name P2"))
						strcpy((char*)data_op.p_SELOPT->p_data, option.data.name[P2]);

					//reset key data
					//so the key press to exit this option doesn't also exit the options menu
					is.dikey1D[dik_cancel] = 0;
					//activate cursor
					mcursor[0].toggle_cursor(1);
				}
			}

			//---- default ----------------------------------------------------------------------------

			//if option selected and sub selection
			if (data_op.SELOPT() && data_op.sub_selection == SUBSEL_DEF)
			{
				//deactivate cursor
				mcursor[0].toggle_cursor(0);

				//button to confirm, cancel
				int dik_confirm		= DIK_RETURN;
				int dik_cancel		= DIK_ESCAPE;
				//time to hold button
				float t_confirm		= 1.5f;
				//bmf or slf
				if (!option.data.shadows)
				{
					dd.typebmf(centerfont(strlen("HOLD ENTER TO CONFIRM! [x.x]"), dd.rSCREEN169).x, 540,
							   bmfwhite, "HOLD ENTER TO CONFIRM! [%.1f]", is.t_dikey[dik_confirm]); 
					dd.typebmf(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169).x, 556,
							   bmfwhite, "(ESC To Cancel)"); 
				}
				else
				{
					dd.typeSLF(centerfont(strlen("HOLD ENTER TO CONFIRM! [x.x]"), dd.rSCREEN169, 0.35f).x, 540,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "HOLD ENTER TO CONFIRM! [%.1f]", is.t_dikey[dik_confirm]);
					dd.typeSLF(centerfont(strlen("(ESC To Cancel)"), dd.rSCREEN169, 0.35f).x, 565,
							   0, 0, 0, 255, 255, 255, 0.35f,
							   "(ESC To Cancel)");
				}

				//wait t_confirm seconds for button hold
				if (is.t_dikey[dik_confirm] > t_confirm)
				{
					playsound_s(S_MENTER);
					//exit subselection
					data_op.sub_selection = SUBSEL_NONE;

					//reset all options to default values
					option.reset();
					//copy player names into editing buffer
					//destination, source
					strcpy(data_op.name_buffer[P1], option.data.name[P1]);
					strcpy(data_op.name_buffer[P2], option.data.name[P2]);

					//reset key data
					//so the key press to exit this option doesn't also exit the options menu
					is.dikey1D[dik_confirm]		= 0;
					//is.dikey1D[dik_cancel]	 = 0;
					//activate cursor
					mcursor[0].toggle_cursor(1);
				}

				//cancel button
				if (is.key1D(dik_cancel))
				{
					playsound_s(S_MCANCEL);
					//exit subselection
					data_op.sub_selection = SUBSEL_NONE;

					//reset key data
					//so the key press to exit this option doesn't also exit the options menu
					is.dikey1D[dik_cancel]	= 0;
					//is.dikey1D[dik_confirm]	 = 0;
					//activate cursor
					mcursor[0].toggle_cursor(1);
				}
			}

			//---- credits ----------------------------------------------------------------------------

			//if option selected and sub selection
			if (data_op.SELOPT() && data_op.sub_selection == SUBSEL_CRED)
			{
				//deactivate cursor
				//mcursor[0].toggle_cursor(0);

				//reset selection
				data_op.reset_SELOPT();
				//reset sub selection
				data_op.sub_selection		= SUBSEL_NONE;
				//reset selections of all slots
				data_op.SELOPT_reset_selection(0, 0, true);
				//reset state
				data_op.state = 0;

				//fade to black
				dd.gamma_fade(0, 0, 0.5f);
				program_state = CREDITS;

				return;
			}

			//---- exit -------------------------------------------------------------------------------

			//if option selected and sub selection
			//or exit key
			if (is.key1D(SYS_ESC))
			{
				//set subselection
				data_op.sub_selection = SUBSEL_EXIT;
				ds.setfrequency(BT_SYS, S_MENTER, 1.0f);
				playsound_s(S_MENTER);
			}
	//		if (data_op.SELOPT() && data_op.sub_selection == SUBSEL_EXIT)
			if (data_op.sub_selection == SUBSEL_EXIT)
			{
				//reset selection
				data_op.reset_SELOPT();
				//reset sub selection
				data_op.sub_selection		= SUBSEL_NONE;
				//reset selections of all slots
				data_op.SELOPT_reset_selection(0, 0, true);
				//reset state
				data_op.state = 0;

				//fade to white
				dd.gamma_fade(0, 1, 0.5f);
				program_state = TITLE;

				return;
			}
		}

		//-----------------------------------------------------------------------------------------

		//set current bounding boxes (updated to current data)
		data_op.set_bounding_box(option.data.shadows);

		//draw options menu
		dd.draw_options_menu(&data_op, option.data.shadows);

		//mouse cursor
		process_mousecursor(option.data.shadows);

		return;
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame credits
//
//	scrolls credits (mf::data_cr contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::credits()
{
	//---- user input ----------------------------------------------------------------------------

	//pause/unpause
	if (is.dikey1D[DIK_SPACE] & 0x80)
	{
		//play sound
		playsound_s(S_MENTER);

		//pause/unpause
		data_cr.pause = !data_cr.pause;
	}
	else
	//any other key exits
	{
		if (is.key1DALL())
		{
			//if paused, only unpause
			if (data_cr.pause)
			{
				//play sound
				playsound_s(S_MENTER);

				data_cr.pause	= 0;

				return;
			}

			//play exit sound
			playsound_s(S_MCANCEL);

			//exit
			data_cr.state	= 3;
		}
	}

	//change credits color
	if (is.dimouse1D[0].rgbButtons[0] & 0x80)
		if (data_cr.bmfcolor < 5)		++data_cr.bmfcolor;
		else							data_cr.bmfcolor = 0;
	if (is.dimouse1D[0].rgbButtons[1] & 0x80)
		if (data_cr.bmfcolor > 0)		--data_cr.bmfcolor;
		else							data_cr.bmfcolor = 5;

	//change scrolling speed
	data_cr.scroll_speed.y -= is.dimouse[0].lZ / 10;
	//limit
	if (data_cr.scroll_speed.y > CR_SPEEDMAX)	data_cr.scroll_speed.y = CR_SPEEDMAX;
	if (data_cr.scroll_speed.y < -CR_SPEEDMAX)	data_cr.scroll_speed.y = -CR_SPEEDMAX;
	//reset
	if (is.dimouse1D[0].rgbButtons[2] & 0x80)
		data_cr.scroll_speed.y	= CR_SPEED;

	//---- exit -----------------------------------------------------------------------------------

	//return to options menu
	if (data_cr.state == 3)
	{
		//reset credits state
		data_cr.reset();

		//fade to white and return to options
		dd.gamma_fade(0, 1, 0.5f);
		program_state	= OPTIONS;
		return;
	}

	//---- initialization ------------------------------------------------------------------------

	if (data_cr.state == 0)
	{
		//reset credits state
		//(state set to 0)
		data_cr.reset();

		//initialize and set state to 1
		data_cr.state = 1;

		//white background
		dd.colorfill(white);

		//show it
		dd.flip(option.data.vsync);

		//fade in from black
		dd.gamma_fade(1, 0, 0.5f);

		//reset timer
		time.get_tfr();
		time.sca = 0.0f;
	}

	//---- scrolling -----------------------------------------------------------------------------

	if (data_cr.state == 1)
	{
		//background depending on credits color
		if (data_cr.bmfcolor != bmfwhite &&
			data_cr.bmfcolor != bmfyellow)
			dd.colorfill(white);
		else
			dd.colorfill(black);

/*dd.typebmf(10, 100, bmfblack, "speed %.1f (per frame: %.5f)", data_cr.scroll_speed.y, data_cr.scroll_speed.y * (float)time.sca);
dd.typebmf(10, 116, bmfblack, "color %i", data_cr.bmfcolor);
dd.typebmf(10, 132, bmfblack, "template top, bottom: %.1f, %.1f", data_cr.temp.p[0].y, data_cr.temp.p[2].y);

		//draw template rectangle
		if (true)
		{
			RECT r;
			fillRECT(r, 300, (int)data_cr.temp.p[0].y, 500, (int)data_cr.temp.p[2].y);
			dd.drawrectangle_uf(r, red);
		}*/

		//for every credit
		for (int i = 0; i < data_cr.ecounter; ++i)
		{
			//draw text
			dd.typebmf(centerfont(strlen(data_cr.pcq[i].pc), dd.rSCREEN).x,
					   (int)(data_cr.temp.p[0].y + data_cr.pcq[i].pos.y),
					   data_cr.bmfcolor, "%s", data_cr.pcq[i].pc);
		}

		//scroll only if not paused
		if (!data_cr.pause)
		{
			//scroll to top
			if (data_cr.scroll_speed.y < 0)
			{
				//if bottom of template still on screen
				if (data_cr.temp.p[2].y >= 0)
				{
					//increase top and bottom of template
					data_cr.temp.p[0].y += data_cr.scroll_speed.y * (float)time.sca;
					data_cr.temp.p[2].y += data_cr.scroll_speed.y * (float)time.sca;
				}
				else
				{
					//reset template position to bottom
					data_cr.set_temp_pos();
					//every entry done, exit credits
					//data_cr.state = 3;
				}
			}
			//scroll to bottom
			if (data_cr.scroll_speed.y > 0)
			{
				//if top of template still on screen
				if (data_cr.temp.p[0].y <= 600)
				{
					//increase top and bottom of template
					data_cr.temp.p[0].y += data_cr.scroll_speed.y * (float)time.sca;
					data_cr.temp.p[2].y += data_cr.scroll_speed.y * (float)time.sca;
				}
				else
				{
					//reset template position to bottom
					data_cr.set_temp_pos(0);
					//every entry done, exit credits
					//data_cr.state = 3;
				}
			}
		}
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame ingameoptions
//
//	checks and displays ingame options if changed for a period of time (two seconds)
//
//------------------------------------------------------------------------------------------------

void master_frame::ingameoptions()
{
	//---- option change -------------------------------------------------------------------------

	//toggle pause on/off
	if (is.COM1D(cPAUSE))
	{
		//if game is running, pause
		//set pauseflag to uninitialized
		if (!data_ig.pause)
		{
			data_ig.pause = true;
			//initialization flag
			data_ig.f_pause = 0;
			//set pause start time
			data_ig.t_pause = time.current;
			//
			con_add_message("PAUSED");
		}
		else
		//if game is paused, unpause
		{
			data_ig.pause = false;
			//adjust script starting times
			data_ig.t_start_a = time.current - (data_ig.t_pause - data_ig.t_start_a);
			data_ig.t_start_s = time.current - (data_ig.t_pause - data_ig.t_start_s);
			//adjust last round timer time index
			data_ig.t_round = time.current - (data_ig.t_pause - data_ig.t_round);
			//resume all paused player sounds
			process_sound(2);
			con_add_message("UNPAUSED");

			//reset bot timers if active
			if (BOT[B1].active)		BOT[B1].reset_timers();
			if (BOT[B2].active)		BOT[B2].reset_timers();
		}
	}

	//change program state according to pause state
	if (data_ig.pause)
		program_state = PAUSE;
	else
		if (!DEVELOPER_)
			program_state = INGAME;
		else
			program_state = DEVELOPER;

	//if game is paused, unpause and exit to main menu if selected
	if (data_ig.pause && is.COM1D(cEXIT))
	{
		data_ig.pause = false;
		data_ig.state = 100;
	}

	//only if console not active
	if (!con.state)
	{
		//font colors
		int color_std	= bmfblack;
		int	color_off	= bmfred;

		//toggle screenmode
//		if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey1D[DIK_RETURN] & 0x80)
//		if (is.COM1D(cSCREENMODE))
		if ((is.dikey[DIK_LSHIFT] & 0x80 && is.dikey1D[DIK_RETURN] & 0x80) ||
			is.COM1D(cSCREENMODE))
		{
			//toggle screen mode
			option.data.screenmode	= !option.data.screenmode;

			if (!ChangeScreenMode())
			{
				gf_logger(true, "master_frame::ChangeScreenMode FAILED");
				program_active	= false;
			}
			else
			{
				if (option.data.screenmode)
					hud_add_message(0, color_std, "Fullscreen Mode Set");
				else
					hud_add_message(0, color_std, "Window Mode Set");
			}
		}

		//toggle vsync on/off
		if (is.COM1D(cVSYNC))
		{
			option.data.vsync	= !option.data.vsync;
			data_ig.f_vsync		= time.current;
			hud_add_message(0, color_std, "VSync %s", getstate((float)option.data.vsync));
		}

		//toggle shadows on/off
		if (is.COM1D(cSHADOWS))
		{
			option.data.shadows	= !option.data.shadows;
			data_ig.f_shadows	= time.current;
			hud_add_message(0, color_std, "Shadows %s", getstate((float)option.data.shadows));
		}

		//toggle sound on/off only if sound is available
		//display message if no sound available
		if (is.COM1D(cSOUND))
		{
			data_ig.f_sound = time.current;
			if (option.dataDEF.sound == 1)
			{
				//also change user setting in ds object
				//ds.sound_set = option.data.sound = !option.data.sound;
				option.data.sound = !option.data.sound;
				//option.data.sound = !option.data.sound;
				hud_add_message(0, color_std, "Sound %s", getstate((float)option.data.sound));
			}
			else
			{
				hud_add_message(0, color_off, "Sound N/A");
			}
		}

		//decrease speed only if not already matched min speed
		//else set to max speed
		if (is.COM1D(cSPEEDDOWN))
		{
			if (option.data.speed >= option.dataMIN.speed + 0.1f)
				option.data.speed -= 0.1f;
			else
				option.data.speed = option.dataMAX.speed;

			data_ig.f_speed = time.current;

			//done in ds::freq_process() now
			//set frequency of soundbuffers
			//ds.setfrequency(BT_P1, -1, option.data.speed);
			//ds.setfrequency(BT_P2, -1, option.data.speed);
			//!!ds.setfrequency(option.data.speed);
			hud_add_message(0, color_std, "Speed %.1f", option.data.speed);
		}

		//increase speed only if not already matched max speed
		//else set to min speed
		if (is.COM1D(cSPEEDUP))
		{
			if (option.data.speed <= option.dataMAX.speed - 0.1f)
				option.data.speed += 0.1f;
			else
				option.data.speed = option.dataMIN.speed;

			data_ig.f_speed = time.current;

			//done in ds::freq_process() now
			//set frequency of soundbuffers
			//ds.setfrequency(BT_P1, -1, option.data.speed);
			//ds.setfrequency(BT_P2, -1, option.data.speed);
			//ds.setfrequency(option.data.speed);
			hud_add_message(0, color_std, "Speed %.1f", option.data.speed);
		}

		//speed reset if both buttons down at the same time
		if ((is.COM1D(cSPEEDDOWN) && is.COM(cSPEEDUP)) ||
			(is.COM(cSPEEDDOWN) && is.COM1D(cSPEEDUP)))
		{
			option.data.speed	= option.dataDEF.speed;
			data_ig.f_speed		= time.current;
			//done in ds::freq_process() now
			//set frequency of soundbuffers
			//ds.setfrequency(BT_P1, -1, option.data.speed);
			//ds.setfrequency(BT_P2, -1, option.data.speed);
			//!!ds.setfrequency(option.data.speed);
			hud_add_message(0, color_std, "Speed %.1f", option.data.speed);
		}

		//decrease blurtime only if not already matched min blurtime
		//else set to max blurtime
		if (is.COM1D(cBLURDOWN))
		{
			if (option.data.mblur > option.dataMIN.mblur)
				--option.data.mblur;
			else
				option.data.mblur = option.dataMAX.mblur;
			if (MBLUR_LIMIT)
				while (option.data.mblur != 0 && !(option.data.mblur % 3))
				{
					if (option.data.mblur > option.dataMIN.mblur)		--option.data.mblur;
					else												option.data.mblur = option.dataMAX.mblur;
				}

			data_ig.f_mblur = time.current;
			hud_add_message(0, color_std, "MotionBlur %i", option.data.mblur);
		}

		//increase blurtime only if not already matched max blurtime
		//else set to min blurtime
		if (is.COM1D(cBLURUP))
		{
			if (option.data.mblur < option.dataMAX.mblur)
				++option.data.mblur;
			else
				option.data.mblur = option.dataMIN.mblur;
			if (MBLUR_LIMIT)
				while (option.data.mblur != 0 && !(option.data.mblur % 3))
				{
					if (option.data.mblur < option.dataMAX.mblur)		++option.data.mblur;
					else												option.data.mblur = option.dataMIN.mblur;
				}

			data_ig.f_mblur = time.current;
			hud_add_message(0, color_std, "MotionBlur %i", option.data.mblur);
		}

		//blurtime reset if both buttons down at the same time
		if ((is.COM1D(cBLURDOWN) && is.COM(cBLURUP)) ||
			(is.COM(cBLURDOWN) && is.COM1D(cBLURUP)))
		{
			option.data.mblur	= option.dataDEF.mblur;
			data_ig.f_mblur		= time.current;
			hud_add_message(0, color_std, "MotionBlur %i", option.data.mblur);
		}

		//toggle bw_mode on/off
		if (is.COM1D(cBWMODE))
		{
			option.data.bw_mode = !option.data.bw_mode;
			data_ig.f_bwmode = time.current;
			hud_add_message(0, color_std, "Black and White Mode %s", getstate((float)option.data.bw_mode));
		}

		//increase damage multiplier
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.COM1D(cDAMUP))
		{
			if (option.data.damage_multiplier <= option.dataMAX.damage_multiplier - 0.1f)
				option.data.damage_multiplier += 0.1f;
			else
				option.data.damage_multiplier = option.dataMIN.damage_multiplier;
			data_ig.f_damage_multiplier = time.current;
			hud_add_message(0, color_std, "Damage Multiplier %.1f", option.data.damage_multiplier);
		}

		//decrease damage multiplier
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.COM1D(cDAMDOWN))
		{
			if (option.data.damage_multiplier >= option.dataMIN.damage_multiplier + 0.1f)
				option.data.damage_multiplier -= 0.1f;
			else
				option.data.damage_multiplier = option.dataMAX.damage_multiplier;
			data_ig.f_damage_multiplier = time.current;
			hud_add_message(0, color_std, "Damage Multiplier %.1f", option.data.damage_multiplier);
		}

		//damage multiplier reset if both buttons down at the same time
		if (is.dikey[DIK_LSHIFT] & 0x80 &&
			((is.COM1D(cDAMDOWN) && is.COM(cDAMUP)) ||
			(is.COM(cDAMDOWN) && is.COM1D(cDAMUP))))
		{
			option.data.damage_multiplier	= option.dataDEF.damage_multiplier;
			data_ig.f_damage_multiplier		= time.current;
			hud_add_message(0, color_std, "Damage Multiplier %.1f", option.data.damage_multiplier);
		}

		//fatigue multiplier
		if (is.dikey[DIK_LSHIFT] == 0 && is.COM1D(cFATUP))
		{
			if (option.data.fom_multiplier <= option.dataMAX.fom_multiplier - 0.1f)
				option.data.fom_multiplier += 0.1f;
			else
				option.data.fom_multiplier = option.dataMIN.fom_multiplier;
			data_ig.f_fom_multiplier = time.current;
			hud_add_message(0, color_std, "Fatigue Multiplier %.1f", option.data.fom_multiplier);
		}

		if (is.dikey[DIK_LSHIFT] == 0 && is.COM1D(cFATDOWN))
		{
			if (option.data.fom_multiplier >= option.dataMIN.fom_multiplier + 0.1f)
				option.data.fom_multiplier -= 0.1f;
			else
				option.data.fom_multiplier = option.dataMAX.fom_multiplier;
			data_ig.f_fom_multiplier = time.current;
			hud_add_message(0, color_std, "Fatigue Multiplier %.1f", option.data.fom_multiplier);
		}

		//fatigue multiplier reset if both buttons down at the same time
		if (is.dikey[DIK_LSHIFT] == 0 &&
			((is.COM1D(cFATDOWN) && is.COM(cFATUP)) ||
			(is.COM(cFATDOWN) && is.COM1D(cFATUP))))
		{
			option.data.fom_multiplier		= option.dataDEF.fom_multiplier;
			data_ig.f_fom_multiplier		= time.current;
			hud_add_message(0, color_std, "Fatigue Multiplier %.1f", option.data.fom_multiplier);
		}

		//bots
//		if ((is.dikey[DIK_LSHIFT] || is.dikey[DIK_RSHIFT]) &&
//			is.COM1D(cTOGGLEBOT1))
		if (is.COM1D(cTOGGLEBOT1))
		{
			BOT[B1].toggle_bot();
		}
//		if ((is.dikey[DIK_LSHIFT] || is.dikey[DIK_RSHIFT]) &&
//			is.COM1D(cTOGGLEBOT2))
		if (is.COM1D(cTOGGLEBOT2))
		{
			BOT[B2].toggle_bot();
		}
	}

	//screenshot message
	if (is.COM1D(cSCREENSHOT))
		data_ig.f_screenshot	= time.current;

	//---- verify data ----------------------------------------------------------------------------
	//certain options need extra verification that isn't covered by dataMIN/MAX
	//also applies when data is changed via console
	//(applies for mblur, rounds, round time, fps max)

	//font colors
	int color_std	= bmfblue;
	int	color_off	= bmfred;

	//motion blur ([off], 1, 2, 4, 5, 7, ...)
	if (MBLUR_LIMIT)
		if (option.data.mblur != 0 && !(option.data.mblur % 3))
		{
			option.data.mblur = option.dataDEF.mblur;
			hud_add_message(0, color_std, "[!] MotionBlur %i", option.data.mblur);
		}

	//rounds (1, 3, 5, ...)
/*	if (!(option.data.rounds % XXX))
	{
		option.data.rounds = option.dataDEF.rounds;
		hud_add_message(0, color_std, "[!] Rounds %i", option.data.rounds);
	}*/
//!! in structs.h, in optionslot handler (als Best Of: x?)

	//round time ([off], 5, 6, 7, ...)
	if (option.data.roundtime < option.dataMIN.roundtime && option.data.roundtime != 0)
	{
		option.data.roundtime = option.dataMIN.roundtime;
		hud_add_message(0, color_std, "[!] Round Time %i", option.data.roundtime);
	}

	//fps max ([off], 30, 31, 32, ...)
	//(covered by console function)
	if (option.data.fps_max < option.dataMIN.fps_max && option.data.fps_max != 0)
	{
		option.data.fps_max = option.dataMIN.fps_max;
		hud_add_message(0, color_std, "[!] Maximum FPS %i", option.data.fps_max);
	}

	//---- option display ------------------------------------------------------------------------
	//display option for 2 seconds from time of change
/*
	LONGLONG	t_display = time.freq * 2;

	//display slots
	ipoint ds_desc[20]	= {0};
	ds_desc[0].setpoint(8, 530);
	ds_desc[1].setpoint(8, 546);
	ds_desc[2].setpoint(8, 562);
	ds_desc[3].setpoint(8, 578);

	ds_desc[4].setpoint(168, 530);
	ds_desc[5].setpoint(168, 546);
	ds_desc[6].setpoint(168, 562);
	ds_desc[7].setpoint(168, 578);

	ds_desc[8].setpoint(328, 530);
	ds_desc[9].setpoint(328, 546);
	ds_desc[10].setpoint(328, 562);
	ds_desc[11].setpoint(328, 578);

	ds_desc[12].setpoint(488, 530);
	ds_desc[13].setpoint(488, 546);
	ds_desc[14].setpoint(488, 562);
	ds_desc[15].setpoint(488, 578);

	ds_desc[16].setpoint(648, 530);
	ds_desc[17].setpoint(648, 546);
	ds_desc[18].setpoint(648, 562);
	ds_desc[19].setpoint(648, 578);

	//for (register int i = 0; i < 20; ++i)
	//	dd.typebmf(ds_desc[i].x, ds_desc[i].y, 1, "1234567890 123");

	//vsync
	if (time.current <= data_ig.f_vsync + t_display)
	{
		dd.typebmf(ds_desc[0].x, ds_desc[0].y, bmfwhite, "VSync %s", getstate((float)option.data.vsync));
	}

	//shadows
	if (time.current <= data_ig.f_shadows + t_display)
	{
		dd.typebmf(ds_desc[1].x, ds_desc[1].y, bmfwhite, "Shadows %s", getstate((float)option.data.shadows));
	}

	//sound
	//display not available message if no sound available
	if (time.current <= data_ig.f_sound + t_display)
	{
		if (option.dataDEF.sound == 1)
		{
			dd.typebmf(ds_desc[0].x, ds_desc[0].y, bmfwhite, "Sound %s", getstate((float)option.data.sound));
		}
		else
		{
			dd.typebmf(ds_desc[0].x, ds_desc[0].y, bmfred, "Sound N/A");
		}
	}

	//speed
	if (time.current <= data_ig.f_speed + t_display)
	{
		dd.typebmf(ds_desc[3].x, ds_desc[3].y, bmfwhite, "Speed %.1f", option.data.speed);
	}

	//mblur
	if (time.current <= data_ig.f_mblur + t_display)
	{
		if (option.data.mblur != 0)
		{
			dd.typebmf(ds_desc[6].x, ds_desc[6].y, bmfwhite, "MotionBlur %i", option.data.mblur);
		}
		else
		{
			dd.typebmf(ds_desc[6].x, ds_desc[6].y, bmfwhite, "MotionBlur OFF");
		}
	}

	//bw_mode
	if (time.current <= data_ig.f_bwmode + t_display)
	{
		dd.typebmf(ds_desc[2].x, ds_desc[2].y, bmfwhite, "BW Mode %s", getstate((float)option.data.bw_mode));
	}

	//damage multiplier
	if (time.current <= data_ig.f_damage_multiplier + t_display)
	{
		dd.typebmf(ds_desc[5].x, ds_desc[5].y, bmfwhite, "Dam Factor %.1f", option.data.damage_multiplier);
	}

	//fatigue multiplier
	if (time.current <= data_ig.f_fom_multiplier + t_display)
	{
		dd.typebmf(ds_desc[4].x, ds_desc[4].y, bmfwhite, "Fat Factor %.1f", option.data.fom_multiplier);
	}

	//screenshot taken
	if (time.current <= data_ig.f_screenshot + t_display)
	{
		//dd.typefont(344, 576, "Screenshot taken");
		//dd.typefont(480, 576, data_ig.screenshot_id);
//		dd.typefont(344, 576, data_ig.screenshot_id);
		dd.typebmf(ds_desc[15].x, ds_desc[15].y, bmfwhite, "%s", data_ig.screenshot_id);
	}*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame ingame
//
//	ingame routine mf::data_ig contains data)
//
//------------------------------------------------------------------------------------------------

void master_frame::ingame()
{
	//---- initialization ------------------------------------------------------------------------

	if (data_ig.state == 0)
	{
		//set input lock to delete everything except for stance feet/arms
		data_ig.state_ip = 1;

		//random number for fight message
		//!!
		//data_ig.message = 0 + (rand() % (4 - 0 + 1));
		data_ig.message = 0;

		//round 1
		data_ig.round = 1;

		//reset round time counter
		//limit
		if (option.data.roundtime > 0 && option.data.roundtime < 5)
			option.data.roundtime = 5;
		data_ig.roundtime	= option.data.roundtime;
		data_ig.t_round		= 0;

		//fill background
		RGBcolor bc(BORDERCOLOR);
		dd.colorfill(bc);

		//show redrawn background
//		dd.flip(option.data.vsync);

		//pause
		ppause.sleep_pause(time.current, 1.0f);

		//draw names, timer and winning points
		RECT	r_plname1, r_plname2;
		r_plname1.left = 0;		r_plname1.right = 399;
		r_plname2.left = 400;	r_plname2.right = 799;
		dd.typefont((int)centerfont(option.data.name[P1], r_plname1, 0.35f).x,
					29,
					option.data.name[P1], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
		dd.typefont((int)centerfont(option.data.name[P2], r_plname2, 0.35f).x,
					29,
					option.data.name[P2], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
		dd.drawwinpoints(option.data.rounds, option.data.bw_mode, option.data.roundtime,
						 data_ig.gl_winpoints, option.data.fistcolor[P1], option.data.fistcolor[P2]);
		//update round time string
		if (option.data.roundtime)
		{
			process_roundtime(true);
			dd.typefont(1 + (int)centerfont(data_ig.rts, dd.rSCREEN169, 0.45f).x,
						(int)((75.0f / 2.0f) - (48.0f * 0.45f / 2.0f)),
						data_ig.rts, 0, 0, 1, 0.45f, 0, 0, 0, 255, 255, 255);
		}

		//show screen
		dd.flip(option.data.vsync);

		//fade to standard
		dd.gamma_fade(1, 0, 0.5f);

		//bordermove and zoom with names, time (if on) and winning points
		game_startup(1.0f, 0, 1.0f);

		//advance sequence state
		data_ig.state = 1;
		//set sequence starting time
		data_ig.t_start_a = time.current;

		//set sound sequence starting time
		data_ig.t_start_s = time.current;

		return;
	}

	//---- sounds --------------------------------------------------------------------------------

	//round sound
	if (data_ig.state_s == 0)
	{
		if (time.current >= data_ig.t_start_s + (time.freq * 0.5f))
		{
			//round
			playsound_s(S_ROUND);

			//advance sound sequence state
			data_ig.t_start_s	= time.current;
			//advance sequence state
			data_ig.state_s		= 1;

			//demo recording
			if (option.data.demo_rec)
			{
				if (recorder.record_start(data_ig.round))
				{
					//con_add_message("RECORDING STARTED");
					hud_add_message(0, bmfgreen, "RECORDING STARTED:");
					hud_add_message(0, bmfblue, "\"%s\"", recorder.demo_name);
				}
			}
		}
	}

	//round number sound
	if (data_ig.state_s == 1)
	{
		if (time.current >= data_ig.t_start_s + (time.freq * 0.75f))
		{
			//round number
			if (data_ig.round == 1)				playsound_s(S_ONE);
			if (data_ig.round == 2)				playsound_s(S_TWO);
			if (data_ig.round == 3)				playsound_s(S_THREE);
			if (data_ig.round == 4)				playsound_s(S_FOUR);

			//advance sound sequence state
			data_ig.t_start_s	= time.current;
			//advance sequence state
			data_ig.state_s		= 2;
		}
	}

	//fight sound
	if (data_ig.state_s == 2)
	{
		if (time.current >= data_ig.t_start_s + (time.freq * 1.15f))
		{
			//round
			playsound_s(S_FIGHT);

			//advance sound sequence state
			data_ig.t_start_s	= time.current;
			//advance sequence state
			data_ig.state_s		= 3;
		}
	}

	//---- new round -----------------------------------------------------------------------------

	if (data_ig.state == 1)
	{
		//size of message
		float size = 0.4f;

		//print round message
		if (time.current >= data_ig.t_start_a + (time.freq * 0.5f))
			if (time.current < data_ig.t_start_a + (time.freq * 2.0f))
			{
				//round
				dd.typefont((int)centerfont("Round  ", dd.rSCREEN169, size).x,
							(int)centerfont("Round  ", dd.rSCREEN169, size).y,
							"Round", 0, 0, 1, size,
							data_ig.c_mb.r, data_ig.c_mb.g, data_ig.c_mb.b, data_ig.c_mf.r, data_ig.c_mf.g, data_ig.c_mf.b);

				//number of round
				dd.typefont((int)(centerfont("Round  ", dd.rSCREEN169, size).x + 6 * 32 * size),
							(int)centerfont("Round  ", dd.rSCREEN169, size).y,
							"", data_ig.round, 0, 1, size,
							data_ig.c_mb.r, data_ig.c_mb.g, data_ig.c_mb.b, data_ig.c_mf.r, data_ig.c_mf.g, data_ig.c_mf.b);
			}
			else
			//advance sequence state
			{
				data_ig.t_start_a	= time.current;
				data_ig.state		= 2;
			}
	}

	//fight message
	if (data_ig.state == 2)
	{
		//size of message
		float size = 0.4f;

		//pause, then print fight message
		if (time.current >= data_ig.t_start_a + (time.freq * 0.4f))
			if (time.current < data_ig.t_start_a + (time.freq * 1.5f))
			{
				//fight
				dd.typefont((int)centerfont(data_ig.pstartmessage[data_ig.message], dd.rSCREEN169, size).x,
							(int)centerfont(data_ig.pstartmessage[data_ig.message], dd.rSCREEN169, size).y,
							data_ig.pstartmessage[data_ig.message], 0, 0, 1, size,
							data_ig.c_mb.r, data_ig.c_mb.g, data_ig.c_mb.b, data_ig.c_mf.r, data_ig.c_mf.g, data_ig.c_mf.b);
			}
			else
			//advance sequence state
			{
				data_ig.t_start_a	= time.current;
				data_ig.state		= 50;

				//set input lock to all input valid
				data_ig.state_ip = 0;

				//set last update of round time counter to current time
				//to start with a whole second
				data_ig.t_round = time.current;
			}
	}

	//---- ingame logic --------------------------------------------------------------------------

	if (data_ig.state > 0 && data_ig.state != 100)
	{
		//if delete input flag set except stance feet/arms
		if (data_ig.state_ip != 0)
			//for all actions
			for (register int i = 0; i < NPAC; ++i)
				//all input except for stance_feet/arms and taunts
				if (data_ig.state_ip == 1)
				{
					if (i != AC_STANCE_FEET &&
						i != AC_STANCE_ARMS &&
						i != AC_TAUNT1 &&
						i != AC_TAUNT2)
					{
						//delete action
						is.PA[P1][i] = AS_INACTIVE;
						is.PA[P2][i] = AS_INACTIVE;
					}
				}
				else
				//all input
				{
					//delete action
					is.PA[P1][i] = AS_INACTIVE;
					is.PA[P2][i] = AS_INACTIVE;
				}

		//---- user input ------------------------------------------------------------------------

		//for both players when not k.o.
//!!		for (register int p = 0; p < 2 && !P[p].gl_ko && !P[!p].gl_ko; ++p)
		for (register int p = 0; p < 2; ++p)
		{
			//process input handling (every frame)
			P[p].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
		}

		//---- animation and game logic ----------------------------------------------------------

		//calculate shadow data in realtime
		if (option.data.shadows)
			calculate_shadows();

		//for all subframes
		for (register int sf = 0; sf < option.data.subframes; ++sf)
		{
			//animate players
			P[P1].al_animate(false);
			P[P2].al_animate(false);

			//process bone data
			P[P1].process_bones(s_scale, s_mpy);
			P[P2].process_bones(s_scale, s_mpy);

			//player distance
			player_distance = (float)fabs(P[P1].sk.p_ref->v.p[0].x - P[P2].sk.p_ref->v.p[0].x);

			//process game logic every subframe
			P[P1].gl_process_game_logic(is.t_move);
			P[P2].gl_process_game_logic(is.t_move);

			//do collision detection tests
			collision_detection();

			//calculate damage to cause if collision occured and store result in rcd object
			rcd.damage[P1] = P[P1].gl_process_damage_off(is.t_move);
			rcd.damage[P2] = P[P2].gl_process_damage_off(is.t_move);

			//check for knockout in subframes for precision
			if ((P[P1].gl_ko || P[P2].gl_ko) &&
				data_ig.state != 10 && data_ig.state != 15)
			{
				//sequence state
				data_ig.state	= 10;

				//start time
				data_ig.t_start_a	= time.current;

				//lock all input
				data_ig.state_ip	= 2;

				//save game speed at ko
				data_ig.speed_start	= option.data.speed;

				//add score to total score
				data_ig.gl_totalscore[P1] += (int)P[P1].gl_score;
				data_ig.gl_totalscore[P2] += (int)P[P2].gl_score;

				break;
			}

			//switching sides
			auto_side_switch();
		}

		//quicksort bones of both players in z-order
		quicksort_zb(pd.pzb, 0, 37, 1);

		//update particle arrays
		P[P1].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);
		P[P2].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);

		//gammaflash
		//!! farben
		if (P[P1].blood_gammaflash)
		{
			dd.gamma_fade_ini(1, 2, red, 0.1f / option.data.speed);
			P[P1].blood_gammaflash = false;
		}
		if (P[P2].blood_gammaflash)
		{
			dd.gamma_fade_ini(1, 2, red, 0.1f / option.data.speed);
			P[P2].blood_gammaflash = false;
		}

		//---- roundtime, points -----------------------------------------------------------------

		//if round time limit and round started
		if (option.data.roundtime && data_ig.state == 50)
			//process round time
			//if round time up
			if (process_roundtime())
			{
				//k.o./slow mo sequence
				data_ig.state	= 10;

				//start time
				data_ig.t_start_a	= time.current;

				//lock all input
				data_ig.state_ip	= 2;

				//save game speed at ko
				data_ig.speed_start	= option.data.speed;

				//add score to total score
				data_ig.gl_totalscore[P1] += (int)P[P1].gl_score;
				data_ig.gl_totalscore[P2] += (int)P[P2].gl_score;
			}

		//---- rendering -------------------------------------------------------------------------

		//draw scene including players, shadows, names, winning points
		dd.drawscene(&pd, 0, 0, black, 0, 0, 0);

		//draw player message if active
		//for both players
/*		for (p = 0; p < 2; ++p)
			if (P[p].pmessage.active)
				dd.typefont((int)P[p].pmessage.pos.x, (int)P[p].pmessage.pos.y,
							P[p].pmessage.message, 0, 0, 1, P[p].pmessage.size,
							P[p].pmessage.b_color.r, P[p].pmessage.b_color.g, P[p].pmessage.b_color.b,
							P[p].pmessage.f_color.r, P[p].pmessage.f_color.g, P[p].pmessage.f_color.b);*/

		//---- sounds ----------------------------------------------------------------------------

		process_sound();

		//---- recorder  --------------------------------------------------------------------------

		//if recording on
		if (option.data.demo_rec)
		{
			recorder.process();
		}
	}

	//---- knockout sequence ---------------------------------------------------------------------

	if (data_ig.state == 10)
	{
		//!! lower arms
		//if (P[P1].gl_ko)	P[P1].stance_arms = 0;
		//if (P[P2].gl_ko)	P[P2].stance_arms = 0;

		//reduce game speed over equal amount of time until reached 0
		if (option.data.speed - (data_ig.speed_start * 2.0f) * time.sca >= 0)
			option.data.speed -= (data_ig.speed_start * 2.0f) * (float)time.sca;
		else
		//when speed reached 0
		{
			//no speed below 0
			option.data.speed = 0;

			//pause and win message
			if (time.current > data_ig.t_start_a + (time.freq * 0.5f))
			{
				//create win message
				RGBcolor	cwinner;
				char wm[35] = {0};

				//update winning points
				int winner = update_winpoints();

				if (winner == P1)
				{
					strcpy(wm, option.data.name[P1]);
					cwinner = option.data.fistcolor[P1];
					//perfect win
					if (P[P1].sk.damage[0] +
						P[P1].sk.damage[1] +
						P[P1].sk.damage[2] +
						P[P1].sk.damage[3] +
						P[P1].sk.damage[4] +
						P[P1].sk.damage[5] +
						P[P1].sk.damage[6] +
						P[P1].sk.damage[7] +
						P[P1].sk.damage[8] +
						P[P1].sk.damage[9] +
						P[P1].sk.damage[10] == 0)
						strcat(wm, " wins PERFECT!");
					else
						strcat(wm, " wins");
				}
				if (winner == P2)
				{
					strcpy(wm, option.data.name[P2]);
					cwinner = option.data.fistcolor[P2];
					//perfect win
					if (P[P2].sk.damage[0] +
						P[P2].sk.damage[1] +
						P[P2].sk.damage[2] +
						P[P2].sk.damage[3] +
						P[P2].sk.damage[4] +
						P[P2].sk.damage[5] +
						P[P2].sk.damage[6] +
						P[P2].sk.damage[7] +
						P[P2].sk.damage[8] +
						P[P2].sk.damage[9] +
						P[P2].sk.damage[10] == 0)
						strcat(wm, " wins PERFECT!");
					else
						strcat(wm, " wins");
				}
				//draw
				if (winner == 2)
				{
					strcpy(wm, "ROUND DRAW");
					cwinner.setcolor(green);
				}

				//size of win message
				float size				= 0.40f;

				//"name wins"/"draw" message
				dd.typefont((int)centerfont(wm, dd.rSCREEN169, size).x,
							(int)centerfont(wm, dd.rSCREEN169, size).y,
							wm, 0, 0, 1, size,
							0, 0, 0, cwinner.r, cwinner.g, cwinner.b);

				size					= 0.45f;
				//create and draw "score_p1:score_p2" string
				char sm[22]				= {0};
				char score[11]			= {0};
				_itoa((int)P[P1].gl_score, score, 10);
				strcat(sm, score);
				strcat(sm, ":");
				_itoa((int)P[P2].gl_score, score, 10);
				strcat(sm, score);
				dd.typefont((int)centerfont(sm, dd.rSCREEN169, size).x,
							320,
							sm, 0, 0, 1, size,
							0, 0, 0, cwinner.r, cwinner.g, cwinner.b);
			}

			//next round or return to title
			if (time.current > data_ig.t_start_a + (time.freq * 3.5f))
			{
				//stop demo
				if (option.data.demo_rec)
					if (recorder.stop())
					{
						hud_add_message(0, bmfgreen, "RECORDING STOPPED:");
						hud_add_message(0, bmfblue, "\"%s\"", recorder.demo_name);
					}

				//if last round return to title
				if (data_ig.round == option.data.rounds)
				{
					//final win message
					data_ig.state		= 15;
					data_ig.t_start_a	= time.current;
				}
				//else reset data and start next round
				else
				{
					//lock all input except for for stance feet/arms
					data_ig.state_ip	= 1;

					//increase round
					++data_ig.round;

					//reset round time counter
					//limit (re-check in case of console change)
					if (option.data.roundtime > 0 && option.data.roundtime < 5)
						option.data.roundtime = 5;
					data_ig.roundtime	= option.data.roundtime;
					data_ig.t_round		= 0;
					//update timestring
					process_roundtime(true);

					//fade out
					dd.gamma_fade(0, 1, 0.5f);

					//reset players
					int pos		= 0 + (rand() % (1 - 0 + 1));
					P[P1].reset(pos);
					P[P2].reset(pos);
					//recalculate z-order else graphic glitch after gamma fade
					quicksort_zb(pd.pzb, 0, 37, 1);

					//reset speed
					option.data.speed	= data_ig.speed_start;

					//process bone data
					P[P1].process_bones(s_scale, s_mpy);
					P[P2].process_bones(s_scale, s_mpy);

					//draw background
					dd.drawbackground(option.data.cbackground.r,
									  option.data.cbackground.g,
									  option.data.cbackground.b,
									  1, 1, 1);

					//draw scene including players, shadows, names, winning points
					dd.drawscene(&pd, 0, 0, black, 0, 0, 0);

					//show screen
					dd.flip(option.data.vsync);

					//draw again
					dd.drawbackground(option.data.cbackground.r,
									  option.data.cbackground.g,
									  option.data.cbackground.b,
									  1, 1, 1);
					dd.drawscene(&pd, 0, 0, black, 0, 0, 0);

					//fade in
					dd.gamma_fade(1, 1, 0.5f);

					//start new round
					data_ig.state		= 1;
					data_ig.state_s		= 0;
					data_ig.t_start_a	= time.current;
					data_ig.t_start_s	= time.current;
				}
			}
		}
	}

	//---- final win message ---------------------------------------------------------------------

	if (data_ig.state == 15)
	{
		if (time.current > data_ig.t_start_a + (time.freq * 0.5f))
		{
			//get final winner
			int winner = update_winpoints(true);

			//win message
			RGBcolor	cwinner;
			char		wm[32] = {0};

			if (winner == P1)
			{
				strcpy(wm, option.data.name[P1]);
				strcat(wm, " wins Fight");
				cwinner = option.data.fistcolor[P1];
			}
			if (winner == P2)
			{
				strcpy(wm, option.data.name[P2]);
				strcat(wm, " wins Fight");
				cwinner = option.data.fistcolor[P2];
			}
			if (winner == 2)
			{
				strcpy(wm, "FIGHT DRAW");
				cwinner.setcolor(green);
			}

			float size = 0.45f;

			//type message
			dd.typefont((int)centerfont(wm, dd.rSCREEN169, size).x,
						(int)centerfont(wm, dd.rSCREEN169, size).y,
						wm, 0, 0, 1, size,
						0, 0, 0, cwinner.r, cwinner.g, cwinner.b);

			//create and draw "totalscore_p1:totalscore_p2" string
			char sm[22]				= {0};
			char score[11]			= {0};
			_itoa(data_ig.gl_totalscore[P1], score, 10);
			strcat(sm, score);
			strcat(sm, ":");
			_itoa(data_ig.gl_totalscore[P2], score, 10);
			strcat(sm, score);
			dd.typefont((int)centerfont(sm, dd.rSCREEN169, size).x,
						320,
						sm, 0, 0, 1, size,
						0, 0, 0, cwinner.r, cwinner.g, cwinner.b);
		}

		//return to title
		if (time.current > data_ig.t_start_a + (time.freq * 3.0f))
		{
			//press button message
			char pbm[]		= "Press Button to Continue";
			dd.typefont((int)centerfont(pbm, dd.rSCREEN169, 0.25f).x,
					   370, pbm, 0, 0, 1, 0.25f,
					   0, 0, 0, white, white, white);

			//wait for button press
			if (is.mouse1DUALL() || is.key1DUALL())
			{
				playsound_s(S_MSELECT);
				data_ig.state = 100;
			}
		}
	}

	//---- done, return to title -----------------------------------------------------------------

	if (data_ig.state == 100)
	{
		//stop demo (in case of exit through pause)
		if (option.data.demo_rec)
			if (recorder.stop())
			{
				hud_add_message(0, bmforange, "RECORDING STOPPED:");
				hud_add_message(0, bmforange, "\"%s\"", recorder.demo_name);
			}

		//fade to black
		dd.gamma_fade(0, 0, 0.5f);

		//reset speed
		if (data_ig.speed_start != 0)
			option.data.speed = data_ig.speed_start;

		//reset ingame data
		data_ig.reset();

		//reset players
		int pos		= 0 + (rand() % (1 - 0 + 1));
		P[P1].reset(pos);
		P[P2].reset(pos);

		//return to title
		program_state = TITLE;
		return;
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame process_roundtime
//
//	processes roundtime
//	returns false when round time up
//
//------------------------------------------------------------------------------------------------

bool master_frame::process_roundtime(bool stringonly)
{
	bool timeup = false;

	//don't decrease timer if only to update round time string
	if (!stringonly)
	{
		//if at least one second remaining
		if (data_ig.roundtime > 0)
		{
			//decrease round time every second
			if (data_ig.t_round + time.freq <= time.current)
			{
				--data_ig.roundtime;
				data_ig.t_round = time.current;

				//play sound fx for last 5 seconds
				if (data_ig.roundtime <= 5)
					playsound_s(S_TICK);
			}
		}
		else
		{
			//round time up
			timeup = true;
		}
	}

	//convert roundtime in minutes and seconds
	int rtm = 0, rts = data_ig.roundtime;

	while (rts > 59)
	{
		rts -= 60;
		++rtm;

		//only double digit minutes
		if (rtm > 99)
			rtm = 99;
	}

	//convert minutes and seconds into string
	//clear round time string
	ZeroMemory(&data_ig.rts, sizeof(data_ig.rts));
	char c[2] = {0};

	if (rtm < 10)
		data_ig.rts[0] = '0';
	_itoa(rtm, c, 10);
	strcat(data_ig.rts, c);

	data_ig.rts[2] = ':';

	if (rts < 10)
		data_ig.rts[3] = '0';
	_itoa(rts, c, 10);
	strcat(data_ig.rts, c);

	return(timeup);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame udpate winpoints
//
//	sets winning points depending on player won
//
//------------------------------------------------------------------------------------------------

int master_frame::update_winpoints(bool final)
{
	if (!final)
	{
		//win through k.o.
		if (P[P1].gl_ko || P[P2].gl_ko)
		{
			//k.o. draw
			if (P[P1].gl_ko && P[P2].gl_ko)
			{
				data_ig.gl_winpoints[data_ig.round - 1] = 3;
				return(2);
			}
			else
				//player 1 wins
				if (P[P2].gl_ko)
				{
					data_ig.gl_winpoints[data_ig.round - 1] = 1;
					return(P1);
				}
				else
				//player 2 wins
				{
					data_ig.gl_winpoints[data_ig.round - 1] = 2;
					return(P2);
				}
		}
		//win through points
		else
		{
			//score draw
			if (P[P1].gl_score == P[P2].gl_score)
			{
				data_ig.gl_winpoints[data_ig.round - 1] = 3;
				return(2);
			}
			else
				//player 1 wins
				if (P[P1].gl_score > P[P2].gl_score)
				{
					data_ig.gl_winpoints[data_ig.round - 1] = 1;
					return(P1);
				}
				else
				//player 2 wins
				{
					data_ig.gl_winpoints[data_ig.round - 1] = 2;
					return(P2);
				}
		}
	}
	else
	//if to determine final winner
	{
		//holds wins of player 1 and 2
		int wp[2] = {0, 0};

		//for all rounds
		for (register int i = 0; i < option.data.rounds; ++i)
		{
			//count rounds won by each player
			if (data_ig.gl_winpoints[i] == 1)			++wp[P1];
			if (data_ig.gl_winpoints[i] == 2)			++wp[P2];
		}

		//return winner
		//0 = P1
		//1 = P2
		//2 = draw
		if (wp[P1] == wp[P2])
		{
			//if same number of rounds won player with higher total score wins
			if (data_ig.gl_totalscore[P1] == data_ig.gl_totalscore[P2])
				return(2);
			else
				if (data_ig.gl_totalscore[P1] > data_ig.gl_totalscore[P2])
					return(P1);
				else
					return(P2);
		}
		else
		{
			if (wp[P1] > wp[P2])
				return(P1);
			else
				return(P2);
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame ChangeScreenMode
//
//	sets screen mode to fullscreen or windowed
//
//------------------------------------------------------------------------------------------------

bool master_frame::ChangeScreenMode()
{
	//release dd objects
	if (!dd.dd_cleanup_screenmode(hwnd))
	{
		gf_logger(true, "master_frame::ChangeScreenMode dd.dd_cleanup_mode FAILED");
		return(false);
	}

	//create new dd objects
	if (!dd.dd_initialization_screenmode(hwnd))
	{
		gf_logger(true, "master_frame::ChangeScreenMode dd.dd_initialization_mode FAILED");
		return(false);
	}
	else
	{
		gf_logger(false, "master_frame::ChangeScreenMode dd.dd_initialization_mode DONE");
		return(true);
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame load_animations
//
//	first loads animation for left side and left stance
//	then creates animations for left side and right stance (mirrored)
//	finally creates animations for right side and its two stances (mirrored)
//	returns false if file doesn't exist
//
//------------------------------------------------------------------------------------------------

bool master_frame::load_animations()
{
	//animation file name format:
	//stance(asi)_name.file ending
	//00_jab.amn

	//load left side, left stance animations from file
	//for all animations
	for (register int i = 0; i < NPAN; ++i)
		//load animation
		if (anmn[0][i].load_animation(panmnfile[0][i],			//file name
									  CAV,						//version
									  0) == false)				//type (0 = animation, 1 = single kf)
		{
			//gp_ErrStr = Err_MFLoadAnimation;
			gp_ErrStr	= panmnfile[0][i];
			return false;
		}

	//reference animation asi and current animation asi
	int r = 0;
	int s = 1;

	//create animations for left side and right stance
	//for all animations
	for (i = 0; i < NPAN; ++i)
	{
		//load default animation
		if (anmn[s][i].load_animation(panmnfile[r][i],
									  CAV,
									  0) == false)
		{
			gp_ErrStr	= panmnfile[s][i];
			return false;
		}

		//---- animation data --------------------------------------------------------------------
		//data swapping:
		/*[btll]	= [btll];
		[btlr]		= [btlr];
		[btul]		= [btul];
		[btur]		= [btur];
		[bn]		= [bn];
		[bsl]		= [bsr];
		[baul]		= [baur];
		[ball]		= [balr];
		[bsr]		= [bsl];
		[baur]		= [baul];
		[balr]		= [ball];
		[bhl]		= [bhr];
		[blul]		= [blur];
		[blll]		= [bllr];
		[bfl]		= [bfr];
		[bhr]		= [bhl];
		[blur]		= [blul];
		[bllr]		= [blll];
		[bfr]		= [bfl];*/

		//don't swap torso since both sides have the same data anyway

		//priority
		anmn[s][i].priority[bsl]		= anmn[r][i].priority[bsr];
		anmn[s][i].priority[baul]		= anmn[r][i].priority[baur];
		anmn[s][i].priority[ball]		= anmn[r][i].priority[balr];
		anmn[s][i].priority[bsr]		= anmn[r][i].priority[bsl];
		anmn[s][i].priority[baur]		= anmn[r][i].priority[baul];
		anmn[s][i].priority[balr]		= anmn[r][i].priority[ball];
		anmn[s][i].priority[bhl]		= anmn[r][i].priority[bhr];
		anmn[s][i].priority[blul]		= anmn[r][i].priority[blur];
		anmn[s][i].priority[blll]		= anmn[r][i].priority[bllr];
		anmn[s][i].priority[bfl]		= anmn[r][i].priority[bfr];
		anmn[s][i].priority[bhr]		= anmn[r][i].priority[bhl];
		anmn[s][i].priority[blur]		= anmn[r][i].priority[blul];
		anmn[s][i].priority[bllr]		= anmn[r][i].priority[blll];
		anmn[s][i].priority[bfr]		= anmn[r][i].priority[bfl];

		//ui_index (also reverse torso)
		if (anmn[r][i].ui_index == btll)	anmn[s][i].ui_index = btlr;
		if (anmn[r][i].ui_index == btlr)	anmn[s][i].ui_index = btll;
		if (anmn[r][i].ui_index == btul)	anmn[s][i].ui_index = btur;
		if (anmn[r][i].ui_index == btur)	anmn[s][i].ui_index = btul;
		if (anmn[r][i].ui_index == bn)		anmn[s][i].ui_index = bn;
		if (anmn[r][i].ui_index == bsl)		anmn[s][i].ui_index = bsr;
		if (anmn[r][i].ui_index == baul)	anmn[s][i].ui_index = baur;
		if (anmn[r][i].ui_index == ball)	anmn[s][i].ui_index = balr;
		if (anmn[r][i].ui_index == bsr)		anmn[s][i].ui_index = bsl;
		if (anmn[r][i].ui_index == baur)	anmn[s][i].ui_index = baul;
		if (anmn[r][i].ui_index == balr)	anmn[s][i].ui_index = ball;
		if (anmn[r][i].ui_index == bhl)		anmn[s][i].ui_index = bhr;
		if (anmn[r][i].ui_index == blul)	anmn[s][i].ui_index = blur;
		if (anmn[r][i].ui_index == blll)	anmn[s][i].ui_index = bllr;
		if (anmn[r][i].ui_index == bfl)		anmn[s][i].ui_index = bfr;
		if (anmn[r][i].ui_index == bhr)		anmn[s][i].ui_index = bhl;
		if (anmn[r][i].ui_index == blur)	anmn[s][i].ui_index = blul;
		if (anmn[r][i].ui_index == bllr)	anmn[s][i].ui_index = blll;
		if (anmn[r][i].ui_index == bfr)		anmn[s][i].ui_index = bfl;

		//ui_bias (same)
		//anmn[s][i].ui_bias				= anmn[r][i].ui_bias;

		//a_diffp, a_diffn, l_diffp, l_diffn, w_diffp, w_diffn
		anmn[s][i].a_diffp[bsl]			= anmn[r][i].a_diffp[bsr];
		anmn[s][i].a_diffp[baul]		= anmn[r][i].a_diffp[baur];
		anmn[s][i].a_diffp[ball]		= anmn[r][i].a_diffp[balr];
		anmn[s][i].a_diffp[bsr]			= anmn[r][i].a_diffp[bsl];
		anmn[s][i].a_diffp[baur]		= anmn[r][i].a_diffp[baul];
		anmn[s][i].a_diffp[balr]		= anmn[r][i].a_diffp[ball];
		anmn[s][i].a_diffp[bhl]			= anmn[r][i].a_diffp[bhr];
		anmn[s][i].a_diffp[blul]		= anmn[r][i].a_diffp[blur];
		anmn[s][i].a_diffp[blll]		= anmn[r][i].a_diffp[bllr];
		anmn[s][i].a_diffp[bfl]			= anmn[r][i].a_diffp[bfr];
		anmn[s][i].a_diffp[bhr]			= anmn[r][i].a_diffp[bhl];
		anmn[s][i].a_diffp[blur]		= anmn[r][i].a_diffp[blul];
		anmn[s][i].a_diffp[bllr]		= anmn[r][i].a_diffp[blll];
		anmn[s][i].a_diffp[bfr]			= anmn[r][i].a_diffp[bfl];

		anmn[s][i].a_diffn[bsl]			= anmn[r][i].a_diffn[bsr];
		anmn[s][i].a_diffn[baul]		= anmn[r][i].a_diffn[baur];
		anmn[s][i].a_diffn[ball]		= anmn[r][i].a_diffn[balr];
		anmn[s][i].a_diffn[bsr]			= anmn[r][i].a_diffn[bsl];
		anmn[s][i].a_diffn[baur]		= anmn[r][i].a_diffn[baul];
		anmn[s][i].a_diffn[balr]		= anmn[r][i].a_diffn[ball];
		anmn[s][i].a_diffn[bhl]			= anmn[r][i].a_diffn[bhr];
		anmn[s][i].a_diffn[blul]		= anmn[r][i].a_diffn[blur];
		anmn[s][i].a_diffn[blll]		= anmn[r][i].a_diffn[bllr];
		anmn[s][i].a_diffn[bfl]			= anmn[r][i].a_diffn[bfr];
		anmn[s][i].a_diffn[bhr]			= anmn[r][i].a_diffn[bhl];
		anmn[s][i].a_diffn[blur]		= anmn[r][i].a_diffn[blul];
		anmn[s][i].a_diffn[bllr]		= anmn[r][i].a_diffn[blll];
		anmn[s][i].a_diffn[bfr]			= anmn[r][i].a_diffn[bfl];

		anmn[s][i].l_diffp[bsl]			= anmn[r][i].l_diffp[bsr];
		anmn[s][i].l_diffp[baul]		= anmn[r][i].l_diffp[baur];
		anmn[s][i].l_diffp[ball]		= anmn[r][i].l_diffp[balr];
		anmn[s][i].l_diffp[bsr]			= anmn[r][i].l_diffp[bsl];
		anmn[s][i].l_diffp[baur]		= anmn[r][i].l_diffp[baul];
		anmn[s][i].l_diffp[balr]		= anmn[r][i].l_diffp[ball];
		anmn[s][i].l_diffp[bhl]			= anmn[r][i].l_diffp[bhr];
		anmn[s][i].l_diffp[blul]		= anmn[r][i].l_diffp[blur];
		anmn[s][i].l_diffp[blll]		= anmn[r][i].l_diffp[bllr];
		anmn[s][i].l_diffp[bfl]			= anmn[r][i].l_diffp[bfr];
		anmn[s][i].l_diffp[bhr]			= anmn[r][i].l_diffp[bhl];
		anmn[s][i].l_diffp[blur]		= anmn[r][i].l_diffp[blul];
		anmn[s][i].l_diffp[bllr]		= anmn[r][i].l_diffp[blll];
		anmn[s][i].l_diffp[bfr]			= anmn[r][i].l_diffp[bfl];

		anmn[s][i].l_diffn[bsl]			= anmn[r][i].l_diffn[bsr];
		anmn[s][i].l_diffn[baul]		= anmn[r][i].l_diffn[baur];
		anmn[s][i].l_diffn[ball]		= anmn[r][i].l_diffn[balr];
		anmn[s][i].l_diffn[bsr]			= anmn[r][i].l_diffn[bsl];
		anmn[s][i].l_diffn[baur]		= anmn[r][i].l_diffn[baul];
		anmn[s][i].l_diffn[balr]		= anmn[r][i].l_diffn[ball];
		anmn[s][i].l_diffn[bhl]			= anmn[r][i].l_diffn[bhr];
		anmn[s][i].l_diffn[blul]		= anmn[r][i].l_diffn[blur];
		anmn[s][i].l_diffn[blll]		= anmn[r][i].l_diffn[bllr];
		anmn[s][i].l_diffn[bfl]			= anmn[r][i].l_diffn[bfr];
		anmn[s][i].l_diffn[bhr]			= anmn[r][i].l_diffn[bhl];
		anmn[s][i].l_diffn[blur]		= anmn[r][i].l_diffn[blul];
		anmn[s][i].l_diffn[bllr]		= anmn[r][i].l_diffn[blll];
		anmn[s][i].l_diffn[bfr]			= anmn[r][i].l_diffn[bfl];

		anmn[s][i].w_diffp[bsl]			= anmn[r][i].w_diffp[bsr];
		anmn[s][i].w_diffp[baul]		= anmn[r][i].w_diffp[baur];
		anmn[s][i].w_diffp[ball]		= anmn[r][i].w_diffp[balr];
		anmn[s][i].w_diffp[bsr]			= anmn[r][i].w_diffp[bsl];
		anmn[s][i].w_diffp[baur]		= anmn[r][i].w_diffp[baul];
		anmn[s][i].w_diffp[balr]		= anmn[r][i].w_diffp[ball];
		anmn[s][i].w_diffp[bhl]			= anmn[r][i].w_diffp[bhr];
		anmn[s][i].w_diffp[blul]		= anmn[r][i].w_diffp[blur];
		anmn[s][i].w_diffp[blll]		= anmn[r][i].w_diffp[bllr];
		anmn[s][i].w_diffp[bfl]			= anmn[r][i].w_diffp[bfr];
		anmn[s][i].w_diffp[bhr]			= anmn[r][i].w_diffp[bhl];
		anmn[s][i].w_diffp[blur]		= anmn[r][i].w_diffp[blul];
		anmn[s][i].w_diffp[bllr]		= anmn[r][i].w_diffp[blll];
		anmn[s][i].w_diffp[bfr]			= anmn[r][i].w_diffp[bfl];

		anmn[s][i].w_diffn[bsl]			= anmn[r][i].w_diffn[bsr];
		anmn[s][i].w_diffn[baul]		= anmn[r][i].w_diffn[baur];
		anmn[s][i].w_diffn[ball]		= anmn[r][i].w_diffn[balr];
		anmn[s][i].w_diffn[bsr]			= anmn[r][i].w_diffn[bsl];
		anmn[s][i].w_diffn[baur]		= anmn[r][i].w_diffn[baul];
		anmn[s][i].w_diffn[balr]		= anmn[r][i].w_diffn[ball];
		anmn[s][i].w_diffn[bhl]			= anmn[r][i].w_diffn[bhr];
		anmn[s][i].w_diffn[blul]		= anmn[r][i].w_diffn[blur];
		anmn[s][i].w_diffn[blll]		= anmn[r][i].w_diffn[bllr];
		anmn[s][i].w_diffn[bfl]			= anmn[r][i].w_diffn[bfr];
		anmn[s][i].w_diffn[bhr]			= anmn[r][i].w_diffn[bhl];
		anmn[s][i].w_diffn[blur]		= anmn[r][i].w_diffn[blul];
		anmn[s][i].w_diffn[bllr]		= anmn[r][i].w_diffn[blll];
		anmn[s][i].w_diffn[bfr]			= anmn[r][i].w_diffn[bfl];

		//hara.x diff and hara.y diff stay same
		//anmn[s][i].h_diffp.x			= anmn[r][i].h_diffp.x;
		//anmn[s][i].h_diffn.x			= anmn[r][i].h_diffn.x;

		//---- keyframe data ---------------------------------------------------------------------

		//for every keyframe
		for (register int k = 0; k < anmn[s][i].nokf; ++k)
		{
			//t_frame
			anmn[s][i].pkf[k].t_frame[bsl]		= anmn[r][i].pkf[k].t_frame[bsr];
			anmn[s][i].pkf[k].t_frame[baul]		= anmn[r][i].pkf[k].t_frame[baur];
			anmn[s][i].pkf[k].t_frame[ball]		= anmn[r][i].pkf[k].t_frame[balr];
			anmn[s][i].pkf[k].t_frame[bsr]		= anmn[r][i].pkf[k].t_frame[bsl];
			anmn[s][i].pkf[k].t_frame[baur]		= anmn[r][i].pkf[k].t_frame[baul];
			anmn[s][i].pkf[k].t_frame[balr]		= anmn[r][i].pkf[k].t_frame[ball];
			anmn[s][i].pkf[k].t_frame[bhl]		= anmn[r][i].pkf[k].t_frame[bhr];
			anmn[s][i].pkf[k].t_frame[blul]		= anmn[r][i].pkf[k].t_frame[blur];
			anmn[s][i].pkf[k].t_frame[blll]		= anmn[r][i].pkf[k].t_frame[bllr];
			anmn[s][i].pkf[k].t_frame[bfl]		= anmn[r][i].pkf[k].t_frame[bfr];
			anmn[s][i].pkf[k].t_frame[bhr]		= anmn[r][i].pkf[k].t_frame[bhl];
			anmn[s][i].pkf[k].t_frame[blur]		= anmn[r][i].pkf[k].t_frame[blul];
			anmn[s][i].pkf[k].t_frame[bllr]		= anmn[r][i].pkf[k].t_frame[blll];
			anmn[s][i].pkf[k].t_frame[bfr]		= anmn[r][i].pkf[k].t_frame[bfl];

			//hara.x stays absolute)
			//anmn[s][i].pkf[k].hara.x			= -anmn[r][i].pkf[k].hara.x;

			//angle, length, width, mode_a
			anmn[s][i].pkf[k].angle[bsl]	= anmn[r][i].pkf[k].angle[bsr];
			anmn[s][i].pkf[k].angle[baul]	= anmn[r][i].pkf[k].angle[baur];
			anmn[s][i].pkf[k].angle[ball]	= anmn[r][i].pkf[k].angle[balr];
			anmn[s][i].pkf[k].angle[bsr]	= anmn[r][i].pkf[k].angle[bsl];
			anmn[s][i].pkf[k].angle[baur]	= anmn[r][i].pkf[k].angle[baul];
			anmn[s][i].pkf[k].angle[balr]	= anmn[r][i].pkf[k].angle[ball];
			anmn[s][i].pkf[k].angle[bhl]	= anmn[r][i].pkf[k].angle[bhr];
			anmn[s][i].pkf[k].angle[blul]	= anmn[r][i].pkf[k].angle[blur];
			anmn[s][i].pkf[k].angle[blll]	= anmn[r][i].pkf[k].angle[bllr];
			anmn[s][i].pkf[k].angle[bfl]	= anmn[r][i].pkf[k].angle[bfr];
			anmn[s][i].pkf[k].angle[bhr]	= anmn[r][i].pkf[k].angle[bhl];
			anmn[s][i].pkf[k].angle[blur]	= anmn[r][i].pkf[k].angle[blul];
			anmn[s][i].pkf[k].angle[bllr]	= anmn[r][i].pkf[k].angle[blll];
			anmn[s][i].pkf[k].angle[bfr]	= anmn[r][i].pkf[k].angle[bfl];

			anmn[s][i].pkf[k].length[bsl]		= anmn[r][i].pkf[k].length[bsr];
			anmn[s][i].pkf[k].length[baul]		= anmn[r][i].pkf[k].length[baur];
			anmn[s][i].pkf[k].length[ball]		= anmn[r][i].pkf[k].length[balr];
			anmn[s][i].pkf[k].length[bsr]		= anmn[r][i].pkf[k].length[bsl];
			anmn[s][i].pkf[k].length[baur]		= anmn[r][i].pkf[k].length[baul];
			anmn[s][i].pkf[k].length[balr]		= anmn[r][i].pkf[k].length[ball];
			anmn[s][i].pkf[k].length[bhl]		= anmn[r][i].pkf[k].length[bhr];
			anmn[s][i].pkf[k].length[blul]		= anmn[r][i].pkf[k].length[blur];
			anmn[s][i].pkf[k].length[blll]		= anmn[r][i].pkf[k].length[bllr];
			anmn[s][i].pkf[k].length[bfl]		= anmn[r][i].pkf[k].length[bfr];
			anmn[s][i].pkf[k].length[bhr]		= anmn[r][i].pkf[k].length[bhl];
			anmn[s][i].pkf[k].length[blur]		= anmn[r][i].pkf[k].length[blul];
			anmn[s][i].pkf[k].length[bllr]		= anmn[r][i].pkf[k].length[blll];
			anmn[s][i].pkf[k].length[bfr]		= anmn[r][i].pkf[k].length[bfl];

			anmn[s][i].pkf[k].width[bsl]		= anmn[r][i].pkf[k].width[bsr];
			anmn[s][i].pkf[k].width[baul]		= anmn[r][i].pkf[k].width[baur];
			anmn[s][i].pkf[k].width[ball]		= anmn[r][i].pkf[k].width[balr];
			anmn[s][i].pkf[k].width[bsr]		= anmn[r][i].pkf[k].width[bsl];
			anmn[s][i].pkf[k].width[baur]		= anmn[r][i].pkf[k].width[baul];
			anmn[s][i].pkf[k].width[balr]		= anmn[r][i].pkf[k].width[ball];
			anmn[s][i].pkf[k].width[bhl]		= anmn[r][i].pkf[k].width[bhr];
			anmn[s][i].pkf[k].width[blul]		= anmn[r][i].pkf[k].width[blur];
			anmn[s][i].pkf[k].width[blll]		= anmn[r][i].pkf[k].width[bllr];
			anmn[s][i].pkf[k].width[bfl]		= anmn[r][i].pkf[k].width[bfr];
			anmn[s][i].pkf[k].width[bhr]		= anmn[r][i].pkf[k].width[bhl];
			anmn[s][i].pkf[k].width[blur]		= anmn[r][i].pkf[k].width[blul];
			anmn[s][i].pkf[k].width[bllr]		= anmn[r][i].pkf[k].width[blll];
			anmn[s][i].pkf[k].width[bfr]		= anmn[r][i].pkf[k].width[bfl];

			anmn[s][i].pkf[k].mode_a[bsl]		= anmn[r][i].pkf[k].mode_a[bsr];
			anmn[s][i].pkf[k].mode_a[baul]		= anmn[r][i].pkf[k].mode_a[baur];
			anmn[s][i].pkf[k].mode_a[ball]		= anmn[r][i].pkf[k].mode_a[balr];
			anmn[s][i].pkf[k].mode_a[bsr]		= anmn[r][i].pkf[k].mode_a[bsl];
			anmn[s][i].pkf[k].mode_a[baur]		= anmn[r][i].pkf[k].mode_a[baul];
			anmn[s][i].pkf[k].mode_a[balr]		= anmn[r][i].pkf[k].mode_a[ball];
			anmn[s][i].pkf[k].mode_a[bhl]		= anmn[r][i].pkf[k].mode_a[bhr];
			anmn[s][i].pkf[k].mode_a[blul]		= anmn[r][i].pkf[k].mode_a[blur];
			anmn[s][i].pkf[k].mode_a[blll]		= anmn[r][i].pkf[k].mode_a[bllr];
			anmn[s][i].pkf[k].mode_a[bfl]		= anmn[r][i].pkf[k].mode_a[bfr];
			anmn[s][i].pkf[k].mode_a[bhr]		= anmn[r][i].pkf[k].mode_a[bhl];
			anmn[s][i].pkf[k].mode_a[blur]		= anmn[r][i].pkf[k].mode_a[blul];
			anmn[s][i].pkf[k].mode_a[bllr]		= anmn[r][i].pkf[k].mode_a[blll];
			anmn[s][i].pkf[k].mode_a[bfr]		= anmn[r][i].pkf[k].mode_a[bfl];

			//action:
			//0 = no action
			//1 = left fist
			//2 = right fist
			//3 = left foot
			//4 = right foot
			//5 = left knee
			//6 = right knee
			if (anmn[r][i].pkf[k].action == 0)		anmn[s][i].pkf[k].action = 0;
			if (anmn[r][i].pkf[k].action == 1)		anmn[s][i].pkf[k].action = 2;
			if (anmn[r][i].pkf[k].action == 2)		anmn[s][i].pkf[k].action = 1;
			if (anmn[r][i].pkf[k].action == 3)		anmn[s][i].pkf[k].action = 4;
			if (anmn[r][i].pkf[k].action == 4)		anmn[s][i].pkf[k].action = 3;
			if (anmn[r][i].pkf[k].action == 5)		anmn[s][i].pkf[k].action = 6;
			if (anmn[r][i].pkf[k].action == 6)		anmn[s][i].pkf[k].action = 5;

			//type and dir stay the same for every keyframe
			}

		//!!
		//save animation
		//anmn[s][i].save_animation(panmnfile[s][i], CAV, 0);
	}

	//---- create mirrored animations for right side ---------------------------------------------

	//for right side, left foot forward (index 2) and
	//right side, right foot forward (index 3)
	for (s = 2; s < 4; ++s)
	{
		//reference to copy from
		//ll(0) -> rr(3)
		//lr(1) -> rl(2)
		int r;
		if (s == 2)		r = 1;
		if (s == 3)		r = 0;

		//for alle animations
		for (register int i = 0; i < NPAN; ++i)
		{
			//load same animation as left side
			if (anmn[s][i].load_animation(panmnfile[0][i], CAV, 0) == false)
			{
				//gp_ErrStr = Err_MFLoadAnimation;
				gp_ErrStr	= panmnfile[s][i];
				return false;
			}

			//---- animation data --------------------------------------------------------------------
			//data swapping:
			/*[btll]	= [btlr];
			[btlr]		= [btll];
			[btul]		= [btur];
			[btur]		= [btul];
			[bn]		= [bn];
			[bsl]		= [bsr];
			[baul]		= [baur];
			[ball]		= [balr];
			[bsr]		= [bsl];
			[baur]		= [baul];
			[balr]		= [ball];
			[bhl]		= [bhr];
			[blul]		= [blur];
			[blll]		= [bllr];
			[bfl]		= [bfr];
			[bhr]		= [bhl];
			[blur]		= [blul];
			[bllr]		= [blll];
			[bfr]		= [bfl];*/

			//priority
			anmn[s][i].priority[btll]		= anmn[r][i].priority[btlr];
			anmn[s][i].priority[btlr]		= anmn[r][i].priority[btll];
			anmn[s][i].priority[btul]		= anmn[r][i].priority[btur];
			anmn[s][i].priority[btur]		= anmn[r][i].priority[btul];
			anmn[s][i].priority[bn]			= anmn[r][i].priority[bn];
			anmn[s][i].priority[bsl]		= anmn[r][i].priority[bsr];
			anmn[s][i].priority[baul]		= anmn[r][i].priority[baur];
			anmn[s][i].priority[ball]		= anmn[r][i].priority[balr];
			anmn[s][i].priority[bsr]		= anmn[r][i].priority[bsl];
			anmn[s][i].priority[baur]		= anmn[r][i].priority[baul];
			anmn[s][i].priority[balr]		= anmn[r][i].priority[ball];
			anmn[s][i].priority[bhl]		= anmn[r][i].priority[bhr];
			anmn[s][i].priority[blul]		= anmn[r][i].priority[blur];
			anmn[s][i].priority[blll]		= anmn[r][i].priority[bllr];
			anmn[s][i].priority[bfl]		= anmn[r][i].priority[bfr];
			anmn[s][i].priority[bhr]		= anmn[r][i].priority[bhl];
			anmn[s][i].priority[blur]		= anmn[r][i].priority[blul];
			anmn[s][i].priority[bllr]		= anmn[r][i].priority[blll];
			anmn[s][i].priority[bfr]		= anmn[r][i].priority[bfl];

			//ui_index
			if (anmn[r][i].ui_index == btll)	anmn[s][i].ui_index = btlr;
			if (anmn[r][i].ui_index == btlr)	anmn[s][i].ui_index = btll;
			if (anmn[r][i].ui_index == btul)	anmn[s][i].ui_index = btur;
			if (anmn[r][i].ui_index == btur)	anmn[s][i].ui_index = btul;
			if (anmn[r][i].ui_index == bn)		anmn[s][i].ui_index = bn;
			if (anmn[r][i].ui_index == bsl)		anmn[s][i].ui_index = bsr;
			if (anmn[r][i].ui_index == baul)	anmn[s][i].ui_index = baur;
			if (anmn[r][i].ui_index == ball)	anmn[s][i].ui_index = balr;
			if (anmn[r][i].ui_index == bsr)		anmn[s][i].ui_index = bsl;
			if (anmn[r][i].ui_index == baur)	anmn[s][i].ui_index = baul;
			if (anmn[r][i].ui_index == balr)	anmn[s][i].ui_index = ball;
			if (anmn[r][i].ui_index == bhl)		anmn[s][i].ui_index = bhr;
			if (anmn[r][i].ui_index == blul)	anmn[s][i].ui_index = blur;
			if (anmn[r][i].ui_index == blll)	anmn[s][i].ui_index = bllr;
			if (anmn[r][i].ui_index == bfl)		anmn[s][i].ui_index = bfr;
			if (anmn[r][i].ui_index == bhr)		anmn[s][i].ui_index = bhl;
			if (anmn[r][i].ui_index == blur)	anmn[s][i].ui_index = blul;
			if (anmn[r][i].ui_index == bllr)	anmn[s][i].ui_index = blll;
			if (anmn[r][i].ui_index == bfr)		anmn[s][i].ui_index = bfl;

			//ui_bias (simply reversed)
			anmn[s][i].ui_bias				= -anmn[r][i].ui_bias;

			//a_diffp, a_diffn, l_diffp, l_diffn, w_diffp, w_diffn
			anmn[s][i].a_diffp[btll]		= -anmn[r][i].a_diffp[btlr];
			anmn[s][i].a_diffp[btlr]		= -anmn[r][i].a_diffp[btll];
			anmn[s][i].a_diffp[btul]		= -anmn[r][i].a_diffp[btur];
			anmn[s][i].a_diffp[btur]		= -anmn[r][i].a_diffp[btul];
			anmn[s][i].a_diffp[bn]			= -anmn[r][i].a_diffp[bn];
			anmn[s][i].a_diffp[bsl]			= -anmn[r][i].a_diffp[bsr];
			anmn[s][i].a_diffp[baul]		= -anmn[r][i].a_diffp[baur];
			anmn[s][i].a_diffp[ball]		= -anmn[r][i].a_diffp[balr];
			anmn[s][i].a_diffp[bsr]			= -anmn[r][i].a_diffp[bsl];
			anmn[s][i].a_diffp[baur]		= -anmn[r][i].a_diffp[baul];
			anmn[s][i].a_diffp[balr]		= -anmn[r][i].a_diffp[ball];
			anmn[s][i].a_diffp[bhl]			= -anmn[r][i].a_diffp[bhr];
			anmn[s][i].a_diffp[blul]		= -anmn[r][i].a_diffp[blur];
			anmn[s][i].a_diffp[blll]		= -anmn[r][i].a_diffp[bllr];
			anmn[s][i].a_diffp[bfl]			= -anmn[r][i].a_diffp[bfr];
			anmn[s][i].a_diffp[bhr]			= -anmn[r][i].a_diffp[bhl];
			anmn[s][i].a_diffp[blur]		= -anmn[r][i].a_diffp[blul];
			anmn[s][i].a_diffp[bllr]		= -anmn[r][i].a_diffp[blll];
			anmn[s][i].a_diffp[bfr]			= -anmn[r][i].a_diffp[bfl];

			anmn[s][i].a_diffn[btll]		= -anmn[r][i].a_diffn[btlr];
			anmn[s][i].a_diffn[btlr]		= -anmn[r][i].a_diffn[btll];
			anmn[s][i].a_diffn[btul]		= -anmn[r][i].a_diffn[btur];
			anmn[s][i].a_diffn[btur]		= -anmn[r][i].a_diffn[btul];
			anmn[s][i].a_diffn[bn]			= -anmn[r][i].a_diffn[bn];
			anmn[s][i].a_diffn[bsl]			= -anmn[r][i].a_diffn[bsr];
			anmn[s][i].a_diffn[baul]		= -anmn[r][i].a_diffn[baur];
			anmn[s][i].a_diffn[ball]		= -anmn[r][i].a_diffn[balr];
			anmn[s][i].a_diffn[bsr]			= -anmn[r][i].a_diffn[bsl];
			anmn[s][i].a_diffn[baur]		= -anmn[r][i].a_diffn[baul];
			anmn[s][i].a_diffn[balr]		= -anmn[r][i].a_diffn[ball];
			anmn[s][i].a_diffn[bhl]			= -anmn[r][i].a_diffn[bhr];
			anmn[s][i].a_diffn[blul]		= -anmn[r][i].a_diffn[blur];
			anmn[s][i].a_diffn[blll]		= -anmn[r][i].a_diffn[bllr];
			anmn[s][i].a_diffn[bfl]			= -anmn[r][i].a_diffn[bfr];
			anmn[s][i].a_diffn[bhr]			= -anmn[r][i].a_diffn[bhl];
			anmn[s][i].a_diffn[blur]		= -anmn[r][i].a_diffn[blul];
			anmn[s][i].a_diffn[bllr]		= -anmn[r][i].a_diffn[blll];
			anmn[s][i].a_diffn[bfr]			= -anmn[r][i].a_diffn[bfl];

			anmn[s][i].l_diffp[btll]		= anmn[r][i].l_diffp[btlr];
			anmn[s][i].l_diffp[btlr]		= anmn[r][i].l_diffp[btll];
			anmn[s][i].l_diffp[btul]		= anmn[r][i].l_diffp[btur];
			anmn[s][i].l_diffp[btur]		= anmn[r][i].l_diffp[btul];
			anmn[s][i].l_diffp[bn]			= anmn[r][i].l_diffp[bn];
			anmn[s][i].l_diffp[bsl]			= anmn[r][i].l_diffp[bsr];
			anmn[s][i].l_diffp[baul]		= anmn[r][i].l_diffp[baur];
			anmn[s][i].l_diffp[ball]		= anmn[r][i].l_diffp[balr];
			anmn[s][i].l_diffp[bsr]			= anmn[r][i].l_diffp[bsl];
			anmn[s][i].l_diffp[baur]		= anmn[r][i].l_diffp[baul];
			anmn[s][i].l_diffp[balr]		= anmn[r][i].l_diffp[ball];
			anmn[s][i].l_diffp[bhl]			= anmn[r][i].l_diffp[bhr];
			anmn[s][i].l_diffp[blul]		= anmn[r][i].l_diffp[blur];
			anmn[s][i].l_diffp[blll]		= anmn[r][i].l_diffp[bllr];
			anmn[s][i].l_diffp[bfl]			= anmn[r][i].l_diffp[bfr];
			anmn[s][i].l_diffp[bhr]			= anmn[r][i].l_diffp[bhl];
			anmn[s][i].l_diffp[blur]		= anmn[r][i].l_diffp[blul];
			anmn[s][i].l_diffp[bllr]		= anmn[r][i].l_diffp[blll];
			anmn[s][i].l_diffp[bfr]			= anmn[r][i].l_diffp[bfl];

			anmn[s][i].l_diffn[btll]		= anmn[r][i].l_diffn[btlr];
			anmn[s][i].l_diffn[btlr]		= anmn[r][i].l_diffn[btll];
			anmn[s][i].l_diffn[btul]		= anmn[r][i].l_diffn[btur];
			anmn[s][i].l_diffn[btur]		= anmn[r][i].l_diffn[btul];
			anmn[s][i].l_diffn[bn]			= anmn[r][i].l_diffn[bn];
			anmn[s][i].l_diffn[bsl]			= anmn[r][i].l_diffn[bsr];
			anmn[s][i].l_diffn[baul]		= anmn[r][i].l_diffn[baur];
			anmn[s][i].l_diffn[ball]		= anmn[r][i].l_diffn[balr];
			anmn[s][i].l_diffn[bsr]			= anmn[r][i].l_diffn[bsl];
			anmn[s][i].l_diffn[baur]		= anmn[r][i].l_diffn[baul];
			anmn[s][i].l_diffn[balr]		= anmn[r][i].l_diffn[ball];
			anmn[s][i].l_diffn[bhl]			= anmn[r][i].l_diffn[bhr];
			anmn[s][i].l_diffn[blul]		= anmn[r][i].l_diffn[blur];
			anmn[s][i].l_diffn[blll]		= anmn[r][i].l_diffn[bllr];
			anmn[s][i].l_diffn[bfl]			= anmn[r][i].l_diffn[bfr];
			anmn[s][i].l_diffn[bhr]			= anmn[r][i].l_diffn[bhl];
			anmn[s][i].l_diffn[blur]		= anmn[r][i].l_diffn[blul];
			anmn[s][i].l_diffn[bllr]		= anmn[r][i].l_diffn[blll];
			anmn[s][i].l_diffn[bfr]			= anmn[r][i].l_diffn[bfl];

			anmn[s][i].w_diffp[btll]		= anmn[r][i].w_diffp[btlr];
			anmn[s][i].w_diffp[btlr]		= anmn[r][i].w_diffp[btll];
			anmn[s][i].w_diffp[btul]		= anmn[r][i].w_diffp[btur];
			anmn[s][i].w_diffp[btur]		= anmn[r][i].w_diffp[btul];
			anmn[s][i].w_diffp[bn]			= anmn[r][i].w_diffp[bn];
			anmn[s][i].w_diffp[bsl]			= anmn[r][i].w_diffp[bsr];
			anmn[s][i].w_diffp[baul]		= anmn[r][i].w_diffp[baur];
			anmn[s][i].w_diffp[ball]		= anmn[r][i].w_diffp[balr];
			anmn[s][i].w_diffp[bsr]			= anmn[r][i].w_diffp[bsl];
			anmn[s][i].w_diffp[baur]		= anmn[r][i].w_diffp[baul];
			anmn[s][i].w_diffp[balr]		= anmn[r][i].w_diffp[ball];
			anmn[s][i].w_diffp[bhl]			= anmn[r][i].w_diffp[bhr];
			anmn[s][i].w_diffp[blul]		= anmn[r][i].w_diffp[blur];
			anmn[s][i].w_diffp[blll]		= anmn[r][i].w_diffp[bllr];
			anmn[s][i].w_diffp[bfl]			= anmn[r][i].w_diffp[bfr];
			anmn[s][i].w_diffp[bhr]			= anmn[r][i].w_diffp[bhl];
			anmn[s][i].w_diffp[blur]		= anmn[r][i].w_diffp[blul];
			anmn[s][i].w_diffp[bllr]		= anmn[r][i].w_diffp[blll];
			anmn[s][i].w_diffp[bfr]			= anmn[r][i].w_diffp[bfl];

			anmn[s][i].w_diffn[btll]		= anmn[r][i].w_diffn[btlr];
			anmn[s][i].w_diffn[btlr]		= anmn[r][i].w_diffn[btll];
			anmn[s][i].w_diffn[btul]		= anmn[r][i].w_diffn[btur];
			anmn[s][i].w_diffn[btur]		= anmn[r][i].w_diffn[btul];
			anmn[s][i].w_diffn[bn]			= anmn[r][i].w_diffn[bn];
			anmn[s][i].w_diffn[bsl]			= anmn[r][i].w_diffn[bsr];
			anmn[s][i].w_diffn[baul]		= anmn[r][i].w_diffn[baur];
			anmn[s][i].w_diffn[ball]		= anmn[r][i].w_diffn[balr];
			anmn[s][i].w_diffn[bsr]			= anmn[r][i].w_diffn[bsl];
			anmn[s][i].w_diffn[baur]		= anmn[r][i].w_diffn[baul];
			anmn[s][i].w_diffn[balr]		= anmn[r][i].w_diffn[ball];
			anmn[s][i].w_diffn[bhl]			= anmn[r][i].w_diffn[bhr];
			anmn[s][i].w_diffn[blul]		= anmn[r][i].w_diffn[blur];
			anmn[s][i].w_diffn[blll]		= anmn[r][i].w_diffn[bllr];
			anmn[s][i].w_diffn[bfl]			= anmn[r][i].w_diffn[bfr];
			anmn[s][i].w_diffn[bhr]			= anmn[r][i].w_diffn[bhl];
			anmn[s][i].w_diffn[blur]		= anmn[r][i].w_diffn[blul];
			anmn[s][i].w_diffn[bllr]		= anmn[r][i].w_diffn[blll];
			anmn[s][i].w_diffn[bfr]			= anmn[r][i].w_diffn[bfl];

			//hara.x diff (y stays absolute)
			anmn[s][i].h_diffp.x			= -anmn[r][i].h_diffp.x;
			anmn[s][i].h_diffn.x			= -anmn[r][i].h_diffn.x;

			//---- keyframe data ---------------------------------------------------------------------

			//for every keyframe
			for (register int k = 0; k < anmn[s][i].nokf; ++k)
			{
				//t_frame
				anmn[s][i].pkf[k].t_frame[btll]		= anmn[r][i].pkf[k].t_frame[btlr];
				anmn[s][i].pkf[k].t_frame[btlr]		= anmn[r][i].pkf[k].t_frame[btll];
				anmn[s][i].pkf[k].t_frame[btul]		= anmn[r][i].pkf[k].t_frame[btur];
				anmn[s][i].pkf[k].t_frame[btur]		= anmn[r][i].pkf[k].t_frame[btul];
				anmn[s][i].pkf[k].t_frame[bn]		= anmn[r][i].pkf[k].t_frame[bn];
				anmn[s][i].pkf[k].t_frame[bsl]		= anmn[r][i].pkf[k].t_frame[bsr];
				anmn[s][i].pkf[k].t_frame[baul]		= anmn[r][i].pkf[k].t_frame[baur];
				anmn[s][i].pkf[k].t_frame[ball]		= anmn[r][i].pkf[k].t_frame[balr];
				anmn[s][i].pkf[k].t_frame[bsr]		= anmn[r][i].pkf[k].t_frame[bsl];
				anmn[s][i].pkf[k].t_frame[baur]		= anmn[r][i].pkf[k].t_frame[baul];
				anmn[s][i].pkf[k].t_frame[balr]		= anmn[r][i].pkf[k].t_frame[ball];
				anmn[s][i].pkf[k].t_frame[bhl]		= anmn[r][i].pkf[k].t_frame[bhr];
				anmn[s][i].pkf[k].t_frame[blul]		= anmn[r][i].pkf[k].t_frame[blur];
				anmn[s][i].pkf[k].t_frame[blll]		= anmn[r][i].pkf[k].t_frame[bllr];
				anmn[s][i].pkf[k].t_frame[bfl]		= anmn[r][i].pkf[k].t_frame[bfr];
				anmn[s][i].pkf[k].t_frame[bhr]		= anmn[r][i].pkf[k].t_frame[bhl];
				anmn[s][i].pkf[k].t_frame[blur]		= anmn[r][i].pkf[k].t_frame[blul];
				anmn[s][i].pkf[k].t_frame[bllr]		= anmn[r][i].pkf[k].t_frame[blll];
				anmn[s][i].pkf[k].t_frame[bfr]		= anmn[r][i].pkf[k].t_frame[bfl];

				//hara.x (y stays absolute)
				anmn[s][i].pkf[k].hara.x			= -anmn[r][i].pkf[k].hara.x;

				//angle, length, width, mode_a
				//angle depending on mode_a
				//absolute
				if (anmn[r][i].pkf[k].mode_a[btlr] == 0)	anmn[s][i].pkf[k].angle[btll]	= 180 - anmn[r][i].pkf[k].angle[btlr];
				if (anmn[r][i].pkf[k].mode_a[btll] == 0)	anmn[s][i].pkf[k].angle[btlr]	= 180 - anmn[r][i].pkf[k].angle[btll];
				if (anmn[r][i].pkf[k].mode_a[btur] == 0)	anmn[s][i].pkf[k].angle[btul]	= 180 - anmn[r][i].pkf[k].angle[btur];
				if (anmn[r][i].pkf[k].mode_a[btul] == 0)	anmn[s][i].pkf[k].angle[btur]	= 180 - anmn[r][i].pkf[k].angle[btul];
				if (anmn[r][i].pkf[k].mode_a[bn] == 0)		anmn[s][i].pkf[k].angle[bn]		= 180 - anmn[r][i].pkf[k].angle[bn];
				if (anmn[r][i].pkf[k].mode_a[bsr] == 0)		anmn[s][i].pkf[k].angle[bsl]	= 180 - anmn[r][i].pkf[k].angle[bsr];
				if (anmn[r][i].pkf[k].mode_a[baur] == 0)	anmn[s][i].pkf[k].angle[baul]	= 180 - anmn[r][i].pkf[k].angle[baur];
				if (anmn[r][i].pkf[k].mode_a[balr] == 0)	anmn[s][i].pkf[k].angle[ball]	= 180 - anmn[r][i].pkf[k].angle[balr];
				if (anmn[r][i].pkf[k].mode_a[bsl] == 0)		anmn[s][i].pkf[k].angle[bsr]	= 180 - anmn[r][i].pkf[k].angle[bsl];
				if (anmn[r][i].pkf[k].mode_a[baul] == 0)	anmn[s][i].pkf[k].angle[baur]	= 180 - anmn[r][i].pkf[k].angle[baul];
				if (anmn[r][i].pkf[k].mode_a[ball] == 0)	anmn[s][i].pkf[k].angle[balr]	= 180 - anmn[r][i].pkf[k].angle[ball];
				if (anmn[r][i].pkf[k].mode_a[bhr] == 0)		anmn[s][i].pkf[k].angle[bhl]	= 180 - anmn[r][i].pkf[k].angle[bhr];
				if (anmn[r][i].pkf[k].mode_a[blur] == 0)	anmn[s][i].pkf[k].angle[blul]	= 180 - anmn[r][i].pkf[k].angle[blur];
				if (anmn[r][i].pkf[k].mode_a[bllr] == 0)	anmn[s][i].pkf[k].angle[blll]	= 180 - anmn[r][i].pkf[k].angle[bllr];
				if (anmn[r][i].pkf[k].mode_a[bfr] == 0)		anmn[s][i].pkf[k].angle[bfl]	= 180 - anmn[r][i].pkf[k].angle[bfr];
				if (anmn[r][i].pkf[k].mode_a[bhl] == 0)		anmn[s][i].pkf[k].angle[bhr]	= 180 - anmn[r][i].pkf[k].angle[bhl];
				if (anmn[r][i].pkf[k].mode_a[blul] == 0)	anmn[s][i].pkf[k].angle[blur]	= 180 - anmn[r][i].pkf[k].angle[blul];
				if (anmn[r][i].pkf[k].mode_a[blll] == 0)	anmn[s][i].pkf[k].angle[bllr]	= 180 - anmn[r][i].pkf[k].angle[blll];
				if (anmn[r][i].pkf[k].mode_a[bfl] == 0)		anmn[s][i].pkf[k].angle[bfr]	= 180 - anmn[r][i].pkf[k].angle[bfl];

				//relative to parent bone angle
				if (anmn[r][i].pkf[k].mode_a[btlr] == 1)	anmn[s][i].pkf[k].angle[btll]	= 360 - anmn[r][i].pkf[k].angle[btlr];
				if (anmn[r][i].pkf[k].mode_a[btll] == 1)	anmn[s][i].pkf[k].angle[btlr]	= 360 - anmn[r][i].pkf[k].angle[btll];
				if (anmn[r][i].pkf[k].mode_a[btur] == 1)	anmn[s][i].pkf[k].angle[btul]	= 360 - anmn[r][i].pkf[k].angle[btur];
				if (anmn[r][i].pkf[k].mode_a[btul] == 1)	anmn[s][i].pkf[k].angle[btur]	= 360 - anmn[r][i].pkf[k].angle[btul];
				if (anmn[r][i].pkf[k].mode_a[bn] == 1)		anmn[s][i].pkf[k].angle[bn]		= 360 - anmn[r][i].pkf[k].angle[bn];
				if (anmn[r][i].pkf[k].mode_a[bsr] == 1)		anmn[s][i].pkf[k].angle[bsl]	= 360 - anmn[r][i].pkf[k].angle[bsr];
				if (anmn[r][i].pkf[k].mode_a[baur] == 1)	anmn[s][i].pkf[k].angle[baul]	= 360 - anmn[r][i].pkf[k].angle[baur];
				if (anmn[r][i].pkf[k].mode_a[balr] == 1)	anmn[s][i].pkf[k].angle[ball]	= 360 - anmn[r][i].pkf[k].angle[balr];
				if (anmn[r][i].pkf[k].mode_a[bsl] == 1)		anmn[s][i].pkf[k].angle[bsr]	= 360 - anmn[r][i].pkf[k].angle[bsl];
				if (anmn[r][i].pkf[k].mode_a[baul] == 1)	anmn[s][i].pkf[k].angle[baur]	= 360 - anmn[r][i].pkf[k].angle[baul];
				if (anmn[r][i].pkf[k].mode_a[ball] == 1)	anmn[s][i].pkf[k].angle[balr]	= 360 - anmn[r][i].pkf[k].angle[ball];
				if (anmn[r][i].pkf[k].mode_a[bhr] == 1)		anmn[s][i].pkf[k].angle[bhl]	= 360 - anmn[r][i].pkf[k].angle[bhr];
				if (anmn[r][i].pkf[k].mode_a[blur] == 1)	anmn[s][i].pkf[k].angle[blul]	= 360 - anmn[r][i].pkf[k].angle[blur];
				if (anmn[r][i].pkf[k].mode_a[bllr] == 1)	anmn[s][i].pkf[k].angle[blll]	= 360 - anmn[r][i].pkf[k].angle[bllr];
				if (anmn[r][i].pkf[k].mode_a[bfr] == 1)		anmn[s][i].pkf[k].angle[bfl]	= 360 - anmn[r][i].pkf[k].angle[bfr];
				if (anmn[r][i].pkf[k].mode_a[bhl] == 1)		anmn[s][i].pkf[k].angle[bhr]	= 360 - anmn[r][i].pkf[k].angle[bhl];
				if (anmn[r][i].pkf[k].mode_a[blul] == 1)	anmn[s][i].pkf[k].angle[blur]	= 360 - anmn[r][i].pkf[k].angle[blul];
				if (anmn[r][i].pkf[k].mode_a[blll] == 1)	anmn[s][i].pkf[k].angle[bllr]	= 360 - anmn[r][i].pkf[k].angle[blll];
				if (anmn[r][i].pkf[k].mode_a[bfl] == 1)		anmn[s][i].pkf[k].angle[bfr]	= 360 - anmn[r][i].pkf[k].angle[bfl];

				//relative to current position
				if (anmn[r][i].pkf[k].mode_a[btlr] == 2)	anmn[s][i].pkf[k].angle[btll]	= 360 - anmn[r][i].pkf[k].angle[btlr];
				if (anmn[r][i].pkf[k].mode_a[btll] == 2)	anmn[s][i].pkf[k].angle[btlr]	= 360 - anmn[r][i].pkf[k].angle[btll];
				if (anmn[r][i].pkf[k].mode_a[btur] == 2)	anmn[s][i].pkf[k].angle[btul]	= 360 - anmn[r][i].pkf[k].angle[btur];
				if (anmn[r][i].pkf[k].mode_a[btul] == 2)	anmn[s][i].pkf[k].angle[btur]	= 360 - anmn[r][i].pkf[k].angle[btul];
				if (anmn[r][i].pkf[k].mode_a[bn] == 2)		anmn[s][i].pkf[k].angle[bn]		= 360 - anmn[r][i].pkf[k].angle[bn];
				if (anmn[r][i].pkf[k].mode_a[bsr] == 2)		anmn[s][i].pkf[k].angle[bsl]	= 360 - anmn[r][i].pkf[k].angle[bsr];
				if (anmn[r][i].pkf[k].mode_a[baur] == 2)	anmn[s][i].pkf[k].angle[baul]	= 360 - anmn[r][i].pkf[k].angle[baur];
				if (anmn[r][i].pkf[k].mode_a[balr] == 2)	anmn[s][i].pkf[k].angle[ball]	= 360 - anmn[r][i].pkf[k].angle[balr];
				if (anmn[r][i].pkf[k].mode_a[bsl] == 2)		anmn[s][i].pkf[k].angle[bsr]	= 360 - anmn[r][i].pkf[k].angle[bsl];
				if (anmn[r][i].pkf[k].mode_a[baul] == 2)	anmn[s][i].pkf[k].angle[baur]	= 360 - anmn[r][i].pkf[k].angle[baul];
				if (anmn[r][i].pkf[k].mode_a[ball] == 2)	anmn[s][i].pkf[k].angle[balr]	= 360 - anmn[r][i].pkf[k].angle[ball];
				if (anmn[r][i].pkf[k].mode_a[bhr] == 2)		anmn[s][i].pkf[k].angle[bhl]	= 360 - anmn[r][i].pkf[k].angle[bhr];
				if (anmn[r][i].pkf[k].mode_a[blur] == 2)	anmn[s][i].pkf[k].angle[blul]	= 360 - anmn[r][i].pkf[k].angle[blur];
				if (anmn[r][i].pkf[k].mode_a[bllr] == 2)	anmn[s][i].pkf[k].angle[blll]	= 360 - anmn[r][i].pkf[k].angle[bllr];
				if (anmn[r][i].pkf[k].mode_a[bfr] == 2)		anmn[s][i].pkf[k].angle[bfl]	= 360 - anmn[r][i].pkf[k].angle[bfr];
				if (anmn[r][i].pkf[k].mode_a[bhl] == 2)		anmn[s][i].pkf[k].angle[bhr]	= 360 - anmn[r][i].pkf[k].angle[bhl];
				if (anmn[r][i].pkf[k].mode_a[blul] == 2)	anmn[s][i].pkf[k].angle[blur]	= 360 - anmn[r][i].pkf[k].angle[blul];
				if (anmn[r][i].pkf[k].mode_a[blll] == 2)	anmn[s][i].pkf[k].angle[bllr]	= 360 - anmn[r][i].pkf[k].angle[blll];
				if (anmn[r][i].pkf[k].mode_a[bfl] == 2)		anmn[s][i].pkf[k].angle[bfr]	= 360 - anmn[r][i].pkf[k].angle[bfl];

				//check angle doesn't exceed its limit
				for (register int a = 0; a < 19; ++a)
				{
					if (anmn[s][i].pkf[k].angle[a] > 359)	anmn[s][i].pkf[k].angle[a] -= 360;
					if (anmn[s][i].pkf[k].angle[a] < 0)		anmn[s][i].pkf[k].angle[a] += 360;
				}

				anmn[s][i].pkf[k].length[btll]		= anmn[r][i].pkf[k].length[btlr];
				anmn[s][i].pkf[k].length[btlr]		= anmn[r][i].pkf[k].length[btll];
				anmn[s][i].pkf[k].length[btul]		= anmn[r][i].pkf[k].length[btur];
				anmn[s][i].pkf[k].length[btur]		= anmn[r][i].pkf[k].length[btul];
				anmn[s][i].pkf[k].length[bn]		= anmn[r][i].pkf[k].length[bn];
				anmn[s][i].pkf[k].length[bsl]		= anmn[r][i].pkf[k].length[bsr];
				anmn[s][i].pkf[k].length[baul]		= anmn[r][i].pkf[k].length[baur];
				anmn[s][i].pkf[k].length[ball]		= anmn[r][i].pkf[k].length[balr];
				anmn[s][i].pkf[k].length[bsr]		= anmn[r][i].pkf[k].length[bsl];
				anmn[s][i].pkf[k].length[baur]		= anmn[r][i].pkf[k].length[baul];
				anmn[s][i].pkf[k].length[balr]		= anmn[r][i].pkf[k].length[ball];
				anmn[s][i].pkf[k].length[bhl]		= anmn[r][i].pkf[k].length[bhr];
				anmn[s][i].pkf[k].length[blul]		= anmn[r][i].pkf[k].length[blur];
				anmn[s][i].pkf[k].length[blll]		= anmn[r][i].pkf[k].length[bllr];
				anmn[s][i].pkf[k].length[bfl]		= anmn[r][i].pkf[k].length[bfr];
				anmn[s][i].pkf[k].length[bhr]		= anmn[r][i].pkf[k].length[bhl];
				anmn[s][i].pkf[k].length[blur]		= anmn[r][i].pkf[k].length[blul];
				anmn[s][i].pkf[k].length[bllr]		= anmn[r][i].pkf[k].length[blll];
				anmn[s][i].pkf[k].length[bfr]		= anmn[r][i].pkf[k].length[bfl];

				anmn[s][i].pkf[k].width[btll]		= anmn[r][i].pkf[k].width[btlr];
				anmn[s][i].pkf[k].width[btlr]		= anmn[r][i].pkf[k].width[btll];
				anmn[s][i].pkf[k].width[btul]		= anmn[r][i].pkf[k].width[btur];
				anmn[s][i].pkf[k].width[btur]		= anmn[r][i].pkf[k].width[btul];
				anmn[s][i].pkf[k].width[bn]			= anmn[r][i].pkf[k].width[bn];
				anmn[s][i].pkf[k].width[bsl]		= anmn[r][i].pkf[k].width[bsr];
				anmn[s][i].pkf[k].width[baul]		= anmn[r][i].pkf[k].width[baur];
				anmn[s][i].pkf[k].width[ball]		= anmn[r][i].pkf[k].width[balr];
				anmn[s][i].pkf[k].width[bsr]		= anmn[r][i].pkf[k].width[bsl];
				anmn[s][i].pkf[k].width[baur]		= anmn[r][i].pkf[k].width[baul];
				anmn[s][i].pkf[k].width[balr]		= anmn[r][i].pkf[k].width[ball];
				anmn[s][i].pkf[k].width[bhl]		= anmn[r][i].pkf[k].width[bhr];
				anmn[s][i].pkf[k].width[blul]		= anmn[r][i].pkf[k].width[blur];
				anmn[s][i].pkf[k].width[blll]		= anmn[r][i].pkf[k].width[bllr];
				anmn[s][i].pkf[k].width[bfl]		= anmn[r][i].pkf[k].width[bfr];
				anmn[s][i].pkf[k].width[bhr]		= anmn[r][i].pkf[k].width[bhl];
				anmn[s][i].pkf[k].width[blur]		= anmn[r][i].pkf[k].width[blul];
				anmn[s][i].pkf[k].width[bllr]		= anmn[r][i].pkf[k].width[blll];
				anmn[s][i].pkf[k].width[bfr]		= anmn[r][i].pkf[k].width[bfl];

				anmn[s][i].pkf[k].mode_a[btll]		= anmn[r][i].pkf[k].mode_a[btlr];
				anmn[s][i].pkf[k].mode_a[btlr]		= anmn[r][i].pkf[k].mode_a[btll];
				anmn[s][i].pkf[k].mode_a[btul]		= anmn[r][i].pkf[k].mode_a[btur];
				anmn[s][i].pkf[k].mode_a[btur]		= anmn[r][i].pkf[k].mode_a[btul];
				anmn[s][i].pkf[k].mode_a[bn]		= anmn[r][i].pkf[k].mode_a[bn];
				anmn[s][i].pkf[k].mode_a[bsl]		= anmn[r][i].pkf[k].mode_a[bsr];
				anmn[s][i].pkf[k].mode_a[baul]		= anmn[r][i].pkf[k].mode_a[baur];
				anmn[s][i].pkf[k].mode_a[ball]		= anmn[r][i].pkf[k].mode_a[balr];
				anmn[s][i].pkf[k].mode_a[bsr]		= anmn[r][i].pkf[k].mode_a[bsl];
				anmn[s][i].pkf[k].mode_a[baur]		= anmn[r][i].pkf[k].mode_a[baul];
				anmn[s][i].pkf[k].mode_a[balr]		= anmn[r][i].pkf[k].mode_a[ball];
				anmn[s][i].pkf[k].mode_a[bhl]		= anmn[r][i].pkf[k].mode_a[bhr];
				anmn[s][i].pkf[k].mode_a[blul]		= anmn[r][i].pkf[k].mode_a[blur];
				anmn[s][i].pkf[k].mode_a[blll]		= anmn[r][i].pkf[k].mode_a[bllr];
				anmn[s][i].pkf[k].mode_a[bfl]		= anmn[r][i].pkf[k].mode_a[bfr];
				anmn[s][i].pkf[k].mode_a[bhr]		= anmn[r][i].pkf[k].mode_a[bhl];
				anmn[s][i].pkf[k].mode_a[blur]		= anmn[r][i].pkf[k].mode_a[blul];
				anmn[s][i].pkf[k].mode_a[bllr]		= anmn[r][i].pkf[k].mode_a[blll];
				anmn[s][i].pkf[k].mode_a[bfr]		= anmn[r][i].pkf[k].mode_a[bfl];

				//action:
				//0 = no action
				//1 = left fist
				//2 = right fist
				//3 = left foot
				//4 = right foot
				//5 = left knee
				//6 = right knee
				if (anmn[r][i].pkf[k].action == 0)		anmn[s][i].pkf[k].action = 0;
				if (anmn[r][i].pkf[k].action == 1)		anmn[s][i].pkf[k].action = 2;
				if (anmn[r][i].pkf[k].action == 2)		anmn[s][i].pkf[k].action = 1;
				if (anmn[r][i].pkf[k].action == 3)		anmn[s][i].pkf[k].action = 4;
				if (anmn[r][i].pkf[k].action == 4)		anmn[s][i].pkf[k].action = 3;
				if (anmn[r][i].pkf[k].action == 5)		anmn[s][i].pkf[k].action = 6;
				if (anmn[r][i].pkf[k].action == 6)		anmn[s][i].pkf[k].action = 5;

				//type and dir stay the same for every keyframe
			}

			//!!
			//save animation
			//anmn[s][i].save_animation(panmnfile[s][i], CAV, 0);
		}
	}

	//---- calculate default angles --------------------------------------------------------------

	//for all sides and stances
	for (s = 0; s < 4; ++s)
		//for all animations
		for (register int i = 0; i < NPAN; ++i)
		{
			//needs parent bone index, pbi depending on stance
			if (s == 0 || s == 2)
				anmn[s][i].calculate_default_angles(-1, -1, btll, btlr, btul,
													btul, bsl, baul, btur, bsr, baur,
													btll, bhl, blul, blll,
													btlr, bhr, blur, bllr);
			else
				anmn[s][i].calculate_default_angles(-1, -1, btll, btlr, btur,
													btul, bsl, baul, btur, bsr, baur,
													btll, bhl, blul, blll,
													btlr, bhr, blur, bllr);

			//assign animation id (defined animation index number)
			anmn[s][i].id		= i;
		}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame set_animation_gl_data
//
//	sets additional game logic data in animations
//
//------------------------------------------------------------------------------------------------

void master_frame::set_animation_gl_data()
{
	/*	cds_nohit			0
		cds_hit				1
		cds_def				2
		cds_hitret			3
		cds_defpart			4
		cds_defpart_b		5
		cds_defpart_e		6*/

	//hold different states and values
	float dam_speed[19] = {0};
	float dam_off[19]	= {0};
	float cd_def[19]	= {0};
	float cd_off[19]	= {0};

	//---- general -------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_HIT, 0, 0, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_IDLE_HI, 0, 50, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	//set idle defense here since only action slot is considered
	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_IDLE_LO, 0, 50, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	//!!
	anmn[0][AN_STANCE_FEET].gl_fatigue = 10;
	anmn[1][AN_STANCE_FEET].gl_fatigue = 10;
	anmn[2][AN_STANCE_FEET].gl_fatigue = 10;
	anmn[3][AN_STANCE_FEET].gl_fatigue = 10;
	anmn[0][AN_STANCE_FEET].gl_fatigue_cancel = 7;
	anmn[1][AN_STANCE_FEET].gl_fatigue_cancel = 7;
	anmn[2][AN_STANCE_FEET].gl_fatigue_cancel = 7;
	anmn[3][AN_STANCE_FEET].gl_fatigue_cancel = 7;

	//---- walking -------------------------------------------------------------------------------

	fill_farray_19(dam_speed, 5.0f, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  0, 0, 3.5f, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_WALK_FWD, 0, 30, 5, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed, 0, 5.0f, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 3.5f, 0);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_WALK_BWD, 0, 60, 5, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed, 5.0f, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  0, 0, 3.5f, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_WALK_SLIDE_FWD, 0, 20, 6, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed, 0, 5.0f, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 3.5f, 0);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_WALK_SLIDE_BWD, 0, 60, 6, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	//---- offense punches -----------------------------------------------------------------------

	//which bones damage affect speed of animation
	fill_farray_19(dam_speed, 0, 0, 5, 0, 0,
							  2, 0, 0,
							  0, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 0, 0);
	//which bones damage affect offensive damage of animation
	//if defense animation which bones affect defense efficiency
	fill_farray_19(dam_off, 0, 0, 5, 0, 0,
							2, 0, 0,
							0, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	//defense cd state of bones
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	//offense cd state of bones
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	//animation, damage done, defend defpart value, fatigue, cancel fatigue,
	//fatigue affecting speed, fatigue affecting offensive/defense efficiency
	set_agl_data(AN_JAB, 10, 50, 5, 3,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	fill_farray_19(dam_speed, 0, 0, 5, 0, 0,
							  2, 0, 0,
							  0, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 0, 0, 5, 0, 0,
							2, 0, 0,
							0, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_JAB_HOOK, 20, 50, 10, 6,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	fill_farray_19(dam_speed, 0, 0, 0, 5, 0,
							  0, 0, 0,
							  2, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 0, 0, 0, 5, 0,
							0, 0, 0,
							2, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_CROSS, 20, 50, 10, 6,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	fill_farray_19(dam_speed, 0, 0, 0, 5, 0,
							  0, 0, 0,
							  2, 0, 0,
							  0, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 0, 0, 0, 5, 0,
							0, 0, 0,
							2, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_CROSS_HOOK, 30, 50, 14, 7,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	//---- offense kicks -------------------------------------------------------------------------

	fill_farray_19(dam_speed, 3, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  2, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 3, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							2, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_KICK_FWD, 20, 50, 10, 8,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	//knee can hit rear leg
	fill_farray_19(dam_speed, 3, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  2, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 3, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							2, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_nohit, cds_hit, cds_hit, cds_hit);
	set_agl_data(AN_KICK_KNEE, 25, 50, 15, 10,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	fill_farray_19(dam_speed, 3, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  2, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 3, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							2, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_KICK_SWD, 25, 50, 15, 10,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	fill_farray_19(dam_speed, 3, 0, 0, 0, 0,
							  0, 0, 0,
							  0, 0, 0,
							  2, 0, 0, 0,
							  0, 0, 0, 0);
	fill_farray_19(dam_off, 3, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							2, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off,
				   cds_hit, cds_nohit, cds_hit, cds_nohit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_nohit, cds_nohit, cds_nohit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_nohit, cds_nohit, cds_nohit, cds_nohit);
	set_agl_data(AN_KICK_SWD_HI, 25, 50, 15, 10,
				 2, 2, dam_speed, dam_off, cd_def, cd_off, S_JAB);

	//---- defense -------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_DEFEND, 0, 0, 50, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	//---- evading -------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_EVADE_HI, 0, 50, 7, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_EVADE_LO, 0, 50, 7, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_DUCK, 0, 50, 7, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_EVADE_HI_HOLD, 0, 50, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_EVADE_LO_HOLD, 0, 30, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_DUCK_HOLD, 0, 50, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off);

	//---- tapping -------------------------------------------------------------------------------

/*	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							5, 0, 0,
							0, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_TAP_JAB, 0, 50, 6, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAP);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							0, 0, 0,
							5, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_TAP_CROSS, 0, 50, 6, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAP);*/

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							0, 0, 0,
							5, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_defpart, cds_defpart,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_TAP_ARMS, 0, 50, 6, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAP);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							5, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_def, cds_def, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	//80
	set_agl_data(AN_TAP_LEG, 0, 80, 8, 6,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAP);

	//---- guards --------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							5, 0, 0,
							0, 0, 0,
							0, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	//fatigue in units per second
	set_agl_data(AN_GUARD_ARMS, 0, 50, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							5, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_def, cds_def, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_GUARD_LEGS, 0, 80, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off, 0, 0, 0, 0, 0,
							0, 0, 0,
							0, 0, 0,
							5, 0, 0, 0,
							0, 0, 0, 0);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_def, cds_def,
				   cds_def, cds_def, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_GUARD_FULL, 0, 65, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);

	//---- pushs and pulls -----------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_def, cds_def,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_PUSH_ARMS, 0, 50, 8, 4,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_defpart,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_PULL_ARMS, 0, 40, 14, 8,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);

	//---- stopping ------------------------------------------------------------------------------

/*	set_agl_data(AN_STOP_JAB,
				 15, 0, 15, 8,
				 0, 0, 0, 0, DS_al);
	set_agl_state(AN_STOP_JAB, 0,
				  cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				  cds_hit, cds_def,
				  cds_hit, cds_hit,
				  cds_hit, cds_hit);
	set_agl_state(AN_STOP_JAB, 1,
				  cds_nohit, cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				  cds_hitret, cds_hitret,
				  cds_nohit, cds_nohit,
				  cds_nohit, cds_nohit);

	set_agl_data(AN_STOP_CROSS,
				 15, 0, 15, 8,
				 0, 0, 0, 0, DS_al);
	set_agl_state(AN_STOP_CROSS, 0,
				  cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				  cds_hit, cds_def,
				  cds_hit, cds_hit,
				  cds_hit, cds_hit);
	set_agl_state(AN_STOP_CROSS, 1,
				  cds_nohit, cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				  cds_hitret, cds_hitret,
				  cds_nohit, cds_nohit,
				  cds_nohit, cds_nohit);

	set_agl_data(AN_STOP_KICK,
				 15, 0, 15, 8,
				 0, 0, 0, 0, DS_al);
	set_agl_state(AN_STOP_KICK, 0,
				  cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				  cds_hit, cds_def,
				  cds_hit, cds_hit,
				  cds_hit, cds_hit);
	set_agl_state(AN_STOP_KICK, 1,
				  cds_nohit, cds_nohit, cds_nohit, cds_nohit, cds_nohit,
				  cds_hitret, cds_hitret,
				  cds_nohit, cds_nohit,
				  cds_nohit, cds_nohit);*/

	//---- taunt ---------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_TAUNT1, 0, 0, 40, 40,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAUNT1);

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_TAUNT2, 0, 0, 40, 40,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, S_TAUNT2);

	//---- knockout ------------------------------------------------------------------------------

	fill_farray_19(dam_speed);
	fill_farray_19(dam_off);
	fill_farray_19(cd_def,
				   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit,
				   cds_hit, cds_hit, cds_hit, cds_hit);
	fill_farray_19(cd_off);
	set_agl_data(AN_KNOCKOUT, 0, 0, 0, 0,
				 0, 0, dam_speed, dam_off, cd_def, cd_off, -1);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame set_agl_data
//
//	helper function for set_animation_gl_data
//	fills animation object with argumented data
//	for all 4 asi
//
//------------------------------------------------------------------------------------------------

void master_frame::set_agl_data(int _anmn,
								float _damage, float _defend, float _fatigue, float _fatcancel,
								float _fat_speed, float _fat_off,
								float _dam_speed[19],
								float _dam_off[19],
								float _cd_def[19],
								float _cd_off[19],
								int _soundid)
{
	//fill all asi
	for (register int a = 0; a < 4; ++a)
	{
		//this data won't be changed for different stances
		anmn[a][_anmn].gl_damage			= (int)_damage;
		anmn[a][_anmn].gl_defend			= (int)_defend;
		anmn[a][_anmn].gl_fatigue			= (int)_fatigue;
		anmn[a][_anmn].gl_fatigue_cancel	= (int)_fatcancel;

		anmn[a][_anmn].gl_eff_fat_speed		= _fat_speed;
		anmn[a][_anmn].gl_eff_fat_off		= _fat_off;

		anmn[a][_anmn].gl_soundid			= _soundid;
	}

	//damage efficiency
	//for asi 0 and 2
	for (register int i = 0; i < 3; i += 2)
	{
		//for all bones
		for (register int b = 0; b < 19; ++b)
		{
			anmn[i][_anmn].gl_eff_dam_speed[b]	= _dam_speed[b];
			anmn[i][_anmn].gl_eff_dam_off[b]	= _dam_off[b];
		}
	}

	//asi 1 and 3
	for (i = 1; i < 4; i += 2)
	{
		anmn[i][_anmn].gl_eff_dam_speed[btll]	= _dam_speed[btlr];
		anmn[i][_anmn].gl_eff_dam_speed[btlr]	= _dam_speed[btll];
		anmn[i][_anmn].gl_eff_dam_speed[btul]	= _dam_speed[btur];
		anmn[i][_anmn].gl_eff_dam_speed[btur]	= _dam_speed[btul];
		anmn[i][_anmn].gl_eff_dam_speed[bn]		= _dam_speed[bn];
		anmn[i][_anmn].gl_eff_dam_speed[bsl]	= _dam_speed[bsr];
		anmn[i][_anmn].gl_eff_dam_speed[baul]	= _dam_speed[baur];
		anmn[i][_anmn].gl_eff_dam_speed[ball]	= _dam_speed[balr];
		anmn[i][_anmn].gl_eff_dam_speed[bsr]	= _dam_speed[bsl];
		anmn[i][_anmn].gl_eff_dam_speed[baur]	= _dam_speed[baul];
		anmn[i][_anmn].gl_eff_dam_speed[balr]	= _dam_speed[ball];
		anmn[i][_anmn].gl_eff_dam_speed[bhl]	= _dam_speed[bhr];
		anmn[i][_anmn].gl_eff_dam_speed[blul]	= _dam_speed[blur];
		anmn[i][_anmn].gl_eff_dam_speed[blll]	= _dam_speed[bllr];
		anmn[i][_anmn].gl_eff_dam_speed[bfl]	= _dam_speed[bfr];
		anmn[i][_anmn].gl_eff_dam_speed[bhr]	= _dam_speed[bhl];
		anmn[i][_anmn].gl_eff_dam_speed[blur]	= _dam_speed[blul];
		anmn[i][_anmn].gl_eff_dam_speed[bllr]	= _dam_speed[blll];
		anmn[i][_anmn].gl_eff_dam_speed[bfr]	= _dam_speed[bfl];
		anmn[i][_anmn].gl_eff_dam_off[btll]		= _dam_off[btlr];
		anmn[i][_anmn].gl_eff_dam_off[btlr]		= _dam_off[btll];
		anmn[i][_anmn].gl_eff_dam_off[btul]		= _dam_off[btur];
		anmn[i][_anmn].gl_eff_dam_off[btur]		= _dam_off[btul];
		anmn[i][_anmn].gl_eff_dam_off[bn]		= _dam_off[bn];
		anmn[i][_anmn].gl_eff_dam_off[bsl]		= _dam_off[bsr];
		anmn[i][_anmn].gl_eff_dam_off[baul]		= _dam_off[baur];
		anmn[i][_anmn].gl_eff_dam_off[ball]		= _dam_off[balr];
		anmn[i][_anmn].gl_eff_dam_off[bsr]		= _dam_off[bsl];
		anmn[i][_anmn].gl_eff_dam_off[baur]		= _dam_off[baul];
		anmn[i][_anmn].gl_eff_dam_off[balr]		= _dam_off[ball];
		anmn[i][_anmn].gl_eff_dam_off[bhl]		= _dam_off[bhr];
		anmn[i][_anmn].gl_eff_dam_off[blul]		= _dam_off[blur];
		anmn[i][_anmn].gl_eff_dam_off[blll]		= _dam_off[bllr];
		anmn[i][_anmn].gl_eff_dam_off[bfl]		= _dam_off[bfr];
		anmn[i][_anmn].gl_eff_dam_off[bhr]		= _dam_off[bhl];
		anmn[i][_anmn].gl_eff_dam_off[blur]		= _dam_off[blul];
		anmn[i][_anmn].gl_eff_dam_off[bllr]		= _dam_off[blll];
		anmn[i][_anmn].gl_eff_dam_off[bfr]		= _dam_off[bfl];
	}

	//defense state
	//for asi 0 and 2 (0 and 2 the same, 1 and 3 the same)
	for (i = 0; i < 3; i += 2)
	{
		//for all bones
		for (register int b = 0; b < 19; ++b)
			anmn[i][_anmn].gl_bcds_def[b]	= (int)_cd_def[b];
	}

	//asi 1 and 3
	for (i = 1; i < 4; i += 2)
	{
		//reverse sides
		anmn[i][_anmn].gl_bcds_def[btll]	= (int)_cd_def[btlr];
		anmn[i][_anmn].gl_bcds_def[btlr]	= (int)_cd_def[btll];
		anmn[i][_anmn].gl_bcds_def[btul]	= (int)_cd_def[btur];
		anmn[i][_anmn].gl_bcds_def[btur]	= (int)_cd_def[btul];
		anmn[i][_anmn].gl_bcds_def[bn]		= (int)_cd_def[bn];
		anmn[i][_anmn].gl_bcds_def[bsl]		= (int)_cd_def[bsr];
		anmn[i][_anmn].gl_bcds_def[baul]	= (int)_cd_def[baur];
		anmn[i][_anmn].gl_bcds_def[ball]	= (int)_cd_def[balr];
		anmn[i][_anmn].gl_bcds_def[bsr]		= (int)_cd_def[bsl];
		anmn[i][_anmn].gl_bcds_def[baur]	= (int)_cd_def[baul];
		anmn[i][_anmn].gl_bcds_def[balr]	= (int)_cd_def[ball];
		anmn[i][_anmn].gl_bcds_def[bhl]		= (int)_cd_def[bhr];
		anmn[i][_anmn].gl_bcds_def[blul]	= (int)_cd_def[blur];
		anmn[i][_anmn].gl_bcds_def[blll]	= (int)_cd_def[bllr];
		anmn[i][_anmn].gl_bcds_def[bfl]		= (int)_cd_def[bfr];
		anmn[i][_anmn].gl_bcds_def[bhr]		= (int)_cd_def[bhl];
		anmn[i][_anmn].gl_bcds_def[blur]	= (int)_cd_def[blul];
		anmn[i][_anmn].gl_bcds_def[bllr]	= (int)_cd_def[blll];
		anmn[i][_anmn].gl_bcds_def[bfr]		= (int)_cd_def[bfl];
	}

	//offense state
	//for all asi
	for (i = 0; i < 4; ++i)
	{
		//for of 0 and 2 opponent
		for (register int a = 0; a < 3; a += 2)
		{
			//for all bones
			for (register int b = 0; b < 19; ++b)
				anmn[i][_anmn].gl_bcds_off[a][b]	= (int)_cd_off[b];
		}

		//for of 1 and 3 opponent
		for (a = 1; a < 4; a += 2)
		{
			//reverse sides
			anmn[i][_anmn].gl_bcds_off[a][btll]	= (int)_cd_off[btlr];
			anmn[i][_anmn].gl_bcds_off[a][btlr]	= (int)_cd_off[btll];
			anmn[i][_anmn].gl_bcds_off[a][btul]	= (int)_cd_off[btur];
			anmn[i][_anmn].gl_bcds_off[a][btur]	= (int)_cd_off[btul];
			anmn[i][_anmn].gl_bcds_off[a][bn]	= (int)_cd_off[bn];
			anmn[i][_anmn].gl_bcds_off[a][bsl]	= (int)_cd_off[bsr];
			anmn[i][_anmn].gl_bcds_off[a][baul]	= (int)_cd_off[baur];
			anmn[i][_anmn].gl_bcds_off[a][ball]	= (int)_cd_off[balr];
			anmn[i][_anmn].gl_bcds_off[a][bsr]	= (int)_cd_off[bsl];
			anmn[i][_anmn].gl_bcds_off[a][baur]	= (int)_cd_off[baul];
			anmn[i][_anmn].gl_bcds_off[a][balr]	= (int)_cd_off[ball];
			anmn[i][_anmn].gl_bcds_off[a][bhl]	= (int)_cd_off[bhr];
			anmn[i][_anmn].gl_bcds_off[a][blul]	= (int)_cd_off[blur];
			anmn[i][_anmn].gl_bcds_off[a][blll]	= (int)_cd_off[bllr];
			anmn[i][_anmn].gl_bcds_off[a][bfl]	= (int)_cd_off[bfr];
			anmn[i][_anmn].gl_bcds_off[a][bhr]	= (int)_cd_off[bhl];
			anmn[i][_anmn].gl_bcds_off[a][blur]	= (int)_cd_off[blul];
			anmn[i][_anmn].gl_bcds_off[a][bllr]	= (int)_cd_off[blll];
			anmn[i][_anmn].gl_bcds_off[a][bfr]	= (int)_cd_off[bfl];
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame collision_detection
//
//	first checks hitboxes than does actual collision detections (subfunctions)
//
//------------------------------------------------------------------------------------------------

void master_frame::collision_detection()
{
	//reset cd-data to no collision
	ZeroMemory(&rcd.bone, sizeof(rcd.bone));
	//reset to no attacking
	for (register int i = 0; i < 6; ++i)
	{
		rcd.attack[P1][i] = -1;
		rcd.attack[P2][i] = -1;
	}
	//reset attack cancel
	ZeroMemory(&rcd.attack_cancel, sizeof(rcd.attack_cancel));
	//reset attack return
	ZeroMemory(&rcd.attack_return, sizeof(rcd.attack_return));

	//first check if whole player hitboxes collide else return
	if (!hitboxcheck(P[P1].sk.r_hbp, P[P2].sk.r_hbp))
		return;

//!!
#define	bone_in_defpart_state	(P[!p].sk.b[h].cd_state == cds_defpart || P[!p].sk.b[h].cd_state == cds_defpart_b || P[!p].sk.b[h].cd_state == cds_defpart_e)

	//for both players (p = P1/P2, !p = P2/P1)
	for (register int p = 0; p < 2; ++p)
	{
		//active type:
		//1 = left fist
		//2 = right fist
		//3 = left foot
		//4 = right foot
		//5 = left knee
		//6 = right knee

		//---- left fist -------------------------------------------------------------------------

//		for (register int a = 0; a < 4; ++a)
//			if (P[p].active_off[a] == ON)
//				cd_sub(p, a);

		//if limb active
		if (P[p].active_off[act_fistl - 1] == 1)
			//for every bone of opponent
			for (register int h = 0; h < 19; ++h)
				//if slot valid
				if (P[p].p_aslot[aslot_action] != NULL)
					//if attacker can (hit or rethit) bone and bone of opponent is either hitable or
					//in defense state or in defensepart state or
					//attacker cannot hit bone but bone is in defense state or bone is in defensepart state
					//do collision detection test
//					if (((angreifer_treffbar || angreifer_rettreffbar) && (verteidiger_treffbar || verteidiger_defense || verteidiger_defensepart)) ||
//						(angreifer_nicht_treffbar && (verteidiger_defense || verteidiger_defensepart)))
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
					/*if ((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit &&
						(P[!p].sk.b[h].cd_state == cds_hit ||
						 P[!p].sk.b[h].cd_state == cds_def)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						 P[!p].sk.b[h].cd_state == cds_def))*/
				{
					//if bone not in defpart_e or
					//bone in defpart_e and either hitable or rethitable
					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					//do hitbox check
					if (hitboxcheck(P[p].sk.b[ball].hitbox_e, P[!p].sk.b[h].hitbox))
						//if succeeds do circle to rectangle cd (fist to bone)
						if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[h].v))
						{
							//if bone in defense state
							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								//if cds_state of attacker for this bone is standard hit or no hit
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									//set attack animation to be advanced (canceled)
									//since it hit a bone in defense mode
									rcd.attack_cancel[p][act_fistl - 1]	= 1;

									//if opponents defense not locked
									if (!P[!p].gl_lock.get_lockstate(h))
										//return damage to attacker
										rcd.attack_return[p][act_fistl - 1] = 1;
								}
//								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//return damage to cause to itself since it hit a bone in defense mode
//									rcd.attack_return[p][act_fistl - 1]	= 1;

								//time stamp (for bone flash)
								rcd.time[!p][h]					= time.current;
							}

							//if bone of opponent not in defense part state
							//if bone in defpart_e state bone counts as hit
							//(if hitable, tested above)
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								//set bone to hit and limb to hitting
								rcd.bone[!p][h]					= act_fistl;
								//set attack to appropriate bone
								rcd.attack[p][act_fistl - 1]	= h;
								//time stamp
								rcd.time[!p][h]					= time.current;

								//break loop to check bones since an attack can only hit
								//once (handled in player object) and then only hit one single
								//bone (the break command here)
								break;
							}
							else
							{
								//apply boneindex of bone which is hit in cds_defpart state
								rcd.defend[p]					= h;

								//continue bone collision detection
							}
						}

					//if bone not in defpart_b or
					//bone in defpart_b and either hitable or rethitable
					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					//if limb is lower arm also test fist
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[ball].hitbox_e, P[!p].sk.b[h].hitbox_e))
						{
							//if successful do circle to circle cd (fist to fist)
							//if returned value (angle) is not -1, they collide
							//left or right fist
							if (h == ball)
								if (cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
													 P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_fistl - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_fistl - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_fistl - 1]	= 1;
										rcd.time[!p][bfistl]			= time.current;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]			= act_fistl;
										rcd.attack[p][act_fistl - 1]	= bfistl;
										rcd.time[!p][bfistl]			= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
													 P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_fistl - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_fistl - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_fistl - 1]	= 1;
										rcd.time[!p][bfistr]			= time.current;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]			= act_fistl;
										rcd.attack[p][act_fistl - 1]	= bfistr;
										rcd.time[!p][bfistr]			= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					//if limb is neck also test head
					if (P[!p].sk.b[h].type == 3)
						//if successful do circle to circle cd (fist to head)
						if (hitboxcheck(P[p].sk.b[ball].hitbox_e, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
															P[!p].sk.chead, P[!p].sk.radius_head);

							//if returned angle not -1, set bone to hit and limb to hitting
							if (rcd.angle_h[!p] != -1)
							{
								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_fistl - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_fistl - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_fistl - 1]	= 1;
									rcd.time[!p][bhead]				= time.current;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_fistl;
									rcd.attack[p][act_fistl - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}

		//---- right fist ------------------------------------------------------------------------

		if (P[p].active_off[act_fistr - 1] == 1)
			for (register int h = 0; h < 19; ++h)
				if (P[p].p_aslot[aslot_action] != NULL)
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
				{
					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (hitboxcheck(P[p].sk.b[balr].hitbox_e, P[!p].sk.b[h].hitbox))
						if (cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[h].v))
						{
							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									rcd.attack_cancel[p][act_fistr - 1]	= 1;
									if (!P[!p].gl_lock.get_lockstate(h))
										rcd.attack_return[p][act_fistr - 1] = 1;
								}
								//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
								//	rcd.attack_return[p][act_fistr - 1]	= 1;
								rcd.time[!p][h]					= time.current;
							}
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								rcd.bone[!p][h]					= act_fistr;
								rcd.attack[p][act_fistr - 1]	= h;
								rcd.time[!p][h]					= time.current;
								break;
							}
							else
								rcd.defend[p]					= h;
						}

					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[balr].hitbox_e, P[!p].sk.b[h].hitbox_e))
						{
							if (h == ball)
								if (cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
													 P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_fistr - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_fistr - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_fistr - 1]	= 1;
										rcd.time[!p][bfistl]			= time.current;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]			= act_fistr;
										rcd.attack[p][act_fistr - 1]	= bfistl;
										rcd.time[!p][bfistl]			= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
													 P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_fistr - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_fistr - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_fistr - 1]	= 1;
										rcd.time[!p][bfistr]			= time.current;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]			= act_fistr;
										rcd.attack[p][act_fistr - 1]	= bfistr;
										rcd.time[!p][bfistr]			= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					if (P[!p].sk.b[h].type == 3)
						if (hitboxcheck(P[p].sk.b[balr].hitbox_e, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
															P[!p].sk.chead, P[!p].sk.radius_head);

							if (rcd.angle_h[!p] != -1)
							{
								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_fistr - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_fistr - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_fistr - 1]	= 1;
									rcd.time[!p][bhead]				= time.current;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_fistr;
									rcd.attack[p][act_fistr - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}

		//---- left foot -------------------------------------------------------------------------

		if (P[p].active_off[act_footl - 1] == 1)
			for (register int h = 0; h < 19; ++h)
				if (P[p].p_aslot[aslot_action] != NULL)
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
				{
					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (hitboxcheck(P[p].sk.b[bfl].hitbox, P[!p].sk.b[h].hitbox))
						if (cd_rect_rect(P[p].sk.b[bfl].v, P[!p].sk.b[h].v))
						{
							rcd.time[!p][h]					= time.current;

							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									rcd.attack_cancel[p][act_footl - 1]	= 1;
									if (!P[!p].gl_lock.get_lockstate(h))
										rcd.attack_return[p][act_footl - 1] = 1;
								}
								//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
								//	rcd.attack_return[p][act_footl - 1]	= 1;
							}
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								rcd.bone[!p][h]					= act_footl;
								rcd.attack[p][act_footl - 1]	= h;
								rcd.time[!p][h]					= time.current;
								break;
							}
							else
								rcd.defend[p]					= h;
						}

					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[bfl].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							if (h == ball)
								if (cd_rect_circle(P[p].sk.b[bfl].v,
												   P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistl]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_footl - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_footl - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_footl - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]				= act_footl;
										rcd.attack[p][act_footl - 1]		= bfistl;
										rcd.time[!p][bfistl]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_rect_circle(P[p].sk.b[bfl].v,
												   P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistr]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_footl - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_footl - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_footl - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]				= act_footl;
										rcd.attack[p][act_footl - 1]		= bfistr;
										rcd.time[!p][bfistr]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					if (P[!p].sk.b[h].type == 3)
						if (hitboxcheck(P[p].sk.b[bfl].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_rect_circle(P[p].sk.b[bfl].v, P[!p].sk.chead, P[!p].sk.radius_head);

							if (rcd.angle_h[!p] != -1)
							{
								rcd.time[!p][bhead]				= time.current;

								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_footl - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_footl - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_footl - 1]	= 1;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_footl;
									rcd.attack[p][act_footl - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}

		//---- right foot ------------------------------------------------------------------------

		if (P[p].active_off[act_footr - 1] == 1)
			for (register int h = 0; h < 19; ++h)
				if (P[p].p_aslot[aslot_action] != NULL)
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
				{
					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (hitboxcheck(P[p].sk.b[bfr].hitbox, P[!p].sk.b[h].hitbox))
						if (cd_rect_rect(P[p].sk.b[bfr].v, P[!p].sk.b[h].v))
						{
							rcd.time[!p][h]					= time.current;

							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									rcd.attack_cancel[p][act_footr - 1]	= 1;
									if (!P[!p].gl_lock.get_lockstate(h))
										rcd.attack_return[p][act_footr - 1] = 1;
								}
								//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
								//	rcd.attack_return[p][act_footr - 1]	= 1;
							}
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								rcd.bone[!p][h]					= act_footr;
								rcd.attack[p][act_footr - 1]	= h;
								rcd.time[!p][h]					= time.current;
								break;
							}
							else
								rcd.defend[p]					= h;
						}

					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[bfr].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							if (h == ball)
								if (cd_rect_circle(P[p].sk.b[bfr].v,
												   P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistl]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_footr - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_footr - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_footr - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]				= act_footr;
										rcd.attack[p][act_footr - 1]		= bfistl;
										rcd.time[!p][bfistl]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_rect_circle(P[p].sk.b[bfr].v,
												   P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistr]				= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
											rcd.attack_cancel[p][act_footr - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_footr - 1] = 1;
									}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_footr - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]				= act_footr;
										rcd.attack[p][act_footr - 1]		= bfistr;
										rcd.time[!p][bfistr]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					if (P[!p].sk.b[h].type == 3)
						if (hitboxcheck(P[p].sk.b[bfr].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_rect_circle(P[p].sk.b[bfr].v, P[!p].sk.chead, P[!p].sk.radius_head);

							if (rcd.angle_h[!p] != -1)
							{
								rcd.time[!p][bhead]				= time.current;

								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_footr - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_footr - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_footr - 1]	= 1;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_footr;
									rcd.attack[p][act_footr - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}

		//---- left knee -------------------------------------------------------------------------

		if (P[p].active_off[act_kneel - 1] == 1)
			for (register int h = 0; h < 19; ++h)
				if (P[p].p_aslot[aslot_action] != NULL)
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
				{
					//knee consists of 2 edges, first are vertices 1, 2 of upper leg
					//second are vertices 0, 3 of lower leg
					//function tests vertices 1, 2 and 2, 3 so the rectangle is filled
					//in the right order
					rectangle rknee;

					//fill order depending on asi
					if (P[p].asi == 0 || P[p].asi == 2)
						rknee.fill_rectangle(0, 0,
											 P[p].sk.b[blul].v.p[2].x, P[p].sk.b[blul].v.p[2].y,
											 P[p].sk.b[blul].v.p[1].x, P[p].sk.b[blul].v.p[1].y,
											 P[p].sk.b[blll].v.p[3].x, P[p].sk.b[blll].v.p[3].y);
					else
						rknee.fill_rectangle(0, 0,
											 P[p].sk.b[blul].v.p[1].x, P[p].sk.b[blul].v.p[1].y,
											 P[p].sk.b[blul].v.p[2].x, P[p].sk.b[blul].v.p[2].y,
											 P[p].sk.b[blll].v.p[3].x, P[p].sk.b[blll].v.p[3].y);

					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					//do 2 hitbox checks, one for upper leg and one for lower
					if (hitboxcheck(P[p].sk.b[blul].hitbox, P[!p].sk.b[h].hitbox) ||
						hitboxcheck(P[p].sk.b[blll].hitbox, P[!p].sk.b[h].hitbox))
					{
						if (cd_rect_rect(rknee, P[!p].sk.b[h].v))
						{
							rcd.time[!p][h]					= time.current;

							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									rcd.attack_cancel[p][act_kneel - 1]	= 1;
									if (!P[!p].gl_lock.get_lockstate(h))
										rcd.attack_return[p][act_kneel - 1] = 1;
								}
								//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
								//	rcd.attack_return[p][act_kneel - 1]	= 1;
							}
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								rcd.bone[!p][h]					= act_kneel;
								rcd.attack[p][act_kneel - 1]	= h;
								rcd.time[!p][h]					= time.current;
								break;
							}
							else
								rcd.defend[p]					= h;
						}
					}

					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[blul].hitbox, P[!p].sk.b[h].hitbox_e) ||
							hitboxcheck(P[p].sk.b[blll].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							if (h == ball)
								if (cd_rect_circle(rknee,
												   P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistl]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
											rcd.attack_cancel[p][act_kneel - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_kneel - 1] = 1;
									}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_kneel - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]				= act_kneel;
										rcd.attack[p][act_kneel - 1]		= bfistl;
										rcd.time[!p][bfistl]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_rect_circle(rknee,
												   P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistr]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_kneel - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_kneel - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_kneel - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]				= act_kneel;
										rcd.attack[p][act_kneel - 1]		= bfistr;
										rcd.time[!p][bfistr]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					if (P[!p].sk.b[h].type == 3)
						if (hitboxcheck(P[p].sk.b[blul].hitbox, P[!p].sk.b[h].hitbox_e) ||
							hitboxcheck(P[p].sk.b[blll].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_rect_circle(rknee,
														  P[!p].sk.chead, P[!p].sk.radius_head);

							if (rcd.angle_h[!p] != -1)
							{
								rcd.time[!p][bhead]				= time.current;

								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_kneel - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_kneel - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_kneel - 1]	= 1;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_kneel;
									rcd.attack[p][act_kneel - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}

		//---- right knee ------------------------------------------------------------------------

		if (P[p].active_off[act_kneer - 1] == 1)
			for (register int h = 0; h < 19; ++h)
				if (P[p].p_aslot[aslot_action] != NULL)
					if (((P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret) &&
						(P[!p].sk.b[h].cd_state == cds_hit || P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)) ||
						(P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit &&
						(P[!p].sk.b[h].cd_state == cds_def || bone_in_defpart_state)))
				{
					//knee consists of 2 edges, first are vertices 1, 2 of upper leg
					//second are vertices 0, 3 of lower leg
					//function tests vertices 1, 2 and 2, 3 so the rectangle is filled
					//in the right order
					rectangle rknee;

					//fill order depending on asi
					if (P[p].asi == 1 || P[p].asi == 3)
						rknee.fill_rectangle(0, 0,
											 P[p].sk.b[blur].v.p[2].x, P[p].sk.b[blur].v.p[2].y,
											 P[p].sk.b[blur].v.p[1].x, P[p].sk.b[blur].v.p[1].y,
											 P[p].sk.b[bllr].v.p[3].x, P[p].sk.b[bllr].v.p[3].y);
					else
						rknee.fill_rectangle(0, 0,
											 P[p].sk.b[blur].v.p[1].x, P[p].sk.b[blur].v.p[1].y,
											 P[p].sk.b[blur].v.p[2].x, P[p].sk.b[blur].v.p[2].y,
											 P[p].sk.b[bllr].v.p[3].x, P[p].sk.b[bllr].v.p[3].y);

					if (P[!p].sk.b[h].cd_state != cds_defpart_e ||
						(P[!p].sk.b[h].cd_state == cds_defpart_e && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					//do 2 hitbox checks, one for upper leg and one for lower
					if (hitboxcheck(P[p].sk.b[blur].hitbox, P[!p].sk.b[h].hitbox) ||
						hitboxcheck(P[p].sk.b[bllr].hitbox, P[!p].sk.b[h].hitbox))
					{
						if (cd_rect_rect(rknee, P[!p].sk.b[h].v))
						{
							rcd.time[!p][h]					= time.current;

							if (P[!p].sk.b[h].cd_state == cds_def)
							{
								if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
									P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
								{
									rcd.attack_cancel[p][act_kneer - 1]	= 1;
									if (!P[!p].gl_lock.get_lockstate(h))
										rcd.attack_return[p][act_kneer - 1] = 1;
								}
								//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
								//	rcd.attack_return[p][act_kneer - 1]	= 1;
							}
							if (P[!p].sk.b[h].cd_state != cds_defpart &&
								P[!p].sk.b[h].cd_state != cds_defpart_b)
							{
								rcd.bone[!p][h]					= act_kneer;
								rcd.attack[p][act_kneer - 1]	= h;
								rcd.time[!p][h]					= time.current;
								break;
							}
							else
								rcd.defend[p]					= h;
						}
					}

					if (P[!p].sk.b[h].cd_state != cds_defpart_b ||
						(P[!p].sk.b[h].cd_state == cds_defpart_b && (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit || P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)))
					if (P[!p].sk.b[h].type == 1)
						if (hitboxcheck(P[p].sk.b[blur].hitbox, P[!p].sk.b[h].hitbox_e) ||
							hitboxcheck(P[p].sk.b[bllr].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							if (h == ball)
								if (cd_rect_circle(rknee,
												   P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistl]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_kneer - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_kneer - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_kneer - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistl]				= act_kneer;
										rcd.attack[p][act_kneer - 1]	= bfistl;
										rcd.time[!p][bfistl]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}

							if (h == balr)
								if (cd_rect_circle(rknee,
												   P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
								{
									rcd.time[!p][bfistr]			= time.current;

									if (P[!p].sk.b[h].cd_state == cds_def)
									{
										if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
											P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
										{
											rcd.attack_cancel[p][act_kneer - 1]	= 1;
											if (!P[!p].gl_lock.get_lockstate(h))
												rcd.attack_return[p][act_kneer - 1] = 1;
										}
										//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
										//	rcd.attack_return[p][act_kneer - 1]	= 1;
									}
									if (P[!p].sk.b[h].cd_state != cds_defpart &&
										P[!p].sk.b[h].cd_state != cds_defpart_e)
									{
										rcd.bone[!p][bfistr]				= act_kneer;
										rcd.attack[p][act_kneer - 1]	= bfistr;
										rcd.time[!p][bfistr]				= time.current;
										break;
									}
									else
										rcd.defend[p]					= h;
								}
						}

					if (P[!p].sk.b[h].type == 3)
						if (hitboxcheck(P[p].sk.b[blur].hitbox, P[!p].sk.b[h].hitbox_e) ||
							hitboxcheck(P[p].sk.b[bllr].hitbox, P[!p].sk.b[h].hitbox_e))
						{
							rcd.angle_h[!p] = cd_rect_circle(rknee,
														  P[!p].sk.chead, P[!p].sk.radius_head);

							if (rcd.angle_h[!p] != -1)
							{
								rcd.time[!p][bhead]				= time.current;

								if (P[!p].sk.b[h].cd_state == cds_def)
								{
									if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hit ||
										P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_nohit)
									{
										rcd.attack_cancel[p][act_kneer - 1]	= 1;
										if (!P[!p].gl_lock.get_lockstate(h))
											rcd.attack_return[p][act_kneer - 1] = 1;
									}
									//if (P[p].p_aslot[aslot_action]->gl_bcds_off[P[!p].asi][h] == cds_hitret)
									//	rcd.attack_return[p][act_kneer - 1]	= 1;
								}
								if (P[!p].sk.b[h].cd_state != cds_defpart)
								{
									rcd.bone[!p][bhead]				= act_kneer;
									rcd.attack[p][act_kneer - 1]	= bhead;
									rcd.time[!p][bhead]				= time.current;
									break;
								}
								else
									rcd.defend[p]					= h;
							}
						}
				}
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame hitboxcheck
//
//	checks to RECTs for collision
//	returns true if they collide, else returns false
//
//------------------------------------------------------------------------------------------------

bool master_frame::hitboxcheck(RECT &r1, RECT &r2)
{
	if (r1.right	>= r2.left &&
		r1.left		<= r2.right &&
		r1.top		<= r2.bottom &&
		r1.bottom	>= r2.top)
		return true;
	else
		return false;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_rect_rect
//
//	returns true or false for two rectangle colliding
//	tests two sides of foot versus four of hitrectangle
//
//------------------------------------------------------------------------------------------------

//!! bei den parametern festlegen, wieviele/welche edges gegen welche/wieviele getestet werden sollen
bool master_frame::cd_rect_rect(rectangle &r1, rectangle &r2)
{
	//unknown a/b numerator, common denominator
	float uanum;
	float ubnum;
	float uden;

	//unknown u1 and u2
	float u1, u2;

	//feet vertices always have the same order
	//only edge[1][2] and edge[2][3] of foot are tested for collision
	//test both foot edge versus four rectangle edges
	//(unrolled loop)
	//if knee a special rectangle is prepared with the matching vertices
	//right and lower side of foot rectangle (r1) against
	//upper, right, lower, left side of hit rectangle (r2)

	//---- 1st rectangle edge --------------------------------------------------------------------

	//first foot edge versus first rectangle edge
	//calculate unknowns u1 and u2
	uanum	= (r2.p[1].x - r2.p[0].x) * (r1.p[1].y - r2.p[0].y) - (r2.p[1].y - r2.p[0].y) * (r1.p[1].x - r2.p[0].x);
	ubnum	= (r1.p[2].x - r1.p[1].x) * (r1.p[1].y - r2.p[0].y) - (r1.p[2].y - r1.p[1].y) * (r1.p[1].x - r2.p[0].x);
	uden	= (r2.p[1].y - r2.p[0].y) * (r1.p[2].x - r1.p[1].x) - (r2.p[1].x - r2.p[0].x) * (r1.p[2].y - r1.p[1].y);

	//if uden = 0, division through zero doesn't matter since it's float
	u1		= uanum / uden;
	u2		= ubnum / uden;

//X1
	//lines coincident
	//both line segments part of the same line
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[2].x, r1.p[2].y, r1.p[1].x, r1.p[1].y);
		line l2(r2.p[1].x, r2.p[1].y, r2.p[0].x, r2.p[0].y);

		//check if both lines are just one point
		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			//same point
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		//unrolled version
		//test both end points of line segemnts against other line
		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	//both line segments intersect if u1 and u2 both lie between 0 and 1
	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	//second foot edge versus first rectangle edge
	uanum	= (r2.p[1].x - r2.p[0].x) * (r1.p[2].y - r2.p[0].y) - (r2.p[1].y - r2.p[0].y) * (r1.p[2].x - r2.p[0].x);
	ubnum	= (r1.p[3].x - r1.p[2].x) * (r1.p[2].y - r2.p[0].y) - (r1.p[3].y - r1.p[2].y) * (r1.p[2].x - r2.p[0].x);
	uden	= (r2.p[1].y - r2.p[0].y) * (r1.p[3].x - r1.p[2].x) - (r2.p[1].x - r2.p[0].x) * (r1.p[3].y - r1.p[2].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X2
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[3].x, r1.p[3].y, r1.p[2].x, r1.p[2].y);
		line l2(r2.p[1].x, r2.p[1].y, r2.p[0].x, r2.p[0].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	//---- 2nd rectangle edge --------------------------------------------------------------------

	uanum	= (r2.p[2].x - r2.p[1].x) * (r1.p[1].y - r2.p[1].y) - (r2.p[2].y - r2.p[1].y) * (r1.p[1].x - r2.p[1].x);
	ubnum	= (r1.p[2].x - r1.p[1].x) * (r1.p[1].y - r2.p[1].y) - (r1.p[2].y - r1.p[1].y) * (r1.p[1].x - r2.p[1].x);
	uden	= (r2.p[2].y - r2.p[1].y) * (r1.p[2].x - r1.p[1].x) - (r2.p[2].x - r2.p[1].x) * (r1.p[2].y - r1.p[1].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X3
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[2].x, r1.p[2].y, r1.p[1].x, r1.p[1].y);
		line l2(r2.p[2].x, r2.p[2].y, r2.p[1].x, r2.p[1].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	uanum	= (r2.p[2].x - r2.p[1].x) * (r1.p[2].y - r2.p[1].y) - (r2.p[2].y - r2.p[1].y) * (r1.p[2].x - r2.p[1].x);
	ubnum	= (r1.p[3].x - r1.p[2].x) * (r1.p[2].y - r2.p[1].y) - (r1.p[3].y - r1.p[2].y) * (r1.p[2].x - r2.p[1].x);
	uden	= (r2.p[2].y - r2.p[1].y) * (r1.p[3].x - r1.p[2].x) - (r2.p[2].x - r2.p[1].x) * (r1.p[3].y - r1.p[2].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X4
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[3].x, r1.p[3].y, r1.p[2].x, r1.p[2].y);
		line l2(r2.p[2].x, r2.p[2].y, r2.p[1].x, r2.p[1].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	//---- 3rd rectangle edge --------------------------------------------------------------------

	uanum	= (r2.p[3].x - r2.p[2].x) * (r1.p[1].y - r2.p[2].y) - (r2.p[3].y - r2.p[2].y) * (r1.p[1].x - r2.p[2].x);
	ubnum	= (r1.p[2].x - r1.p[1].x) * (r1.p[1].y - r2.p[2].y) - (r1.p[2].y - r1.p[1].y) * (r1.p[1].x - r2.p[2].x);
	uden	= (r2.p[3].y - r2.p[2].y) * (r1.p[2].x - r1.p[1].x) - (r2.p[3].x - r2.p[2].x) * (r1.p[2].y - r1.p[1].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X5
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[2].x, r1.p[2].y, r1.p[1].x, r1.p[1].y);
		line l2(r2.p[3].x, r2.p[3].y, r2.p[2].x, r2.p[2].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	uanum	= (r2.p[3].x - r2.p[2].x) * (r1.p[2].y - r2.p[2].y) - (r2.p[3].y - r2.p[2].y) * (r1.p[2].x - r2.p[2].x);
	ubnum	= (r1.p[3].x - r1.p[2].x) * (r1.p[2].y - r2.p[2].y) - (r1.p[3].y - r1.p[2].y) * (r1.p[2].x - r2.p[2].x);
	uden	= (r2.p[3].y - r2.p[2].y) * (r1.p[3].x - r1.p[2].x) - (r2.p[3].x - r2.p[2].x) * (r1.p[3].y - r1.p[2].y);

//X6
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[3].x, r1.p[3].y, r1.p[2].x, r1.p[2].y);
		line l2(r2.p[3].x, r2.p[3].y, r2.p[2].x, r2.p[2].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	u1		= uanum / uden;
	u2		= ubnum / uden;

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	//---- 4th rectangle edge --------------------------------------------------------------------

	uanum	= (r2.p[0].x - r2.p[3].x) * (r1.p[1].y - r2.p[3].y) - (r2.p[0].y - r2.p[3].y) * (r1.p[1].x - r2.p[3].x);
	ubnum	= (r1.p[2].x - r1.p[1].x) * (r1.p[1].y - r2.p[3].y) - (r1.p[2].y - r1.p[1].y) * (r1.p[1].x - r2.p[3].x);
	uden	= (r2.p[0].y - r2.p[3].y) * (r1.p[2].x - r1.p[1].x) - (r2.p[0].x - r2.p[3].x) * (r1.p[2].y - r1.p[1].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X7
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[2].x, r1.p[2].y, r1.p[1].x, r1.p[1].y);
		line l2(r2.p[0].x, r2.p[0].y, r2.p[3].x, r2.p[3].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	uanum	= (r2.p[0].x - r2.p[3].x) * (r1.p[2].y - r2.p[3].y) - (r2.p[0].y - r2.p[3].y) * (r1.p[2].x - r2.p[3].x);
	ubnum	= (r1.p[3].x - r1.p[2].x) * (r1.p[2].y - r2.p[3].y) - (r1.p[3].y - r1.p[2].y) * (r1.p[2].x - r2.p[3].x);
	uden	= (r2.p[0].y - r2.p[3].y) * (r1.p[3].x - r1.p[2].x) - (r2.p[0].x - r2.p[3].x) * (r1.p[3].y - r1.p[2].y);

	u1		= uanum / uden;
	u2		= ubnum / uden;

//X8
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		line l1(r1.p[3].x, r1.p[3].y, r1.p[2].x, r1.p[2].y);
		line l2(r2.p[0].x, r2.p[0].y, r2.p[3].x, r2.p[3].y);

		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);

	//else no collision
	return(false);

/*  un-unrolled
//	uanum	= (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
//	ubnum	= (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
//	uden	= (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);

	//result
	bool result = false;

	//feet edges
	line fedge[2];

	fedge[0].p[0].x		= r1.p[1].x;	fedge[0].p[0].y		= r1.p[1].y;
	fedge[0].p[1].x		= r1.p[2].x;	fedge[0].p[1].y		= r1.p[2].y;

	fedge[1].p[0].x		= r1.p[2].x;	fedge[1].p[0].y		= r1.p[2].y;
	fedge[1].p[1].x		= r1.p[3].x;	fedge[1].p[1].y		= r1.p[3].y;

	//hit rectangle edges
	line redge[4];

	redge[0].p[0].x		= r2.p[0].x;	redge[0].p[0].y		= r2.p[0].y;
	redge[0].p[1].x		= r2.p[1].x;	redge[0].p[1].y		= r2.p[1].y;

	redge[1].p[0].x		= r2.p[1].x;	redge[1].p[0].y		= r2.p[1].y;
	redge[1].p[1].x		= r2.p[2].x;	redge[1].p[1].y		= r2.p[2].y;

	redge[2].p[0].x		= r2.p[2].x;	redge[2].p[0].y		= r2.p[2].y;
	redge[2].p[1].x		= r2.p[3].x;	redge[2].p[1].y		= r2.p[3].y;

	redge[3].p[0].x		= r2.p[3].x;	redge[3].p[0].y		= r2.p[3].y;
	redge[3].p[1].x		= r2.p[0].x;	redge[3].p[1].y		= r2.p[0].y;

	float uanum = 0;
	float ubnum = 0;
	float uden	= 0;

	float u1 = 0;
	float u2 = 0;

	//for both feet edges
	for (register int fe = 0; fe < 2; ++fe)
		//for all rectangle edges
		for (register int re = 0; re < 4; ++re)
		{
			//calculate unknowns u1 and u2
			uanum	= (redge[re].p[1].x - redge[re].p[0].x) * (fedge[fe].p[0].y - redge[re].p[0].y) - (redge[re].p[1].y - redge[re].p[0].y) * (fedge[fe].p[0].x - redge[re].p[0].x);
			ubnum	= (fedge[fe].p[1].x - fedge[fe].p[0].x) * (fedge[fe].p[0].y - redge[re].p[0].y) - (fedge[fe].p[1].y - fedge[fe].p[0].y) * (fedge[fe].p[0].x - redge[re].p[0].x);
			uden	= (redge[re].p[1].y - redge[re].p[0].y) * (fedge[fe].p[1].x - fedge[fe].p[0].x) - (redge[re].p[1].x - redge[re].p[0].x) * (fedge[fe].p[1].y - fedge[fe].p[0].y);

			//if uden = 0, division through zero doesn't matter since it's float
			u1		= uanum / uden;
			u2		= ubnum / uden;

			//both line segments intersect if u1 and u2 both lie between 0 and 1
			//or uanum and ubnum and uden is zero which means they are parallel
			if ((u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1) ||
				(uanum == 0 && ubnum == 0 && uden == 0))
			{
				//set result
				result = true;

				//stop cd
				fe = 1;
				break;
			}
		}

	return(result);*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame CD_rect_rect
//
//	returns the (first) point of collision between two rectangles
//	(tests the four edges against each other)
//
//------------------------------------------------------------------------------------------------

bool master_frame::CD_rect_rect(rectangle &r1, rectangle &r2)
{
	//unknown a/b numerator, common denominator
	float uanum	= 0;
	float ubnum	= 0;
	float uden	= 0;

	//unknown u1 and u2
	float u1	= 0;
	float u2	= 0;

	//point of first hit detection
	bool result	= false;

	//un-unrolled
//	uanum	= (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
//	ubnum	= (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
//	uden	= (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);

	//get the four edges of both rectangles
	line Aedge[4];
	line Bedge[4];

	Aedge[0].p[0].x		= r1.p[0].x;	Aedge[0].p[0].y		= r1.p[0].y;
	Aedge[0].p[1].x		= r1.p[1].x;	Aedge[0].p[1].y		= r1.p[1].y;
	Aedge[1].p[0].x		= r1.p[1].x;	Aedge[1].p[0].y		= r1.p[1].y;
	Aedge[1].p[1].x		= r1.p[2].x;	Aedge[1].p[1].y		= r1.p[2].y;
	Aedge[2].p[0].x		= r1.p[2].x;	Aedge[2].p[0].y		= r1.p[2].y;
	Aedge[2].p[1].x		= r1.p[3].x;	Aedge[2].p[1].y		= r1.p[3].y;
	Aedge[3].p[0].x		= r1.p[3].x;	Aedge[3].p[0].y		= r1.p[3].y;
	Aedge[3].p[1].x		= r1.p[0].x;	Aedge[3].p[1].y		= r1.p[0].y;

	Bedge[0].p[0].x		= r2.p[0].x;	Bedge[0].p[0].y		= r2.p[0].y;
	Bedge[0].p[1].x		= r2.p[1].x;	Bedge[0].p[1].y		= r2.p[1].y;
	Bedge[1].p[0].x		= r2.p[1].x;	Bedge[1].p[0].y		= r2.p[1].y;
	Bedge[1].p[1].x		= r2.p[2].x;	Bedge[1].p[1].y		= r2.p[2].y;
	Bedge[2].p[0].x		= r2.p[2].x;	Bedge[2].p[0].y		= r2.p[2].y;
	Bedge[2].p[1].x		= r2.p[3].x;	Bedge[2].p[1].y		= r2.p[3].y;
	Bedge[3].p[0].x		= r2.p[3].x;	Bedge[3].p[0].y		= r2.p[3].y;
	Bedge[3].p[1].x		= r2.p[0].x;	Bedge[3].p[1].y		= r2.p[0].y;

	//for all A edges
	for (int A = 0; A < 4; ++A)
		//for all B edges
		for (int B = 0; B < 4; ++B)
		{
			//calculate unknowns u1 and u2
			uanum	= (Bedge[B].p[1].x - Bedge[B].p[0].x) * (Aedge[A].p[0].y - Bedge[B].p[0].y) - (Bedge[B].p[1].y - Bedge[B].p[0].y) * (Aedge[A].p[0].x - Bedge[B].p[0].x);
			ubnum	= (Aedge[A].p[1].x - Aedge[A].p[0].x) * (Aedge[A].p[0].y - Bedge[B].p[0].y) - (Aedge[A].p[1].y - Aedge[A].p[0].y) * (Aedge[A].p[0].x - Bedge[B].p[0].x);
			uden	= (Bedge[B].p[1].y - Bedge[B].p[0].y) * (Aedge[A].p[1].x - Aedge[A].p[0].x) - (Bedge[B].p[1].x - Bedge[B].p[0].x) * (Aedge[A].p[1].y - Aedge[A].p[0].y);

			//if uden = 0, division through zero doesn't matter since it's float
			u1		= uanum / uden;
			u2		= ubnum / uden;

			//lines coincident
			//both line segments part of the same line
			if (uanum == 0 && ubnum == 0 && uden == 0)
			{
				//check if both lines are just one point
				if (Aedge[A].p[0] == Aedge[A].p[1] && Bedge[B].p[0] == Bedge[B].p[1])
					//same point
					if (Aedge[A].p[0] == Bedge[B].p[0])
					{
						return(true);
					}

				//unrolled version
				//test both end points of line segemnts against other line
				float dx, dy;
				float unum, uden, u;

				//Aedge[A].p[0] vs. Bedge[B]
				dx		= Bedge[B].p[1].x - Bedge[B].p[0].x;
				dy		= Bedge[B].p[1].y - Bedge[B].p[0].y;
				unum	= (Aedge[A].p[0].x - Bedge[B].p[0].x) * (Bedge[B].p[1].x - Bedge[B].p[0].x) +
						  (Aedge[A].p[0].y - Bedge[B].p[0].y) * (Bedge[B].p[1].y - Bedge[B].p[0].y);
				uden	= dx * dx + dy * dy;
				u		= unum / uden;
				//within line
				if (u >= 0 && u <= 1)
				{
					return(true);
				}
				//Aedge[A].p[1] vs. Bedge[B]
				//dx		= Bedge[B].p[1].x - Bedge[B].p[0].x;
				//dy		= Bedge[B].p[1].y - Bedge[B].p[0].y;
				unum	= (Aedge[A].p[1].x - Bedge[B].p[0].x) * (Bedge[B].p[1].x - Bedge[B].p[0].x) +
						  (Aedge[A].p[1].y - Bedge[B].p[0].y) * (Bedge[B].p[1].y - Bedge[B].p[0].y);
				//uden	= dx * dx + dy * dy;
				u		= unum / uden;
				//within line
				if (u >= 0 && u <= 1)
				{
					return(true);
				}
				//Bedge[B].p[0] vs. Aedge[A]
				dx		= Aedge[A].p[1].x - Aedge[A].p[0].x;
				dy		= Aedge[A].p[1].y - Aedge[A].p[0].y;
				unum	= (Bedge[B].p[0].x - Aedge[A].p[0].x) * (Aedge[A].p[1].x - Aedge[A].p[0].x) +
						  (Bedge[B].p[0].y - Aedge[A].p[0].y) * (Aedge[A].p[1].y - Aedge[A].p[0].y);
				uden	= dx * dx + dy * dy;
				u		= unum / uden;
				//within line
				if (u >= 0 && u <= 1)
				{
					return(true);
				}
				//Bedge[B].p[1] vs. Aedge[A]
				//dx		= Aedge[A].p[1].x - Aedge[A].p[0].x;
				//dy		= Aedge[A].p[1].y - Aedge[A].p[0].y;
				unum	= (Bedge[B].p[1].x - Aedge[A].p[0].x) * (Aedge[A].p[1].x - Aedge[A].p[0].x) +
						  (Bedge[B].p[1].y - Aedge[A].p[0].y) * (Aedge[A].p[1].y - Aedge[A].p[0].y);
				//uden	= dx * dx + dy * dy;
				u		= unum / uden;
				//within line
				if (u >= 0 && u <= 1)
				{
					return(true);
				}
			}

			//both line segments intersect if u1 and u2 both lie between 0 and 1
			if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
			{
				return(true);
			}
		}

/*
	//feet edges
	line fedge[2];

	fedge[0].p[0].x		= r1.p[1].x;	fedge[0].p[0].y		= r1.p[1].y;
	fedge[0].p[1].x		= r1.p[2].x;	fedge[0].p[1].y		= r1.p[2].y;

	fedge[1].p[0].x		= r1.p[2].x;	fedge[1].p[0].y		= r1.p[2].y;
	fedge[1].p[1].x		= r1.p[3].x;	fedge[1].p[1].y		= r1.p[3].y;

	//hit rectangle edges
	line redge[4];

	redge[0].p[0].x		= r2.p[0].x;	redge[0].p[0].y		= r2.p[0].y;
	redge[0].p[1].x		= r2.p[1].x;	redge[0].p[1].y		= r2.p[1].y;

	redge[1].p[0].x		= r2.p[1].x;	redge[1].p[0].y		= r2.p[1].y;
	redge[1].p[1].x		= r2.p[2].x;	redge[1].p[1].y		= r2.p[2].y;

	redge[2].p[0].x		= r2.p[2].x;	redge[2].p[0].y		= r2.p[2].y;
	redge[2].p[1].x		= r2.p[3].x;	redge[2].p[1].y		= r2.p[3].y;

	redge[3].p[0].x		= r2.p[3].x;	redge[3].p[0].y		= r2.p[3].y;
	redge[3].p[1].x		= r2.p[0].x;	redge[3].p[1].y		= r2.p[0].y;

	float uanum = 0;
	float ubnum = 0;
	float uden	= 0;

	float u1 = 0;
	float u2 = 0;

	//for both feet edges
	for (register int fe = 0; fe < 2; ++fe)
		//for all rectangle edges
		for (register int re = 0; re < 4; ++re)
		{
			//calculate unknowns u1 and u2
			uanum	= (redge[re].p[1].x - redge[re].p[0].x) * (fedge[fe].p[0].y - redge[re].p[0].y) - (redge[re].p[1].y - redge[re].p[0].y) * (fedge[fe].p[0].x - redge[re].p[0].x);
			ubnum	= (fedge[fe].p[1].x - fedge[fe].p[0].x) * (fedge[fe].p[0].y - redge[re].p[0].y) - (fedge[fe].p[1].y - fedge[fe].p[0].y) * (fedge[fe].p[0].x - redge[re].p[0].x);
			uden	= (redge[re].p[1].y - redge[re].p[0].y) * (fedge[fe].p[1].x - fedge[fe].p[0].x) - (redge[re].p[1].x - redge[re].p[0].x) * (fedge[fe].p[1].y - fedge[fe].p[0].y);

			//if uden = 0, division through zero doesn't matter since it's float
			u1		= uanum / uden;
			u2		= ubnum / uden;

			//both line segments intersect if u1 and u2 both lie between 0 and 1
			//or uanum and ubnum and uden is zero which means they are parallel
			if ((u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1) ||
				(uanum == 0 && ubnum == 0 && uden == 0))
			{
				//set result
				result = true;

				//stop cd
				fe = 1;
				break;
			}
		}*/

	//---------------------------------------------------------------------------------------------

	return(result);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_circle_circle
//
//	returns angle of two circles colliding (-1 for no collision)
//	(angle from point of hit circle)
//
//------------------------------------------------------------------------------------------------

float master_frame::cd_circle_circle(point c1, float r1, point c2, float r2)
{
	//relative distance of x and y positions
	float diffx = (float)fabs(c1.x - c2.x);
	float diffy = (float)fabs(c1.y - c2.y);

	//calculate angle in rad between two circles (from point of hit circle)
	float angle = (float)atan2(c1.y - c2.y, c1.x - c2.x);

	//convert in degree
	angle = angle * 180 / PI;

	//check for limits
	if (angle < 0)		angle += 360;
	if (angle > 359)	angle -= 360;

	//if distance between two center is smaller/equal
	//to sum of both radi they collide, else they don't
	//a� + b� = c�
	if (sqrt(diffx * diffx + diffy * diffy) <= r1 + r2)
		return(angle);
	else
		return(-1);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_circle_rect
//
//	returns true if circle and rectangle collide
//
//------------------------------------------------------------------------------------------------

bool master_frame::cd_circle_rect(point cc, float rc, rectangle &r)
{
	//unknown u
	float unum, uden, u;

	//shortest distance between circle center and line
	point sd;

	//distance between sd and circle center
	float dis_sd;
	//distance between circle center and end points of line
	float dis_ep;

	//---- 1st edge of hit rectangle -------------------------------------------------------------

	//calculate unknown u
//	unum	= (cc.x - x1) * (x2 - x1) + (cc.y - y1) * (y2 - y1);
//	uden	= (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
	unum	= (cc.x - r.p[0].x) * (r.p[1].x - r.p[0].x) + (cc.y - r.p[0].y) * (r.p[1].y - r.p[0].y);
	uden	= (r.p[1].x - r.p[0].x) * (r.p[1].x - r.p[0].x) + (r.p[1].y - r.p[0].y) * (r.p[1].y - r.p[0].y);
	u		= unum / uden;

	//if u lies not on line, set it to end points
	if (u < 0) u = 0;	if (u > 1) u = 1;

	//calculate shortes distance between center of circle and line
	sd.x	= r.p[0].x + u * (r.p[1].x - r.p[0].x);
	sd.y	= r.p[0].y + u * (r.p[1].y - r.p[0].y);

	//calculate distance between sd and circle center
	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	//if distance is smaller or equal to radius they collide
	if (dis_sd <= rc)		return true;

	//calculate distances between end points of line and circle;
	dis_ep	= (float)fabs(cc.x - r.p[0].x) * (float)fabs(cc.x - r.p[0].x) + (float)fabs(cc.y - r.p[0].y) * (float)fabs(cc.y - r.p[0].y);
	dis_ep	= (float)sqrt(dis_ep);

	//if distance is smaller or equal to radius they collide
	//(in case the line is completely within circle)
	if (dis_ep <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[1].x) * (float)fabs(cc.x - r.p[1].x) + (float)fabs(cc.y - r.p[1].y) * (float)fabs(cc.y - r.p[1].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	//---- 2nd edge of hit rectangle -------------------------------------------------------------

	unum	= (cc.x - r.p[1].x) * (r.p[2].x - r.p[1].x) + (cc.y - r.p[1].y) * (r.p[2].y - r.p[1].y);
	uden	= (r.p[2].x - r.p[1].x) * (r.p[2].x - r.p[1].x) + (r.p[2].y - r.p[1].y) * (r.p[2].y - r.p[1].y);
	u		= unum / uden;

	if (u < 0) u = 0;	if (u > 1) u = 1;

	sd.x	= r.p[1].x + u * (r.p[2].x - r.p[1].x);
	sd.y	= r.p[1].y + u * (r.p[2].y - r.p[1].y);

	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	if (dis_sd <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[1].x) * (float)fabs(cc.x - r.p[1].x) + (float)fabs(cc.y - r.p[1].y) * (float)fabs(cc.y - r.p[1].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[2].x) * (float)fabs(cc.x - r.p[2].x) + (float)fabs(cc.y - r.p[2].y) * (float)fabs(cc.y - r.p[2].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	//---- 3rd edge of hit rectangle -------------------------------------------------------------

	unum	= (cc.x - r.p[2].x) * (r.p[3].x - r.p[2].x) + (cc.y - r.p[2].y) * (r.p[3].y - r.p[2].y);
	uden	= (r.p[3].x - r.p[2].x) * (r.p[3].x - r.p[2].x) + (r.p[3].y - r.p[2].y) * (r.p[3].y - r.p[2].y);
	u		= unum / uden;

	if (u < 0) u = 0;	if (u > 1) u = 1;

	sd.x	= r.p[2].x + u * (r.p[3].x - r.p[2].x);
	sd.y	= r.p[2].y + u * (r.p[3].y - r.p[2].y);

	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	if (dis_sd <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[2].x) * (float)fabs(cc.x - r.p[2].x) + (float)fabs(cc.y - r.p[2].y) * (float)fabs(cc.y - r.p[2].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[3].x) * (float)fabs(cc.x - r.p[3].x) + (float)fabs(cc.y - r.p[3].y) * (float)fabs(cc.y - r.p[3].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	//---- 4th edge of hit rectangle -------------------------------------------------------------

	unum	= (cc.x - r.p[3].x) * (r.p[0].x - r.p[3].x) + (cc.y - r.p[3].y) * (r.p[0].y - r.p[3].y);
	uden	= (r.p[0].x - r.p[3].x) * (r.p[0].x - r.p[3].x) + (r.p[0].y - r.p[3].y) * (r.p[0].y - r.p[3].y);
	u		= unum / uden;

	if (u < 0) u = 0;	if (u > 1) u = 1;

	sd.x	= r.p[3].x + u * (r.p[0].x - r.p[3].x);
	sd.y	= r.p[3].y + u * (r.p[0].y - r.p[3].y);

	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	if (dis_sd <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[3].x) * (float)fabs(cc.x - r.p[3].x) + (float)fabs(cc.y - r.p[3].y) * (float)fabs(cc.y - r.p[3].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	dis_ep	= (float)fabs(cc.x - r.p[0].x) * (float)fabs(cc.x - r.p[0].x) + (float)fabs(cc.y - r.p[0].y) * (float)fabs(cc.y - r.p[0].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		return true;

	//--------------------------------------------------------------------------------------------

	//no intersection
	return false;

/*	//substitutions
	float a, b, c;
	float dis;

	//unknowns u1 and u2
	float u1, u2;


	//intersection points
	float ix1, iy1, ix2, iy2;
	line l1, l2;

	//---- 1st edge of hit rectangle -------------------------------------------------------------

	//calculate a, b and c
//	a	= (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
//	b	= 2 * ((x2 - x1) * (x1 - c.x) + (y2 - y1) * (y1 - c.y));
//	c	= c.x * c.x + c.y * c.y + x1 * x1 + y1 * y1 - 2 * (c.x * x1 + c.y * y1) - r * r;
	a	= (r.p[1].x - r.p[0].x) * (r.p[1].x - r.p[0].x) + (r.p[1].y - r.p[0].y) * (r.p[1].y - r.p[0].y);
	b	= 2 * ((r.p[1].x - r.p[0].x) * (r.p[0].x - cc.x) + (r.p[1].y - r.p[0].y) * (r.p[0].y - cc.y));
	c	= cc.x * cc.x + cc.y * cc.y + r.p[0].x * r.p[0].x + r.p[0].y * r.p[0].y - 2 * (cc.x * r.p[0].x + cc.y * r.p[0].y) - rc * rc;

	//determine intersection
	//(dis < 0 = no intersection, dis = 0 = 1 intersection, dis > 0 = 2 intersections)
	dis	= b * b - 4 * a * c;

	//calculate unknowns u1 and u2
	u1	= (-b + (float)sqrt(dis)) / (2 * a);
	u2	= (-b - (float)sqrt(dis)) / (2 * a);

	//calculate intersection points
	ix1 = r.p[0].x + u1 * (r.p[1].x - r.p[0].x);
	iy1 = r.p[0].y + u1 * (r.p[1].y - r.p[0].y);
	ix2 = r.p[0].x + u2 * (r.p[1].x - r.p[0].x);
	iy2 = r.p[0].y + u2 * (r.p[1].y - r.p[0].y);

	//check if line formed of edge and line
	//formed of center of circle and collision points and rim
	//collid
	//if so, return true
	l1.p[0].x = r.p[0].x;	l1.p[0].y = r.p[0].y;
	l1.p[1].x = r.p[1].x;	l1.p[1].y = r.p[1].y;

	l2.p[0]		= cc;
	l2.p[1].x	= ix1;		l2.p[1].y = iy1;

	if (cd_line_line(l1, l2))
		return true;

	l2.p[1].x	= ix2;		l2.p[1].y = iy2;

	if (cd_line_line(l1, l2))
		return true;

	//---- 2nd edge of hit rectangle -------------------------------------------------------------

	a	= (r.p[2].x - r.p[1].x) * (r.p[2].x - r.p[1].x) + (r.p[2].y - r.p[1].y) * (r.p[2].y - r.p[1].y);
	b	= 2 * ((r.p[2].x - r.p[1].x) * (r.p[1].x - cc.x) + (r.p[2].y - r.p[1].y) * (r.p[1].y - cc.y));
	c	= cc.x * cc.x + cc.y * cc.y + r.p[1].x * r.p[1].x + r.p[1].y * r.p[1].y - 2 * (cc.x * r.p[1].x + cc.y * r.p[1].y) - rc * rc;

	dis	= b * b - 4 * a * c;

	u1	= (-b + (float)sqrt(dis)) / (2 * a);
	u2	= (-b - (float)sqrt(dis)) / (2 * a);

	ix1 = r.p[1].x + u1 * (r.p[2].x - r.p[1].x);
	iy1 = r.p[1].y + u1 * (r.p[2].y - r.p[1].y);
	ix2 = r.p[1].x + u2 * (r.p[2].x - r.p[1].x);
	iy2 = r.p[1].y + u2 * (r.p[2].y - r.p[1].y);

	l1.p[0].x = r.p[1].x;	l1.p[0].y = r.p[1].y;
	l1.p[1].x = r.p[2].x;	l1.p[1].y = r.p[2].y;

	l2.p[0]		= cc;
	l2.p[1].x	= ix1;		l2.p[1].y = iy1;

	if (cd_line_line(l1, l2))
		return true;

	l2.p[1].x	= ix2;		l2.p[1].y = iy2;

	if (cd_line_line(l1, l2))
		return true;

	//---- 3rd edge of hit rectangle -------------------------------------------------------------

	a	= (r.p[3].x - r.p[2].x) * (r.p[3].x - r.p[2].x) + (r.p[3].y - r.p[2].y) * (r.p[3].y - r.p[2].y);
	b	= 2 * ((r.p[3].x - r.p[2].x) * (r.p[2].x - cc.x) + (r.p[3].y - r.p[2].y) * (r.p[2].y - cc.y));
	c	= cc.x * cc.x + cc.y * cc.y + r.p[2].x * r.p[2].x + r.p[2].y * r.p[2].y - 2 * (cc.x * r.p[2].x + cc.y * r.p[1].y) - rc * rc;

	dis	= b * b - 4 * a * c;

	u1	= (-b + (float)sqrt(dis)) / (2 * a);
	u2	= (-b - (float)sqrt(dis)) / (2 * a);

	ix1 = r.p[2].x + u1 * (r.p[3].x - r.p[2].x);
	iy1 = r.p[2].y + u1 * (r.p[3].y - r.p[2].y);
	ix2 = r.p[2].x + u2 * (r.p[3].x - r.p[2].x);
	iy2 = r.p[2].y + u2 * (r.p[3].y - r.p[2].y);

	l1.p[0].x = r.p[2].x;	l1.p[0].y = r.p[2].y;
	l1.p[1].x = r.p[3].x;	l1.p[1].y = r.p[3].y;

	l2.p[0]		= cc;
	l2.p[1].x	= ix1;		l2.p[1].y = iy1;

	if (cd_line_line(l1, l2))
		return true;

	l2.p[1].x	= ix2;		l2.p[1].y = iy2;

	if (cd_line_line(l1, l2))
		return true;

	//---- 4th edge of hit rectangle -------------------------------------------------------------

	a	= (r.p[0].x - r.p[3].x) * (r.p[0].x - r.p[3].x) + (r.p[0].y - r.p[3].y) * (r.p[0].y - r.p[3].y);
	b	= 2 * ((r.p[0].x - r.p[3].x) * (r.p[3].x - cc.x) + (r.p[0].y - r.p[3].y) * (r.p[3].y - cc.y));
	c	= cc.x * cc.x + cc.y * cc.y + r.p[3].x * r.p[3].x + r.p[3].y * r.p[3].y - 2 * (cc.x * r.p[3].x + cc.y * r.p[3].y) - rc * rc;

	dis	= b * b - 4 * a * c;

	u1	= (-b + (float)sqrt(dis)) / (2 * a);
	u2	= (-b - (float)sqrt(dis)) / (2 * a);

	ix1 = r.p[3].x + u1 * (r.p[0].x - r.p[3].x);
	iy1 = r.p[3].y + u1 * (r.p[0].y - r.p[3].y);
	ix2 = r.p[3].x + u2 * (r.p[0].x - r.p[3].x);
	iy2 = r.p[3].y + u2 * (r.p[0].y - r.p[3].y);

	l1.p[0].x = r.p[3].x;	l1.p[0].y = r.p[3].y;
	l1.p[1].x = r.p[0].x;	l1.p[1].y = r.p[0].y;

	l2.p[0]		= cc;
	l2.p[1].x	= ix1;		l2.p[1].y = iy1;

	if (cd_line_line(l1, l2))
		return true;

	l2.p[1].x	= ix2;		l2.p[1].y = iy2;

	if (cd_line_line(l1, l2))
		return true;*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_rect_circle
//
//	tests two side of a rectangle (feet) for collision with circle (head)
//
//------------------------------------------------------------------------------------------------

float master_frame::cd_rect_circle(rectangle &r, point cc, float rc)
{
	//center of foot
	point pcf;

	//angle between center of head and center of foot
	float angle;

	//result of test
	bool result = false;

	//unknown u
	float unum, uden, u;

	//shortest distance between circle center and line
	point sd;

	//distance between sd and circle center
	float dis_sd;
	//distance between circle center and end points of line
	float dis_ep;

	//calculate center of foot
	line l1, l2;
	l1.p[0].x	= r.p[0].x;		l1.p[0].y	= r.p[0].y;
	l1.p[1].x	= r.p[2].x;		l1.p[1].y	= r.p[2].y;
	l2.p[0].x	= r.p[1].x;		l2.p[0].y	= r.p[1].y;
	l2.p[1].x	= r.p[3].x;		l2.p[1].y	= r.p[3].y;

	//should always return true
	cd_line_line(l1, l2, pcf);

	//calculate angle in rad between foot and head (from point of head circle)
	angle = (float)atan2(pcf.y - cc.y, pcf.x - cc.x);

	//convert in degree
	angle = angle * 180 / PI;

	//check for limits
	if (angle < 0)		angle += 360;
	if (angle > 359)	angle -= 360;

	//---- 1st edge of foot ----------------------------------------------------------------------
	//for comments see cd_circle_line

	unum	= (cc.x - r.p[1].x) * (r.p[2].x - r.p[1].x) + (cc.y - r.p[1].y) * (r.p[2].y - r.p[1].y);
	uden	= (r.p[2].x - r.p[1].x) * (r.p[2].x - r.p[1].x) + (r.p[2].y - r.p[1].y) * (r.p[2].y - r.p[1].y);
	u		= unum / uden;

	if (u < 0) u = 0;	if (u > 1) u = 1;

	sd.x	= r.p[1].x + u * (r.p[2].x - r.p[1].x);
	sd.y	= r.p[1].y + u * (r.p[2].y - r.p[1].y);

	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	if (dis_sd <= rc)		result = true;

	dis_ep	= (float)fabs(cc.x - r.p[1].x) * (float)fabs(cc.x - r.p[1].x) + (float)fabs(cc.y - r.p[1].y) * (float)fabs(cc.y - r.p[1].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		result = true;

	dis_ep	= (float)fabs(cc.x - r.p[2].x) * (float)fabs(cc.x - r.p[2].x) + (float)fabs(cc.y - r.p[2].y) * (float)fabs(cc.y - r.p[2].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		result = true;

	//---- 2nd edge of foot ----------------------------------------------------------------------

	unum	= (cc.x - r.p[2].x) * (r.p[3].x - r.p[2].x) + (cc.y - r.p[2].y) * (r.p[3].y - r.p[2].y);
	uden	= (r.p[3].x - r.p[2].x) * (r.p[3].x - r.p[2].x) + (r.p[3].y - r.p[2].y) * (r.p[3].y - r.p[2].y);
	u		= unum / uden;

	if (u < 0) u = 0;	if (u > 1) u = 1;

	sd.x	= r.p[2].x + u * (r.p[3].x - r.p[2].x);
	sd.y	= r.p[2].y + u * (r.p[3].y - r.p[2].y);

	dis_sd	= (float)fabs(cc.x - sd.x) * (float)fabs(cc.x - sd.x) + (float)fabs(cc.y - sd.y) * (float)fabs(cc.y - sd.y);
	dis_sd	= (float)sqrt(dis_sd);

	if (dis_sd <= rc)		result = true;

	dis_ep	= (float)fabs(cc.x - r.p[2].x) * (float)fabs(cc.x - r.p[2].x) + (float)fabs(cc.y - r.p[2].y) * (float)fabs(cc.y - r.p[2].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		result = true;

	dis_ep	= (float)fabs(cc.x - r.p[3].x) * (float)fabs(cc.x - r.p[3].x) + (float)fabs(cc.y - r.p[3].y) * (float)fabs(cc.y - r.p[3].y);
	dis_ep	= (float)sqrt(dis_ep);

	if (dis_ep <= rc)		result = true;

	//--------------------------------------------------------------------------------------------

	//if intersection, return angle between center of foot and head
	//else return -1
	if (result == true)
		return(angle);
	else
		return(-1);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_line_line
//
//	returns true if two lines collide
//
//------------------------------------------------------------------------------------------------

bool master_frame::cd_line_line(line l1, line l2)
{
	//unknown a/b numerator, common denominator
	float uanum, ubnum, uden;

	//unknown u1 and u2
	float u1, u2;

	//calculate unknowns u1 and u2
	uanum	= (l2.p[1].x - l2.p[0].x) * (l1.p[0].y - l2.p[0].y) - (l2.p[1].y - l2.p[0].y) * (l1.p[0].x - l2.p[0].x);
	ubnum	= (l1.p[1].x - l1.p[0].x) * (l1.p[0].y - l2.p[0].y) - (l1.p[1].y - l1.p[0].y) * (l1.p[0].x - l2.p[0].x);
	uden	= (l2.p[1].y - l2.p[0].y) * (l1.p[1].x - l1.p[0].x) - (l2.p[1].x - l2.p[0].x) * (l1.p[1].y - l1.p[0].y);

	//if uden = 0, division through zero doesn't matter since it's float
	u1		= uanum / uden;
	u2		= ubnum / uden;

	//lines coincident
	//both line segments part of the same line
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		//check if both lines are just one point
		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			//same point
			if (l1.p[0] == l2.p[0])
			{
				return(true);
			}

		//unrolled version
		//test both end points of line segemnts against other line
		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}


	//both line segments intersect if u1 and u2 both lie between 0 and 1
	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
		return(true);
	else
		//else no collision
		return(false);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_line_line
//
//	overloaded cd_line_line
//	takes additional point (reference) as argument which stores coordinates of collision
//	if no collision occurs argumented point remains unchanged and function returns false
//
//------------------------------------------------------------------------------------------------

bool master_frame::cd_line_line(line l1, line l2, point &p)
{
	//numerator
	//---------
	//denominator

	//unknown a/b numerator, common denominator
	float uanum, ubnum, uden;

	//unknown u1 and u2
	float u1, u2;

	//calculate unknowns u1 and u2
	uanum	= (l2.p[1].x - l2.p[0].x) * (l1.p[0].y - l2.p[0].y) - (l2.p[1].y - l2.p[0].y) * (l1.p[0].x - l2.p[0].x);
	ubnum	= (l1.p[1].x - l1.p[0].x) * (l1.p[0].y - l2.p[0].y) - (l1.p[1].y - l1.p[0].y) * (l1.p[0].x - l2.p[0].x);
	uden	= (l2.p[1].y - l2.p[0].y) * (l1.p[1].x - l1.p[0].x) - (l2.p[1].x - l2.p[0].x) * (l1.p[1].y - l1.p[0].y);

	//if uden = 0, division through zero doesn't matter since it's float
	u1		= uanum / uden;
	u2		= ubnum / uden;

	//if uden == 0, lines are parallel
	//(no _intersection_ possible in the mathematically correct sense of the word)
	//if uanum == 0 and ubnum == 0 and uden == 0, both line segments part of the same line
	//(also no intersection possible, but collision is)

	//lines coincident
	//both line segments part of the same line
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		//check if both lines are just one point
		if (l1.p[0] == l1.p[1] && l2.p[0] == l2.p[1])
			//same point
			if (l1.p[0] == l2.p[0])
			{
				//intersection point
				p		= l1.p[0];
				return(true);
			}

		//if the ending points of either line lie within the other line
		//intersection occurs at this point

		//unrolled version
		//test both end points of line segemnts against other line
		float dx, dy;
		float unum, uden, u;

		//l1.p[0] vs. l2
		dx		= l2.p[1].x - l2.p[0].x;
		dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[0].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[0].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			p	= l1.p[0];
			return(true);
		}
		//l1.p[1] vs. l2
		//same as above
		//dx		= l2.p[1].x - l2.p[0].x;
		//dy		= l2.p[1].y - l2.p[0].y;
		unum	= (l1.p[1].x - l2.p[0].x) * (l2.p[1].x - l2.p[0].x) +
				  (l1.p[1].y - l2.p[0].y) * (l2.p[1].y - l2.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			p	= l1.p[1];
			return(true);
		}
		//l2.p[0] vs. l1
		dx		= l1.p[1].x - l1.p[0].x;
		dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[0].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[0].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			p	= l2.p[0];
			return(true);
		}
		//l2.p[1] vs. l1
		//same as above
		//dx		= l1.p[1].x - l1.p[0].x;
		//dy		= l1.p[1].y - l1.p[0].y;
		unum	= (l2.p[1].x - l1.p[0].x) * (l1.p[1].x - l1.p[0].x) +
				  (l2.p[1].y - l1.p[0].y) * (l1.p[1].y - l1.p[0].y);
		//uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			p	= l2.p[1];
			return(true);
		}
	}

//un-unrolled
/*
		//four end points of lines
		point pe[4] = {l1.p[0], l1.p[1],
					   l2.p[0], l2.p[1]};
		//both lines to test against
		//(order is important, so that both points of one line are tested against
		//other line and not itself!)
		line l[2]	= {l2, l1};

		//for all four points
		for (int i = 0; i < 4; ++i)
		{
			int L = (int)(i / 2);
//			if (i == 0 || i == 1)		L = 0;
//			if (i == 2 || i == 3)		L = 1;
			float dx	= l[L].p[1].x - l[L].p[0].x;
			float dy	= l[L].p[1].y - l[L].p[0].y;
			float unum	= (pe[i].x - l[L].p[0].x) * (l[L].p[1].x - l[L].p[0].x) +
						  (pe[i].y - l[L].p[0].y) * (l[L].p[1].y - l[L].p[0].y);
			float uden	= dx * dx + dy * dy;
			float u		= unum / uden;

			//within line
			if (u >= 0 && u <= 1)
			{
				//intersection point
				p		= pe[i];
				return(true);
			}
		}*/

	//both line segments intersect if u1 and u2 both lie between 0 and 1
	if (u1 >= 0 && u1 <= 1 && u2 >= 0 && u2 <= 1)
	{
		//calculate point of intersection (point is reference)
		p.x	= l1.p[0].x + u1 * (l1.p[1].x - l1.p[0].x);
		p.y	= l1.p[0].y + u1 * (l1.p[1].y - l1.p[0].y);

		return(true);
	}
	else
		//else no collision
		return(false);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame cd_point_line
//
//	returns true if point lies on line
//
//------------------------------------------------------------------------------------------------

bool master_frame::cd_point_line(point p, line l)
{
	//special case: line segment also a point, both the same
	if (l.p[0] == l.p[1])
		if (p == l.p[0])
			return(true);
	//unknown a/b numerator, common denominator
	float uanum, ubnum, uden;

	//unknown u1 and u2
	//float u1, u2;

	//calculate unknowns u1 and u2
//	uanum	= (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3);
//	ubnum	= (x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3);
//	uden	= (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
	uanum	= (l.p[1].x - l.p[0].x) * (p.y - l.p[0].y) - (l.p[1].y - l.p[0].y) * (p.x - l.p[0].x);
	ubnum	= (p.x - p.x) * (p.y - l.p[0].y) - (p.y - p.y) * (p.x - l.p[0].x);
	uden	= (l.p[1].y - l.p[0].y) * (p.x - p.x) - (l.p[1].x - l.p[0].x) * (p.y - p.y);

	//if uden = 0, division through zero doesn't matter since it's float
	//u1		= uanum / uden;
	//u2		= ubnum / uden;

	//lines coincident
	//both line segments part of the same line
	if (uanum == 0 && ubnum == 0 && uden == 0)
	{
		//unrolled version
		//test both end points of line segemnts against other line
		float dx, dy;
		float unum, uden, u;

		//p vs. l
		dx		= l.p[1].x - l.p[0].x;
		dy		= l.p[1].y - l.p[0].y;
		unum	= (p.x - l.p[0].x) * (l.p[1].x - l.p[0].x) +
				  (p.y - l.p[0].y) * (l.p[1].y - l.p[0].y);
		uden	= dx * dx + dy * dy;
		u		= unum / uden;
		//within line
		if (u >= 0 && u <= 1)
		{
			return(true);
		}
	}

	//no collision
	return(false);

/*
	//old, nonworking version

	return false;

	//y - y1 = (y2 - x1) / (x2 - x1) * (x - x1)
	//m = (y1 - y2) / (x1 - x2)
	float m = (l.p[0].y - l.p[1].y) / (l.p[0].x - l.p[1].x);
	float D = (l.p[1].y - l.p[0].y) / (l.p[1].x - l.p[0].x);

//dd.typefont(0, 184, "", m, 5, 0, 1.0f, -1);
//dd.typefont(0, 200, "", D, 5, 0, 1.0f, -1);
//dd.typefont(0, 216, "", D * p.x - D * l.p[0].x + l.p[0].y, 5, 0, 1.0f, -1);

	float temp_index[4];
	if (l.p[0].y <= l.p[1].y)
	{
		temp_index[0] = l.p[0].y;		temp_index[1] = l.p[1].y;
	}
	else
	{
		temp_index[0] = l.p[1].y;		temp_index[1] = l.p[0].y;
	}
	if (l.p[0].x <= l.p[1].x)
	{
		temp_index[2] = l.p[0].x;		temp_index[3] = l.p[1].x;
	}
	else
	{
		temp_index[2] = l.p[1].x;		temp_index[3] = l.p[0].x;
	}

	//infinite slope?
	//int precision
	//if slope infinite (straight vertical line)

	//infinite slope
//	if (((int)p.y == (int)(D * p.x - D * l.p[0].x + l.p[0].y) ||
//		l.p[1].x - l.p[0].x == 0) &&
//		((int)p.y >= temp_index[0] && (int)p.y <= temp_index[1]) &&
//		((int)p.x >= temp_index[2] && (int)p.x <= temp_index[3]))
	if ((p.y == (D * p.x - D * l.p[0].x + l.p[0].y) ||
		l.p[1].x - l.p[0].x == 0) &&
		(p.y >= temp_index[0] && p.y <= temp_index[1]) &&
		(p.x >= temp_index[2] && p.x <= temp_index[3]))
	{
		//draw crossing line of intersection
		line a, b;
		a.p[0].x = 0;				a.p[0].y = p.y;
		a.p[1].x = 799;				a.p[1].y = p.y;
		b.p[0].x = p.x;				b.p[0].y = 0;
		b.p[1].x = p.x;				b.p[1].y = 599;

		RGBcolor ab;				ab.setcolor(lightblue);
		dd.drawline(a, ab);			dd.drawline(b, ab);

		//draw point of intersection
		RGBcolor cis;				cis.setcolor(red);
		dd.drawpoint(p, cis);

		return true;
	}
	else
	{
		return false;
	}*/
}

//------------------------------------------------------------------------------------------------
//
//	master_frame calculate shadows
//
//	calculates shadow data
//
//------------------------------------------------------------------------------------------------

void master_frame::calculate_shadows()
{
	//day, shadow below
	if (time.ch >= 7 &&time.ch < 19)
	{
		//s_scale.y	= 0.5f;
		s_scale.y	= 0.4f;
		s_scale.x	= -(((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 13) * 0.2f;
	}
	else
	{
		//night, above
		s_scale.y	= -0.4f;

		if (time.ch >= 0 && time.ch < 7)
			s_scale.x	= (((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 1) * 0.2f;
		if (time.ch >= 19 && time.ch <= 23)
			s_scale.x	= (((float)time.ch + (float)time.cm / 60 + (float)time.cs / 60 / 60) - 25) * 0.2f;
	}

	//floor according to zoomfactor
	s_mpy = S_PYDEF + (int)((S_FLOOR - S_PYDEF) * option.data.zoomfactor);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame auto_side_switch
//
//	switches sides of player when crossing
//
//------------------------------------------------------------------------------------------------

void master_frame::auto_side_switch()
{
	//---- guard block ---------------------------------------------------------------------------

	//both players
	for (register int p = 0; p < 2; ++p)
	{
		//if any guard
		if (P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_GUARD_ARMS] ||
			P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_GUARD_LEGS] ||
			P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_GUARD_FULL])
		{
			//if too close
			if (player_distance < 40.0f)
			{
				//push other player
				P[!p].gl_SetPush(2, 0.035f, 0);

				//results in jerky resets if player already within < 40.0f
/*				//reset other players position
				if (P[p].side == SLEFT)
				{
//					P[!p].sk.p_ref->v.p[0].x = P[p].sk.p_ref->v.p[0].x + 40.0f;
				}
				else
				{
					P
//					P[!p].sk.p_ref->v.p[0].x = P[p].sk.p_ref->v.p[0].x - 40.0f;
				}

				//cancel walk/slide fwd animation
				if (P[!p].p_aslot[aslot_cycle] == P[!p].p_anmn[P[!p].asi][AN_WALK_FWD] ||
					P[!p].p_aslot[aslot_cycle] == P[!p].p_anmn[P[!p].asi][AN_WALK_SLIDE_FWD])
				{
					P[!p].al_deactivate_slot(aslot_cycle);
				}*/
			}
		}
	}

	//---- auto side switch ----------------------------------------------------------------------

	switch (P[P1].side)
	{
		//if on left
		case (SLEFT):
		{
			//if to the right of other player switch sides
			if (P[P1].sk.p_ref->v.p[0].x > P[P2].sk.p_ref->v.p[0].x + 10)
			{
				P[P1].set_side(SRIGHT);
				P[P2].set_side(SLEFT);
			}

			break;
		}

		case (SRIGHT):
		{
			if (P[P1].sk.p_ref->v.p[0].x < P[P2].sk.p_ref->v.p[0].x - 10)
			{
				P[P1].set_side(SLEFT);
				P[P2].set_side(SRIGHT);
			}

			break;
		}
	}

	//---- pushing and pulling -------------------------------------------------------------------

	//for both players
	//since it's checked every frame the push/drag effect is stronger the nearer the
	//opponent is (unintentional effect)
	for (p = 0; p < 2; ++p)
	{
		//if pushing (forward animation)
		if (P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_PUSH_ARMS] &&
			(P[p].p_aslot[aslot_action]->pkf[P[p].cki[ball]].dir == 0 ||
			P[p].p_aslot[aslot_action]->pkf[P[p].cki[balr]].dir == 0))
		{
//!!
//if (P[p].p_aslot[aslot_action]->gl_attack[p] == 1)
//	break;

			//pushed bone, -1 no hit
			int bone = -1;

			//both fists against opponents torso, neck and head
			if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[btul].v) ||
				cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[btul].v))	bone = btul;
			if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[btur].v) ||
				cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[btur].v))	bone = btur;
			if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[btll].v) ||
				cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[btll].v))	bone = btll;
			if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[btlr].v) ||
				cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[btlr].v))	bone = btlr;
			if (cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
								 P[!p].sk.chead, P[!p].sk.radius_head) != -1 ||
				cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
								 P[!p].sk.chead, P[!p].sk.radius_head) != -1)				bone = bn;
			if (bone != -1)
			{
				//set hit animation
				P[!p].gl_SetHitBone(bone, 20);

				//set minimum damage if not already set
				if (!P[p].p_aslot[aslot_action]->gl_attack[p])
				{
					//set hit registered
					P[p].p_aslot[aslot_action]->gl_attack[p]	= 1;

					//reset combo data so pushing won't get registered as combo action
					//(with previous hit)
					P[!p].t_combo_lasthit	= 0;
					P[!p].combo_counter		= 0;
					P[!p].combo_damage		= 0;
					int dummy_defbi				= -1;
					float dummy_t_move[2][2]	= {0};
					P[!p].gl_process_damage_def(bone, 1.0f, dummy_defbi, dummy_t_move, false, false);
					//reset combo data so pushing won't get registered as combo action
					//(with following hit)
					P[!p].t_combo_lasthit	= 0;
					P[!p].combo_counter		= 0;
					P[!p].combo_damage		= 0;

					//bone flash
					rcd.time[!p][bone]	= time.current;
				}

				//sound
				//s_buffer[S_HIT_TAP]	= SB_PLAY;

				//push other player
				//stronger push if rushing forward
				if (P[p].p_aslot[aslot_cycle] == P[p].p_anmn[P[p].asi][AN_WALK_SLIDE_FWD])
					P[!p].gl_SetPush(2, 0.6f, 0);
				else
					P[!p].gl_SetPush(2, 0.4f, 95);

				//push message
				if (option.data.show_pmessages)
					P[!p].pmessage.set_message(PM_PUSHPULL, yellow, "Pushed!");
			}
		}

		//if pulling (backward animation)
		if (P[p].p_aslot[aslot_action] == P[p].p_anmn[P[p].asi][AN_PULL_ARMS] &&
			(P[p].p_aslot[aslot_action]->pkf[P[p].cki[ball]].dir == 1 ||
			P[p].p_aslot[aslot_action]->pkf[P[p].cki[balr]].dir == 1))
		{
			//circle to rectangle and circle to circle test
			//(fwd fist against opponents arms and fists)
			if (P[p].asi == 0 || P[p].asi == 2)
			{
				if (cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[baul].v) ||
					cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[ball].v) ||
					cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[baur].v) ||
					cd_circle_rect(P[p].sk.cfistl, P[p].sk.radius_fist, P[!p].sk.b[balr].v) ||
					cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
									 P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1 ||
					cd_circle_circle(P[p].sk.cfistl, P[p].sk.radius_fist,
									 P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
				{
					//set fatigue if not already set
					if (!P[p].p_aslot[aslot_action]->gl_attack[p])
					{
						//set pull registered
						P[p].p_aslot[aslot_action]->gl_attack[p]	= 1;

						//fatigue
						P[!p].gl_fatigue_add(0, 0, 10.0f * option.data.fom_multiplier);
					}

					//pull other player
					P[!p].gl_SetPush(4, 0.3f, 80);


					//pull message
					if (option.data.show_pmessages)
						P[!p].pmessage.set_message(PM_PUSHPULL, yellow, "Pulled!");
				}
			}
			else
			{
				if (cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[baul].v) ||
					cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[ball].v) ||
					cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[baur].v) ||
					cd_circle_rect(P[p].sk.cfistr, P[p].sk.radius_fist, P[!p].sk.b[balr].v) ||
					cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
									 P[!p].sk.cfistl, P[!p].sk.radius_fist) != -1 ||
					cd_circle_circle(P[p].sk.cfistr, P[p].sk.radius_fist,
									 P[!p].sk.cfistr, P[!p].sk.radius_fist) != -1)
				{
					//set fatigue if not already set
					if (!P[p].p_aslot[aslot_action]->gl_attack[p])
					{
						//set pull registered
						P[p].p_aslot[aslot_action]->gl_attack[p]	= 1;

						//fatigue
						P[!p].gl_fatigue_add(0, 0, 10.0f * option.data.fom_multiplier);
					}

					//pull other player
					P[!p].gl_SetPush(4, 0.3f, 80);

					//pull message
					if (option.data.show_pmessages)
						P[!p].pmessage.set_message(PM_PUSHPULL, yellow, "Pulled!");
				}
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame process_mousecursor
//
//	handles mousecursor position data and draws cursor
//
//------------------------------------------------------------------------------------------------

void master_frame::process_mousecursor(int type)		//cursor type
														//0 = standard
														//1 = rotating yinyang
														//2 = fist
{
	//don't process if console open
	if (con.state)
		return;

	//lock backbuffer if yinyang/fist cursor
	if (type == 1 || type == 2)
		if (!dd.BBLock())
			return;

	//for both cursor
//	for (int c = 0; c < 2; ++c)
	//draw first cursor last
	for (int c = 1; c > -1; --c)
	{
		//if active
		if (mcursor[c].active)
		{
			//process cursor
			//passed time since last update and input data
			mcursor[c].process((float)time.sca,
							   is.dimouse[mcursor[c].mouse_index].lX,
							   is.dimouse[mcursor[c].mouse_index].lY,
							   is.dimouse[mcursor[c].mouse_index].lZ,
							   is.dimouse[mcursor[c].mouse_index].rgbButtons[0],
							   is.dimouse[mcursor[c].mouse_index].rgbButtons[1],
							   is.dimouse[mcursor[c].mouse_index].rgbButtons[2],
							   is.dimouse[mcursor[c].mouse_index].rgbButtons[3]);

			//bitmap cursor
			if (type == 0)
			{
				//don't give the original or else it will be clipped
				RECT r = mcursor[c].r_off;
				//draw bitmap cursor
				dd.blitrect(dd.rSCREEN169, r, mcursor[c].r_scr);
			}

			//yinyang
			if (type == 1)
			{
				//draw yin yang cursor (manual lock)
				dd.drawyinyang(mcursor[c].yy, 1);
			}

			//fist
			if (type == 2)
			{
				//draw fist in players fist color (manual lock)
				dd.drawfist(mcursor[c].pos.x - 6, mcursor[c].pos.y - 6, option.data.fistcolor[mcursor[c].mouse_index - 1], 1);
			}
		}
	}

	//cursor collision detection
	if ((mcursor[P1].collidable && mcursor[P2].collidable) &&
		(is.mouseALL()))
	{
		//displacement force
		ipoint v(1, 1);

		//which type of collision detection
		//bitmap = RECT, yinyang = rectangle, fist = circle
		//bitmap
		if (type == 0)
		{
			while (CD_rect_rect((rectangle)mcursor[P1].r_scr, (rectangle)mcursor[P2].r_scr))
			{
				//
				//playsound_g(BT_P1, S_HIT_TAP);

				//hit rectangle (including subframe movements)
				dd.drawrectangle_uf(mcursor[P1].r_scr, red);
				dd.drawrectangle_uf(mcursor[P2].r_scr, blue);

				//relative distance of x and y positions
				float diffx = (float)fabs(mcursor[P1].pos.x - mcursor[P2].pos.x);
				float diffy = (float)fabs(mcursor[P1].pos.y - mcursor[P2].pos.y);

				//calculate angle in rad between two circles (from point of hit circle)
				float angle = (float)atan2(mcursor[P1].pos.y - mcursor[P2].pos.y, mcursor[P1].pos.x - mcursor[P2].pos.x);

				//convert in degree
				angle = angle * 180 / PI;

				//check for limits
				if (angle < 0)		angle += 360;
				if (angle > 359)	angle -= 360;

				//displacement direction
				if (angle >= 112.5 && angle <= 247.5)
				{
					mcursor[P1].add_input_data(-v.x, 0);
					mcursor[P2].add_input_data(v.x, 0);
				}
				if (angle >= 292.5 || angle <= 67.5)
				{
					mcursor[P1].add_input_data(v.x, 0);
					mcursor[P2].add_input_data(-v.x, 0);
				}
				if (angle >= 22.5 && angle <= 157.5)
				{
					mcursor[P1].add_input_data(0, v.y);
					mcursor[P2].add_input_data(0, -v.y);
				}
				if (angle >= 202.5 && angle <= 337.5)
				{
					mcursor[P1].add_input_data(0, -v.y);
					mcursor[P2].add_input_data(0, v.y);
				}
/*				if (angle > 90 && angle < 270)
				{
					mcursor[P1].add_input_data(-v, 0);
					mcursor[P2].add_input_data(v, 0);
				}
				else
				{
					mcursor[P1].add_input_data(v, 0);
					mcursor[P2].add_input_data(-v, 0);
				}
				if (angle > 0 && angle < 180)
				{
					mcursor[P1].add_input_data(0, v);
					mcursor[P2].add_input_data(0, -v);
				}
				else
				{
					mcursor[P1].add_input_data(0, -v);
					mcursor[P2].add_input_data(0, v);
				}*/

				//calculate mouse data (no rotation)
				mcursor[P1].process(0, 0, 0, 0, 0, 0, 0, 0);
				mcursor[P2].process(0, 0, 0, 0, 0, 0, 0, 0);
			}
		}
		//yinyang
		if (type == 1)
		{
			while (CD_rect_rect(mcursor[P1].yy.r[6], mcursor[P2].yy.r[6]))
//			if (CD_rect_rect(mcursor[P1].yy.r[6], mcursor[P2].yy.r[6]))
			{
				//
				//playsound_g(BT_P1, S_HIT_TAP);

				//hit rectangle (including subframe movements)
				dd.drawrectangle_uf(mcursor[P1].yy.r[6], red, 1);
				dd.drawrectangle_uf(mcursor[P2].yy.r[6], red, 1);

				//relative distance of x and y positions
				float diffx = (float)fabs(mcursor[P1].pos.x - mcursor[P2].pos.x);
				float diffy = (float)fabs(mcursor[P1].pos.y - mcursor[P2].pos.y);

				//calculate angle in rad between two circles (from point of hit circle)
				float angle = (float)atan2(mcursor[P1].pos.y - mcursor[P2].pos.y, mcursor[P1].pos.x - mcursor[P2].pos.x);

				//convert in degree
				angle = angle * 180 / PI;

				//check for limits
				if (angle < 0)		angle += 360;
				if (angle > 359)	angle -= 360;

				//displacement
/*				v.setpoint(is.dimouse[mcursor[P1].mouse_index].lX -
						   is.dimouse[mcursor[P2].mouse_index].lX,
						   is.dimouse[mcursor[P1].mouse_index].lY - 
						   is.dimouse[mcursor[P2].mouse_index].lY);*/
/*				mcursor[P1].add_input_data(-is.dimouse[mcursor[P1].mouse_index].lX,
										   -is.dimouse[mcursor[P1].mouse_index].lY);
//				mcursor[P2].add_input_data(is.dimouse[mcursor[P1].mouse_index].lX / 2,
//										   is.dimouse[mcursor[P1].mouse_index].lY / 2);
//				mcursor[P1].add_input_data(is.dimouse[mcursor[P2].mouse_index].lX / 2,
//										   is.dimouse[mcursor[P2].mouse_index].lY / 2);
				mcursor[P2].add_input_data(-is.dimouse[mcursor[P2].mouse_index].lX,
										   -is.dimouse[mcursor[P2].mouse_index].lY);
*/				//displacement direction
				if (angle >= 112.5 && angle <= 247.5)
				{
					mcursor[P1].add_input_data(-v.x, 0);
					mcursor[P2].add_input_data(v.x, 0);
				}
				if (angle >= 292.5 || angle <= 67.5)
				{
					mcursor[P1].add_input_data(v.x, 0);
					mcursor[P2].add_input_data(-v.x, 0);
				}
				if (angle >= 22.5 && angle <= 157.5)
				{
					mcursor[P1].add_input_data(0, v.y);
					mcursor[P2].add_input_data(0, -v.y);
				}
				if (angle >= 202.5 && angle <= 337.5)
				{
					mcursor[P1].add_input_data(0, -v.y);
					mcursor[P2].add_input_data(0, v.y);
				}

				//calculate mouse data (no rotation)
				mcursor[P1].process(0, 0, 0, 0, 0, 0, 0, 0);
				mcursor[P2].process(0, 0, 0, 0, 0, 0, 0, 0);
				//calculate new yinyang cursor position
				mcursor[P1].yy.calculate();
				mcursor[P2].yy.calculate();
			}
		}
		//fist
		if (type == 2)
		{
			//get and compare angle between 2 circle cursor
			float angle = -1;
			while (-1 != (angle = cd_circle_circle(mcursor[P1].pos, 6, mcursor[P2].pos, 6)))
			{
				//
				//playsound_g(BT_P1, S_HIT_TAP);
	
				//hit circle (including subframe movements)
				dd.drawcircle(mcursor[P1].pos.x, mcursor[P1].pos.y, 6, red, 1);
				dd.drawcircle(mcursor[P2].pos.x, mcursor[P2].pos.y, 6, red, 1);

				//displacement direction
				if (angle >= 112.5 && angle <= 247.5)
				{
					mcursor[P1].add_input_data(-v.x, 0);
					mcursor[P2].add_input_data(v.x, 0);
				}
				if (angle >= 292.5 || angle <= 67.5)
				{
					mcursor[P1].add_input_data(v.x, 0);
					mcursor[P2].add_input_data(-v.x, 0);
				}
				if (angle >= 22.5 && angle <= 157.5)
				{
					mcursor[P1].add_input_data(0, v.y);
					mcursor[P2].add_input_data(0, -v.y);
				}
				if (angle >= 202.5 && angle <= 337.5)
				{
					mcursor[P1].add_input_data(0, -v.y);
					mcursor[P2].add_input_data(0, v.y);
				}

				//calculate mouse data (no rotation)
				mcursor[P1].process(0, 0, 0, 0, 0, 0, 0, 0);
				mcursor[P2].process(0, 0, 0, 0, 0, 0, 0, 0);
			}
		}
	}

	//unlock backbuffer if not already unlocked
	if (type == 1 || type == 2)
		dd.BBUnlock();

	return;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame game_startup
//
//	startup sequence of game
//	moves in borders with names and winning points
//	then zooms in players
//
//------------------------------------------------------------------------------------------------

void master_frame::game_startup(float t_border, float t_pause, float t_zoom)
{
	//verify times
	if (t_border < 0.01f)			t_border	= 0.01f;
	if (t_border > 10.0f)			t_border	= 10.f;
	if (t_pause < 0.01f)			t_pause		= 0.01f;
	if (t_pause > 10.0f)			t_pause		= 10.f;
	if (t_zoom < 0.01f)				t_zoom		= 0.01f;
	if (t_zoom > 10.0f)				t_zoom		= 10.f;

	//---- border move ---------------------------------------------------------------------------

	//start time
	LONGLONG t_start = time.current;

	//time in seconds passed since start of bordermove
	double t_pass = (time.current - t_start) / (double)time.freq;

	//static and moving borders (one background, other border itself)
	RECT b_upper, b_lower, b_mupper, b_mlower;

	//color of border (black by default), color of background (white)
	RGBcolor	bc(BORDERCOLOR);
	RGBcolor	bgc(option.data.cbackground);

	//set static and moving borders to "in" position
	fillRECT(b_upper, 0, 0, 800, 300);	fillRECT(b_lower, 0, 300, 800, 600);
	b_mupper = b_upper;					b_mlower = b_lower;

	//while time passed since start is <= than time of move
	while (t_start + (time.freq * t_border) >= time.current)
	{
//!! ??
if (is.dikey[DIK_ESCAPE] & 0x80)
	t_start = 0;
		//increase, decrease y-values of moving boarders
		fillRECT(b_mupper, 0, 0, 800, (int)(b_upper.bottom - 225 / t_border * t_pass));
		fillRECT(b_mlower, 0, (int)(b_lower.top + 225 / t_border * t_pass), 800, 600);

		//fill area of upper border with background color
		dd.colorfill(b_upper, bgc);
		//fill area of upper border with border
		dd.colorfill(b_mupper, bc);

		//same with lower area
		dd.colorfill(b_lower, bgc);
		dd.colorfill(b_mlower, bc);

		//draw names and winning points
		RECT	r_plname1, r_plname2;
		r_plname1.left = 0;		r_plname1.right = 399;
		r_plname2.left = 400;	r_plname2.right = 799;
		dd.typefont((int)centerfont(option.data.name[P1], r_plname1, 0.35f).x,
					29,
					option.data.name[P1], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
		dd.typefont((int)centerfont(option.data.name[P2], r_plname2, 0.35f).x,
					29,
					option.data.name[P2], 0, 0, 1, 0.35f, 0, 0, 0, 255, 255, 255);
//		dd.drawwinpoints(P[P1].winloss, (int)centerfont(option.data.name[P1], r_plname1, 0.35f).x, P[P2].winloss, (int)centerfont(option.data.name[P2], r_plname2, 0.35f).x, option.data.bw_mode, option.data.rounds);
		dd.drawwinpoints(option.data.rounds, option.data.bw_mode, option.data.roundtime,
						 data_ig.gl_winpoints,
						 option.data.fistcolor[P1], option.data.fistcolor[P2]);
		//update round time string
		if (option.data.roundtime)
		{
			process_roundtime(true);
			dd.typefont(1 + (int)centerfont(data_ig.rts, dd.rSCREEN169, 0.45f).x,
						(int)((75.0f / 2.0f) - (48.0f * 0.45f / 2.0f)),
						data_ig.rts, 0, 0, 1, 0.45f, 0, 0, 0, 255, 255, 255);
		}

		//show change
		dd.flip(option.data.vsync);

		//update *pt_current and t_pass
		QueryPerformanceCounter((LARGE_INTEGER*) &time.current);
		t_pass = (time.current - t_start) / (double)time.freq;
	}

	//---- pause ---------------------------------------------------------------------------------

	//set start and passed time
	t_start = time.current;
	t_pass = (time.current - t_start) / (double)time.freq;

	//idle
	while (t_start + (time.freq * t_pause) > time.current)
	{
if (is.dikey[DIK_ESCAPE] & 0x80)
	t_start = 0;
		//update timer
		QueryPerformanceCounter((LARGE_INTEGER*) &time.current);
		t_pass = (time.current - t_start) / (double)time.freq;
	}

	//---- zoom in -------------------------------------------------------------------------------

	//set start and passed time
	t_start = time.current;
	t_pass = (time.current - t_start) / (double)time.freq;
	//set zoomfactor
	option.data.zoomfactor = 0.01f;

	//while time passed since start is <= than time of move
//	while (t_start + (time.freq * t_zoom) > time.current)
	while (option.data.zoomfactor < 1.0f)
	{
if (is.dikey[DIK_ESCAPE] & 0x80)
t_start = 0;
		//zoom
		//option.data.zoomfactor = 1.0f / t_zoom * (float)t_pass * option.data.speed;
		option.data.zoomfactor = 1.0f / t_zoom * (float)t_pass;

		//draw background
		dd.drawbackground(option.data.cbackground.r, option.data.cbackground.g, option.data.cbackground.b, 1, 1, 1);

		//calculate shadow data
		calculate_shadows();

		//set players skeleton to zoomfaktor and default animation keyframe
		P[P1].set_keyframe(AN_DEFAULT, 0, option.data.zoomfactor);
		P[P2].set_keyframe(AN_DEFAULT, 0, option.data.zoomfactor);

		//calculate skeleton
		P[P1].process_bones(s_scale, s_mpy);
		P[P2].process_bones(s_scale, s_mpy);

		//sort z
		quicksort_zb(pd.pzb, 0, 37, 1);

		//render scene
		dd.drawscene(&pd, 0, 0, black, 0, 0, 0);

		//show change
		dd.flip(option.data.vsync);

		//update timer
		QueryPerformanceCounter((LARGE_INTEGER*) &time.current);
		t_pass = (time.current - t_start) / (double)time.freq;
	}

	//reset zoomfactor
	option.data.zoomfactor = 1.0f;
}


//------------------------------------------------------------------------------------------------
//
//	master_frame dev_showdata
//
//	shows all relevant animation data on screen
//
//------------------------------------------------------------------------------------------------

void master_frame::dev_showdata()
{
	//print showdata, devmode state, showref, animate
	dd.typebmf(8, 24, bmfwhite, "show/dm: %i %i", (int)dev_s_showdata, (int)dev_s_devmode);
	dd.typebmf(8, 40, bmfwhite, "showref: %i", (int)dev_s_showref);
	dd.typebmf(8, 56, bmfwhite, "animate: %i", (int)dev_s_animate);

	//draw extra bars
	RECT		eb;
	fillRECT(eb, 0, 75, 800, 150);		dd.colorfill(eb, blue);
	fillRECT(eb, 0, 450, 800, 525);		dd.colorfill(eb, blue);

	//draw floor lines
	line	floor_up(0, S_FLOOR, 799, S_FLOOR),
			floor_lo(0, S_FLOOR + 10, 799, S_FLOOR + 10);
	dd.drawline(floor_up, green);
	dd.drawline(floor_lo, blue);

	//print current bone index
	dd.typebmf(8, 33 * 16, bmfwhite, "%i", (int)dev_bi[P1]);
//	dd.typebmf(17 * 8, 33 * 16, 1, "%i", (int)dev_bi[P2]);

	//print angle, length width and position of selected bone for both players
	dd.typebmf(1 * 8, 34 * 16, bmfwhite, "angle: %.1f", P[P1].sk.b[dev_bi[P1]].angle);
	dd.typebmf(1 * 8, 35 * 16, bmfwhite, "lngth: %.1f", P[P1].sk.b[dev_bi[P1]].length);
	dd.typebmf(1 * 8, 36 * 16, bmfwhite, "width: %.1f", P[P1].sk.b[dev_bi[P1]].width);
	dd.typebmf(5 * 8, 33 * 16, bmfwhite, "%i", (int)P[P1].sk.b[dev_bi[P1]].v.p[0].x);
	dd.typebmf(9 * 8, 33 * 16, bmfwhite, "%i", (int)P[P1].sk.b[dev_bi[P1]].v.p[0].y);

//	dd.typefont(17 * 8, 34 * 16, "angle:");		dd.typefont(24 * 8, 34 * 16, "", P[P2].sk.b[dev_bi[P2]].angle, 1);
//	dd.typefont(17 * 8, 35 * 16, "lengt:");		dd.typefont(24 * 8, 35 * 16, "", P[P2].sk.b[dev_bi[P2]].length, 1);
//	dd.typefont(17 * 8, 36 * 16, "width:");		dd.typefont(24 * 8, 36 * 16, "", P[P2].sk.b[dev_bi[P2]].width, 1);
//	dd.typefont(21 * 8, 33 * 16, "", P[P2].sk.b[dev_bi[P2]].v.p[0].x, 0);
//	dd.typefont(25 * 8, 33 * 16, "", P[P2].sk.b[dev_bi[P2]].v.p[0].y, 0);

	//damage, fatigue, arm stance
	dd.typebmf(1 * 8, 5 * 16, bmfwhite, "fatigu: %.1f %.1f", P[P1].fatigue, P[P2].fatigue);
	dd.typebmf(1 * 8, 6 * 16, bmfwhite, "damage: %i %i", P[P1].sk.b[dev_bi[P1]].damage, P[P2].sk.b[dev_bi[P2]].damage);
	dd.typebmf(1 * 8, 7 * 16, bmfwhite, "a_stnc: %i %i", (int)P[P1].stance_arms, (int)P[P2].stance_arms);

	//---- reference skeletons -------------------------------------------------------------------

	if (dev_s_showref)
		for (register int i = 0; i < 19; ++i)
		{
			//skeletons (if set)
			if (dev_hsk[0].p[0].x != 0 && dev_hsk[0].p[1].x != 0)
				dd.drawrectangle_uf(dev_hsk[i], red);
			if (dev_esk[0][0].p[0].x != 0 && dev_esk[0][0].p[1].x != 0)
				dd.drawrectangle_uf(dev_esk[0][i], blue);
			if (dev_esk[1][0].p[0].x != 0 && dev_esk[1][0].p[1].x != 0)
				dd.drawrectangle_uf(dev_esk[1][i], green);
		}

	//---- animation data ------------------------------------------------------------------------

	//mark cai, ckfi
	RECT	r;	fillRECT(r, 31 * 8, 33 * 16, 40 * 8, 34 * 16);	dd.drawrectangle_f(r, blue);
	fillRECT(r, 31 * 8, 35 * 16, 40 * 8, 36 * 16);				dd.drawrectangle_f(r, red);

	//mark data of current bone index
	fillRECT(r, (dev_bi[P1] * 4 + 13) * 8 - 2, 450, (dev_bi[P1] * 4 + 13) * 8 + 24, 525);
	dd.drawrectangle_f(r, green);

	//mark hara data
	fillRECT(r, 735, 450, 799, 525);							dd.drawrectangle_f(r, darkgreen);
	fillRECT(r, 735, 466, 799, 482),							dd.drawrectangle_f(r, green);

	//current animation index, number of keyframes, current keyframe index
	dd.typebmf(32 * 8, 33 * 16, bmfwhite, "cai: %i", dev_cai);
	dd.typebmf(32 * 8, 34 * 16, bmfwhite, "nokf: %i", p_dev_a[P[P1].asi][dev_cai]->nokf);
	dd.typebmf(32 * 8, 35 * 16, bmfwhite, "ckfi: %i", dev_ckf);

	//keyframe time
	dd.typebmf(1 * 8, 32 * 16, bmfwhite, "t_frame[%i]:", (int)dev_bi[P1]);
	for (register int i = 0; i < 19; ++i)
		dd.typebmf((i * 4 + 13) * 8, 32 * 16, bmfwhite, "%i", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[i]);
	//hara x, y time
	dd.typebmf(92 * 8, 32 * 16, bmfwhite, "%i %i", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19], p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20]);

	//animation priority
	dd.typebmf(1 * 8, 31 * 16, bmfwhite, "priority:");
	for (i = 0; i < 19; ++i)
		dd.typebmf((i * 4 + 13) * 8, 31 * 16, bmfwhite, "%i", p_dev_a[P[P1].asi][dev_cai]->priority[i]);
	//hara x, y priority
	dd.typebmf(92 * 8, 31 * 16, bmfwhite, "%i %i", p_dev_a[P[P1].asi][dev_cai]->priority[19], p_dev_a[P[P1].asi][dev_cai]->priority[20]);

	//angle current
	dd.typebmf(1 * 8, 28 * 16, bmfwhite, "angle_cu:");
	for (i = 0; i < 19; ++i)
		dd.typebmf((i * 4 + 13) * 8, 28 * 16, bmfwhite, "%i", (int)P[P1].sk.b[i].angle);
	//angle in keyframe
	dd.typebmf(1 * 8, 29 * 16, bmfwhite, "angle_kf:");
	for (i = 0; i < 19; ++i)
		dd.typebmf((i * 4 + 13) * 8, 29 * 16, bmfwhite, "%i", (int)p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[i]);

	//mode_a
	dd.typebmf(1 * 8, 30 * 16, bmfwhite, "mode_a:");
	for (i = 0; i < 19; ++i)
		dd.typebmf((i * 4 + 13) * 8, 30 * 16, bmfwhite, "%i", (int)p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[i]);
	//mode_h
//	dd.typefont(92 * 8, 30 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.x, 0);
//	dd.typefont(96 * 8, 30 * 16, "", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.y, 0);

	//hara x, y
	dd.typebmf(92 * 8, 29 * 16, bmfwhite, "%i %i", (int)p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x, (int)p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y);
	//hara x, y offset in reference to hara reference position
	if (P[P1].stance_feet == SLEFT)
		dd.typebmf(92 * 8, 28 * 16, bmfwhite, "%i %i", (int)(P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x), (int)(P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y));
	else
		//!! wrong?
		dd.typebmf(92 * 8, 28 * 16, bmfwhite, "%i %i", (int)(P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x), (int)(P[P1].sk.p_ref->v.p[1].y - dev_hsk[1].p[0].y));

	//keyframe type, action, dir
	dd.typebmf(44 * 8, 33 * 16, bmfwhite, "tpe: %i", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].type);
	dd.typebmf(44 * 8, 34 * 16, bmfwhite, "act: %i", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].action);
	dd.typebmf(44 * 8, 35 * 16, bmfwhite, "dir: %i", p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir);

	//animation id, cycle, ui_index, ui_bias
	dd.typebmf(53 * 8, 33 * 16, bmfwhite, "id: %i", p_dev_a[P[P1].asi][dev_cai]->id);
	dd.typebmf(53 * 8, 35 * 16, bmfwhite, "uii: %i", p_dev_a[P[P1].asi][dev_cai]->ui_index);
	dd.typebmf(53 * 8, 36 * 16, bmfwhite, "uib: %i", p_dev_a[P[P1].asi][dev_cai]->ui_bias);
//	dd.typefont(53 * 8, 34 * 16, "cyc:");
//	dd.typefont(58 * 8, 34 * 16, "", p_dev_a[P[P1].asi][dev_cai]->cycle, 0);

	//formula
	dd.typebmf(66 * 8, 33 * 16, bmfwhite, "h Xpn Ypn %i %i %i %i",
			   (int)p_dev_a[P[P1].asi][dev_cai]->h_diffp.x,
			   (int)p_dev_a[P[P1].asi][dev_cai]->h_diffn.x,
			   (int)p_dev_a[P[P1].asi][dev_cai]->h_diffp.y,
			   (int)p_dev_a[P[P1].asi][dev_cai]->h_diffn.y);
	dd.typebmf(66 * 8, 34 * 16, bmfwhite, "a p/n: %i %i", (int)p_dev_a[P[P1].asi][dev_cai]->a_diffp[dev_bi[P1]], (int)p_dev_a[P[P1].asi][dev_cai]->a_diffn[dev_bi[P1]]);
	dd.typebmf(66 * 8, 35 * 16, bmfwhite, "l p/n: %i %i", (int)p_dev_a[P[P1].asi][dev_cai]->l_diffp[dev_bi[P1]], (int)p_dev_a[P[P1].asi][dev_cai]->l_diffn[dev_bi[P1]]);
	dd.typebmf(66 * 8, 36 * 16, bmfwhite, "w p/n: %i %i", (int)p_dev_a[P[P1].asi][dev_cai]->w_diffp[dev_bi[P1]], (int)p_dev_a[P[P1].asi][dev_cai]->w_diffn[dev_bi[P1]]);

/*	//sound id, fatigue, damage, special
	dd.typefont(1 * 8, 31 * 16, "sound-id fatigue damage special");
	dd.typefont(1 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->sound_id, 0);
	dd.typefont(10 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->fatigue, 0);
	dd.typefont(18 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->damage, 0);
//	dd.typefont(25 * 8, 32 * 16, "", p_dev_a[P[P1].asi][dev_cai]->special, 0);*/
};

//------------------------------------------------------------------------------------------------
//
//	master_frame dev_edit
//
//	skeleton and animation editor
//
//------------------------------------------------------------------------------------------------

void master_frame::dev_edit()
{
	//---- reference skeletons -------------------------------------------------------------------

	//switch ref sk on/off
	if (is.dikey1D[DIK_5] & 0x80)
	{
		hud_add_message(0, bmfgreen, "reference skeletons: %i", (int)!dev_s_showref);
		dev_s_showref = !dev_s_showref;
	}

	//set hara reference
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD1] & 0x80)
	{
		for (register int i = 0; i < 19; ++i)
			dev_hsk[i] = P[P1].sk.b[i].v;
		hud_add_message(0, bmfgreen, "hara reference set");
		playsound_s(S_MENTER);
	}
	//set editor reference 1
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD2] & 0x80)
	{
		for (register int i = 0; i < 19; ++i)
			dev_esk[0][i] = P[P1].sk.b[i].v;
		hud_add_message(0, bmfgreen, "editor reference 1 set");
		playsound_s(S_MENTER);
	}
	//set editor reference 2
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD3] & 0x80)
	{
		for (register int i = 0; i < 19; ++i)
			dev_esk[1][i] = P[P1].sk.b[i].v;
		hud_add_message(0, bmfgreen, "editor reference 2 set");
		playsound_s(S_MENTER);
	}
	//del reference 1
	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD2] & 0x80)
	{
		dev_esk[0][0].p[0].x	= dev_esk[0][1].p[1].x = 0;
		hud_add_message(0, bmfgreen, "editor reference 1 deleted");
		playsound_s(S_MSELECT);
	}
	//del reference 2
	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD3] & 0x80)
	{
		dev_esk[1][0].p[0].x	= dev_esk[1][1].p[1].x = 0;
		hud_add_message(0, bmfgreen, "editor reference 2 deleted");
		playsound_s(S_MSELECT);
	}

	//load hara.x
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_NUMPAD0] & 0x80)
	{
		if (P[P1].stance_feet == SLEFT)
			P[P1].sk.p_ref->v.p[0].x = dev_hsk[0].p[0].x;
		else
			P[P1].sk.p_ref->v.p[0].x = dev_hsk[1].p[0].x;
		hud_add_message(0, bmfgreen, "hara.x loaded");
		playsound_s(S_MENTER);
	}
	//load hara.y
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey1D[DIK_DECIMAL] & 0x80)
	{
		if (P[P1].stance_feet == SLEFT)
			P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y;
		else
			P[P1].sk.p_ref->v.p[0].y = dev_hsk[1].p[0].y;
		hud_add_message(0, bmfgreen, "hara.y loaded");
		playsound_s(S_MENTER);
	}

	//---- bone selection ------------------------------------------------------------------------

	//bone selection P1 (no shift keys)
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey[DIK_1] & 0x80) dev_bi[P1] = bhr;
		if (is.dikey[DIK_Q] & 0x80) dev_bi[P1] = blur;
		if (is.dikey[DIK_A] & 0x80) dev_bi[P1] = bllr;
		if (is.dikey[DIK_Z] & 0x80) dev_bi[P1] = bfr;
		if (is.dikey[DIK_2] & 0x80) dev_bi[P1] = bhl;
		if (is.dikey[DIK_W] & 0x80) dev_bi[P1] = blul;
		if (is.dikey[DIK_S] & 0x80) dev_bi[P1] = blll;
		if (is.dikey[DIK_X] & 0x80) dev_bi[P1] = bfl;
		if (is.dikey[DIK_E] & 0x80) dev_bi[P1] = bsr;
		if (is.dikey[DIK_D] & 0x80) dev_bi[P1] = baur;
		if (is.dikey[DIK_C] & 0x80) dev_bi[P1] = balr;
		if (is.dikey[DIK_R] & 0x80) dev_bi[P1] = bsl;
		if (is.dikey[DIK_F] & 0x80) dev_bi[P1] = baul;
		if (is.dikey[DIK_V] & 0x80) dev_bi[P1] = ball;
		if (is.dikey[DIK_T] & 0x80) dev_bi[P1] = bn;
		//lower torso in dependance of stance
//		if (P[P1].stance_feet == 0)
		{
			if (is.dikey[DIK_G] & 0x80 && is.dikey[DIK_LCONTROL] == 0) dev_bi[P1] = btul;
			if (is.dikey[DIK_B] & 0x80 && is.dikey[DIK_LCONTROL] == 0) dev_bi[P1] = btll;
			if (is.dikey[DIK_G] & 0x80 && is.dikey[DIK_LCONTROL] & 0x80) dev_bi[P1] = btur;
			if (is.dikey[DIK_B] & 0x80 && is.dikey[DIK_LCONTROL] & 0x80) dev_bi[P1] = btlr;
		}
/*		else
		{
			if (is.dikey[DIK_G] & 0x80) dev_bi[P1] = btur;
			if (is.dikey[DIK_B] & 0x80) dev_bi[P1] = btlr;
		}*/
	}
	else
	//else P2
	{
		if (is.dikey[DIK_1] & 0x80) dev_bi[P2] = bhr;
		if (is.dikey[DIK_Q] & 0x80) dev_bi[P2] = blur;
		if (is.dikey[DIK_A] & 0x80) dev_bi[P2] = bllr;
		if (is.dikey[DIK_Z] & 0x80) dev_bi[P2] = bfr;
		if (is.dikey[DIK_2] & 0x80) dev_bi[P2] = bhl;
		if (is.dikey[DIK_W] & 0x80) dev_bi[P2] = blul;
		if (is.dikey[DIK_S] & 0x80) dev_bi[P2] = blll;
		if (is.dikey[DIK_X] & 0x80) dev_bi[P2] = bfl;
		if (is.dikey[DIK_E] & 0x80) dev_bi[P2] = bsr;
		if (is.dikey[DIK_D] & 0x80) dev_bi[P2] = baur;
		if (is.dikey[DIK_C] & 0x80) dev_bi[P2] = balr;
		if (is.dikey[DIK_R] & 0x80) dev_bi[P2] = bsl;
		if (is.dikey[DIK_F] & 0x80) dev_bi[P2] = baul;
		if (is.dikey[DIK_V] & 0x80) dev_bi[P2] = ball;
		if (is.dikey[DIK_T] & 0x80) dev_bi[P2] = bn;

		//p1 hara other side
		if (is.dikey[DIK_G] & 0x80) dev_bi[P1] = btur;
		if (is.dikey[DIK_B] & 0x80) dev_bi[P1] = btlr;
/*		//lower torso in dependance of stance
		if (P[P2].stance_feet == 0)
		{
			if (is.dikey[DIK_G] & 0x80) dev_bi[P2] = btul;
			if (is.dikey[DIK_B] & 0x80) dev_bi[P2] = btll;
		}
		else
		{
			if (is.dikey[DIK_G] & 0x80) dev_bi[P2] = btur;
			if (is.dikey[DIK_B] & 0x80) dev_bi[P2] = btlr;
		}*/
	}

	//set selected bone to yellow
//	P[P1].sk.b[dev_bi[P1]].damage =
//	P[P2].sk.b[dev_bi[P2]].damage = 50;

	//---- center change -------------------------------------------------------------------------

	//change position of center of skeleton with right mouse button
	if (is.dimouse[1].rgbButtons[1] & 0x80)
	{
		P[P1].sk.p_ref->v.p[0].x += is.dimouse[1].lX;
		P[P1].sk.p_ref->v.p[0].y += is.dimouse[1].lY;
	}
	if (is.dimouse[2].rgbButtons[1] & 0x80)
	{
		P[P2].sk.p_ref->v.p[0].x += is.dimouse[2].lX;
		P[P2].sk.p_ref->v.p[0].y += is.dimouse[2].lY;
	}

	//--- length, width, angle -------------------------------------------------------------------

	//length and width
	if (is.dikey[DIK_LMENU] & 0x80)
	{
		//mark bone
//		P[P1].sk.b[dev_bi[P1]].damage	= P[P2].sk.b[dev_bi[P2]].damage = 100;
		P[P1].sk.b[dev_bi[P1]].length	+= is.dimouse[1].lX;
		P[P2].sk.b[dev_bi[P2]].length	+= is.dimouse[2].lX;
	}
	if (is.dikey[DIK_LWIN] & 0x80)
	{
		//mark bone
//		P[P1].sk.b[dev_bi[P1]].damage	= P[P2].sk.b[dev_bi[P2]].damage = 100;
		P[P1].sk.b[dev_bi[P1]].width	+= is.dimouse[1].lX;
		P[P1].sk.b[dev_bi[P2]].width	+= is.dimouse[2].lX;
	}

	//angle
	if (is.dimouse[1].rgbButtons[0] & 0x80)
	{
		//mark bone
//		P[P1].sk.b[dev_bi[P1]].damage	= 100;
		P[P1].sk.b[dev_bi[P1]].angle	+= is.dimouse[1].lX;
	}
	if (is.dimouse[2].rgbButtons[0] & 0x80)
	{
		P[P2].sk.b[dev_bi[P2]].angle	+= is.dimouse[2].lX;
	}

	//---- stance change -------------------------------------------------------------------------

/*	//!! in player object
	if (is.PA[P1][AC_STANCE_FEET])
	{
		P[P1].set_stance(!P[P1].stance_feet);
		P[P1].fatigue_buff += anmn[P[P1].asi][AN_STANCE_FEET].gl_fatigue;
	}
	if (is.PA[P2][AC_STANCE_FEET])
	{
		P[P2].set_stance(!P[P2].stance_feet);
		P[P2].fatigue_buff += anmn[P[P2].asi][AN_STANCE_FEET].gl_fatigue;
	}*/

	//---- load current state --------------------------------------------------------------------

	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey1D[DIK_7] & 0x80)
	{
		hud_add_message(0, bmfred, "DIK_7: don't know what it does...");

		FILE		*f_state = NULL;
		bone		b_def[2][19];

		f_state = fopen("animation_dev/current_sleft.amn", "rb");
		if (f_state != NULL)
		{
			//read file data into default skeleton
			for (register int i = 0; i < 19; ++i)
			{
				fscanf(f_state,
					   "%f %f %f",
					   &b_def[0][i].angle,
					   &b_def[0][i].length,
					   &b_def[0][i].width);
			}

			//close file
			fclose(f_state);
		}

		f_state = fopen("animation_dev/current_sright.amn", "rb");
		if (f_state != NULL)
		{
			//read file data into default skeleton
			for (register int i = 0; i < 19; ++i)
			{
				fscanf(f_state,
					   "%f %f %f",
					   &b_def[1][i].angle,
					   &b_def[1][i].length,
					   &b_def[1][i].width);
			}

			//close file
			fclose(f_state);
		}

		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			if (P[p].side == SLEFT)
				if (P[p].stance_feet == SLEFT)
				{
					for (register int i = 0; i < 19; ++i)
					{
						P[p].sk.b[i].angle	= b_def[0][i].angle;
						P[p].sk.b[i].length	= b_def[0][i].length;
						P[p].sk.b[i].width	= b_def[0][i].width;
					}
				}
				else
				{
					for (register int i = 0; i < 19; ++i)
					{
						P[p].sk.b[i].angle	= b_def[1][i].angle;
						P[p].sk.b[i].length	= b_def[1][i].length;
						P[p].sk.b[i].width	= b_def[1][i].width;
					}
				}
			else
				if (P[p].stance_feet == SLEFT)
				{
					for (register int i = 0; i < 19; ++i)
					{
						P[p].sk.b[i].angle	= b_def[1][i].angle;
						P[p].sk.b[i].length	= b_def[1][i].length;
						P[p].sk.b[i].width	= b_def[1][i].width;
					}

					P[p].sk.b[bn].angle				= 180 - b_def[1][bn].angle;

					P[p].sk.b[btul].angle			= 180 - b_def[1][btur].angle;
					P[p].sk.b[btul].length			= b_def[1][btur].length;
					P[p].sk.b[btul].width			= b_def[1][btur].width;

					P[p].sk.b[btur].angle			= 180 - b_def[1][btul].angle;
					P[p].sk.b[btur].length			= b_def[1][btul].length;
					P[p].sk.b[btur].width			= b_def[1][btul].width;

					P[p].sk.b[btll].angle			= 180 - b_def[1][btlr].angle;
					P[p].sk.b[btll].length			= b_def[1][btlr].length;
					P[p].sk.b[btll].width			= b_def[1][btlr].width;

					P[p].sk.b[btlr].angle			= 180 - b_def[1][btll].angle;
					P[p].sk.b[btlr].length			= b_def[1][btll].length;
					P[p].sk.b[btlr].width			= b_def[1][btll].width;

					P[p].sk.b[bsl].angle			= 180 - b_def[1][bsr].angle;
					P[p].sk.b[baul].angle			= 180 - b_def[1][baur].angle;
					P[p].sk.b[ball].angle			= 180 - b_def[1][balr].angle;

					P[p].sk.b[bsr].angle			= 180 - b_def[1][bsl].angle;
					P[p].sk.b[baur].angle			= 180 - b_def[1][baul].angle;
					P[p].sk.b[balr].angle			= 180 - b_def[1][ball].angle;

					P[p].sk.b[bhl].angle			= 180 - b_def[1][bhr].angle;
					P[p].sk.b[blul].angle			= 180 - b_def[1][blur].angle;
					P[p].sk.b[blll].angle			= 180 - b_def[1][bllr].angle;
					P[p].sk.b[bfl].angle			= 180 - b_def[1][bfr].angle;

					P[p].sk.b[bhr].angle			= 180 - b_def[1][bhl].angle;
					P[p].sk.b[blur].angle			= 180 - b_def[1][blul].angle;
					P[p].sk.b[bllr].angle			= 180 - b_def[1][blll].angle;
					P[p].sk.b[bfr].angle			= 180 - b_def[1][bfl].angle;
				}
				else
				{
					for (register int i = 0; i < 19; ++i)
					{
						P[p].sk.b[i].angle	= b_def[0][i].angle;
						P[p].sk.b[i].length	= b_def[0][i].length;
						P[p].sk.b[i].width	= b_def[0][i].width;
					}

					P[p].sk.b[bn].angle				= 180 - b_def[0][bn].angle;

					P[p].sk.b[btul].angle			= 180 - b_def[0][btur].angle;
					P[p].sk.b[btul].length			= b_def[0][btur].length;
					P[p].sk.b[btul].width			= b_def[0][btur].width;

					P[p].sk.b[btur].angle			= 180 - b_def[0][btul].angle;
					P[p].sk.b[btur].length			= b_def[0][btul].length;
					P[p].sk.b[btur].width			= b_def[0][btul].width;

					P[p].sk.b[btll].angle			= 180 - b_def[0][btlr].angle;
					P[p].sk.b[btll].length			= b_def[0][btlr].length;
					P[p].sk.b[btll].width			= b_def[0][btlr].width;

					P[p].sk.b[btlr].angle			= 180 - b_def[0][btll].angle;
					P[p].sk.b[btlr].length			= b_def[0][btll].length;
					P[p].sk.b[btlr].width			= b_def[0][btll].width;

					P[p].sk.b[bsl].angle			= 180 - b_def[0][bsr].angle;
					P[p].sk.b[baul].angle			= 180 - b_def[0][baur].angle;
					P[p].sk.b[ball].angle			= 180 - b_def[0][balr].angle;

					P[p].sk.b[bsr].angle			= 180 - b_def[0][bsl].angle;
					P[p].sk.b[baur].angle			= 180 - b_def[0][baul].angle;
					P[p].sk.b[balr].angle			= 180 - b_def[0][ball].angle;

					P[p].sk.b[bhl].angle			= 180 - b_def[0][bhr].angle;
					P[p].sk.b[blul].angle			= 180 - b_def[0][blur].angle;
					P[p].sk.b[blll].angle			= 180 - b_def[0][bllr].angle;
					P[p].sk.b[bfl].angle			= 180 - b_def[0][bfr].angle;

					P[p].sk.b[bhr].angle			= 180 - b_def[0][bhl].angle;
					P[p].sk.b[blur].angle			= 180 - b_def[0][blul].angle;
					P[p].sk.b[bllr].angle			= 180 - b_def[0][blll].angle;
					P[p].sk.b[bfr].angle			= 180 - b_def[0][bfl].angle;
				}
		}
	}

	//---- save current state --------------------------------------------------------------------

	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey1D[DIK_7] & 0x80)
	{
		//only save first player and on left side
		if (P[P1].side == SRIGHT)
		{
			hud_add_message(0, bmfred, "DIK_LSHIFT + DIK_7: don't know what it does...");
			//play error sound
			playsound_s(S_ERROR);
		}
		else
		{
			FILE	*f_state = NULL;

			//open state file
			if (P[P1].stance_feet == SLEFT)
				f_state = fopen("animation_dev/current_sleft.amn", "wb");
			else
				f_state = fopen("animation_dev/current_sright.amn", "wb");

			//if file successfully opened
			if (f_state != NULL)
			{
				//write file data from skeleton
				for (register int i = 0; i < 19; ++i)
				{
					fprintf(f_state,
							"%.f %.f %.f\n",
							P[P1].sk.b[i].angle,
							P[P1].sk.b[i].length,
							P[P1].sk.b[i].width);
				}

				//close file
				fclose(f_state);
			}
		}
	}

	//---- animation -----------------------------------------------------------------------------

	//select animation index (left control and left/right)
	if (is.dikey[DIK_LSHIFT] == 0 &&
		is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey[DIK_LCONTROL] & 0x80 &&
		is.dikey[DIK_RCONTROL] == 0)
	{
		//circle through cai
		if (is.dikey1D[DIK_LEFT] & 0x80)
		{
			//reset current keyframe index
			dev_ckf		= 0;

			if (dev_cai > 0)					--dev_cai;
			else								dev_cai = NPAN - 1;
		}

		//circle through ckf index
		if (is.dikey1D[DIK_RIGHT] & 0x80)
		{
			//reset current keyframe index
			dev_ckf		= 0;

			if (dev_cai < NPAN - 1)				++dev_cai;
			else								dev_cai = 0;
		}
	}

	//---- load/save animation -------------------------------------------------------------------

	if (is.dikey[DIK_RSHIFT] == 0)
	{
		//select file name in depedence of current animation index
		char	*p_anmn_file		= panmnfile[P[P1].asi][dev_cai];

//!!
/*		if (is.dikey1D[DIK_DELETE] & 0x80)
			if (!p_dev_a[P[P1].asi][dev_cai]->load_animation(p_anmn_file, CAV, 0))
			{
				//play error sound
				playsound(S_ERROR);
			}
			else
			{
				//reset current keyframe index
				dev_ckf		= 0;
				//play confirmation sound
				playsound(S_MENTER);
			}*/

		if (is.dikey1D[DIK_INSERT] & 0x80 && is.dikey[DIK_LSHIFT] & 0x80)
			if (!p_dev_a[P[P1].asi][dev_cai]->save_animation(p_anmn_file, CAV, 0))
			{
				hud_add_message(0, bmfred, "save animation FAILED %i", dev_cai);
				//play error sound
				playsound_s(S_ERROR);
			}
			else
			{
				//reset current keyframe index
				dev_ckf		= 0;
				hud_add_message(0, bmfgreen, "animation saved %i", dev_cai);
				//play confirmation sound
				playsound_s(S_MSELECT);
			}
	}

	//---- select keyframe index -----------------------------------------------------------------

	if (is.dikey[DIK_LCONTROL] == 0 &&
		is.dikey[DIK_RCONTROL] == 0 &&
		is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		//circle through ckf index
		if (is.dikey1D[DIK_LEFT] & 0x80)
			if (dev_ckf > 0)							--dev_ckf;
			else										dev_ckf = p_dev_a[P[P1].asi][dev_cai]->nokf - 1;

		//circle through ckf index
		if (is.dikey1D[DIK_RIGHT] & 0x80)
			if (dev_ckf < p_dev_a[P[P1].asi][dev_cai]->nokf - 1)	++dev_ckf;
			else										dev_ckf = 0;
	}

	//select ckf index and load state with LSHIFT
	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0)
	{
		//circle through ckf index and load it into player
		if (is.dikey1D[DIK_LEFT] & 0x80)
		{
			if (dev_ckf > 0)					--dev_ckf;
			else								dev_ckf = p_dev_a[P[P1].asi][dev_cai]->nokf -1;

			//load state
			for (register int b = 0; b < 19; ++b)
			{
				//angle
				//if angle is relative to parent bone (mode_a = 1) and pointer to parent bone
				//not NULL
				if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[b] == 1 &&
					P[P1].sk.b[b].p_pb != NULL)
					//angle of bone is angle of parent bone plus angle of keyframe
					P[P1].sk.b[b].angle	= P[P1].sk.b[b].p_pb->angle + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
				else
					P[P1].sk.b[b].angle	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
				//length, width
				P[P1].sk.b[b].length	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b];
				P[P1].sk.b[b].width		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b];
			}
			//hara in reference to hara reference skeleton
			//x relative to current postion, y relative to reference position
			if (P[P1].stance_feet == SLEFT)
			{
				P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}
			else
			{
				///!!
				P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
				//P[P1].sk.p_ref->v.p[1].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				//P[P1].sk.p_ref->v.p[1].y = dev_hsk[1].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}
		}

		//circle through ckf index and load it into player
		if (is.dikey1D[DIK_RIGHT] & 0x80)
		{
			if (dev_ckf < p_dev_a[P[P1].asi][dev_cai]->nokf - 1)	++dev_ckf;
			else								dev_ckf = 0;

			//load state
			for (register int b = 0; b < 19; ++b)
			{
				//angle
				//if angle is relative to parent bone (mode_a = 1) and pointer to parent bone
				//not NULL
				if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[b] == 1 &&
					P[P1].sk.b[b].p_pb != NULL)
					//angle of bone is angle of parent bone plus angle of keyframe
					P[P1].sk.b[b].angle	= P[P1].sk.b[b].p_pb->angle + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
				else
					P[P1].sk.b[b].angle	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
				//length, width
				P[P1].sk.b[b].length	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b];
				P[P1].sk.b[b].width		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b];
			}
			//hara in reference to hara reference skeleton
			//x relative to current postion, y relative to reference position
			if (P[P1].stance_feet == SLEFT)
			{
				P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}
			else
			{
				P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
				//!!
				//P[P1].sk.p_ref->v.p[1].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				//P[P1].sk.p_ref->v.p[1].y = dev_hsk[1].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}
		}
	}

	//---- add/del keyframe with right shift and direction ---------------------------------------

//	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] & 0x80)
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RCONTROL] & 0x80)
	{
		//delete one keyframe if at least 2 exist
		if (is.dikey1D[DIK_LEFT] & 0x80 && p_dev_a[P[P1].asi][dev_cai]->nokf > 1)
		{
			hud_add_message(0, bmfgreen, "keyframe deleted");
			p_dev_a[P[P1].asi][dev_cai]->del_keyframe();
			//reset ckf index
			dev_ckf		= 0;
		}

		//add one keyframe
		if (is.dikey1D[DIK_RIGHT] & 0x80)
		{
			hud_add_message(0, bmfgreen, "keyframe added");
			p_dev_a[P[P1].asi][dev_cai]->add_keyframe();
			//reset ckf index
			dev_ckf		= 0;
		}
	}

	//---- save keyframe in animation ------------------------------------------------------------

	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey1D[DIK_HOME] & 0x80)
		{
			//for every bone
			for (register int b = 0; b < 19; ++b)
			{
				//angle
				//if angle relative to parent bone (mode_a = 1) and pointer to parent bone
				//not NULL (lower torso has no parent bone)
				if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[b] == 1 &&
					P[P1].sk.b[b].p_pb != NULL)
					//angle of bone is current angle minus angle of parent bone
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b]	=
					P[P1].sk.b[b].angle - P[P1].sk.b[b].p_pb->angle;
				else
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b]	= P[P1].sk.b[b].angle;
				//length, width
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b]		= P[P1].sk.b[b].length;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b]		= P[P1].sk.b[b].width;
			}

			//!!
			//if not AN_IDLE_SETS
			if (dev_cai != AN_IDLE_SETS)
			{
				//calculate hara offset from difference between current position
				//and hara reference position
				if (P[P1].stance_feet == SLEFT)
				{
					//keyframe hara.x offset is current skeleton position minus hara skeleton position
					//minus all the hara.x offsets of the previous keyframes
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x;
					for (register int i = 0; i < dev_ckf; ++i)
						p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x -= p_dev_a[P[P1].asi][dev_cai]->pkf[i].hara.x;
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y;
				}
				else
				{
					//keyframe hara.x offset is current skeleton position minus hara skeleton position
					//minus all the hara.x offsets of the previous keyframes
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x;
					for (register int i = 0; i < dev_ckf; ++i)
						p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x -= p_dev_a[P[P1].asi][dev_cai]->pkf[i].hara.x;
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[1].y - dev_hsk[1].p[0].y;
				}
			}
			else
			//don't take previous keyframe positions into account
			{
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y;
			}

			hud_add_message(0, bmfgreen, "keyframe in animation saved");
			//play confirmation sound
			playsound_s(S_MSELECT);
		}
	}

	//---- load keyframe from animation ----------------------------------------------------------

//!!
/*	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey1D[DIK_END] & 0x80)
		{
			//for every bone
			for (register int b = 0; b < 19; ++b)
			{
				//angle, length, width
				P[P1].sk.b[b].angle		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
				P[P1].sk.b[b].length	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b];
				P[P1].sk.b[b].width		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b];
			}
			//hara in reference to hara reference skeleton
			//x relative to current postion, y relative to reference position
			if (P[P1].stance_feet == SLEFT)
			{
				P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}
			else
			{
				P[P1].sk.p_ref->v.p[1].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
				P[P1].sk.p_ref->v.p[1].y = dev_hsk[1].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
			}

			//play confirmation sound
			playsound_s(S_MENTER);
		}
	}*/

	//---- load/save keyframe from file ----------------------------------------------------------

	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0)
	{
		//load
		if (is.dikey1D[DIK_PGDN] & 0x80)
		{
			if (!p_dev_a[P[P1].asi][dev_cai]->load_animation("animation_dev/keyframe_cur.amn", CAV, 1))
			{
				hud_add_message(0, bmfred, "load keyframe from file animation_dev/keyframe_cur.amn FAILED");
				//play error sound
				playsound_s(S_ERROR);
			}
			else
			{
				//for every bone
				for (register int b = 0; b < 19; ++b)
				{
					//angle, length, width
					P[P1].sk.b[b].angle		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b];
					P[P1].sk.b[b].length	= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b];
					P[P1].sk.b[b].width		= p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b];
				}
				//hara in reference to hara reference skeleton
				//x relative to current postion, y relative to reference position
				if (P[P1].stance_feet == SLEFT)
				{
					P[P1].sk.p_ref->v.p[0].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
					P[P1].sk.p_ref->v.p[0].y = dev_hsk[0].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
				}
				else
				{
					P[P1].sk.p_ref->v.p[1].x += p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x;
					P[P1].sk.p_ref->v.p[1].y = dev_hsk[1].p[0].y + p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y;
				}

				hud_add_message(0, bmfgreen, "keyframe loaded");
				//play confirmation sound
				playsound_s(S_MENTER);
			}
		}

		//save
		if (is.dikey1D[DIK_PGUP] & 0x80)
		{
			//for every bone
			for (register int b = 0; b < 19; ++b)
			{
				//angle, length, width
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].angle[b]		= P[P1].sk.b[b].angle;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].length[b]	= P[P1].sk.b[b].length;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].width[b]		= P[P1].sk.b[b].width;
			}
			//calculate hara offset from difference between current position
			//and hara reference position
/*			if (P[P1].stance_feet == SLEFT)
			{
				//if first keyframe, hara.x reference is reference skeleton, else reference
				//is previous keyframe
				if (dev_ckf == 0)
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x;
				else
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x - p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf - 1].hara.x;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y;
			}
			else
			{
				//if first keyframe, hara.x reference is reference skeleton, else reference
				//is previous keyframe
				if (dev_ckf == 0)
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x;
				else
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x - p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf - 1].hara.x;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[1].y - dev_hsk[1].p[0].y;
			}*/
			if (P[P1].stance_feet == SLEFT)
			{
				//keyframe hara.x offset is current skeleton position minus hara skeleton position
				//minus all the hara.x offsets of the previous keyframes
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[0].x - dev_hsk[0].p[0].x;
				for (register int i = 0; i < dev_ckf; ++i)
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x -= p_dev_a[P[P1].asi][dev_cai]->pkf[i].hara.x;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[0].y - dev_hsk[0].p[0].y;
			}
			else
			{
				//keyframe hara.x offset is current skeleton position minus hara skeleton position
				//minus all the hara.x offsets of the previous keyframes
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x = P[P1].sk.p_ref->v.p[1].x - dev_hsk[1].p[0].x;
				for (register int i = 0; i < dev_ckf; ++i)
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.x -= p_dev_a[P[P1].asi][dev_cai]->pkf[i].hara.x;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].hara.y = P[P1].sk.p_ref->v.p[1].y - dev_hsk[1].p[0].y;
			}

			if (!p_dev_a[P[P1].asi][dev_cai]->save_animation("animation_dev/keyframe_cur.amn", 0, 1))
			{
				hud_add_message(0, bmfred, "save keyframe in file FAILED");
				//play error sound
				playsound_s(S_ERROR);
			}
			else
			{
				hud_add_message(0, bmfgreen, "save keyframe in file DONE");
				//play confirmation sound
				playsound_s(S_MSELECT);
			}
		}
	}

	//---- set time, priority, mode_a ------------------------------------------------------------

	//set bone keyframe time
	if (is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey1D[DIK_DOWN] & 0x80)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[dev_bi[P1]] > 10)
				//all bones and hara
				if (is.key(DIK_Z) && is.key(DIK_X))
				{
					for (register int b = 0; b < 19; ++b)
						p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[b] -= 10;

					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19] -= 10;
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20] -= 10;
				}
				else
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[dev_bi[P1]] -= 10;
		}

		if (is.dikey1D[DIK_UP] & 0x80)
		{
			//all bones and hara
			if (is.key(DIK_Z) && is.key(DIK_X))
			{
				for (register int b = 0; b < 19; ++b)
					p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[b] += 10;

				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19] += 10;
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20] += 10;
			}
			else
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[dev_bi[P1]] += 10;
		}
	}
	//set bone priority
	if (is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey1D[DIK_DOWN] & 0x80)
			if (p_dev_a[P[P1].asi][dev_cai]->priority[dev_bi[P1]] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->priority[dev_bi[P1]];

		if (is.dikey1D[DIK_UP] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->priority[dev_bi[P1]];
	}
	//set bone priority
	if (is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		if (is.dikey1D[DIK_DOWN] & 0x80)
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[dev_bi[P1]] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[dev_bi[P1]];

		if (is.dikey1D[DIK_UP] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_a[dev_bi[P1]];
	}

	//---- hara data -----------------------------------------------------------------------------

	//increase hara.x
	if (is.dikey1D[DIK_H] & 0x80)
	{
		//increase x time
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19] += 10;
		}
		//increase x priority
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->priority[19];
		}
/*		//increase x mode_h
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.x;
		}*/
		//increase x diffn
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->h_diffn.x;
		}
		//increase x diffp
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] & 0x80)
		{
			++p_dev_a[P[P1].asi][dev_cai]->h_diffp.x;
		}
	}
	//increase hara.y
	if (is.dikey1D[DIK_J] & 0x80)
	{
		//increase x time
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20] += 10;
		}
		//increase x priority
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->priority[20];
		}
/*		//increase x mode_h
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.y;
		}*/
		//increase y diffn
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			++p_dev_a[P[P1].asi][dev_cai]->h_diffn.y;
		}
		//increase y diffp
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] & 0x80)
		{
			++p_dev_a[P[P1].asi][dev_cai]->h_diffp.y;
		}
	}
	//decrease x
	if (is.dikey1D[DIK_N] & 0x80)
	{
		//decrease x time
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19] >= 10)
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[19] -= 10;
		}
		//decrease x priority
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->priority[19] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->priority[19];
		}
/*		//decrease x mode_h
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.x > 0)
				--p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.x;
		}*/
		//decrease x diffn
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			--p_dev_a[P[P1].asi][dev_cai]->h_diffn.x;
		}
		//decrease x diffp
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] & 0x80)
		{
			--p_dev_a[P[P1].asi][dev_cai]->h_diffp.x;
		}
	}
	//decrease y
	if (is.dikey1D[DIK_M] & 0x80)
	{
		//decrease y time
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20] >= 10)
				p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].t_frame[20] -= 10;
		}
		//decrease y priority
		if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->priority[20] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->priority[20];
		}
/*		//decrease y mode_h
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			if (p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.y > 0)
				--p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].mode_h.y;
		}*/
		//decrease y diffn
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] & 0x80 && is.dikey[DIK_LALT] == 0)
		{
			--p_dev_a[P[P1].asi][dev_cai]->h_diffn.y;
		}
		//decrease y diffp
		if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
			is.dikey[DIK_LCONTROL] == 0 && is.dikey[DIK_LALT] & 0x80)
		{
			--p_dev_a[P[P1].asi][dev_cai]->h_diffp.y;
		}
	}

	//---- set diff ------------------------------------------------------------------------------

/*	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey[DIK_LCONTROL] == 0)
	{
		if (is.dikey1D[DIK_Y] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->h_ri;

		if (is.dikey1D[DIK_K] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->a_ri[dev_bi[P1]];
		if (is.dikey1D[DIK_L] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->l_ri[dev_bi[P1]];
		if (is.dikey1D[DIK_SEMICOLON] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->w_ri[dev_bi[P1]];
		if (is.dikey1D[DIK_COMMA] & 0x80)
			if (p_dev_a[P[P1].asi][dev_cai]->a_ri[dev_bi[P1]] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->a_ri[dev_bi[P1]];
		if (is.dikey1D[DIK_PERIOD] & 0x80)
			if (p_dev_a[P[P1].asi][dev_cai]->l_ri[dev_bi[P1]] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->l_ri[dev_bi[P1]];
		if (is.dikey1D[DIK_SLASH] & 0x80)
			if (p_dev_a[P[P1].asi][dev_cai]->w_ri[dev_bi[P1]] > 0)
				--p_dev_a[P[P1].asi][dev_cai]->w_ri[dev_bi[P1]];
	}*/
	//diffp
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey[DIK_LCONTROL] == 0)
	{
		if (is.dikey1D[DIK_K] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->a_diffp[dev_bi[P1]];
		if (is.dikey1D[DIK_L] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->l_diffp[dev_bi[P1]];
		if (is.dikey1D[DIK_SEMICOLON] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->w_diffp[dev_bi[P1]];
		if (is.dikey1D[DIK_COMMA] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->a_diffp[dev_bi[P1]];
		if (is.dikey1D[DIK_PERIOD] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->l_diffp[dev_bi[P1]];
		if (is.dikey1D[DIK_SLASH] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->w_diffp[dev_bi[P1]];
	}
	//diffn
	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0 &&
		is.dikey[DIK_LCONTROL] == 0)
	{
		if (is.dikey1D[DIK_K] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->a_diffn[dev_bi[P1]];
		if (is.dikey1D[DIK_L] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->l_diffn[dev_bi[P1]];
		if (is.dikey1D[DIK_SEMICOLON] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->w_diffn[dev_bi[P1]];
		if (is.dikey1D[DIK_COMMA] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->a_diffn[dev_bi[P1]];
		if (is.dikey1D[DIK_PERIOD] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->l_diffn[dev_bi[P1]];
		if (is.dikey1D[DIK_SLASH] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->w_diffn[dev_bi[P1]];
	}

	//---- keyframe/animation data ---------------------------------------------------------------

	//increase
	if (is.dikey[DIK_LSHIFT] == 0 && is.dikey[DIK_RSHIFT] == 0)
	{
		//ui_bias, ui_index
		if (is.dikey1D[DIK_Y] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->ui_bias;
		if (is.dikey1D[DIK_U] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->ui_index;

		//action, keyframe type, direction
		if (is.dikey1D[DIK_I] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].action;
		if (is.dikey1D[DIK_O] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].type;
		if (is.dikey1D[DIK_P] & 0x80)
			p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir = !p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir;

		//animation id, cycle
		if (is.dikey1D[DIK_APOSTROPHE] & 0x80)
			++p_dev_a[P[P1].asi][dev_cai]->id;
		/*if (is.dikey1D[DIK_BACKSLASH] & 0x80)
			p_dev_a[P[P1].asi][dev_cai]->cycle = !p_dev_a[P[P1].asi][dev_cai]->cycle;*/
	}
	//decrease
	if (is.dikey[DIK_LSHIFT] & 0x80 && is.dikey[DIK_RSHIFT] == 0)
	{
		//ui_bias, ui_index
		if (is.dikey1D[DIK_Y] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->ui_bias;
		if (is.dikey1D[DIK_U] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->ui_index;

		//action, keyframe type, direction
		if (is.dikey1D[DIK_I] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].action;
		if (is.dikey1D[DIK_O] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].type;
		if (is.dikey1D[DIK_P] & 0x80)
			p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir = !p_dev_a[P[P1].asi][dev_cai]->pkf[dev_ckf].dir;

		//animation id, cycle
		if (is.dikey1D[DIK_APOSTROPHE] & 0x80)
			--p_dev_a[P[P1].asi][dev_cai]->id;
		/*if (is.dikey1D[DIK_BACKSLASH] & 0x80)
			p_dev_a[P[P1].asi][dev_cai]->cycle = !p_dev_a[P[P1].asi][dev_cai]->cycle;*/
	}

	//---- animator ------------------------------------------------------------------------------
};

//------------------------------------------------------------------------------------------------
//
//	master_frame dev_input
//
//	checks developer input
//
//------------------------------------------------------------------------------------------------

void master_frame::dev_input()
{
	if (is.dikey1D[DIK_3] & 0x80)			dev_s_showdata		= !dev_s_showdata;
	if (is.dikey1D[DIK_4] & 0x80)			dev_s_devmode		= !dev_s_devmode;

	if (is.dikey1D[DIK_ADD] & 0x80)
	{
		dev_s_animate		= !dev_s_animate;
		hud_add_message(0, bmfred, "dev_s_animate: %i", (int)dev_s_animate);
	}
	if (is.dikey1D[DIK_BACKSPACE] & 0x80)
	{
		dev_s_ai			= !dev_s_ai;
		hud_add_message(0, bmfred, "dev_s_ai: %i", (int)dev_s_ai);
	}

	//---- walk bot ------------------------------------------------------------------------------

	if (!demo_playback && walkbot)
	{
		static bool bot_walk = false;
		if (P[P2].sk.p_ref->v.p[0].x > 650 ||
			P[P2].sk.p_ref->v.p[0].x < 150)
			bot_walk = true;

		if (bot_walk)
		{
			if (P[P2].sk.p_ref->v.p[0].x < 375)
			{
				if (P[P2].side == SLEFT)
				{
					is.t_move[P2][1] = 1.0f;
					is.PA[P2][AN_WALK_FWD] = AS_ACTIVE;
				}
				else
				{
					is.t_move[P2][0] = 1.0f;
					is.PA[P2][AN_WALK_BWD] = AS_ACTIVE;
				}
			}

			if (P[P2].sk.p_ref->v.p[0].x > 425)
			{
				if (P[P2].side == SLEFT)
				{
					is.t_move[P2][0] = 1.0f;
					is.PA[P2][AN_WALK_BWD] = AS_ACTIVE;
				}
				else
				{
					is.t_move[P2][1] = 1.0f;
					is.PA[P2][AN_WALK_FWD] = AS_ACTIVE;
				}
			}

			if (P[P2].sk.p_ref->v.p[0].x >= 375 &&
				P[P2].sk.p_ref->v.p[0].x <= 425)
				bot_walk = false;
		}
	}

	//---- dummy ai ------------------------------------------------------------------------------

	if (!demo_playback)
	{
	static LONGLONG t_aistart[2] = {0};
	static float ai_[2] = {0.0f};
	static int ai_ini[2] = {0};
	if (dev_s_ai)
	for (register int AI = 1; AI < 2; ++AI)
	{
		//stance
		if (P[AI].sk.damage[DS_hlr] + P[AI].sk.damage[DS_flr] > 150 &&
			P[AI].stance_feet == SRIGHT)
			is.PA[AI][AN_STANCE_FEET] = 1;
		if (P[AI].sk.damage[DS_hll] + P[AI].sk.damage[DS_fll] > 150 &&
			P[AI].sk.damage[DS_hlr] + P[AI].sk.damage[DS_flr] < 150 &&
			P[AI].stance_feet == SLEFT)
			is.PA[AI][AN_STANCE_FEET] = 1;

		if (P[AI].sk.damage[DS_hn] >= 50)
			P[AI].stance_arms = 100;
		else
		{
			if (P[AI].sk.damage[DS_tll] >= 50 ||
				P[AI].sk.damage[DS_tlr] >= 50)
				P[AI].stance_arms = 0;
			else
			if (P[AI].sk.damage[DS_tul] >= 50 ||
				P[AI].sk.damage[DS_tur] >= 50)
				P[AI].stance_arms = 70;
		}
		/*if (P[AI].sk.damage[DS_hn] > P[AI].sk.damage[DS_tll] &&
			P[AI].sk.damage[DS_hn] > P[AI].sk.damage[DS_tlr] &&
			P[AI].sk.damage[DS_hn] > P[AI].sk.damage[DS_tul] &&
			P[AI].sk.damage[DS_hn] > P[AI].sk.damage[DS_tur])
			P[AI].stance_arms = 100;
		else
		{
			if (P[AI].sk.damage[DS_tll] > P[AI].sk.damage[DS_tul] &&
				P[AI].sk.damage[DS_tll] > P[AI].sk.damage[DS_tur] &&
				P[AI].sk.damage[DS_tlr] > P[AI].sk.damage[DS_tul] &&
				P[AI].sk.damage[DS_tlr] > P[AI].sk.damage[DS_tur])
				P[AI].stance_arms = 0;
			else
				P[AI].stance_arms = 70;
		}*/

		if (ai_ini[AI] == 0)
		{
//			if (P[AI].p_aslot[aslot_action] == NULL ||
//				P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_IDLE_LO])
			if (P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_IDLE_LO])
			{
				ai_ini[AI] = 1;
				ai_[AI] = (float)(100 + (rand() % (500 - 100 + 1)));
				ai_[AI] = ai_[AI] / 1000;
				t_aistart[AI] = time.current;
			}
			else
			{
				//if (P[AI].p_aslot[aslot_action]->pkf[0].dir == 1)
				{
					ai_ini[AI] = 1;
					ai_[AI] = (float)(100 + (rand() % (500 - 100 + 1)));
					ai_[AI] = ai_[AI] / 1000;
					t_aistart[AI] = time.current;
				}
			}
		}
//		if (t_aistart[AI] + time.freq * ai_[AI] <= time.current &&
//			P[AI].p_aslot[aslot_action] == NULL)
		if (t_aistart[AI] + time.freq * ai_[AI] <= time.current &&
			P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_IDLE_LO])
		{
			int ai_action = 0 + (rand() % (2 - 0 + 1));

		//		is.mm_angle[P2] = 200;
				if (AI == P1)
				{
					/*if (0 + (rand() % (1 - 0 + 1)) == 1)
						is.mm_angle[AI] = 0 + (rand() % (70 - 0 + 1));
					else
						is.mm_angle[AI] = 290 + (rand() % (359 - 290 + 1));

					//set 180 angle
					if (is.mm_angle[AI] > 270)
						is.mm_angle_180[AI] = is.mm_angle[AI] - 271;
					if (is.mm_angle[AI] >= 0 && is.mm_angle[AI] <= 90)
						is.mm_angle_180[AI] = is.mm_angle[AI] + 89;
					if (is.mm_angle[AI] > 90 && is.mm_angle[AI] <= 270)
						is.mm_angle_180[AI] = 270 - is.mm_angle[AI];*/
				}
				else
				{
					if (ai_action < 2)
					{
						is.mm_angle[AI] = 135 + (rand() % (220 - 135 + 1));
						if (ai_action == 1)
							is.mm_angle[AI] = 180;
					}
					else
						is.mm_angle[AI] = 110 + (rand() % (200 - 110 + 1));

					//cross hack
					if (ai_action == 1)
					{
						if (0 + (rand() % (1 - 0 + 1)) == 1)
							is.mm_angle[AI] = 0 + (rand() % (70 - 0 + 1));
						else
							is.mm_angle[AI] = 290 + (rand() % (359 - 290 + 1));
					}

					//set 180 angle
					if (is.mm_angle[AI] > 270)
						is.mm_angle_180[AI] = is.mm_angle[AI] - 271;
					if (is.mm_angle[AI] >= 0 && is.mm_angle[AI] <= 90)
						is.mm_angle_180[AI] = is.mm_angle[AI] + 89;
					if (is.mm_angle[AI] > 90 && is.mm_angle[AI] <= 270)
						is.mm_angle_180[AI] = 270 - is.mm_angle[AI];

					//cross hack
					if (ai_action == 1)
					{
						is.mm_angle_180[AI] = 180 - is.mm_angle_180[AI];
					}

					if (P[AI].side == SLEFT)
					{
						is.mm_angle[AI]	= 180 - is.mm_angle[AI];
						if (is.mm_angle[AI] < 0) is.mm_angle[AI]	+= 360;
						if (is.mm_angle[AI] > 360) is.mm_angle[AI]	-= 360;
					}
				}


			if (ai_action == 0)
				if (P[AI].fatigue < 40 &&
					player_distance < 500)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 200)
					P[AI].al_activate_slot(aslot_action, AC_JAB, is.mm_angle[AI], is.mm_angle_180[AI]);
			if (ai_action == 1)
				if (P[AI].fatigue < 40 &&
					player_distance < 500)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 200)
				{
					//is.mm_angle[AI] = 0;
					//is.mm_angle_180[AI] = 89;
					P[AI].al_activate_slot(aslot_action, AC_CROSS, is.mm_angle[AI], is.mm_angle_180[AI]);
				}
			if (ai_action == 2)
				if (P[AI].fatigue < 40 &&
					player_distance < 200)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 200)
					P[AI].al_activate_slot(aslot_action, AC_KICK_FWD, is.mm_angle[AI], is.mm_angle_180[AI]);
//					P[AI].al_activate_slot(aslot_action, AC_JAB);
			if (ai_action == 3)
				if (P[AI].fatigue < 40 &&
					player_distance < 200)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 200)
					P[AI].al_activate_slot(aslot_action, AC_KICK_SWD, is.mm_angle[AI], is.mm_angle_180[AI]);
//					P[AI].al_activate_slot(aslot_action, AC_JAB);
			if (P[AI].fatigue < 40)
			{
				if (P[AI].p_aslot[aslot_action] != NULL)
				{
					//cross hack
					if (P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_CROSS])
					{
						//is.mm_angle[AI] = 350;
						//is.mm_angle_180[AI] = 89;
					}
					P[AI].p_aslot[aslot_action]->state[AI]	= AS_FINAL;
					P[AI].p_aslot[aslot_action]->ui_valid[AI] = 1;
				}
			}
			ai_ini[AI] = 0;
		}
		if (//(P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x > 200 ||
			(player_distance > 500 ||
			P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_JAB] ||
			P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_CROSS] ||
			P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_KICK_FWD] ||
			P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_KICK_SWD]) &&
			player_distance > 80)
			//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x > 80)
		{
			is.t_move[AI][1] = 1.0f;
			is.PA[AI][AN_WALK_FWD] = AS_ACTIVE;
		}

		if (P[AI].side == SLEFT)
		{
			if (P[AI].fatigue < 70)
				if (player_distance < 80)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 80)
				{
					is.t_move[AI][0] = 1.0f;
					is.PA[AI][AN_WALK_BWD] = AS_ACTIVE;
				}
			if (P[AI].fatigue >= 70)
				if (player_distance < 550)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 150)
				{
					is.t_move[AI][1] = 0.075f;
					is.PA[AI][AN_WALK_FWD] = AS_ACTIVE;
				}
		}
		else
		{
			if (P[AI].fatigue < 70)
				if (player_distance < 80)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 80)
				{
					is.t_move[AI][0] = 1.0f;
					is.PA[AI][AN_WALK_BWD] = AS_ACTIVE;
				}
			if (P[AI].fatigue >= 70)
				if (player_distance < 550)
					//P[AI].sk.p_ref->v.p[0].x - P[!AI].sk.p_ref->v.p[0].x < 150)
				{
					is.t_move[AI][0] = 0.075f;
					is.PA[AI][AN_WALK_BWD] = AS_ACTIVE;
				}
		}

		if (is.PA[!AI][AN_JAB] == AS_PRE ||
			is.PA[!AI][AN_JAB] == AS_FINAL ||
			is.PA[!AI][AN_CROSS] == AS_PRE ||
			is.PA[!AI][AN_CROSS] == AS_FINAL ||
			is.PA[!AI][AN_KICK_FWD] == AS_PRE ||
			is.PA[!AI][AN_KICK_FWD] == AS_FINAL ||
			is.PA[!AI][AN_KICK_SWD] == AS_PRE ||
			is.PA[!AI][AN_KICK_SWD] == AS_FINAL)
		{
			//4 : 1
			if (0 + (rand() % (3 - 0 + 1)) == 1 &&
				(P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_TAP_ARMS] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_TAP_LEG] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_EVADE_HI] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_EVADE_LO] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_DUCK] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_EVADE_HI_HOLD] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_EVADE_LO_HOLD] &&
				P[AI].p_aslot[aslot_action] != P[AI].p_anmn[P[AI].asi][AN_DUCK_HOLD]))
//				(P[AI].p_aslot[aslot_action] == NULL ||
//				P[AI].p_aslot[aslot_action] == P[AI].p_anmn[P[AI].asi][AN_IDLE_LO]))
			{
				if (0 + (rand() % (1 - 0 + 1)))
				{
					if (P[AI].side == SLEFT)	is.mm_angle[AI] = 0;
					else						is.mm_angle[AI]	= 180;

					if (is.PA[!AI][AN_JAB] == AS_PRE ||
						is.PA[!AI][AN_JAB] == AS_FINAL ||
						is.PA[!AI][AN_CROSS] == AS_PRE ||
						is.PA[!AI][AN_CROSS] == AS_FINAL)
					{
						is.PA[AI][AN_TAP_ARMS]	= AS_FINAL;
					}
					else
					{
						is.PA[AI][AN_TAP_LEG]	= AS_FINAL;
					}
					if (P[AI].side == SLEFT)	is.mm_angle[AI] = 0;
					else						is.mm_angle[AI]	= 180;
					is.PA[AI][AN_TAP_ARMS] = AS_FINAL;
					//playsound_s(S_ERROR);
				}
				else
				{
					is.PA[AI][AN_DEFEND]	= AS_FINAL;
					//playsound_s(S_MENTER);
				}
				/*if (0 + (rand() % (1 - 0 + 1)))
				{
					is.PA[AI][AN_TAP_ARMS] = AS_FINAL;
				}
				else
					is.PA[AI][AN_TAP_LEG] = AS_FINAL;*/
//				is.PA[AI][AN_DEFEND] = AS_ACTIVE;
			}
			else
				if (0 + (rand() % (50 - 0 + 1)) == 1)
				{
					//is.PA[AI][AN_DEFEND]	= AS_FINAL;
					/*if (AI == 0)
						is.mm_angle[AI] = 0; //120 + (rand() % (240 - 120 + 1));
					else
						is.mm_angle[AI] = 180; //120 + (rand() % (240 - 120 + 1));
//					is.PA[AI][AC_TAP_JAB] = AS_ACTIVE;
					P[AI].al_activate_slot(aslot_action, AC_TAP_JAB);
					P[AI].p_aslot[aslot_action]->state[AI]	= AS_FINAL;
					P[AI].p_aslot[aslot_action]->ui_valid[AI] = 1;
					ai_ini[AI] = 0;*/
				}
		}
	}
	}

//push
if (is.key1D(DIK_X))
{
	is.PA[P2][AN_PUSH_ARMS]	= AS_PRE;
	is.mm_angle[P2]		= 200;
	is.mm_angle_180[P2]	= 45;
	P[P2].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
	is.PA[P2][AN_PUSH_ARMS]	= AS_FINAL;
}
//jab
if (is.key1D(DIK_E))
{
//	P[P1].gl_SetPush(4, 0.5f, 80);
//	P[P1].al_activate_slot(aslot_action, AN_KICK_FWD, 45, 135);
//	P[P1].p_aslot[aslot_action]->state[P1]	= AS_FINAL;
//		P[P2].al_activate_slot(aslot_action, AN_JAB, 200, 45);
//		P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;

//	P[P2].al_activate_slot(aslot_action, AN_JAB, 200, 45);
//	P[P2].p_aslot[aslot_action]->state[P2]	= AS_PRE;
	is.PA[P2][AN_JAB]	= AS_PRE;
	is.mm_angle[P2]		= 200;
	is.mm_angle_180[P2]	= 45;
	P[P2].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
	is.PA[P2][AN_JAB]	= AS_FINAL;
}
if (is.key1D(DIK_W))
{
//	P[P1].gl_SetPush(2, 0.5f, 80);
//	P[P2].al_activate_slot(aslot_action, AN_KICK_FWD, 135, 135);
	P[P2].al_activate_slot(aslot_action, AN_KICK_FWD, 165, 120);
	P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
}
//if (is.key(DIK_R))
if (is.key1D(DIK_R))
{
//	P[P2].al_activate_slot(aslot_action, AN_GUARD_FULL, 135, 135);
//	P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
//	P[P2].gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, time.current);
//	P[P2].al_activate_slot(aslot_action, AN_JAB, 140, 135);
//	P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
	P[P2].al_activate_slot(aslot_action, AN_CROSS, 320, 135);
	P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
}
if (is.key1D(DIK_Q))
{
	P[P2].al_activate_slot(aslot_action, AN_TAP_ARMS, 180, 90);
	P[P2].p_aslot[aslot_action]->state[P2]	= AS_FINAL;
//	P[P2].gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, time.current);
}

	//---- bot opt --------------------------------------------------------------------------------

	static bool botopt = false;
	if (is.key1D(DIK_G))
	{
		botopt = !botopt;
		hud_add_message(0, bmforange, "botopt %i", (int)botopt);
		playsound_s(S_MENTER);
	}
	if (botopt)
	{
		static LONGLONG t_lastaction = 0;
		bool action = 0;
		static int type = 0;

		static int opt_angle		= 0;
		static float opt_distance	= 0;
		static float opt_fat		= 0;
		static int opt_dam			= 0;

		static float targ_dist		= 150;
		static int walk				= 1;

		//time passed
		if (time.current >= t_lastaction + (time.freq * (1.0f / option.data.speed)) && !walk && !action)
		{
	//		action = 1;
			type = !type;
			//repeat force
			if (is.key(DIK_LSHIFT))
				type = 1;
			if (type == 0)
				targ_dist	= (float)random(150, 0);
			else
				targ_dist	= opt_distance;
			walk = 1;
		}

		if (walk)
		{
			walk = 0;

			if (player_distance > targ_dist + 2)
			{
				is.PA[P2][AN_WALK_FWD] = AS_ACTIVE;
				is.t_move[P2][1]	= 1.0f;
				walk = 1;
			}
			else
			{
				action = 1;
	//			walk = 0;
			}
			if (player_distance < targ_dist - 2 &&
				(P[P2].sk.p_ref->v.p[0].x > 20 && P[P2].sk.p_ref->v.p[0].x < 780))
			{
				is.PA[P2][AN_WALK_BWD] = AS_ACTIVE;
				is.t_move[P2][0]	= 1.0f;
				walk = 1;
			}
			else
			{
				action = 1;
	//			walk = 0;
			}
		}

		if (action && !walk)
		{
			t_lastaction	= time.current;

			//jab
			{
				is.PA[P2][AN_JAB]	= AS_PRE;
				//angle
				if (type == 0)
				{
					if (P[P2].side == SLEFT)
					{
						if (random())
							is.mm_angle[P2]		= random(359, 270);
						else
							is.mm_angle[P2]		= random(90, 0);
					}
					else
					{
						is.mm_angle[P2]		= random(270, 90);
					}
				}
				else
				{
					is.mm_angle[P2]	= opt_angle;
				}
				//set 180 angle
				if (is.mm_angle[P2] > 270)
					is.mm_angle_180[P2] = is.mm_angle[P2] - 271;
				if (is.mm_angle[P2] >= 0 && is.mm_angle[P2] <= 90)
					is.mm_angle_180[P2] = is.mm_angle[P2] + 89;
				if (is.mm_angle[P2] > 90 && is.mm_angle[P2] <= 270)
					is.mm_angle_180[P2] = 270 - is.mm_angle[P2];

				P[P2].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
				is.PA[P2][AN_JAB]	= AS_FINAL;
			}

			action			= 0;
		}

		//analysis
		if (!action &&
			!walk &&
			P[P2].damage_dealt_last > opt_dam)
		{
			opt_angle				= is.mm_angle[P2];
			opt_distance			= player_distance;
			opt_fat					= P[P2].fatigue;
			opt_dam					= P[P2].damage_dealt_last;
		}

		//reset
		if (is.key1D(DIK_T))
		{
			opt_angle				= 0;
			opt_distance			= 0;
			opt_fat					= 0;
			opt_dam					= 0;
		}

		//display data
		if (type == 0)
			dd.typebmf(10, 75 - 16, bmfwhite, "type: %i LEARN", type);
		else
			dd.typebmf(10, 75 - 16, bmfwhite, "type: %i REPEAT", type);
		dd.typebmf(10, 75, bmfred, "opt_angle: %i", opt_angle);
		dd.typebmf(10, 75 + 16 * 1, bmfred, "opt_dist: %.1f, target: %.1f (walk: %i)", opt_distance, targ_dist, walk);
		dd.typebmf(10, 75 + 16 * 2, bmfred, "opt_fat: %.1f", opt_fat);
		dd.typebmf(10, 75 + 16 * 3, bmfred, "opt_dam: %i", opt_dam);
		dd.typebmf(10, 75 + 16 * 4, bmfblue, "action: %i, %i %i", action, is.PA[P2][AN_WALK_FWD], is.PA[P2][AN_WALK_BWD]);
		dd.typebmf(10, 75 + 16 * 5, bmfblue, "dist: %i", (int)player_distance);
	}

	//---------------------------------------------------------------------------------------------

	//bot processing
	if (BOT[B1].active)		BOT[B1].process();
	if (BOT[B2].active)		BOT[B2].process();

	if (!demo_playback)
	{
	if (dev_s_animate)
//!! knockout		if (!P[P1].gl_ko && !P[P2].gl_ko)
	{
		//process input handling every frame
		P[P1].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
		P[P2].gl_process_input(is.PA, is.mm_angle, is.mm_angle_180, is.t_move);
	}
	}

	//reset damage
	if (is.dikey1D[DIK_RETURN] & 0x80)
	{
		int pos		= 0 + (rand() % (1 - 0 + 1));
		P[P1].reset(pos);
		P[P2].reset(pos);
		hud_add_message(0, bmfred, "RESET");

//		option.data.speed = 1.0f;
	}

	//animate
	if (dev_s_animate &&
		!demo_playback)
	{
//		P[P1].animate(time.current, (float)time.sca, option.data.speed);
//		P[P2].animate(time.current, (float)time.sca, option.data.speed);
		for (register int sf = 0; sf < option.data.subframes; ++sf)
		{
/*			//if not first subframe update timer
			if (sf)
				//get time and store it in current
				QueryPerformanceCounter((LARGE_INTEGER*) &time.current);
				//time.get_timer();*/

//!! knockout			if (!P[P1].gl_ko && !P[P2].gl_ko)
			{
				P[P1].al_animate(false);
				P[P2].al_animate(false);
			}

			//!!
			P[P1].process_bones(s_scale, s_mpy);
			P[P2].process_bones(s_scale, s_mpy);

			//player distance
			player_distance = (float)fabs(P[P1].sk.p_ref->v.p[0].x - P[P2].sk.p_ref->v.p[0].x);

//!! knockout			if (!P[P1].gl_ko && !P[P2].gl_ko)
			{
			//!! process game logic every subframe
			P[P1].gl_process_game_logic(is.t_move);
			P[P2].gl_process_game_logic(is.t_move);

			//do collision detection tests
			collision_detection();

			//stop if collision occured
/*			int _hit = 0;
			for (register int i = 0; i < 6; ++i)
			{
//				if (rcd.attack[P1][i] != -1)
//				if (rcd.defend[P1] != -1)
				if (rcd.attack_cancel[P1][i] == 1)
				{
					//set hit flag
					_hit			= 1;
					//stop animation
					dev_s_animate	= 0;
					break;
				}
			}
			//if hit flag set, break
			if (_hit)
				break;*/

			//calculate damage to cause if collision occured
			//and store result in rcd
			rcd.damage[P1] = P[P1].gl_process_damage_off(is.t_move);
			rcd.damage[P2] = P[P2].gl_process_damage_off(is.t_move);
			}

			//!! automatischer seitenwechsel hier rein

			//render subframes hollow
			//option.data.r_hollow = 1;
			//dd.drawscene(&pd, 0, 0, black, 0, 0, 0);
			//option.data.r_hollow = 0;
		}

		//update particle arrays
		P[P1].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);
		P[P2].al_update_particles(option.data.shadows, s_scale, s_mpy, option.data.speed, option.data.zoomfactor);

		//gammaflash
		if (P[P1].blood_gammaflash)
		{
			dd.gamma_fade_ini(1, 2, red, 0.1f / option.data.speed);
			P[P1].blood_gammaflash = false;
		}
		if (P[P2].blood_gammaflash)
		{
			dd.gamma_fade_ini(1, 2, red, 0.1f / option.data.speed);
			P[P2].blood_gammaflash = false;
		}

		//sounds
		process_sound();
	}

	//demo playback
	if (demo_playback)
	{
		P[P1].process_bones(s_scale, s_mpy);
		P[P2].process_bones(s_scale, s_mpy);
	}

		//zooom--------------------------------------------------------------------
/*	static int zoomer = 0;
	static int zi = 0;

	if (zoom ||
		(is.dimouse[1].rgbButtons[0] & 0x80 && is.dikey[DIK_LSHIFT] & 0x80))
	{
		dd.bordermove(0, 0, 2, 1.0f, 255, 255, 255);
		//option.data.zoomfactor = 1.0f;
		zoomer = 1;
		zoom = 0;
	}

	if (zoomer)
	{
		if (zi == 0)
		{
			zi = 1;
			option.data.zoomfactor = 0.01f;
		}

		if (option.data.zoomfactor < 1.0f)
		{
			option.data.zoomfactor += 0.75f * (float)time.sca * option.data.speed;
		}

		if (option.data.zoomfactor >= 1.0f)
		{
			option.data.zoomfactor = 1.0f;
			zi = 0;
			zoomer = 0;
		}

		P[P1].al_animate(option.data.speed,							//user set speed
						 option.data.zoomfactor, true);				//user set zoomfactor

		P[P2].al_animate(option.data.speed,
						 option.data.zoomfactor, true);
	}*/

//	if (is.dimouse[1].lZ > 0)		option.data.zoomfactor += 0.1f;
//	if (is.dimouse[1].lZ < 0)		option.data.zoomfactor -= 0.1f;

	//!! bottom
	//line l(0, s_mpy, 799, s_mpy);
	//dd.drawline(l, black);

/*	option.data.zoomfactor = 250 / fabs(P[P1].sk.p_ref->v.p[0].x - P[P2].sk.p_ref->v.p[0].x);
	if (option.data.zoomfactor < option.dataMIN.zoomfactor)
		option.data.zoomfactor = option.dataMIN.zoomfactor;
	if (option.data.zoomfactor > option.dataMAX.zoomfactor)
		option.data.zoomfactor = option.dataMAX.zoomfactor;*/

	//!! ins player object
	//adjust head and fist radius by zoomfactor
//	P[P1].sk.radius_fist	=	P[P2].sk.radius_fist	= 12 / 2 * option.data.zoomfactor;
//	P[P1].sk.radius_head	=	P[P2].sk.radius_head	= (26 / 2 - 1)* option.data.zoomfactor;

	//adjust shadow plane according to zoomfactor
//	s_mpy = S_PYDEF + (int)((S_FLOOR - S_PYDEF) * option.data.zoomfactor);

	//dd.typefont(200, 60, "", option.data.zoomfactor);

	//____ fom ___________________________________________________________________________________

/*	if (is.dimouse[1].lZ < 0 && P[P1].fatigue + 5 <= 100)
		P[P1].fatigue += 5;
	if (is.dimouse[1].lZ > 0 && P[P1].fatigue - 5 >= 0)
		P[P1].fatigue -= 5;
	if (is.dimouse[2].lZ > 0 && P[P2].fatigue + 5 <= 100)
		P[P2].fatigue += 5;
	if (is.dimouse[2].lZ < 0 && P[P2].fatigue - 5 >= 0)
			P[P2].fatigue -= 5;*/

	//bordermove
	//if (is.dikey1D[DIK_6] & 0x80)
	//	dd.bordermove(1, 0, 2, 1.0f, 255, 255, 255);
	//if (is.dikey1D[DIK_5] & 0x80)
	//	dd.bordermove(0, 0, 2, 1.0f, 255, 255, 255);

						//---- particle ----------------------------------------------------------
/*
						static particle_heap blood;
						static int blood_ini = 0;
						static point source;
						static int noblood = 50;
						//show in abh�ngigkeit von st�rke
						//winkel von schlag

						source.x = P[P2].sk.chead.x + P[P2].sk.radius_head;
						source.y = P[P2].sk.chead.y;

						if (blood_ini == 0)
						{
							blood_ini = 1;
							blood.create_heap(noblood,
											  dd.rSCREEN_ARENA_TOP);
						}

						//update particle heap
						if (blood.state == 0)
						{
							//float rad_hit = rcd.head[P2] / 180 * PI;
							float rad_hit = 180 / 180 * PI;

							source.x = P[P2].sk.chead.x;
							source.y = P[P2].sk.chead.y;

							source.x = source.x + P[P2].sk.radius_head * (float)cos(rad_hit);
							source.y = source.y + P[P2].sk.radius_head * (float)sin(rad_hit);

							blood.update(time.current,
										 time.sca,
										 option.data.speed,
										 option.data.shadows, s_mpy, s_scale,
										 (int)source.x, (int)source.y,
										 //(int)P[P1].sk.b[bn].angle + 90, 100,
										 (int)P[P2].sk.b[bn].angle - 90, 100,
										 true);
						}

						//draw particle heap
						if (blood.state == 0)
							dd.drawparticles(blood.pp, noblood, option.data.shadows, 100);

//						if (is.dimouse1D[1].rgbButtons[2] & 0x80)
						if (is.dimouse1D[1].rgbButtons[2] & 0x80 ||
							rcd.bone[P2][19] == 1)
						{
/*							blood.initialization(time.current,
												 0, 0,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 50, 150,
												 0, 100,
												 500, 800);*/
							//direction is neck plus 90 degree

/*							float rad_hit = rcd.angle_h[P2] / 180 * PI;

							source.x = P[P2].sk.chead.x;
							source.y = P[P2].sk.chead.y;

							source.x = source.x + P[P2].sk.radius_head * (float)cos(rad_hit);
							source.y = source.y + P[P2].sk.radius_head * (float)sin(rad_hit);

							blood.initialization(time.current,
												 1, 0.1f,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 50, 150,
												 //(int)P[P2].sk.b[bn].angle + 90, 100,
												 (int)rcd.angle_h[P2], 100,
												 500, 1500,
												 option.data.speed);

							blood.state = 0;
						}
						if (is.dimouse1D[1].rgbButtons[3] & 0x80)
						{
							//direction is neck plus 90 degree
							blood.initialization(time.current,
												 0, 0,
												 (int)source.x, (int)source.y,
												 0, 0,
												 400.0f, 0.5f, 0.5f,
												 20, 150,
												 (int)P[P1].sk.b[bn].angle + 90, 100,
												 500, 1500,
												 option.data.speed);

							blood.state = 0;
						}

/*	if (P[P1].p_aslot[0] != NULL)
	{
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}

	if (is.dikey1D[DIK_NUMPAD4] & 0x80)
	{
		ZeroMemory(&P[P1].cki, sizeof(P[P1].cki));
		dev_s_animate = 1;
		P[P1].p_aslot[0] = p_dev_a[P[P1].asi][0];
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}
	if (is.dikey1D[DIK_NUMPAD5] & 0x80)
	{
		ZeroMemory(&P[P1].cki, sizeof(P[P1].cki));
		dev_s_animate = 1;
		P[P1].p_aslot[0] = p_dev_a[P[P1].asi][1];
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}
	if (is.dikey1D[DIK_NUMPAD6] & 0x80)
	{
		ZeroMemory(&P[P1].cki, sizeof(P[P1].cki));
		dev_s_animate = 1;
		P[P1].p_aslot[0] = p_dev_a[P[P1].asi][2];
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}
	if (is.dikey1D[DIK_NUMPAD7] & 0x80)
	{
		ZeroMemory(&P[P1].cki, sizeof(P[P1].cki));
		dev_s_animate = 1;
		P[P1].p_aslot[0] = p_dev_a[P[P1].asi][3];
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}
	if (is.dikey1D[DIK_NUMPAD8] & 0x80)
	{
		ZeroMemory(&P[P1].cki, sizeof(P[P1].cki));
		dev_s_animate = 1;
		P[P1].p_aslot[0] = p_dev_a[P[P1].asi][4];
		P[P1].p_aslot[0]->angle[P1] = is.mm_angle[P1];
		P[P1].p_aslot[0]->angle_180[P1] = is.mm_angle_180[P1];
	}

	for (register int i = 0; i < 21; ++i)
	{
		P[P1].casi[i] = 0;
		P[P2].casi[i] = 0;
	}

	if (dev_s_animate)
		P[P1].animate(time.current, (float)time.sca, option.data.speed);
//		P[P2].animate(time.current, (float)time.sca, option.data.speed);
//		for (register int sf = 0; sf < option.data.subframes; ++sf)
//			P[P1].animate(time.current,
//								  (float)(time.sca / option.data.subframes),	//passed time since last
//								   option.data.speed);

/*	//!! animation index
	static int ai = -1;

	//!!
	if (is.dimouse1D[1].rgbButtons[0] & 0x80)
		for (register int b = 0; b < 19; ++b)
			P[P1].sk.b[b].damage = 0;

	//animation
/*	if (is.dikey1D[DIK_ADD] & 0x80 ||
		is.PA[P1][AC_JAB] == AS_PRE ||
		is.PA[P1][AC_CROSS] == AS_FINAL ||
		is.PA[P1][AC_DEFEND] == AS_ACTIVE)*/
/*	if (is.dikey1D[DIK_ADD] & 0x80)
	{
		for (register int a = 0; a < 5; ++a)
			for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
				p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;

		P[P1].cki[0] = 0;

		dev_s_animate = !dev_s_animate;
		if (dev_s_animate == 0)
			ai = -1;
	}

	if (dev_s_animate)
	{
/*		if (is.dikey1D[DIK_ADD] & 0x80)
		{
			ai = dev_cai;
			dev_s_animate = ON;
		}*/

/*		if (is.PA[P1][AC_JAB] == AS_PRE)
		{
			for (register int a = 0; a < 5; ++a)
				for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
					p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;
			P[P1].cki[0] = 0;
			P[P1].cki[1] = 0;
			ai = 0;
			dev_s_animate = ON;
			p_dev_a[P[P1].asi][0]->ui_valid[P1]	= 0;
//			p_dev_a[P[P1].asi][0]->angle[P1]		= is.mm_angle[P1];
//			p_dev_a[P[P1].asi][0]->angle_180[P1]	= is.mm_angle_180[P1];
			p_dev_a[P[P1].asi][0]->angle[P1]		= is.mm_angle[P1];
			p_dev_a[P[P1].asi][0]->angle_180[P1]	= 89;
		}
		if (is.PA[P1][AC_JAB] == AS_FINAL)
		{
			p_dev_a[P[P1].asi][0]->ui_valid[P1]	= 1;
			p_dev_a[P[P1].asi][0]->angle[P1]		= is.mm_angle[P1];
			p_dev_a[P[P1].asi][0]->angle_180[P1]	= is.mm_angle_180[P1];
		}
		if (is.PA[P1][AC_CROSS] == AS_PRE)
		{
			for (register int a = 0; a < 5; ++a)
				for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
					p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;
			P[P1].cki[0] = 0;
			P[P1].cki[1] = 0;
			ai = 1;
			dev_s_animate = ON;
		}
		if (is.PA[P1][AC_DEFEND] == AS_FINAL)
		{
			for (register int a = 0; a < 5; ++a)
				for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
					p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;
			P[P1].cki[0] = 0;
			ai = 2;
			dev_s_animate = ON;
		}
		if (is.PA[P1][AC_KICK_SWD] == AS_PRE ||
			is.PA[P1][AC_KICK_FWD] == AS_PRE)
		{
			for (register int a = 0; a < 5; ++a)
				for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
					p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;
			P[P1].cki[0] = 0;
			P[P1].cki[1] = 0;
			ai = 3;
			dev_s_animate = ON;
		}

		//cancel to default
		if (is.PA[P1][AC_JAB] == AS_CANCEL ||
			is.PA[P1][AC_CROSS] == AS_CANCEL ||
			is.PA[P1][AC_KICK_SWD] == AS_CANCEL ||
			is.PA[P1][AC_KICK_FWD] == AS_CANCEL)
		{
			for (register int a = 0; a < 5; ++a)
				for (register int k = 0; k < p_dev_a[P[P1].asi][a]->nokf; ++k)
					p_dev_a[P[P1].asi][a]->pkf[k].state[P1][0] = 0;
			P[P1].cki[0] = 0;
			ai = 4;
			dev_s_animate = ON;
		};
	}

	//if animation done switch off
//	if (dev_s_animate)
	if (ai != -1)
		if (P[P1].dev_animate_single(time.current,
											  (float)time.sca,
											  option.data.speed,
											  p_dev_a[P[P1].asi],
											  ai,
//											  dev_cai,
											  4,
											  false))
											  ai = -1;
//											  dev_s_animate = false;*/
};

//------------------------------------------------------------------------------------------------
//
//	master_frame dev_ingame
//
//	checks ingame input
//
//------------------------------------------------------------------------------------------------

void master_frame::dev_ingame()
{
/*	//walk speed factor
	float wsf = 0.1f / option.data.speed;

	//!!! walking anpassen
	//for both players
	for (register int p = 0; p < 2; ++p)
	{
		if (is.PA[p][AC_WALK_BWD])
		{
			if (P[p].side == SLEFT)
				P[p].sk.p_ref->v.p[0].x -= 150 * option.data.zoomfactor * (float)time.sca * option.data.speed;
			else
				P[p].sk.p_ref->v.p[0].x += 150 * option.data.zoomfactor * (float)time.sca * option.data.speed;
			/*if (is.t_move[p][0] < wsf)
				P[p].sk.p_ref->v.p[0].x -= 200 * (is.t_move[p][0] / wsf) * (float)time.sca * option.data.speed;
			else
				P[p].sk.p_ref->v.p[0].x -= 200 * (float)time.sca * option.data.speed;*/
	//							P[P1].sk.p_ref->v.p[0].x -= 200 * (float)time.sca * option.data.speed;
	//							P[P1].sk.p_ref->v.p[0].x -= 200 * (is.t_move[P1][0] * 2) * (float)time.sca * option.data.speed;
/*		}
		if (is.PA[p][AC_WALK_FWD])
		{
			if (P[p].side == SLEFT)
				P[p].sk.p_ref->v.p[0].x += 150 * option.data.zoomfactor * (float)time.sca * option.data.speed;
			else
				P[p].sk.p_ref->v.p[0].x -= 150 * option.data.zoomfactor * (float)time.sca * option.data.speed;
			/*if (is.t_move[p][1] < wsf)
				P[p].sk.p_ref->v.p[0].x += 200 * (is.t_move[p][1] / wsf) * (float)time.sca * option.data.speed;
			else
				P[p].sk.p_ref->v.p[0].x += 200 * (float)time.sca * option.data.speed;*/
	//							P[P1].sk.p_ref->v.p[0].x += 200 * (float)time.sca * option.data.speed;
	//							P[P1].sk.p_ref->v.p[0].x += 200 * (is.t_move[P1][1] * 2) * (float)time.sca * option.data.speed;
/*		}
	}

	//!! check boundaries

	//!!
/*	//in player object

	//feet change (also in editor)
	if (is.PA[P1][AC_STANCE_FEET])
	{
		P[P1].set_stance(!P[P1].stance_feet);
		P[P1].fatigue_buff += anmn[P[P1].asi][AN_STANCE_FEET].gl_fatigue;
	}
	if (is.PA[P2][AC_STANCE_FEET])
	{
		P[P2].set_stance(!P[P2].stance_feet);
		P[P2].fatigue_buff += anmn[P[P2].asi][AN_STANCE_FEET].gl_fatigue;
	}*/
};

//------------------------------------------------------------------------------------------------
//
//	master_frame sdemo_start
//
//	starts state demo recording
//
//------------------------------------------------------------------------------------------------

bool master_frame::sdemo_startrec(char *pname, int fps)
{
	//if already recording return false
	//!!! playback und aufnahme gleichzeitig?
	if (demo_record)
		return false;

	//open demo file (append) if file name valid
	if (pname != NULL)
	{
		//create demo folder
		_mkdir("demos");

		//delete file if already exists
		DeleteFile(pname);
		f_demo_rec		= fopen(pname, "wb");
		fclose(f_demo_rec);

		f_demo_rec		= fopen(pname, "ab");
	}
	else
	{
		//log recording
		gf_logger(true, "DEMO recording sdemo_startrec failed %s", pname);
		return false;
	}

	//if file successfully opened
	if (f_demo_rec != NULL)
	{
		//set time data
		t_drec_start		= time.current;
		t_drec_lastframe	= time.current;

		//set demo fps
		//-1 no limit
		if (fps > 150)					fps		= 150;
		if (fps < 10 && fps != -1)		fps		= 10;
		demo_fps		= fps;

		//write file header
		//!!
		fprintf(f_demo_rec, "%i\n", demo_fps);

		//set recording on
		demo_record		= true;

		//log recording
		gf_logger(false, "DEMO recording started %s", pname);
	}
	else
	{
		//log recording
		gf_logger(true, "DEMO recording sdemo_startrec failed %s", pname);
		//no recording
		return false;
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame sdemo_stop
//
//	stops recording a demo started with sdemo_start()
//
//------------------------------------------------------------------------------------------------

bool master_frame::sdemo_stop(int stop)
{
	//stop recording
	if (stop == 0)
	{
		//if recording a demo
		if (demo_record && f_demo_rec != NULL)
		{
			//write file end
			//!!

			//close demo file
			fclose(f_demo_rec);

			//reset time data
			t_drec_start		= 0;
			t_drec_lastframe	= 0;

			//stop recording
			demo_record		= false;

			//log recording
			gf_logger(false, "DEMO recording stopped");

			return true;
		}
		else
			//no demo recording
			return false;
	}
	//stop playback
	else
	{
		//if playing back a demo
		if (demo_playback && f_demo_pb != NULL)
		{
			//close demo file
			fclose(f_demo_pb);

			//reset time data
			t_dpb_start				= 0;
			t_dpb_lastframe			= 0;

			//stop playback
			demo_playback			= false;

			//log playback
			gf_logger(false, "DEMO playback stopped");

			return true;
		}
		else
			//no demo playback
			return false;
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame sdemo_record
//
//	records demo started with sdemo_startrec()
//	called every frame, writes player states into file
//
//------------------------------------------------------------------------------------------------

bool master_frame::sdemo_record()
{
	//if recording and file valid
	//and recording mode is either every frame or specified fps reached
	if (demo_record && f_demo_rec != NULL &&
		(demo_fps == -1 || time.current >= t_drec_lastframe + time.freq / demo_fps))
	{
		//---- write time data -------------------------------------------------------------------

		//time index relative to start
		fprintf(f_demo_rec, "%li ", time.current - t_drec_start);

		//time index relative to last update
//		fprintf(f_demo_rec, "%li\n", time.current - t_drec_lastframe);

		//update last update index
		t_drec_lastframe		= time.current;

		//---- write player data -----------------------------------------------------------------

		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//hara position
			fprintf(f_demo_rec,
					"%.f %.f\n",
					P[p].sk.p_ref->v.p[0].x,
					P[p].sk.p_ref->v.p[0].y);

			//for all bones
			for (register int b = 0; b < 19; ++b)
			{
				//angle, length and width
				fprintf(f_demo_rec,
						"%.f %.f %.f\n",
						P[p].sk.b[b].angle,
						P[p].sk.b[b].length,
						P[p].sk.b[b].width);

				//damage, hit_state, hit_state_e
				fprintf(f_demo_rec,
						"%i %i %i\n",
						P[p].sk.b[b].damage,
						P[p].sk.b[b].hit_state,
						P[p].sk.b[b].hit_state_e);
			}

			//fatigue, stance_feet
			fprintf(f_demo_rec,
					"%i %i\n",
					(int)P[p].fatigue,
					P[p].stance_feet);
		}

		//set demo frame end sign
		fprintf(f_demo_rec, "\n\n\n");

		/*		winloss
				(lockstate)
				sp�ter mal blood
				sound
		*/

		return true;
	}
	else
		//!! cancel recording
		return false;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame sdemo_startplay
//
//	starts demo playback
//
//------------------------------------------------------------------------------------------------

bool master_frame::sdemo_startplay(char *pname)
{
	//no playback when still recording or already playing back
	if (demo_record || demo_playback)
		return false;

	//open file (read) if name valid
	if (pname != NULL)
	{
		f_demo_pb		= fopen(pname, "rb");
	}
	else
	{
		//log playback
		gf_logger(true, "DEMO playback sdemo_startplay failed %s", pname);
		return false;
	}

	//if files successfully opened
	if (f_demo_pb != NULL)
	{
		//set time data
		t_dpb_start				= time.current;
		t_dpb_lastframe			= 0;

		//read file header
		fscanf(f_demo_pb, "%*i");

		//set playback on
		demo_playback	= true;

		//log playback
		gf_logger(false, "DEMO playback started %s", pname);
	}
	else
	{
		//log playback
		gf_logger(true, "DEMO playback sdemo_startplay failed %s", pname);
		return false;
	}

	return true;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame sdemo_playback
//
//	plays back demo started with sdemo_startplay()
//
//------------------------------------------------------------------------------------------------

bool master_frame::sdemo_playback()
{
	//if recording and file valid
	if (demo_playback && f_demo_pb != NULL)
	{
		//assign frame if time reached, adjusted to speed
		if (t_dpb_lastframe <= (time.current - t_dpb_start) * option.data.speed)
		{
			//endless loop
			while (true)
			{
				//time indices
				if (EOF == fscanf(f_demo_pb,
								  "%li",
								  &t_dpb_lastframe))
					//no more data, end of demo, return false;
					return false;

				//break loop if demo frame with right time index found
				//else read in frame but don't apply data
				if (t_dpb_lastframe >= (time.current - t_dpb_start) * option.data.speed)
					break;

				//for both players
				for (register int p = 0; p < 2; ++p)
				{
					//hara position
					fscanf(f_demo_pb, "%*f %*f");

					//for all bones
					for (register int b = 0; b < 19; ++b)
					{
						//angle, length and width
						fscanf(f_demo_pb, "%*f %*f %*f");

						//damage, hit_state, hit_state_e
						fscanf(f_demo_pb, "%*i %*i %*i");
					}

					//fatigue, stance_feet
					fscanf(f_demo_pb, "%*f %*i");
				}
			}

			//read in demo frame and assign data to player
			//for both players
			for (register int p = 0; p < 2; ++p)
			{
				//hara position
				fscanf(f_demo_pb,
					   "%f %f",
					   &P[p].sk.p_ref->v.p[0].x,
					   &P[p].sk.p_ref->v.p[0].y);

				//for all bones
				for (register int b = 0; b < 19; ++b)
				{
					//angle, length and width
					fscanf(f_demo_pb,
						   "%f %f %f",
						   &P[p].sk.b[b].angle,
						   &P[p].sk.b[b].length,
						   &P[p].sk.b[b].width);

					//damage, hit_state, hit_state_e
					fscanf(f_demo_pb,
						   "%i %i %i",
						   &P[p].sk.b[b].damage,
						   &P[p].sk.b[b].hit_state,
						   &P[p].sk.b[b].hit_state_e);

					//damage limits
					if (P[p].sk.b[b].damage < 0)		P[p].sk.b[b].damage = 0;
					if (P[p].sk.b[b].damage > 100)		P[p].sk.b[b].damage = 100;
				}

				//holds stance, only set if different then previous stance
				int stance;

				//fatigue, stance_feet
				fscanf(f_demo_pb,
					   "%f %i",
					   &P[p].fatigue,
					   &stance);

				//set stance
				if (stance != P[p].stance_feet)
					P[p].set_stance(stance);

				//fatigue limits
				if (P[p].fatigue < 0)		P[p].fatigue = 0;
				if (P[p].fatigue > 100)		P[p].fatigue = 100;
			}
		}

	//!! wenn EOF abbrechen

		return true;
	}
	else
		//!! cancel playback
		return false;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame con_check_dumpmessages
//
//------------------------------------------------------------------------------------------------

void master_frame::con_check_dumpmessages()
{
	//object console dumps
	for (register int p = 0; p < 2; ++p)
	{
		//players
		if (P[p].con_dumpmessage[0])
		{
			con.print_outputbuffer(P[p].con_dumpmessage);
			P[p].con_clear();
		}
		//bots
		if (BOT[p].con_dumpmessage[0])
		{
			con.print_outputbuffer(BOT[p].con_dumpmessage);
			BOT[p].con_clear();
		}
	}

	//direct draw
	if (dd.con_dumpmessage[0])
	{
		con.print_outputbuffer(dd.con_dumpmessage);
		dd.con_clear();
	}
	//direct input
//	if (di.con_dumpmessage[0])
//	{
//		con.print_outputbuffer(di.con_dumpmessage);
//		di.con_clear();
//	}
	//direct sound
	if (ds.con_dumpmessage[0])
	{
		con.print_outputbuffer(ds.con_dumpmessage);
		ds.con_clear();
	}
	//master_frame
	if (con_dumpmessage[0])
	{
		con.print_outputbuffer(con_dumpmessage);
		con_clear();
	}
}

//------------------------------------------------------------------------------------------------
//
//	master_frame RegisterConVars
//
//	registers console variable
//
//------------------------------------------------------------------------------------------------

void master_frame::RegisterConVars(console *pcon)
{
	CLASS_CVI(bool, walkbot, 0, 0, 1, CONVARF_RESTRICTED);
	CLASS_CVI(int, host_id, 0, 0, 1, CONVARF_RESTRICTED);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame con_add_message
//
//	adds message to console
//
//------------------------------------------------------------------------------------------------

void master_frame::con_add_message(char *format, ...)
{
	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	//clear message dump
	con_clear();

	//print formated string in console dump message
	vsprintf(con_dumpmessage, format, ap);

	//clear up
	va_end(ap);
}

//------------------------------------------------------------------------------------------------
//
//	master_frame con_clear
//
//	clears console message buffer
//
//------------------------------------------------------------------------------------------------

void master_frame::con_clear()
{
	ZeroMemory(&con_dumpmessage, sizeof(con_dumpmessage));
}

//------------------------------------------------------------------------------------------------
//
//	master_frame hud_add_message
//
//	with argumented hud_id and color
//
//------------------------------------------------------------------------------------------------

void master_frame::hud_add_message(int _hud_id, int color, char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "master_frame::hud_add_message NULL");
		return;
	}

	//verify id
	if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
	if (_hud_id < 0)				_hud_id = 0;

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//create new hud entry
	hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	master_frame hud_add_message
//
//	with default hud_id and color
//
//------------------------------------------------------------------------------------------------

void master_frame::hud_add_message(char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "master_frame::hud_add_message NULL");
		return;
	}

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//default values
	int _hud_id		= 0;
	int color		= bmfblack;

	//create new hud entry
	hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	con_func_t constructor
//
//------------------------------------------------------------------------------------------------

con_func_t::con_func_t()
{
	name	= NULL;
	func	= NULL;
	flags	= 0;
	next	= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	con_func_t init
//
//------------------------------------------------------------------------------------------------

void con_func_t::init(console *pcon,
					  const char *inName,
					  con_func_bodyFunc_t inFunc,
					  unsigned long inFlags,
					  unsigned char isVarHandler)
{
	name	= inName;
	func	= inFunc;
	flags	= inFlags;
	next	= NULL;

	if (isVarHandler)			pcon->RegisterVarHandler(this);
	else						pcon->RegisterFunc(this);
}

//------------------------------------------------------------------------------------------------
//
//	con_var_t constructor
//
//------------------------------------------------------------------------------------------------

con_var_t::con_var_t()
{
	name			= NULL;
	varTypeName		= NULL;
	valuePtr		= NULL;
	valueMin		= NULL;
	valueMax		= NULL;
	instance		= 0;
	elements		= 0;
	flags			= 0;

	handler			= NULL;
	next			= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	con_var_t init
//
//------------------------------------------------------------------------------------------------

void con_var_t::init(console *pcon,
					 const char *inName,
					 int _elements,
					 void *inValuePtr,
					 void *inValueMin,
					 void *inValueMax,
					 const char *inVarTypeName,
					 unsigned long inFlags)
{
	name			= inName;
	varTypeName		= inVarTypeName;
	valuePtr		= inValuePtr;
	valueMin		= inValueMin;
	valueMax		= inValueMax;
	instance		= 0;
	elements		= _elements;
	flags			= inFlags;

	//handler may be NULL if handler hasn't registered yet; that's ok
	handler			= pcon->GetHandlerForVarType((char*)varTypeName);
	next			= NULL;
	pcon->RegisterVar(this);
}

//------------------------------------------------------------------------------------------------
//
//	console struct function definitions
//
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//
//	console init
//
//	initializes console functions and variables
//
//------------------------------------------------------------------------------------------------

void console::init(console *pcon)
{
	CLASS_CHI(int);
	CLASS_CHI(float);
	CLASS_CHI(bool);
	CLASS_CHI(char);
	CLASS_CHI(RGBcolor);
	CLASS_CHI(RECT);

	CLASS_CFI(clear, 0);
	CLASS_CFI(listvars, 0);
	CLASS_CFI(listcmds, 0);
	CLASS_CFI(listtypes, 0);
	CLASS_CFI(help, 0);
	CLASS_CFI(version, 0);
	CLASS_CFI(exec, 0);
	CLASS_CFI(screenshot, 0);

	CLASS_CFI(exit, 0);
	CLASS_CFI(program_state, CONFUNCF_RESTRICTED);
	CLASS_CFI(input, 0);
	CLASS_CFI(bind, 0);
	CLASS_CFI(unbind, 0);
//	CLASS_CFI(screenmode, 0);

	CLASS_CFI(fps_max, 0);
	CLASS_CFI(sound, 0);
	CLASS_CFI(volume, 0);
	CLASS_CFI(ko_mode, 0);
	CLASS_CFI(fight_mode, 0);
	CLASS_CFI(def_mode, 0);
	CLASS_CFI(handicap, 0);

	CLASS_CFI(playdemo, 0);

	//!!!
	CLASS_CFI(reset, CONFUNCF_RESTRICTED);
	CLASS_CFI(mouse, CONFUNCF_RESTRICTED);
	CLASS_CFI(set_damage, CONFUNCF_RESTRICTED);

	console_r					= *pcon_dim;
	if (*pcon_style == 0)
	{
		console_r.p[2].y		= (float)pcon_dim->top;
		console_r.p[3].y		= (float)pcon_dim->top;
	}
	if (*pcon_style == 1)
	{
		console_r.p[1].x		= (float)pcon_dim->left;
		console_r.p[2].x		= (float)pcon_dim->left;
	}

//	CLASS_CVI(char, _char, 'X', 0, 0, 0);
//	CLASS_CVIA(int, _int, 3, 13, 0, 100, 0);
//	CLASS_CVIA(bool, _bool, 3, ON, OFF, ON, 0);
//	CLASS_CVIA(float, _float, 3, 1.3f, 0, 100.0f, 0);
//	CLASS_CVIA(RGBcolor, _rgbcolor, 3, yellow, black, white, 0);
//	CLASS_CVIA(RECT, _rect, 3, tmp, tmpmin, tmpmax, 0);

	//--------------------------------------------------------------------------------------------

	print_outputbuffer("**** " APPTITLE " - v" VERSION_S " (" DATE ") - console initialized ****>");
}

//------------------------------------------------------------------------------------------------
//
//	console RegisterVarHandler
//
//------------------------------------------------------------------------------------------------

void console::RegisterVarHandler(con_func_t *varHandler)
{
	//new con_func_t points to previously created con_func_t
	varHandler->next	= con_varHandlerList;
	//con_varHandlerList points to new created con_func_t
	con_varHandlerList	= varHandler;
}

//------------------------------------------------------------------------------------------------
//
//	console RegisterFunc
//
//------------------------------------------------------------------------------------------------

void console::RegisterFunc(con_func_t *func)
{
	//new con_func_t points to previously created con_func_t
	func->next = con_funcList;
	//con_funcList points to new created con_func_t
	con_funcList = func;
}

//------------------------------------------------------------------------------------------------
//
//	console RegisterVar
//
//------------------------------------------------------------------------------------------------

void console::RegisterVar(con_var_t *var)
{
	//instance counter
	int ic = 0;

	//for all con vars
	for (con_var_t *f = con_varList; f != NULL; f = f->next)
	{
		//if con var exits with same description as con var to add
		//increase instance counter
		if (!strcmp(f->name, var->name))
			++ic;
	}

	//set instance of con var to add
	var->instance = ic;

	//new con_var_t points to previously created con_var_t
	var->next = con_varList;
	//con_varList points to new created con_var_t
	con_varList = var;
}

//------------------------------------------------------------------------------------------------
//
//	console GetHandlerForVarType
//
//------------------------------------------------------------------------------------------------

con_func_t* console::GetHandlerForVarType(char* varTypeName)
{
	//valid type name
	if (!varTypeName)
		return(NULL);

	//for all console variable handler functions
	for (con_func_t *handler = con_varHandlerList; handler != NULL; handler = handler->next)
	{
		//if function handles argumented console variable type
		if (!stricmp(handler->name, varTypeName))
			//return pointer to con_func_t object with pointer to handler
			return(handler);
	}

	return(NULL);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler int
//
//------------------------------------------------------------------------------------------------

void console::handler_int_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//array index
	int	ai				= 0;
	//adds to indices
	//because if con var is array argc increase by one (first post-name arg is array index)
	int inc				= 0;

	//con var is array
	if (argvar->elements)
	{
		//get array index (#number)
		if (argc > 1)
			//'#' symbolizes index
			if (argv[1][0] == '#')
			{
				//get index after '#'
				ai	= atoi(argv[1] + 1);
				inc	= 1;
			}

		//check boundaries
		if (ai < 0)							ai = 0;
		if (ai > argvar->elements - 1)		ai = argvar->elements - 1;
	}

	//pointer to value of con var
	int *val_	= (int *)argvar->valuePtr;
	int *val	= &val_[ai];
	int *valmin	= (int *)argvar->valueMin;
	int *valmax = (int *)argvar->valueMax;

	//if only one argument (specifier)
	if (argc < 2 + inc)
	{
		if (!argvar->elements)
		{
			//output value of variable
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("int %s == %d (min: %d, max: %d)", argvar->name, *val, *valmin, *valmax);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("int %s == %d (min: %d)", argvar->name, *val, *valmin);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("int %s == %d (max: %d)", argvar->name, *val, *valmax);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("int %s == %d", argvar->name, *val);
				return;
			}
		}
		else
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("int %s[%d] == %d (min: %d, max: %d)", argvar->name, ai, *val, *valmin, *valmax);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("int %s[%d] == %d (min: %d)", argvar->name, ai, *val, *valmin);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("int %s[%d] == %d (max: %d)", argvar->name, ai, *val, *valmax);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("int %s[%d] == %d", argvar->name, ai, *val);
				return;
			}
		}
	}

	//if third argument valid
	if (argv[2 + inc])
	{
		if (!strcmp(argv[1 + inc], "="))
			*val = atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "+="))
			*val += atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "-="))
			*val -= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "*="))
			*val *= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "/="))
			*val /= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "&="))
			*val &= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "|="))
			*val |= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "^="))
			*val ^= atoi(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "%="))
			*val %= atoi(argv[2 + inc]);
		else
//		if (!stricmp(argv[1 + inc], "on"))
//			*val = 1;
//		else
//		if (!stricmp(argv[1 + inc], "off"))
//			*val = 0;
//		else
//		if (!stricmp(argv[1 + inc], "tog"))
//		{
//			if (*val)			*val = 0;
///			else				*val = 1;
//		}
//		else
			*val = atoi(argv[1 + inc]);
	}
	else
		*val = atoi(argv[1 + inc]);

	//limits (if existing)
	if (valmin)		if (*val < *valmin)			*val = *valmin;
	if (valmax)		if (*val > *valmax)			*val = *valmax;

	//output new value
	if (!argvar->elements)
		pcon->print_outputbuffer("int %s == %d", argvar->name, *val);
	else
		pcon->print_outputbuffer("int %s[%d] == %d", argvar->name, ai, *val);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler float
//
//------------------------------------------------------------------------------------------------

void console::handler_float_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	int ai				= 0;
	int inc				= 0;

	if (argvar->elements)
	{
		if (argc > 1)
			if (argv[1][0] == '#')
			{
				ai	= atoi(argv[1] + 1);
				inc	= 1;
			}

		//check boundaries
		if (ai < 0)							ai = 0;
		if (ai > argvar->elements - 1)		ai = argvar->elements - 1;
	}

	float *val_		= (float *)argvar->valuePtr;
	float *val		= &val_[ai];
	float *valmin	= (float *)argvar->valueMin;
	float *valmax	= (float *)argvar->valueMax;

	if (argc < 2 + inc)
	{
		if (!argvar->elements)
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("float %s == %.4f (min: %.4f, max: %.4f)", argvar->name, *val, *valmin, *valmax);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("float %s == %.4f (min: %.4f)", argvar->name, *val, *valmin);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("float %s == %.4f (max: %.4f)", argvar->name, *val, *valmax);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("float %s == %.4f", argvar->name, *val);
				return;
			}
		}
		else
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("float %s[%d] == %.4f (min: %.4f, max: %.4f)", argvar->name, ai, *val, *valmin, *valmax);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("float %s[%d] == %.4f (min: %.4f)", argvar->name, ai, *val, *valmin);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("float %s[%d] == %.4f (max: %.4f)", argvar->name, ai, *val, *valmax);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("float %s[%d] == %.4f", argvar->name, ai, *val);
				return;
			}
		}
	}

	if (argv[2 + inc])
	{
		if (!strcmp(argv[1 + inc], "="))
			*val = (float)atof(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "+="))
			*val += (float)atof(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "-="))
			*val -= (float)atof(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "*="))
			*val *= (float)atof(argv[2 + inc]);
		else
		if (!strcmp(argv[1 + inc], "/="))
			*val /= (float)atof(argv[2 + inc]);
		else
			*val = (float)atof(argv[1 + inc]);
	}
	else
		*val = (float)atof(argv[1 + inc]);

	//limits (if existing)
	if (valmin)		if (*val < *valmin)			*val = *valmin;
	if (valmax)		if (*val > *valmax)			*val = *valmax;

	if (!argvar->elements)
		pcon->print_outputbuffer("float %s == %.4f", argvar->name, *val);
	else
		pcon->print_outputbuffer("float %s[%d] == %.4f", argvar->name, ai, *val);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler bool
//
//------------------------------------------------------------------------------------------------

void console::handler_bool_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	int ai				= 0;
	int inc				= 0;

	if (argvar->elements)
	{
		//get array index (#number)
		if (argc > 1)
			//'#' symbolizes index
			if (argv[1][0] == '#')
			{
				//get index after '#'
				ai	= atoi(argv[1] + 1);
				inc	= 1;
			}

		//check boundaries
		if (ai < 0)							ai = 0;
		if (ai > argvar->elements - 1)		ai = argvar->elements - 1;
	}

	//what the fuck? int?
//	int *val_	= (int *)argvar->valuePtr;
//	int *val	= &val_[ai];
	bool *val_	= (bool *)argvar->valuePtr;
	bool *val	= &val_[ai];

	if (argc < 2 + inc)
	{
		if (!argvar->elements)
		{
			if (*val)		pcon->print_outputbuffer("bool %s is ON", argvar->name);
			else			pcon->print_outputbuffer("bool %s is OFF", argvar->name);
		}
		else
		{
			if (*val)		pcon->print_outputbuffer("bool %s[%d] is ON", argvar->name, ai);
			else			pcon->print_outputbuffer("bool %s[%d] is OFF", argvar->name, ai);
		}

		return;
	}

	//3 arguments (variable = x)
	if (argv[2 + inc])
	{
		if (!strcmp(argv[1 + inc], "="))
			*val = atoi(argv[2 + inc]) != 0;
		else
//		if (!strcmp(argv[1 + inc], "^="))
//			*val ^= atoi(argv[2 + inc]) != 0;
//		else
			*val = atoi(argv[1 + inc]) != 0;
	}
	else
	//2 arguments
	{
		if (!stricmp(argv[1 + inc], "on"))
			*val = 1;
		else
		if (!stricmp(argv[1 + inc], "off"))
			*val = 0;
		else
		if (!stricmp(argv[1 + inc], "tog"))
		{
			if (*val)				*val = 0;
			else					*val = 1;
		}
		else
			*val = atoi(argv[1 + inc]) != 0;
	}

	//auto clamp var to 0 or 1
	if (*val)
		*val = 1;

	if (!argvar->elements)
		if (*val)
			pcon->print_outputbuffer("bool %s is ON", argvar->name);
		else
			pcon->print_outputbuffer("bool %s is OFF", argvar->name);
	else
		if (*val)
			pcon->print_outputbuffer("bool %s[%d] is ON", argvar->name, ai);
		else
			pcon->print_outputbuffer("bool %s[%d] is OFF", argvar->name, ai);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler char
//
//------------------------------------------------------------------------------------------------

void console::handler_char_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	char *val			= (char *)argvar->valuePtr;

	//no arguments
	if (argc < 2)
	{
		//if valid display string or char value
		if (val)
		{
			if (argvar->elements)
				pcon->print_outputbuffer("char %s[%d] is \"%s\"", argvar->name, argvar->elements, val);
			else
				pcon->print_outputbuffer("char %s is \"%c\"", argvar->name, *val);
		}
		else
			pcon->print_outputbuffer("char %s is NULL", argvar->name);

		return;
	}

	//if string and argument not too long assign argument
	if (argvar->elements)
		if (strlen(argv[1]) + 1 > (unsigned int)argvar->elements)
		{
			pcon->print_outputbuffer("string too long (%d)", (strlen(argv[1]) + 1) - (unsigned int)argvar->elements);
			return;
		}
		else
			strcpy(val, argv[1]);
	else
	//assign char
		*val = *argv[1];

	//output new value
	if (val)
	{
		if (argvar->elements)
			pcon->print_outputbuffer("char %s[%d] is \"%s\"", argvar->name, argvar->elements, val);
		else
			pcon->print_outputbuffer("char %s is \"%c\"", argvar->name, *val);
	}
	else
		pcon->print_outputbuffer("char %s is NULL", argvar->name);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler RGBcolor
//
//------------------------------------------------------------------------------------------------

void console::handler_RGBcolor_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	int ai				= 0;
	int inc				= 0;

	if (argvar->elements)
	{
		//get array index (#number)
		if (argc > 1)
			//'#' symbolizes index
			if (argv[1][0] == '#')
			{
				//get index after '#'
				ai	= atoi(argv[1] + 1);
				inc	= 1;
			}

		//check boundaries
		if (ai < 0)							ai = 0;
		if (ai > argvar->elements - 1)		ai = argvar->elements - 1;
	}

	RGBcolor *val_		= (RGBcolor *)argvar->valuePtr;
	RGBcolor *val		= &val_[ai];
	RGBcolor *valmin	= (RGBcolor *)argvar->valueMin;
	RGBcolor *valmax	= (RGBcolor *)argvar->valueMax;

	if (argc < 2 + inc)
	{
		if (!argvar->elements)
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s is %i.%i.%i (min: %i.%i.%i, max: %i.%i.%i)", argvar->name, val->r, val->g, val->b, valmin->r, valmin->g, valmin->b, valmax->r, valmax->g, valmax->b);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s is %i.%i.%i (min: %i.%i.%i)", argvar->name, val->r, val->g, val->b, valmin->r, valmin->g, valmin->b);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s is %i.%i.%i (max: %i.%i.%i)", argvar->name, val->r, val->g, val->b, valmax->r, valmax->g, valmax->b);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s is %i.%i.%i", argvar->name, val->r, val->g, val->b);
				return;
			}
		}
		else
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s[%d] is %i.%i.%i (min: %i.%i.%i, max: %i.%i.%i)", argvar->name, ai, val->r, val->g, val->b, valmin->r, valmin->g, valmin->b, valmax->r, valmax->g, valmax->b);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s[%d] is %i.%i.%i (min: %i.%i.%i)", argvar->name, ai, val->r, val->g, val->b, valmin->r, valmin->g, valmin->b);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s[%d] is %i.%i.%i (max: %i.%i.%i)", argvar->name, ai, val->r, val->g, val->b, valmax->r, valmax->g, valmax->b);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("RGBcolor %s[%d] is %i.%i.%i", argvar->name, ai, val->r, val->g, val->b);
				return;
			}
		}

		return;
	}

	//new color
	RGBcolor	nc = *val;

	//first argument after specifier is r, then g, then b
	if (argc >= 2 + inc)			if (argv[1 + inc])		nc.r	= atoi(argv[1 + inc]);
	if (argc >= 3 + inc)			if (argv[2 + inc])		nc.g	= atoi(argv[2 + inc]);
	if (argc >= 4 + inc)			if (argv[3 + inc])		nc.b	= atoi(argv[3 + inc]);

	*val = nc;

	//limits (if existing)
	if (valmin)
	{
		if (val->r < valmin->r)	val->r = valmin->r;
		if (val->g < valmin->g)	val->g = valmin->g;
		if (val->b < valmin->b)	val->b = valmin->b;
	}
	if (valmax)
	{
		if (val->r > valmax->r)	val->r = valmax->r;
		if (val->g > valmax->g)	val->g = valmax->g;
		if (val->b > valmax->b)	val->b = valmax->b;
	}

	if (!argvar->elements)
		pcon->print_outputbuffer("RGBcolor %s is %i.%i.%i", argvar->name, val->r, val->g, val->b);
	else
		pcon->print_outputbuffer("RGBcolor %s[%d] is %i.%i.%i", argvar->name, ai, val->r, val->g, val->b);
}

//------------------------------------------------------------------------------------------------
//
//	console variable handler RECT
//
//------------------------------------------------------------------------------------------------

void console::handler_RECT_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	int ai				= 0;
	int inc				= 0;

	if (argvar->elements)
	{
		//get array index (#number)
		if (argc > 1)
			//'#' symbolizes index
			if (argv[1][0] == '#')
			{
				//get index after '#'
				ai	= atoi(argv[1] + 1);
				inc	= 1;
			}

		//check boundaries
		if (ai < 0)							ai = 0;
		if (ai > argvar->elements - 1)		ai = argvar->elements - 1;
	}

	RECT *val_		= (RECT *)argvar->valuePtr;
	RECT *val		= &val_[ai];
	RECT *valmin	= (RECT *)argvar->valueMin;
	RECT *valmax	= (RECT *)argvar->valueMax;

	if (argc < 2 + inc)
	{
		if (!argvar->elements)
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("RECT %s is (LRTB) %i.%i.%i.%i (min: %i.%i.%i.%i, max: %i.%i.%i.%i)", argvar->name, val->left, val->right, val->top, val->bottom, valmin->left, valmin->right, valmin->top, valmin->bottom, valmax->left, valmax->right, valmax->top, valmax->bottom);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("RECT %s is (LRTB) %i.%i.%i.%i (min: %i.%i.%i.%i)", argvar->name, val->left, val->right, val->top, val->bottom, valmin->left, valmin->right, valmin->top, valmin->bottom);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("RECT %s is (LRTB) %i.%i.%i.%i (max: %i.%i.%i.%i)", argvar->name, val->left, val->right, val->top, val->bottom, valmax->left, valmax->right, valmax->top, valmax->bottom);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("RECT %s is (LRTB) %i.%i.%i.%i", argvar->name, val->left, val->right, val->top, val->bottom);
				return;
			}
		}
		else
		{
			if (valmin && valmax)
			{
				pcon->print_outputbuffer("RECT %s[%d] is (LRTB) %i.%i.%i.%i (min: %i.%i.%i.%i, max: %i.%i.%i.%i)", argvar->name, ai, val->left, val->right, val->top, val->bottom, valmin->left, valmin->right, valmin->top, valmin->bottom, valmax->left, valmax->right, valmax->top, valmax->bottom);
				return;
			}
			if (valmin && !valmax)
			{
				pcon->print_outputbuffer("RECT %s[%d] is (LRTB) %i.%i.%i.%i (min: %i.%i.%i.%i)", argvar->name, ai, val->left, val->right, val->top, val->bottom, valmin->left, valmin->right, valmin->top, valmin->bottom);
				return;
			}
			if (!valmin && valmax)
			{
				pcon->print_outputbuffer("RECT %s[%d] is (LRTB) %i.%i.%i.%i (max: %i.%i.%i.%i)", argvar->name, ai, val->left, val->right, val->top, val->bottom, valmax->left, valmax->right, valmax->top, valmax->bottom);
				return;
			}
			if (!valmin && !valmax)
			{
				pcon->print_outputbuffer("RECT %s[%d] is (LRTB) %i.%i.%i.%i", argvar->name, ai, val->left, val->right, val->top, val->bottom);
				return;
			}
		}
	}

	//new RECT, initialized with old one
	RECT	nr = *val;

	//first argument after specifier is left, then right, then top, then bottom
	if (argc >= 2 + inc)		if (argv[1 + inc])		nr.left		= atoi(argv[1 + inc]);
	if (argc >= 3 + inc)		if (argv[2 + inc])		nr.right	= atoi(argv[2 + inc]);
	if (argc >= 4 + inc)		if (argv[3 + inc])		nr.top		= atoi(argv[3 + inc]);
	if (argc >= 5 + inc)		if (argv[4 + inc])		nr.bottom	= atoi(argv[4 + inc]);

	*val = nr;

	//limits (if existing)
	if (valmin)
	{
		if (val->left	< valmin->left)		val->left	= valmin->left;
		if (val->right	< valmin->right)	val->right	= valmin->right;
		if (val->top	< valmin->top)		val->top	= valmin->top;
		if (val->bottom	< valmin->bottom)	val->bottom	= valmin->bottom;
	}
	if (valmax)
	{
		if (val->left	> valmax->left)		val->left	= valmax->left;
		if (val->right	> valmax->right)	val->right	= valmax->right;
		if (val->top	> valmax->top)		val->top	= valmax->top;
		if (val->bottom	> valmax->bottom)	val->bottom	= valmax->bottom;
	}

	if (!argvar->elements)
		pcon->print_outputbuffer("RECT %s is (LRTB) %i.%i.%i.%i", argvar->name, val->left, val->right, val->top, val->bottom);
	else
		pcon->print_outputbuffer("RECT %s[%d] is (LRTB) %i.%i.%i.%i", argvar->name, ai, val->left, val->right, val->top, val->bottom);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	exit
//	exits program
//
//------------------------------------------------------------------------------------------------

void console::exit_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	pcon->pmf->program_state = EXIT;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	program_state
//	changes program_state
//
//------------------------------------------------------------------------------------------------

void console::program_state_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no arguments
	if (argc < 2)
	{
		if (pcon->pmf->program_state == DEVELOPER)
			pcon->print_outputbuffer("program_state == DEVELOPER");
		if (pcon->pmf->program_state == EXIT)
			pcon->print_outputbuffer("program_state == EXIT");
		if (pcon->pmf->program_state == STARTUP)
			pcon->print_outputbuffer("program_state == STARTUP");
		if (pcon->pmf->program_state == TITLE)
			pcon->print_outputbuffer("program_state == TITLE");
		if (pcon->pmf->program_state == OPTIONS)
			pcon->print_outputbuffer("program_state == OPTIONS");
		if (pcon->pmf->program_state == CREDITS)
			pcon->print_outputbuffer("program_state == CREDITS");
		if (pcon->pmf->program_state == INGAME)
			pcon->print_outputbuffer("program_state == INGAME");
		if (pcon->pmf->program_state == PAUSE)
			pcon->print_outputbuffer("program_state == PAUSE");
		if (pcon->pmf->program_state == TEASER)
			pcon->print_outputbuffer("program_state == TEASER");

		return;
	}

	int	argvalue = atoi(argv[1]);

	if (argvalue == DEVELOPER || !stricmp(argv[1], "DEVELOPER"))
	{
		pcon->pmf->program_state	= DEVELOPER;
		return;
	}
//	if (argvalue == EXIT || !stricmp(argv[1], "EXIT"))
//	{
//		pcon->pmf->program_state	= EXIT;
//		return;
//	}
	if (argvalue == STARTUP || !stricmp(argv[1], "STARTUP"))
	{
		pcon->pmf->program_state	= STARTUP;
		return;
	}
	if (argvalue == TITLE || !stricmp(argv[1], "TITLE"))
	{
		pcon->pmf->program_state	= TITLE;
		return;
	}
	if (argvalue == OPTIONS || !stricmp(argv[1], "OPTIONS"))
	{
		pcon->pmf->program_state	= OPTIONS;
		return;
	}
	if (argvalue == CREDITS || !stricmp(argv[1], "CREDITS"))
	{
		pcon->pmf->program_state	= CREDITS;
		return;
	}
	if (argvalue == INGAME || !stricmp(argv[1], "INGAME"))
	{
		pcon->pmf->program_state	= INGAME;
		return;
	}
	if (argvalue == PAUSE || !stricmp(argv[1], "PAUSE"))
	{
		pcon->pmf->program_state	= PAUSE;
		return;
	}
	if (argvalue == TEASER || !stricmp(argv[1], "TEASER"))
	{
		pcon->pmf->program_state	= TEASER;
		return;
	}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	input
//	sets inputdevice for both players
//
//------------------------------------------------------------------------------------------------

void console::input_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//inputdevice description
	char *pdev[6]				= {NULL};
	pdev[DCD_MOUSE1]			= "Mouse 1";
	pdev[DCD_MOUSE2]			= "Mouse 2";
	pdev[DCD_CONTROLLER1_DIG]	= "Controller 1 Digital";
	pdev[DCD_CONTROLLER2_DIG]	= "Controller 2 Digital";
	pdev[DCD_CONTROLLER1_ANA]	= "Controller 1 Analog";
	pdev[DCD_CONTROLLER2_ANA]	= "Controller 2 Analog";

	//no further arguments
	if (argc < 2)
	{
		pcon->print_outputbuffer("P1 = %s", pdev[pcon->pmf->option.data.inputdevice[P1]]);
		pcon->print_outputbuffer("P2 = %s", pdev[pcon->pmf->option.data.inputdevice[P2]]);
		pcon->print_outputbuffer("");
		pcon->print_outputbuffer("Input Devices:");

		//show all devices
		for (register int d = 0; d < 6; ++d)
		{
			pcon->print_outputbuffer("(%i) %s", d, pdev[d]);
		}

		return;
	}

	int player = 0;

	//get player
	if (!strcmp(argv[1], "p1"))			player	= 0;
	else								player	= 1;

	if (argc < 3)
	{
		pcon->print_outputbuffer("input [PLAYER] [IPDEVICE]");
		return;
	}

	//don't allow assigning mice
	if (argv[3] && !strcmp(argv[2], "="))
	{
		if (atoi(argv[3]) == DCD_MOUSE1 || atoi(argv[3]) == DCD_MOUSE2)
		{
			pcon->print_outputbuffer("Use \"mouse\" command to assign player mouse.");
			return;
		}
	}
	else
		if (argv[2])
		{
			if (atoi(argv[2]) == DCD_MOUSE1 || atoi(argv[2]) == DCD_MOUSE2)
			{
				pcon->print_outputbuffer("Use \"mouse\" command to assign player mouse.");
				return;
			}
		}

	//assign argumented device
	if (argv[3] && !strcmp(argv[2], "="))
		pcon->pmf->option.data.inputdevice[player] = atoi(argv[3]);
	else
		if (argv[2])
			pcon->pmf->option.data.inputdevice[player] = atoi(argv[2]);

	//verify
	if (pcon->pmf->option.data.inputdevice[player] < 0)
		pcon->pmf->option.data.inputdevice[player] = 0;
	if (pcon->pmf->option.data.inputdevice[player] > 5)
		pcon->pmf->option.data.inputdevice[player] = 5;

	//player 1 and 2 can't share the same device
	if (pcon->pmf->option.data.inputdevice[P1] ==
		pcon->pmf->option.data.inputdevice[P2])
	{
		pcon->print_outputbuffer("users can't share same input device");
		pcon->print_outputbuffer("auto-set assigned devices");

		if (pcon->pmf->option.data.inputdevice[P1] > 0)
			pcon->pmf->option.data.inputdevice[P2] = 0;
		else
			pcon->pmf->option.data.inputdevice[P2] = 1;
	}

	//set mouse button binds
	//DCD_MOUSE1 equals m0b0, m0b1, m0b2, m0b3, mwheelup0, mwheeldown0
	//DCD_MOUSE2 equals m1b0, m1b1, m1b2, m1b3, mwheelup1, mwheeldown1
	//you can't assign a player action to a !player mouse
	if (pcon->pmf->option.data.inputdevice[P1] == DCD_MOUSE1)
	{
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 400)		pcon->pmf->option.data.CBT[cP1PUNCH] = 300;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 401)		pcon->pmf->option.data.CBT[cP1PUNCH] = 301;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 402)		pcon->pmf->option.data.CBT[cP1PUNCH] = 302;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 403)		pcon->pmf->option.data.CBT[cP1PUNCH] = 303;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 405)		pcon->pmf->option.data.CBT[cP1PUNCH] = 305;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 406)		pcon->pmf->option.data.CBT[cP1PUNCH] = 306;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 400)		pcon->pmf->option.data.CBT[cP1KICK] = 300;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 401)		pcon->pmf->option.data.CBT[cP1KICK] = 301;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 402)		pcon->pmf->option.data.CBT[cP1KICK] = 302;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 403)		pcon->pmf->option.data.CBT[cP1KICK] = 303;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 405)		pcon->pmf->option.data.CBT[cP1KICK] = 305;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 406)		pcon->pmf->option.data.CBT[cP1KICK] = 306;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 400)		pcon->pmf->option.data.CBT[cP1DEFEND] = 300;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 401)		pcon->pmf->option.data.CBT[cP1DEFEND] = 301;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 402)		pcon->pmf->option.data.CBT[cP1DEFEND] = 302;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 403)		pcon->pmf->option.data.CBT[cP1DEFEND] = 303;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 405)		pcon->pmf->option.data.CBT[cP1DEFEND] = 305;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 406)		pcon->pmf->option.data.CBT[cP1DEFEND] = 306;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 400)		pcon->pmf->option.data.CBT[cP1LEFT] = 300;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 401)		pcon->pmf->option.data.CBT[cP1LEFT] = 301;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 402)		pcon->pmf->option.data.CBT[cP1LEFT] = 302;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 403)		pcon->pmf->option.data.CBT[cP1LEFT] = 303;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 405)		pcon->pmf->option.data.CBT[cP1LEFT] = 305;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 406)		pcon->pmf->option.data.CBT[cP1LEFT] = 306;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 400)		pcon->pmf->option.data.CBT[cP1RIGHT] = 300;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 401)		pcon->pmf->option.data.CBT[cP1RIGHT] = 301;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 402)		pcon->pmf->option.data.CBT[cP1RIGHT] = 302;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 403)		pcon->pmf->option.data.CBT[cP1RIGHT] = 303;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 405)		pcon->pmf->option.data.CBT[cP1RIGHT] = 305;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 406)		pcon->pmf->option.data.CBT[cP1RIGHT] = 306;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 400)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 300;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 401)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 301;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 402)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 302;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 403)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 303;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 405)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 305;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 406)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 306;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 400)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 300;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 401)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 301;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 402)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 302;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 403)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 303;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 405)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 305;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 406)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 306;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 400)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 300;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 401)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 301;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 402)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 302;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 403)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 303;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 405)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 305;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 406)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 306;
	}
	if (pcon->pmf->option.data.inputdevice[P1] == DCD_MOUSE2)
	{
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 300)		pcon->pmf->option.data.CBT[cP1PUNCH] = 400;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 301)		pcon->pmf->option.data.CBT[cP1PUNCH] = 401;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 302)		pcon->pmf->option.data.CBT[cP1PUNCH] = 402;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 303)		pcon->pmf->option.data.CBT[cP1PUNCH] = 403;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 305)		pcon->pmf->option.data.CBT[cP1PUNCH] = 405;
		if (pcon->pmf->option.data.CBT[cP1PUNCH] == 306)		pcon->pmf->option.data.CBT[cP1PUNCH] = 406;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 300)		pcon->pmf->option.data.CBT[cP1KICK] = 400;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 301)		pcon->pmf->option.data.CBT[cP1KICK] = 401;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 302)		pcon->pmf->option.data.CBT[cP1KICK] = 402;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 303)		pcon->pmf->option.data.CBT[cP1KICK] = 403;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 305)		pcon->pmf->option.data.CBT[cP1KICK] = 405;
		if (pcon->pmf->option.data.CBT[cP1KICK] == 306)		pcon->pmf->option.data.CBT[cP1KICK] = 406;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 300)		pcon->pmf->option.data.CBT[cP1DEFEND] = 400;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 301)		pcon->pmf->option.data.CBT[cP1DEFEND] = 401;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 302)		pcon->pmf->option.data.CBT[cP1DEFEND] = 402;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 303)		pcon->pmf->option.data.CBT[cP1DEFEND] = 403;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 305)		pcon->pmf->option.data.CBT[cP1DEFEND] = 405;
		if (pcon->pmf->option.data.CBT[cP1DEFEND] == 306)		pcon->pmf->option.data.CBT[cP1DEFEND] = 406;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 300)		pcon->pmf->option.data.CBT[cP1LEFT] = 400;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 301)		pcon->pmf->option.data.CBT[cP1LEFT] = 401;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 302)		pcon->pmf->option.data.CBT[cP1LEFT] = 402;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 303)		pcon->pmf->option.data.CBT[cP1LEFT] = 403;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 305)		pcon->pmf->option.data.CBT[cP1LEFT] = 405;
		if (pcon->pmf->option.data.CBT[cP1LEFT] == 306)		pcon->pmf->option.data.CBT[cP1LEFT] = 406;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 300)		pcon->pmf->option.data.CBT[cP1RIGHT] = 400;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 301)		pcon->pmf->option.data.CBT[cP1RIGHT] = 401;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 302)		pcon->pmf->option.data.CBT[cP1RIGHT] = 402;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 303)		pcon->pmf->option.data.CBT[cP1RIGHT] = 403;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 305)		pcon->pmf->option.data.CBT[cP1RIGHT] = 405;
		if (pcon->pmf->option.data.CBT[cP1RIGHT] == 306)		pcon->pmf->option.data.CBT[cP1RIGHT] = 406;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 300)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 400;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 301)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 401;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 302)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 402;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 303)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 403;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 305)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 405;
		if (pcon->pmf->option.data.CBT[cP1SPECIAL] == 306)		pcon->pmf->option.data.CBT[cP1SPECIAL] = 406;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 300)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 400;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 301)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 401;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 302)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 402;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 303)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 403;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 305)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 405;
		if (pcon->pmf->option.data.CBT[cP1STANCEUP] == 306)		pcon->pmf->option.data.CBT[cP1STANCEUP] = 406;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 300)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 400;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 301)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 401;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 302)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 402;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 303)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 403;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 305)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 405;
		if (pcon->pmf->option.data.CBT[cP1STANCEDOWN] == 306)		pcon->pmf->option.data.CBT[cP1STANCEDOWN] = 406;
	}
	if (pcon->pmf->option.data.inputdevice[P2] == DCD_MOUSE1)
	{
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 400)		pcon->pmf->option.data.CBT[cP2PUNCH] = 300;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 401)		pcon->pmf->option.data.CBT[cP2PUNCH] = 301;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 402)		pcon->pmf->option.data.CBT[cP2PUNCH] = 302;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 403)		pcon->pmf->option.data.CBT[cP2PUNCH] = 303;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 405)		pcon->pmf->option.data.CBT[cP2PUNCH] = 305;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 406)		pcon->pmf->option.data.CBT[cP2PUNCH] = 306;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 400)		pcon->pmf->option.data.CBT[cP2KICK] = 300;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 401)		pcon->pmf->option.data.CBT[cP2KICK] = 301;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 402)		pcon->pmf->option.data.CBT[cP2KICK] = 302;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 403)		pcon->pmf->option.data.CBT[cP2KICK] = 303;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 405)		pcon->pmf->option.data.CBT[cP2KICK] = 305;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 406)		pcon->pmf->option.data.CBT[cP2KICK] = 306;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 400)		pcon->pmf->option.data.CBT[cP2DEFEND] = 300;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 401)		pcon->pmf->option.data.CBT[cP2DEFEND] = 301;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 402)		pcon->pmf->option.data.CBT[cP2DEFEND] = 302;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 403)		pcon->pmf->option.data.CBT[cP2DEFEND] = 303;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 405)		pcon->pmf->option.data.CBT[cP2DEFEND] = 305;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 406)		pcon->pmf->option.data.CBT[cP2DEFEND] = 306;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 400)		pcon->pmf->option.data.CBT[cP2LEFT] = 300;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 401)		pcon->pmf->option.data.CBT[cP2LEFT] = 301;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 402)		pcon->pmf->option.data.CBT[cP2LEFT] = 302;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 403)		pcon->pmf->option.data.CBT[cP2LEFT] = 303;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 405)		pcon->pmf->option.data.CBT[cP2LEFT] = 305;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 406)		pcon->pmf->option.data.CBT[cP2LEFT] = 306;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 400)		pcon->pmf->option.data.CBT[cP2RIGHT] = 300;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 401)		pcon->pmf->option.data.CBT[cP2RIGHT] = 301;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 402)		pcon->pmf->option.data.CBT[cP2RIGHT] = 302;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 403)		pcon->pmf->option.data.CBT[cP2RIGHT] = 303;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 405)		pcon->pmf->option.data.CBT[cP2RIGHT] = 305;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 406)		pcon->pmf->option.data.CBT[cP2RIGHT] = 306;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 400)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 300;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 401)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 301;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 402)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 302;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 403)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 303;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 405)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 305;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 406)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 306;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 400)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 300;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 401)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 301;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 402)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 302;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 403)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 303;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 405)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 305;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 406)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 306;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 400)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 300;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 401)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 301;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 402)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 302;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 403)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 303;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 405)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 305;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 406)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 306;
	}
	if (pcon->pmf->option.data.inputdevice[P2] == DCD_MOUSE2)
	{
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 300)		pcon->pmf->option.data.CBT[cP2PUNCH] = 400;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 301)		pcon->pmf->option.data.CBT[cP2PUNCH] = 401;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 302)		pcon->pmf->option.data.CBT[cP2PUNCH] = 402;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 303)		pcon->pmf->option.data.CBT[cP2PUNCH] = 403;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 305)		pcon->pmf->option.data.CBT[cP2PUNCH] = 405;
		if (pcon->pmf->option.data.CBT[cP2PUNCH] == 306)		pcon->pmf->option.data.CBT[cP2PUNCH] = 406;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 300)		pcon->pmf->option.data.CBT[cP2KICK] = 400;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 301)		pcon->pmf->option.data.CBT[cP2KICK] = 401;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 302)		pcon->pmf->option.data.CBT[cP2KICK] = 402;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 303)		pcon->pmf->option.data.CBT[cP2KICK] = 403;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 305)		pcon->pmf->option.data.CBT[cP2KICK] = 405;
		if (pcon->pmf->option.data.CBT[cP2KICK] == 306)		pcon->pmf->option.data.CBT[cP2KICK] = 406;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 300)		pcon->pmf->option.data.CBT[cP2DEFEND] = 400;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 301)		pcon->pmf->option.data.CBT[cP2DEFEND] = 401;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 302)		pcon->pmf->option.data.CBT[cP2DEFEND] = 402;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 303)		pcon->pmf->option.data.CBT[cP2DEFEND] = 403;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 305)		pcon->pmf->option.data.CBT[cP2DEFEND] = 405;
		if (pcon->pmf->option.data.CBT[cP2DEFEND] == 306)		pcon->pmf->option.data.CBT[cP2DEFEND] = 406;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 300)		pcon->pmf->option.data.CBT[cP2LEFT] = 400;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 301)		pcon->pmf->option.data.CBT[cP2LEFT] = 401;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 302)		pcon->pmf->option.data.CBT[cP2LEFT] = 402;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 303)		pcon->pmf->option.data.CBT[cP2LEFT] = 403;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 305)		pcon->pmf->option.data.CBT[cP2LEFT] = 405;
		if (pcon->pmf->option.data.CBT[cP2LEFT] == 306)		pcon->pmf->option.data.CBT[cP2LEFT] = 406;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 300)		pcon->pmf->option.data.CBT[cP2RIGHT] = 400;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 301)		pcon->pmf->option.data.CBT[cP2RIGHT] = 401;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 302)		pcon->pmf->option.data.CBT[cP2RIGHT] = 402;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 303)		pcon->pmf->option.data.CBT[cP2RIGHT] = 403;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 305)		pcon->pmf->option.data.CBT[cP2RIGHT] = 405;
		if (pcon->pmf->option.data.CBT[cP2RIGHT] == 306)		pcon->pmf->option.data.CBT[cP2RIGHT] = 406;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 300)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 400;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 301)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 401;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 302)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 402;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 303)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 403;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 305)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 405;
		if (pcon->pmf->option.data.CBT[cP2SPECIAL] == 306)		pcon->pmf->option.data.CBT[cP2SPECIAL] = 406;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 300)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 400;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 301)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 401;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 302)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 402;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 303)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 403;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 305)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 405;
		if (pcon->pmf->option.data.CBT[cP2STANCEUP] == 306)		pcon->pmf->option.data.CBT[cP2STANCEUP] = 406;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 300)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 400;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 301)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 401;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 302)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 402;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 303)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 403;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 305)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 405;
		if (pcon->pmf->option.data.CBT[cP2STANCEDOWN] == 306)		pcon->pmf->option.data.CBT[cP2STANCEDOWN] = 406;
	}

	pcon->print_outputbuffer("Input P%i == %s (%i)", player + 1, pdev[pcon->pmf->option.data.inputdevice[player]], pcon->pmf->option.data.inputdevice[player]);
	pcon->print_outputbuffer("Input P%i == %s (%i)", !player + 1, pdev[pcon->pmf->option.data.inputdevice[!player]], pcon->pmf->option.data.inputdevice[!player]);
	return;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	bind
//	binds key to function
//
//------------------------------------------------------------------------------------------------

void console::bind_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		//syntax help
		pcon->print_outputbuffer("bind [KEY] [FUNCTION]");
		pcon->print_outputbuffer("\"bind keys\" for all available keys");
		pcon->print_outputbuffer("\"bind commands\" for all available commands");
		pcon->print_outputbuffer("Current assignments (* = locked):");
		pcon->print_outputbuffer("");
		pcon->print_outputbuffer("");

		//for all commands
		for (register int c = 0; c < 256; ++c)
		{
			//if not unassigned
			if (pcon->pmf->option.data.CBT[c] != 0)
			{
				if (pcon->pmf->option.data.CBT[c] < 256)
				{
					pcon->add_outputbuffer("[", 0);
					pcon->add_outputbuffer(pcon->pmf->is.p_lutDIK_DESC[pcon->pmf->option.data.CBT[c]], 0);
					//lock status
					if (pcon->pmf->option.data.KEY_LOCK[pcon->pmf->option.data.CBT[c]])
						pcon->add_outputbuffer("* = ", 0);
					else
						pcon->add_outputbuffer(" = ", 0);
					pcon->add_outputbuffer(pcon->pmf->is.p_lutFUNC_DESC[c], 0);
					pcon->add_outputbuffer("]", 0);
				}
				else
				{
					char *pdesc		= NULL;

					if (pcon->pmf->option.data.CBT[c] == 300)	pdesc = "m0b0"; else
					if (pcon->pmf->option.data.CBT[c] == 301)	pdesc = "m0b1"; else
					if (pcon->pmf->option.data.CBT[c] == 302)	pdesc = "m0b2"; else
					if (pcon->pmf->option.data.CBT[c] == 303)	pdesc = "m0b3"; else
					if (pcon->pmf->option.data.CBT[c] == 400)	pdesc = "m1b0"; else
					if (pcon->pmf->option.data.CBT[c] == 401)	pdesc = "m1b1"; else
					if (pcon->pmf->option.data.CBT[c] == 402)	pdesc = "m1b2"; else
					if (pcon->pmf->option.data.CBT[c] == 403)	pdesc = "m1b3"; else
					if (pcon->pmf->option.data.CBT[c] == 305)	pdesc = "mwheelup0"; else
					if (pcon->pmf->option.data.CBT[c] == 306)	pdesc = "mwheeldown0"; else
					if (pcon->pmf->option.data.CBT[c] == 405)	pdesc = "mwheelup1"; else
					if (pcon->pmf->option.data.CBT[c] == 406)	pdesc = "mwheeldown1"; else
					if (pcon->pmf->option.data.CBT[c] == 500)	pdesc = "c0b0"; else
					if (pcon->pmf->option.data.CBT[c] == 501)	pdesc = "c0b1"; else
					if (pcon->pmf->option.data.CBT[c] == 502)	pdesc = "c0b2"; else
					if (pcon->pmf->option.data.CBT[c] == 503)	pdesc = "c0b3"; else
					if (pcon->pmf->option.data.CBT[c] == 504)	pdesc = "c0b4"; else
					if (pcon->pmf->option.data.CBT[c] == 505)	pdesc = "c0b5"; else
					if (pcon->pmf->option.data.CBT[c] == 506)	pdesc = "c0b6"; else
					if (pcon->pmf->option.data.CBT[c] == 507)	pdesc = "c0b7"; else
					if (pcon->pmf->option.data.CBT[c] == 508)	pdesc = "c0b8"; else
					if (pcon->pmf->option.data.CBT[c] == 509)	pdesc = "c0b9"; else
					if (pcon->pmf->option.data.CBT[c] == 510)	pdesc = "c0b10"; else
					if (pcon->pmf->option.data.CBT[c] == 511)	pdesc = "c0b11"; else
					if (pcon->pmf->option.data.CBT[c] == 512)	pdesc = "c0b12"; else
					if (pcon->pmf->option.data.CBT[c] == 513)	pdesc = "c0b13"; else
					if (pcon->pmf->option.data.CBT[c] == 514)	pdesc = "c0b14"; else
					if (pcon->pmf->option.data.CBT[c] == 515)	pdesc = "c0b15"; else
					if (pcon->pmf->option.data.CBT[c] == 516)	pdesc = "c0b16"; else
					if (pcon->pmf->option.data.CBT[c] == 517)	pdesc = "c0b17"; else
					if (pcon->pmf->option.data.CBT[c] == 518)	pdesc = "c0b18"; else
					if (pcon->pmf->option.data.CBT[c] == 519)	pdesc = "c0b19"; else
					if (pcon->pmf->option.data.CBT[c] == 520)	pdesc = "c0b20"; else
					if (pcon->pmf->option.data.CBT[c] == 600)	pdesc = "c1b0"; else
					if (pcon->pmf->option.data.CBT[c] == 601)	pdesc = "c1b1"; else
					if (pcon->pmf->option.data.CBT[c] == 602)	pdesc = "c1b2"; else
					if (pcon->pmf->option.data.CBT[c] == 603)	pdesc = "c1b3"; else
					if (pcon->pmf->option.data.CBT[c] == 604)	pdesc = "c1b4"; else
					if (pcon->pmf->option.data.CBT[c] == 605)	pdesc = "c1b5"; else
					if (pcon->pmf->option.data.CBT[c] == 606)	pdesc = "c1b6"; else
					if (pcon->pmf->option.data.CBT[c] == 607)	pdesc = "c1b7"; else
					if (pcon->pmf->option.data.CBT[c] == 608)	pdesc = "c1b8"; else
					if (pcon->pmf->option.data.CBT[c] == 609)	pdesc = "c1b9"; else
					if (pcon->pmf->option.data.CBT[c] == 610)	pdesc = "c1b10"; else
					if (pcon->pmf->option.data.CBT[c] == 611)	pdesc = "c1b11"; else
					if (pcon->pmf->option.data.CBT[c] == 612)	pdesc = "c1b12"; else
					if (pcon->pmf->option.data.CBT[c] == 613)	pdesc = "c1b13"; else
					if (pcon->pmf->option.data.CBT[c] == 614)	pdesc = "c1b14"; else
					if (pcon->pmf->option.data.CBT[c] == 615)	pdesc = "c1b15"; else
					if (pcon->pmf->option.data.CBT[c] == 616)	pdesc = "c1b16"; else
					if (pcon->pmf->option.data.CBT[c] == 617)	pdesc = "c1b17"; else
					if (pcon->pmf->option.data.CBT[c] == 618)	pdesc = "c1b18"; else
					if (pcon->pmf->option.data.CBT[c] == 619)	pdesc = "c1b19"; else
					if (pcon->pmf->option.data.CBT[c] == 620)	pdesc = "c1b20";

					pcon->add_outputbuffer("[", 0);
					pcon->add_outputbuffer(pdesc, 0);
					//lock status
					if (pcon->pmf->option.data.KEY_LOCK[pcon->pmf->option.data.CBT[c]])
						pcon->add_outputbuffer("* = ", 0);
					else
						pcon->add_outputbuffer(" = ", 0);
					pcon->add_outputbuffer(pcon->pmf->is.p_lutFUNC_DESC[c], 0);
					pcon->add_outputbuffer("]", 0);
				}

				//line break
				if (c % 3 == 2)
//					pcon->add_outputbuffer(" ");
					pcon->print_outputbuffer("");
				else
//					pcon->print_outputbuffer("		");
					pcon->add_outputbuffer("    ", 0);
			}
		}

		return;
	}

	if (argc == 2)
	{
		//list all available keys
		if (!strcmp(argv[1], "keys"))
		{
			pcon->print_outputbuffer("Available keys (* = locked):");
			pcon->print_outputbuffer("");
			pcon->print_outputbuffer("");

			//for all keys
			for (register int c = 0; c < 256; ++c)
			{
				//if not unassigned
				if (strcmp(pcon->pmf->is.p_lutDIK_DESC[c], NOTAVAILABLE))
				{
					pcon->add_outputbuffer(pcon->pmf->is.p_lutDIK_DESC[c], 0);
					//lock status
					if (pcon->pmf->option.data.KEY_LOCK[c])
						pcon->add_outputbuffer("*", 0);
					//pcon->print_outputbuffer("%s", pcon->pmf->is.p_lutDIK_DESC[c]);

					//line break
					if (c % 15 == 14)		pcon->print_outputbuffer("");
					else					pcon->add_outputbuffer(" ", 0);
				}
			}
			//special keys
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[300]) pcon->add_outputbuffer("M0B0* ", 0); else pcon->add_outputbuffer("M0B0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[301]) pcon->add_outputbuffer("M0B1* ", 0); else pcon->add_outputbuffer("M0B1 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[302]) pcon->add_outputbuffer("M0B2* ", 0); else pcon->add_outputbuffer("M0B2 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[303]) pcon->add_outputbuffer("M0B3* ", 0); else pcon->add_outputbuffer("M0B3 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[400]) pcon->add_outputbuffer("M1B0* ", 0); else pcon->add_outputbuffer("M1B0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[401]) pcon->add_outputbuffer("M1B1* ", 0); else pcon->add_outputbuffer("M1B1 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[402]) pcon->add_outputbuffer("M1B2* ", 0); else pcon->add_outputbuffer("M1B2 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[403]) pcon->add_outputbuffer("M1B3*", 0); else pcon->add_outputbuffer("M1B3", 0);
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[305]) pcon->add_outputbuffer("MWHEELUP0* ", 0); else pcon->add_outputbuffer("MWHEELUP0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[306]) pcon->add_outputbuffer("MWHEELDOWN0* ", 0); else pcon->add_outputbuffer("MWHEELDOWN0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[405]) pcon->add_outputbuffer("MWHEELUP1* ", 0); else pcon->add_outputbuffer("MWHEELUP1 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[406]) pcon->add_outputbuffer("MWHEELDOWN1*", 0); else pcon->add_outputbuffer("MWHEELDOWN1", 0);
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[500]) pcon->add_outputbuffer("C0B0* ", 0); else pcon->add_outputbuffer("C0B0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[501]) pcon->add_outputbuffer("C0B1* ", 0); else pcon->add_outputbuffer("C0B1 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[502]) pcon->add_outputbuffer("C0B2* ", 0); else pcon->add_outputbuffer("C0B2 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[503]) pcon->add_outputbuffer("C0B3* ", 0); else pcon->add_outputbuffer("C0B3 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[504]) pcon->add_outputbuffer("C0B4* ", 0); else pcon->add_outputbuffer("C0B4 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[505]) pcon->add_outputbuffer("C0B5* ", 0); else pcon->add_outputbuffer("C0B5 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[506]) pcon->add_outputbuffer("C0B6* ", 0); else pcon->add_outputbuffer("C0B6 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[507]) pcon->add_outputbuffer("C0B7* ", 0); else pcon->add_outputbuffer("C0B7 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[508]) pcon->add_outputbuffer("C0B8* ", 0); else pcon->add_outputbuffer("C0B8 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[509]) pcon->add_outputbuffer("C0B9* ", 0); else pcon->add_outputbuffer("C0B9 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[510]) pcon->add_outputbuffer("C0B10*", 0); else pcon->add_outputbuffer("C0B10", 0);
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[511]) pcon->add_outputbuffer("C0B11* ", 0); else pcon->add_outputbuffer("C0B11 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[512]) pcon->add_outputbuffer("C0B12* ", 0); else pcon->add_outputbuffer("C0B12 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[513]) pcon->add_outputbuffer("C0B13* ", 0); else pcon->add_outputbuffer("C0B13 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[514]) pcon->add_outputbuffer("C0B14* ", 0); else pcon->add_outputbuffer("C0B14 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[515]) pcon->add_outputbuffer("C0B15* ", 0); else pcon->add_outputbuffer("C0B15 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[516]) pcon->add_outputbuffer("C0B16* ", 0); else pcon->add_outputbuffer("C0B16 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[517]) pcon->add_outputbuffer("C0B17* ", 0); else pcon->add_outputbuffer("C0B17 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[518]) pcon->add_outputbuffer("C0B18* ", 0); else pcon->add_outputbuffer("C0B18 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[519]) pcon->add_outputbuffer("C0B19* ", 0); else pcon->add_outputbuffer("C0B19 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[520]) pcon->add_outputbuffer("C0B20*", 0); else pcon->add_outputbuffer("C0B20", 0);
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[600]) pcon->add_outputbuffer("C1B0* ", 0); else pcon->add_outputbuffer("C1B0 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[601]) pcon->add_outputbuffer("C1B1* ", 0); else pcon->add_outputbuffer("C1B1 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[602]) pcon->add_outputbuffer("C1B2* ", 0); else pcon->add_outputbuffer("C1B2 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[603]) pcon->add_outputbuffer("C1B3* ", 0); else pcon->add_outputbuffer("C1B3 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[604]) pcon->add_outputbuffer("C1B4* ", 0); else pcon->add_outputbuffer("C1B4 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[605]) pcon->add_outputbuffer("C1B5* ", 0); else pcon->add_outputbuffer("C1B5 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[606]) pcon->add_outputbuffer("C1B6* ", 0); else pcon->add_outputbuffer("C1B6 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[607]) pcon->add_outputbuffer("C1B7* ", 0); else pcon->add_outputbuffer("C1B7 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[608]) pcon->add_outputbuffer("C1B8* ", 0); else pcon->add_outputbuffer("C1B8 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[609]) pcon->add_outputbuffer("C1B9* ", 0); else pcon->add_outputbuffer("C1B9 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[610]) pcon->add_outputbuffer("C1B10*", 0); else pcon->add_outputbuffer("C1B10", 0);
			pcon->print_outputbuffer("");
			if (pcon->pmf->option.data.KEY_LOCK[611]) pcon->add_outputbuffer("C1B11* ", 0); else pcon->add_outputbuffer("C1B11 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[612]) pcon->add_outputbuffer("C1B12* ", 0); else pcon->add_outputbuffer("C1B12 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[613]) pcon->add_outputbuffer("C1B13* ", 0); else pcon->add_outputbuffer("C1B13 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[614]) pcon->add_outputbuffer("C1B14* ", 0); else pcon->add_outputbuffer("C1B14 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[615]) pcon->add_outputbuffer("C1B15* ", 0); else pcon->add_outputbuffer("C1B15 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[616]) pcon->add_outputbuffer("C1B16* ", 0); else pcon->add_outputbuffer("C1B16 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[617]) pcon->add_outputbuffer("C1B17* ", 0); else pcon->add_outputbuffer("C1B17 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[618]) pcon->add_outputbuffer("C1B18* ", 0); else pcon->add_outputbuffer("C1B18 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[619]) pcon->add_outputbuffer("C1B19* ", 0); else pcon->add_outputbuffer("C1B19 ", 0);
			if (pcon->pmf->option.data.KEY_LOCK[620]) pcon->add_outputbuffer("C1B20*", 0); else pcon->add_outputbuffer("C1B20", 0);
/*			pcon->print_outputbuffer("M0B0 M0B1 M0B2 M0B3");
			pcon->print_outputbuffer("M1B0 M1B1 M1B2 M1B3");
			pcon->print_outputbuffer("MWHEELUP0 MWHEELDOWN0 MWHEELUP1 MWHEELDOWN1");
			pcon->print_outputbuffer("C0B0 to C0B20 C1B0 to C1B20");*/

			return;
		}

		//list all available commands
		if (!strcmp(argv[1], "commands"))
		{
			pcon->print_outputbuffer("Available commands (* = locked):");
			pcon->print_outputbuffer("");
			pcon->print_outputbuffer("");

			//for all commands
			for (register int c = 0; c < 256; ++c)
			{
				//if not unassigned
				if (strcmp(pcon->pmf->is.p_lutFUNC_DESC[c], NOTAVAILABLE))
				{
					pcon->add_outputbuffer(pcon->pmf->is.p_lutFUNC_DESC[c], 0);
					//locked command status
					if (pcon->pmf->option.data.CBT_LOCK[c])
						pcon->add_outputbuffer("*", 0);

					//line break
					if (c % 5 == 4)			pcon->print_outputbuffer("");
					else					pcon->add_outputbuffer(" ", 0);
				}
			}

			return;
		}
	}

	//only one further argument (key), show key binding
	if (argc <= 2)
	{
		int index		= -1;

		//for all keys
		for (register int i = 0; i < 256; ++i)
		{
			//if argumented key description's DIK index found
			if (!stricmp(argv[1], pcon->pmf->is.p_lutDIK_DESC[i]))
			{
				//save index
				index	= i;
				break;
			}
		}

		//mouse buttons/wheels, controller
		if (index == -1)
		{
			if (!stricmp(argv[1], "m0b0"))				index = 300; else
			if (!stricmp(argv[1], "m0b1"))				index = 301; else
			if (!stricmp(argv[1], "m0b2"))				index = 302; else
			if (!stricmp(argv[1], "m0b3"))				index = 303; else
			if (!stricmp(argv[1], "m1b0"))				index = 400; else
			if (!stricmp(argv[1], "m1b1"))				index = 401; else
			if (!stricmp(argv[1], "m1b2"))				index = 402; else
			if (!stricmp(argv[1], "m1b3"))				index = 403; else
			if (!stricmp(argv[1], "mwheelup0"))			index = 305; else
			if (!stricmp(argv[1], "mwheeldown0"))		index = 306; else
			if (!stricmp(argv[1], "mwheelup1"))			index = 405; else
			if (!stricmp(argv[1], "mwheeldown1"))		index = 406; else
			if (!stricmp(argv[1], "c0b0"))				index = 500; else
			if (!stricmp(argv[1], "c0b1"))				index = 501; else
			if (!stricmp(argv[1], "c0b2"))				index = 502; else
			if (!stricmp(argv[1], "c0b3"))				index = 503; else
			if (!stricmp(argv[1], "c0b4"))				index = 504; else
			if (!stricmp(argv[1], "c0b5"))				index = 505; else
			if (!stricmp(argv[1], "c0b6"))				index = 506; else
			if (!stricmp(argv[1], "c0b7"))				index = 507; else
			if (!stricmp(argv[1], "c0b8"))				index = 508; else
			if (!stricmp(argv[1], "c0b9"))				index = 509; else
			if (!stricmp(argv[1], "c0b10"))				index = 510; else
			if (!stricmp(argv[1], "c0b11"))				index = 511; else
			if (!stricmp(argv[1], "c0b12"))				index = 512; else
			if (!stricmp(argv[1], "c0b13"))				index = 513; else
			if (!stricmp(argv[1], "c0b14"))				index = 514; else
			if (!stricmp(argv[1], "c0b15"))				index = 515; else
			if (!stricmp(argv[1], "c0b16"))				index = 516; else
			if (!stricmp(argv[1], "c0b17"))				index = 517; else
			if (!stricmp(argv[1], "c0b18"))				index = 518; else
			if (!stricmp(argv[1], "c0b19"))				index = 519; else
			if (!stricmp(argv[1], "c0b20"))				index = 520; else
			if (!stricmp(argv[1], "c1b0"))				index = 600; else
			if (!stricmp(argv[1], "c1b1"))				index = 601; else
			if (!stricmp(argv[1], "c1b2"))				index = 602; else
			if (!stricmp(argv[1], "c1b3"))				index = 603; else
			if (!stricmp(argv[1], "c1b4"))				index = 604; else
			if (!stricmp(argv[1], "c1b5"))				index = 605; else
			if (!stricmp(argv[1], "c1b6"))				index = 606; else
			if (!stricmp(argv[1], "c1b7"))				index = 607; else
			if (!stricmp(argv[1], "c1b8"))				index = 608; else
			if (!stricmp(argv[1], "c1b9"))				index = 609; else
			if (!stricmp(argv[1], "c1b10"))				index = 610; else
			if (!stricmp(argv[1], "c1b11"))				index = 611; else
			if (!stricmp(argv[1], "c1b12"))				index = 612; else
			if (!stricmp(argv[1], "c1b13"))				index = 613; else
			if (!stricmp(argv[1], "c1b14"))				index = 614; else
			if (!stricmp(argv[1], "c1b15"))				index = 615; else
			if (!stricmp(argv[1], "c1b16"))				index = 616; else
			if (!stricmp(argv[1], "c1b17"))				index = 617; else
			if (!stricmp(argv[1], "c1b18"))				index = 618; else
			if (!stricmp(argv[1], "c1b19"))				index = 619; else
			if (!stricmp(argv[1], "c1b20"))				index = 620;
		}

		//valid key found
		if (index != -1)
		{
			//indicates if binding found
			bool match = false;
			//search through CBT if DIK is bound to some function
			for (register int c = 0; c < 256; ++c)
			{
				if (pcon->pmf->option.data.CBT[c] == index)
				{
					//remark lock status
					if (pcon->pmf->option.data.KEY_LOCK[index])
					{
						pcon->print_outputbuffer("\"%s\"[LOCKED] = \"%s\"", argv[1], pcon->pmf->is.p_lutFUNC_DESC[c]);
						match = true;
					}
					else
					{
						//print bound function
						pcon->print_outputbuffer("\"%s\" = \"%s\"", argv[1], pcon->pmf->is.p_lutFUNC_DESC[c]);
						//return;
						match = true;
					}
				}
			}

			//key not bound to any function
			if (!match)
				pcon->print_outputbuffer("\"%s\" not bound", argv[1]);

			return;
		}

		//no such key found
		pcon->print_outputbuffer("\"%s\" no valid key", argv[1]);
		return;
	}

	//---- at least two arguments ----------------------------------------------------------------

	//control binding table index
	int cbtindex		= -1;
	//index of DIK desription table
	int dikdescindex	= -1;

	//for all keys
	for (register int i = 0; i < 256; ++i)
	{
		//find DIK scan code of argumented key string
		if (!stricmp(argv[1], pcon->pmf->is.p_lutDIK_DESC[i]))
		{
			//save DIK index
			dikdescindex	= i;
			break;
		}
	}

	//mouse buttons/wheels
	if (dikdescindex == -1)
	{
		if (!stricmp(argv[1], "m0b0"))				dikdescindex = 300; else
		if (!stricmp(argv[1], "m0b1"))				dikdescindex = 301; else
		if (!stricmp(argv[1], "m0b2"))				dikdescindex = 302; else
		if (!stricmp(argv[1], "m0b3"))				dikdescindex = 303; else
		if (!stricmp(argv[1], "m1b0"))				dikdescindex = 400; else
		if (!stricmp(argv[1], "m1b1"))				dikdescindex = 401; else
		if (!stricmp(argv[1], "m1b2"))				dikdescindex = 402; else
		if (!stricmp(argv[1], "m1b3"))				dikdescindex = 403; else
		if (!stricmp(argv[1], "mwheelup0"))			dikdescindex = 305; else
		if (!stricmp(argv[1], "mwheeldown0"))		dikdescindex = 306; else
		if (!stricmp(argv[1], "mwheelup1"))			dikdescindex = 405; else
		if (!stricmp(argv[1], "mwheeldown1"))		dikdescindex = 406; else
		if (!stricmp(argv[1], "c0b0"))				dikdescindex = 500; else
		if (!stricmp(argv[1], "c0b1"))				dikdescindex = 501; else
		if (!stricmp(argv[1], "c0b2"))				dikdescindex = 502; else
		if (!stricmp(argv[1], "c0b3"))				dikdescindex = 503; else
		if (!stricmp(argv[1], "c0b4"))				dikdescindex = 504; else
		if (!stricmp(argv[1], "c0b5"))				dikdescindex = 505; else
		if (!stricmp(argv[1], "c0b6"))				dikdescindex = 506; else
		if (!stricmp(argv[1], "c0b7"))				dikdescindex = 507; else
		if (!stricmp(argv[1], "c0b8"))				dikdescindex = 508; else
		if (!stricmp(argv[1], "c0b9"))				dikdescindex = 509; else
		if (!stricmp(argv[1], "c0b10"))				dikdescindex = 510; else
		if (!stricmp(argv[1], "c0b11"))				dikdescindex = 511; else
		if (!stricmp(argv[1], "c0b12"))				dikdescindex = 512; else
		if (!stricmp(argv[1], "c0b13"))				dikdescindex = 513; else
		if (!stricmp(argv[1], "c0b14"))				dikdescindex = 514; else
		if (!stricmp(argv[1], "c0b15"))				dikdescindex = 515; else
		if (!stricmp(argv[1], "c0b16"))				dikdescindex = 516; else
		if (!stricmp(argv[1], "c0b17"))				dikdescindex = 517; else
		if (!stricmp(argv[1], "c0b18"))				dikdescindex = 518; else
		if (!stricmp(argv[1], "c0b19"))				dikdescindex = 519; else
		if (!stricmp(argv[1], "c0b20"))				dikdescindex = 520; else
		if (!stricmp(argv[1], "c1b0"))				dikdescindex = 600; else
		if (!stricmp(argv[1], "c1b1"))				dikdescindex = 601; else
		if (!stricmp(argv[1], "c1b2"))				dikdescindex = 602; else
		if (!stricmp(argv[1], "c1b3"))				dikdescindex = 603; else
		if (!stricmp(argv[1], "c1b4"))				dikdescindex = 604; else
		if (!stricmp(argv[1], "c1b5"))				dikdescindex = 605; else
		if (!stricmp(argv[1], "c1b6"))				dikdescindex = 606; else
		if (!stricmp(argv[1], "c1b7"))				dikdescindex = 607; else
		if (!stricmp(argv[1], "c1b8"))				dikdescindex = 608; else
		if (!stricmp(argv[1], "c1b9"))				dikdescindex = 609; else
		if (!stricmp(argv[1], "c1b10"))				dikdescindex = 610; else
		if (!stricmp(argv[1], "c1b11"))				dikdescindex = 611; else
		if (!stricmp(argv[1], "c1b12"))				dikdescindex = 612; else
		if (!stricmp(argv[1], "c1b13"))				dikdescindex = 613; else
		if (!stricmp(argv[1], "c1b14"))				dikdescindex = 614; else
		if (!stricmp(argv[1], "c1b15"))				dikdescindex = 615; else
		if (!stricmp(argv[1], "c1b16"))				dikdescindex = 616; else
		if (!stricmp(argv[1], "c1b17"))				dikdescindex = 617; else
		if (!stricmp(argv[1], "c1b18"))				dikdescindex = 618; else
		if (!stricmp(argv[1], "c1b19"))				dikdescindex = 619; else
		if (!stricmp(argv[1], "c1b20"))				dikdescindex = 620;
	}

	//no valid key
	if (dikdescindex == -1)
	{
		pcon->print_outputbuffer("\"%s\" no valid key", argv[1]);
		return;
	}
	else
	//key locked
	{
		if (pcon->pmf->option.data.KEY_LOCK[dikdescindex] == 1)
		{
			pcon->print_outputbuffer("\"%s\" KEY LOCKED", argv[1]);
			return;
		}
	}

	//argumented function not "N/A" (which is the string in empty function description)
	if (strcmp(argv[2], NOTAVAILABLE))
		//for all functions
		for (register int f = 0; f < 256; ++f)
		{
			//if argumented function found
			if (!stricmp(argv[2], pcon->pmf->is.p_lutFUNC_DESC[f]))
			{
				//if function locked
				if (pcon->pmf->option.data.CBT_LOCK[f] == 1)
				{
					pcon->print_outputbuffer("\"%s\" NO ACCESS TO FUNCTION", argv[2]);
					return;
				}
				else
				{
					//save control function index
					cbtindex		= f;
					break;
				}
			}
		}

	//no such function found
	if (cbtindex == -1)
	{
		pcon->print_outputbuffer("\"%s\" no valid function", argv[2]);
		return;
	}

	//set bind
	pcon->pmf->option.data.CBT[cbtindex] = dikdescindex;
	//print key and bound function
	pcon->print_outputbuffer("\"%s\" = \"%s\"", argv[1], pcon->pmf->is.p_lutFUNC_DESC[cbtindex]);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	unbind
//	unbinds key from function
//
//------------------------------------------------------------------------------------------------

void console::unbind_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		//syntax help
		pcon->print_outputbuffer("unbind [KEY]/all");
		return;
	}

	//at least one further argument
	//all keys
	if (!stricmp(argv[1], "all"))
	{
		//for all functions
		for (register int i = 0; i < 256; ++i)
		{
			//if not locked
			if (pcon->pmf->option.data.KEY_LOCK[i] != 1)
				pcon->pmf->option.data.CBT[i]	= 0;
		}

		pcon->print_outputbuffer("all keys unbound");
		return;
	}

	//---- unbind specific key -------------------------------------------------------------------

	int index			= -1;

	//for all keys
	for (register int i = 0; i < 256; ++i)
	{
		//if argumented key description's DIK index found
		if (!stricmp(argv[1], pcon->pmf->is.p_lutDIK_DESC[i]))
		{
			//save index
			index	= i;
			break;
		}
	}

	//mouse buttons/wheels
	if (index == -1)
	{
		if (!stricmp(argv[1], "m0b0"))				index = 300; else
		if (!stricmp(argv[1], "m0b1"))				index = 301; else
		if (!stricmp(argv[1], "m0b2"))				index = 302; else
		if (!stricmp(argv[1], "m0b3"))				index = 303; else
		if (!stricmp(argv[1], "m1b0"))				index = 400; else
		if (!stricmp(argv[1], "m1b1"))				index = 401; else
		if (!stricmp(argv[1], "m1b2"))				index = 402; else
		if (!stricmp(argv[1], "m1b3"))				index = 403; else
		if (!stricmp(argv[1], "mwheelup0"))			index = 305; else
		if (!stricmp(argv[1], "mwheeldown0"))		index = 306; else
		if (!stricmp(argv[1], "mwheelup1"))			index = 405; else
		if (!stricmp(argv[1], "mwheeldown1"))		index = 406; else
		if (!stricmp(argv[1], "c0b0"))				index = 500; else
		if (!stricmp(argv[1], "c0b1"))				index = 501; else
		if (!stricmp(argv[1], "c0b2"))				index = 502; else
		if (!stricmp(argv[1], "c0b3"))				index = 503; else
		if (!stricmp(argv[1], "c0b4"))				index = 504; else
		if (!stricmp(argv[1], "c0b5"))				index = 505; else
		if (!stricmp(argv[1], "c0b6"))				index = 506; else
		if (!stricmp(argv[1], "c0b7"))				index = 507; else
		if (!stricmp(argv[1], "c0b8"))				index = 508; else
		if (!stricmp(argv[1], "c0b9"))				index = 509; else
		if (!stricmp(argv[1], "c0b10"))				index = 510; else
		if (!stricmp(argv[1], "c0b11"))				index = 511; else
		if (!stricmp(argv[1], "c0b12"))				index = 512; else
		if (!stricmp(argv[1], "c0b13"))				index = 513; else
		if (!stricmp(argv[1], "c0b14"))				index = 514; else
		if (!stricmp(argv[1], "c0b15"))				index = 515; else
		if (!stricmp(argv[1], "c0b16"))				index = 516; else
		if (!stricmp(argv[1], "c0b17"))				index = 517; else
		if (!stricmp(argv[1], "c0b18"))				index = 518; else
		if (!stricmp(argv[1], "c0b19"))				index = 519; else
		if (!stricmp(argv[1], "c0b20"))				index = 520; else
		if (!stricmp(argv[1], "c1b0"))				index = 600; else
		if (!stricmp(argv[1], "c1b1"))				index = 601; else
		if (!stricmp(argv[1], "c1b2"))				index = 602; else
		if (!stricmp(argv[1], "c1b3"))				index = 603; else
		if (!stricmp(argv[1], "c1b4"))				index = 604; else
		if (!stricmp(argv[1], "c1b5"))				index = 605; else
		if (!stricmp(argv[1], "c1b6"))				index = 606; else
		if (!stricmp(argv[1], "c1b7"))				index = 607; else
		if (!stricmp(argv[1], "c1b8"))				index = 608; else
		if (!stricmp(argv[1], "c1b9"))				index = 609; else
		if (!stricmp(argv[1], "c1b10"))				index = 610; else
		if (!stricmp(argv[1], "c1b11"))				index = 611; else
		if (!stricmp(argv[1], "c1b12"))				index = 612; else
		if (!stricmp(argv[1], "c1b13"))				index = 613; else
		if (!stricmp(argv[1], "c1b14"))				index = 614; else
		if (!stricmp(argv[1], "c1b15"))				index = 615; else
		if (!stricmp(argv[1], "c1b16"))				index = 616; else
		if (!stricmp(argv[1], "c1b17"))				index = 617; else
		if (!stricmp(argv[1], "c1b18"))				index = 618; else
		if (!stricmp(argv[1], "c1b19"))				index = 619; else
		if (!stricmp(argv[1], "c1b20"))				index = 620;
	}

	//valid key found
	if (index != -1)
	{
		//search through CBT if DIK is bound to some function
		for (register int c = 0; c < 256; ++c)
		{
			if (pcon->pmf->option.data.CBT[c] == index)
			{
				//if not locked
				//!! KEY_LOCK[c] korrekt?
				if (pcon->pmf->option.data.KEY_LOCK[index] != 1)
				{
					pcon->pmf->option.data.CBT[c]	= 0;
					pcon->print_outputbuffer("\"%s\" key unbound", argv[1]);
					return;
				}
				else
				//locked
				{
					pcon->print_outputbuffer("\"%s\" KEY LOCKED", argv[1]);
					return;
				}
//				//print bound function
//				pcon->print_outputbuffer("\"%s\" = \"%s\"", argv[1], pcon->pmf->is.p_lutFUNC_DESC[c]);
//				return;
			}
		}

		//key not bound to any function
		pcon->print_outputbuffer("\"%s\" already unbound", argv[1]);
		return;
	}

	//no such key found
	pcon->print_outputbuffer("\"%s\" no valid key", argv[1]);
	return;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	screenmode
//	fullscreen or windowed mode
//
//------------------------------------------------------------------------------------------------

//void console::screenmode_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
//{
//	return;
//}

//------------------------------------------------------------------------------------------------
//
//	console function
//	clear
//	clears console output buffer
//
//------------------------------------------------------------------------------------------------

void console::clear_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	pcon->clear_output_buffer();
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	listvars
//	lists all console variables
//
//------------------------------------------------------------------------------------------------

void console::listvars_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//for all console variables
	for (con_var_t *v = pcon->con_varList; v != NULL; v = v->next)
	{
		//works even if no argv[1] exits because
		//if argc < 2 strnicmp won't be called
		if ((argc < 2) || (!strnicmp(v->name, argv[1], strlen(argv[1]))))
			if (!v->elements)
				if (!v->instance)
					pcon->print_outputbuffer("%s (%s)", v->name, v->varTypeName);
				else
					pcon->print_outputbuffer("%s:%d (%s)", v->name, v->instance, v->varTypeName);
			else
				if (!v->instance)
					pcon->print_outputbuffer("%s[%d] (%s)", v->name, v->elements, v->varTypeName);
				else
					pcon->print_outputbuffer("%s[%d]:%d (%s)", v->name, v->elements, v->instance, v->varTypeName);
	}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	listcmds
//	lists all console functions
//
//------------------------------------------------------------------------------------------------

void console::listcmds_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//for all console functions
	for (con_func_t *f = pcon->con_funcList; f != NULL; f = f->next)
	{
		if ((argc < 2) || (!strnicmp(f->name, argv[1], strlen(argv[1]))))
			pcon->print_outputbuffer("%s", f->name);
	}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	listypes
//	lists all console variable handlers
//
//------------------------------------------------------------------------------------------------

void console::listtypes_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//for all console variable handler functions
	for (con_func_t *f = pcon->con_varHandlerList; f != NULL; f = f->next)
	{
		if ((argc < 2) || (!strnicmp(f->name, argv[1], strlen(argv[1]))))
			pcon->print_outputbuffer("%s", f->name);
	}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	help
//	lists all console functions
//
//------------------------------------------------------------------------------------------------

void console::help_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	pcon->print_outputbuffer("help: executing \"listcmds\"");
	pcon->con_execute(0, "listcmds");
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	version
//	program version, date
//
//------------------------------------------------------------------------------------------------

void console::version_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	pcon->print_outputbuffer("v" VERSION_S " (" DATE ")");
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	exec
//	executes commands from file
//
//------------------------------------------------------------------------------------------------

void console::exec_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//if only specifier
	if (argc < 2)
	{
		//help text
		pcon->print_outputbuffer("[?] EXEC filename.cfg");
		return;
	}

	//if ExecuteFile fails print error message
	if (!pcon->ExecuteFile(argv[1]))
		pcon->print_outputbuffer("exec: unable to execute %s", argv[1]);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	screenshot
//	takes screenshot
//
//------------------------------------------------------------------------------------------------

void console::screenshot_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//print screenshot id
	char buffer[256] = "";
	pcon->pmf->dd.save_bitmap(buffer);
	pcon->print_outputbuffer(buffer);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	fps_max
//	set/get fps_max
//
//------------------------------------------------------------------------------------------------

void console::fps_max_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		pcon->print_outputbuffer("fps_max == %d (min: %d, max: %d, no limit: 0)", pcon->pmf->option.data.fps_max, pcon->pmf->option.dataMIN.fps_max, pcon->pmf->option.dataMAX.fps_max);
		return;
	}

	//pointer to (current) volume
	int *val		= &pcon->pmf->option.data.fps_max;
	//new volume in percentage
	int fps			= 0;

	if (argv[2] && !strcmp(argv[1], "="))
		fps = atoi(argv[2]);
	else
	if (!stricmp(argv[1], "off"))
		fps = 0;
	else
		fps = atoi(argv[1]);
	
	//limits
	if (fps < 30 && fps != 0)
		fps = 30;
	if (fps > 1000)			fps = 1000;

	*val	= fps;

	//set fps_max
	pcon->pmf->time.set_fps_max(fps);

	//new fps_max
	pcon->print_outputbuffer("fps_max == %d", pcon->pmf->option.data.fps_max);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	sound
//	set/get sound
//
//------------------------------------------------------------------------------------------------

void console::sound_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no sound available, no change
	//if (!pcon->pds->sound_sys)
	if (!pcon->pmf->option.dataDEF.sound)
	{
		pcon->print_outputbuffer("sound is unavailable");
		return;
	}

	//no further arguments
	if (argc < 2)
	{
		if (pcon->pmf->option.data.sound)
			pcon->print_outputbuffer("sound is ON");
		else
			pcon->print_outputbuffer("sound is OFF");

		return;
	}

	//pointer to (current) value
	int *val		= &pcon->pmf->option.data.sound;

	if (argv[2] && !strcmp(argv[1], "="))
		*val = atoi(argv[2]);
	else
	if (!stricmp(argv[1], "on"))
		*val = 1;
	else
	if (!stricmp(argv[1], "off"))
		*val = 0;
	else
		*val = atoi(argv[1]);
	
	//limits
	if (*val > 1)			*val = 1;
	if (*val < 0)			*val = 0;

	//set value
	//pcon->pds->sound_set	= *val;

	//new value
	if (pcon->pmf->option.data.sound)
		pcon->print_outputbuffer("sound is ON");
	else
		pcon->print_outputbuffer("sound is OFF");
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	volume
//	set/get main volume
//	-10,000 to 0
//	0% - to 100% (standard)
//
//------------------------------------------------------------------------------------------------

void console::volume_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no sound, no volume change
	if (!pcon->pmf->option.data.sound)
	{
		pcon->print_outputbuffer("sound is off");
		return;
	}
	//if (!pcon->pds->sound_sys)
	if (!pcon->pmf->option.dataDEF.sound)
	{
		pcon->print_outputbuffer("sound is unavailable");
		return;
	}

	//no further arguments
	if (argc < 2)
	{
		pcon->print_outputbuffer("volume == %d%s (real: %d, min: 0%s, max: 100%s)", (int)(100.0f - ((float)pcon->pmf->option.data.volume / -10000.0f) * 100.0f), "%", pcon->pmf->option.data.volume, "%", "%");
		//play example sound
		pcon->pmf->playsound_s(S_ERROR);
		return;
	}

	//pointer to (current) volume
	int *val		= &pcon->pmf->option.data.volume;
	//new volume in percentage
	int volume		= 100;

	if (argv[2] && !strcmp(argv[1], "="))
		volume = atoi(argv[2]);
	else
	if (!stricmp(argv[1], "on"))
		volume = 100;
	else
	if (!stricmp(argv[1], "off"))
		volume = 0;
	else
		volume = atoi(argv[1]);
	
	//limits
	if (volume > 100)			volume = 100;
	if (volume < 0)				volume = 0;

	*val	= -10000 + volume * 100;

	//set volume
	pcon->pds->setvolume(BT_ALL, 0, *val);

	//new volume
	pcon->print_outputbuffer("volume == %d%s (real: %d)", volume, "%", *val);
	pcon->pmf->playsound_s(S_ERROR);
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	ko_mode
//	changes ko_mode
//
//------------------------------------------------------------------------------------------------

void console::ko_mode_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		//mode description
		char *pmode[15]					= {NULL};
		pmode[KOM_HEAD]					= "Head only";
		pmode[KOM_HEAD_OR_UP]			= "Head or Upper Torso";
		pmode[KOM_HEAD_AND_UP]			= "Head and Upper Torso";
		pmode[KOM_HEAD_OR_LO]			= "Head or Lower Torso";
		pmode[KOM_HEAD_AND_LO]			= "Head and Lower Torso";
		pmode[KOM_HEAD_OR_UP_OR_LO]		= "Head or Upper or Lower Torso";
		pmode[KOM_HEAD_AND_UP_AND_LO]	= "Head and Upper and Lower Torso";
		pmode[KOM_HEAD_AND_UP_OR_LO]	= "Head and Upper or Lower Torso";
		pmode[KOM_HEAD_OR_UP_AND_LO]	= "Head or Upper and Lower Torso";
		pmode[KOM_UP]					= "Upper Torso";
		pmode[KOM_LO]					= "Lower Torso";
		pmode[KOM_UP_OR_LO]				= "Upper or Lower Torso";
		pmode[KOM_UP_AND_LO]			= "Upper and Lower Torso";
		pmode[KOM_HPRIMARY]				= "First Hit (Head and Torso)";
		pmode[KOM_HGENERAL]				= "First Hit (Everything)";

		//show all ko-modes
		for (register int k = 0; k < 15; ++k)
		{
			if (pcon->pmf->option.data.ko_mode == k)
				pcon->print_outputbuffer("(%i) *** %s ***", k, pmode[k]);
			else
				pcon->print_outputbuffer("(%i) %s", k, pmode[k]);
		}

		return;
	}

	//assign argumented mode
	if (argv[2] && !strcmp(argv[1], "="))
		pcon->pmf->option.data.ko_mode = atoi(argv[2]);
	else
		pcon->pmf->option.data.ko_mode = atoi(argv[1]);

	//verify
	char *pmode = NULL;
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD)					pmode = "Head only";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_OR_UP)			pmode = "Head or Upper Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_AND_UP)			pmode = "Head and Upper Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_OR_LO)			pmode = "Head or Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_AND_LO)			pmode = "Head and Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_OR_UP_OR_LO)		pmode = "Head or Upper or Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_AND_UP_AND_LO)	pmode = "Head and Upper and Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_AND_UP_OR_LO)	pmode = "Head and Upper or Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HEAD_OR_UP_AND_LO)	pmode = "Head or Upper and Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_UP)					pmode = "Upper Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_LO)					pmode = "Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_UP_OR_LO)				pmode = "Upper or Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_UP_AND_LO)			pmode = "Upper and Lower Torso";
	if (pcon->pmf->option.data.ko_mode == KOM_HPRIMARY)				pmode = "First Hit (Head and Torso)";
	if (pcon->pmf->option.data.ko_mode == KOM_HGENERAL)				pmode = "First Hit (Everything)";

	//no valid mode, set default
	if (pmode == NULL)
	{
		pcon->pmf->option.data.ko_mode	= KOM_HEAD;
		pmode							= "Head only";
	}

	pcon->print_outputbuffer("ko_mode == %s (%i)", pmode, pcon->pmf->option.data.ko_mode);
	return;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	fight_mode
//	sets fight_mode
//
//------------------------------------------------------------------------------------------------

void console::fight_mode_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		//mode description
		char *pmode[3]					= {NULL};
		pmode[FM_DEF]					= "Default";
		pmode[FM_BOX]					= "Boxing only";
		pmode[FM_KICK]					= "Kicking only";

		//show all fighting-modes
		for (register int m = 0; m < 3; ++m)
		{
			if (pcon->pmf->option.data.fight_mode == m)
				pcon->print_outputbuffer("(%i) *** %s ***", m, pmode[m]);
			else
				pcon->print_outputbuffer("(%i) %s", m, pmode[m]);
		}

		return;
	}

	//assign argumented mode
	if (argv[2] && !strcmp(argv[1], "="))
		pcon->pmf->option.data.fight_mode = atoi(argv[2]);
	else
		pcon->pmf->option.data.fight_mode = atoi(argv[1]);

	//verify
	char *pmode = NULL;
	if (pcon->pmf->option.data.fight_mode == FM_DEF)			pmode = "Default";
	if (pcon->pmf->option.data.fight_mode == FM_BOX)			pmode = "Boxing only";
	if (pcon->pmf->option.data.fight_mode == FM_KICK)			pmode = "Kicking only";

	//no valid mode, set default
	if (pmode == NULL)
	{
		pcon->pmf->option.data.fight_mode	= FM_DEF;
		pmode								= "Default";
	}

	pcon->print_outputbuffer("fight_mode == %s (%i)", pmode, pcon->pmf->option.data.fight_mode);
	return;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	def_mode
//	sets defense mode
//
//------------------------------------------------------------------------------------------------

void console::def_mode_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	/*pcon->print_outputbuffer("%i arguments", argc);
	for (register int i = 0; i < argc; ++i)
		pcon->print_outputbuffer("(%i) %s", i, argv[i]);
	return;*/

	//no further arguments
	if (argc < 2)
	{
		//mode description
		char *pmode[4]					= {NULL};
		pmode[DM_mTmE]					= "Manual Tapping and Manual Evading";
		pmode[DM_aTmE]					= "Auto Tapping and Manual Evading";
		pmode[DM_mTaE]					= "Manual Tapping and Auto Evading";
		pmode[DM_aTaE]					= "Auto Tapping and Auto Evading";

		//show syntax
		pcon->print_outputbuffer("def_mode PLAYER MODE");
		pcon->print_outputbuffer(" ");

		//show all def_modes
		for (register int d = 0; d < 4; ++d)
		{
			pcon->print_outputbuffer("(%i) %s", d, pmode[d]);
		}

		//show players def_mode
		pcon->print_outputbuffer(" ");
		pcon->print_outputbuffer("PLAYER 1: (%i) %s", pcon->pmf->option.data.defense_mode[P1], pmode[pcon->pmf->option.data.defense_mode[P1]]);
		pcon->print_outputbuffer("PLAYER 2: (%i) %s", pcon->pmf->option.data.defense_mode[P2], pmode[pcon->pmf->option.data.defense_mode[P2]]);

		return;
	}

	//at least one argument
	//get argumented player
	int PL		= 0;

	if (!stricmp(argv[1], "P1") ||
		!strcmp(argv[1], "1"))
	{
		PL			= P1;
	}
	else
		if (!stricmp(argv[1], "P2") ||
			!strcmp(argv[1], "2"))
		{
			PL		= P2;
		}
		else
			if (!stricmp(argv[1], "ALL"))
			{
				PL		= -1;
			}
			else
			{
				pcon->print_outputbuffer("invalid player argument (P1/1 P2/2 ALL)");
				return;
			}

	//too many arguments
	if (argc > 3)
	{
		pcon->print_outputbuffer("too many arguments");
		return;
	}

	//if third argument
	if (argv[2])
	{
		//assign argumented defense mode
		if (PL != -1)
			pcon->pmf->option.data.defense_mode[PL] = atoi(argv[2]);
		else
		{
			pcon->pmf->option.data.defense_mode[P1] = atoi(argv[2]);
			pcon->pmf->option.data.defense_mode[P2] = atoi(argv[2]);
		}
	}

	//verify
	char *pmode	= NULL;
	if (PL != -1)
	{
		if (pcon->pmf->option.data.defense_mode[PL]	== DM_mTmE)		pmode = "Manual Tapping and Manual Evading";
		if (pcon->pmf->option.data.defense_mode[PL]	== DM_aTmE)		pmode = "Auto Tapping and Manual Evading";
		if (pcon->pmf->option.data.defense_mode[PL]	== DM_mTaE)		pmode = "Manual Tapping and Auto Evading";
		if (pcon->pmf->option.data.defense_mode[PL]	== DM_aTaE)		pmode = "Auto Tapping and Auto Evading";
	}
	else
	{
		//both set to same type
		if (pcon->pmf->option.data.defense_mode[P1]	== DM_mTmE)		pmode = "Manual Tapping and Manual Evading";
		if (pcon->pmf->option.data.defense_mode[P1]	== DM_aTmE)		pmode = "Auto Tapping and Manual Evading";
		if (pcon->pmf->option.data.defense_mode[P1]	== DM_mTaE)		pmode = "Manual Tapping and Auto Evading";
		if (pcon->pmf->option.data.defense_mode[P1]	== DM_aTaE)		pmode = "Auto Tapping and Auto Evading";
	}

	//no valid mode, set default
	if (pmode == NULL)
	{
		if (PL != -1)
		{
			pcon->pmf->option.data.defense_mode[PL]	= DM_aTaE;
			pmode									= "Auto Tapping and Auto Evading";
		}
		else
		{
			pcon->pmf->option.data.defense_mode[P1]	= DM_aTaE;
			pcon->pmf->option.data.defense_mode[P2]	= DM_aTaE;
			pmode									= "Auto Tapping and Auto Evading";
		}
	}

	if (PL != -1)
	{
		pcon->print_outputbuffer("def_mode PLAYER(%i) == (%i) %s",
								 pcon->pmf->P[PL].id + 1,
								 pcon->pmf->option.data.defense_mode[PL],
								 pmode);
	}
	else
	{
		pcon->print_outputbuffer("PLAYER 1: (%i) %s", pcon->pmf->option.data.defense_mode[P1], pmode);
		pcon->print_outputbuffer("PLAYER 2: (%i) %s", pcon->pmf->option.data.defense_mode[P2], pmode);
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	handicap
//	sets damage and fatigue handicaps
//
//------------------------------------------------------------------------------------------------

void console::handicap_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//no further arguments
	if (argc < 2)
	{
		pcon->print_outputbuffer("PLAYER DAM/FAT VALUES");
		pcon->print_outputbuffer("");

		pcon->print_outputbuffer("PLAYER 1 DAMAGE HANDICAP:");
		pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
								 pcon->pmf->option.data.dam_handicap_p1[DS_tll],
								 pcon->pmf->option.data.dam_handicap_p1[DS_tlr],
								 pcon->pmf->option.data.dam_handicap_p1[DS_tul],
								 pcon->pmf->option.data.dam_handicap_p1[DS_tur],
								 pcon->pmf->option.data.dam_handicap_p1[DS_hn],
								 pcon->pmf->option.data.dam_handicap_p1[DS_al],
								 pcon->pmf->option.data.dam_handicap_p1[DS_ar],
								 pcon->pmf->option.data.dam_handicap_p1[DS_hll],
								 pcon->pmf->option.data.dam_handicap_p1[DS_fll],
								 pcon->pmf->option.data.dam_handicap_p1[DS_hlr],
								 pcon->pmf->option.data.dam_handicap_p1[DS_flr]);
		pcon->print_outputbuffer("PLAYER 1 FATIGUE HANDICAP: %.1f",
								 pcon->pmf->option.data.fat_handicap[P1]);

		pcon->print_outputbuffer("");

		pcon->print_outputbuffer("PLAYER 2 DAMAGE HANDICAP:");
		pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
								 pcon->pmf->option.data.dam_handicap_p2[DS_tll],
								 pcon->pmf->option.data.dam_handicap_p2[DS_tlr],
								 pcon->pmf->option.data.dam_handicap_p2[DS_tul],
								 pcon->pmf->option.data.dam_handicap_p2[DS_tur],
								 pcon->pmf->option.data.dam_handicap_p2[DS_hn],
								 pcon->pmf->option.data.dam_handicap_p2[DS_al],
								 pcon->pmf->option.data.dam_handicap_p2[DS_ar],
								 pcon->pmf->option.data.dam_handicap_p2[DS_hll],
								 pcon->pmf->option.data.dam_handicap_p2[DS_fll],
								 pcon->pmf->option.data.dam_handicap_p2[DS_hlr],
								 pcon->pmf->option.data.dam_handicap_p2[DS_flr]);
		pcon->print_outputbuffer("PLAYER 2 FATIGUE HANDICAP: %.1f",
								 pcon->pmf->option.data.fat_handicap[P2]);

		return;
	}

	//at least one additional argument
	//get argumented player
	int PL		= 0;

	if (!stricmp(argv[1], "P1") ||
		!strcmp(argv[1], "1"))
	{
		PL			= P1;
	}
	else
		if (!stricmp(argv[1], "P2") ||
			!strcmp(argv[1], "2"))
		{
			PL		= P2;
		}
		else
			if (!stricmp(argv[1], "ALL"))
			{
				PL		= -1;
			}
			else
			{
				pcon->print_outputbuffer("invalid player argument (P1/1 P2/2 ALL)");
				return;
			}

	//only one additional argument
	if (argc < 3)
	{
		if (PL == P1 || PL == -1)
		{
			pcon->print_outputbuffer("PLAYER 1 DAMAGE HANDICAP:");
			pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
									 pcon->pmf->option.data.dam_handicap_p1[DS_tll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tlr],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tul],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tur],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hn],
									 pcon->pmf->option.data.dam_handicap_p1[DS_al],
									 pcon->pmf->option.data.dam_handicap_p1[DS_ar],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_fll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hlr],
									 pcon->pmf->option.data.dam_handicap_p1[DS_flr]);
			pcon->print_outputbuffer("PLAYER 1 FATIGUE HANDICAP: %.1f",
									 pcon->pmf->option.data.fat_handicap[P1]);

			if (PL == -1)			pcon->print_outputbuffer("");
		}
		if (PL == P2 || PL == -1)
		{
			pcon->print_outputbuffer("PLAYER 2 DAMAGE HANDICAP:");
			pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
									 pcon->pmf->option.data.dam_handicap_p2[DS_tll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tlr],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tul],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tur],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hn],
									 pcon->pmf->option.data.dam_handicap_p2[DS_al],
									 pcon->pmf->option.data.dam_handicap_p2[DS_ar],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_fll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hlr],
									 pcon->pmf->option.data.dam_handicap_p2[DS_flr]);
			pcon->print_outputbuffer("PLAYER 2 FATIGUE HANDICAP: %.1f",
									 pcon->pmf->option.data.fat_handicap[P2]);
		}

		return;
	}

	//get argumented handicap type
	//(0 = damage, 1 = fatigue)
	int HT		= -1;

	if (!stricmp(argv[2], "DAM"))
		HT		= 0;
	else
		if (!stricmp(argv[2], "FAT"))
			HT		= 1;
		else
		{
			pcon->print_outputbuffer("invalid handicap type argument (FAT/DAM)");
			return;
		}

	//only two additional arguments
	if (argc < 4)
	{
		if (PL == P1 || PL == -1)
		{
			//show damage handicap
			if (HT == 0)
			{
				pcon->print_outputbuffer("PLAYER 1 DAMAGE HANDICAP:");
				pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
										 pcon->pmf->option.data.dam_handicap_p1[DS_tll],
										 pcon->pmf->option.data.dam_handicap_p1[DS_tlr],
										 pcon->pmf->option.data.dam_handicap_p1[DS_tul],
										 pcon->pmf->option.data.dam_handicap_p1[DS_tur],
										 pcon->pmf->option.data.dam_handicap_p1[DS_hn],
										 pcon->pmf->option.data.dam_handicap_p1[DS_al],
										 pcon->pmf->option.data.dam_handicap_p1[DS_ar],
										 pcon->pmf->option.data.dam_handicap_p1[DS_hll],
										 pcon->pmf->option.data.dam_handicap_p1[DS_fll],
										 pcon->pmf->option.data.dam_handicap_p1[DS_hlr],
										 pcon->pmf->option.data.dam_handicap_p1[DS_flr]);

				if (PL == -1)			pcon->print_outputbuffer("");
			}
			else
			//show fatigue handicap
				pcon->print_outputbuffer("PLAYER 1 FATIGUE HANDICAP: %.1f",
										 pcon->pmf->option.data.fat_handicap[P1]);
		}
		if (PL == P2 || PL == -1)
		{
			//show damage handicap
			if (HT == 0)
			{
				pcon->print_outputbuffer("PLAYER 2 DAMAGE HANDICAP:");
				pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
										 pcon->pmf->option.data.dam_handicap_p2[DS_tll],
										 pcon->pmf->option.data.dam_handicap_p2[DS_tlr],
										 pcon->pmf->option.data.dam_handicap_p2[DS_tul],
										 pcon->pmf->option.data.dam_handicap_p2[DS_tur],
										 pcon->pmf->option.data.dam_handicap_p2[DS_hn],
										 pcon->pmf->option.data.dam_handicap_p2[DS_al],
										 pcon->pmf->option.data.dam_handicap_p2[DS_ar],
										 pcon->pmf->option.data.dam_handicap_p2[DS_hll],
										 pcon->pmf->option.data.dam_handicap_p2[DS_fll],
										 pcon->pmf->option.data.dam_handicap_p2[DS_hlr],
										 pcon->pmf->option.data.dam_handicap_p2[DS_flr]);
			}
			else
				pcon->print_outputbuffer("PLAYER 2 FATIGUE HANDICAP: %.1f",
										 pcon->pmf->option.data.fat_handicap[P2]);
		}

		return;
	}

	//too many arguments
	if (argc > 14)
	{
		pcon->print_outputbuffer("too many arguments (%i)", argc - 14);
		return;
	}

	//at least one value argument
	//fatigue handicap
	if (HT == 1)
	{
		//player 1 or both players
		if (PL == P1 || PL == -1)
		{
			pcon->pmf->option.data.fat_handicap[P1]		= (float)atof(argv[3]);

			//verify
			if (pcon->pmf->option.data.fat_handicap[P1] < pcon->pmf->option.dataMIN.fat_handicap[P1])
				pcon->pmf->option.data.fat_handicap[P1] = pcon->pmf->option.dataMIN.fat_handicap[P1];
			if (pcon->pmf->option.data.fat_handicap[P1] > pcon->pmf->option.dataMAX.fat_handicap[P1])
				pcon->pmf->option.data.fat_handicap[P1] = pcon->pmf->option.dataMAX.fat_handicap[P1];

			//show fatigue handicap
			pcon->print_outputbuffer("PLAYER 1 FATIGUE HANDICAP: %.1f",
									 pcon->pmf->option.data.fat_handicap[P1]);

//			pcon->print_outputbuffer("");
		}
		if (PL == P2 || PL == -1)
		{
			pcon->pmf->option.data.fat_handicap[P2]		= (float)atof(argv[3]);

			if (pcon->pmf->option.data.fat_handicap[P2] < pcon->pmf->option.dataMIN.fat_handicap[P2])
				pcon->pmf->option.data.fat_handicap[P2] = pcon->pmf->option.dataMIN.fat_handicap[P2];
			if (pcon->pmf->option.data.fat_handicap[P2] > pcon->pmf->option.dataMAX.fat_handicap[P2])
				pcon->pmf->option.data.fat_handicap[P2] = pcon->pmf->option.dataMAX.fat_handicap[P2];

			pcon->print_outputbuffer("PLAYER 2 FATIGUE HANDICAP: %.1f",
									 pcon->pmf->option.data.fat_handicap[P2]);
		}
	}
	else
	//damage handicap
	{
		if (PL == P1 || PL == -1)
		{
			//for all value arguments up to all damage slots
			for (register int i = 3; i < argc && i < NODS + 3; ++i)
			{
				//assign handicap
				pcon->pmf->option.data.dam_handicap_p1[i - 3]	= atoi(argv[i]);
			}

			//verify
			for (i = 0; i < NODS; ++i)
			{
				if (pcon->pmf->option.data.dam_handicap_p1[i] < pcon->pmf->option.dataMIN.dam_handicap_p1[i])
					pcon->pmf->option.data.dam_handicap_p1[i] = pcon->pmf->option.dataMIN.dam_handicap_p1[i];
				if (pcon->pmf->option.data.dam_handicap_p1[i] > pcon->pmf->option.dataMAX.dam_handicap_p1[i])
					pcon->pmf->option.data.dam_handicap_p1[i] = pcon->pmf->option.dataMAX.dam_handicap_p1[i];
			}

			//show damage handicap
			pcon->print_outputbuffer("PLAYER 1 DAMAGE HANDICAP:");
			pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
									 pcon->pmf->option.data.dam_handicap_p1[DS_tll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tlr],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tul],
									 pcon->pmf->option.data.dam_handicap_p1[DS_tur],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hn],
									 pcon->pmf->option.data.dam_handicap_p1[DS_al],
									 pcon->pmf->option.data.dam_handicap_p1[DS_ar],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_fll],
									 pcon->pmf->option.data.dam_handicap_p1[DS_hlr],
									 pcon->pmf->option.data.dam_handicap_p1[DS_flr]);

			if (PL == -1)			pcon->print_outputbuffer("");
		}

		if (PL == P2 || PL == -1)
		{
			for (register int i = 3; i < argc && i < NODS + 3; ++i)
			{
				pcon->pmf->option.data.dam_handicap_p2[i - 3]	= atoi(argv[i]);
			}

			for (i = 0; i < NODS; ++i)
			{
				if (pcon->pmf->option.data.dam_handicap_p2[i] < pcon->pmf->option.dataMIN.dam_handicap_p2[i])
					pcon->pmf->option.data.dam_handicap_p2[i] = pcon->pmf->option.dataMIN.dam_handicap_p2[i];
				if (pcon->pmf->option.data.dam_handicap_p2[i] > pcon->pmf->option.dataMAX.dam_handicap_p2[i])
					pcon->pmf->option.data.dam_handicap_p2[i] = pcon->pmf->option.dataMAX.dam_handicap_p2[i];
			}

			pcon->print_outputbuffer("PLAYER 2 DAMAGE HANDICAP:");
			pcon->print_outputbuffer("TLL %i TLR %i TUL %i TUR %i HN %i AL %i AR %i HLL %i FLL %i HLR %i FLR %i",
									 pcon->pmf->option.data.dam_handicap_p2[DS_tll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tlr],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tul],
									 pcon->pmf->option.data.dam_handicap_p2[DS_tur],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hn],
									 pcon->pmf->option.data.dam_handicap_p2[DS_al],
									 pcon->pmf->option.data.dam_handicap_p2[DS_ar],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_fll],
									 pcon->pmf->option.data.dam_handicap_p2[DS_hlr],
									 pcon->pmf->option.data.dam_handicap_p2[DS_flr]);
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	playdemo
//	replays demo
//
//------------------------------------------------------------------------------------------------

void console::playdemo_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//without argument
	if (argc < 2)
	{
		pcon->print_outputbuffer("playdemo name.bmd");
		return;
	}

	//wenn beim zweiten argument .bmd dranhaengt, rufe sdemo_startplay mit 2tem parameter auf
	//wenn nicht, haenge .bmd dran und rufe auf
	//verzeichnis entweder beatmaster root und demo
	//(gehe namen durch, kopiere bis zum ersten . oder ende, rufe damit sdemo_startplay auf
	//fehlercode: already playing, already recording, file not found
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	reset
//	resets players
//
//------------------------------------------------------------------------------------------------

void console::reset_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//without argument, reset both players
	if (argc < 2)
	{
		int pos		= 0 + (rand() % (1 - 0 + 1));
		pcon->pmf->P[P1].reset(pos);
		pcon->pmf->P[P2].reset(pos);
		pcon->print_outputbuffer("reset both players");
		return;
	}

	//!! bullshite einzelne spieler zu resetten?
	int pos		= 0 + (rand() % (1 - 0 + 1));

	if (!stricmp(argv[1], "P1") ||
		!strcmp(argv[1], "1"))
	{
		pcon->pmf->P[P1].reset(pos);
		pcon->print_outputbuffer("reset player 1");
		return;
	}
	else
		if (!stricmp(argv[1], "P2") ||
			!strcmp(argv[1], "2"))
		{
			pcon->pmf->P[P2].reset(pos);
			pcon->print_outputbuffer("reset player 2");
			return;
		}
		else
		{
			//help
			pcon->print_outputbuffer("reset Player (1, P1, 2, P2)");
			return;
		}
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	mouse
//	sets/gets mouse/player binding state
//
//------------------------------------------------------------------------------------------------

void console::mouse_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//mouse switch
	if (argc == 2)
	{
		if (!strcmp(argv[1], "switch"))
		{
			int p1_old								= pcon->pmf->option.data.player_mouse[P1];
			pcon->pmf->option.data.player_mouse[P1]	= pcon->pmf->option.data.player_mouse[P2];
			pcon->pmf->option.data.player_mouse[P2]	= p1_old;

			pcon->print_outputbuffer("Switched Mouse Binding:");
			pcon->print_outputbuffer("P1 = Mouse %i", (int)pcon->pmf->option.data.player_mouse[P1]);
			pcon->print_outputbuffer("P2 = Mouse %i", (int)pcon->pmf->option.data.player_mouse[P2]);

			return;
		}
	}

	//without argument
	if (argc < 3)
	{
		//usage
		pcon->print_outputbuffer("mouse [PLAYER] [MOUSE]");
		//switches
		pcon->print_outputbuffer("\"mouse switch\" to switch bound mice between P1 and P2");
		pcon->print_outputbuffer("\"mouse [PLAYER] stance\" to reverse STANCE buttons");
		pcon->print_outputbuffer("");

		//available mice
		if (pcon->pmf->di.RI.RIMn > 1)
			pcon->print_outputbuffer("Available mice: %i [Index 0-%i]", (int)pcon->pmf->di.RI.RIMn, (int)pcon->pmf->di.RI.RIMn - 1);
		if (pcon->pmf->di.RI.RIMn == 1)
			pcon->print_outputbuffer("Available mouse: %i [Index 0]", (int)pcon->pmf->di.RI.RIMn);
		if (pcon->pmf->di.RI.RIMn < 1)
			pcon->print_outputbuffer("Available mouse: None");

		//player binding
		pcon->print_outputbuffer("P1 = Mouse %i", (int)pcon->pmf->option.data.player_mouse[P1]);
		pcon->print_outputbuffer("P2 = Mouse %i", (int)pcon->pmf->option.data.player_mouse[P2]);

		return;
	}

	//selected player
	int player = 0;
	//get player
	if (!strcmp(argv[1], "p1"))			player	= 0;
	else								player	= 1;

	//stance button switch
	if (!strcmp(argv[2], "stance"))
	{
		if (player == P1)
		{
			int up_old									= pcon->pmf->option.data.CBT[cP1STANCEUP];
			pcon->pmf->option.data.CBT[cP1STANCEUP]		= pcon->pmf->option.data.CBT[cP1STANCEDOWN];
			pcon->pmf->option.data.CBT[cP1STANCEDOWN]	= up_old;
		}
		else
		{
			int up_old									= pcon->pmf->option.data.CBT[cP2STANCEUP];
			pcon->pmf->option.data.CBT[cP2STANCEUP]		= pcon->pmf->option.data.CBT[cP2STANCEDOWN];
			pcon->pmf->option.data.CBT[cP2STANCEDOWN]	= up_old;
		}

		pcon->print_outputbuffer("Reversed stance buttons for Player %i", player + 1);

		return;
	}

	//assign argumented device, if used '=' without further value value will be 0
	if (argv[3] && !strcmp(argv[2], "="))
		pcon->pmf->option.data.player_mouse[player] = atoi(argv[3]);
	else
		if (argv[2])
			pcon->pmf->option.data.player_mouse[player] = atoi(argv[2]);

	//verify
	//only if at least two mice
	if (pcon->pmf->di.RI.RIMn > 1)
	{
		if (pcon->pmf->option.data.player_mouse[player] < 0)
			pcon->pmf->option.data.player_mouse[player] = 0;
		if (pcon->pmf->option.data.player_mouse[player] > (int)pcon->pmf->di.RI.RIMn - 1)
			pcon->pmf->option.data.player_mouse[player] = (int)pcon->pmf->di.RI.RIMn - 1;
		//!! users can share same device
		if (pcon->pmf->option.data.player_mouse[player] == pcon->pmf->option.data.player_mouse[!player])
		{
			pcon->print_outputbuffer("USERS SHARE SAME MOUSE: %i", (int)pcon->pmf->option.data.player_mouse[player]);

/*			pcon->print_outputbuffer("Users can't share same mouse");

			if (pcon->pmf->option.data.player_mouse[player] > 0)
				pcon->pmf->option.data.player_mouse[!player] = 0;
			else
				pcon->pmf->option.data.player_mouse[!player] = 1;*/
		}
	}

	pcon->print_outputbuffer("P%i == Mouse (%i)", player + 1, pcon->pmf->option.data.player_mouse[player]);
	pcon->print_outputbuffer("P%i == Mouse (%i)", !player + 1, pcon->pmf->option.data.player_mouse[!player]);

/*
	//old di code

	//without argument
	if (argc < 2)
	{
		pcon->print_outputbuffer("mouse state: %d", (int)pcon->pmf->is.mouse_2usb);
		return;
	}

	//pointer to (current) value
	BYTE *val		= &pcon->pmf->is.mouse_2usb;

	if (argv[2] && !strcmp(argv[1], "="))
		*val = (BYTE)atoi(argv[2]);
	else
	if (!stricmp(argv[1], "on"))
		*val = 1;
	else
	if (!stricmp(argv[1], "off"))
		*val = 0;
	else
		*val = (BYTE)atoi(argv[1]);
	
	//limits
	if (*val > 1)			*val = 1;
	if (*val < 0)			*val = 0;

	//new value
	pcon->print_outputbuffer("mouse state: %d", (int)pcon->pmf->is.mouse_2usb);
*/
}

//------------------------------------------------------------------------------------------------
//
//	console function
//	set_damage
//	sets damage of damage slot
//
//------------------------------------------------------------------------------------------------

void console::set_damage_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv)
{
	//without argument, show syntax
	if (argc < 2)
	{
		pcon->print_outputbuffer("set_damage PLAYER DAMAGE_SLOT DAMAGE");
		return;
	}

	//pointer to argumented player
	player	*PL		= NULL;

	if (!stricmp(argv[1], "P1") ||
		!strcmp(argv[1], "1"))
	{
		PL			= &pcon->pmf->P[P1];
	}
	else
		if (!stricmp(argv[1], "P2") ||
			!strcmp(argv[1], "2"))
		{
			PL		= &pcon->pmf->P[P2];
		}
		else
		{
			pcon->print_outputbuffer("invalid player argument");
			return;
		}

	//pointer to argumented damage slot
	int *DS			= NULL;
	//set true if damage to apply to all slots
	bool all_slots	= false;

	if (argc > 2)
	{
		if (!stricmp(argv[2], "all"))
			all_slots	= true;
		else
		if (!stricmp(argv[2], "tll"))
			DS		= &PL->sk.damage[DS_tll];
		else
		if (!stricmp(argv[2], "tlr"))
			DS		= &PL->sk.damage[DS_tlr];
		else
		if (!stricmp(argv[2], "tul"))
			DS		= &PL->sk.damage[DS_tul];
		else
		if (!stricmp(argv[2], "tur"))
			DS		= &PL->sk.damage[DS_tur];
		else
		if (!stricmp(argv[2], "hn"))
			DS		= &PL->sk.damage[DS_hn];
		else
		if (!stricmp(argv[2], "al"))
			DS		= &PL->sk.damage[DS_al];
		else
		if (!stricmp(argv[2], "ar"))
			DS		= &PL->sk.damage[DS_ar];
		else
		if (!stricmp(argv[2], "hll"))
			DS		= &PL->sk.damage[DS_hll];
		else
		if (!stricmp(argv[2], "fll"))
			DS		= &PL->sk.damage[DS_fll];
		else
		if (!stricmp(argv[2], "hlr"))
			DS		= &PL->sk.damage[DS_hlr];
		else
		if (!stricmp(argv[2], "flr"))
			DS		= &PL->sk.damage[DS_flr];
		else
		{
			pcon->print_outputbuffer("invalid damage slot argument");
			return;
		}
	}
	else
	{
		pcon->print_outputbuffer("no damage slot specified");
		return;
	}

	//holds argumented damage
	int	dam			= 0;

	if (argc > 3)
	{
		//get damage, check limits
		dam	= atoi(argv[3]);
		if (dam > 100)			dam	= 100;
		if (dam < 0)			dam = 0;

		//if to apply damage to all slots
		if (all_slots)
		{
			//apply damage to all damage slots
			for (register int dsl = 0; dsl < NODS; ++dsl)
				PL->sk.damage[dsl] = dam;
		}
		else
		{
			//apply damage to specified damage slot
			*DS		= dam;
		}

		//apply damage from damage slots to bones
		for (register int dsl = 0; dsl < NODS; ++dsl)
		{
			//for all bones
			for (register int b = 0; b < 19; ++b)
			{
				//if bone belongs to current damage slot
				if (PL->sk.b[b].d_slot == dsl)
					//copy damage of damage slot to bone
					PL->sk.b[b].damage = PL->sk.damage[dsl];
			}
		}

		pcon->print_outputbuffer("damage set to %i", dam);
	}
	else
	{
		pcon->print_outputbuffer("no damage specified");
		return;
	}
}

//------------------------------------------------------------------------------------------------
//
//	program_options RegisterConVars
//
//	registers console variable
//
//------------------------------------------------------------------------------------------------

void program_options::RegisterConVars(console *pcon)
{
	//initialize with own values
	//now in options
//	CLASS_CVI(bool, pal, this->pal, 0, 1, CONVARF_RESTRICTED);
//	CLASS_CVI(bool, hitbox, this->hitbox, 0, 1, CONVARF_RESTRICTED);
//	CLASS_CVI(bool, cd_state, this->cd_state, 0, 1, CONVARF_RESTRICTED);
//	CLASS_CVI(bool, showscores, this->showscores, 0, 1, CONVARF_RESTRICTED);
	CLASS_CVIA(bool, xfatigue, 2, this->xfatigue[0], 0, 1, CONVARF_RESTRICTED);
}

//------------------------------------------------------------------------------------------------
//
//	point point
//
//	conversion constructor (in structs.h)
//
//------------------------------------------------------------------------------------------------

point::point(const ipoint &ip)
{
	x	= (float)ip.x;
	y	= (float)ip.y;
};

bool point::operator== (const ipoint &i)
{
	return(x == (float)i.x && y == (float)i.y);
};

//-------------------------------------------------------------------------------------------------
//
//	game_recorder::record()
//
//	records replay
//
//-------------------------------------------------------------------------------------------------

bool game_recorder::record()
{
	//if recording and file valid
	if (recording && f_demo != NULL)
	{
		//if recording time reached option.data.demo_maxlength
		if ((p_time->current - t_rec_start) / p_time->freq >= p_option->data.demo_maxlength)
		{
			gf_logger(false, "game_recorder::record Stopped Max Length Reached %i", p_option->data.demo_maxlength);
			stop();
			return(true);
		}

		//---- write time data -------------------------------------------------------------------

		//time index relative to last frame
		//fprintf(f_demo, "%.9f ", p_time->sca);
		fprintf(f_demo, "%.9f\n", p_time->sca);

		//---- write player data -----------------------------------------------------------------

		//for both players
		for (int p = 0; p < 2; ++p)
		{
			//hara position
			fprintf(f_demo,
					"%.f %.f\n",
					P[p]->sk.p_ref->v.p[0].x,
					P[p]->sk.p_ref->v.p[0].y);

//!! reihenfolge geaendert!

			//fatigue, stance_feet
			fprintf(f_demo,
					"%i %i\n",
					(int)P[p]->fatigue,
					P[p]->stance_feet);

			//for all sounds
			for (int sb = 0; sb < NSBP; ++sb)
			{
				//wenn sound spielt, wenn sound schon spielt, vorher beenden
				//if (ds->

				fprintf(f_demo,
						"%i ",
						(int)P[p]->s_buffer[sb]);
				if ((int)P[p]->s_buffer[sb] != 0)
					fprintf(f_demo,
					"sound");
			}
			//line break
			fprintf(f_demo, "\n");

			//for all bones
			for (int b = 0; b < 19; ++b)
			{
				//angle, length, widt
				fprintf(f_demo,
						"%.f %.f %.f\n",
						P[p]->sk.b[b].angle,
						P[p]->sk.b[b].length,
						P[p]->sk.b[b].width);

				//damage, hit_state, hit_state_e
				fprintf(f_demo,
						"%i %i %i\n",
						P[p]->sk.b[b].damage,
						P[p]->sk.b[b].hit_state,
						P[p]->sk.b[b].hit_state_e);
			}
		}

		//set demo frame end sign
		fprintf(f_demo, "\n\n\n");

		return(true);
	}
	else
	{
		gf_logger(true, "game_recorder::record Not Recording!");
		return(false);
	}
};
