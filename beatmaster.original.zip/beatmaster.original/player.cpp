//------------------------------------------------------------------------------------------------
//
//	player class definitions
//
//------------------------------------------------------------------------------------------------

#include "player.h"					//class declaration header

//------------------------------------------------------------------------------------------------
//
//	player constructor
//
//------------------------------------------------------------------------------------------------

player::player()
{
	//---- timer/option data ---------------------------------------------------------------------

	p_option				= NULL;
	p_time					= NULL;
	t_sca_sf				= 0;

	p_rcd					= NULL;

	p_angle					= NULL;
	p_angle180				= NULL;

	p_distance				= NULL;

	//---- general info --------------------------------------------------------------------------

	id						= 0;
	side					= 0;
	asi						= 0;
	stance_arms				= 0;
	stance_feet				= 0;

	p_opp					= NULL;

	ZeroMemory(&dst_index, sizeof(dst_index));

	//---- skills and game logic info ------------------------------------------------------------

	fatigue						= 0;
	fatigue_buff				= 0;
	fatigue_delay				= 0;
	t_fat_delay_start			= 0;
	t_fatdam_last				= 0;
	skill_freg					= SKILL_FREG;
	skill_freg_ad				= SKILL_FREG;

	walk_fwd_ad					= SKILL_WALK_FWD;
	walk_bwd_ad					= SKILL_WALK_BWD;
	walk_fwd_rush				= 0;
	walk_bwd_rush				= 0;
	walk_lock					= 0;

	ZeroMemory(&power_attack, sizeof(power_attack));
	ZeroMemory(&t_power_attack, sizeof(t_power_attack));

	ZeroMemory(&cd_bh_force, sizeof(cd_bh_force));

	cd_t_pushhit				= 0;
	cd_push_type				= 0;
	cd_push_force				= 0;
	cd_push_speed				= 0;
	cd_cancel_action			= 0;

	gl_score					= 0;
	gl_ko						= 0;
	gl_ko_pending				= 0;

	ZeroMemory(&active_off, sizeof(active_off));
	gl_def_success				= false;

	//---- blood fx ------------------------------------------------------------------------------

	ZeroMemory(&blood_active, sizeof(blood_active));
	ZeroMemory(&blood_size, sizeof(blood_size));
	ZeroMemory(&blood_force, sizeof(blood_force));
	ZeroMemory(&blood_angle_h, sizeof(blood_angle_h));
	ZeroMemory(&blood_angle, sizeof(blood_angle));
	blood_gammaflash			= false;

	//---- animation data ------------------------------------------------------------------------

	for (register int s = 0; s < 4; ++s)
		for (register int i = 0; i < NPAN; ++i)
			p_anmn[s][i]	= NULL;
	p_aslot[aslot_cycle]		= NULL;
	p_aslot[aslot_action]		= NULL;
	p_aslot[aslot_hit]			= NULL;

	ZeroMemory(&opp_time, sizeof(opp_time));

	ZeroMemory(&last_anmn, sizeof(last_anmn));
	ZeroMemory(&advance_slot, sizeof(advance_slot));
	ZeroMemory(&t_advanceslot_start, sizeof(t_advanceslot_start));

	ZeroMemory(&t_animation_adj_start, sizeof(t_animation_adj_start));
	ZeroMemory(&t_animation_adj_delay, sizeof(t_animation_adj_delay));
	ZeroMemory(&animation_adj_type, sizeof(animation_adj_type));

	ZeroMemory(&casi, sizeof(casi));
	ZeroMemory(&cki, sizeof(cki));

	ZeroMemory(&bpc, sizeof(bpc));
	ZeroMemory(&bdc, sizeof(bdc));

	ZeroMemory(&bhi, sizeof(bhi));

	//---- sound data ----------------------------------------------------------------------------

	s_reset_soundbuffer();
	s_pan						= 0;

	//--------------------------------------------------------------------------------------------

	//!! reset player data (default pos)
	reset(0);

	//---- score data ----------------------------------------------------------------------------

	gl_score_multiplier_off[btll]	=
	gl_score_multiplier_off[btlr]	= 1.5f;
	gl_score_multiplier_off[btul]	=
	gl_score_multiplier_off[btur]	= 1.2f;
	gl_score_multiplier_off[bn]		= 3.0f;
	gl_score_multiplier_off[bsl]	= 2.0f;
	gl_score_multiplier_off[baul]	= 1.0f;
	gl_score_multiplier_off[ball]	= 1.0f;
	gl_score_multiplier_off[bsr]	= 2.0f;
	gl_score_multiplier_off[baur]	= 1.0f;
	gl_score_multiplier_off[balr]	= 1.0f;
	gl_score_multiplier_off[bhl]	= 2.5f;
	gl_score_multiplier_off[blul]	= 1.0f;
	gl_score_multiplier_off[blll]	= 1.0f;
	gl_score_multiplier_off[bfl]	= 0.5f;
	gl_score_multiplier_off[bhr]	= 2.5f;
	gl_score_multiplier_off[blur]	= 1.0f;
	gl_score_multiplier_off[bllr]	= 1.0f;
	gl_score_multiplier_off[bfr]	= 0.5f;

	gl_score_multiplier_def[btll]	= 0.5f;
	gl_score_multiplier_def[btlr]	= 0.5f;
	gl_score_multiplier_def[btul]	= 0.5f;
	gl_score_multiplier_def[btur]	= 0.5f;
	gl_score_multiplier_def[bn]		= 0.5f;
	gl_score_multiplier_def[bsl]	= 0.5f;
	gl_score_multiplier_def[baul]	= 0.5f;
	gl_score_multiplier_def[ball]	= 0.5f;
	gl_score_multiplier_def[bsr]	= 0.5f;
	gl_score_multiplier_def[baur]	= 0.5f;
	gl_score_multiplier_def[balr]	= 0.5f;
	gl_score_multiplier_def[bhl]	= 0.5f;
	gl_score_multiplier_def[blul]	= 0.5f;
	gl_score_multiplier_def[blll]	= 0.5f;
	gl_score_multiplier_def[bfl]	= 0.5f;
	gl_score_multiplier_def[bhr]	= 0.5f;
	gl_score_multiplier_def[blur]	= 0.5f;
	gl_score_multiplier_def[bllr]	= 0.5f;
	gl_score_multiplier_def[bfr]	= 0.5f;

	//---- cvars ---------------------------------------------------------------------------------

	//clear console message buffer
	con_clear();

	//---- hud data ------------------------------------------------------------------------------

	p_hud_text				= NULL;

	//---- developer data ------------------------------------------------------------------------

	dev_i					= 0;
	dev_f					= 0;
	dev_pi					= NULL;
	dev_pf					= NULL;

	//--------------------------------------------------------------------------------------------

	gf_logger(false, "player::player done");
}

//------------------------------------------------------------------------------------------------
//
//	player RegisterConVars
//
//	registers console variables
//
//------------------------------------------------------------------------------------------------

void player::RegisterConVars(console *pcon)
{
//	CLASS_CVI(float, fatigue, 0, 0, 100, 0);
}

//------------------------------------------------------------------------------------------------
//
//	player initialization
//
//------------------------------------------------------------------------------------------------

bool player::pl_initialization(int player)				//player 1 always left, p2 right
{
	//---- damage slot transfer indices ----------------------------------------------------------

	//-1 == no link
	for (register int i = 0; i < NODS; ++i)
		dst_index[i][0] =
		dst_index[i][1] =
		dst_index[i][2] =
		dst_index[i][3] =
		dst_index[i][4] = -1;

	dst_index[DS_fll][0]	= DS_hll;
	dst_index[DS_flr][0]	= DS_hlr;

	dst_index[DS_hll][0]	= DS_fll;
	dst_index[DS_hll][1]	= DS_tll;
	dst_index[DS_hlr][0]	= DS_flr;
	dst_index[DS_hlr][1]	= DS_tlr;

	dst_index[DS_al][0]		= DS_tul;
	dst_index[DS_ar][0]		= DS_tur;

	dst_index[DS_hn][0]		= DS_tul;			//updated depending on asi

	dst_index[DS_tll][0]	= DS_hll;
//	dst_index[DS_tll][1]	= DS_tlr;
	dst_index[DS_tll][1]	= DS_tul;
	dst_index[DS_tlr][0]	= DS_hlr;
//	dst_index[DS_tlr][1]	= DS_tll;
	dst_index[DS_tlr][1]	= DS_tur;

	dst_index[DS_tul][0]	= DS_al;
//	dst_index[DS_tul][1]	= DS_tur;
	dst_index[DS_tul][1]	= DS_tll;
	dst_index[DS_tul][2]	= DS_hn;
	dst_index[DS_tur][0]	= DS_ar;
//	dst_index[DS_tur][1]	= DS_tul;
	dst_index[DS_tur][1]	= DS_tlr;
	dst_index[DS_tur][2]	= DS_hn;

	//---- pointer to parent bone ----------------------------------------------------------------

	sk.b[btll].p_pb			= NULL;				sk.b[btlr].p_pb			= NULL;
	sk.b[btul].p_pb			= &sk.b[btll];		sk.b[btur].p_pb			= &sk.b[btlr];
	sk.b[bn].p_pb			= &sk.b[btul];

	sk.b[bsl].p_pb			= &sk.b[btul];		sk.b[bsr].p_pb			= &sk.b[btur];
	sk.b[baul].p_pb			= &sk.b[bsl];		sk.b[baur].p_pb			= &sk.b[bsr];
	sk.b[ball].p_pb			= &sk.b[baul];		sk.b[balr].p_pb			= &sk.b[baur];

	sk.b[bhl].p_pb			= &sk.b[btll];		sk.b[bhr].p_pb			= &sk.b[btlr];
	sk.b[blul].p_pb			= &sk.b[bhl];		sk.b[blur].p_pb			= &sk.b[bhr];
	sk.b[blll].p_pb			= &sk.b[blul];		sk.b[bllr].p_pb			= &sk.b[blur];
	sk.b[bfl].p_pb			= &sk.b[blll];		sk.b[bfr].p_pb			= &sk.b[bllr];

	//---- parent bone index ---------------------------------------------------------------------

	sk.b[btll].pbi			= -1;				sk.b[btlr].pbi			= -1;
	sk.b[btul].pbi			= btll;				sk.b[btur].pbi			= btlr;
	sk.b[bn].pbi			= btul;

	sk.b[bsl].pbi			= btul;				sk.b[bsr].pbi			= btur;
	sk.b[baul].pbi			= bsl;				sk.b[baur].pbi			= bsr;
	sk.b[ball].pbi			= baul;				sk.b[balr].pbi			= baur;

	sk.b[bhl].pbi			= btll;				sk.b[bhr].pbi			= btlr;
	sk.b[blul].pbi			= bhl;				sk.b[blur].pbi			= bhr;
	sk.b[blll].pbi			= blul;				sk.b[bllr].pbi			= blur;
	sk.b[bfl].pbi			= blll;				sk.b[bfr].pbi			= bllr;

	//---- bone type -----------------------------------------------------------------------------
	//0 = standard with visible damage
	//1 = standard with fist
	//2 = no visible damage (black)
	//3 = no visible/visible damage with head

	//type depending on program options
	//!! cd_state steht zwar in options, aber nicht fest und type wird nur
	//bei initialization gesetzt
//	if (!p_option->data.cd_state)
	if (true)
	{
		sk.b[btll].type			= 0;	sk.b[btlr].type			= 0;
		sk.b[btul].type			= 0;	sk.b[btur].type			= 0;
		sk.b[bn].type			= 3;

		sk.b[bsl].type			= 2;	sk.b[bsr].type			= 2;
		sk.b[baul].type			= 0;	sk.b[baur].type			= 0;
		sk.b[ball].type			= 1;	sk.b[balr].type			= 1;

		sk.b[bhl].type			= 2;	sk.b[bhr].type			= 2;
		sk.b[blul].type			= 0;	sk.b[blur].type			= 0;
		sk.b[blll].type			= 0;	sk.b[bllr].type			= 0;
		sk.b[bfl].type			= 2;	sk.b[bfr].type			= 2;
	}
	else
	{
		sk.b[btll].type			= 0;	sk.b[btlr].type			= 0;
		sk.b[btul].type			= 0;	sk.b[btur].type			= 0;
		sk.b[bn].type			= 3;

		sk.b[bsl].type			= 0;	sk.b[bsr].type			= 0;
		sk.b[baul].type			= 0;	sk.b[baur].type			= 0;
		sk.b[ball].type			= 1;	sk.b[balr].type			= 1;

		sk.b[bhl].type			= 0;	sk.b[bhr].type			= 0;
		sk.b[blul].type			= 0;	sk.b[blur].type			= 0;
		sk.b[blll].type			= 0;	sk.b[bllr].type			= 0;
		sk.b[bfl].type			= 0;	sk.b[bfr].type			= 0;
	}

	//---- damage slots --------------------------------------------------------------------------

	sk.b[btll].d_slot		= DS_tll;	sk.b[btlr].d_slot		= DS_tlr;
	sk.b[btul].d_slot		= DS_tul;	sk.b[btur].d_slot		= DS_tur;
	sk.b[bn].d_slot			= DS_hn;

	sk.b[bsl].d_slot		= DS_al;	sk.b[bsr].d_slot		= DS_ar;
	sk.b[baul].d_slot		= DS_al;	sk.b[baur].d_slot		= DS_ar;
	sk.b[ball].d_slot		= DS_al;	sk.b[balr].d_slot		= DS_ar;

	sk.b[bhl].d_slot		= DS_hll;	sk.b[bhr].d_slot		= DS_hlr;
	sk.b[blul].d_slot		= DS_hll;	sk.b[blur].d_slot		= DS_hlr;
	sk.b[blll].d_slot		= DS_fll;	sk.b[bllr].d_slot		= DS_flr;
	sk.b[bfl].d_slot		= DS_fll;	sk.b[bfr].d_slot		= DS_flr;

	//---- head/fist radius ----------------------------------------------------------------------

	sk.radius_fist				= 12 / 2;
	//reduced by one for more generous collision detection
	sk.radius_head				= 26 / 2 - 1;

	//arm guard
	stance_arms					= 65;

	//player 1
	if (player == P1)
	{
		//set player id
		id					= P1;
		//player id for each bone
		for (register int i = 0; i < 19; ++i)
			sk.b[i].id		= P1;

		//set player 1 to left side
		side	= SLEFT;

		//set initial stance
		set_stance(SLEFT);

		//start coordinates
		sk.p_ref->v.p[0].x = 249;
		sk.p_ref->v.p[0].y = S_PYDEF;
	}

	//player 2
	if (player == P2)
	{
		//set player id
		id					= P2;
		//player id for each bone
		for (register int i = 0; i < 19; ++i)
			sk.b[i].id		= P2;

		//set player 2 to right side
		side	= SRIGHT;

		//set inital stance
		set_stance(SLEFT);

		//start coordinates
		sk.p_ref->v.p[0].x = 549;
		sk.p_ref->v.p[0].y = S_PYDEF;
	}

	//---- blood fx ------------------------------------------------------------------------------

	RECT	screen;
	screen.left		= 0;	screen.right	= 799;
	screen.top		= 75;	screen.bottom	= S_FLOOR;		//particles stay on bottom

	//create 2 particle arrays with defined size
	blood_fx[0].create_heap(NOBLOOD, screen);
	blood_fx[1].create_heap(NOBLOOD, screen);

	return(true);
}

//------------------------------------------------------------------------------------------------
//
//	player set_opp_data
//
//	sets pointers to opponents data
//
//------------------------------------------------------------------------------------------------

void player::set_opp_data(player *_opp)
{
	p_opp			= _opp;
}

//------------------------------------------------------------------------------------------------
//
//	player cleanup
//
//------------------------------------------------------------------------------------------------

void player::pl_cleanup()
{
	//---- xxx -----------------------------------------------------------------------------------

	gf_logger(false, "player::pl_cleanup done");
}

//------------------------------------------------------------------------------------------------
//
//	player set_data_pointer
//
//	fills pointer to timer and option data
//
//------------------------------------------------------------------------------------------------

void player::set_data_pointer(options *_options, timer *_timer, hud_text *_hud,
							  result_collision_detection *p_rcd_,
							  int *p_a, int *p_a180,
							  float *p_dist)
{
	p_option			= _options;
	p_time				= _timer;
	p_hud_text			= _hud;

	p_rcd				= p_rcd_;

	p_angle				= p_a;
	p_angle180			= p_a180;

	p_distance			= p_dist;

	//set data pointers in player message
	pmessage.set_data_pointer(_options, _timer, &sk.chead);
//	pmessage.set_data_pointer((options *)p_option, (timer *)p_time, &sk.chead);
}

//------------------------------------------------------------------------------------------------
//
//	player set_z_order
//
//------------------------------------------------------------------------------------------------

void player::set_z_order(int _tll, int _tlr, int _tul, int _tur, int _n,
						 int _sl, int _aul, int _all,
						 int _sr, int _aur, int _alr,
						 int _hl, int _lul, int _lll, int _fl,
						 int _hr, int _lur, int _llr, int _fr)
{
	sk.b[btll].z			= _tll;		sk.b[btlr].z			= _tlr;
	sk.b[btul].z			= _tul;		sk.b[btur].z			= _tur;
	sk.b[bn].z				= _n;

	sk.b[bsl].z				= _sl;		sk.b[bsr].z				= _sr;
	sk.b[baul].z			= _aul;		sk.b[baur].z			= _aur;
	sk.b[ball].z			= _all;		sk.b[balr].z			= _alr;

	sk.b[bhl].z				= _hl;		sk.b[bhr].z				= _hr;
	sk.b[blul].z			= _lul;		sk.b[blur].z			= _lur;
	sk.b[blll].z			= _lll;		sk.b[bllr].z			= _llr;
	sk.b[bfl].z				= _fl;		sk.b[bfr].z				= _fr;
}

//------------------------------------------------------------------------------------------------
//
//	player reset
//
//	resets player values before new round
//	argument indicates which player is left
//
//------------------------------------------------------------------------------------------------

void player::reset(int pos)
{
	//---- position ------------------------------------------------------------------------------

	//arm guard
	stance_arms					= 65;

	//set player positions
	if (p_option != NULL)
		if (!p_option->data.randomstart)
			pos = 1;

	//P1 left, P2 right
//	if (pos || DEVELOPER_)
	if (pos)
	{
		if (id == P1)
		{
			//player side
			set_side(SLEFT);
			set_stance(SLEFT);

			//player position
			sk.p_ref->v.p[0].x	= 249;
			sk.p_ref->v.p[0].y	= S_PYDEF;
		}
		else
		{
			set_side(SRIGHT);
			set_stance(SLEFT);

			sk.p_ref->v.p[0].x	= 549;
			sk.p_ref->v.p[0].y	= S_PYDEF;
		}
	}
	else
	//P1 right, P2 left
	{
		if (id == P2)
		{
			set_side(SLEFT);
			set_stance(SLEFT);

			sk.p_ref->v.p[0].x	= 249;
			sk.p_ref->v.p[0].y	= S_PYDEF;
		}
		else
		{
			set_side(SRIGHT);
			set_stance(SLEFT);

			sk.p_ref->v.p[0].x	= 549;
			sk.p_ref->v.p[0].y	= S_PYDEF;
		}
	}

	//---- bone states ---------------------------------------------------------------------------

	//for all bones
	for (register int b = 0; b < 19; ++b)
	{
		sk.b[b].hit_state	= hs_nohit;
		sk.b[b].hit_state_e	= hs_nohit;
	}

	//---- keyframe ------------------------------------------------------------------------------

	//set player skeleton to default keyframe
	set_keyframe(AN_DEFAULT, 0);

	//---- skills and game logic info ------------------------------------------------------------

	//flag set on start of new game
//!!if (wp)
//		ZeroMemory(&winloss, sizeof(winloss));

	gl_score					= 0;
	gl_ko						= 0;
	gl_ko_pending				= 0;

	fatigue						= 0;
	fatigue_buff				= 0;
	fatigue_delay				= 0;
	t_fat_delay_start			= 0;
	t_fatdam_last				= 0;
	skill_freg					= SKILL_FREG;
	skill_freg_ad				= SKILL_FREG;

	walk_fwd_ad					= SKILL_WALK_FWD;
	walk_bwd_ad					= SKILL_WALK_BWD;
	walk_fwd_rush				= 0;
	walk_bwd_rush				= 0;
	walk_lock					= 0;

	ZeroMemory(&power_attack, sizeof(power_attack));
	ZeroMemory(&t_power_attack, sizeof(t_power_attack));

	ZeroMemory(&cd_bh_force, sizeof(cd_bh_force));

	cd_t_pushhit				= 0;
	cd_push_type				= 0;
	cd_push_force				= 0;
	cd_push_speed				= 0;
	cd_cancel_action			= 0;

	//deactivate offensive
	ZeroMemory(&active_off, sizeof(active_off));
	//defense success
	gl_def_success				= false;

	//!!
damage_dealt_last				= 0;

	//for all bones reset damage
	for (register int i = 0; i < 19; ++i)
		sk.b[i].damage = 0;
	//reset skeleton damage
	ZeroMemory(&sk.damage, sizeof(sk.damage));

	//deactivate blood
	ZeroMemory(&blood_active, sizeof(blood_active));
	ZeroMemory(&blood_size, sizeof(blood_size));
	ZeroMemory(&blood_force, sizeof(blood_force));
	ZeroMemory(&blood_angle_h, sizeof(blood_angle_h));
	ZeroMemory(&blood_angle, sizeof(blood_angle));
	blood_gammaflash			= false;

	gl_lock.reset();
	gl_SetBoneLockState(true);

	//---- reset animation data ------------------------------------------------------------------

	//deactivate slots
	al_deactivate_slot(aslot_cycle);
	al_deactivate_slot(aslot_action);
	al_deactivate_slot(aslot_hit);

	ZeroMemory(&last_anmn, sizeof(last_anmn));
	ZeroMemory(&advance_slot, sizeof(advance_slot));
	ZeroMemory(&t_advanceslot_start, sizeof(t_advanceslot_start));

	ZeroMemory(&t_animation_adj_start, sizeof(t_animation_adj_start));
	ZeroMemory(&t_animation_adj_delay, sizeof(t_animation_adj_delay));
	ZeroMemory(&animation_adj_type, sizeof(animation_adj_type));

	ZeroMemory(&casi, sizeof(casi));
	ZeroMemory(&cki, sizeof(cki));

	ZeroMemory(&bpc, sizeof(bpc));
	ZeroMemory(&bdc, sizeof(bdc));

	ZeroMemory(&bhi, sizeof(bhi));

	ZeroMemory(&opp_time, sizeof(opp_time));

	//---- last leg tap data ---------------------------------------------------------------------
	//in case leg is def_locked before first proper tap
	//set default angle (0 degree)

	//for all asi
	al_legtap_last_a[0]		= al_legtap_last_a[1]		= 0;
	al_legtap_last_a_180[0]	= al_legtap_last_a_180[1]	= 89;
	al_legtap_last_a[2]		= al_legtap_last_a[3]		= 180;
	al_legtap_last_a_180[2]	= al_legtap_last_a_180[3]	= 89;

	t_last_tap_arms			= 0;
	t_last_tap_legs			= 0;

	//---- combo data ----------------------------------------------------------------------------

	t_combo_lasthit			= 0;
	combo_counter			= 0;
	combo_damage			= 0;

	//---- handicaps -----------------------------------------------------------------------------

	gl_SetHandicap();

	//---- sound data ----------------------------------------------------------------------------

	s_reset_soundbuffer();
	s_pan						= 0;

	//reset player all messages
	pmessage.reset();
}

//------------------------------------------------------------------------------------------------
//
//	player set_keyframe
//
//	sets player skeleton to argumented animations keyframe
//
//------------------------------------------------------------------------------------------------

void player::set_keyframe(int anmn_index, int keyframe, float s_zoom)
{
	//if animation and keyframe not valid return
	if (p_anmn[asi][anmn_index] == NULL)
		return;
	else
		if (keyframe > p_anmn[asi][anmn_index]->nokf - 1)
			return;

	//for all bones
	for (register int i = 0; i < 19; ++i)
	{
		//set angle, lenght and width
		//absolute
		//angle relative to parent or current
		if ((p_anmn[asi][anmn_index]->pkf[keyframe].mode_a[i] == 1 ||
			p_anmn[asi][anmn_index]->pkf[keyframe].mode_a[i] == 1) &&
			sk.b[i].p_pb != NULL)
			sk.b[i].angle	= p_anmn[asi][anmn_index]->pkf[keyframe].angle[sk.b[i].pbi] +
							  p_anmn[asi][anmn_index]->pkf[keyframe].angle[i];
		else
			//absolute
			sk.b[i].angle	= p_anmn[asi][anmn_index]->pkf[keyframe].angle[i];

		sk.b[i].length	= p_anmn[asi][anmn_index]->pkf[keyframe].length[i] * s_zoom;
		sk.b[i].width	= p_anmn[asi][anmn_index]->pkf[keyframe].width[i] * s_zoom;

		//no hara
	}
}

//------------------------------------------------------------------------------------------------
//
//	player set_keyframe
//
//	overloaded
//	sets only selected bones to argumented animations keyframe
//
//------------------------------------------------------------------------------------------------

void player::set_keyframe(int anmn_index, int keyframe, float s_zoom, bool _b[19])
{
	//if animation and keyframe not valid return
	if (p_anmn[asi][anmn_index] == NULL)
		return;
	else
		if (keyframe > p_anmn[asi][anmn_index]->nokf - 1)
			return;

	//for all selected bones
	for (register int i = 0; i < 19; ++i)
	{
		if (_b[i])
		{
			//set angle, lenght and width
			//absolute
			//angle relative to parent or current
			if ((p_anmn[asi][anmn_index]->pkf[keyframe].mode_a[i] == 1 ||
				p_anmn[asi][anmn_index]->pkf[keyframe].mode_a[i] == 1) &&
				sk.b[i].p_pb != NULL)
				sk.b[i].angle	= p_anmn[asi][anmn_index]->pkf[keyframe].angle[sk.b[i].pbi] +
								  p_anmn[asi][anmn_index]->pkf[keyframe].angle[i];
			else
				//absolute
				sk.b[i].angle	= p_anmn[asi][anmn_index]->pkf[keyframe].angle[i];

			sk.b[i].length	= p_anmn[asi][anmn_index]->pkf[keyframe].length[i] * s_zoom;
			sk.b[i].width	= p_anmn[asi][anmn_index]->pkf[keyframe].width[i] * s_zoom;

			//no hara
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player set_stance
//
//	sets player feet stance and changes all skeleton values in accordance
//	(calculation order, joint alignment and direction, z-order)
//
//------------------------------------------------------------------------------------------------

void player::set_stance(int stance)
{
	//save current reference bone x-position and apply it to new reference bone
	//after stance change so that the actual player position won't be affected
	point	ref_bu;
	if (sk.p_ref != NULL)
		ref_bu = sk.p_ref->v.p[0];

	//left side
	if (side == SLEFT)
	{
		//set stance
		stance_feet = stance;

		//if left foot forward
		if (stance_feet == SLEFT)
		{
			//---- set calculation order ---------------------------------------------------------

			//bone calculation order
			sk.b_order[0] = 0;			sk.b_order[1] = 1;
			sk.b_order[2] = 2;			sk.b_order[3] = 3;

			//---- parent bone, parent bone index ------------------------------------------------
			//only neck changes parent bone to alway front upper torso

			sk.b[bn].p_pb			= &sk.b[btul];
			sk.b[bn].pbi			= btul;

			//---- reference bone, joints and width angle direction ------------------------------

			//reference bone has no parent bone
			//f_aw indicates whether angle of width is angle + 90� (1) or angle - 90� (0)
			sk.p_ref					= &sk.b[btll];
			sk.b[btll].p_pbjv			= NULL;					sk.b[btll].f_aw		= 0;

			sk.b[btlr].p_pbjv			= &sk.b[btll].v.p[3];	sk.b[btlr].f_aw		= 0;
			sk.b[btul].p_pbjv			= &sk.b[btll].v.p[1];	sk.b[btul].f_aw		= 0;
			sk.b[btur].p_pbjv			= &sk.b[btul].v.p[3];	sk.b[btur].f_aw		= 0;
			sk.b[bn].p_pbjv				= &sk.b[btul].v.p[2];	sk.b[bn].f_aw		= 1;

			sk.b[bsl].p_pbjv			= &sk.b[btul].v.p[1];	sk.b[bsl].f_aw		= 0;
			sk.b[baul].p_pbjv			= &sk.b[bsl].v.p[1];	sk.b[baul].f_aw		= 0;
			sk.b[ball].p_pbjv			= &sk.b[baul].v.p[2];	sk.b[ball].f_aw		= 1;

			sk.b[bsr].p_pbjv			= &sk.b[btur].v.p[2];	sk.b[bsr].f_aw		= 1;
			sk.b[baur].p_pbjv			= &sk.b[bsr].v.p[1];	sk.b[baur].f_aw		= 1;
			sk.b[balr].p_pbjv			= &sk.b[baur].v.p[1];	sk.b[balr].f_aw		= 1;

			sk.b[bhl].p_pbjv			= &sk.b[btll].v.p[0];	sk.b[bhl].f_aw		= 1;
			sk.b[blul].p_pbjv			= &sk.b[bhl].v.p[2];	sk.b[blul].f_aw		= 0;
			sk.b[blll].p_pbjv			= &sk.b[blul].v.p[1];	sk.b[blll].f_aw		= 0;
			sk.b[bfl].p_pbjv			= &sk.b[blll].v.p[1];	sk.b[bfl].f_aw		= 1;

			sk.b[bhr].p_pbjv			= &sk.b[btlr].v.p[3];	sk.b[bhr].f_aw		= 0;
			sk.b[blur].p_pbjv			= &sk.b[bhr].v.p[2];	sk.b[blur].f_aw		= 1;
			sk.b[bllr].p_pbjv			= &sk.b[blur].v.p[2];	sk.b[bllr].f_aw		= 0;
			sk.b[bfr].p_pbjv			= &sk.b[bllr].v.p[1];	sk.b[bfr].f_aw		= 1;

			//---- relative bone angle limits ----------------------------------------------------

			sk.b[btll].angle_vd[0]		= 0;		sk.b[btll].angle_vd[1]			= 0;
			sk.b[btlr].angle_vd[0]		= 0;		sk.b[btlr].angle_vd[1]			= 0;
			sk.b[btul].angle_vd[0]		= -20;		sk.b[btul].angle_vd[1]			= 125;
			sk.b[btur].angle_vd[0]		= -20;		sk.b[btur].angle_vd[1]			= 125;
			sk.b[bn].angle_vd[0]		= -30;		sk.b[bn].angle_vd[1]			= 90;

			sk.b[bsl].angle_vd[0]		= -180;		sk.b[bsl].angle_vd[1]			= 180;
			sk.b[baul].angle_vd[0]		= -180;		sk.b[baul].angle_vd[1]			= 180;
			sk.b[ball].angle_vd[0]		= -180;		sk.b[ball].angle_vd[1]			= 10;

			sk.b[bsr].angle_vd[0]		= -180;		sk.b[bsr].angle_vd[1]			= 180;
			sk.b[baur].angle_vd[0]		= -180;		sk.b[baur].angle_vd[1]			= 180;
			sk.b[balr].angle_vd[0]		= -180;		sk.b[balr].angle_vd[1]			= 10;

			sk.b[bhl].angle_vd[0]		= -180;		sk.b[bhl].angle_vd[1]			= 180;
//			sk.b[blul].angle_vd[0]		= -20;		sk.b[blul].angle_vd[1]			= 125;
//			sk.b[blll].angle_vd[0]		= -10;		sk.b[blll].angle_vd[1]			= 180;
			sk.b[blul].angle_vd[0]		= -40;		sk.b[blul].angle_vd[1]			= 125;
			sk.b[blll].angle_vd[0]		= -10;		sk.b[blll].angle_vd[1]			= 160;
			sk.b[bfl].angle_vd[0]		= -125;		sk.b[bfl].angle_vd[1]			= 0;

			sk.b[bhr].angle_vd[0]		= -180;		sk.b[bhr].angle_vd[1]			= 180;
//			sk.b[blur].angle_vd[0]		= -125;		sk.b[blur].angle_vd[1]			= 20;
//			sk.b[bllr].angle_vd[0]		= -10;		sk.b[bllr].angle_vd[1]			= 180;
			sk.b[blur].angle_vd[0]		= -125;		sk.b[blur].angle_vd[1]			= 40;
			sk.b[bllr].angle_vd[0]		= -10;		sk.b[bllr].angle_vd[1]			= 160;
			sk.b[bfr].angle_vd[0]		= -125;		sk.b[bfr].angle_vd[1]			= 0;

			//---- z-order -----------------------------------------------------------------------

			set_z_order(25, 25, 26, 26, 27,
						5, 6, 7,
						45, 46, 47,
						15, 16, 17, 18,
						35, 36, 37, 38);
		}
		else
		//right foot forward
		{
			//---- set calculation order ---------------------------------------------------------

			//bone calculation order
			sk.b_order[0] = 1;			sk.b_order[1] = 0;
			sk.b_order[2] = 3;			sk.b_order[3] = 2;

			//---- parent bone, parent bone index ------------------------------------------------
			//only neck changes parent bone to alway front upper torso

			sk.b[bn].p_pb			= &sk.b[btur];
			sk.b[bn].pbi			= btur;

			//---- reference bone, joints and width angle direction ------------------------------

			//reference bone has no parent bone
			//f_aw indicates whether angle of width is angle + 90� (1) or angle - 90� (0)
			sk.p_ref					= &sk.b[btlr];
			sk.b[btlr].p_pbjv			= NULL;					sk.b[btlr].f_aw		= 0;

			sk.b[btll].p_pbjv			= &sk.b[btlr].v.p[3];	sk.b[btll].f_aw		= 0;
			sk.b[btul].p_pbjv			= &sk.b[btur].v.p[3];	sk.b[btul].f_aw		= 0;
			sk.b[btur].p_pbjv			= &sk.b[btlr].v.p[1];	sk.b[btur].f_aw		= 0;
			sk.b[bn].p_pbjv				= &sk.b[btur].v.p[2];	sk.b[bn].f_aw		= 1;

			sk.b[bsl].p_pbjv			= &sk.b[btul].v.p[2];	sk.b[bsl].f_aw		= 1;
			sk.b[baul].p_pbjv			= &sk.b[bsl].v.p[1];	sk.b[baul].f_aw		= 1;
			sk.b[ball].p_pbjv			= &sk.b[baul].v.p[1];	sk.b[ball].f_aw		= 1;

			sk.b[bsr].p_pbjv			= &sk.b[btur].v.p[1];	sk.b[bsr].f_aw		= 0;
			sk.b[baur].p_pbjv			= &sk.b[bsr].v.p[1];	sk.b[baur].f_aw		= 0;
			sk.b[balr].p_pbjv			= &sk.b[baur].v.p[2];	sk.b[balr].f_aw		= 1;

			sk.b[bhl].p_pbjv			= &sk.b[btll].v.p[3];	sk.b[bhl].f_aw		= 0;
			sk.b[blul].p_pbjv			= &sk.b[bhl].v.p[2];	sk.b[blul].f_aw		= 1;
			sk.b[blll].p_pbjv			= &sk.b[blul].v.p[2];	sk.b[blll].f_aw		= 0;
			sk.b[bfl].p_pbjv			= &sk.b[blll].v.p[1];	sk.b[bfl].f_aw		= 1;

			sk.b[bhr].p_pbjv			= &sk.b[btlr].v.p[0];	sk.b[bhr].f_aw		= 1;
			sk.b[blur].p_pbjv			= &sk.b[bhr].v.p[2];	sk.b[blur].f_aw		= 0;
			sk.b[bllr].p_pbjv			= &sk.b[blur].v.p[1];	sk.b[bllr].f_aw		= 0;
			sk.b[bfr].p_pbjv			= &sk.b[bllr].v.p[1];	sk.b[bfr].f_aw		= 1;

			//---- relative bone angle limits ----------------------------------------------------

			sk.b[btll].angle_vd[0]		= 0;		sk.b[btll].angle_vd[1]			= 0;
			sk.b[btlr].angle_vd[0]		= 0;		sk.b[btlr].angle_vd[1]			= 0;
			sk.b[btul].angle_vd[0]		= -20;		sk.b[btul].angle_vd[1]			= 125;
			sk.b[btur].angle_vd[0]		= -20;		sk.b[btur].angle_vd[1]			= 125;
			sk.b[bn].angle_vd[0]		= -30;		sk.b[bn].angle_vd[1]			= 90;

			sk.b[bsl].angle_vd[0]		= -180;		sk.b[bsl].angle_vd[1]			= 180;
			sk.b[baul].angle_vd[0]		= -180;		sk.b[baul].angle_vd[1]			= 180;
			sk.b[ball].angle_vd[0]		= -180;		sk.b[ball].angle_vd[1]			= 10;

			sk.b[bsr].angle_vd[0]		= -180;		sk.b[bsr].angle_vd[1]			= 180;
			sk.b[baur].angle_vd[0]		= -180;		sk.b[baur].angle_vd[1]			= 180;
			sk.b[balr].angle_vd[0]		= -180;		sk.b[balr].angle_vd[1]			= 10;

			sk.b[bhl].angle_vd[0]		= -180;		sk.b[bhl].angle_vd[1]			= 180;
//			sk.b[blul].angle_vd[0]		= -125;		sk.b[blul].angle_vd[1]			= 20;
//			sk.b[blll].angle_vd[0]		= -10;		sk.b[blll].angle_vd[1]			= 180;
			sk.b[blul].angle_vd[0]		= -125;		sk.b[blul].angle_vd[1]			= 40;
			sk.b[blll].angle_vd[0]		= -10;		sk.b[blll].angle_vd[1]			= 160;
			sk.b[bfl].angle_vd[0]		= -125;		sk.b[bfl].angle_vd[1]			= 0;

			sk.b[bhr].angle_vd[0]		= -180;		sk.b[bhr].angle_vd[1]			= 180;
//			sk.b[blur].angle_vd[0]		= -20;		sk.b[blur].angle_vd[1]			= 125;
//			sk.b[bllr].angle_vd[0]		= -10;		sk.b[bllr].angle_vd[1]			= 180;
			sk.b[blur].angle_vd[0]		= -40;		sk.b[blur].angle_vd[1]			= 125;
			sk.b[bllr].angle_vd[0]		= -10;		sk.b[bllr].angle_vd[1]			= 160;
			sk.b[bfr].angle_vd[0]		= -125;		sk.b[bfr].angle_vd[1]			= 0;

			//---- z-order -----------------------------------------------------------------------

			set_z_order(27, 27, 26, 26, 25,
						7, 6, 5,
						47, 46, 45,
						18, 17, 16, 15,
						38, 37, 36, 35);
		}
	}
	else
	//right side
	{
		//set stance
		stance_feet = stance;

		//if left foot forward
		if (stance_feet == SLEFT)
		{
			//---- set calculation order ---------------------------------------------------------

			//bone calculation order
			sk.b_order[0] = 0;			sk.b_order[1] = 1;
			sk.b_order[2] = 2;			sk.b_order[3] = 3;

			//---- parent bone, parent bone index ------------------------------------------------
			//only neck changes parent bone to alway front upper torso

			sk.b[bn].p_pb			= &sk.b[btul];
			sk.b[bn].pbi			= btul;

			//---- reference bone, joints and width angle direction ------------------------------

			//reference bone has no parent bone
			//f_aw indicates whether angle of width is angle + 90� (1) or angle - 90� (0)
			sk.p_ref					= &sk.b[btll];
			sk.b[btll].p_pbjv			= NULL;					sk.b[btll].f_aw		= 1;

			sk.b[btlr].p_pbjv			= &sk.b[btll].v.p[3];	sk.b[btlr].f_aw		= 1;
			sk.b[btul].p_pbjv			= &sk.b[btll].v.p[1];	sk.b[btul].f_aw		= 1;
			sk.b[btur].p_pbjv			= &sk.b[btul].v.p[3];	sk.b[btur].f_aw		= 1;
			sk.b[bn].p_pbjv				= &sk.b[btul].v.p[2];	sk.b[bn].f_aw		= 0;

			sk.b[bsl].p_pbjv			= &sk.b[btul].v.p[1];	sk.b[bsl].f_aw		= 1;
			sk.b[baul].p_pbjv			= &sk.b[bsl].v.p[1];	sk.b[baul].f_aw		= 1;
			sk.b[ball].p_pbjv			= &sk.b[baul].v.p[2];	sk.b[ball].f_aw		= 0;

			sk.b[bsr].p_pbjv			= &sk.b[btur].v.p[2];	sk.b[bsr].f_aw		= 0;
			sk.b[baur].p_pbjv			= &sk.b[bsr].v.p[1];	sk.b[baur].f_aw		= 0;
			sk.b[balr].p_pbjv			= &sk.b[baur].v.p[1];	sk.b[balr].f_aw		= 0;

			sk.b[bhl].p_pbjv			= &sk.b[btll].v.p[0];	sk.b[bhl].f_aw		= 0;
			sk.b[blul].p_pbjv			= &sk.b[bhl].v.p[2];	sk.b[blul].f_aw		= 1;
			sk.b[blll].p_pbjv			= &sk.b[blul].v.p[1];	sk.b[blll].f_aw		= 1;
			sk.b[bfl].p_pbjv			= &sk.b[blll].v.p[1];	sk.b[bfl].f_aw		= 0;

			sk.b[bhr].p_pbjv			= &sk.b[btlr].v.p[3];	sk.b[bhr].f_aw		= 1;
			sk.b[blur].p_pbjv			= &sk.b[bhr].v.p[2];	sk.b[blur].f_aw		= 0;
			sk.b[bllr].p_pbjv			= &sk.b[blur].v.p[2];	sk.b[bllr].f_aw		= 1;
			sk.b[bfr].p_pbjv			= &sk.b[bllr].v.p[1];	sk.b[bfr].f_aw		= 0;

			//---- relative bone angle limits ----------------------------------------------------

			sk.b[btll].angle_vd[0]		= 0;		sk.b[btll].angle_vd[1]			= 0;
			sk.b[btlr].angle_vd[0]		= 0;		sk.b[btlr].angle_vd[1]			= 0;
			sk.b[btul].angle_vd[0]		= -125;		sk.b[btul].angle_vd[1]			= 20;
			sk.b[btur].angle_vd[0]		= -125;		sk.b[btur].angle_vd[1]			= 20;
			sk.b[bn].angle_vd[0]		= -90;		sk.b[bn].angle_vd[1]			= 30;

			sk.b[bsl].angle_vd[0]		= -180;		sk.b[bsl].angle_vd[1]			= 180;
			sk.b[baul].angle_vd[0]		= -180;		sk.b[baul].angle_vd[1]			= 180;
			sk.b[ball].angle_vd[0]		= -10;		sk.b[ball].angle_vd[1]			= 180;

			sk.b[bsr].angle_vd[0]		= -180;		sk.b[bsr].angle_vd[1]			= 180;
			sk.b[baur].angle_vd[0]		= -180;		sk.b[baur].angle_vd[1]			= 180;
			sk.b[balr].angle_vd[0]		= -10;		sk.b[balr].angle_vd[1]			= 180;

			sk.b[bhl].angle_vd[0]		= -180;		sk.b[bhl].angle_vd[1]			= 180;
//			sk.b[blul].angle_vd[0]		= -125;		sk.b[blul].angle_vd[1]			= 20;
//			sk.b[blll].angle_vd[0]		= -180;		sk.b[blll].angle_vd[1]			= 10;
			sk.b[blul].angle_vd[0]		= -125;		sk.b[blul].angle_vd[1]			= 40;
			sk.b[blll].angle_vd[0]		= -160;		sk.b[blll].angle_vd[1]			= 10;
			sk.b[bfl].angle_vd[0]		= 0;		sk.b[bfl].angle_vd[1]			= 125;

			sk.b[bhr].angle_vd[0]		= -180;		sk.b[bhr].angle_vd[1]			= 180;
//			sk.b[blur].angle_vd[0]		= -20;		sk.b[blur].angle_vd[1]			= 125;
//			sk.b[bllr].angle_vd[0]		= -180;		sk.b[bllr].angle_vd[1]			= 10;
			sk.b[blur].angle_vd[0]		= -40;		sk.b[blur].angle_vd[1]			= 125;
			sk.b[bllr].angle_vd[0]		= -160;		sk.b[bllr].angle_vd[1]			= 10;
			sk.b[bfr].angle_vd[0]		= 0;		sk.b[bfr].angle_vd[1]			= 125;

			//---- z-order -----------------------------------------------------------------------

			set_z_order(22, 22, 21, 21, 20,
						42, 41, 40,
						2, 1, 0,
						33, 32, 31, 30,
						13, 12, 11, 10);
		}
		else
		//right foot forward
		{
			//---- set calculation order ---------------------------------------------------------

			//bone calculation order
			sk.b_order[0] = 1;			sk.b_order[1] = 0;
			sk.b_order[2] = 3;			sk.b_order[3] = 2;

			//---- parent bone, parent bone index ------------------------------------------------
			//only neck changes parent bone to alway front upper torso

			sk.b[bn].p_pb			= &sk.b[btur];
			sk.b[bn].pbi			= btur;

			//---- reference bone, joints and width angle direction ------------------------------

			//reference bone has no parent bone
			//f_aw indicates whether angle of width is angle + 90� (1) or angle - 90� (0)
			sk.p_ref					= &sk.b[btlr];
			sk.b[btlr].p_pbjv			= NULL;					sk.b[btlr].f_aw		= 1;

			sk.b[btll].p_pbjv			= &sk.b[btlr].v.p[3];	sk.b[btll].f_aw		= 1;
			sk.b[btul].p_pbjv			= &sk.b[btur].v.p[3];	sk.b[btul].f_aw		= 1;
			sk.b[btur].p_pbjv			= &sk.b[btlr].v.p[1];	sk.b[btur].f_aw		= 1;
			sk.b[bn].p_pbjv				= &sk.b[btur].v.p[2];	sk.b[bn].f_aw		= 0;

			sk.b[bsl].p_pbjv			= &sk.b[btul].v.p[2];	sk.b[bsl].f_aw		= 0;
			sk.b[baul].p_pbjv			= &sk.b[bsl].v.p[1];	sk.b[baul].f_aw		= 0;
			sk.b[ball].p_pbjv			= &sk.b[baul].v.p[1];	sk.b[ball].f_aw		= 0;

			sk.b[bsr].p_pbjv			= &sk.b[btur].v.p[1];	sk.b[bsr].f_aw		= 1;
			sk.b[baur].p_pbjv			= &sk.b[bsr].v.p[1];	sk.b[baur].f_aw		= 1;
			sk.b[balr].p_pbjv			= &sk.b[baur].v.p[2];	sk.b[balr].f_aw		= 0;

			sk.b[bhl].p_pbjv			= &sk.b[btll].v.p[3];	sk.b[bhl].f_aw		= 1;
			sk.b[blul].p_pbjv			= &sk.b[bhl].v.p[2];	sk.b[blul].f_aw		= 0;
			sk.b[blll].p_pbjv			= &sk.b[blul].v.p[2];	sk.b[blll].f_aw		= 1;
			sk.b[bfl].p_pbjv			= &sk.b[blll].v.p[1];	sk.b[bfl].f_aw		= 0;

			sk.b[bhr].p_pbjv			= &sk.b[btlr].v.p[0];	sk.b[bhr].f_aw		= 0;
			sk.b[blur].p_pbjv			= &sk.b[bhr].v.p[2];	sk.b[blur].f_aw		= 1;
			sk.b[bllr].p_pbjv			= &sk.b[blur].v.p[1];	sk.b[bllr].f_aw		= 1;
			sk.b[bfr].p_pbjv			= &sk.b[bllr].v.p[1];	sk.b[bfr].f_aw		= 0;

			//---- relative bone angle limits ----------------------------------------------------

			sk.b[btll].angle_vd[0]		= 0;		sk.b[btll].angle_vd[1]			= 0;
			sk.b[btlr].angle_vd[0]		= 0;		sk.b[btlr].angle_vd[1]			= 0;
			sk.b[btul].angle_vd[0]		= -125;		sk.b[btul].angle_vd[1]			= 20;
			sk.b[btur].angle_vd[0]		= -125;		sk.b[btur].angle_vd[1]			= 20;
			sk.b[bn].angle_vd[0]		= -90;		sk.b[bn].angle_vd[1]			= 30;

			sk.b[bsl].angle_vd[0]		= -180;		sk.b[bsl].angle_vd[1]			= 180;
			sk.b[baul].angle_vd[0]		= -180;		sk.b[baul].angle_vd[1]			= 180;
			sk.b[ball].angle_vd[0]		= -10;		sk.b[ball].angle_vd[1]			= 180;

			sk.b[bsr].angle_vd[0]		= -180;		sk.b[bsr].angle_vd[1]			= 180;
			sk.b[baur].angle_vd[0]		= -180;		sk.b[baur].angle_vd[1]			= 180;
			sk.b[balr].angle_vd[0]		= -10;		sk.b[balr].angle_vd[1]			= 180;

			sk.b[bhl].angle_vd[0]		= -180;		sk.b[bhl].angle_vd[1]			= 180;
//			sk.b[blul].angle_vd[0]		= -20;		sk.b[blul].angle_vd[1]			= 125;
//			sk.b[blll].angle_vd[0]		= -180;		sk.b[blll].angle_vd[1]			= 10;
			sk.b[blul].angle_vd[0]		= -40;		sk.b[blul].angle_vd[1]			= 125;
			sk.b[blll].angle_vd[0]		= -160;		sk.b[blll].angle_vd[1]			= 10;
			sk.b[bfl].angle_vd[0]		= 0;		sk.b[bfl].angle_vd[1]			= 125;

			sk.b[bhr].angle_vd[0]		= -180;		sk.b[bhr].angle_vd[1]			= 180;
//			sk.b[blur].angle_vd[0]		= -125;		sk.b[blur].angle_vd[1]			= 20;
//			sk.b[bllr].angle_vd[0]		= -180;		sk.b[bllr].angle_vd[1]			= 10;
			sk.b[blur].angle_vd[0]		= -125;		sk.b[blur].angle_vd[1]			= 40;
			sk.b[bllr].angle_vd[0]		= -160;		sk.b[bllr].angle_vd[1]			= 10;
			sk.b[bfr].angle_vd[0]		= 0;		sk.b[bfr].angle_vd[1]			= 125;

			//---- z-order -----------------------------------------------------------------------

			set_z_order(20, 20, 21, 21, 22,
						40, 41, 42,
						0, 1, 2,
						30, 31, 32, 33,
						10, 11, 12, 13);
		}
	}

	//set reference bone x-position to pre-change position
	if (sk.p_ref != NULL)
		sk.p_ref->v.p[0]	= ref_bu;

	//set animation side index
	if (side == SLEFT && stance_feet == SLEFT)			asi		= 0;
	if (side == SLEFT && stance_feet == SRIGHT)			asi		= 1;
	if (side == SRIGHT && stance_feet == SLEFT)			asi		= 2;
	if (side == SRIGHT && stance_feet == SRIGHT)		asi		= 3;

	//set legs to new sides default keyframe to avoid joint limit errors
/*	bool _b[19] = {0, 0, 0, 0, 0,
				   0, 0, 0,
				   0, 0, 0,
				   1, 1, 1, 1,
				   1, 1, 1, 1};*/
//	set_keyframe(AN_STANCE_FEET, 0, 1.0f, _b);
	set_keyframe(AN_STANCE_FEET, 0, 1.0f);

	//cancel all running animations
	al_deactivate_slot(aslot_cycle);
	al_deactivate_slot(aslot_action);
	//!! dritter slot?

	//set last animation to non idle so next first idle animation is fast
	last_anmn[aslot_cycle]	= !AN_IDLE_HI;
	last_anmn[aslot_action]	= !AN_IDLE_LO;
}

//------------------------------------------------------------------------------------------------
//
//	player set_side
//
//	sets player side
//
//------------------------------------------------------------------------------------------------

void player::set_side(int _side)
{
	//if side change (called by master_frame::auto_side_switch())
	if (side != _side)
	{
		//reverse push
		gl_ReversePush();
	}

	side	= _side;
	set_stance(!stance_feet);
}

//------------------------------------------------------------------------------------------------
//
//	player process_bones
//
//	calculates player bones and its shadows according to length, width and angle
//	also calculates player hitboxes including whole player hitbox
//
//------------------------------------------------------------------------------------------------

void player::process_bones(point s_scale, int s_mpy)
{
/*	//angle of second part of torso is always the same as first part
	if (stance_feet == SLEFT)
	{
		sk.b[btlr].angle = sk.b[btll].angle;
		sk.b[btur].angle = sk.b[btul].angle;
	}
	else
	{
		sk.b[btll].angle = sk.b[btlr].angle;
		sk.b[btul].angle = sk.b[btur].angle;
	}*/

	//---- angle in radians ----------------------------------------------------------------------

	//angle in rad (length, width) of every bone
	float	rad_l[19];
	float	rad_w[19];

	//for every bone calculate angle in rad and joint limit
	for (register int i = 0; i < 19; ++i)
	{
		//calculate positive and negative relative angle to parent bone
		//if pointer to parent bone not NULL (lower torso)
		if (sk.b[i].p_pb != NULL)
		{
			//relative angle to parent bone
			float angle_rp = sk.b[i].angle - sk.b[i].p_pb->angle;

			//set relative angle to shortest direction
			if (angle_rp > 180)			angle_rp = -(360 - angle_rp);
			if (angle_rp < -180)		angle_rp += 360;

			//absolute relative angle
			float angle_rp_abs = angle_rp;
			if (angle_rp_abs < 0)	angle_rp_abs = -angle_rp_abs;

			//limit bone joint
			if (angle_rp < sk.b[i].angle_vd[0] ||
				angle_rp > sk.b[i].angle_vd[1])
			{
				if (fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[0])) <
					fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[1])))
					sk.b[i].angle = sk.b[i].p_pb->angle + sk.b[i].angle_vd[0];
				else
					sk.b[i].angle = sk.b[i].p_pb->angle + sk.b[i].angle_vd[1];
			}

			//!!
			//if (stance_feet == SLEFT && i == btlr)		sk.b[btlr].angle = sk.b[btll].angle;
			//if (stance_feet == SLEFT && i == btur)		sk.b[btur].angle = sk.b[btul].angle;
			//if (stance_feet == SRIGHT && i == btll)		sk.b[btll].angle = sk.b[btlr].angle;
			//if (stance_feet == SRIGHT && i == btul)		sk.b[btul].angle = sk.b[btur].angle;
			if (i < bn)
				if (stance_feet == SLEFT)
				{
					sk.b[btlr].angle	= sk.b[btll].angle;
					sk.b[btur].angle	= sk.b[btul].angle;
					//check angle doesn't exceed its limit
					if (sk.b[btlr].angle > 359)		sk.b[btlr].angle -= 360;
					if (sk.b[btlr].angle < 0)		sk.b[btlr].angle += 360;
					if (sk.b[btur].angle > 359)		sk.b[btur].angle -= 360;
					if (sk.b[btur].angle < 0)		sk.b[btur].angle += 360;
					rad_l[btlr] = sk.b[btlr].angle / 180 * PI;
					rad_l[btur] = sk.b[btur].angle / 180 * PI;
					if (sk.b[btlr].f_aw == 0)		rad_w[btlr] = sk.b[btlr].angle - 90;
					else							rad_w[btlr] = sk.b[btlr].angle + 90;
					rad_w[btlr] = rad_w[btlr] / 180 * PI;
					if (sk.b[btur].f_aw == 0)		rad_w[btur] = sk.b[btur].angle - 90;
					else							rad_w[btur] = sk.b[btur].angle + 90;
					rad_w[btur] = rad_w[btur] / 180 * PI;
				}
				else
				{
					sk.b[btll].angle	= sk.b[btlr].angle;
					sk.b[btul].angle	= sk.b[btur].angle;
					if (sk.b[btll].angle > 359)		sk.b[btll].angle -= 360;
					if (sk.b[btll].angle < 0)		sk.b[btll].angle += 360;
					if (sk.b[btul].angle > 359)		sk.b[btul].angle -= 360;
					if (sk.b[btul].angle < 0)		sk.b[btul].angle += 360;
					rad_l[btll] = sk.b[btll].angle / 180 * PI;
					rad_l[btul] = sk.b[btul].angle / 180 * PI;
					if (sk.b[btll].f_aw == 0)		rad_w[btll] = sk.b[btll].angle - 90;
					else							rad_w[btll] = sk.b[btll].angle + 90;
					rad_w[btll] = rad_w[btll] / 180 * PI;
					if (sk.b[btul].f_aw == 0)		rad_w[btul] = sk.b[btul].angle - 90;
					else							rad_w[btul] = sk.b[btul].angle + 90;
					rad_w[btul] = rad_w[btul] / 180 * PI;
				}
		}

		//check angle doesn't exceed its limit
		if (sk.b[i].angle > 359)	sk.b[i].angle -= 360;
		if (sk.b[i].angle < 0)		sk.b[i].angle += 360;

		//length angle
		rad_l[i] = sk.b[i].angle / 180 * PI;

		//width angle according to f_aw flag of bone either angle + 90� or angle - 90�
		if (sk.b[i].f_aw == 0)
			rad_w[i] = sk.b[i].angle - 90;
		else
			rad_w[i] = sk.b[i].angle + 90;

		//check angle doesn't exceed its limit
		if (rad_w[i] > 359)			rad_w[i] -= 360;
		if (rad_w[i] < 0)			rad_w[i] += 360;

		//calculate rad of width angle
		rad_w[i] = rad_w[i] / 180 * PI;
	}

	//---- reference bone ------------------------------------------------------------------------

	//first calculate reference bone
	//(extra rad)
	float rad_lr	= sk.p_ref->angle / 180 * PI;
	float rad_wr;

	if (sk.p_ref->f_aw == 0)
		rad_wr = sk.p_ref->angle - 90;
	else
		rad_wr = sk.p_ref->angle + 90;

	//check angle doesn't exceed its limit
	if (rad_wr > 359)		rad_wr -= 360;
	if (rad_wr < 0)			rad_wr += 360;

	//in radians
	rad_wr = rad_wr / 180 * PI;

	sk.p_ref->v.p[1].x	= sk.p_ref->v.p[0].x + sk.p_ref->length * (float)cos(rad_lr);
	sk.p_ref->v.p[1].y	= sk.p_ref->v.p[0].y + sk.p_ref->length * (float)sin(rad_lr);

	sk.p_ref->v.p[2].x = sk.p_ref->v.p[1].x + sk.p_ref->width * (float)cos(rad_wr);
	sk.p_ref->v.p[2].y = sk.p_ref->v.p[1].y + sk.p_ref->width * (float)sin(rad_wr);

	sk.p_ref->v.p[3].x = sk.p_ref->v.p[0].x + sk.p_ref->width * (float)cos(rad_wr);
	sk.p_ref->v.p[3].y = sk.p_ref->v.p[0].y + sk.p_ref->width * (float)sin(rad_wr);

	//screen boundaries for first vector of reference bone
	if (sk.p_ref->v.p[0].x < S_LBOUND)		sk.p_ref->v.p[0].x = S_LBOUND;
	if (sk.p_ref->v.p[0].x > S_RBOUND)		sk.p_ref->v.p[0].x = S_RBOUND;

	//---- other bones ---------------------------------------------------------------------------

	//first four bones (different order)
	for (i = 0; i < 4; ++i)
	{
		//only if not reference bone
		if (sk.b[sk.b_order[i]].p_pbjv != NULL)
		{
			//first vertex is the vertex of the parent bone to which the
			//p_pbjv pointer of the bone points
			sk.b[sk.b_order[i]].v.p[0] = *sk.b[sk.b_order[i]].p_pbjv;

			//second vertex is along length of bone
			sk.b[sk.b_order[i]].v.p[1].x = sk.b[sk.b_order[i]].v.p[0].x + sk.b[sk.b_order[i]].length * (float)cos(rad_l[sk.b_order[i]]);
			sk.b[sk.b_order[i]].v.p[1].y = sk.b[sk.b_order[i]].v.p[0].y + sk.b[sk.b_order[i]].length * (float)sin(rad_l[sk.b_order[i]]);

			//third vertex is along width of bone starting at vertex 1
			sk.b[sk.b_order[i]].v.p[2].x = sk.b[sk.b_order[i]].v.p[1].x + sk.b[sk.b_order[i]].width * (float)cos(rad_w[sk.b_order[i]]);
			sk.b[sk.b_order[i]].v.p[2].y = sk.b[sk.b_order[i]].v.p[1].y + sk.b[sk.b_order[i]].width * (float)sin(rad_w[sk.b_order[i]]);

			//fourth vertex is along width of bone starting at vertex 0
			sk.b[sk.b_order[i]].v.p[3].x = sk.b[sk.b_order[i]].v.p[0].x + sk.b[sk.b_order[i]].width * (float)cos(rad_w[sk.b_order[i]]);
			sk.b[sk.b_order[i]].v.p[3].y = sk.b[sk.b_order[i]].v.p[0].y + sk.b[sk.b_order[i]].width * (float)sin(rad_w[sk.b_order[i]]);
		}

		//calculate shadows only if option is on
		if (p_option->data.shadows == 1)
		{
			//if distance from mp to bone is greater than zero, mirror points
			if (sk.b[sk.b_order[i]].v.p[0].y <= s_mpy)
				sk.b[sk.b_order[i]].vs.p[0].y = s_mpy + (s_mpy - sk.b[sk.b_order[i]].v.p[0].y) * s_scale.y;
			else
				//else shadowpoint is exactly the same as bone
				sk.b[sk.b_order[i]].vs.p[0].y = sk.b[sk.b_order[i]].v.p[0].y;

			if (sk.b[sk.b_order[i]].v.p[1].y <= s_mpy)
				sk.b[sk.b_order[i]].vs.p[1].y = s_mpy + (s_mpy - sk.b[sk.b_order[i]].v.p[1].y) * s_scale.y;
			else
				sk.b[sk.b_order[i]].vs.p[1].y = sk.b[sk.b_order[i]].v.p[1].y;

			if (sk.b[sk.b_order[i]].v.p[2].y <= s_mpy)
				sk.b[sk.b_order[i]].vs.p[2].y = s_mpy + (s_mpy - sk.b[sk.b_order[i]].v.p[2].y) * s_scale.y;
			else
				sk.b[sk.b_order[i]].vs.p[2].y = sk.b[sk.b_order[i]].v.p[2].y;

			if (sk.b[sk.b_order[i]].v.p[3].y <= s_mpy)
				sk.b[sk.b_order[i]].vs.p[3].y = s_mpy + (s_mpy - sk.b[sk.b_order[i]].v.p[3].y) * s_scale.y;
			else
				sk.b[sk.b_order[i]].vs.p[3].y = sk.b[sk.b_order[i]].v.p[3].y;

			//shift x-coordinates in relation to y-coordinate difference between bone and shadow
			sk.b[sk.b_order[i]].vs.p[0].x	= sk.b[sk.b_order[i]].v.p[0].x + s_scale.x * (float)fabs(sk.b[sk.b_order[i]].v.p[0].y - sk.b[sk.b_order[i]].vs.p[0].y);
			sk.b[sk.b_order[i]].vs.p[1].x	= sk.b[sk.b_order[i]].v.p[1].x + s_scale.x * (float)fabs(sk.b[sk.b_order[i]].v.p[1].y - sk.b[sk.b_order[i]].vs.p[1].y);
			sk.b[sk.b_order[i]].vs.p[2].x	= sk.b[sk.b_order[i]].v.p[2].x + s_scale.x * (float)fabs(sk.b[sk.b_order[i]].v.p[2].y - sk.b[sk.b_order[i]].vs.p[2].y);
			sk.b[sk.b_order[i]].vs.p[3].x	= sk.b[sk.b_order[i]].v.p[3].x + s_scale.x * (float)fabs(sk.b[sk.b_order[i]].v.p[3].y - sk.b[sk.b_order[i]].vs.p[3].y);
		}
	}

	//rest of skeleton
	for (i = 4; i < 19; ++i)
	{
		//first vertex is the vertex of the parent bone to which the
		//p_pbjv pointer of the bone points
		sk.b[i].v.p[0] = *sk.b[i].p_pbjv;

		//second vertex is along length of bone
		sk.b[i].v.p[1].x = sk.b[i].v.p[0].x + sk.b[i].length * (float)cos(rad_l[i]);
		sk.b[i].v.p[1].y = sk.b[i].v.p[0].y + sk.b[i].length * (float)sin(rad_l[i]);

		//third vertex is along width of bone starting at vertex 1
		sk.b[i].v.p[2].x = sk.b[i].v.p[1].x + sk.b[i].width * (float)cos(rad_w[i]);
		sk.b[i].v.p[2].y = sk.b[i].v.p[1].y + sk.b[i].width * (float)sin(rad_w[i]);

		//fourth vertex is along width of bone starting at vertex 0
		sk.b[i].v.p[3].x = sk.b[i].v.p[0].x + sk.b[i].width * (float)cos(rad_w[i]);
		sk.b[i].v.p[3].y = sk.b[i].v.p[0].y + sk.b[i].width * (float)sin(rad_w[i]);

		//calculate shadows only if option is on
		if (p_option->data.shadows == 1)
		{
			//if distance from mp to bone is greater than zero, mirror points
			if (sk.b[i].v.p[0].y <= s_mpy)
				sk.b[i].vs.p[0].y = s_mpy + (s_mpy - sk.b[i].v.p[0].y) * s_scale.y;
			else
				//else shadowpoint is exactly the same as bone
				sk.b[i].vs.p[0].y = sk.b[i].v.p[0].y;

			if (sk.b[i].v.p[1].y <= s_mpy)
				sk.b[i].vs.p[1].y = s_mpy + (s_mpy - sk.b[i].v.p[1].y) * s_scale.y;
			else
				sk.b[i].vs.p[1].y = sk.b[i].v.p[1].y;

			if (sk.b[i].v.p[2].y <= s_mpy)
				sk.b[i].vs.p[2].y = s_mpy + (s_mpy - sk.b[i].v.p[2].y) * s_scale.y;
			else
				sk.b[i].vs.p[2].y = sk.b[i].v.p[2].y;

			if (sk.b[i].v.p[3].y <= s_mpy)
				sk.b[i].vs.p[3].y = s_mpy + (s_mpy - sk.b[i].v.p[3].y) * s_scale.y;
			else
				sk.b[i].vs.p[3].y = sk.b[i].v.p[3].y;

			//shift x-coordinates in relation to y-coordinate difference between bone and shadow
			sk.b[i].vs.p[0].x	= sk.b[i].v.p[0].x + s_scale.x * (float)fabs(sk.b[i].v.p[0].y - sk.b[i].vs.p[0].y);
			sk.b[i].vs.p[1].x	= sk.b[i].v.p[1].x + s_scale.x * (float)fabs(sk.b[i].v.p[1].y - sk.b[i].vs.p[1].y);
			sk.b[i].vs.p[2].x	= sk.b[i].v.p[2].x + s_scale.x * (float)fabs(sk.b[i].v.p[2].y - sk.b[i].vs.p[2].y);
			sk.b[i].vs.p[3].x	= sk.b[i].v.p[3].x + s_scale.x * (float)fabs(sk.b[i].v.p[3].y - sk.b[i].vs.p[3].y);
		}
	}

	//---- head and fist center ------------------------------------------------------------------

	//radi
	sk.radius_fist				= 12 / 2 * p_option->data.zoomfactor;
	sk.radius_head				= (26 / 2 - 1) * p_option->data.zoomfactor;

	//fist left
	//half way on wrist
	sk.cfistl.x	= sk.b[ball].v.p[1].x + (sk.b[ball].width / 2.0f) * (float)cos(rad_w[ball]);
	sk.cfistl.y	= sk.b[ball].v.p[1].y + (sk.b[ball].width / 2.0f) * (float)sin(rad_w[ball]);
	//from there in length of fist radius and angle of bone
	//if length of lower arm positive
	if (sk.b[ball].length >= 0)
	{
		sk.cfistl.x	= sk.cfistl.x + sk.radius_fist * (float)cos(rad_l[ball]);
		sk.cfistl.y	= sk.cfistl.y + sk.radius_fist * (float)sin(rad_l[ball]);
	}
	else
	//length negative
	{
		//fist shows out of arm
//		sk.cfistl.x	= sk.cfistl.x - sk.radius_fist * (float)cos(rad_l[ball]);
//		sk.cfistl.y	= sk.cfistl.y - sk.radius_fist * (float)sin(rad_l[ball]);
		//fist shows into arm
		sk.cfistl.x	= sk.cfistl.x + (sk.radius_fist - 2) * (float)cos(rad_l[ball]);
		sk.cfistl.y	= sk.cfistl.y + (sk.radius_fist - 2) * (float)sin(rad_l[ball]);
	}

	//fist right
	sk.cfistr.x	= sk.b[balr].v.p[1].x + (sk.b[balr].width / 2.0f) * (float)cos(rad_w[balr]);
	sk.cfistr.y	= sk.b[balr].v.p[1].y + (sk.b[balr].width / 2.0f) * (float)sin(rad_w[balr]);
	if (sk.b[balr].length >= 0)
	{
		sk.cfistr.x	= sk.cfistr.x + sk.radius_fist * (float)cos(rad_l[balr]);
		sk.cfistr.y	= sk.cfistr.y + sk.radius_fist * (float)sin(rad_l[balr]);
	}
	else
	{
//		sk.cfistr.x	= sk.cfistr.x - sk.radius_fist * (float)cos(rad_l[balr]);
//		sk.cfistr.y	= sk.cfistr.y - sk.radius_fist * (float)sin(rad_l[balr]);
		sk.cfistr.x	= sk.cfistr.x + (sk.radius_fist - 2) * (float)cos(rad_l[ball]);
		sk.cfistr.y	= sk.cfistr.y + (sk.radius_fist - 2) * (float)sin(rad_l[ball]);
	}

	//head
	sk.chead.x	= sk.b[bn].v.p[1].x + (sk.b[bn].width / 2.0f) * (float)cos(rad_w[bn]);
	sk.chead.y	= sk.b[bn].v.p[1].y + (sk.b[bn].width / 2.0f) * (float)sin(rad_w[bn]);
	sk.chead.x	= sk.chead.x + sk.radius_head * (float)cos(rad_l[bn]);
	sk.chead.y	= sk.chead.y + sk.radius_head * (float)sin(rad_l[bn]);


	//---- hitboxes ------------------------------------------------------------------------------

	//whole player hitbox x and y coordinates including both fist and head
	float hbpx[44];	float hbpy[44];

	//for every bone
	for (i = 0; i < 19; ++i)
	{
		//2 arrays with x/y data of bone which get sorted by the coordinates
		float hbx[4]	= {sk.b[i].v.p[0].x, sk.b[i].v.p[1].x, sk.b[i].v.p[2].x, sk.b[i].v.p[3].x};
		float hby[4]	= {sk.b[i].v.p[0].y, sk.b[i].v.p[1].y, sk.b[i].v.p[2].y, sk.b[i].v.p[3].y};

		//default order sort
		quicksort(hbx, 0, 3);
		quicksort(hby, 0, 3);

		//assign bone hitbox with max/min x/y values
		sk.b[i].hitbox.left		= (long)hbx[0];		sk.b[i].hitbox.right	= (long)hbx[3];
		sk.b[i].hitbox.top		= (long)hby[0];		sk.b[i].hitbox.bottom	= (long)hby[3];

		//take min/max data from already sorted hbx/hby arrays
		//fill array from both sides
		hbpx[i]			= hbx[0];		hbpx[37 - i] = hbx[3];
		hbpy[i]			= hby[0];		hbpy[37 - i] = hby[3];
	}

	//get head/fist hitboxes
	//fist left
	sk.b[ball].hitbox_e.left	= (long)(sk.cfistl.x - sk.radius_fist);
	sk.b[ball].hitbox_e.right	= (long)(sk.cfistl.x + sk.radius_fist);
	sk.b[ball].hitbox_e.top		= (long)(sk.cfistl.y - sk.radius_fist);
	sk.b[ball].hitbox_e.bottom	= (long)(sk.cfistl.y + sk.radius_fist);
	//fist right
	sk.b[balr].hitbox_e.left	= (long)(sk.cfistr.x - sk.radius_fist);
	sk.b[balr].hitbox_e.right	= (long)(sk.cfistr.x + sk.radius_fist);
	sk.b[balr].hitbox_e.top		= (long)(sk.cfistr.y - sk.radius_fist);
	sk.b[balr].hitbox_e.bottom	= (long)(sk.cfistr.y + sk.radius_fist);
	//head
	sk.b[bn].hitbox_e.left		= (long)(sk.chead.x - sk.radius_head);
	sk.b[bn].hitbox_e.right		= (long)(sk.chead.x + sk.radius_head);
	sk.b[bn].hitbox_e.top		= (long)(sk.chead.y - sk.radius_head);
	sk.b[bn].hitbox_e.bottom	= (long)(sk.chead.y + sk.radius_head);

	//add head hitbox to array to be sorted
	hbpx[38]	= (float)sk.b[bn].hitbox_e.left;
	hbpx[39]	= (float)sk.b[bn].hitbox_e.right;
	hbpy[38]	= (float)sk.b[bn].hitbox_e.top;
	hbpy[39]	= (float)sk.b[bn].hitbox_e.bottom;
	//add fists
	hbpx[40]	= (float)sk.b[ball].hitbox_e.left;
	hbpx[41]	= (float)sk.b[ball].hitbox_e.right;
	hbpy[40]	= (float)sk.b[ball].hitbox_e.top;
	hbpy[41]	= (float)sk.b[ball].hitbox_e.bottom;
	hbpx[42]	= (float)sk.b[balr].hitbox_e.left;
	hbpx[43]	= (float)sk.b[balr].hitbox_e.right;
	hbpy[42]	= (float)sk.b[balr].hitbox_e.top;
	hbpy[43]	= (float)sk.b[balr].hitbox_e.bottom;

	//sort player hitbox data
	quicksort(hbpx, 0, 43);
	quicksort(hbpy, 0, 43);

	//assign whole player hitbox
	sk.r_hbp.left				= (long)hbpx[0];	sk.r_hbp.right			= (long)hbpx[43];
	sk.r_hbp.top				= (long)hbpy[0];	sk.r_hbp.bottom			= (long)hbpy[43];

	//---- clipping ------------------------------------------------------------------------------
	//head and fistclipping is done separately in draw function

	//first test whole player hitbox
	if (sk.r_hbp.left	< 0		||
		sk.r_hbp.right	> 799	||
		sk.r_hbp.top	< 0		||
		sk.r_hbp.bottom > 599)
		//clip every bone if hitbox out of screen
		for (i = 0; i < 19; ++i)
		{
			if (sk.b[i].hitbox.left		< 0		||
				sk.b[i].hitbox.right	> 799	||
				sk.b[i].hitbox.top		< 0		||
				sk.b[i].hitbox.bottom	> 599)
			{
				sk.b[i].v.p[0].x < 0	? sk.b[i].v.p[0].x = 0		: sk.b[i].v.p[0].x;
				sk.b[i].v.p[0].x > 799	? sk.b[i].v.p[0].x = 799	: sk.b[i].v.p[0].x;
				sk.b[i].v.p[0].y < 0	? sk.b[i].v.p[0].y = 0		: sk.b[i].v.p[0].y;
				sk.b[i].v.p[0].y > 599	? sk.b[i].v.p[0].y = 599	: sk.b[i].v.p[0].y;

				sk.b[i].v.p[1].x < 0	? sk.b[i].v.p[1].x = 0		: sk.b[i].v.p[1].x;
				sk.b[i].v.p[1].x > 799	? sk.b[i].v.p[1].x = 799	: sk.b[i].v.p[1].x;
				sk.b[i].v.p[1].y < 0	? sk.b[i].v.p[1].y = 0		: sk.b[i].v.p[1].y;
				sk.b[i].v.p[1].y > 599	? sk.b[i].v.p[1].y = 599	: sk.b[i].v.p[1].y;

				sk.b[i].v.p[2].x < 0	? sk.b[i].v.p[2].x = 0		: sk.b[i].v.p[2].x;
				sk.b[i].v.p[2].x > 799	? sk.b[i].v.p[2].x = 799	: sk.b[i].v.p[2].x;
				sk.b[i].v.p[2].y < 0	? sk.b[i].v.p[2].y = 0		: sk.b[i].v.p[2].y;
				sk.b[i].v.p[2].y > 599	? sk.b[i].v.p[2].y = 599	: sk.b[i].v.p[2].y;

				sk.b[i].v.p[3].x < 0	? sk.b[i].v.p[3].x = 0		: sk.b[i].v.p[3].x;
				sk.b[i].v.p[3].x > 799	? sk.b[i].v.p[3].x = 799	: sk.b[i].v.p[3].x;
				sk.b[i].v.p[3].y < 0	? sk.b[i].v.p[3].y = 0		: sk.b[i].v.p[3].y;
				sk.b[i].v.p[3].y > 599	? sk.b[i].v.p[3].y = 599	: sk.b[i].v.p[3].y;
			}
		}

	//shadow clipping
	for (i = 0; i < 19; ++i)
	{
		sk.b[i].vs.p[0].x < 0	? sk.b[i].vs.p[0].x = 0		: sk.b[i].vs.p[0].x;
		sk.b[i].vs.p[0].x > 799	? sk.b[i].vs.p[0].x = 799	: sk.b[i].vs.p[0].x;
		sk.b[i].vs.p[0].y < 0	? sk.b[i].vs.p[0].y = 0		: sk.b[i].vs.p[0].y;
		sk.b[i].vs.p[0].y > 599	? sk.b[i].vs.p[0].y = 599	: sk.b[i].vs.p[0].y;

		sk.b[i].vs.p[1].x < 0	? sk.b[i].vs.p[1].x = 0		: sk.b[i].vs.p[1].x;
		sk.b[i].vs.p[1].x > 799	? sk.b[i].vs.p[1].x = 799	: sk.b[i].vs.p[1].x;
		sk.b[i].vs.p[1].y < 0	? sk.b[i].vs.p[1].y = 0		: sk.b[i].vs.p[1].y;
		sk.b[i].vs.p[1].y > 599	? sk.b[i].vs.p[1].y = 599	: sk.b[i].vs.p[1].y;

		sk.b[i].vs.p[2].x < 0	? sk.b[i].vs.p[2].x = 0		: sk.b[i].vs.p[2].x;
		sk.b[i].vs.p[2].x > 799	? sk.b[i].vs.p[2].x = 799	: sk.b[i].vs.p[2].x;
		sk.b[i].vs.p[2].y < 0	? sk.b[i].vs.p[2].y = 0		: sk.b[i].vs.p[2].y;
		sk.b[i].vs.p[2].y > 599	? sk.b[i].vs.p[2].y = 599	: sk.b[i].vs.p[2].y;

		sk.b[i].vs.p[3].x < 0	? sk.b[i].vs.p[3].x = 0		: sk.b[i].vs.p[3].x;
		sk.b[i].vs.p[3].x > 799	? sk.b[i].vs.p[3].x = 799	: sk.b[i].vs.p[3].x;
		sk.b[i].vs.p[3].y < 0	? sk.b[i].vs.p[3].y = 0		: sk.b[i].vs.p[3].y;
		sk.b[i].vs.p[3].y > 599	? sk.b[i].vs.p[3].y = 599	: sk.b[i].vs.p[3].y;
	}

	//---- sound pan -----------------------------------------------------------------------------

//	s_pan = (int)((sk.p_ref->v.p[0].x * 4) - 1600);
	s_pan = (int)((sk.p_ref->v.p[0].x * 2) - 800);
}

//------------------------------------------------------------------------------------------------
//
//	player al_update_particles
//
//	updates particle heaps
//
//------------------------------------------------------------------------------------------------

void player::al_update_particles(int shadows, point s_scale, int s_mpy, float s_speed, float s_zoom)
{
	//if heap inactive set flag
	if (blood_fx[0].state == 1)			blood_active[0]	= 0;
	if (blood_fx[1].state == 1)			blood_active[1]	= 0;

	//update heap if active
	//for both heap
	for (register int h = 0; h < 2; ++h)
	{
		//if active
		if (blood_active[h] == 1)
		{
			//recalculate heap source
			point	bsource;
			//angle in rad
			float	angle_h_rad = blood_angle_h[h] / 180 * PI;
			bsource.x			= sk.chead.x + sk.radius_head * (float)(cos(angle_h_rad));
			bsource.y			= sk.chead.y + sk.radius_head * (float)(sin(angle_h_rad));

			//update heap
			blood_fx[h].update(p_time->current,							//current time
							   p_time->sca,								//time passed since last update
							   p_option->data.speed,					//user set speedfactor
							   p_option->data.shadows, s_mpy, s_scale,	//shadow on/off, shadow data
							   (int)bsource.x, (int)bsource.y,			//source of particles
							   (int)blood_angle[h].x,					//angle min and max
							   (int)blood_angle[h].y,
							   true);									//bottom
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player quicksort
//
//	sorts a given array of float data
//	either from lowest to largest value (order = 0)
//	or from largest to lowest (order = 1)
//
//------------------------------------------------------------------------------------------------

void player::quicksort(float data[],			//array with data
					   int l,					//always 0, left border index of array
					   int r,					//right border index of array (including 0)
					   int order)				//0 = lowest to largest (def), 1 = largest to lowest
{
	//if right index is larger than left index
	if(r > l)
	{
		//
		int lg = l + 1, rg = r;
		
		float tempdata;
		float key = data[l];

		//infinite loop
		for(; ;)
		{
			//if to sort from lowest to largest
			if (order == 0)
			{
				while (data[lg] <= key && lg < r)
					++lg;

				while (data[rg] >= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}
			else
			//if to sort from largest to lowest
			{
				while (data[lg] >= key && lg < r)
					++lg;

				while (data[rg] <= key && rg > l)
					--rg;

				if (lg >= rg)
					break;
			}

			tempdata	= data[lg];
			data[lg]	= data[rg];
			data[rg]	= tempdata;
		}

		tempdata	= data[rg];
		data[rg]	= data[l];
		data[l]		= tempdata;

		//recursive call of quicksort
		quicksort(data, l, rg - 1, order);
		quicksort(data, rg + 1, r, order);
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_set_speedfactor
//
//  sets speedfactor of animation indicated by asi and argument player_action
//
//------------------------------------------------------------------------------------------------

void player::gl_set_speedfactor(int slot)
{
	//slot valid
	if (p_aslot[slot] == NULL)
		return;

	//speefactor (cumulative for fatigue and damage)
	float sf	= 0;

	//if fatigue has affect on animation speed
	if (p_aslot[slot]->gl_eff_fat_speed >= 1)
	{
		//adjust speedfactor using animations effiency factor
		sf += (fatigue / 100.0f) / p_aslot[slot]->gl_eff_fat_speed;
	}

	//for all bones
	for (register int i = 0; i < 19; ++i)
	{
		//if damage of bone has affect on animation
		if (p_aslot[slot]->gl_eff_dam_speed[i] >= 1.0f)
			//adjust speedfactor using bones effiency factor
			sf += (sk.b[i].damage / 100.0f) / p_aslot[slot]->gl_eff_dam_speed[i];
	}

	//assign to speedfactor in animation
	p_aslot[slot]->speedfactor[id] = 1.0f + sf;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_set_cd_state
//
//  sets cd_state of bones according to data of animation with higher priority
//
//------------------------------------------------------------------------------------------------

void player::gl_set_cd_state()
{

	//gets called after set_priority and simply sets cd_state of all bones
	//to gl_bcds_def state specified in the animation of the animation slot the
	//bone is assigned to
	for (register int b = 0; b < 19; ++b)
		sk.b[b].cd_state = p_aslot[casi[b]]->gl_bcds_def[b];

	return;

/*	//---- both slots active ---------------------------------------------------------------------

	if (p_aslot[aslot_cycle] != NULL &&
		p_aslot[aslot_action] != NULL)
	{
		//for every bone
		for (register int b = 0; b < 19; ++b)
			//if priority of bone in slot 0 is bigger than priority of bone in slot 1
			if (p_aslot[aslot_cycle]->priority[b] > p_aslot[aslot_action]->priority[b])
				//set cd_state of bone to data of animation in slot 0
				sk.b[b].cd_state = p_aslot[aslot_cycle]->gl_bcds_def[b];
			else
				//set cd_state of bone to data of animation in slot 1
				sk.b[b].cd_state = p_aslot[aslot_action]->gl_bcds_def[b];

		return;
	}

	//---- only one slot active ------------------------------------------------------------------

	//cycle slot active
	if (p_aslot[aslot_cycle] != NULL)
	{
		//for every bone
		for (register int b = 0; b < 19; ++b)
			//set cd_state of bone to data of animation in slot 0
			sk.b[b].cd_state = p_aslot[aslot_cycle]->gl_bcds_def[b];

		return;
	}

	//action slot active
	if (p_aslot[aslot_action] != NULL)
	{
		//for every bone
		for (register int b = 0; b < 19; ++b)
			//set cd_state of bone to data of animation in slot 0
			sk.b[b].cd_state = p_aslot[aslot_action]->gl_bcds_def[b];

		return;
	}*/
}

//------------------------------------------------------------------------------------------------
//
//	player gl_fatigue_add
//
//	sets target fatigue (cumulative)
//
//------------------------------------------------------------------------------------------------

void player::gl_fatigue_add(int slot, int type, float instant)
{
	//if instant valid, apply valid and return
	if (instant > 0)
	{
		//adjust instant fatigue value to regeneration value
		//so that effective fatigue is instant value
//		instant	+= skill_freg_ad / ((float)SKILL_FAPP / instant);
		//!! warum hier multiplier?
//		fatigue_buff += instant * p_option->data.fom_multiplier;
		fatigue_buff += instant;
		return;
	}

	//return if slot invalid
	if (p_aslot[slot] == NULL)
		return;

	//if already applied return
	if (p_aslot[slot]->gl_fat[id])
		return;

	//set animation fat state to fatigue applied
	p_aslot[slot]->gl_fat[id] = 1;

/*	//standard fatigue
	//adjust fatigue of animation to user set fatigue multiplier
	if (type == 0)
		fatigue_buff += skill_freg_ad / ((float)SKILL_FAPP / (p_aslot[slot]->gl_fatigue * p_option->data.fom_multiplier)) + (p_aslot[slot]->gl_fatigue * p_option->data.fom_multiplier);
	//cancel fatigue
	if (type == 1)
		fatigue_buff += skill_freg_ad / ((float)SKILL_FAPP / (p_aslot[slot]->gl_fatigue_cancel * p_option->data.fom_multiplier)) + (p_aslot[slot]->gl_fatigue_cancel * p_option->data.fom_multiplier);
	//air attack, increase fatigue
	if (type == 2)
		fatigue_buff += skill_freg_ad / ((float)SKILL_FAPP / (p_aslot[slot]->gl_fatigue * 1.5f * p_option->data.fom_multiplier)) + (p_aslot[slot]->gl_fatigue * 1.5f * p_option->data.fom_multiplier);*/

	//fatigue delay
	if (fatigue <= 5)
	{
		//standard fatigue
		if (type == 0)
			fatigue_delay += p_aslot[slot]->gl_fatigue * p_option->data.fom_multiplier;
		//cancel fatigue
		if (type == 1)
			fatigue_delay += p_aslot[slot]->gl_fatigue_cancel * p_option->data.fom_multiplier;
		//air attack, increase fatigue
		if (type == 2)
			fatigue_delay += p_aslot[slot]->gl_fatigue * 1.5f * p_option->data.fom_multiplier;
		//power attack, increase fatigue
		if (type == 3)
			fatigue_delay += p_aslot[slot]->gl_fatigue * 2.5f * p_option->data.fom_multiplier;

		//if fatigue applied and start time not already set
		if (fatigue_delay && !t_fat_delay_start)
			t_fat_delay_start	= p_time->current;
	}
	else
	{
		//standard fatigue
		if (type == 0)
			fatigue_buff += p_aslot[slot]->gl_fatigue * p_option->data.fom_multiplier;
		//cancel fatigue
		if (type == 1)
			fatigue_buff += p_aslot[slot]->gl_fatigue_cancel * p_option->data.fom_multiplier;
		//air attack, increase fatigue
		if (type == 2)
			fatigue_buff += p_aslot[slot]->gl_fatigue * 1.5f * p_option->data.fom_multiplier;
		//power attack, increase fatigue
		if (type == 3)
			fatigue_buff += p_aslot[slot]->gl_fatigue * 2.5f * p_option->data.fom_multiplier;
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_fatigue_interpolator
//
//  interpolates between current and targeted fatigue
//	also applies fatigue regeneration
//
//------------------------------------------------------------------------------------------------

void player::gl_fatigue_interpolator()
{
	//---- cheats --------------------------------------------------------------------------------

	if (gProgramOptions.xfatigue[id])
	{
		fatigue			= 0;
		fatigue_buff	= 0;
		return;
	}

	//---- efficiency ----------------------------------------------------------------------------

	//fatigue regeneration speed
	//adjusted to handicap
	skill_freg_ad = SKILL_FREG * p_option->data.fat_handicap[id];
	//effected by damage on head/neck
	skill_freg_ad -= SKILL_FREG * (sk.damage[DS_hn] / 100.0f / 4.0f);
	//also effected by total damage of torso
	float torso_damage = (sk.damage[DS_tll] + sk.damage[DS_tlr] + sk.damage[DS_tul] + sk.damage[DS_tur]) / 4.0f;
	skill_freg_ad -= SKILL_FREG * (torso_damage / 100.0f / 4.0f);

	//regeneration increased the lower the arm stance
	//quadratic?
	skill_freg_ad	+= SKILL_FREG * (0.25f - (stance_arms * stance_arms * 0.000025f));
	//stance_arms 100	+ 0% of SKILL_FREG
	//stance_arms 0		+ 0.25%
//	skill_freg_ad	+= SKILL_FREG * (0.25f - (stance_arms / 400.0f));

	//if (stance_arms <= 40)
	//	skill_freg_ad += SKILL_FREG * 0.25f;
	//max regeneration
	if (skill_freg_ad > SKILL_FREG * p_option->data.fat_handicap[id])
		skill_freg_ad	= SKILL_FREG * p_option->data.fat_handicap[id];

	/*char cb[7] = {0};
	sprintf(cb, "%.2f", (float)skill_freg_ad);
	sprintf(cb, "%i", (int)fatigue);
	pmessage.set_message(cb, 0, 0, 0, 0, 0, 255, 0.35f, 0.1f / p_option->data.speed, p_time->current);*/

	//---- interpolate ---------------------------------------------------------------------------

	//set t_sca_sf depending on subframes
	t_sca_sf	= (float)(p_time->sca / p_option->data.subframes);

/*	//instant style
	//as long as fatigue buffer not empty
	if (fatigue_buff)
	{
		//empty fatigue buffer into fatigue until fatigue full
		if (fatigue + fatigue_buff <= 100)
		{
			fatigue			+= fatigue_buff;
			fatigue_buff	= 0;
		}
		else
		{
			fatigue_buff	-= (100 - fatigue);
			fatigue			+= (100 - fatigue);
		}

		//check fatigue buffer for limits
		if (fatigue_buff > 100)		fatigue_buff = 100;
	}*/

	//if start time valid
	if (t_fat_delay_start)
	{
		//if p_option->data.fat_delay time passed
		if (p_time->current >= t_fat_delay_start + (p_option->data.fat_delay / p_option->data.speed) * p_time->freq)
		{
			//add fatigue delay buffer to fatigue buffer
			fatigue_buff		+= fatigue_delay;
			fatigue_delay		= 0;
			//reset start time
			t_fat_delay_start	= 0;
		}
	}

	//slow style
	//as long as fatigue buffer not empty
	if (fatigue_buff)
	{
		//empty fatigue buffer into fatigue
		if (fatigue_buff - SKILL_FAPP * t_sca_sf * p_option->data.speed >= 0)
		{
			fatigue			+= SKILL_FAPP * t_sca_sf * p_option->data.speed;
			fatigue_buff	-= SKILL_FAPP * t_sca_sf * p_option->data.speed;
		}
		else
		{
			fatigue			+= fatigue_buff;
			fatigue_buff	-= fatigue_buff;
		}
/*
//!!
//fatigue_buff += skill_freg_ad * t_sca_sf * p_option->data.speed;

		//empty fatigue buffer into fatigue
		//if fatigue from fatigue buffer to apply with apply speed doesn't empty fatigue buffer
		if (fatigue_buff - SKILL_FAPP * t_sca_sf * p_option->data.speed >= 0)
		{
			//if fatigue to apply doesn't exceed fatigue limit
			if (fatigue + SKILL_FAPP * t_sca_sf * p_option->data.speed <= 100)
			{
				fatigue			+= SKILL_FAPP * t_sca_sf * p_option->data.speed;
				fatigue_buff	-= SKILL_FAPP * t_sca_sf * p_option->data.speed;
			}
			else
			//only apply valid difference
			{
				fatigue_buff	-= (100 - fatigue);
				fatigue			+= (100 - fatigue);
			}
		}
		else
		//if fatigue from fatigue buffer to apply with apply speed empties fatigue buffer
		{
			if (fatigue + fatigue_buff <= 100)
			{
				fatigue			+= fatigue_buff;
				fatigue_buff	-= fatigue_buff;
			}
			else
			{
				fatigue_buff	-= (100 - fatigue);
				fatigue			+= (100 - fatigue);
			}
		}*/

		//check fatigue buffer for limits
		if (fatigue_buff > 100)		fatigue_buff = 100;
	}

	//---- fatigue damage ------------------------------------------------------------------------
	//if full fatigue add damage to head in units per second

	//if option on
	if (p_option->data.fat_dam)
		//polled once a second (adjusted to game speed)
		if ((int)fatigue == 100 && t_fatdam_last + (p_time->freq * 1.0f / p_option->data.speed) <= p_time->current)
		{
			//update last poll time
			t_fatdam_last		= p_time->current;

			//apply damage
			int dummy_defbi				= -1;
			float dummy_t_move[2][2]	= {0};
			gl_process_damage_def(bhead, (float)p_option->data.fat_damage * p_option->data.damage_multiplier, dummy_defbi, dummy_t_move, false, true);

			//damage message (in gl_process_damage_def())
//			pmessage.set_message("FAT DAMAGE! -%i", 0, 0, 0, 50, 50, 255, 0.35f, 0.8f / p_option->data.speed, p_time->current);
//			pmessage.set_message(0, 0, 0, 50, 50, 255, 0.35f, 0.8f / p_option->data.speed, p_time->current,
//								 "FAT DAMAGE +%i", p_option->data.fat_damage);

			//bone flash
			p_rcd->time[id][bhead]	= p_time->current;

//!! manual
/*			if (sk.b[bn].damage < 100)
			{
				//!! applied damage
				//damage message
				//char cb[6] = {0};
				//sprintf(cb, "%i", -FAT_DAMAGE);
				//pmessage.set_message(cb, 0, 0, 0, 255, 255, 255, 0.35f, 0.8f / p_option->data.speed, p_time->current);
				pmessage.set_message("FAT DAMAGE!", 0, 0, 0, 50, 50, 255, 0.35f, 0.8f / p_option->data.speed, p_time->current);

				//apply damage
				sk.b[bn].damage		+= p_option->data.fat_damage;
				if (sk.b[bn].damage > 100)
					sk.b[bn].damage	= 100;
				sk.damage[DS_hn]	= sk.b[bn].damage;

				//bone flash
				sk.b[bn].hit_state_e	= hs_hit;
				p_rcd->time[id][bhead]	= p_time->current;

				//sound
				s_buffer[S_HIT_TAP]	= SB_PLAY;
			}*/
		}

	//---- regeneration --------------------------------------------------------------------------

	//as long as fatigue not 0
	if (fatigue)
//!!!
//		if (!fatigue_buff)
		fatigue -= skill_freg_ad * t_sca_sf * p_option->data.speed;

	//check fatigue for limits
	if (fatigue > 100)		fatigue = 100;
	if (fatigue < 0)		fatigue = 0;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_process_damage_def
//
//  calculates and applies damage taken by opponent to
//	damage slot to which argumented bone belongs
//
//------------------------------------------------------------------------------------------------

void player::gl_process_damage_def(int _bone, float _dam, int &_defbi, float t_move[2][2],
								   bool retdamage,
								   bool fatdamage)
{
	if (p_option->data.digidamage)
	{
//		return;
	}

	//holds sound type id
	int sound_id	= 0;

	//---- bone hit state ------------------------------------------------------------------------

	//true when bone in defense mode
	//for use to not apply defpart bonus to same bone when in defense
	bool def = false;

	if (_bone == bhead)
		if (sk.b[bn].cd_state == cds_def)
		{
			sk.b[bn].hit_state_e	= hs_hitdef;
			def						= true;
		}
		else
			sk.b[bn].hit_state_e	= hs_hit;
	if (_bone == bfistl)
		if (sk.b[ball].cd_state == cds_def)
		{
			sk.b[ball].hit_state_e	= hs_hitdef;
			def						= true;
		}
		else
			sk.b[ball].hit_state_e	= hs_hit;
	if (_bone == bfistr)
		if (sk.b[balr].cd_state == cds_def)
		{
			sk.b[balr].hit_state_e	= hs_hitdef;
			def						= true;
		}
		else
			sk.b[balr].hit_state_e	= hs_hit;
	if (_bone != bhead && _bone != bfistl && _bone != bfistr)
		if (sk.b[_bone].cd_state == cds_def)
		{
			sk.b[_bone].hit_state	= hs_hitdef;
			def						= true;
		}
		else
			sk.b[_bone].hit_state	= hs_hit;

	//damage taken is return damage from tapped attack
	if (retdamage)
	{
		//set sound type id if not already set
		if (sound_id == 0)			sound_id	= S_HIT_RET;

		if (_bone == bhead)			sk.b[bn].hit_state_e	= hs_hitret;
		if (_bone == bfistl)		sk.b[ball].hit_state_e	= hs_hitret;
		if (_bone == bfistr)		sk.b[balr].hit_state_e	= hs_hitret;
		if (_bone != bhead && _bone != bfistl && _bone != bfistr)
			sk.b[_bone].hit_state	= hs_hitret;
	}

	//---- defense bonus -------------------------------------------------------------------------

	//true if defense bonus
	bool defbonus = false;

//!!
//hooks
//if (false)
{
	dev_i = _defbi;
	//if defense bonus applied reduce damage
	//_defbi is the index of the bone which was hit in cds_defpart mode
	//(and hit bone not in defense state, happens when arm still in defpart mode
	//and defpart bonus registered and changes to defense while still hit)
	if (_defbi != -1 && !def && !retdamage && !fatdamage)
	{
		//set sound type id if not already set
		if (sound_id == 0)			sound_id	= S_HIT_DPART;

		//set defbonus flag true
		defbonus		= true;

		/*/test
		_defbi	= -1;
		_dam	-= _dam * 0.5f;
		//set bone to hit state to reduced hit
		if (_bone == bhead)				sk.b[bn].hit_state_e	= hs_hitred;
		if (_bone == bfistl)			sk.b[ball].hit_state_e	= hs_hitred;
		if (_bone == bfistr)			sk.b[balr].hit_state_e	= hs_hitred;
		if (_bone != bhead && _bone != bfistl && _bone != bfistr)
			sk.b[_bone].hit_state = hs_hitred;*/

		//slot to take defense value from
		int		_slot = 0;

		if (p_aslot[aslot_cycle] == NULL &&
			p_aslot[aslot_action] == NULL)
		{
			//only reset defbonus (reference)
			_defbi = -1;
		}
		else
		{
			//always prefer action slot
			if (p_aslot[aslot_action] == NULL)			_slot = aslot_cycle;
			else										_slot = aslot_action;

			//holds reduced damage, initialized with defend efficiency of animation
			float _damreduce = (float)p_aslot[_slot]->gl_defend;

			//defend efficiency gets reduced by damage of the bone with cds_defpart (_defbi)
			//linear reduced in efficiency for each damage point
//			_damreduce	-= p_aslot[_slot]->gl_defend * (sk.b[_defbi].damage / 100.0f / 1.0f);
			_damreduce	-= p_aslot[_slot]->gl_defend * (sk.b[_defbi].damage / 100.0f);

			//if no damage bonus, reset defbonus flag and sound id
			if (_damreduce <= 0)
			{
				sound_id	= 0;
				defbonus	= false;
				//reset defense bonus
				_defbi		= -1;
			}
			else
			{
				//reduce damage
				_dam		-= _dam / 100.0f * _damreduce;

				//reset defbonus
				_defbi = -1;

				//set bone to hit state to reduced hit
				if (_bone == bhead)				sk.b[bn].hit_state_e	= hs_hitred;
				if (_bone == bfistl)			sk.b[ball].hit_state_e	= hs_hitred;
				if (_bone == bfistr)			sk.b[balr].hit_state_e	= hs_hitred;
				if (_bone != bhead && _bone != bfistl && _bone != bfistr)
					sk.b[_bone].hit_state = hs_hitred;
			}
		}
	}
}

	//--------------------------------------------------------------------------------------------

	//set true if bone hit is an extension (head, fist)
	int	b_ext	= 0;

	//head, fistl, fistr
	if (_bone == bfistl)	{	_bone = ball;	b_ext = 1; }
	if (_bone == bfistr)	{	_bone = balr;	b_ext = 1; }
	if (_bone == bhead)		{	_bone = bn;		b_ext = 1; }

	float	dam_basic			= _dam;			//basic damage (already reduced by defense bonus)
	float	dam_final			= dam_basic;	//final damage which gets applied
	int		dam_applied			= 0;			//damage applied, standard final, but if
												//max bone damage (100) exceeded, dam applied
												//holds remaining damage
	int		dam_cumulative		= 0;			//all applied damage, including transfer damage

	//---- movement ------------------------------------------------------------------------------
	//forward movement increases damage
	//backward movement decreases damage

	//maximum time factor, adjusted to user set speed
	//float	t_eff = 0.5f * p_option->data.speed;
	//holds adjusted move time
	//float	mtime[2];

	//not for fatigue damage
	if (!fatdamage)
	{
		//forward movement gives malus
		if (t_move[id][1] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
		{
			//maximum of t_eff seconds
			//if (t_move[id][1] > t_eff)		mtime[1] = t_eff;
			//else							mtime[1] = t_move[id][1];

			//1/3 of basic damage
			//dam_final		+= dam_basic / t_eff * mtime[1] / 3.0f;
			dam_final		+= dam_basic * 0.2f;
		}

		//backward movement gives bonus
		if (t_move[id][0] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
		{
			//if (t_move[id][0] > t_eff)		mtime[0] = t_eff;
			//else							mtime[0] = t_move[id][0];

			//1/3 of basic damage
			//dam_final		-= dam_basic / t_eff * mtime[0] / 3.0f;
			dam_final		-= dam_basic * 0.3f;
		}
	}

	//---- jkd bonus -----------------------------------------------------------------------------

	//bullshit
	/*/if right foot forward and no cross/cross hook
	if (stance_feet == SRIGHT)
		//apply bonus if no fatigue
		if (fatigue == 0)
			dam_final	-= dam_basic * 0.2f;
		else
			dam_final	-= dam_basic * 0.1f;*/

	//---- evading -------------------------------------------------------------------------------
	//if player evading while beeing hit he gets additional defense bonus

	//true if evading (for damage message color)
	bool defevade = false;

	//not for fatigue damage
	if (!fatdamage)
	{
		if (p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_DUCK] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI_HOLD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO_HOLD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_DUCK_HOLD])
		{
			//set evade flag
			defevade		= true;

			//set sound type id if not already set
			if (sound_id == 0)			sound_id	= S_HIT_DPART;

			//20% of final damage
			dam_final		-= dam_basic * 0.2f;
		}
	}

	//---- defense state -------------------------------------------------------------------------
	//applied to final damage, not basic damage
	//gl_defend is percentage of damage blocked
	//may get reduced by gl_eff_dam_off and
	//fatigue (gl_eff_fat_off)

	//true if defense and locked
	bool deflock		= false;

	//not for fatigue damage
	if (!fatdamage)
	{
		//if bone hit in defence state
		if (sk.b[_bone].cd_state == cds_def)
		{
			//if limb (to which _bone belongs) not def_locked, no damage
			if (!gl_lock.get_lockstate(_bone))
			{
	//			if (p_option->data.show_damage)
	//				pmessage.set_message("X", 0, 0, 0, 0, 255, 0, 0.40f, 0.8f / p_option->data.speed, p_time->current);

				//bruce lee sound, only if lockdef time set, else it gets annoying
				if (p_option->data.t_lockdef >= 0.1f)
					s_set_sound(S_UHU);

				return;
			}
			else
				//opponents attack is power attack
				if (p_opp->p_aslot[aslot_action] != NULL)
					if (p_opp->p_aslot[aslot_action]->power_attack[!id] == 1)
					{
	//					if (p_option->data.show_damage)
	//						pmessage.set_message("X", 0, 0, 0, 0, 255, 0, 0.40f, 0.8f / p_option->data.speed, p_time->current);
						return;
					}

			//if limb def locked
			if (gl_lock.get_lockstate(_bone))
			{
				//don't unlock
	/*			//unlock because of successful tap
				//default arms (both get locked anyway)
				int lindex	= 0;
				if (_bone == bhl ||	_bone == blul || _bone == blll || _bone == bfl)
				{
					lindex	= 2;
				}
				if (_bone == bhr ||	_bone == blur || _bone == bllr || _bone == bfr)
				{
					lindex	= 3;
				}
				gl_lock.set_lockstate(DEFENSIVE, lindex, 0, OFF, 0, 0);*/

				//but push back
				gl_SetPush(1, 0.1f, 0);
			}

			//for damage message color
			deflock					= true;

			//set sound type id if not already set
			if (sound_id == 0)			sound_id	= S_HIT_TAP;

			//slot valid
			if (p_aslot[aslot_action] != NULL)
			{
				//set defense flag to registered
				//!! nicht mehr aktuell
				//p_aslot[aslot_action]->gl_def[id] = 1;

				//holds adjusted defense value of animation
				float _defend	= (float)p_aslot[aslot_action]->gl_defend;

				//for all bones
				for (register int i = 0; i < 19; ++i)
					//if damage on this bone affects defense efficiency
					if (p_aslot[aslot_action]->gl_eff_dam_off[i] >= 1.0f)
						//decrease defend efficiency
						_defend		-= p_aslot[aslot_action]->gl_defend * (sk.b[i].damage / 100.0f / p_aslot[aslot_action]->gl_eff_dam_off[i]);

				//if fatigue effects defense
				if (p_aslot[aslot_action]->gl_eff_fat_off >= 1.0f)
					_defend	-= (float)p_aslot[aslot_action]->gl_defend * (fatigue / 100.0f / p_aslot[aslot_action]->gl_eff_fat_off);

				//final damage value
				dam_final	-= dam_final / 100.0f * _defend;

				//if guarding
				if (p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_ARMS] ||
					p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_LEGS])
				{
					dam_final	*= 0.5f;
				}

				//test
				//dam_final	-= dam_final * 0.5f;
			}
		}
	}

	//---- high fatigue malus --------------------------------------------------------------------

	//hit bone not in defense state and no return damage
	if (!def && !retdamage && !fatdamage)
	{
		//increase final damage depending on fatigue
		//up to 20%
		dam_final += (dam_final / p_option->data.damage_multiplier) * (fatigue / 100 * 0.2f);
	}

	//---- foot bonus ----------------------------------------------------------------------------
	//if bone hit is foot, reduce damage

//	if (_bone == bfl || _bone == bfr)
//	{
//		dam_final = dam_final * 0.5f;
//	}

	//---- cancel power attack -------------------------------------------------------------------
	//if damage exceeds value cancel power attacks

	if (dam_final >= 15 * p_option->data.damage_multiplier)
		power_attack[0]	= power_attack[1]	= 0;

	//---- save final damage ---------------------------------------------------------------------
	//save received damage in opponent

	if (!fatdamage)
		p_opp->damage_dealt_last	= (int)dam_final;

	//---- combo ---------------------------------------------------------------------------------

	//if pure hit
	if (!retdamage &&
		!fatdamage &&
		!defbonus &&
		!defevade &&
		!deflock)
	{
		//if time passed since last hit <= t_combo
		if ((float)(p_time->current - t_combo_lasthit) / p_time->freq <= p_option->data.t_combo / p_option->data.speed)
		{
			//increase combo counter
			++combo_counter;
			//increase final damage
			dam_final		*= p_option->data.combo_multiplier;
			//add damage to combo damage
			combo_damage	+= (int)dam_final;
		}
		else
		{
			//save last damage
			combo_damage	= (int)dam_final;
			//reset combo counter
			combo_counter	= 0;
		}

		//save current time as last hit time
		t_combo_lasthit	= p_time->current;
	}
	else
	{
		//reset last hit time
		t_combo_lasthit	= 0;
		//reset combo counter
		combo_counter	= 0;
		//reset combo damage
		combo_damage	= 0;
	}

	//---- damage transfer -----------------------------------------------------------------------
	//transfer damage to next damage slot if full

	//update head/neck damage slot transfer index depending on asi
	if (asi == 0 || asi == 2)		dst_index[DS_hn][0]		= DS_tul;
	else							dst_index[DS_hn][0]		= DS_tur;

	//holds damage to apply
	int dam			= (int)dam_final;
	//(current) damage slot which gets damage
	int ds			= sk.b[_bone].d_slot;
	//last damage slot
//		int last_ds		= -1;
	//loop condition
//		bool cont		= false;
	//percentage of damage to apply if transferdamage
	float dp		= 0.75f;

	//apply damage to damage slot, save applied damage
	dam_applied		= gl_apply_damage(ds, &dam, true);
	//add to cumulative damage
	dam_cumulative	= dam_applied;

	//if transfer option ON
	if (p_option->data.dam_transfer)
	{
		//for all transfer slots if slot valid and damage remaining
		//apply remaining damage, get applied damage
		for (register int t = 0; t < 5 && dst_index[ds][t] != -1 && dam > 0; ++t)
		{
			//reduce damage for each transfer
			dam				= (int)(dam * dp);
			dam_applied		= gl_apply_damage(dst_index[ds][t], &dam);
			//add to cumulative damage
			dam_cumulative	+= dam_applied;
		}
	}

/*		while(cont)
		{
		//for all transfer slots (if valid)
		//apply remaining damage, get remaining damage
		for (register int t = 0; t < 5 && dst_index[ds][t] != -1; ++t)
		{
			dam		= gl_apply_damage(dst_index[ds][t], (int)(dam * 0.75f));
		}
		//get last valid transfer index
		if (t > 0)
			--t;

		//if still damage remains
		if (dam)
		{
			//if last damage slot is not new damage slot
			if (last_ds != dst_index[ds][t])
			{
				//current ds is last ds
				//set new damage slot
				last_ds		= ds;
				ds			= dst_index[ds][t];
			}
			else
			{
				//exit loop
				dam		= 0;
				cont	= false;
			}
		}
		else
		{
			//exit loop
			dam		= 0;
			cont	= false;
		}
	}*/

	//---- apply damage --------------------------------------------------------------------------

	//for all damage slots
	for (register int dsl = 0; dsl < NODS; ++dsl)
	{
		//for all bones
		for (register int b = 0; b < 19; ++b)
		{
			//if bone belongs to current damage slot
			if (sk.b[b].d_slot == dsl)
				//copy damage of damage slot to bone
				sk.b[b].damage = sk.damage[dsl];
		}
	}

/*	//for all bones
	for (register int b = 0; b < 19; ++b)
	{
		//if bone belongs to the same damage slot as argumented bone
		if (sk.b[b].d_slot == sk.b[_bone].d_slot)
		{
			//get applied damage
			if (sk.b[_bone].damage + (int)dam_final > 100)
				dam_applied		= (float)(100 - sk.b[_bone].damage);
			else
				dam_applied		= dam_final;

			//apply damage (includes argumented bone)
			sk.b[b].damage += (int)dam_final;

			//check damage limits
			if (sk.b[b].damage < 0)			sk.b[b].damage = 0;
			if (sk.b[b].damage > 100)		sk.b[b].damage = 100;
		}

		//set damage slot damage in skeleton
		sk.damage[sk.b[_bone].d_slot] = sk.b[_bone].damage;
	}*/

	//---- display damage ------------------------------------------------------------------------

	if (p_option->data.show_damage)
	{
		//damage to display, color
		RGBcolor dam_color(red);

		//return damage
		if (retdamage)
			if (!p_option->data.bw_mode)			dam_color.setcolor(pink);
			else									dam_color.setcolor(pink);
		//reduced damage or evading damage
		if (defbonus || defevade)
//			if (!p_option->data.bw_mode)			dam_color.setcolor(hsc_hitred);
//			else									dam_color.setcolor(hscbw_hitred);
			if (!p_option->data.bw_mode)			dam_color.setcolor(orange);
			else									dam_color.setcolor(orange);
		//defense damage
		if (deflock)
			if (!p_option->data.bw_mode)			dam_color.setcolor(yellow);
			else									dam_color.setcolor(yellow);

		//no damage
		if ((int)dam_final == 0)
			dam_color.setcolor(green);
		else
			//no damage applied and not defense bonus, evading or defense lock
			if (dam_cumulative == 0 && !defbonus && !defevade && !deflock)
			{
				dam_color.setcolor(white);

				//set flash color to black/blue
				if (_bone == bn && b_ext)		sk.b[bn].hit_state_e	= hs_hitret;
				if (_bone == ball && b_ext)		sk.b[ball].hit_state_e	= hs_hitret;
				if (_bone == balr && b_ext)		sk.b[balr].hit_state_e	= hs_hitret;
				if (!b_ext)						sk.b[_bone].hit_state	= hs_hitret;
			}

		//if combo active
		if (combo_counter)
		{
			pmessage.set_message(PM_COMBO, red, "%i Hits -%i", combo_counter + 1, combo_damage);
		}
		else
		{
			if (!fatdamage)
			{
				pmessage.set_message(PM_STDDAMAGE, dam_color, "-%i", dam_cumulative);
			}
			else
			//fatigue damage
			{
				sound_id	= S_ATT_LOCKED;

				RGBcolor c(50, 50, 255);
				pmessage.set_message(PM_FATDAMAGE, c, "FAT DAMAGE +%i", dam_cumulative);
			}
		}
	}

/*/		int dam_display;

		//no damage applied
		if (dam_cumulative == 0)
		{
			dam_color.setcolor(white);

			//set flash color to black/blue
//!!			if (_bone == bn && b_ext)		sk.b[bn].hit_state_e	= hs_hitret;
//			if (_bone == ball && b_ext)		sk.b[ball].hit_state_e	= hs_hitret;
//			if (_bone == balr && b_ext)		sk.b[balr].hit_state_e	= hs_hitret;
//			if (!b_ext)						sk.b[_bone].hit_state	= hs_hitret;
		}

/*		if (dam_applied != (int)dam_final)
		{
			if (dam_applied == 0)
			{
//				dam_display = 0;
				dam_color.setcolor(white);

				//set flash color
				if (_bone == bn && b_ext)		sk.b[bn].hit_state_e	= hs_hitret;
				if (_bone == ball && b_ext)		sk.b[ball].hit_state_e	= hs_hitret;
				if (_bone == balr && b_ext)		sk.b[balr].hit_state_e	= hs_hitret;
				if (!b_ext)						sk.b[_bone].hit_state	= hs_hitret;
			}
//			else
//			{
//				dam_display	= dam_applied;
//				if (dam_display > 0)
//					dam_display = -dam_display;
//			}
		}*/
//		else
//			dam_display	= (int)-dam_final;

		//sprintf(cb, "%i", dam_display);

	//---- hit animation -------------------------------------------------------------------------

	//only if bone hit not in defense state or damage from tapped attack
	if (sk.b[_bone].cd_state != cds_def && !retdamage && !fatdamage)
	{
		//set hit animation
		gl_SetHitBone(_bone, dam_final);

		//---- push back/cancel ------------------------------------------------------------------
		//also only if bone not in defence state

		//type
		//0 = stop player forward movement
		//1 = push player backward, may be neutralized if player hits forward
		//2 = push player backward, no neutralizing

		//basic push back for every hit is to stop player movement
		int _push_type			= 0;
		//unassign damage multiplier to force
		float _push_force		= dam_final / p_option->data.damage_multiplier / 100.0f * 1.2f;
		//!!
		//adjust backward walking speed
		float _push_speed		= 75;

		//head
		if (_bone == bn)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 10.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			//always push back player
			_push_type			= 2;
			//adjust push force
			_push_force = dam_final / p_option->data.damage_multiplier / 100.0f * 1.5f;
		}
		//torso
		if (_bone == btul || _bone == btur ||
			_bone == btll || _bone == btlr)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 15.0f * p_option->data.damage_multiplier)
			{
				cd_cancel_action	= 1;
				_push_type			= 1;

				if (_dam >= 20.0f * p_option->data.damage_multiplier)
					_push_type		= 2;
			}
		}
		//legs (including hip, no feet)
		if (_bone == bhl || _bone == blul || _bone == blll ||
			_bone == bhr || _bone == blur || _bone == bllr)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 15.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			_push_type			= 1;

			if (_dam >= 20.0f * p_option->data.damage_multiplier)
				_push_type		= 2;
		}

/*		//generel pushing
		if (_dam >= 12.0f * p_option->data.damage_multiplier)
		{
			//push neutral backward
			cd_push_type		= 1;
			//cancel actions
			cd_cancel_action	= 1;
		}
		if (_dam >= 20.0f * p_option->data.damage_multiplier)
		{
			//push backward
			cd_push_type		= 2;
		}

		//head
		if (_bone == bn)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 10.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			//always push back player
			cd_push_type			= 2;
			//adjust push force
			cd_push_force = dam_final / p_option->data.damage_multiplier / 100.0f * 1.5f;
		}*/

/*old version
		//head
		if (_bone == bn)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 10.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			//always push back player
			cd_push_type			= 2;
			//adjust push force
			cd_push_force = dam_final / p_option->data.damage_multiplier / 100.0f * 1.5f;
		}
		//torso
		if (_bone == btul || _bone == btur ||
			_bone == btll || _bone == btlr)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 15.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			//if damage exceeds damage level
			if (_dam >= 15 * p_option->data.damage_multiplier)
				cd_push_type		= 1;

			if (_dam > 30.0f * p_option->data.damage_multiplier)
				cd_push_type		= 2;
		}
		//legs (including hip, no feet)
		if (_bone == bhl || _bone == blul || _bone == blll ||
			_bone == bhr || _bone == blur || _bone == bllr)
		{
			//if damage exceeds damage level cancel player actions
			if (_dam >= 20.0f * p_option->data.damage_multiplier)
				cd_cancel_action	= 1;

			cd_push_type			= 1;

			if (_dam >= 30.0f * p_option->data.damage_multiplier)
				cd_push_type		= 2;
		}*/

		//force limits (since force actually is time in seconds the player is pushed back)
		if (_push_force < 0)
			_push_force = 0;

		//set push
		gl_SetPush(_push_type, _push_force, _push_speed);

		//cancel all actions in pre state if damage >= 10%
		//except evading and tapping animations
		if (p_aslot[aslot_action] != NULL && dam_final >= 10 * p_option->data.damage_multiplier)
			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0 &&
				p_aslot[aslot_action]->ui_dir[id] == 0)
				if (p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_DUCK] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI_HOLD] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO_HOLD] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_DUCK_HOLD] &&
					//p_aslot[aslot_action] != p_anmn[asi][AN_TAP_JAB] &&
					//p_aslot[aslot_action] != p_anmn[asi][AN_TAP_CROSS] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_ARMS] &&
					p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG])
					cd_cancel_action	= 1;
	}

	//---- walk stun -----------------------------------------------------------------------------

	//if pure hit
	if (!retdamage &&
		!fatdamage &&
//		!defbonus &&
		!defevade &&
		!deflock)
	{
		//for each hit with at least 10 damage
		if (dam_final >= 1 * p_option->data.damage_multiplier)
		{
			gl_lock.stun_walk_bwd	-= 0.1f;
			gl_lock.stun_walk_fwd	-= 0.1f;
			//limit
			if (gl_lock.stun_walk_bwd < 0.7f)			gl_lock.stun_walk_bwd	= 0.7f;
			if (gl_lock.stun_walk_fwd < 0.7f)			gl_lock.stun_walk_fwd	= 0.7f;
			//set start time
			gl_lock.t_stun_bwd		= p_time->current;
			gl_lock.t_stun_fwd		= p_time->current;
		}
	}

	//---- blood fx ------------------------------------------------------------------------------

	//not for fatigue damage
	if (!fatdamage)
	{
		//if damage to head exceeds certain damage level (adjusted to damage multiplier)
		if (_bone == bn && _dam >= 30.0f * p_option->data.damage_multiplier)
		{
			//set sound type id
			sound_id	= S_HIT_BLOOD;

			//set to gamma flash
			blood_gammaflash = true;

			//determine index of blood array
			int	b_index = 0;
			//index is heap which is not active, if both active, overwrite first heap
			if (blood_active[0] == 0)				b_index	= 0;
			else
			{
				if (blood_active[1] == 0)			b_index	= 1;
				else								b_index	= 0;
			}

			//activate heap
			blood_active[b_index] = 1;

			//calculate particle source point from angle of impact
			point	bsource;
			//save between head and attacking limb
			//blood_angle_h[b_index]	= p_rcd->angle_h[id];
//!! blut in richtung schlag, nicht entgegengesetzt
blood_angle_h[b_index]	= p_rcd->angle_h[id] - 180;
if (blood_angle_h[b_index] > 359)	blood_angle_h[b_index] -= 360;
if (blood_angle_h[b_index] < 0)		blood_angle_h[b_index] += 360;
//hud_add_message(0, bmfblack, "angle: %i", (int)blood_angle_h[b_index]);
			//angle in rad
			float	angle_h_rad = blood_angle_h[b_index] / 180 * PI;
			bsource.x			= sk.chead.x + sk.radius_head * (float)(cos(angle_h_rad));
			bsource.y			= sk.chead.y + sk.radius_head * (float)(sin(angle_h_rad));

			//calculate min and max spread angle from source
			//!! art von min max
			blood_angle[b_index].x	= blood_angle_h[b_index];
			blood_angle[b_index].y	= 100;

			//calculate min and max force
			blood_force[b_index].x	= 50;
			blood_force[b_index].y	= 100;

			//number of particles shown, depending on force
			blood_size[b_index]		= (int)((_dam / p_option->data.damage_multiplier) * 1.2f);
			//limit
			if (blood_size[b_index]	> NOBLOOD)
				blood_size[b_index] = NOBLOOD;

			//initialize particle heap
			blood_fx[b_index].initialization(p_time->current,						//current time
											 1, 0.1f,								//reemerge mode and active time
											 (int)bsource.x, (int)bsource.y,		//source of particles
											 2, 2,									//source position tolerance
											 400.0f, 0.5f, 0.5f,					//y-acceleration, velocity damper
											 (int)blood_force[b_index].x,			//force min and max
											 (int)blood_force[b_index].y,
											 (int)blood_angle[b_index].x,			//angle min and max
											 (int)blood_angle[b_index].y,
//											 500, 3000,								//lifetime min and max
											 2500, 8000,								//lifetime min and max
											 p_option->data.speed);					//user set speedfactor

				//!!
				//angle an seite anpassen und limits
			//manchmal kommen zu viele raus
			//* dam multi ist doch totaler m�ll, oder?

			//!! shadow geht nicht
				//!! screen valid exklusive?
				//clipping, clipping in particle_heap, auch f�r init? in draw sicherheitshalber?
				//if particle is out of bounds, his age becomes -1 and it won't be drawn, reset
//				pp[i].pos.x < val_screen.left		? pp[i].age = -1 : pp[i].pos.x;
//				pp[i].pos.x > val_screen.right - 1	? pp[i].age = -1 : pp[i].pos.x;
//				pp[i].pos.y < val_screen.top		? pp[i].age = -1 : pp[i].pos.y;
		}
	}

	//---- lower guard ---------------------------------------------------------------------------

if (false)
	if (_dam > 10.0f * p_option->data.damage_multiplier)
	{
//int old = stance_arms;
		//lower guard
		//stance_arms	-= 10;
		//stance_arms	-= (int)(_dam / p_option->data.damage_multiplier * 0.5f);
		if (_dam / p_option->data.damage_multiplier * 0.5f > 20.0f)
			stance_arms	-= 20;
		else
			stance_arms	-= (int)(_dam / p_option->data.damage_multiplier * 0.5f);

		//check limit
		if (stance_arms < 0)		stance_arms = 0;

//pmessage.set_message(PM_DEFAULT, lightblue, "guard -%i", (old - stance_arms));
	}

	//---- knockout ------------------------------------------------------------------------------

	//depening on ko_mode
	switch (p_option->data.ko_mode)
	{
	case (KOM_HEAD):
		{
			if (sk.damage[DS_hn] == 100)
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_OR_UP):
		{
			if (sk.damage[DS_hn] == 100 ||
				(sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_AND_UP):
		{
			if (sk.damage[DS_hn] == 100 &&
				(sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_OR_LO):
		{
			if (sk.damage[DS_hn] == 100 ||
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_AND_LO):
		{
			if (sk.damage[DS_hn] == 100 &&
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_OR_UP_OR_LO):
		{
			if (sk.damage[DS_hn] == 100 ||
				(sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) ||
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_AND_UP_AND_LO):
		{
			if (sk.damage[DS_hn] == 100 &&
				(sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) &&
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_AND_UP_OR_LO):
		{
			if (sk.damage[DS_hn] == 100 &&
				((sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) ||
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100)))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HEAD_OR_UP_AND_LO):
		{
			if (sk.damage[DS_hn] == 100 ||
				((sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) &&
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100)))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_UP):
		{
			if (sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100)
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_LO):
		{
			if (sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100)
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_UP_OR_LO):
		{
			if ((sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) ||
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_UP_AND_LO):
		{
			if ((sk.damage[DS_tul] == 100 || sk.damage[DS_tur] == 100) &&
				(sk.damage[DS_tll] == 100 || sk.damage[DS_tlr] == 100))
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HPRIMARY):
		{
			if (sk.damage[DS_hn] > 0 ||
				sk.damage[DS_tul] > 0 || sk.damage[DS_tur] > 0 ||
				sk.damage[DS_tll] > 0 || sk.damage[DS_tlr] > 0)
			{
				gl_ko					= 1;
			}
			break;
		}
	case (KOM_HGENERAL):
		{
			//for all damage slots
			for (register int ds = 0; ds < NODS; ++ds)
				if (sk.damage[ds] > 0)
				{
					gl_ko					= 1;
					break;
				}
			break;
		}
	}

	//ko sound
	if (gl_ko)		s_set_sound(S_HIT_KO);

	//if knocked out but last damage taken not enough show warning but no ko
	if (gl_ko && dam_final < p_option->data.ko_limit * p_option->data.damage_multiplier)
	{
		gl_ko					= 0;
		gl_ko_pending			= 1;

		s_set_sound(S_HIT_KO, SB_OFF);

		//all bones flash
		for (register int b = 0; b < 19; ++b)
		{
			if (b != bsl && b != bsr &&
				b != bhl && b != bhr &&
				b != bfl && b != bfr)
			{
				sk.b[b].hit_state		= hs_hit;
				if (b == ball || b == balr || b == bn)
					sk.b[b].hit_state_e		= hs_hit;
				p_rcd->time[id][b]		= p_time->current;
			}
		}
		p_rcd->time[id][19]		= p_time->current;
		p_rcd->time[id][20]		= p_time->current;
		p_rcd->time[id][21]		= p_time->current;

		/*if (p_option->data.show_pmessages)
		{
			//pmessage.set_message("DANGER!", 0, 0, 0, 255, 0, 0, 0.35f, 1.2f / p_option->data.speed, p_time->current);
			//char cb[6] = {0};
			//sprintf(cb, "%i", -dam_final);

			//pmessage.set_message(0, 0, 0, 255, 0, 0, 0.35f, 1.2f / p_option->data.speed, p_time->current,
			//					 "%i!", dam_cumulative);
		}*/
	}

	//not for fatigue damage
	if (!fatdamage)
	{
		//instant knockout (0 = off)
		if (p_option->data.ko_instant &&
			(dam_final >= p_option->data.ko_instant * p_option->data.damage_multiplier))
		{
			gl_ko					= 1;
			s_set_sound(S_HIT_KO);

			if (p_option->data.show_pmessages)
				p_opp->pmessage.set_message(PM_GODLIKE, white, "GODLIKE!");
		}
	}

	//---- fatigue -------------------------------------------------------------------------------

/*	//if damage very high, also apply certain percentage of damage to fatigue of player
	//if hit to head do always
	if (_bone != bn)
	{
		if (_dam >= 30.0f * p_option->data.damage_multiplier)
			gl_fatigue_add(0, 0, _dam * p_option->data.damage_multiplier / 2.0f);
	}
	else
	{
		if (_dam >= 30.0f * p_option->data.damage_multiplier)
			gl_fatigue_add(0, 0, _dam * p_option->data.damage_multiplier / 2.0f);
		else
			gl_fatigue_add(0, 0, _dam * p_option->data.damage_multiplier / 3.0f);
	}*/

	//not for fatigue damage
	if (!fatdamage)
	{
		//only if bone hit not in defence state
		if (sk.b[_bone].cd_state != cds_def)
			//only for head and torso
			if (_bone == bn)
			{
				//third of damage as fatigue
				gl_fatigue_add(0, 0, _dam / p_option->data.damage_multiplier / (3.0f / p_option->data.fom_multiplier));
			}
			if (_bone == btll || _bone == btlr ||
				_bone == btul || _bone == btur)
			{
				//third of damage as fatigue
				gl_fatigue_add(0, 0, _dam / p_option->data.damage_multiplier / (3.0f / p_option->data.fom_multiplier));
			}
	}

	//---- score ---------------------------------------------------------------------------------

	//no fatigue damage
	if (!fatdamage)
	{
		//not a tap
		if (sk.b[_bone].cd_state != cds_def)
		{
			if (p_option->data.score_mode == 0)
			{
				//return damage
				if (retdamage)
				{
					p_opp->gl_score += 2;
					--gl_score;
				}
				else
					//head and torso more scores
					if (_bone == bn ||
						_bone == btul || _bone == btur ||
						_bone == btll || _bone == btlr)
					{
						p_opp->gl_score += 3;
						--gl_score;
					}
					else
					{
						++p_opp->gl_score;
						--gl_score;
					}
			}
			else
			{
				//increase opponents score depending on damage taken
				p_opp->gl_score += (int)(dam_final / p_option->data.damage_multiplier * gl_score_multiplier_off[_bone]);

				//decrease own score depending on damage taken
				gl_score -= (int)(dam_final / p_option->data.damage_multiplier * gl_score_multiplier_def[_bone]);
			}
		}
		else
		//tap increase own score
		{
			if (p_option->data.score_mode == 0)
				++gl_score;
			else
				gl_score += (int)(dam_final / p_option->data.damage_multiplier * 2.0f);
		}
	}
	else
	//fatigue damage
	{
		//decrease score by 1
		gl_score -= 1;
	}

	//---- sound-fx ------------------------------------------------------------------------------

	//set sound type id if not already set
	if (sound_id == 0)
	{
		sound_id	= S_HIT_STD;
	}

	//!!
	if (sound_id == S_HIT_RET)
		sound_id = S_HIT_TAP;

	s_set_sound(sound_id);
}

//------------------------------------------------------------------------------------------------
//
//	player gl_apply_damage
//
//  applies argumented damage to argumented damage slot
//	reduced referenced damage depending on applied damage
//	returns applied damage
//
//------------------------------------------------------------------------------------------------

int player::gl_apply_damage(int ds, int *p_damage, bool first)
{
	//applied damage
	int dam_app			= *p_damage;

	//if additional damage exceeds 100
	if (sk.damage[ds] + *p_damage > 100)
	{
		//for all bones of damage slot
		//set hit flash
		//if not originally hit damage slot and damage slot not already max damage
		if (!first && sk.damage[ds] < 100)
			for (register int b = 0; b < 19; ++b)
				if (sk.b[b].d_slot == ds)
				{
					sk.b[b].hit_state	= hs_hitret;
					p_rcd->time[id][b]	= p_time->current;
					//bone has fist or head
					if (b == ball)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][20]	= p_time->current;
					}
					if (b == balr)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][21]	= p_time->current;
					}
					if (b == bn)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][19]	= p_time->current;
					}
				}

		//applied damage
		dam_app			= 100 - sk.damage[ds];
		//reduce damage
		*p_damage		-= dam_app;
		//set max damage
		sk.damage[ds]	= 100;

		//return applied damage
		return(dam_app);
	}
	else
	{
		//for all bones of damage slot
		//set hit flash
		//if not originally hit damage slot and damage slot not already max damage
		if (!first && sk.damage[ds] < 100)
			for (register int b = 0; b < 19; ++b)
				if (sk.b[b].d_slot == ds)
				{
					sk.b[b].hit_state	= hs_hitret;
					p_rcd->time[id][b]	= p_time->current;
					//bone has fist or head
					if (b == ball)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][20]	= p_time->current;
					}
					if (b == balr)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][21]	= p_time->current;
					}
					if (b == bn)
					{
						sk.b[b].hit_state_e = hs_hitret;
						p_rcd->time[id][19]	= p_time->current;
					}
				}

		//apply and empty damage
		sk.damage[ds]	+= *p_damage;
		*p_damage		= 0;

		//return applied damage
		return(dam_app);
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetHitBone
//
//  applies argumented damage to argumented damage slot
//	reduced referenced damage depending on applied damage
//	returns applied damage
//
//------------------------------------------------------------------------------------------------

void player::gl_SetHitBone(int _bone, float dam_final)
{
	//not the feet
	if (_bone != bfl && _bone != bfr)
	{
		//assign hit-animation to hit-slot
		p_aslot[aslot_hit] = p_anmn[asi][AN_HIT];

		//reset keyframe state of bones current keyframe
		if (p_aslot[casi[_bone]] != NULL)
			p_aslot[casi[_bone]]->pkf[cki[_bone]].state[id][_bone]		= 0;

		//assign bone to hit-slot
		casi[_bone]			= aslot_hit;
		//to first keyframe
		cki[_bone]			= 0;
		//reset keyframe state
		p_aslot[casi[_bone]]->pkf[cki[_bone]].state[id][_bone] = 0;
		//set bone to hit
		bhi[_bone]			= 1;
		//unassign damage multiplier from force
		cd_bh_force[_bone]		= (int)(dam_final / p_option->data.damage_multiplier * 1.2f);

		//if bone hit has a parent bone
		if (sk.b[_bone].pbi != -1)
		{
			//also assign bone to be hit but with less force
			int _pbone = sk.b[_bone].pbi;

			if (p_aslot[casi[_pbone]] != NULL)
				p_aslot[casi[_pbone]]->pkf[cki[_pbone]].state[id][_pbone] = 0;

			casi[_pbone]		= aslot_hit;
			cki[_pbone]			= 0;
			p_aslot[casi[_pbone]]->pkf[cki[_pbone]].state[id][_pbone] = 0;
			bhi[_pbone]			= 1;
			cd_bh_force[_pbone]	= (int)(dam_final / p_option->data.damage_multiplier * 0.8f);
		}

		//!! bei torso evtl. auch andere seite setzen

		/*//if hit into lower torso flip upper torso forward
		if (_bone == btll || _bone == btlr)
		{
			int _cbone = btul;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 1.5f);
			_cbone = btur;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 1.5f);
		}*/

		//if leg/hip hit flip torso and head forward
		if (_bone == bhl || _bone == bhr ||
			_bone == blul || _bone == blur ||
			_bone == blll || _bone == bllr)
		{
			int _cbone = btul;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 0.6f);
			_cbone = btur;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 0.6f);
			_cbone = btll;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 0.5f);
			_cbone = btlr;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 0.5f);
			_cbone = bn;
			if (p_aslot[casi[_cbone]] != NULL)
				p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			casi[_cbone]		= aslot_hit;
			cki[_cbone]			= 0;
			p_aslot[casi[_cbone]]->pkf[cki[_cbone]].state[id][_cbone] = 0;
			bhi[_cbone]			= 1;
			cd_bh_force[_cbone]	= -(int)(dam_final / p_option->data.damage_multiplier * 0.6f);
		}

		//set priority
		al_set_priority();
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_process_damage_off
//
//  calculates offensive damage done to opponent
//	returns damage (-1 if no attack/no hit)
//
//------------------------------------------------------------------------------------------------

float player::gl_process_damage_off(float t_move[2][2])
{
	if (p_option->data.digidamage)
	{
		float	dam_basic		= 0;			//basic damage
		float	dam_final		= 0;			//final damage which gets returned
		int		angle_bone[2]	= {-1, -1};		//index of both bones between relative angle is determined
		float	angle_limit[2]	= {-1, -1};		//angle limits for efficiency (bonus, malus)
		int		angle_attack	= 0;			//attack angle of limbs

		//for all attack types
		for (register int a = 0; a < 6; ++a)
		{
			//if attacking
			if (p_rcd->attack[id][a] != -1)
			{
				//if slot valid
				if (p_aslot[aslot_action] != NULL)
				{
					//---- get basic damage ----------------------------------------------------------

					dam_basic = (float)p_aslot[aslot_action]->gl_damage;

					//assign basic damage
					dam_final = dam_basic;

					//---- determine attack angle ----------------------------------------------------

					//limb and action type
					//hooks not affected
					if (a == act_fistl - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_JAB] || p_aslot[aslot_action] == p_anmn[asi][AN_CROSS]))
					{
						angle_bone[0]	= baul;	angle_bone[1]	= ball;
						angle_limit[0]	= 60;	angle_limit[1]	= 100;
					}
					if (a == act_fistr - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_JAB] || p_aslot[aslot_action] == p_anmn[asi][AN_CROSS]))
					{
						angle_bone[0]	= baur;	angle_bone[1]	= balr;
						angle_limit[0]	= 60;	angle_limit[1]	= 100;
					}
					if (a == act_footl - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] || p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD]))
					{
						angle_bone[0]	= blul;	angle_bone[1]	= blll;
						angle_limit[0]	= 40;	angle_limit[1]	= 100;
					}
					if (a == act_footr - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] || p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD]))
					{
						angle_bone[0]	= blur;	angle_bone[1]	= bllr;
						angle_limit[0]	= 40;	angle_limit[1]	= 100;
					}

					//if angle effects efficiency
					if (angle_bone[0] != -1 && angle_bone[1] != -1)
					{
						//get relative angle between two bones
						angle_attack = (int)(sk.b[angle_bone[0]].angle - sk.b[angle_bone[1]].angle);
						//absolute value
						if (angle_attack < 0)
							angle_attack += 360;
						//shortest direction
						if (angle_attack > 180)
							angle_attack = 360 - angle_attack;

						/*/angle as player message
						char cb[7] = {0};
						sprintf(cb, "%i", (int)angle_attack);
						pmessage.set_message(cb, 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, p_time->current);
						//halt game
						options *phack = (options*)p_option;
						phack->data.speed = 0;*/

						//3 possibilities:
						//either player gets a damage bonus if arm almost stretched completely
						//or player gets malus if angle is too steep
						//or player gets neither
						/*if (angle_attack <= angle_limit[0])
							dam_final += (dam_basic * 0.20f);
						if (angle_attack > angle_limit[1])
							dam_final -= (dam_basic * 0.30f);*/

						//bonus
						if (angle_attack <= angle_limit[0])
						{
							//plus 0.5 of basic damage
							//dam_final += (dam_basic * ((1.0f - (float)angle_attack / angle_limit[0]) * 0.5f));
							dam_final	+= dam_basic * 0.2f;
						}
						//malus
						if (angle_attack >= angle_limit[1])
						{
							//minus 0.5 of basic damage
							//dam_final -= (dam_basic * (((angle_attack - angle_limit[0]) / (angle_limit[1] - angle_limit[0])) * 0.5f));
							dam_final	-= dam_basic * 0.4f;
						}
					}

					//---- damage of vital bone(s) ---------------------------------------------------

					//for all bones
					for (register int i = 0; i < 19; ++i)
					{
						//if damage of bone has affect on attack damage
						if (p_aslot[aslot_action]->gl_eff_dam_off[i] >= 1.0f)
							//apply effect on basic damage and reduce final damage by it
							dam_final	-= dam_basic * (sk.b[i].damage / 100.0f / p_aslot[aslot_action]->gl_eff_dam_off[i]);
					}

					//---- fatigue -------------------------------------------------------------------

					//if fatigue has affect on attack damage
					if (p_aslot[aslot_action]->gl_eff_fat_off >= 1.0f)
						//apply effect on basic damage and reduce final damage by it
						dam_final	-= dam_basic * (fatigue / 100.0f / p_aslot[aslot_action]->gl_eff_fat_off);

					//---- forward/backward movement -------------------------------------------------

					//maximum time factor, adjusted to user set speed
					//float	t_eff = 0.5f * p_option->data.speed;
					//holds adjusted move time
					//float	mtime[2];

					//forward movement gives bonus
					if (t_move[id][1] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
					{
						//maximum of t_eff seconds
						//if (t_move[id][1] > t_eff)		mtime[1] = t_eff;
						//else							mtime[1] = t_move[id][1];

						//1/3 of basic damage
						//dam_final		+= dam_basic / t_eff * mtime[1] / 3.0f;
						dam_final		+= dam_basic * 0.2f;
					}

					//backward movement gives malus
					if (t_move[id][0] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					{
						//if (t_move[id][0] > t_eff)		mtime[0] = t_eff;
						//else							mtime[0] = t_move[id][0];

						//1/3 of basic damage
						//dam_final		-= dam_basic / t_eff * mtime[0] / 3.0f;
						dam_final		-= dam_basic * 0.2f;
					}

					//---- power attack bonus -------------------------------------------------------------

					if (p_aslot[aslot_action]->power_attack[id] == 1)
					{
						//punch
						if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
							p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
						{
							//not if offense locked
							if (!gl_lock.get_offlockstate(0))
							{
								//dam_final		+= dam_basic * 1.0f;
								dam_final		*= 1.5f;

								//minimum power attack damage
								if (dam_final <= 0)
									dam_final		= dam_basic * 0.5f;
							}
						}

						//kick
						if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
							p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
						{
							//not if offense locked
							if (!gl_lock.get_lockstate(asi, 2, 0, 0, -1))
							{
								//dam_final		+= dam_basic * 1.0f;
								dam_final		*= 1.5f;

								//minimum power attack damage
								if (dam_final <= 0)
									dam_final		= dam_basic * 0.5f;
							}
						}
					}

					//---- jkd bonus -----------------------------------------------------------------

					//bullshit
					/*/if right foot forward and no cross/cross hook
					if (stance_feet == SRIGHT &&
						p_aslot[aslot_action] != p_anmn[asi][AN_CROSS] &&
						p_aslot[aslot_action] != p_anmn[asi][AN_CROSS])
						//apply bonus if no fatigue
						if (fatigue == 0)
						//fatigue < 10.0f * p_option->data.fom_multiplier)
							dam_final	+= dam_basic * 0.2f;
						else
							dam_final	+= dam_basic * 0.1f;*/

					//---- damage multiplier ---------------------------------------------------------

					//multiply final damage by user set damage multiplier
					dam_final	*= p_option->data.damage_multiplier;

					//!!
					//multiplier am grund- oder finalschaden?

					//---- offense lock malus ----------------------------------------------------

					//if offense lock slowdown
					if (OFF_LOCK_SLOWDOWN)
					{
						//if limb offense locked apply damage malus
						if (gl_lock.get_offlockstate(a))
						{
							dam_final	*= OFF_LOCK_DAMAGE;
						}
					}

					//make sure no negative damage is returned (which in fact
					//increases opponents health)
					//happens sometimes when attacking limbs are very damaged and
					//other mali get applied
					if (dam_final < 0)
						dam_final = 0;

					//no defpart for hooks
					if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK] ||
						p_aslot[aslot_action] == p_anmn[asi][AN_CROSS_HOOK])
					{
						if (p_rcd->defend[id])
							p_rcd->defend[id] = -1;
					}

					return(dam_final);
				}
				else
					return(-1);
			}
		}
	}
	else
	{
		float	dam_basic		= 0;			//basic damage
		float	dam_final		= 0;			//final damage which gets returned
		int		angle_bone[2]	= {-1, -1};		//index of both bones between relative angle is determined
		float	angle_limit[2]	= {-1, -1};		//angle limits for efficiency (bonus, malus)
		int		angle_attack	= 0;			//attack angle of limbs

		//for all attack types
		for (register int a = 0; a < 6; ++a)
		{
			//if attacking
			if (p_rcd->attack[id][a] != -1)
			{
				//if slot valid
				if (p_aslot[aslot_action] != NULL)
				{
					//---- get basic damage ----------------------------------------------------------

					dam_basic = (float)p_aslot[aslot_action]->gl_damage;

					//assign basic damage
					dam_final = dam_basic;

					//---- determine attack angle ----------------------------------------------------

					//limb and action type
					//hooks not affected
					if (a == act_fistl - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_JAB] || p_aslot[aslot_action] == p_anmn[asi][AN_CROSS]))
					{
						angle_bone[0]	= baul;	angle_bone[1]	= ball;
						angle_limit[0]	= 60;	angle_limit[1]	= 100;
					}
					if (a == act_fistr - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_JAB] || p_aslot[aslot_action] == p_anmn[asi][AN_CROSS]))
					{
						angle_bone[0]	= baur;	angle_bone[1]	= balr;
						angle_limit[0]	= 60;	angle_limit[1]	= 100;
					}
					if (a == act_footl - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] || p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD]))
					{
						angle_bone[0]	= blul;	angle_bone[1]	= blll;
						angle_limit[0]	= 40;	angle_limit[1]	= 100;
					}
					if (a == act_footr - 1 &&
						(p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] || p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD]))
					{
						angle_bone[0]	= blur;	angle_bone[1]	= bllr;
						angle_limit[0]	= 40;	angle_limit[1]	= 100;
					}

					//if angle effects efficiency
					if (angle_bone[0] != -1 && angle_bone[1] != -1)
					{
						//get relative angle between two bones
						angle_attack = (int)(sk.b[angle_bone[0]].angle - sk.b[angle_bone[1]].angle);
						//absolute value
						if (angle_attack < 0)
							angle_attack += 360;
						//shortest direction
						if (angle_attack > 180)
							angle_attack = 360 - angle_attack;

						/*/angle as player message
						char cb[7] = {0};
						sprintf(cb, "%i", (int)angle_attack);
						pmessage.set_message(cb, 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, p_time->current);
						//halt game
						options *phack = (options*)p_option;
						phack->data.speed = 0;*/

						//3 possibilities:
						//either player gets a damage bonus if arm almost stretched completely
						//or player gets malus if angle is too steep
						//or player gets neither
						/*if (angle_attack <= angle_limit[0])
							dam_final += (dam_basic * 0.20f);
						if (angle_attack > angle_limit[1])
							dam_final -= (dam_basic * 0.30f);*/

						//bonus
						if (angle_attack <= angle_limit[0])
						{
							//plus 0.5 of basic damage
							//dam_final += (dam_basic * ((1.0f - (float)angle_attack / angle_limit[0]) * 0.5f));
							dam_final	+= dam_basic * 0.2f;
						}
						//malus
						if (angle_attack >= angle_limit[1])
						{
							//minus 0.5 of basic damage
							//dam_final -= (dam_basic * (((angle_attack - angle_limit[0]) / (angle_limit[1] - angle_limit[0])) * 0.5f));
							dam_final	-= dam_basic * 0.4f;
						}
					}

					//---- damage of vital bone(s) ---------------------------------------------------

					//for all bones
					for (register int i = 0; i < 19; ++i)
					{
						//if damage of bone has affect on attack damage
						if (p_aslot[aslot_action]->gl_eff_dam_off[i] >= 1.0f)
							//apply effect on basic damage and reduce final damage by it
							dam_final	-= dam_basic * (sk.b[i].damage / 100.0f / p_aslot[aslot_action]->gl_eff_dam_off[i]);
					}

					//---- fatigue -------------------------------------------------------------------

					//if fatigue has affect on attack damage
					if (p_aslot[aslot_action]->gl_eff_fat_off >= 1.0f)
						//apply effect on basic damage and reduce final damage by it
						dam_final	-= dam_basic * (fatigue / 100.0f / p_aslot[aslot_action]->gl_eff_fat_off);

					//---- forward/backward movement -------------------------------------------------

					//maximum time factor, adjusted to user set speed
					//float	t_eff = 0.5f * p_option->data.speed;
					//holds adjusted move time
					//float	mtime[2];

					//forward movement gives bonus
					if (t_move[id][1] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
					{
						//maximum of t_eff seconds
						//if (t_move[id][1] > t_eff)		mtime[1] = t_eff;
						//else							mtime[1] = t_move[id][1];

						//1/3 of basic damage
						//dam_final		+= dam_basic / t_eff * mtime[1] / 3.0f;
						dam_final		+= dam_basic * 0.2f;
					}

					//backward movement gives malus
					if (t_move[id][0] || p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					{
						//if (t_move[id][0] > t_eff)		mtime[0] = t_eff;
						//else							mtime[0] = t_move[id][0];

						//1/3 of basic damage
						//dam_final		-= dam_basic / t_eff * mtime[0] / 3.0f;
						dam_final		-= dam_basic * 0.2f;
					}

					//---- power attack bonus -------------------------------------------------------------

					if (p_aslot[aslot_action]->power_attack[id] == 1)
					{
						//punch
						if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
							p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
						{
							//not if offense locked
							if (!gl_lock.get_offlockstate(0))
							{
								//dam_final		+= dam_basic * 1.0f;
								dam_final		*= 1.5f;

								//minimum power attack damage
								if (dam_final <= 0)
									dam_final		= dam_basic * 0.5f;
							}
						}

						//kick
						if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
							p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
						{
							//not if offense locked
							if (!gl_lock.get_lockstate(asi, 2, 0, 0, -1))
							{
								//dam_final		+= dam_basic * 1.0f;
								dam_final		*= 1.5f;

								//minimum power attack damage
								if (dam_final <= 0)
									dam_final		= dam_basic * 0.5f;
							}
						}
					}

					//---- jkd bonus -----------------------------------------------------------------

					//bullshit
					/*/if right foot forward and no cross/cross hook
					if (stance_feet == SRIGHT &&
						p_aslot[aslot_action] != p_anmn[asi][AN_CROSS] &&
						p_aslot[aslot_action] != p_anmn[asi][AN_CROSS])
						//apply bonus if no fatigue
						if (fatigue == 0)
						//fatigue < 10.0f * p_option->data.fom_multiplier)
							dam_final	+= dam_basic * 0.2f;
						else
							dam_final	+= dam_basic * 0.1f;*/

					//---- damage multiplier ---------------------------------------------------------

					//multiply final damage by user set damage multiplier
					dam_final	*= p_option->data.damage_multiplier;

					//!!
					//multiplier am grund- oder finalschaden?

					//make sure no negative damage is returned (which in fact
					//increases opponents health)
					//happens sometimes when attacking limbs are very damaged and
					//other mali get applied
					if (dam_final < 0)
						dam_final = 0;

					return(dam_final);
				}
				else
					return(-1);
			}
		}
	}

	return(-1);
}

//------------------------------------------------------------------------------------------------
//
//	player al_activate_slot
//
//  activates animation slot
//
//------------------------------------------------------------------------------------------------

void player::al_activate_slot(int slot, int player_action, int angle, int angle_180, bool sf)
{
	//assign new animation as last animation of slot
	last_anmn[slot] = player_action;

	//if slot already active deactivate it first
	if (p_aslot[slot] != NULL)
		al_deactivate_slot(slot);

	//if hit animation active deactivate for certain animation else
	//it distorts the animation
	//action slot
	if (slot == aslot_action)
	{
		//kicks only
		if (player_action == AN_KICK_FWD ||
			player_action == AN_KICK_SWD ||
			player_action == AN_KICK_KNEE ||
			player_action == AN_KICK_SWD_HI)
		{
			//reset bhi
			bhi[bhl]		= 0;
			bhi[blul]		= 0;
			bhi[blll]		= 0;
			bhi[bfl]		= 0;
			bhi[bhr]		= 0;
			bhi[blur]		= 0;
			bhi[bllr]		= 0;
			bhi[bfr]		= 0;
		}
	}

	//cancel idling if active and action to activate is not idling
	if (player_action != AN_IDLE_HI &&
		player_action != AN_IDLE_LO)
	{
		if (p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
		{
			al_deactivate_slot(aslot_cycle);
			last_anmn[aslot_cycle] = !AN_IDLE_HI;
		}
		if (p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO])
		{
			al_deactivate_slot(aslot_action);
			last_anmn[aslot_action] = !AN_IDLE_LO;
		}
	}
	//!!
	else
	{
	//	last_anmn[slot] = player_action;
	}

	//assign animation
	p_aslot[slot] = p_anmn[asi][player_action];

	//set time index
	p_aslot[slot]->gl_time[id] = p_time->current;

	//set prioritiy
	al_set_priority();

	//set speedfactor of animation
	if (sf)
		gl_set_speedfactor(slot);

	//set angle if valid
	if (angle != -1 && angle_180 != -1)
	{
		p_aslot[slot]->angle[id]		= angle;
		p_aslot[slot]->angle_180[id]	= angle_180;
		p_aslot[slot]->ui_valid[id]		= 1;
	}
	else
	{
		p_aslot[slot]->ui_valid[id]		= 0;
	}

	//set soundflag to be played (only if animation has sound assigned; id != -1)
	if (p_aslot[slot]->gl_soundid != -1)
		s_set_slotsound(slot, SB_PLAY);
//!!		p_aslot[slot]->gl_soundplay[id] = true;
}

//------------------------------------------------------------------------------------------------
//
//	player al_deactivate_slot
//
//  deactivates animation slot
//
//------------------------------------------------------------------------------------------------

void player::al_deactivate_slot(int slot, bool fat)
{
	//if slot is valid
	if (p_aslot[slot] != NULL)
	{
		//if action slot gets deactivated
		if (slot == aslot_action)
			//reset other players defense bonus
			p_rcd->defend[id]	= -1;

		//walk slide
		if (p_aslot[slot] == p_anmn[asi][AN_WALK_SLIDE_BWD] ||
			p_aslot[slot] == p_anmn[asi][AN_WALK_SLIDE_FWD])
		{
			//apply standard full fatigue
			gl_fatigue_add(slot, 0);
		}

		//---- fatigue ---------------------------------------------------------------------------
		//apply fatigue if not already applied
		if (fat && !p_aslot[slot]->gl_fat[id])
		{
			//for every action
			for (register int a = 1; a < 7; ++a)
				//if current keyframe of ui_index bone in action_slot is action
				if (p_aslot[slot]->pkf[cki[p_aslot[slot]->ui_index]].action == a)
				{
					//if attack hit something
					if (p_aslot[slot]->gl_attack[id])
					{
						//if attack was power attack apply increased full fatigue
						if (p_aslot[slot]->power_attack[id] == 1)
							gl_fatigue_add(slot, 2);
						else
							//apply standard full fatigue
							gl_fatigue_add(slot, 0);
					}
					else
					//attack missed
					{
						//if attack was power attack
						if (p_aslot[slot]->power_attack[id] == 1)
							//power air attack
							gl_fatigue_add(slot, 3);
						else
							//normal air attack
							gl_fatigue_add(slot, 2);

						//air attack drag if within range
						if (false)	//not when deactivated for other animation
						//if (*p_distance <= SKILL_AAD_DISTANCE)
						{
							gl_SetPush(3, 0.2f, 0);
							//s_buffer[S_ERROR]	= SB_PLAY;
						}

						//get defense lock index
						int lindex = a - 1;
						//knee locks feet
						if (a == act_kneel)		lindex = 2;
						if (a == act_kneer)		lindex = 3;

						//set defense lock and start time
						gl_lock.set_lockstate(DEFENSIVE, lindex, 0, ON,
											  p_aslot[slot]->angle_180[id], p_time->current);
					}
				}
				else
					//apply cancel fatigue
					gl_fatigue_add(slot, 1);
		}

		//---- attack drive ----------------------------------------------------------------------
		//now in process input
/*		//if animation to deactivate was a incomplete kick player gets an attack drive
		//bonus which increases damage
		if (p_aslot[slot] == p_anmn[asi][AN_KICK_FWD])
			//only if kick in pre-state
			if (p_aslot[slot]->pkf[cki[p_aslot[slot]->ui_index]].dir == 0 &&
				p_aslot[slot]->pkf[cki[p_aslot[slot]->ui_index]].action == 0)
			{
				attack_drive[0]		= 1;
				//start time of canceling, bonus only valid for limited amount of time
				t_attack_drive[0]	= p_time->current;
			}
		//kick
		if (p_aslot[slot] == p_anmn[asi][AN_JAB])
			//only if in pre-state
			if (p_aslot[slot]->pkf[cki[p_aslot[slot]->ui_index]].dir == 0 &&
				p_aslot[slot]->pkf[cki[p_aslot[slot]->ui_index]].action == 0)
			{
				attack_drive[1]		= 1;
				t_attack_drive[1]	= p_time->current;
			}*/

		//---- defense lock ----------------------------------------------------------------------

		//if slot valid defense animation
		if (//p_aslot[slot] == p_anmn[asi][AN_TAP_JAB] ||
			//p_aslot[slot] == p_anmn[asi][AN_TAP_CROSS] ||
			p_aslot[slot] == p_anmn[asi][AN_TAP_ARMS] ||
			p_aslot[slot] == p_anmn[asi][AN_TAP_LEG])
		{
			//if defense blocked no attack set defense lock
//			if (p_aslot[slot]->gl_def[id] != 1)
			if (!gl_def_success)
			{
				//last tap time index
				if (p_aslot[slot] == p_anmn[asi][AN_TAP_LEG])
					t_last_tap_legs		= p_time->current;
				else
					t_last_tap_arms		= p_time->current;

				//index of limb to lock
				int lindex	= -1;
				if (asi == 0 || asi == 2)
				{
					//if (p_aslot[slot] == p_anmn[asi][AN_TAP_JAB])			lindex = 0;
					//if (p_aslot[slot] == p_anmn[asi][AN_TAP_CROSS])			lindex = 1;
					if (p_aslot[slot] == p_anmn[asi][AN_TAP_ARMS])			lindex = 1;
					if (p_aslot[slot] == p_anmn[asi][AN_TAP_LEG])			lindex = 2;
				}
				else
				{
					//if (p_aslot[slot] == p_anmn[asi][AN_TAP_JAB])			lindex = 1;
					//if (p_aslot[slot] == p_anmn[asi][AN_TAP_CROSS])			lindex = 0;
					if (p_aslot[slot] == p_anmn[asi][AN_TAP_ARMS])			lindex = 0;
					if (p_aslot[slot] == p_anmn[asi][AN_TAP_LEG])			lindex = 3;
				}

				if (lindex != -1)
					gl_lock.set_lockstate(DEFENSIVE, lindex, 0, ON,
										  p_aslot[slot]->angle_180[id], p_time->current);
			}

			//reset gl_def
			gl_def_success	= false;
		}

		//----------------------------------------------------------------------------------------

		//for all bones
		for (register int b = 0; b < 21; ++b)
		{
			//reset current keyframe index of bone of slot to delete
			if (casi[b] == slot)
				cki[b] = 0;
		}

		//!! reset user input angles
		//geht nicht, weil werte in dings gel�scht werden m�ssen
//		p_angle[id]							= 0;
//		p_angle180[id]						= 90;

		//set soundflag to be stopped (only if animation has sound assigned; id != -1)
		if (p_aslot[slot]->gl_soundid != -1)
			s_set_slotsound(slot, SB_STOP);

		//reset runtime data of animation and of all its keyframes
		p_aslot[slot]->reset_runtime_data(id);
		//clear slot
		p_aslot[slot] = NULL;
		//set prioritiy
		al_set_priority();

		//reset delay data for slot
		al_ResetDelayedAnimationAdj(slot);
	}
}

//------------------------------------------------------------------------------------------------
//
//	player al_set_priority
//
//	called whenever an animation is activated or deactivated
//	sets casi and cki of animator depending on priorities of animation
//
//------------------------------------------------------------------------------------------------

void player::al_set_priority()
{
	//reset bone priority counter
	ZeroMemory(&bpc, sizeof(bpc));
	//reset bone done counter
	ZeroMemory(&bdc, sizeof(bdc));

	//holds every bone which is changed
	//only these bones will get assigned a new cki
	int bcflag[21]	= {0};

	//---- both slots active ---------------------------------------------------------------------

	if (p_aslot[aslot_cycle] != NULL &&
		p_aslot[aslot_action] != NULL)
	{
		//assign current animation slot index (casi)
		//depending on bone priority of each slot
		//for every bone
		for (register int b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
			{
				//if priority of bone in slot 0 is bigger than priority of bone in slot 1
				if (p_aslot[aslot_cycle]->priority[b] > p_aslot[aslot_action]->priority[b])
				{
					//if assigned animation of bone changed
					if (casi[b] != aslot_cycle)
					{
						//reset keyframe state for this bone
						p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
						//reset cki of bone
						cki[b]		= 0;
						//set change flag
						bcflag[b]	= 1;
					}

					//assign bone to slot 0
					casi[b] = aslot_cycle;
					//increase number of bones in slot 0 with priority of priority of bone
					++bpc[aslot_cycle][p_aslot[aslot_cycle]->priority[b]];
					//increase number of bones in slot 0
					++bpc[aslot_cycle][21];
				}
				else
				{
					//if assigned animation of bone changed
					if (casi[b] != aslot_action)
					{
						//reset keyframe state for this bone
						p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
						//reset cki of bone
						cki[b]		= 0;
						//set change flag
						bcflag[b]	= 1;
					}

					//assign bone to slot 1
					casi[b] = aslot_action;
					//increase number of bones in slot 1 with priority of priority of bone
					++bpc[aslot_action][p_aslot[aslot_action]->priority[b]];
					//increase number of bones in slot 1
					++bpc[aslot_action][21];
				}
			}

		//that's bullshite because the cki of all bones
		//is not to be set to the most advanced cki of the animation
		//but to the cki of the bone(s) with the highest priority
		//
		//only true for aslot_action
		//aslot_cycle gets the highest general cki
		//else walking with another action in action_slot will never
		//advance

/*		//holds most advanced keyframe for both slots
		int makf[2] = {0};
		//for cycle and action slot
		for (register int s = 0; s < 2; ++s)
			//for every bone
			for (b = 0; b < 21; ++b)
				//if bone not hit
				if (bhi[b] != 1)
					//set highest cki
					if (casi[b] == s && cki[b] > makf[s])
						makf[s] = cki[b];
		//set cki of all bones to highest cki in slot
		for (s = 0; s < 2; ++s)
			for (b = 0; b < 21; ++b)
				//if bone not hit
				if (bhi[b] != 1)
					if (casi[b] == s)
						cki[b] = makf[s];*/

		//that's also kinda bullshite
		//if an animation is running and a bone is assigned to it from another
		//animation slot it should get the (highest) current keyframe index (cki)
		//of the bones with the same priority as his
		//
		//in this version the highest cki of the bone with the highest priority
		//is assigned to all bones

		//get highest cki of bone with highest priority (alsot_action)
		//get highest cki of slot (aslot_cycle)
				
		//highest priority (for both slots)
		int	hp[2]		= {0};
		//current keyframe index of bone(s) with highest priority
		int cki_p[2]	= {0};

		//for cycle and action slot
		for (register int s = 0; s < 2; ++s)
			//get bone with highest priority
			for (b = 0; b < 21; ++b)
				//if bone not hit
				if (bhi[b] != 1)
					if (s == aslot_cycle)
					{
						//if bone belongs to current slot
						//and cki of bone is higher than highest registered cki
						if (casi[b] == s &&
							cki[b] > cki_p[s])
							cki_p[s] = cki[b];
					}
					else
					{
						//if bone belongs to current slot and
						//bones priority is higher than highest registered priority
						//or bone has same priority but his cki is higher than
						//highest registered cki
						if (casi[b] == s &&
							(p_aslot[s]->priority[b] > hp[s] ||
							(p_aslot[s]->priority[b] == hp[s] && cki[b] > cki_p[s])))
						{
							//get new highest priority
							hp[s]		= p_aslot[s]->priority[b];
							//get current keyframe index of bone
							cki_p[s]	= cki[b];
						}
					}

		//set cki of all bones that changed
		for (s = 0; s < 2; ++s)
			for (b = 0; b < 21; ++b)
				//if bone changed
				if (bcflag[b] == 1)
					//if bone not hit
					if (bhi[b] != 1)
						if (casi[b] == s)
						{
							cki[b] = cki_p[s];
						}

		//set cd_state (depends on priority)
		gl_set_cd_state();

		return;
	}

	//---- only cycle slot active ----------------------------------------------------------------

	//assign all bones that aren't to cycle slot

	//cycle slot active
	if (p_aslot[aslot_cycle] != NULL)
	{
		//for all bones
		for (register int b = 0; b < 21; ++b)
		{
			//if bone not hit
			if (bhi[b] != 1)
			{
				//if bone not assigned to cycle slot
				if (casi[b] != aslot_cycle)
				{
					//reset cki of bone
					cki[b]		= 0;
					//set change flag
					bcflag[b]	= 1;
				}

				//set casi to active slot
				casi[b] = aslot_cycle;
				//increase number of bones in active slot with priority of priority of bone
				++bpc[aslot_cycle][p_aslot[aslot_cycle]->priority[b]];
				//increase number of bones in active slot
				++bpc[aslot_cycle][21];
			}
		}

/*		//holds most advanced keyframe in active slot
		int makf = 0;
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
				if (cki[b] > makf)
					makf = cki[b];

		//set cki of all bones to highest cki in slot
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
				cki[b] = makf;*/

		//get highest cki of animation

		//current keyframe index of bone(s) with highest priority
		int cki_p	= 0;

		//get bone with highest priority
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
			{
				//if cki of bone is higher than highest registered cki
				//save new highest cki
				if (cki[b] > cki_p)
					cki_p = cki[b];
			}

		//set cki of all bones that changed to highest cki in slot
		for (b = 0; b < 21; ++b)
			//if bone changed
			if (bcflag[b] == 1)
				//if bone not hit
				if (bhi[b] != 1)
					cki[b] = cki_p;

		//set cd_state
		gl_set_cd_state();

		return;
	}

	//---- only action slot active ---------------------------------------------------------------

	//assign all bones that aren't to action slot

	//action slot active
	if (p_aslot[aslot_action] != NULL)
	{
		//for all bones
		for (register int b = 0; b < 21; ++b)
		{
			//if bone not hit
			if (bhi[b] != 1)
			{
				//if bone not assigned to action slot
				if (casi[b] != aslot_action)
				{
					//reset cki of bone
					cki[b]		= 0;
					//set change flag
					bcflag[b]	= 1;
				}

				//set casi to active slot
				casi[b] = aslot_action;
				//increase number of bones in active slot with priority of priority of bone
				++bpc[aslot_action][p_aslot[aslot_action]->priority[b]];
				//increase number of bones in active slot
				++bpc[aslot_action][21];
			}
		}

/*		//holds most advanced keyframe in active slot
		int makf = 0;
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
				if (cki[b] > makf)
					makf = cki[b];

		//set cki of all bones to highest cki in slot
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
				cki[b] = makf;*/

		//get highest cki of bone with highest priority

		//highest priority
		int	hp		= 0;
		//current keyframe index of bone(s) with highest priority
		int cki_p	= 0;

		//get bone with highest priority
		for (b = 0; b < 21; ++b)
			//if bone not hit
			if (bhi[b] != 1)
			{
				//if bones priority is higher than highest registered priority
				//ore bone has same priority but his cki is higher than
				//highest registered cki
				if (p_aslot[aslot_action]->priority[b] > hp ||
					(p_aslot[aslot_action]->priority[b] == hp &&
					cki[b] > cki_p))
				{
					//get new highest priority
					hp		= p_aslot[aslot_action]->priority[b];
					//get current keyframe index of bone
					cki_p	= cki[b];
				}
			}

		//set cki of all bones that changed to highest cki of bone with highest priority
		for (b = 0; b < 21; ++b)
			//if bone changed
			if (bcflag[b] == 1)
				//if bone not hit
				if (bhi[b] != 1)
				{
					cki[b] = cki_p;
				}

		//set cd_state
		gl_set_cd_state();

		return;
	}
}

//------------------------------------------------------------------------------------------------
//
//	player al_create_idle_cycle
//
//	creates idle cycling in dependence of fatigue
//	(the more fatigue the heavier the player "breathes")
//
//------------------------------------------------------------------------------------------------

void player::al_create_idle_cycle(int type,			//0 = for upper body
													//1 = for lower body
								  int fast_kf)		//!!
{
	/*
		set		x		y
		0		-3		-1
		1		-3		0
		2		-3		1
		3		-2		-1
		4		-2		0
		5		-2		1
		6		-1		-1
		7		-1		0
		8		-1		1
		9		0		-1
		10		0		0
		11		0		1
		12		1		-1
		13		1		0
		14		1		1
		15		2		-1
		16		2		0
		17		2		1
		18		3		-1
		19		3		0
		20		3		1
	*/

	//indices for idle_sets animation
	//x(-3) = index 0
	//y(-1) = index 0
	int hara_set[7][3] = {0, 1, 2,
						  3, 4, 5,
						  6, 7, 8,
						  9, 10, 11,
						  12, 13, 14,
						  15, 16, 17,
						  18, 19, 20};

	//---- cd state ------------------------------------------------------------------------------

	//for all 3 stance arms heights for asi 0
	//(bsl, baul, ball, bsr, baur, balr)
	int defstate[3][6]	= {cds_defpart, cds_hit, cds_hit, cds_hit, cds_hit, cds_defpart_e,
						   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_defpart,
						   cds_hit, cds_hit, cds_defpart, cds_hit, cds_hit, cds_hit};

	//for all asi, for 3 stance arms heights
	int set	= 0;
	if (stance_arms > 70)						set = 0;
	if (stance_arms > 30 && stance_arms <= 70)	set = 1;
	if (stance_arms <= 30)						set = 2;
	if (asi == 0 || asi == 2)
	{
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[bsl]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[bsl]		= defstate[set][0];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[baul]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[baul]	= defstate[set][1];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball]	= defstate[set][2];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[bsr]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[bsr]		= defstate[set][3];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[baur]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[baur]	= defstate[set][4];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr]	= defstate[set][5];
	}
	else
	{
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[bsl]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[bsl]		= defstate[set][3];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[baul]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[baul]	= defstate[set][4];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball]	= defstate[set][5];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[bsr]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[bsr]		= defstate[set][0];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[baur]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[baur]	= defstate[set][1];
		p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr]	= p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr]	= defstate[set][2];
	}

	//---- upper body ----------------------------------------------------------------------------
	if (type == 0)
	{
		//create first keyframe depending on stance_arms for all sides and stances

		//hi guard
		if (stance_arms > 70)
		{
			if (side == SLEFT)
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
					//(also set for lower part)
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart_e;

/*					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 29 - (25.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 86 - (0.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 301 - (10.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 166 + (8.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 72 - (11.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 293 - (10.0f / 29.0f) * (stance_arms - 71);*/
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 29 - (29.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 86 + (4.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 301 + (5.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 166 + (24.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 72 - (27.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 293 - (5.0f / 29.0f) * (stance_arms - 71);
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 166 + (24.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 72 - (27.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 293 - (5.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 29 - (29.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 86 + (4.0f / 29.0f) * (stance_arms - 71);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 301 + (5.0f / 29.0f) * (stance_arms - 71);
				}
			}
			else
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart_e;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (29 - (29.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (86 + (4.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (301 + (5.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (166 + (24.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (72 - (27.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (293 - (5.0f / 29.0f) * (stance_arms - 71));
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart_e;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (166 + (24.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (72 - (27.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (293 - (5.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (29 - (29.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (86 + (4.0f / 29.0f) * (stance_arms - 71));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (301 + (5.0f / 29.0f) * (stance_arms - 71));
				}

				//check angle limits
				for (register int i = 0; i < 19; ++i)
				{
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] -= 360;
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] += 360;
				}
			}
		}
		//mi guard
		if (stance_arms > 30 && stance_arms <= 70)
		{
			if (side == SLEFT)
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 24 - (5.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 99 - (13.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 18 - (77.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 166 + (0.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 84 - (12.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 317 - (24.0f / 39.0f) * (stance_arms - 31);
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 166 + (0.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 84 - (12.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 317 - (24.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 24 - (5.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 99 - (13.0f / 39.0f) * (stance_arms - 31);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 18 - (77.0f / 39.0f) * (stance_arms - 31);
				}
			}
			else
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (24 - (5.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (99 - (13.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (18 - (77.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (166 + (0.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (84 - (12.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (317 - (24.0f / 39.0f) * (stance_arms - 31));
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (166 + (0.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (84 - (12.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (317 - (24.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (24 - (5.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (99 - (13.0f / 39.0f) * (stance_arms - 31));
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (18 - (77.0f / 39.0f) * (stance_arms - 31));
				}

				for (register int i = 0; i < 19; ++i)
				{
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] -= 360;
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] += 360;
				}
			}
		}
		//lo guard
		if (stance_arms <= 30)
		{
			if (side == SLEFT)
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 32 - (8.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 94 + (5.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 36 - (18.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 164 + (2.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 93 - (9.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 330 - (13.0f / 30.0f) * stance_arms;
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 164 + (2.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 93 - (9.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 330 - (13.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 32 - (8.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 94 + (5.0f / 30.0f) * stance_arms;
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 36 - (18.0f / 30.0f) * stance_arms;
				}
			}
			else
			{
				if (stance_feet == SLEFT)
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_hit;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (32 - (8.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (94 + (5.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (36 - (18.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (164 + (2.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (93 - (9.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (330 - (13.0f / 30.0f) * stance_arms);
				}
				else
				{
					//set game logic data
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_HI]->gl_bcds_def[balr] = cds_defpart;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[ball] = cds_hit;
//					p_anmn[asi][AN_IDLE_LO]->gl_bcds_def[balr] = cds_defpart;

					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl]	= 180 - (164 + (2.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul]	= 180 - (93 - (9.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball]	= 180 - (330 - (13.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr]	= 180 - (32 - (8.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur]	= 180 - (94 + (5.0f / 30.0f) * stance_arms);
					p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr]	= 180 - (36 - (18.0f / 30.0f) * stance_arms);
				}

				for (register int i = 0; i < 19; ++i)
				{
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] -= 360;
					if (p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[i] += 360;
				}
			}
		}

		//create random movement for upper and lower arm
		//for all 3 remaining keyframes
		for (register int i = 1; i < 4; ++i)
		{
			if (side == SLEFT)
			{
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[baul]	= 0 + (rand() % (8 - 0 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul];
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[ball]	= 0 + (rand() % (8 - 0 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball];
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[baur]	= 0 + (rand() % (8 - 0 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur];
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[balr]	= 0 + (rand() % (8 - 0 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr];

//				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[btul] = -2 + (rand() % (2 - -2 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul];
//				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[btur] = -2 + (rand() % (2 - -2 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur];
			}
			else
			{
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[baul]	= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baul] - (0 + (rand() % (8 - 0 + 1)));
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[ball]	= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[ball] - (0 + (rand() % (8 - 0 + 1)));
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[baur]	= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[baur] - (0 + (rand() % (8 - 0 + 1)));
				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[balr]	= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[balr] - (0 + (rand() % (8 - 0 + 1)));

//				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[btul] = -2 + (rand() % (2 - -2 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul];
//				p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[btur] = -2 + (rand() % (2 - -2 + 1)) + p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur];
			}

			//check angle limits
			for (register int b = 0; b < 19; ++b)
			{
				if (p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[b] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[b] -= 360;
				if (p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[b] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[i].angle[b] += 360;
			}
		}

		//shoulders breathing depending on fatigue
		//also upper torso
		if (side == SLEFT)
		{
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] - 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] + 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] - 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] + 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] + 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] - 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);

			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] - 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] - 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] - 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] - 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] + 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] + 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		}
		else
		{
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] + 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] - 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] + 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] - 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsl] - 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[bsr] + 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);

			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] + 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] + 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] + 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] + 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btul]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btul] - 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btur]		= p_anmn[asi][AN_IDLE_HI]->pkf[0].angle[btur] - 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		}
		//check limits
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsl] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[bsr] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btul] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btul] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btur] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[1].angle[btur] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsl] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[bsr] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btul] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btul] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btur] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[2].angle[btur] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsl] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr] < 0)			p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[bsr] += 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btul] > 359)		p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btul] -= 360;
		if (p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btur] < 0)		p_anmn[asi][AN_IDLE_HI]->pkf[3].angle[btur] += 360;

		//set keyframe speed of animation depending on fatigue
		//(random tolerance)
		for (i = 0; i < 4; ++i)
			for (register int b = 0; b < 21; ++b)
				p_anmn[asi][AN_IDLE_HI]->pkf[i].t_frame[b]		= (int)(250.0f / ((fatigue / 100.0f) * 1.0f + 1.0f));

		//if fast keyframe
		if (fast_kf)
			//increase speed so that change of arm guard is displayed immediately
			//or player returns to default position after an action
			for (i = 0; i < 21; ++i)
				p_anmn[asi][AN_IDLE_HI]->pkf[0].t_frame[i] = fast_kf;
	}
	else
	//---- lower body ----------------------------------------------------------------------------
	{
		//deflection in both dimensions for left/right, up/down
		int rn_x[2];
		int rn_y[2];

		//create random values for deflection
		//x movement
		rn_x[0]		= -3 + (rand() % (3 - (-3) + 1));
		rn_x[1]		= 0 + (rand() % (3 - 0 + 1));
		//if first one is positive negate second
		if (rn_x[0] >= 0)
			rn_x[1] = -rn_x[1];

		//y movement
		rn_y[0]		= -1 + (rand() % (1 - (-1) + 1));
		rn_y[1]		= 0 + (rand() % (1 - 0 + 1));
		if (rn_y[0] >= 0)
			rn_y[1] = -rn_y[1];

		//create cycle
		//for all four idle keyframes
		//hara_set holds the index of the keyframe in the idle_sets animation with
		//the right x and y index (increase the value because the value for x = -3 is index
		//0 of hara_set array)
		//first keyframe is first random created value
		p_anmn[asi][AN_IDLE_LO]->pkf[0] = p_anmn[asi][AN_IDLE_SETS]->pkf[hara_set[rn_x[0] + 3][rn_y[0] + 1]];
		//second keyframe is move back to default position
		p_anmn[asi][AN_IDLE_LO]->pkf[1] = p_anmn[asi][AN_IDLE_SETS]->pkf[10];
		//third keyframe is second random created value
		p_anmn[asi][AN_IDLE_LO]->pkf[2] = p_anmn[asi][AN_IDLE_SETS]->pkf[hara_set[rn_x[1] + 3][rn_y[1] + 1]];
		//fourth is move back to default position
		p_anmn[asi][AN_IDLE_LO]->pkf[3] = p_anmn[asi][AN_IDLE_SETS]->pkf[10];

		//assign hara values for default position
		//(negated value of deflection)
		if (side == SLEFT)
		{
			p_anmn[asi][AN_IDLE_LO]->pkf[1].hara.x = (float)-rn_x[0];
			p_anmn[asi][AN_IDLE_LO]->pkf[1].hara.y = 0.0f;
			p_anmn[asi][AN_IDLE_LO]->pkf[3].hara.x = (float)-rn_x[1];
			p_anmn[asi][AN_IDLE_LO]->pkf[3].hara.y = 0.0f;
		}
		else
		{
			//x-values of idle_sets get reversed
			p_anmn[asi][AN_IDLE_LO]->pkf[1].hara.x = (float)rn_x[0];
			p_anmn[asi][AN_IDLE_LO]->pkf[1].hara.y = 0.0f;
			p_anmn[asi][AN_IDLE_LO]->pkf[3].hara.x = (float)rn_x[1];
			p_anmn[asi][AN_IDLE_LO]->pkf[3].hara.y = 0.0f;
		}

		//set keyframe speed depending on fatigue
		//(random tolerance)
		for (register int i = 0; i < 4; ++i)
			for (register int b = 0; b < 21; ++b)
				p_anmn[asi][AN_IDLE_LO]->pkf[i].t_frame[b]		= (int)(350.0f / ((fatigue / 100.0f) * 1.0f + 1.0f));

		//if fast keyframe
		if (fast_kf)
			//increase speed so that change of arm guard is displayed immediately
			//or player returns to default position after an action
			for (i = 0; i < 21; ++i)
				p_anmn[asi][AN_IDLE_LO]->pkf[0].t_frame[i] = fast_kf;
	}
}

//------------------------------------------------------------------------------------------------
//
//	player al_create_walk_cycle
//
//	adjusts positions of arms in walk animation according to stance_arms
//
//------------------------------------------------------------------------------------------------

void player::al_create_walk_cycle(int direction, float speedfactor)
{
	//---- cd state ------------------------------------------------------------------------------

	//for all 3 stance arms heights for asi 0
	//(bsl, baul, ball, bsr, baur, balr)
	int defstate[3][6]	= {cds_defpart, cds_hit, cds_hit, cds_hit, cds_hit, cds_defpart_e,
						   cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_defpart,
						   cds_hit, cds_hit, cds_defpart, cds_hit, cds_hit, cds_hit};

	//for all asi, for 3 stance arms heights
	int set	= 0;
	if (stance_arms > 70)						set = 0;
	if (stance_arms > 30 && stance_arms <= 70)	set = 1;
	if (stance_arms <= 30)						set = 2;
	if (asi == 0 || asi == 2)
	{
		p_anmn[asi][direction]->gl_bcds_def[bsl]	= defstate[set][0];
		p_anmn[asi][direction]->gl_bcds_def[baul]	= defstate[set][1];
		p_anmn[asi][direction]->gl_bcds_def[ball]	= defstate[set][2];
		p_anmn[asi][direction]->gl_bcds_def[bsr]	= defstate[set][3];
		p_anmn[asi][direction]->gl_bcds_def[baur]	= defstate[set][4];
		p_anmn[asi][direction]->gl_bcds_def[balr]	= defstate[set][5];
	}
	else
	{
		p_anmn[asi][direction]->gl_bcds_def[bsl]	= defstate[set][3];
		p_anmn[asi][direction]->gl_bcds_def[baul]	= defstate[set][4];
		p_anmn[asi][direction]->gl_bcds_def[ball]	= defstate[set][5];
		p_anmn[asi][direction]->gl_bcds_def[bsr]	= defstate[set][0];
		p_anmn[asi][direction]->gl_bcds_def[baur]	= defstate[set][1];
		p_anmn[asi][direction]->gl_bcds_def[balr]	= defstate[set][2];
	}

	//--------------------------------------------------------------------------------------------

	//hi guard
	if (stance_arms > 70)
	{
		if (side == SLEFT)
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart_e;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 29 - (29.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 86 + (4.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 301 + (5.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 166 + (24.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 72 - (27.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 293 - (5.0f / 29.0f) * (stance_arms - 71);
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart_e;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 166 + (24.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 72 - (27.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 293 - (5.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 29 - (29.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 86 + (4.0f / 29.0f) * (stance_arms - 71);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 301 + (5.0f / 29.0f) * (stance_arms - 71);
			}
		}
		else
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart_e;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (29 - (29.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (86 + (4.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (301 + (5.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (166 + (24.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (72 - (27.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (293 - (5.0f / 29.0f) * (stance_arms - 71));
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart_e;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (166 + (24.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (72 - (27.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (293 - (5.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (29 - (29.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (86 + (4.0f / 29.0f) * (stance_arms - 71));
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (301 + (5.0f / 29.0f) * (stance_arms - 71));
			}

			//check angle limits
			for (register int i = 0; i < 19; ++i)
			{
			if (p_anmn[asi][direction]->pkf[0].angle[i] > 359)		p_anmn[asi][direction]->pkf[0].angle[i] -= 360;
				if (p_anmn[asi][direction]->pkf[0].angle[i] < 0)		p_anmn[asi][direction]->pkf[0].angle[i] += 360;
			}
		}
	}
	//mi guard
	if (stance_arms > 30 && stance_arms <= 70)
	{
		if (side == SLEFT)
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 24 - (5.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 99 - (13.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 18 - (77.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 166 + (0.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 84 - (12.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 317 - (24.0f / 39.0f) * (stance_arms - 31);
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 166 + (0.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 84 - (12.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 317 - (24.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 24 - (5.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 99 - (13.0f / 39.0f) * (stance_arms - 31);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 18 - (77.0f / 39.0f) * (stance_arms - 31);
			}
		}
		else
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (24 - (5.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (99 - (13.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (18 - (77.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (166 + (0.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (84 - (12.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (317 - (24.0f / 39.0f) * (stance_arms - 31));
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (166 + (0.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (84 - (12.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (317 - (24.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (24 - (5.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (99 - (13.0f / 39.0f) * (stance_arms - 31));
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (18 - (77.0f / 39.0f) * (stance_arms - 31));
			}

			for (register int i = 0; i < 19; ++i)
			{
				if (p_anmn[asi][direction]->pkf[0].angle[i] > 359)		p_anmn[asi][direction]->pkf[0].angle[i] -= 360;
				if (p_anmn[asi][direction]->pkf[0].angle[i] < 0)		p_anmn[asi][direction]->pkf[0].angle[i] += 360;
			}
		}
	}
	//lo guard
	if (stance_arms <= 30)
	{
		if (side == SLEFT)
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 32 - (8.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 94 + (5.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 36 - (18.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 164 + (2.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 93 - (9.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 330 - (13.0f / 30.0f) * stance_arms;
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 164 + (2.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 93 - (9.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 330 - (13.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 32 - (8.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 94 + (5.0f / 30.0f) * stance_arms;
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 36 - (18.0f / 30.0f) * stance_arms;
			}
		}
		else
		{
			if (stance_feet == SLEFT)
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_defpart;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_hit;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (32 - (8.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (94 + (5.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (36 - (18.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (164 + (2.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (93 - (9.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (330 - (13.0f / 30.0f) * stance_arms);
			}
			else
			{
				//set game logic data
//				p_anmn[asi][direction]->gl_bcds_def[ball] = cds_hit;
//				p_anmn[asi][direction]->gl_bcds_def[balr] = cds_defpart;

				p_anmn[asi][direction]->pkf[0].angle[bsl]	= 180 - (164 + (2.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[baul]	= 180 - (93 - (9.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[ball]	= 180 - (330 - (13.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[bsr]	= 180 - (32 - (8.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[baur]	= 180 - (94 + (5.0f / 30.0f) * stance_arms);
				p_anmn[asi][direction]->pkf[0].angle[balr]	= 180 - (36 - (18.0f / 30.0f) * stance_arms);
			}

			for (register int i = 0; i < 19; ++i)
			{
				if (p_anmn[asi][direction]->pkf[0].angle[i] > 359)		p_anmn[asi][direction]->pkf[0].angle[i] -= 360;
				if (p_anmn[asi][direction]->pkf[0].angle[i] < 0)		p_anmn[asi][direction]->pkf[0].angle[i] += 360;
			}
		}
	}

	//arm movement
	if (side == SLEFT)
	{
		if (stance_feet == SLEFT)
		{
			p_anmn[asi][direction]->pkf[1].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[1].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 8;
			p_anmn[asi][direction]->pkf[1].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 5;
			p_anmn[asi][direction]->pkf[1].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[1].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 5;
			p_anmn[asi][direction]->pkf[1].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 5;

			p_anmn[asi][direction]->pkf[2].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[2].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[2].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 0;

			p_anmn[asi][direction]->pkf[3].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[3].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 8;
			p_anmn[asi][direction]->pkf[3].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 5;
			p_anmn[asi][direction]->pkf[3].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[3].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 5;
			p_anmn[asi][direction]->pkf[3].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 0;
		}
		else
		{
			p_anmn[asi][direction]->pkf[1].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[1].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 8;
			p_anmn[asi][direction]->pkf[1].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 5;
			p_anmn[asi][direction]->pkf[1].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[1].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 5;
			p_anmn[asi][direction]->pkf[1].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 5;

			p_anmn[asi][direction]->pkf[2].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[2].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[2].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 0;
			p_anmn[asi][direction]->pkf[2].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 0;

			p_anmn[asi][direction]->pkf[3].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		+ 0;
			p_anmn[asi][direction]->pkf[3].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 8;
			p_anmn[asi][direction]->pkf[3].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	+ 5;
			p_anmn[asi][direction]->pkf[3].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		+ 0;
			p_anmn[asi][direction]->pkf[3].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 5;
			p_anmn[asi][direction]->pkf[3].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	+ 0;
		}
	}
	else
	{
		if (stance_feet == SLEFT)
		{
			p_anmn[asi][direction]->pkf[1].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[1].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 8;
			p_anmn[asi][direction]->pkf[1].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 5;
			p_anmn[asi][direction]->pkf[1].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[1].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 5;
			p_anmn[asi][direction]->pkf[1].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 5;

			p_anmn[asi][direction]->pkf[2].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[2].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[2].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 0;

			p_anmn[asi][direction]->pkf[3].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[3].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 8;
			p_anmn[asi][direction]->pkf[3].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 5;
			p_anmn[asi][direction]->pkf[3].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[3].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 5;
			p_anmn[asi][direction]->pkf[3].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 0;
		}
		else
		{
			p_anmn[asi][direction]->pkf[1].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[1].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 8;
			p_anmn[asi][direction]->pkf[1].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 5;
			p_anmn[asi][direction]->pkf[1].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[1].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	+ 5;
			p_anmn[asi][direction]->pkf[1].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 5;

			p_anmn[asi][direction]->pkf[2].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[2].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[2].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 0;
			p_anmn[asi][direction]->pkf[2].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 0;

			p_anmn[asi][direction]->pkf[3].angle[bsl]	= p_anmn[asi][direction]->pkf[0].angle[bsl]		- 0;
			p_anmn[asi][direction]->pkf[3].angle[baul]	= p_anmn[asi][direction]->pkf[0].angle[baul]	+ 8;
			p_anmn[asi][direction]->pkf[3].angle[ball]	= p_anmn[asi][direction]->pkf[0].angle[ball]	- 5;
			p_anmn[asi][direction]->pkf[3].angle[bsr]	= p_anmn[asi][direction]->pkf[0].angle[bsr]		- 0;
			p_anmn[asi][direction]->pkf[3].angle[baur]	= p_anmn[asi][direction]->pkf[0].angle[baur]	- 5;
			p_anmn[asi][direction]->pkf[3].angle[balr]	= p_anmn[asi][direction]->pkf[0].angle[balr]	- 0;
		}
	}

	//check angle limits
	for (register int k = 1; k < 4; ++k)
		for (register int b = 0; b < 19; ++b)
		{
			if (p_anmn[asi][direction]->pkf[k].angle[b] > 359)		p_anmn[asi][direction]->pkf[k].angle[b] -= 360;
			if (p_anmn[asi][direction]->pkf[k].angle[b] < 0)		p_anmn[asi][direction]->pkf[k].angle[b] += 360;
		}

	//shoulders breathing depending on fatigue
	//also upper torso
	if (side == SLEFT)
	{
		p_anmn[asi][direction]->pkf[1].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] - 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[1].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] + 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] - 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] + 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] + 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] - 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);

		p_anmn[asi][direction]->pkf[1].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] - 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[1].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] - 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] - 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] - 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] + 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] + 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
	}
	else
	{
		p_anmn[asi][direction]->pkf[1].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] + 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[1].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] - 12 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] + 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] - 3 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[bsl]		= p_anmn[asi][direction]->pkf[0].angle[bsl] - 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[bsr]		= p_anmn[asi][direction]->pkf[0].angle[bsr] + 4 * ((fatigue / 100.0f) * 1.5f + 1.0f);

		p_anmn[asi][direction]->pkf[1].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] + 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[1].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] + 1 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] + 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[2].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] + 0.5f * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[btul]		= p_anmn[asi][direction]->pkf[0].angle[btul] - 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
		p_anmn[asi][direction]->pkf[3].angle[btur]		= p_anmn[asi][direction]->pkf[0].angle[btur] - 2 * ((fatigue / 100.0f) * 1.5f + 1.0f);
	}
	//check limits
	if (p_anmn[asi][direction]->pkf[1].angle[bsl] > 359)		p_anmn[asi][direction]->pkf[1].angle[bsl] -= 360;
	if (p_anmn[asi][direction]->pkf[1].angle[bsl] < 0)			p_anmn[asi][direction]->pkf[1].angle[bsl] += 360;
	if (p_anmn[asi][direction]->pkf[1].angle[bsr] > 359)		p_anmn[asi][direction]->pkf[1].angle[bsr] -= 360;
	if (p_anmn[asi][direction]->pkf[1].angle[bsr] < 0)			p_anmn[asi][direction]->pkf[1].angle[bsr] += 360;
	if (p_anmn[asi][direction]->pkf[2].angle[bsl] > 359)		p_anmn[asi][direction]->pkf[2].angle[bsl] -= 360;
	if (p_anmn[asi][direction]->pkf[2].angle[bsl] < 0)			p_anmn[asi][direction]->pkf[2].angle[bsl] += 360;
	if (p_anmn[asi][direction]->pkf[2].angle[bsr] > 359)		p_anmn[asi][direction]->pkf[2].angle[bsr] -= 360;
	if (p_anmn[asi][direction]->pkf[2].angle[bsr] < 0)			p_anmn[asi][direction]->pkf[2].angle[bsr] += 360;
	if (p_anmn[asi][direction]->pkf[3].angle[bsl] > 359)		p_anmn[asi][direction]->pkf[3].angle[bsl] -= 360;
	if (p_anmn[asi][direction]->pkf[3].angle[bsl] < 0)			p_anmn[asi][direction]->pkf[3].angle[bsl] += 360;
	if (p_anmn[asi][direction]->pkf[3].angle[bsr] > 359)		p_anmn[asi][direction]->pkf[3].angle[bsr] -= 360;
	if (p_anmn[asi][direction]->pkf[3].angle[bsr] < 0)			p_anmn[asi][direction]->pkf[3].angle[bsr] += 360;
	if (p_anmn[asi][direction]->pkf[1].angle[btul] > 359)		p_anmn[asi][direction]->pkf[1].angle[btul] -= 360;
	if (p_anmn[asi][direction]->pkf[1].angle[btur] < 0)			p_anmn[asi][direction]->pkf[1].angle[btur] += 360;
	if (p_anmn[asi][direction]->pkf[2].angle[btul] > 359)		p_anmn[asi][direction]->pkf[2].angle[btul] -= 360;
	if (p_anmn[asi][direction]->pkf[2].angle[btur] < 0)			p_anmn[asi][direction]->pkf[2].angle[btur] += 360;
	if (p_anmn[asi][direction]->pkf[3].angle[btul] > 359)		p_anmn[asi][direction]->pkf[3].angle[btul] -= 360;
	if (p_anmn[asi][direction]->pkf[3].angle[btur] < 0)			p_anmn[asi][direction]->pkf[3].angle[btur] += 360;

	/*/!! will be overwritten below anyway
	//set keyframe speed for arms
	for (register int i = 0; i < 4; ++i)
	{
		p_anmn[asi][direction]->pkf[i].t_frame[bsl]		= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[baul]	= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[ball]	= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[bsr]		= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[baur]	= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[balr]	= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[btul]	= 90;
		p_anmn[asi][direction]->pkf[i].t_frame[btur]	= 90;
	}*/

	//minimum walk speed
	if (speedfactor < 0.05f)
		speedfactor = 0.05f;

	/*/set speedfactor keyframe speed
	for (k = 0; k < 4; ++k)
	{
		p_anmn[asi][direction]->pkf[k].t_frame[bhl]		= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[blul]	= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[blll]	= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[bfl]		= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[bhr]		= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[blur]	= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[bllr]	= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[bfr]		= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[IHX]		= (int)(100.0f / speedfactor);
		p_anmn[asi][direction]->pkf[k].t_frame[IHY]		= (int)(100.0f / speedfactor);
	}*/
	//set keyframe time for all bones/hara depending on speedfactor
//!!	for (k = 0; k < 4; ++k)
//		for (register int i = 0; i < 21; ++i)
//			p_anmn[asi][direction]->pkf[k].t_frame[i]	= (int)(110.0f / speedfactor);

	//for all keyframes, for all bones and hara, set t_frame depending on speedfactor
	for (k = 0; k < 4; ++k)
		for (register int b = 0; b < 21; ++b)
		{
			if (direction == AN_WALK_BWD)
				p_anmn[asi][AN_WALK_BWD]->pkf[k].t_frame[b]		= (int)(walk_kftb_bwd[k][b] / speedfactor);
			if (direction == AN_WALK_FWD)
				p_anmn[asi][AN_WALK_FWD]->pkf[k].t_frame[b]		= (int)(walk_kftb_fwd[k][b] / speedfactor);
			//70/40
			if (direction == AN_WALK_SLIDE_BWD)
				if (k < 3)
					p_anmn[asi][AN_WALK_SLIDE_BWD]->pkf[k].t_frame[b]		= (int)(70 / speedfactor);
				else
					p_anmn[asi][AN_WALK_SLIDE_BWD]->pkf[k].t_frame[b]		= (int)(40 / speedfactor);
			if (direction == AN_WALK_SLIDE_FWD)
				if (k < 3)
					p_anmn[asi][AN_WALK_SLIDE_FWD]->pkf[k].t_frame[b]		= (int)(70 / speedfactor);
				else
					p_anmn[asi][AN_WALK_SLIDE_FWD]->pkf[k].t_frame[b]		= (int)(40 / speedfactor);
		}
}

//------------------------------------------------------------------------------------------------
//
//	player al_adjust_walk_cycle
//
//	adjusts speed of walking animation keyframes during acceleration
//
//------------------------------------------------------------------------------------------------

void player::al_adjust_walk_cycle(int direction, float speedfactor)
{
	//minimum walk speed
	if (speedfactor < 0.05f)
		speedfactor = 0.05f;

	//set keyframe time for all bones/hara depending on speedfactor
//	for (register int k = 0; k < 4; ++k)
//		for (register int i = 0; i < 21; ++i)
//			p_anmn[asi][direction]->pkf[k].t_frame[i]	= (int)(110.0f / speedfactor);
	//for all keyframes, for all bones and hara, set t_frame depending on speedfactor
	for (register int k = 0; k < 4; ++k)
		for (register int b = 0; b < 21; ++b)
		{
			if (direction == AN_WALK_BWD)
				p_anmn[asi][AN_WALK_BWD]->pkf[k].t_frame[b]		= (int)(walk_kftb_bwd[k][b] / speedfactor);
			if (direction == AN_WALK_FWD)
				p_anmn[asi][AN_WALK_FWD]->pkf[k].t_frame[b]		= (int)(walk_kftb_fwd[k][b] / speedfactor);
		}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_process_input
//
//	called once per frame
//	handles player input and activates appropriate animations
//
//------------------------------------------------------------------------------------------------

void player::gl_process_input(int PA[2][NPAN],				//inputstate data
							  int angle[2],
							  int angle_180[2],
							  float t_move[2][2])
{
	//---- player message ------------------------------------------------------------------------

	//update player message
//	pmessage.update(p_time->current, p_time->freq, sk.chead);
	pmessage.update(p_time->current, p_time->freq, (float)p_time->sca, sk.chead);

	//if ko pending show exclamation mark
	if (gl_ko_pending)
		pmessage.set_message(PM_KO, red, "!");

	//play ko pending sound if ko pending but not already ko
	//and sound not already playing
	if (gl_ko_pending && !gl_ko)
		s_set_sound(S_HEALTH, SB_PLAY_NP);

	//---- knockout ------------------------------------------------------------------------------

	if (gl_ko)
	{
		//if not already knockout animation
		if (p_aslot[aslot_action] != p_anmn[asi][AN_KNOCKOUT])
		{
			al_activate_slot(aslot_action, AN_KNOCKOUT);
			al_deactivate_slot(aslot_cycle);
		}

		return;
	}

	//---- bone lock state -----------------------------------------------------------------------

	gl_SetBoneLockState(false);

/*	//---- keyframe advancing --------------------------------------------------------------------
	//if bone hit bone in cd defense mode attack animation may be cancelled

	//if animation in slot 0 set to advance
	if (advance_slot[0] == 1)
	{
		//for all bones and hara
		for (register int b = 0; b < 21; ++b)
			//if not already reached last keyframe
			if (casi[b] == 0 && cki[b] < p_aslot[0]->nokf - 1)
			{
				//reset state of current keyframe, increase keyframe
				p_aslot[0]->pkf[cki[b]].state[id][b] = 0;
				++cki[b];
			}

		//slow animation down
		p_aslot[0]->speedfactor[id] = 1.5f;

		//reset advance flag
		advance_slot[0] = 0;
	}
	//if animation in slot 1 set to advance
	if (advance_slot[1] == 1)
	{
		for (register int b = 0; b < 21; ++b)
			if (casi[b] == 1 && cki[b] < p_aslot[1]->nokf - 1)
			{
				p_aslot[1]->pkf[cki[b]].state[id][b] = 0;
				++cki[b];
			}

		//slow animation down
		p_aslot[1]->speedfactor[id] = 1.5f;

		advance_slot[1] = 0;
	}*/

	//---- cancel action -------------------------------------------------------------------------

	//if hit very hard actions in action_slot may be canceled
	if (cd_cancel_action == 1)
	{
		//if not empty or assigned with certain animation
		if (p_aslot[aslot_action] != NULL)
			if (p_aslot[aslot_action] != p_anmn[asi][AN_IDLE_LO] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_DUCK] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_HI_HOLD] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_EVADE_LO_HOLD] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_DUCK_HOLD] &&
				//p_aslot[aslot_action] != p_anmn[asi][AN_TAP_JAB] &&
				//p_aslot[aslot_action] != p_anmn[asi][AN_TAP_CROSS] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_TAP_ARMS] &&
				p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG])
			{
				//if animation not already on way back
				if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir != 1)
				{
					al_deactivate_slot(aslot_action);
					//set cancel sound
					s_set_sound(S_HIT_CANCEL);
					//change player message color
//					pmessage.change_format(0, 0, 0,
//										   192, 192, 192);
/*					//change player message color
					//or set message if no message already set
					if (!pmessage.change_format(0, 0, 0,
											   125, 125, 125))
						pmessage.set_message(0, 0, 0, 125, 125, 125,
											 0.35f,
											 0.8f / p_option->data.speed, p_time->current,
											 "CANCELED!");*/
				}
			}
		cd_cancel_action = 0;
	}

	//---- fight mode ----------------------------------------------------------------------------

	//boxing only
	if (p_option->data.fight_mode == FM_BOX)
	{
		PA[id][AN_KICK_FWD]			= AS_INACTIVE;
		PA[id][AN_KICK_KNEE]		= AS_INACTIVE;
		PA[id][AN_KICK_SWD]			= AS_INACTIVE;

		PA[id][AN_TAP_LEG]			= AS_INACTIVE;
		PA[id][AN_GUARD_LEGS]		= AS_INACTIVE;
		PA[id][AN_GUARD_FULL]		= AS_INACTIVE;
	}

	//kicking only
	if (p_option->data.fight_mode == FM_KICK)
	{
		PA[id][AN_JAB]				= AS_INACTIVE;
		PA[id][AN_JAB_HOOK]			= AS_INACTIVE;
		PA[id][AN_CROSS]			= AS_INACTIVE;
		PA[id][AN_CROSS_HOOK]		= AS_INACTIVE;

		//PA[id][AN_TAP_JAB]			= AS_INACTIVE;
		//PA[id][AN_TAP_CROSS]		= AS_INACTIVE;
		PA[id][AN_TAP_ARMS]			= AS_INACTIVE;
		PA[id][AN_GUARD_ARMS]		= AS_INACTIVE;
		PA[id][AN_GUARD_FULL]		= AS_INACTIVE;
	}

	//---- walking -------------------------------------------------------------------------------

	//walk slide
	//not guarding
	if (p_aslot[aslot_action] != p_anmn[asi][AN_GUARD_LEGS] &&
		p_aslot[aslot_action] != p_anmn[asi][AN_GUARD_FULL])
	{
		//not already active
		if (PA[id][AN_WALK_SLIDE_BWD] && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_SLIDE_BWD])
		{
			//deactivate walking
			PA[id][AN_WALK_BWD]	= AS_INACTIVE;
			PA[id][AN_WALK_FWD]	= AS_INACTIVE;

			//create walkcycle and activate animation with speedfactor
			al_create_walk_cycle(AN_WALK_SLIDE_BWD, 1.0f);
			al_activate_slot(aslot_cycle, AN_WALK_SLIDE_BWD, -1, -1, true);
		}
		if (PA[id][AN_WALK_SLIDE_FWD] && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_SLIDE_FWD])
		{
			//deactivate walking
			PA[id][AN_WALK_BWD]	= AS_INACTIVE;
			PA[id][AN_WALK_FWD]	= AS_INACTIVE;

			//create walkcycle and activate animation with speedfactor
			al_create_walk_cycle(AN_WALK_SLIDE_FWD, 1.0f);
			al_activate_slot(aslot_cycle, AN_WALK_SLIDE_FWD, -1, -1, true);
		}

		//cancel slide if walking in opposite direction
		if (PA[id][AN_WALK_BWD] == AS_ACTIVE &&
			p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
		{
			al_deactivate_slot(aslot_cycle);
			//inertia
			gl_SetPush(4, 0.10f, 0);
		}
		if (PA[id][AN_WALK_FWD] == AS_ACTIVE &&
			p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
		{
			al_deactivate_slot(aslot_cycle);
			//inertia
			gl_SetPush(2, 0.10f, 0);
		}
	}

	//deactivate walking while sliding
	if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD] ||
		p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
	{
		PA[id][AN_WALK_BWD]	= AS_INACTIVE;
		PA[id][AN_WALK_FWD]	= AS_INACTIVE;
	}
	//!! doesn't work
	/*/increase walking time if last animation was slide
	if (last_anmn[aslot_cycle] == AN_WALK_SLIDE_BWD)
	{
		if (t_move[id][0] < 1.0f)
			t_move[id][0]	= 1.0f;
	}
	if (last_anmn[aslot_cycle] == AN_WALK_SLIDE_FWD)
	{
		if (t_move[id][1] < 1.0f)
			t_move[id][1]	= 1.0f;
	}*/

	//walking lock
	//the movement at movement start can't be changed till animation done
	//(except for stopping)
	if (walk_lock)
	{
		//no slide when locked
		if (walk_lock)
		{
			PA[id][AN_WALK_SLIDE_FWD]	= AS_INACTIVE;
			PA[id][AN_WALK_SLIDE_BWD]	= AS_INACTIVE;
		}

		//if current animation walking
		if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
		{
			//non power attack
//			if (!p_aslot[aslot_action]->power_attack[id])
			//doesn't work because the power_attack flag in the animation also gets set
			//in case of lock_off (for return damage), which can lead to unwanted movement
			if (true)
			{
				//until on way back
	//			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0)
				//until before last keyframe
				if (cki[p_aslot[aslot_action]->ui_index] < p_aslot[aslot_action]->nokf - 1)
				{
					//fwd, no bwd
					if (walk_lock == 1)					PA[id][AN_WALK_BWD] = AS_INACTIVE;

					//bwd, no fwd
					if (walk_lock == 2)					PA[id][AN_WALK_FWD] = AS_INACTIVE;

					//not walking
					if (walk_lock == -1)
					{
						//change lock when starting to walk
						if (PA[id][AN_WALK_FWD] == AS_ACTIVE)	walk_lock = 1;
						if (PA[id][AN_WALK_BWD] == AS_ACTIVE)	walk_lock = 2;
						//reset move time
						t_move[id][0] = t_move[id][1] = 0;
					}
				}
				else
					walk_lock = 0;
			}
			else
			//power attack
			{
				//until on way back
	//			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0)
				//until before last keyframe
				if (cki[p_aslot[aslot_action]->ui_index] < p_aslot[aslot_action]->nokf - 1)
				{
					//fwd, no bwd, cont fwd
					if (walk_lock == 1)
					{
						PA[id][AN_WALK_BWD] = AS_INACTIVE;
						PA[id][AN_WALK_FWD]	= AS_ACTIVE;
						t_move[id][0]		= 0;
						t_move[id][1]		= 1.0f;
					}

					//bwd, no fwd, cont bwd
					if (walk_lock == 2)
					{
						PA[id][AN_WALK_BWD] = AS_ACTIVE;
						PA[id][AN_WALK_FWD] = AS_INACTIVE;
						t_move[id][0]		= 1.0f;
						t_move[id][1]		= 0;
					}

					//not walking
					if (walk_lock == -1)
					{
						PA[id][AN_WALK_BWD] = AS_INACTIVE;
						PA[id][AN_WALK_FWD] = AS_INACTIVE;
						t_move[id][0] = t_move[id][1] = 0;
					}
				}
				else
					walk_lock = 0;
			}
		}
		else
			walk_lock = 0;
	}

	//push force
	//if pushtime valid
	if (cd_t_pushhit + p_time->freq * (cd_push_force / p_option->data.speed) >= p_time->current)
	{
		//0 = stop player forward movement
		if (cd_push_type == 0)
			PA[id][AN_WALK_FWD] = AS_INACTIVE;

		//1 = push player backward, may be canceled to stop
		//when player hits forward
		if (cd_push_type == 1)
		{
			PA[id][AN_WALK_BWD] = AS_ACTIVE;
			//also set move time
			t_move[id][0] = 1.0f;

			//if player moving forward
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE)
			{
				//change push type to not forward
				cd_push_type = 0;

				//set to stop
				PA[id][AN_WALK_BWD] = AS_INACTIVE;
				PA[id][AN_WALK_FWD] = AS_INACTIVE;
			}
		}

		//2 = push player backwards, no canceling possible
		if (cd_push_type == 2)
		{
			//also set move time
			t_move[id][0] = 1.0f;
			PA[id][AN_WALK_BWD] = AS_ACTIVE;
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
		}

		//3 = drag player forwards, stoppable and reversable
		if (cd_push_type == 3)
		{
			//if player not moving, drag forward
			if (PA[id][AN_WALK_FWD]	== AS_INACTIVE &&
				PA[id][AN_WALK_BWD] == AS_INACTIVE)
			{
				PA[id][AN_WALK_FWD]	= AS_ACTIVE;
				//also set move time
				t_move[id][1]	= 0.05f;
			}
			else
			{
				//if already walking fwd
				//increase walking speed but don't adjust t_move
				if (PA[id][AN_WALK_FWD] == AS_ACTIVE)
				{
					cd_push_speed	= 20;
				}

				//if walking bwd
				//decrease walking speed but don't adjust t_move
				if (PA[id][AN_WALK_BWD]	== AS_ACTIVE)
				{
					cd_push_speed	= -20;
				}

				/*else
				{
					//reset push time
					cd_t_pushhit	= 0;
					//reset push type
					cd_push_type	= -1;
					//reset push force
					cd_push_force	= 0;
					//reset push speed
					cd_push_speed	= 0;
				}*/
			}
		}

		//4 = drag player forwards, no canceling
		if (cd_push_type == 4)
		{
			//also set move time
			t_move[id][1]	= 1.0f;
			PA[id][AN_WALK_FWD]		= AS_ACTIVE;
			PA[id][AN_WALK_BWD]		= AS_INACTIVE;
		}
	}
	else
	{
		//reset push data
		gl_ResetPush();
	}

	//rushing fwd
	//increase forward speed while attacking
	if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_CROSS] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_KNEE])
	{
		//if action keyframe
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action != act_none &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action != act_def)
		{
			//increase forward walking speed
			walk_fwd_rush = WALK_FWD_BONUS;
		}

		//if animation on way back decrease forward walking speed
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 1)
		{
			//walk_fwd_rush = -50;
		}
	}
	else
		walk_fwd_rush = 0;

	//rushing bwd
	//increase forward speed while tapping or evading
	if (//p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI] ||
		//p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_MI] ||
		//p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO] ||
		//p_aslot[aslot_action] == p_anmn[asi][AN_DUCK] ||
		//p_aslot[aslot_action] == p_anmn[asi][AN_TAP_JAB] ||
		//p_aslot[aslot_action] == p_anmn[asi][AN_TAP_CROSS] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_TAP_ARMS] ||
		p_aslot[aslot_action] == p_anmn[asi][AN_TAP_LEG])
	{
		//if action keyframe
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == act_def)
		{
			//increase backward walking speed
			walk_bwd_rush = WALK_BWD_BONUS;
		}

		//if animation on way back decrease forward walking speed
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 1)
		{
			//walk_fwd_rush = -50;
		}
	}
	else
		walk_bwd_rush = 0;

	//walk stun, reset if time up
	if (gl_lock.t_stun_bwd + p_time->freq * (T_WALK_STUN / p_option->data.speed) < p_time->current)
	{
		//if not already deactivated
		//if player walking, deactivate to create new walk cycle and reassgin walk animation
		if (gl_lock.t_stun_bwd != 0)
		{
//			al_create_walk_cycle(AN_WALK_BWD, 1.0f);
			if (PA[id][AN_WALK_BWD] == AS_ACTIVE)
				PA[id][AN_WALK_BWD]	= AS_INACTIVE;
		}
		gl_lock.stun_walk_bwd	= 1.0f;
		gl_lock.t_stun_bwd		= 0;
	}
	if (gl_lock.t_stun_fwd + p_time->freq * (T_WALK_STUN / p_option->data.speed) < p_time->current)
	{
		if (gl_lock.t_stun_fwd != 0)
		{
//			al_create_walk_cycle(AN_WALK_FWD, 1.0f);
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE)
				PA[id][AN_WALK_FWD]	= AS_INACTIVE;
		}
		gl_lock.stun_walk_fwd	= 1.0f;
		gl_lock.t_stun_fwd		= 0;
	}

	//screen boundaries
/*	if (side == SLEFT)
	{
		if (sk.p_ref->v.p[0].x <= S_LBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x <= S_LBOUND + 3))
			PA[id][AN_WALK_BWD] = AS_INACTIVE;

		if (sk.p_ref->v.p[0].x >= S_RBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x >= S_LBOUND - 3))
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
	}
	else
	{
		if (sk.p_ref->v.p[0].x <= S_LBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x <= S_LBOUND + 3))
			PA[id][AN_WALK_FWD] = AS_INACTIVE;

		if (sk.p_ref->v.p[0].x >= S_RBOUND ||
			(p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_LO] &&
			sk.p_ref->v.p[0].x >= S_LBOUND - 3))
			PA[id][AN_WALK_BWD] = AS_INACTIVE;
	}*/
	if (sk.p_ref->v.p[0].x <= S_LBOUND)
		if (side == SLEFT)
			PA[id][AN_WALK_BWD] = AS_INACTIVE;
		else
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
	if (sk.p_ref->v.p[0].x >= S_RBOUND)
		if (side == SLEFT)
			PA[id][AN_WALK_FWD] = AS_INACTIVE;
		else
			PA[id][AN_WALK_BWD] = AS_INACTIVE;

	//time in seconds until full walking speed
	//adjusted to user set speed
	float waf = SKILL_WALK_ACC / p_option->data.speed;
//!! bei push-back setzen, sonst keine bewegung
//!! von fatigue abh�ngig

	//actual player movement
	//calculate movement speed depending on fatigue and bone damage
	if (PA[id][AN_WALK_BWD])
	{
		//calculate walking speed
		walk_bwd_ad		= SKILL_WALK_BWD * gl_lock.stun_walk_bwd + cd_push_speed + walk_bwd_rush;

		//for all bones
		for (register int i = 0; i < 19; ++i)
		{
			//if damage of bone has affect on speed
			if (p_anmn[asi][AN_WALK_BWD]->gl_eff_dam_speed[i] >= 1.0f)
				//reduce walking speed
				walk_bwd_ad -= (int)(SKILL_WALK_BWD * (sk.b[i].damage / 100.0f / p_anmn[asi][AN_WALK_BWD]->gl_eff_dam_speed[i]));
		}

		//if fatigue effects speed
		if (p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed >= 1)
			walk_bwd_ad -= (int)(SKILL_WALK_BWD * (fatigue / 100.0f / p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed));

//!!
//if (!dev_i)
{
		if (side == SLEFT)
			if (t_move[id][0] < waf)
				sk.p_ref->v.p[0].x -= walk_bwd_ad * (t_move[id][0] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x -= walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			if (t_move[id][0] < waf)
				sk.p_ref->v.p[0].x += walk_bwd_ad * (t_move[id][0] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x += walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
}
		//!!
//		if (t_move[id][0] < waf)
//			walk_bwd_ad = walk_bwd_ad / (waf / t_move[id][0]);
/*		if (side == SLEFT)
			sk.p_ref->v.p[0].x -= walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			sk.p_ref->v.p[0].x += walk_bwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;*/
	}

	if (PA[id][AN_WALK_FWD])
	{
		walk_fwd_ad		= SKILL_WALK_FWD * gl_lock.stun_walk_fwd + cd_push_speed + walk_fwd_rush;

		for (register int i = 0; i < 19; ++i)
		{
			if (p_anmn[asi][AN_WALK_FWD]->gl_eff_dam_speed[i] >= 1.0f)
				walk_fwd_ad -= (int)(SKILL_WALK_FWD * (sk.b[i].damage / 100.0f / p_anmn[asi][AN_WALK_FWD]->gl_eff_dam_speed[i]));
		}

		if (p_anmn[asi][AN_WALK_BWD]->gl_eff_fat_speed >= 1)
			walk_fwd_ad -= (int)(SKILL_WALK_FWD * (fatigue / 100.0f / p_anmn[asi][AN_WALK_FWD]->gl_eff_fat_speed));

//!!
//if (!dev_i)
{
		if (side == SLEFT)
			if (t_move[id][1] < waf)
				sk.p_ref->v.p[0].x += walk_fwd_ad * (t_move[id][1] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x += walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			if (t_move[id][1] < waf)
				sk.p_ref->v.p[0].x -= walk_fwd_ad * (t_move[id][1] / waf) * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
			else
				sk.p_ref->v.p[0].x -= walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
}
		//!!
//		if (t_move[id][1] < waf)
//			walk_fwd_ad = walk_fwd_ad / (waf / t_move[id][1]);
/*		if (side == SLEFT)
			sk.p_ref->v.p[0].x += walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;
		else
			sk.p_ref->v.p[0].x -= walk_fwd_ad * p_option->data.zoomfactor * (float)p_time->sca * p_option->data.speed;*/
	}

	//input and animation
	//deactivate walking if button no longer down
	if (PA[id][AN_WALK_FWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
		al_deactivate_slot(aslot_cycle);
	if (PA[id][AN_WALK_BWD] == AS_INACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
		al_deactivate_slot(aslot_cycle);

	//activate if button down
	if (PA[id][AN_WALK_FWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_FWD])
	{
		//create walk cycle in depedence of stance_arms
		al_create_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
		//don't apply speedfactor while activating the slot because
		//this is already done in al_create_walk_cycle
		al_activate_slot(aslot_cycle, AN_WALK_FWD, -1, -1, false);
	}
	//if already running update keyframe speed if necessary
/*	if (PA[id][AN_WALK_FWD] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
	{
		if (t_move[id][1] < waf)
			al_adjust_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
	}*/
	if (PA[id][AN_WALK_BWD] == AS_ACTIVE && p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_BWD])
	{
		//create walk cycle in depedence of stance_arms
		al_create_walk_cycle(AN_WALK_BWD, walk_bwd_ad / SKILL_WALK_BWD);
		al_activate_slot(aslot_cycle, AN_WALK_BWD, -1, -1, false);
	}
/*	if (PA[id][AN_WALK_BWD] == AS_ACTIVE && p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
	{
		if (t_move[id][0] < waf)
			al_adjust_walk_cycle(AN_WALK_BWD, walk_bwd_ad / SKILL_WALK_BWD);
	}*/

	//walking fatigue
	//since most of the time the fatigue value for walking is lower than the
	//fatigue regeneration all walking does is slowing down the regeneration
	if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
		//fatigue_buff += (float)p_anmn[asi][AN_WALK_FWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed;
		gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_WALK_FWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
	if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
		//fatigue_buff += (float)p_anmn[asi][AN_WALK_BWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed;
		gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_WALK_BWD]->gl_fatigue * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);

	//---- jab -----------------------------------------------------------------------------------

	//context locks:
	//since the pre action lock check is always done the program doesn't
	//know yet if the action will be a context or non-context action
	//and whether either of them is locked
	//
	//if non-context action was locked check if the angle difference to the
	//new attack is big enough
	//if so unlock the limb and allow the new attack
	//
	//if context action was locked don't allow any attack (context or non-context)

	if (PA[id][AN_JAB] == AS_PRE)
	{
		//not locked
		//30
		if (!gl_lock.get_lockstate(asi, 0, 0, angle_180[id], -1))
		{
			al_activate_slot(aslot_action, AN_JAB, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
		}
		else
		{
			//slow down offense locked attack
			if (OFF_LOCK_SLOWDOWN)
			{
				//slow down
				al_activate_slot(aslot_action, AN_JAB, angle[id], angle_180[id]);
				p_aslot[aslot_action]->state[id]		= AS_PRE;
				p_aslot[aslot_action]->speedfactor[id]	= AADJ_LOCKSPEED;
				//if blocked gets damage even if opponent def locked
				p_aslot[aslot_action]->power_attack[id]	= 1;
				s_set_sound(S_ATT_LOCKED);
			}
			else
			//cancel and apply fatigue for offense locked attack
			{
				//cancel sound
				s_set_sound(S_ATT_LOCKED);
				pmessage.set_message(PM_STDDAMAGE, blue, "FAT +%i", (int)(LLOCK_FAT * p_option->data.fom_multiplier));
				gl_fatigue_add(aslot_action, 0, LLOCK_FAT * p_option->data.fom_multiplier);
			}
		}
	}
	if (PA[id][AN_JAB] == AS_FINAL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
	{
		//not locked
		if (!gl_lock.get_lockstate(asi, 0, 0, angle_180[id], -1))
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//power jab
			//not while moving or sliding backwards
			if (PA[id][AN_WALK_BWD] != AS_ACTIVE &&
				p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_SLIDE_BWD] &&
				power_attack[0] == 1 &&
				p_time->current <= t_power_attack[0] + p_time->freq * (0.5f / p_option->data.speed))
			{
				//reset power flag data
				power_attack[0]		= power_attack[1]		= 0;
				t_power_attack[0]	= t_power_attack[1]		= 0;
				//set flag in animation
				p_aslot[aslot_action]->power_attack[id]		= 1;
				//sound and player message
				s_set_sound(S_AGA1);
				if (p_option->data.show_pmessages)
					pmessage.set_message(PM_POWERATTACK, green, "POWER JAB!");
			}
		}
		else
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}

	//---- jab hook ------------------------------------------------------------------------------

	if (PA[id][AN_JAB] == AS_CONTEXT && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
	{
		//not locked
		if (!gl_lock.get_lockstate(asi, 0, 1, angle_180[id], -1))
		{
			//set jab fatigue flag, deactivate jab and activate jab hook
			//p_aslot[aslot_action]->gl_fat[id]	= 1;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_JAB_HOOK, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//set powerattack flag in animation so if blocked (even if locked) gets damage
			p_aslot[aslot_action]->power_attack[id]		= 1;
		}
		else
		{
			//if locked cancel hook
			//PA[id][AN_JAB]	= AS_CANCEL;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_JAB_HOOK, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			p_aslot[aslot_action]->power_attack[id]		= 1;
			p_aslot[aslot_action]->speedfactor[id]		= AADJ_LOCKSPEED;
		}
	}

	//---- jab cancel ----------------------------------------------------------------------------

	if (PA[id][AN_JAB] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_JAB])
	{
		//if punch was only in pre-state
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0 &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0)
		{
			//set power kick active
			power_attack[1]			= 1;
			//start time of canceling, bonus valid only for limited amount of time
			t_power_attack[1]		= p_time->current;
		}
		al_deactivate_slot(aslot_action);
	}
	
	//---- cross ---------------------------------------------------------------------------------

	if (PA[id][AN_CROSS] == AS_PRE)
	{
		if (!gl_lock.get_lockstate(asi, 1, 0, angle_180[id], -1))
		{
			al_activate_slot(aslot_action, AN_CROSS, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
		}
		else
		{
			if (OFF_LOCK_SLOWDOWN)
			{
				al_activate_slot(aslot_action, AN_CROSS, angle[id], angle_180[id]);
				p_aslot[aslot_action]->state[id]		= AS_PRE;
				p_aslot[aslot_action]->speedfactor[id]	= AADJ_LOCKSPEED;
				p_aslot[aslot_action]->power_attack[id]	= 1;
				s_set_sound(S_ATT_LOCKED);
			}
			else
			{
				s_set_sound(S_ATT_LOCKED);
				pmessage.set_message(PM_STDDAMAGE, blue, "FAT +%i", (int)(LLOCK_FAT * p_option->data.fom_multiplier));
				gl_fatigue_add(aslot_action, 0, LLOCK_FAT * p_option->data.fom_multiplier);
			}
		}
	}
	if (PA[id][AN_CROSS] == AS_FINAL && p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
	{
		if (!gl_lock.get_lockstate(asi, 1, 0, angle_180[id], -1))
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//power cross
			//not while moving or sliding backwards
			if (PA[id][AN_WALK_BWD] != AS_ACTIVE &&
				p_aslot[aslot_cycle] != p_anmn[asi][AN_WALK_SLIDE_BWD] &&
				power_attack[0] == 1 &&
				p_time->current <= t_power_attack[0] + p_time->freq * (0.5f / p_option->data.speed))
			{
				power_attack[0]		= power_attack[1]		= 0;
				t_power_attack[0]	= t_power_attack[1]		= 0;
				p_aslot[aslot_action]->power_attack[id]		= 1;
				s_set_sound(S_AGA2);
				if (p_option->data.show_pmessages)
					pmessage.set_message(PM_POWERATTACK, green, "POWER CROSS!");
			}
		}
		else
		{
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}

	//---- cross hook ----------------------------------------------------------------------------

	if (PA[id][AN_CROSS] == AS_CONTEXT && p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
	{
		if (!gl_lock.get_lockstate(asi, 1, 1, angle_180[id], -1))
		{
			//set cross fatigue flag, deactivate cross and activate cross hook
			//p_aslot[aslot_action]->gl_fat[id] = 1;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_CROSS_HOOK, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			//set powerattack flag in animation so if blocked (even if locked) gets damage
			p_aslot[aslot_action]->power_attack[id]		= 1;
		}
		else
		{
			//if locked cancel hook
			//PA[id][AN_CROSS]	= AS_CANCEL;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_CROSS_HOOK, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			p_aslot[aslot_action]->power_attack[id]		= 1;
			p_aslot[aslot_action]->speedfactor[id]		= AADJ_LOCKSPEED;
		}
	}

	//---- cross cancel --------------------------------------------------------------------------

	if (PA[id][AN_CROSS] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
	{
		/*if punch was only in pre-state
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0 &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0)
		{
			//set power kick active
			power_attack[1]			= 1;
			//start time of canceling, bonus valid only for limited amount of time
			t_power_attack[1]		= p_time->current;
		}*/
		al_deactivate_slot(aslot_action);
	}

	//---- kick_fwd ------------------------------------------------------------------------------

	if (PA[id][AN_KICK_FWD] == AS_PRE)
	{
		//20
		if (!gl_lock.get_lockstate(asi, 2, 0, angle_180[id], -1))
		{
			al_activate_slot(aslot_action, AN_KICK_FWD, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
		}
		else
		{
			if (OFF_LOCK_SLOWDOWN)
			{
				al_activate_slot(aslot_action, AN_KICK_FWD, angle[id], angle_180[id]);
				p_aslot[aslot_action]->state[id]		= AS_PRE;
				p_aslot[aslot_action]->speedfactor[id]	= AADJ_LOCKSPEED;
				p_aslot[aslot_action]->power_attack[id]	= 1;
				s_set_sound(S_ATT_LOCKED);
			}
			else
			{
				s_set_sound(S_ATT_LOCKED);
				pmessage.set_message(PM_STDDAMAGE, blue, "FAT +%i", (int)(LLOCK_FAT * p_option->data.fom_multiplier));
				gl_fatigue_add(aslot_action, 0, LLOCK_FAT * p_option->data.fom_multiplier);
			}
		}
	}
	if (PA[id][AN_KICK_FWD] == AS_FINAL &&
		(p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD]))
	{
		if (!gl_lock.get_lockstate(asi, 2, 0, angle_180[id], -1))
		{
			//set walking direction at begin of action
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE ||
				p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
				walk_lock	= 1;
			else
				if (PA[id][AN_WALK_BWD] == AS_ACTIVE ||
					p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					walk_lock	= 2;
				else
					walk_lock	= -1;

			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//power kick
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE &&
				power_attack[1] == 1 &&
				p_time->current <= t_power_attack[1] + p_time->freq * (0.5f / p_option->data.speed))
			{
				power_attack[0]		= power_attack[1]		= 0;
				t_power_attack[0]	= t_power_attack[1]		= 0;
				p_aslot[aslot_action]->power_attack[id]		= 1;
				s_set_sound(S_AGA2);
				if (p_option->data.show_pmessages)
					pmessage.set_message(PM_POWERATTACK, green, "POWER KICK!");
			}
		}
		else
		{
			//set walking direction at begin of action
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE ||
				p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
				walk_lock	= 1;
			else
				if (PA[id][AN_WALK_BWD] == AS_ACTIVE ||
					p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					walk_lock	= 2;
				else
					walk_lock	= -1;

			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}

	//---- knee ----------------------------------------------------------------------------------

	if (PA[id][AN_KICK_FWD] == AS_CONTEXT && p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD])
	{
		//30
		if (!gl_lock.get_lockstate(asi, 2, 1, angle_180[id], -1))
		{
			//p_aslot[aslot_action]->gl_fat[id]	= 1;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_KICK_KNEE, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
			//set powerattack flag in animation so if blocked (even if locked) gets damage
			p_aslot[aslot_action]->power_attack[id]		= 1;
		}
		else
		{
			//if locked cancel knee
			//PA[id][AN_KICK_FWD]	= AS_CANCEL;
			//p_aslot[aslot_action]->gl_fat[id]	= 1;
			al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_KICK_KNEE, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			p_aslot[aslot_action]->power_attack[id]		= 1;
			p_aslot[aslot_action]->speedfactor[id]		= AADJ_LOCKSPEED;
		}
	}

	//---- kick_fwd cancel -----------------------------------------------------------------------

	if (PA[id][AN_KICK_FWD] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD])
	{
		//if kick was only in pre-state
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0 &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0)
		{
			//set power punch active
			power_attack[0]			= 1;
			//start time of canceling, bonus valid only for limited amount of time
			t_power_attack[0]		= p_time->current;
		}
		al_deactivate_slot(aslot_action);
	}

	//---- kick_swd ------------------------------------------------------------------------------

	if (PA[id][AN_KICK_SWD] == AS_PRE)
	{
		//20
		if (!gl_lock.get_lockstate(asi, 2, 0, angle_180[id], -1))
		{
			al_activate_slot(aslot_action, AN_KICK_SWD, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_PRE;
		}
		else
		{
			if (OFF_LOCK_SLOWDOWN)
			{
				al_activate_slot(aslot_action, AN_KICK_SWD, angle[id], angle_180[id]);
				p_aslot[aslot_action]->state[id]		= AS_PRE;
				p_aslot[aslot_action]->speedfactor[id]	= AADJ_LOCKSPEED;
				p_aslot[aslot_action]->power_attack[id]	= 1;
				s_set_sound(S_ATT_LOCKED);
			}
			else
			{
				s_set_sound(S_ATT_LOCKED);
				pmessage.set_message(PM_STDDAMAGE, blue, "FAT +%i", (int)(LLOCK_FAT * p_option->data.fom_multiplier));
				gl_fatigue_add(aslot_action, 0, LLOCK_FAT * p_option->data.fom_multiplier);
			}
		}
	}

	if (PA[id][AN_KICK_SWD] == AS_FINAL &&
		p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
	{
		//20
		if (!gl_lock.get_lockstate(asi, 2, 0, angle_180[id], -1))
		{
			//set walking direction at begin of action
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE ||
				p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
				walk_lock	= 1;
			else
				if (PA[id][AN_WALK_BWD] == AS_ACTIVE ||
					p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					walk_lock	= 2;
				else
					walk_lock	= -1;

			//---- kick_swd_hi -------------------------------------------------------------------

/*			if (p_aslot[aslot_action]->angle_180[id] < 80)
			{
				//deactive slot
//				al_deactivate_slot(aslot_action, false);

				int _a		= p_aslot[aslot_action]->angle[id];
				int _a180	= p_aslot[aslot_action]->angle_180[id];
				//set high kick animation
				al_activate_slot(aslot_action, AN_KICK_SWD_HI, _a, _a180);
			}*/

			//------------------------------------------------------------------------------------

			p_aslot[aslot_action]->state[id]	= AS_FINAL;

			//power kick
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE &&
				power_attack[1] == 1 &&
				p_time->current <= t_power_attack[1] + p_time->freq * (0.5f / p_option->data.speed))
			{
				//reset power flag data
				power_attack[0]		= power_attack[1]		= 0;
				t_power_attack[0]	= t_power_attack[1]		= 0;
				//set flag in animation
				p_aslot[aslot_action]->power_attack[id]		= 1;
				//sound and player message
				s_set_sound(S_AGA2);
				if (p_option->data.show_pmessages)
					pmessage.set_message(PM_POWERATTACK, green, "POWER KICK!");
			}
		}
		else
		{
			//set walking direction at begin of action
			if (PA[id][AN_WALK_FWD] == AS_ACTIVE ||
				p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_FWD])
				walk_lock	= 1;
			else
				if (PA[id][AN_WALK_BWD] == AS_ACTIVE ||
					p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_SLIDE_BWD])
					walk_lock	= 2;
				else
					walk_lock	= -1;

			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}

	//---- kick_swd cancel -----------------------------------------------------------------------

	if (PA[id][AN_KICK_SWD] == AS_CANCEL && p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
	{
		/*if kick was only in pre-state
		if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 0 &&
			p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == 0)
		{
			//set power punch active
			power_attack[0]			= 1;
			//start time of canceling, bonus valid only for limited amount of time
			t_power_attack[0]		= p_time->current;
		}*/
		al_deactivate_slot(aslot_action);
	}

	//---- defense -------------------------------------------------------------------------------

	//---- guard ---------------------------------------------------------------------------------

	if (PA[id][AN_GUARD_ARMS] == AS_FINAL)
	{
		//set defense lock on
		gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
		//if not in guard or in guard but at least 0.03 sec passed (adjusted to game speed)
		if (p_aslot[aslot_action] != p_anmn[asi][AN_GUARD_ARMS] ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_ARMS] &&
			p_aslot[aslot_action]->gl_time[id] + (0.12f / p_option->data.speed) * p_time->freq <= p_time->current))
		{
			al_activate_slot(aslot_action, AN_GUARD_ARMS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}
	if (PA[id][AN_GUARD_ARMS] == AS_CANCEL)
	{
		al_deactivate_slot(aslot_action);
	}
	if (PA[id][AN_GUARD_LEGS] == AS_FINAL)
	{
		//set defense lock on
		if (asi == 0 || asi == 2)	gl_lock.set_lockstate(DEFENSIVE, 2, 0, ON, 0, p_time->current);
		else						gl_lock.set_lockstate(DEFENSIVE, 3, 0, ON, 0, p_time->current);
		//if not in guard or in guard but at least 0.03 sec passed (adjusted to game speed)
		if (p_aslot[aslot_action] != p_anmn[asi][AN_GUARD_LEGS] ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_LEGS] &&
			p_aslot[aslot_action]->gl_time[id] + (0.12f / p_option->data.speed) * p_time->freq <= p_time->current))
		{
			al_activate_slot(aslot_action, AN_GUARD_LEGS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}
	if (PA[id][AN_GUARD_LEGS] == AS_CANCEL)
	{
		al_deactivate_slot(aslot_action);
	}
	if (PA[id][AN_GUARD_FULL] == AS_FINAL)
	{
		//set defense lock on
		gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
		if (asi == 0 || asi == 2)	gl_lock.set_lockstate(DEFENSIVE, 2, 0, ON, 0, p_time->current);
		else						gl_lock.set_lockstate(DEFENSIVE, 3, 0, ON, 0, p_time->current);
		//if not in guard or in guard but at least 0.03 sec passed (adjusted to game speed)
		if (p_aslot[aslot_action] != p_anmn[asi][AN_GUARD_FULL] ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_FULL] &&
			p_aslot[aslot_action]->gl_time[id] + (0.10f / p_option->data.speed) * p_time->freq <= p_time->current))
		{
			al_activate_slot(aslot_action, AN_GUARD_FULL);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
	}
	if (PA[id][AN_GUARD_FULL] == AS_CANCEL)
	{
		al_deactivate_slot(aslot_action);
	}

	//guard fatigue in units per second
	//if guarded, adjust fatigue regeneration
	if (p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_ARMS])
//		gl_fatigue_add(0, 0, skill_freg_ad * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
		gl_fatigue_add(0, 0, ((skill_freg_ad / skill_freg) * FAT_GUARD_ARMS) * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
	if (p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_LEGS])
//		gl_fatigue_add(0, 0, skill_freg_ad * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
		gl_fatigue_add(0, 0, ((skill_freg_ad / skill_freg) * FAT_GUARD_LEGS) * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
	if (p_aslot[aslot_action] == p_anmn[asi][AN_GUARD_FULL])
		gl_fatigue_add(0, 0, ((skill_freg_ad / skill_freg) * FAT_GUARD_FULL) * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);

	//---- manual tapping ------------------------------------------------------------------------

	if (p_option->data.defense_mode[id] == DM_mTmE ||
		p_option->data.defense_mode[id] == DM_mTaE)
	{
		//solid arms block
		if (PA[id][AN_TAP_ARMS] == AS_FINAL)
		{
			//if previous animation jab or cross (pre-state)
			//deactivate it without applying fatige
			if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_CROSS])
				al_deactivate_slot(aslot_action, false);

			//if not already tapping or successful tap
			//AND NOT DEF LOCKED OR TIME SINCE LAST TAP LONGER THAN T_LOCKDEF, else use previous data
			//this is done to prevent height locks for taps in case of missed attacks
			//that happened after the deflock for the last tap was deactivated
			if ((p_aslot[aslot_action] != p_anmn[asi][AN_TAP_ARMS] ||
				gl_def_success) &&
				(!gl_lock.get_lockstate(baul, asi) || (float)(p_time->current - t_last_tap_arms) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed))
				//gl_SetSolidTapData();
				gl_SetTapArmsAnmn();

			al_activate_slot(aslot_action, AN_TAP_ARMS);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}

		if (PA[id][AN_TAP_ARMS] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}

		if (PA[id][AN_TAP_LEG] == AS_FINAL)
		{
			//if not already tapping or successful tap 
			if (p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG] ||
				gl_def_success)
			{
				//not def locked or last tap longer than t_lockdef
				if (!gl_lock.get_lockstate(blul, asi) || (float)(p_time->current - t_last_tap_legs) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed)
				{
					//get tap angle
					gl_SetTapLegAnmn(&angle[id], &angle_180[id]);
					//save angle data
					al_legtap_last_a[asi]		= angle[id];
					al_legtap_last_a_180[asi]	= angle_180[id];
				}
				else
				//use previous angle data
				{
					angle[id]		= al_legtap_last_a[asi];
					angle_180[id]	= al_legtap_last_a_180[asi];
				}
			}

			//if previous animation kick_fwd or kick_swd (pre-state)
			//deactivate it without applying fatige
			if (p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
				al_deactivate_slot(aslot_action, false);
			al_activate_slot(aslot_action, AN_TAP_LEG, angle[id], angle_180[id]);
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
		if (PA[id][AN_TAP_LEG] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}
	}

	//---- auto tapping --------------------------------------------------------------------------

	if (p_option->data.defense_mode[id] == DM_aTmE ||
		p_option->data.defense_mode[id] == DM_aTaE)
	{
		if (PA[id][AN_TAP_ARMS] == AS_FINAL ||
			PA[id][AN_TAP_LEG] == AS_FINAL)
		{
			//if previous animation jab, cross, kick_fwd, kick_swd (pre-state)
			//deactivate it without applying fatigue
			if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_CROSS] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_KICK_FWD] ||
				p_aslot[aslot_action] == p_anmn[asi][AN_KICK_SWD])
				al_deactivate_slot(aslot_action, false);

			//first holds pressed tap
			//then holds tap to execute
			int taptype	= 0;

			if (PA[id][AN_TAP_ARMS] == AS_FINAL)			taptype = AN_TAP_ARMS;
			if (PA[id][AN_TAP_LEG] == AS_FINAL)				taptype = AN_TAP_LEG;

			//get tap type and angle
			gl_GetAutoTap(&taptype, &angle[id], &angle_180[id]);

			//no user angle input with solid arms block
			if (taptype == AN_TAP_ARMS)
			{
				al_activate_slot(aslot_action, taptype);
			}
			else
			{
				al_activate_slot(aslot_action, taptype, angle[id], angle_180[id]);
			}
			p_aslot[aslot_action]->state[id]	= AS_FINAL;
		}
		if (PA[id][AN_TAP_ARMS] == AS_CANCEL ||
			PA[id][AN_TAP_LEG] == AS_CANCEL)
		{
			al_deactivate_slot(aslot_action);
		}
	}

	//---- manual evade --------------------------------------------------------------------------

	if (p_option->data.defense_mode[id] == DM_mTmE ||
		p_option->data.defense_mode[id] == DM_aTmE)
	{
		if (PA[id][AN_DEFEND] == AS_FINAL)
			if (side == SLEFT)
			{
				if (angle[id] >= 225 && angle[id] < 315)
				{
					al_activate_slot(aslot_action, AN_EVADE_HI);
					//p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 135 && angle[id] < 225)
				{
					al_activate_slot(aslot_action, AN_EVADE_LO);
					//p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 45 && angle[id] < 135)
				{
					//angle for lower walking animation
					angle_180[id]	= 160;
					al_activate_slot(aslot_action, AN_DUCK, 0, 160);
				}
			}
			else
			{
				if (angle[id] >= 225 && angle[id] < 315)
				{
					al_activate_slot(aslot_action, AN_EVADE_HI);
					//p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 315 || angle[id] < 45)
				{
					al_activate_slot(aslot_action, AN_EVADE_LO);
					//p_aslot[aslot_action]->ui_valid[id]	= 1;
				}
				if (angle[id] >= 45 && angle[id] < 135)
				{
					//angle for lower walking animation
					angle_180[id]	= 160;
					al_activate_slot(aslot_action, AN_DUCK, 0, 160);
				}
			}
	}

	//---- auto evade ----------------------------------------------------------------------------

	if (p_option->data.defense_mode[id] == DM_mTaE ||
		p_option->data.defense_mode[id] == DM_aTaE)
	{
		if (PA[id][AN_DEFEND] == AS_FINAL)
		{
			//get evade type
			int evade_type	= gl_GetAutoEvade();

			//angle for lower walking animation
			if (evade_type == AN_DUCK)
			{
				angle_180[id]	= 160;
				al_activate_slot(aslot_action, evade_type, 0, 160);
			}
			else
			{
				al_activate_slot(aslot_action, evade_type);
				//p_aslot[aslot_action]->ui_valid[id]	= 1;
			}
		}
	}

	//---- evade hold ----------------------------------------------------------------------------

	if (PA[id][AN_DEFEND] == AS_ACTIVE)
	{
		//either when already evade hold active and time since animation start (adjusted to game
		//speed) at least 0.02 sec or
		//evade active and on way back
		if ((p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI_HOLD] &&
			p_aslot[aslot_action]->gl_time[id] + (0.10f / p_option->data.speed) * p_time->freq <= p_time->current) ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI] &&
			p_aslot[aslot_action]->pkf[cki[btul]].dir == 1))
			al_activate_slot(aslot_action, AN_EVADE_HI_HOLD);

		if ((p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO_HOLD] &&
			p_aslot[aslot_action]->gl_time[id] + (0.10f / p_option->data.speed) * p_time->freq <= p_time->current) ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO] &&
			p_aslot[aslot_action]->pkf[cki[btll]].dir == 1))
			al_activate_slot(aslot_action, AN_EVADE_LO_HOLD);

		if ((p_aslot[aslot_action] == p_anmn[asi][AN_DUCK_HOLD] &&
			p_aslot[aslot_action]->gl_time[id] + (0.15f / p_option->data.speed) * p_time->freq <= p_time->current) ||
			(p_aslot[aslot_action] == p_anmn[asi][AN_DUCK] &&
			p_aslot[aslot_action]->pkf[cki[btll]].dir == 1))
		{
			//angle for lower walking animation
			angle_180[id]	= 160;
			al_activate_slot(aslot_action, AN_DUCK_HOLD, 0, 160);
		}

		//evade hold fatigue
		if (p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_HI_HOLD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_EVADE_LO_HOLD] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_DUCK_HOLD])
			gl_fatigue_add(0, 0, ((skill_freg_ad / skill_freg) * FAT_EVADE_HOLD) * p_option->data.fom_multiplier * (float)p_time->sca * p_option->data.speed);
	}

	//---- pushing and pulling -------------------------------------------------------------------

	if (PA[id][AN_PUSH_ARMS] == AS_FINAL)
	{
		//adjust other arm
		if (asi == 0 || asi == 2)
		{
			if (side == SLEFT)
			{
				p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur]	= (float)angle[id] + 58;
				p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur]	= (float)angle[id] + 13;
			}
			else
			{
				p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur]	= (float)angle[id] - 58;
				p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur]	= (float)angle[id] - 13;
			}

			//angle limits
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur] > 359)	p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur]	-= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur] < 0)		p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baur]	+= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur] > 359)	p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur]	-= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur] < 0)		p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baur]	+= 360;
		}
		else
		{
			if (side == SLEFT)
			{
				p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul]	= (float)angle[id] + 58;
				p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul]	= (float)angle[id] + 13;
			}
			else
			{
				p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul]	= (float)angle[id] - 58;
				p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul]	= (float)angle[id] - 13;
			}

			//angle limits
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul] > 359)	p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul]	-= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul] < 0)		p_anmn[asi][AN_PUSH_ARMS]->pkf[0].angle[baul]	+= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul] > 359)	p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul]	-= 360;
			if (p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul] < 0)		p_anmn[asi][AN_PUSH_ARMS]->pkf[1].angle[baul]	+= 360;
		}

		//set defense lock on
		gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
		al_activate_slot(aslot_action, AN_PUSH_ARMS, angle[id], angle_180[id]);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
	}
	if (PA[id][AN_PUSH_ARMS] == AS_CANCEL)
	{
		al_deactivate_slot(aslot_action);
	}

	if (PA[id][AN_PULL_ARMS] == AS_FINAL)
	{
		//set defense lock on
		gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
		al_activate_slot(aslot_action, AN_PULL_ARMS, angle[id], angle_180[id]);
		p_aslot[aslot_action]->state[id]	= AS_FINAL;
	}
	if (PA[id][AN_PULL_ARMS] == AS_CANCEL)
	{
		al_deactivate_slot(aslot_action);
	}

	//---- idling --------------------------------------------------------------------------------

	//upper body
	//if cycle slot unassigned and
	//action slot unassigned or action slot assigned to idling lo
	if (p_aslot[aslot_cycle] == NULL &&
		(p_aslot[aslot_action] == NULL || p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO]))
	{
		//if last animation of cycle slot was not idling
		//create idle cycle with fast first keyframe
		if (last_anmn[aslot_cycle] != AN_IDLE_HI)
		{
			al_create_idle_cycle(0, 100);
			//!!
			//sk.b[ball].damage = 50;
		}
		else
		//else create slow one
		{
			al_create_idle_cycle(0, 0);
			//sk.b[ball].damage = 0;
		}
		al_activate_slot(aslot_cycle, AN_IDLE_HI);
	}

	//lower body
	if (p_aslot[aslot_action] == NULL &&
		(p_aslot[aslot_cycle] == NULL || p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI]))
	{
		if (last_anmn[aslot_action] != AN_IDLE_LO)
		{
			al_create_idle_cycle(1, 100);
			//sk.b[blll].damage = 50;
		}
		else
		{
			al_create_idle_cycle(1, 0);
			//sk.b[blll].damage = 0;
		}
		al_activate_slot(aslot_action, AN_IDLE_LO);
	}

	//---- stance_arms ---------------------------------------------------------------------------

	//only if no other action
//	if (PA[id][AN_STANCE_ARMS] &&
//		(p_aslot[aslot_action] == NULL ||
//		p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO]))
//!!
	//always, independent from other actions
	if (PA[id][AN_STANCE_ARMS])
	{
		//stance button
		if (PA[id][AN_STANCE_ARMS] == 1000 ||
			PA[id][AN_STANCE_ARMS] == - 1000)
		{
			//stance button up
			if (PA[id][AN_STANCE_ARMS] == -1000)
			{
				if (stance_arms > 70)							stance_arms = 100;
				if (stance_arms > 30 && stance_arms <= 70)		stance_arms = 100;
				if (stance_arms <= 30)							stance_arms = 65;
			}

			//stance button down
			if (PA[id][AN_STANCE_ARMS] == 1000)
			{
				if (stance_arms <= 30)							stance_arms = 15;
				if (stance_arms > 30 && stance_arms <= 70)		stance_arms = 15;
				if (stance_arms > 70)							stance_arms = 65;
			}
		}
		else
		//lY
		{
			//!!
//			stance_arms -= (int)(PA[id][AN_STANCE_ARMS] * (1.0f / 144.0f));
			stance_arms -= (int)(PA[id][AN_STANCE_ARMS] * p_time->sca);

			//limit
			if (stance_arms > 100)		stance_arms = 100;
			if (stance_arms < 0)		stance_arms = 0;
		}

		//create new idle cycle for upper body with updated arm stance
		//if stance changed with lY, create cycle which first keyframe
		//is executed almost immediately to show change of arm stance
		//if stance changed with lZ, create standard (slow) cycle
		if ((PA[id][AN_STANCE_ARMS] != -1000 && PA[id][AN_STANCE_ARMS] != 1000) &&
			p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
		{
			al_create_idle_cycle(0, 10);
			al_activate_slot(aslot_cycle, AN_IDLE_HI);
		}
		if ((PA[id][AN_STANCE_ARMS] == -1000 || PA[id][AN_STANCE_ARMS] == 1000) &&
			p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
		{
			al_create_idle_cycle(0, 0);
			al_activate_slot(aslot_cycle, AN_IDLE_HI);
		}
		//also while walking
		if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_FWD])
			al_create_walk_cycle(AN_WALK_FWD, walk_fwd_ad / SKILL_WALK_FWD);
		if (p_aslot[aslot_cycle] == p_anmn[asi][AN_WALK_BWD])
			al_create_walk_cycle(AN_WALK_BWD, walk_fwd_ad / SKILL_WALK_BWD);

		//flash def_part bones
		//for all bones
		int	flashcolor		= hs_stanceflash;	//hs_hitred;
		for (register int b = 0; b < 19; ++b)
		{
			//clear all other bones
			//(or for continues change the defpart bones of other stances will flash)
			if (sk.b[b].cd_state == cds_hit)
			{
				sk.b[b].hit_state	= hs_nohit;
				sk.b[b].hit_state_e	= hs_nohit;
			}

			//whole bone in defpart
			if (sk.b[b].cd_state == cds_defpart)
			{
				sk.b[b].hit_state	= flashcolor;
				p_rcd->time[id][b]	= p_time->current;

				//if lower arms also for fists
				if (b == ball)
				{
					sk.b[b].hit_state_e	= flashcolor;
					p_rcd->time[id][20]	= p_time->current;
				}
				if (b == balr)
				{
					sk.b[b].hit_state_e	= flashcolor;
					p_rcd->time[id][21]	= p_time->current;
				}
			}

			//only bone without extension
			if (sk.b[b].cd_state == cds_defpart_b)
			{
				sk.b[b].hit_state	= flashcolor;
				p_rcd->time[id][b]	= p_time->current;
				//clear extension
				sk.b[b].hit_state_e	= hs_nohit;
			}

			//only extension
			if (sk.b[b].cd_state == cds_defpart_e)
			{
				sk.b[b].hit_state_e	= flashcolor;
				if (b == ball)
					p_rcd->time[id][20]	= p_time->current;
				if (b == balr)
					p_rcd->time[id][21]	= p_time->current;
				//clear bone
				sk.b[b].hit_state	= hs_nohit;
			}
		}
	}

	//---- stance_feet ---------------------------------------------------------------------------

	//no animation, just change stance and add fatigue
	if (PA[id][AN_STANCE_FEET] == AS_ACTIVE)
	{
		//only if idling or animation on way back
		int valid	= 0;
		if (p_aslot[aslot_action] == NULL ||
			p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO])
			valid	= 1;
		if (p_aslot[aslot_action] != NULL)
			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 1)
				valid	= 1;

		if (valid)
		{
			//reset locks
			gl_lock.reset();

			//deactivate hit animation
			//prevents strange bone positions after beeing hit and doing stance change
			for (register int b = 0; b < 22; ++b)
				if (casi[b] == aslot_hit)
				{
					if (p_aslot[aslot_action] != NULL)
						casi[b] = aslot_action;
					else
						casi[b] = aslot_cycle;

				cki[b]										= 0;
				p_aslot[casi[b]]->pkf[cki[b]].state[id][b]	= 0;
				bhi[b]										= 0;
				}
			p_aslot[aslot_hit] = NULL;

			set_stance(!stance_feet);
			gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_STANCE_FEET]->gl_fatigue * p_option->data.fom_multiplier);
		}
	}

	//faked stance change
	if (PA[id][AN_STANCE_FEET] == AS_CANCEL)
	{
		//only if idling or animation on way back
		int valid	= 0;
		if (p_aslot[aslot_action] == NULL ||
			p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO])
			valid	= 1;
		if (p_aslot[aslot_action] != NULL)
			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].dir == 1)
				valid	= 1;

		if (valid)
		{
			set_stance(!stance_feet);
			set_stance(!stance_feet);
			gl_fatigue_add(0, 0, (float)p_anmn[asi][AN_STANCE_FEET]->gl_fatigue_cancel * p_option->data.fom_multiplier);
		}
	}

	//---- taunt ---------------------------------------------------------------------------------

	if (PA[id][AN_TAUNT1] == AS_ACTIVE)
	{
		al_activate_slot(aslot_action, AN_TAUNT1);
		if (p_option->data.show_pmessages)
//			pmessage.set_message(PM_TAUNT, pink, "Come On!");
			//replace other taunt if active
			pmessage.set_message(0, 0, 0, 255, 0, 255,
								 0.35f, T_PMESSAGE * 1.5f,
								 1, T_PMESSAGE * 0.75f,
								 p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
								 p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
								 ST_DYNAMIC, 0, 0,
								 "Aaoouuwww!", "Come On!");
	}
	if (PA[id][AN_TAUNT2] == AS_ACTIVE)
	{
		al_activate_slot(aslot_action, AN_TAUNT2);
		if (p_option->data.show_pmessages)
//			pmessage.set_message(PM_TAUNT, pink, "Aaoouuwww!");
			//replace other taunt if active
			pmessage.set_message(0, 0, 0, 255, 0, 255,
								 0.35f, T_PMESSAGE * 1.5f,
								 1, T_PMESSAGE * 0.75f,
								 p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
								 p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
								 ST_DYNAMIC, 0, 0,
								 "Come On!", "Aaoouuwww!");
	}

	//---- assign user input values --------------------------------------------------------------

	//unnecessary to apply the input value every frame
/*	if (p_aslot[aslot_action] != NULL)
	{
		p_aslot[aslot_action]->angle[id]			= angle[id];
		p_aslot[aslot_action]->angle_180[id]		= angle_180[id];
	}*/
	if (p_aslot[aslot_cycle] != NULL)
	{
		//assign to cycle slot for more crouched walking
		if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_CROSS] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_CROSS_HOOK] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_DUCK] ||
			p_aslot[aslot_action] == p_anmn[asi][AN_DUCK_HOLD])
		{
			p_aslot[aslot_cycle]->angle[id]				= angle[id];
			p_aslot[aslot_cycle]->angle_180[id]			= angle_180[id];
		}
		else
		{
			p_aslot[aslot_cycle]->angle[id]				= 0;
			p_aslot[aslot_cycle]->angle_180[id]			= 90;
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_GetAutoEvade
//
//	returns animation index of evade action depending on opponents attack and attack height
//	called by player::gl_process_input
//
//------------------------------------------------------------------------------------------------

int player::gl_GetAutoEvade()
{
	//opponent jab or cross
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 75)
			return(AN_DUCK);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 75 &&
			p_opp->p_aslot[aslot_action]->angle_180[!id] < 110)
			return(AN_EVADE_HI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 110)
			return(AN_EVADE_LO);
	}

	//opponent jab hook or cross hook
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB_HOOK] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS_HOOK])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 110)
			return(AN_EVADE_HI);
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] >= 110)
			return(AN_EVADE_LO);
	}

	//opponent kick_fwd or kick_swd
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_FWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_SWD])
	{
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 75)
			return(AN_EVADE_HI);
		else
			return(AN_EVADE_LO);
	}

	//opponent knee
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_KNEE])
	{
		return(AN_EVADE_LO);
	}

	//default evade
	//!! depening on arm stance?
	return(AN_EVADE_HI);
}

//------------------------------------------------------------------------------------------------
//
//	player gl_GetAutoTap
//
//	selects auto tapping action and angle depening on
//	lock state of limbs
//	stance arms
//	distance to opponent
//	opponents attack and attack height
//	values returned as argumented pointers
//
//------------------------------------------------------------------------------------------------

void player::gl_GetAutoTap(int *ptap, int *pangle, int *pangle_180)
{
	//opponent kicks
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_FWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_SWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_KNEE])
	{
		//if not already tapping or successful tap 
		if (p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG] ||
			gl_def_success)
		{
			//not def locked or last tap longer than t_lockdef
			if (!gl_lock.get_lockstate(blul, asi) || (float)(p_time->current - t_last_tap_legs) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed)
			{
				//get tap angle
				gl_SetTapLegAnmn(pangle, pangle_180);
				//save angle data
				al_legtap_last_a[asi]		= *pangle;
				al_legtap_last_a_180[asi]	= *pangle_180;
			}
			else
			//use previous angle data
			{
				*pangle			= al_legtap_last_a[asi];
				*pangle_180		= al_legtap_last_a_180[asi];
			}
		}

		//player not pushed tap leg
		if (*ptap != AN_TAP_LEG)
		{
			//wrong tap, change tap type to leg and set lock
			*ptap	= AN_TAP_LEG;
			if (asi == 0 || asi == 2)
				gl_lock.set_lockstate(DEFENSIVE, 2, 0, ON, 0, p_time->current);
			else
				gl_lock.set_lockstate(DEFENSIVE, 3, 0, ON, 0, p_time->current);
		}

		return;
	}

	//opponent jab or cross or hooked
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB_HOOK] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS_HOOK])
	{
		//if not already tapping or successful tap
		//AND NOT DEF LOCKED OR TIME SINCE LAST TAP LONGER THAN T_LOCKDEF, else use previous data
		//this is done to prevent height locks for taps in case of missed attacks
		//that happened after the deflock for the last tap was deactivated
		if ((p_aslot[aslot_action] != p_anmn[asi][AN_TAP_ARMS] ||
			gl_def_success) &&
			(!gl_lock.get_lockstate(baul, asi) || (float)(p_time->current - t_last_tap_arms) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed))
			gl_SetTapArmsAnmn();

		//player not pushed tap arms
		if (*ptap != AN_TAP_ARMS)
		{
			//change tap type
			*ptap	= AN_TAP_ARMS;
			//set lock
			gl_lock.set_lockstate(DEFENSIVE, 0, 0, ON, 0, p_time->current);
		}

		return;
	}

	//no opponent action
	//set pushed tap
	if (*ptap == AN_TAP_ARMS)
	{
		if ((p_aslot[aslot_action] != p_anmn[asi][AN_TAP_ARMS] ||
			gl_def_success) &&
			(!gl_lock.get_lockstate(baul, asi) || (float)(p_time->current - t_last_tap_arms) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed))
			gl_SetTapArmsAnmn();
	}
	else
	{
		//if not already tapping or successful tap 
		if (p_aslot[aslot_action] != p_anmn[asi][AN_TAP_LEG] ||
			gl_def_success)
		{
			//not def locked or last tap longer than t_lockdef
			if (!gl_lock.get_lockstate(blul, asi) || (float)(p_time->current - t_last_tap_legs) / p_time->freq > p_option->data.t_lockdef / p_option->data.speed)
			{
				//get tap angle
				gl_SetTapLegAnmn(pangle, pangle_180);
				//save angle data
				al_legtap_last_a[asi]		= *pangle;
				al_legtap_last_a_180[asi]	= *pangle_180;
			}
			else
			//use previous angle data
			{
				*pangle			= al_legtap_last_a[asi];
				*pangle_180		= al_legtap_last_a_180[asi];
			}
		}
	}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetTapArmsAnmn
//
//	sets different tap animations depending on opponent attack height
//	and player stance arms
//
//------------------------------------------------------------------------------------------------

void player::gl_SetTapArmsAnmn()
{
	//4 variations of taps (2 kf each)
	//0	= stance hi, cross up defending, jab stays
	//1	= stance hi, cross down, jab curled down defending
	//2	= stance lo, cross up defending, jab up
	//3 = stance lo, cross stays, jab down stretched defending
	int tapset;
	//default (no attack) depending on stance arms
	if (stance_arms < 60)		tapset	= 3;
	else						tapset	= 0;

	//opponent jab or cross or hooked
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB_HOOK] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS_HOOK])
	{
		//high attack
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] <= 100)
		{
			if (stance_arms < 60)		tapset	= 2;
			else						tapset	= 0;
		}
		else
		//low attack
		{
			if (stance_arms < 60)		tapset	= 3;
			else						tapset	= 1;
		}
	}

	//opponent kick_fwd or kick_swd
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_FWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_SWD])
	{
		//high attack
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] <= 80)
		{
			if (stance_arms < 60)		tapset	= 2;
			else						tapset	= 0;
		}
		else
		//low attack
		{
			if (stance_arms < 60)		tapset	= 3;
			else						tapset	= 1;
		}
	}

	//opponent kick_knee
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_KNEE])
	{
		if (stance_arms < 60)		tapset	= 3;
		else						tapset	= 1;
	}

	//---- set animation data --------------------------------------------------------------------

	//keyframe offset in animation set
	int kfoffset	= 0;
//	if (tapset == 0)		kfoffset	= 0;
//	if (tapset == 1)		kfoffset	= 2;
//	if (tapset == 2)		kfoffset	= 4;
//	if (tapset == 3)		kfoffset	= 6;
	if (tapset == 0)		kfoffset	= 2;
	if (tapset == 1)		kfoffset	= 0;
	if (tapset == 2)		kfoffset	= 6;
	if (tapset == 3)		kfoffset	= 4;

	//for all asi
	//in case of side change
	for (register int i = 0; i < 4; ++i)
	{
		//assign animation from animation set
		p_anmn[i][AN_TAP_ARMS]->pkf[0]	= p_anmn[i][AN_TAP_ARMS_SET]->pkf[0 + kfoffset];
		p_anmn[i][AN_TAP_ARMS]->pkf[1]	= p_anmn[i][AN_TAP_ARMS_SET]->pkf[1 + kfoffset];
	}

	//---- set game logic data -------------------------------------------------------------------

	//for all tapsets for asi 0
	//0 - stance hi - cross hi, jab stay
	//1 - stance hi - cross lower, jab lo curl
	//2 - stance lo - cross hi, jab higher
	//3 - stance lo - cross stay, jab lo stretched
	//
	//bsl, baul, ball, bsr, baur, balr, bn, btul, btll
	//set for bone independet state logic
	int defstate[4][9]	= {cds_hit, cds_hit, cds_hit, cds_hit, cds_def, cds_def, cds_def, cds_def, cds_hit,
						   cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_def,
						   cds_hit, cds_hit, cds_hit, cds_hit, cds_def, cds_def, cds_def, cds_def, cds_hit,
						   cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_def};
	//set for bone dependet state logic
//	int defstate[4][9]	= {cds_hit, cds_hit, cds_hit, cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit,
//						   cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit,
//						   cds_hit, cds_hit, cds_hit, cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit
//						   cds_hit, cds_def, cds_def, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit, cds_hit};
	//priority of these bones
	int pri[4][6]		= {3, 3, 3, 4, 4, 4,
						   4, 4, 4, 3, 3, 3,
						   3, 3, 3, 4, 4, 4,
						   4, 4, 4, 3, 3, 3};

	//for asi 0 and 2
	for (i = 0; i < 3; i += 2)
	{
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bsl]	= defstate[tapset][0];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[baul]	= defstate[tapset][1];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[ball]	= defstate[tapset][2];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bsr]	= defstate[tapset][3];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[baur]	= defstate[tapset][4];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[balr]	= defstate[tapset][5];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bn]		= defstate[tapset][6];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[btul]	= defstate[tapset][7];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[btll]	= defstate[tapset][8];

		p_anmn[i][AN_TAP_ARMS]->priority[bsl]		= pri[tapset][0];
		p_anmn[i][AN_TAP_ARMS]->priority[baul]		= pri[tapset][1];
		p_anmn[i][AN_TAP_ARMS]->priority[ball]		= pri[tapset][2];
		p_anmn[i][AN_TAP_ARMS]->priority[bsr]		= pri[tapset][3];
		p_anmn[i][AN_TAP_ARMS]->priority[baur]		= pri[tapset][4];
		p_anmn[i][AN_TAP_ARMS]->priority[balr]		= pri[tapset][5];
	}

	//asi 1 and 3
	for (i = 1; i < 4; i += 2)
	{
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bsl]	= defstate[tapset][3];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[baul]	= defstate[tapset][4];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[ball]	= defstate[tapset][5];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bsr]	= defstate[tapset][0];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[baur]	= defstate[tapset][1];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[balr]	= defstate[tapset][2];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[bn]		= defstate[tapset][6];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[btur]	= defstate[tapset][7];
		p_anmn[i][AN_TAP_ARMS]->gl_bcds_def[btlr]	= defstate[tapset][8];

		p_anmn[i][AN_TAP_ARMS]->priority[bsl]		= pri[tapset][3];
		p_anmn[i][AN_TAP_ARMS]->priority[baul]		= pri[tapset][4];
		p_anmn[i][AN_TAP_ARMS]->priority[ball]		= pri[tapset][5];
		p_anmn[i][AN_TAP_ARMS]->priority[bsr]		= pri[tapset][0];
		p_anmn[i][AN_TAP_ARMS]->priority[baur]		= pri[tapset][1];
		p_anmn[i][AN_TAP_ARMS]->priority[balr]		= pri[tapset][2];
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetTapLegAnmn
//
//	sets height of tap leg animation depending on opponent attack height
//
//------------------------------------------------------------------------------------------------

void player::gl_SetTapLegAnmn(int *pangle, int *pangle_180)
{
	//default angle
	if (side == SLEFT)				*pangle	= 0;
	else							*pangle	= 180;

	//opponent jab or cross or hooked
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_JAB_HOOK] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_CROSS_HOOK])
	{
		//high tap leg
		if (side == SLEFT)				*pangle	= 330;
		else							*pangle	= 210;
	}

	//opponent kick_fwd or kick_swd
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_FWD] ||
		p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_SWD])
	{
		if (side == SLEFT)
		{
			if (p_opp->p_aslot[aslot_action]->angle_180[!id] <= 89)
				*pangle = 270 + p_opp->p_aslot[aslot_action]->angle_180[!id];
			else
			{
				*pangle = p_opp->p_aslot[aslot_action]->angle_180[!id] - 90;

				//not too low
				if (*pangle > 30)
					*pangle	= 30;
			}
		}
		else
		{
			if (p_opp->p_aslot[aslot_action]->angle_180[!id] <= 89)
				*pangle = 270 - p_opp->p_aslot[aslot_action]->angle_180[!id];
			else
			{
				*pangle = 180 - (p_opp->p_aslot[aslot_action]->angle_180[!id] - 90);

				if (*pangle < 150)
					*pangle	= 150;
			}
		}

		//high kick
		if (p_opp->p_aslot[aslot_action]->angle_180[!id] < 100)
			if (side == SLEFT)				*pangle	= 330;
			else							*pangle	= 210;
	}

	//opponent kick_knee
	if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_KICK_KNEE])
	{
		if (side == SLEFT)				*pangle	= 330;
		else							*pangle	= 210;
	}

	//angle limits
	if (side == SLEFT)
	{
		if (*pangle > 50 && *pangle < 270)			*pangle	= 50;
		if (*pangle < 330 && *pangle >= 270)		*pangle	= 330;
	}
	else
	{
		if (*pangle < 130)							*pangle	= 130;
		if (*pangle > 210)							*pangle	= 210;
	}

	//set 180 angle
	if (*pangle > 270)							*pangle_180 = *pangle - 271;
	if (*pangle >= 0 && *pangle <= 90)			*pangle_180 = *pangle + 89;
	if (*pangle > 90 && *pangle <= 270)			*pangle_180 = 270 - *pangle;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetPush
//
//	sets push
//
//------------------------------------------------------------------------------------------------

void player::gl_SetPush(int type,							//0 = stop player forward movement
															//1 = push player backward, may be canceled
															//to stop when player walks forward
															//2 = push player backward, no canceling
															//3 = drag player forward
															//increases fwd speed, decreases bwd speed
															//4 = drag player forward, no canceling
						float force,						//time of push in seconds
						float speed)						//(additional) walking speed
{
	//set push start time
	cd_t_pushhit	= p_time->current;

	cd_push_type	= type;
	cd_push_force	= force;
	cd_push_speed	= speed;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_ReversePush
//
//	reverses push (for side change, pulling becomes pushing)
//
//------------------------------------------------------------------------------------------------

void player::gl_ReversePush()
{
	//no pull, return
	if (cd_push_type != 4)
	{
		gl_ResetPush();
	}
	else
	{
		//push bwd, no cancelling
		cd_push_type			= 2;
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_ResetPush
//
//	stops push, resets push data
//
//------------------------------------------------------------------------------------------------

void player::gl_ResetPush()
{
	cd_t_pushhit				= 0;
	cd_push_type				= -1;
	cd_push_force				= 0;
	cd_push_speed				= 0;
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetHandicap()
//
//	sets damage handicap data
//
//------------------------------------------------------------------------------------------------

void player::gl_SetHandicap()
{
	//player 1
	if (id == P1)
	{
		//option pointer valid
		//gl_SetHandicap() gets called in reset() which also gets called
		//in constructor when pointer to options not valid yet
		if (p_option)
		{
			//for all damage slots
			for (register int i = 0; i < NODS; ++i)
			{
				sk.damage[i]	= p_option->data.dam_handicap_p1[i];

				//for all bones
				for (register int b = 0; b < 19; ++b)
				{
					//if bone belongs to current damage slot
					if (sk.b[b].d_slot == i)
						//copy damage of damage slot to bone
						sk.b[b].damage	= sk.damage[i];
				}
			}
		}
	}
	//player 2
	else
	{
		if (p_option)
			for (register int i = 0; i < NODS; ++i)
			{
				sk.damage[i]	= p_option->data.dam_handicap_p2[i];

				for (register int b = 0; b < 19; ++b)
				{
					//if bone belongs to current damage slot
					if (sk.b[b].d_slot == i)
						//copy damage of damage slot to bone
						sk.b[b].damage	= sk.damage[i];
				}
			}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_process_game_logic
//
//	called every subframe
//	handles player game logic
//
//------------------------------------------------------------------------------------------------

void player::gl_process_game_logic(float t_move[2][2])
{
	//---- direction -----------------------------------------------------------------------------
	//set direction of bone which gets user input

	//for both slots
	for (register int s = 0; s < 2; ++s)
		//if slot valid
		if (p_aslot[s] != NULL)
			//set direction of user input bone
			p_aslot[s]->ui_dir[id] = p_aslot[s]->pkf[cki[p_aslot[s]->ui_index]].dir;

	//---- active action -------------------------------------------------------------------------

	//reset active states
	ZeroMemory(&active_off, sizeof(active_off));

	//for every action
	for (register int i = 0; i < 6; ++i)
		//if attacking
		if (p_rcd->attack[id][i] != -1)
			//if animation slot valid set game logic flag to attack
			//a single attack can only hit one time and only one single bone at the time
			if (p_aslot[aslot_action] != NULL)
			{
				//set attack flag to registered
				p_aslot[aslot_action]->gl_attack[id] = 1;

				//advance attack animation
				//doesn't feel good
				if (p_option->data.hitstop)
				{
					//advance_slot[aslot_action]			= 1;
					//t_advanceslot_start[aslot_action]	= p_time->current;

					//freeze current frame
					//al_SetFreezeFrame(aslot_action, 50);

					//delayed keyframe advancement
					al_SetDelayedAnimationAdj(aslot_action, p_option->data.hitstop, AADJ_ADVKF);
				}

				//!! hit stop
				//halt player forward movement
				if (p_rcd->damage[id] >= 20 * p_option->data.damage_multiplier)
				{
					gl_SetPush(0, 0.2f, 0);
				}

				//for both if attack hit a bone in defense or defense return mode
				if(p_rcd->attack_cancel[id][i] == 1 ||
				   p_rcd->attack_return[id][i] == 1)
				{
					//advance attack animation
//					advance_slot[aslot_action]			= 1;
//					t_advanceslot_start[aslot_action]	= p_time->current;

					//delayed keyframe advancement
					al_SetDelayedAnimationAdj(aslot_action, 40, AADJ_SETTARGET);

					//freeze current frame
					//al_SetFreezeFrame(aslot_action, 75);

					//halt player movement
					gl_SetPush(0, 0.25f, 0);
//!!
//p_opp->gl_SetPush(2, 0.25f, 0);

					//push back if opponent is walking fwd
					//if (p_opp->p_aslot[aslot_action] != NULL)
//						if (p_opp->p_aslot[aslot_cycle] == p_opp->p_anmn[p_opp->asi][AN_WALK_FWD])
if (false)
						{
								gl_SetPush(2, 0.5f, 75);
								if (p_option->data.show_pmessages)
									pmessage.set_message(PM_PUSHPULL, green, "Pushed!");
						}

					//set offense and defense lock
					//get defense lock index
					int lindex		= i;
					//if context attack, get context
					int context		= 0;
					//i = 0 to 5
					//act_kneel = 5 (set to 2), act_kneer = 6 (set to 3)
					//so i + 1
					if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK] ||
						p_aslot[aslot_action] == p_anmn[asi][AN_CROSS_HOOK] ||
						i + 1 == act_kneel || i + 1 == act_kneer)
					{
						context		= 1;

						//knee locks feet
						if (i + 1 == act_kneel)		lindex = 2;
						if (i + 1 == act_kneer)		lindex = 3;
					}

					//set offense lock
					gl_lock.set_lockstate(OFFENSIVE, lindex, context, ON,
										  p_aslot[aslot_action]->angle_180[id], p_time->current);

					//also set defense lock
					gl_lock.set_lockstate(DEFENSIVE, lindex, 0, ON,
										  p_aslot[aslot_action]->angle_180[id], p_time->current);
				}

				//opponents bone in defense mode (defense locked)
				//(no power attack)
				if (p_rcd->attack_cancel[id][i] == 1 &&
					!p_aslot[aslot_action]->power_attack[id])
				{
					//set opponents defense to succeed (no def lock)
					p_opp->gl_def_success = true;

					//restart opponents tapping animation
					if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_TAP_ARMS])
					{
						p_opp->al_activate_slot(aslot_action, AN_TAP_ARMS);
						p_opp->p_aslot[aslot_action]->state[p_opp->id]			= AS_FINAL;
						p_opp->p_aslot[aslot_action]->speedfactor[p_opp->id]	= SF_DOUBLE_TAP;
						p_opp->gl_def_success									= true;
					}
					if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_TAP_LEG])
					{
						int a		= p_opp->p_aslot[aslot_action]->angle[p_opp->id];
						int a180	= p_opp->p_aslot[aslot_action]->angle_180[p_opp->id];
						p_opp->al_activate_slot(aslot_action, AN_TAP_LEG, a, a180);
						p_opp->p_aslot[aslot_action]->state[p_opp->id]			= AS_FINAL;
						p_opp->p_aslot[aslot_action]->speedfactor[p_opp->id]	= SF_DOUBLE_TAP;
						p_opp->gl_def_success									= true;
					}
				}

				//opponents bone in defense return mode (non locked defense) or
				//attack was power attack
				//offense damage to cause to own bone
				if (p_rcd->attack_return[id][i] == 1 ||
					(p_rcd->attack_cancel[id][i] == 1 &&
					p_aslot[aslot_action]->power_attack[id] == 1))
				{
					//if power attack, increased damage
					if (p_aslot[aslot_action]->power_attack[id] == 1)
					{
						//set opponents defense to succeed (no def lock)
						p_opp->gl_def_success = true;

						//restart opponents tapping animation
						if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_TAP_ARMS])
						{
							p_opp->al_activate_slot(aslot_action, AN_TAP_ARMS);
							p_opp->p_aslot[aslot_action]->state[p_opp->id]			= AS_FINAL;
							p_opp->p_aslot[aslot_action]->speedfactor[p_opp->id]	= SF_DOUBLE_TAP;
							p_opp->gl_def_success									= true;
						}
						if (p_opp->p_aslot[aslot_action] == p_opp->p_anmn[p_opp->asi][AN_TAP_LEG])
						{
							int a		= p_opp->p_aslot[aslot_action]->angle[p_opp->id];
							int a180	= p_opp->p_aslot[aslot_action]->angle_180[p_opp->id];
							p_opp->al_activate_slot(aslot_action, AN_TAP_LEG, a, a180);
							p_opp->p_aslot[aslot_action]->state[p_opp->id]			= AS_FINAL;
							p_opp->p_aslot[aslot_action]->speedfactor[p_opp->id]	= SF_DOUBLE_TAP;
							p_opp->gl_def_success									= true;
						}

						//increase self damage
						p_rcd->damage[!id] = (float)p_aslot[aslot_action]->gl_damage * p_option->data.tapdamratio * p_option->data.damage_multiplier * 1.5f;
					}
					else
					{
						//standard self damage
						p_rcd->damage[!id] = (float)p_aslot[aslot_action]->gl_damage * p_option->data.tapdamratio * p_option->data.damage_multiplier;
					}

					//push back
					gl_SetPush(2, 0.2f, 0);

					//bone index to get damage and bone flash
					int _bone;

					if (i == 0)	_bone = ball;
					if (i == 1)	_bone = balr;
					if (i == 2)	_bone = bfl;
					if (i == 3)	_bone = bfr;
					if (i == 4)	_bone = blul;
					if (i == 5)	_bone = blur;

					//process self damage
					gl_process_damage_def(_bone, p_rcd->damage[!id], p_rcd->defend[!id], t_move, true);

					//set hit start time (for flash)
					p_rcd->time[id][_bone]	= p_time->current;

					//done in gl_process_damage_def
					//pmessage return damage
					//if (p_option->data.show_damage)
					//{
					//	char cb[6] = {0};
					//	sprintf(cb, "%i", (int)-p_rcd->damage[!id]);
					//	pmessage.set_message(cb, 0, 0, 0, 255, 255, 0, 0.35f, 0.5f, p_time->current);
					//}
				}

				//////////////////////////////////////////////////////////////////////////////////

/*				//if attack hit a bone in defense mode
				//(no power attack)
				if (p_rcd->attack_cancel[id][i] == 1 &&
					!p_aslot[aslot_action]->power_attack[id])
				{
					//set opponents defense to succeed (no def lock)
					p_opp->gl_def_success = true;

					//advance attack animation
					advance_slot[aslot_action] = 1;

					//halt player movement
					cd_t_pushhit		= p_time->current;
					cd_push_type		= 0;
					cd_push_force		= 0.25f;
					//push back if opponent is walking fwd
					if (p_opp->p_aslot[aslot_action] != NULL)
						if (p_opp->p_aslot[aslot_cycle] == p_opp->p_anmn[p_opp->asi][AN_WALK_FWD])
						{
								cd_push_type		= 2;
								cd_push_force		= 0.4f;
								pmessage.set_message("Pushed!", 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, p_time->current);
						}

					/*get offense lock index
					int lindex = i;
					//knee locks feet
					if (i == act_kneel)		lindex = 2;
					if (i == act_kneer)		lindex = 3;*/

					//!!
//					for (register int a = 0; a < 6; ++a)
//					{
//						if (p_rcd->attack[!id][a] == 1)
//							break;
//					}
//					if (p_opp->gl_lock.lock_def[a] == OFF)
//						xxx

/*					//if context attack, get context
					int context		= 0;
					if (p_aslot[aslot_action] == p_anmn[asi][AN_JAB_HOOK] ||
						p_aslot[aslot_action] == p_anmn[asi][AN_CROSS_HOOK] ||
						i == act_kneel || i == act_kneer)
						context		= 1;
					//set offense lock
					gl_lock.set_lockstate(OFFENSIVE, i, context, ON,
										  p_aslot[aslot_action]->angle_180[id], p_time->current);
					//also set defense lock
					gl_lock.set_lockstate(DEFENSIVE, i, 0, ON,
										  p_aslot[aslot_action]->angle_180[id], p_time->current);
				}

				//if attack hit a bone in defense return mode
				//or bone hit is in defense mode and attack was power attack
				//calculate damage to
				//cause and apply to own damage slot
				if (p_rcd->attack_return[id][i] == 1 ||
					(p_rcd->attack_cancel[id][i] == 1 &&
					p_aslot[aslot_action]->power_attack[id] == 1))
					//if action slot valid
					if (p_aslot[aslot_action] != NULL)
					{
						int _bone;

						if (i == 0)	_bone = ball;
						if (i == 1)	_bone = balr;
						if (i == 2)	_bone = bfl;
						if (i == 3)	_bone = bfr;
						if (i == 4)	_bone = blul;
						if (i == 5)	_bone = blur;

						//damage to cause to own bone
						//if power attack, increased
						if (p_aslot[aslot_action]->power_attack[id] == 1)
						{
							//set opponents defense to succeed (no def lock)
							p_opp->gl_def_success = true;

							//advance attack animation
							advance_slot[aslot_action] = 1;

							//halt player movement
							cd_t_pushhit		= p_time->current;
							cd_push_type		= 0;
							cd_push_force		= 0.25f;
							//push back if opponent is walking fwd
							if (p_opp->p_aslot[aslot_action] != NULL)
								if (p_opp->p_aslot[aslot_cycle] == p_opp->p_anmn[p_opp->asi][AN_WALK_FWD])
								{
										cd_push_type		= 2;
										cd_push_force		= 0.4f;
										pmessage.set_message("Pushed!", 0, 0, 0, 0, 255, 0, 0.35f, 0.5f, p_time->current);
								}

							p_rcd->damage[!id] = (float)p_aslot[aslot_action]->gl_damage * p_option->data.tapdamratio * p_option->data.damage_multiplier * 1.5f;
						}
						else
							p_rcd->damage[!id] = (float)p_aslot[aslot_action]->gl_damage * p_option->data.tapdamratio * p_option->data.damage_multiplier;
						gl_process_damage_def(_bone, p_rcd->damage[!id], p_rcd->defend[!id], t_move, true);

						//set hit start time (for flash)
						p_rcd->time[id][_bone]	= p_time->current;

						//pmessage
						if (p_option->data.show_damage)
						{
							char cb[6] = {0};
							sprintf(cb, "%i", (int)-p_rcd->damage[!id]);
							pmessage.set_message(cb, 0, 0, 0, 255, 255, 0, 0.35f, 0.5f, p_time->current);
						}
					}*/
			}
/*
			//old code to advance animation when hit (doesn't look and feel good)
			//for every bone
			for (register int b = 0; b < 21; ++b)
				//if current keyframe index of bone smaller than number of keyframes in animation
				if (cki[b] < p_aslot[casi[b]]->nokf - 1)
				{
					//set advance_slot to 1 and break loop
					advance_slot[casi[b]] = 1;
					//set attack to registered
					if (p_aslot[aslot_action] != NULL)
						p_aslot[aslot_action]->gl_attack[id] = 1;
					break;
				}*/

	//for every action
	for (register int a = 1; a < 7; ++a)
		//if slot valid
		if (p_aslot[aslot_action] != NULL)
			//if current keyframe of ui_index bone in action_slot is action
			//and attack not already registered
			if (p_aslot[aslot_action]->pkf[cki[p_aslot[aslot_action]->ui_index]].action == a &&
				!p_aslot[aslot_action]->gl_attack[id])
				//set action active
				active_off[a - 1] = 1;

	//lock expire (all contexts)
	//for all limbs
	for (register int l = 0; l < 4; ++l)
	{
		//offense lock
		//lock for "data.t_lockoff" seconds
		if (gl_lock.ts_off[l] + p_time->freq * (p_option->data.t_lockoff / p_option->data.speed) < p_time->current)
		{
			//reset lock
			gl_lock.set_lockstate(OFFENSIVE, l, 0, OFF, 0, 0);
		}

		//defense lock
		if (gl_lock.ts_def[l] + p_time->freq * (p_option->data.t_lockdef / p_option->data.speed) < p_time->current)
		{
			//reset lock
			gl_lock.set_lockstate(DEFENSIVE, l, 0, OFF, 0, 0);
		}
	}

	//---- keyframe advancing --------------------------------------------------------------------
	//if hit bone in cd defense mode attack animation may be cancelled

/*	//if animation in slot 0 set to advance 
	if (advance_slot[0] == 1)
	{
		if (p_time->current >= t_advanceslot_start[0] + p_time->freq * (0.05f / p_option->data.speed))
		{
			//advance animation
			//for all bones and hara
			for (register int b = 0; b < 21; ++b)
				//if not already reached last keyframe
				if (casi[b] == 0 && cki[b] < p_aslot[0]->nokf - 1)
				{
					//reset state of current keyframe, increase keyframe
					p_aslot[0]->pkf[cki[b]].state[id][b] = 0;
					++cki[b];
				}

			//reset advance flag
			advance_slot[0]		= 0;
		}
	}

	//if animation in slot 0 set to advance 
	if (advance_slot[1] == 1)
	{
		if (p_time->current >= t_advanceslot_start[1] + p_time->freq * (0.05f / p_option->data.speed))
		{
			//advance animation
			//for all bones and hara
			for (register int b = 0; b < 21; ++b)
				//if not already reached last keyframe
				if (casi[b] == 1 && cki[b] < p_aslot[1]->nokf - 1)
				{
					//reset state of current keyframe, increase keyframe
					p_aslot[1]->pkf[cki[b]].state[id][b] = 0;
					++cki[b];
				}

			//reset advance flag
			advance_slot[1]		= 0;
		}
	}*/

	//if animation in slot 0 set to advance
	if (advance_slot[0] == 1)
	{
		//for all bones and hara
		for (register int b = 0; b < 21; ++b)
			//if not already reached last keyframe
			if (casi[b] == 0 && cki[b] < p_aslot[0]->nokf - 1)
			{
				//reset state of current keyframe, increase keyframe
				p_aslot[0]->pkf[cki[b]].state[id][b] = 0;
				++cki[b];
			}

		//slow animation down
		p_aslot[0]->speedfactor[id] = 1.5f;

		//reset advance flag
		advance_slot[0] = 0;
	}
	//if animation in slot 1 set to advance
	if (advance_slot[1] == 1)
	{
		//al_deactivate_slot(aslot_action);

		for (register int b = 0; b < 21; ++b)
//			if (casi[b] == 1 && cki[b] < p_aslot[1]->nokf - 1)
			{
				p_aslot[1]->pkf[cki[b]].state[id][b] = 0;
//				++cki[b];
				//set to last keyframe
				cki[b]	= p_aslot[1]->nokf - 1;
			}

		//slow animation down
//		p_aslot[1]->speedfactor[id] = 1.5f;
		p_aslot[1]->speedfactor[id] = 2.0f;

		advance_slot[1] = 0;
	}

	//animation delayed advancement
	al_ProcessDelayAnimationAdj();

	//---- bone flashing -------------------------------------------------------------------------

	//set hit_state in bone for a defined amount of time since bone is hit
	//to flash bone indicating it was hit

	//time of flash adjusted to user set speed
	float flashtime = T_BONEFLASH / p_option->data.speed;

	//for all regular bones
	for (i = 0; i < 19; ++i)
	{
/*		//if bone is in defense or defense part mode
		if (sk.b[i].cd_state == cds_def)
		{
			//cancel hit flash
			p_rcd->time[id][i] = 0;
			sk.b[i].hit_state = 0;
		}*/

		//if time valid (set to 0 when done)
		if (p_rcd->time[id][i] != 0)
		{
			//if flash time run out
			if (p_time->current > p_rcd->time[id][i] + p_time->freq * flashtime)
			{
				//reset time
				p_rcd->time[id][i] = 0;
				//reset hit_state of bone
				sk.b[i].hit_state = hs_nohit;
			}
		}
	}
	//head
	//if time valid (set to 0 when done)
	if (p_rcd->time[id][bhead] != 0)
	{
		//if flash time run out
		if (p_time->current > p_rcd->time[id][bhead] + p_time->freq * flashtime)
		{
			//reset time
			p_rcd->time[id][bhead] = 0;
			//reset hit_state of bone
			sk.b[bn].hit_state_e = hs_nohit;
		}
	}
	//left fist
	//if time valid (set to 0 when done)
	if (p_rcd->time[id][bfistl] != 0)
	{
		//if flash time run out
		if (p_time->current > p_rcd->time[id][bfistl] + p_time->freq * flashtime)
		{
			//reset time
			p_rcd->time[id][bfistl] = 0;
			//reset hit_state of bone
			sk.b[ball].hit_state_e = hs_nohit;
		}
	}
	//right fist
	//if time valid (set to 0 when done)
	if (p_rcd->time[id][bfistr] != 0)
	{
		//if flash time run out
		if (p_time->current > p_rcd->time[id][bfistr] + p_time->freq * flashtime)
		{
			//reset time
			p_rcd->time[id][bfistr] = 0;
			//reset hit_state of bone
			sk.b[balr].hit_state_e = hs_nohit;
		}
	}

	//---- fatigue -------------------------------------------------------------------------------

	//for both slots
	for (s = 0; s < 2; ++s)
	{
		//if slot valid
		if (p_aslot[s] != NULL)
			//if animation on way back and fatigue not already applied
			if (p_aslot[s]->pkf[cki[p_aslot[s]->ui_index]].dir == 1 &&
				!p_aslot[s]->gl_fat[id])
			{
				//if offense action and attack hit something
				//check all keyframes for action type
				//break after offense action found
				int actkf = -1;
				for (register int t = 0; t < p_aslot[s]->nokf; ++t)
					if (p_aslot[s]->pkf[t].action != act_none &&
						p_aslot[s]->pkf[t].action != act_def)
					{
						actkf = t;
						break;
					}

				if (actkf != -1)
				{
					//attack missed
					if (!p_aslot[s]->gl_attack[id])
					{
						//if attack was power attack
						if (p_aslot[s]->power_attack[id] == 1)
							//power air attack
							gl_fatigue_add(s, 3);
						else
							//normal air attack
							gl_fatigue_add(s, 2);

						//air attack drag if within range
						if (fatigue >= SKILL_ADD_FAT)
//							*p_distance <= SKILL_AAD_DISTANCE)
						{
							gl_SetPush(3, 0.2f, 0);
							//s_buffer[S_ERROR]	= SB_PLAY;
						}

						//get defense lock index
						int lindex = p_aslot[s]->pkf[actkf].action - 1;
						//knee locks feet
						if (lindex + 1 == act_kneel)		lindex = 2;
						if (lindex + 1 == act_kneer)		lindex = 3;

						//set defense lock and start time
						gl_lock.set_lockstate(DEFENSIVE, lindex, 0, ON,
											  p_aslot[s]->angle_180[id], p_time->current);
					}
					else
					{
						//attack hit

						//if attack was power attack
						if (p_aslot[s]->power_attack[id] == 1)
							gl_fatigue_add(s, 2);
						else
							gl_fatigue_add(s, 0);
					}
				}
				else
				{
					//non offensive animation
					//!!gl_fatigue_add(s, 0);
					///!!
					//s_buffer[S_ERROR] = SB_PLAY;
				}
			}
	}

	//run fatigue interpolator (also regeneration)
	gl_fatigue_interpolator();

	//---- damage --------------------------------------------------------------------------------

	//calculate damage done by opponent
	//for all actions
	for (a = 0; a < 6; ++a)
		if (p_rcd->attack[!id][a] != -1)
			//prevents attacks with no offensive damage to get registered
//			if (p_rcd->damage[!id] != 0)
			{
				//process damage
				gl_process_damage_def(p_rcd->attack[!id][a], p_rcd->damage[!id], p_rcd->defend[!id], t_move);

/*				//if bone beeing attacked is regular bone
				if (p_rcd->attack[!id][a] < 19)
				{
					//if bone cd_state is not defending
					if (sk.b[p_rcd->attack[!id][a]].cd_state != cds_def)
						//calculate and apply damage taken
						gl_process_damage_def(p_rcd->attack[!id][a], p_rcd->damage[!id], p_rcd->defend[!id], p_option->data.speed, t_move);

					//since simple block-defense seems too strong apply percentage of damage to blocking limb
					//gl_defend values is percentage of damage which gets blocked
					//reduced by damage of bones
					else
					{
						einfach in process damage gucken, ob bone defend?
						gl_process_damage_def(p_rcd->attack[!id][a], p_rcd->damage[!id] * 0.3f, p_rcd->defend[!id], p_option->data.speed, t_move);
					}
				}
				else
				//head, fistl, fistr
				{
					int _bone;
					if (p_rcd->attack[!id][a] == bfistl)		_bone = ball;
					if (p_rcd->attack[!id][a] == bfistr)		_bone = balr;
					if (p_rcd->attack[!id][a] == bhead)			_bone = bn;

					//if bone cd_state is not defending
					if (sk.b[_bone].cd_state != cds_def)
						//calculate and apply damage taken
						gl_process_damage_def(p_rcd->attack[!id][a], p_rcd->damage[!id], p_rcd->defend[!id], p_option->data.speed, t_move);
				}*/

				//reset damage caused
				p_rcd->damage[!id] = 0;
			}
}

//------------------------------------------------------------------------------------------------
//
//	player al_animate
//
//	executes current loaded animations
//
//------------------------------------------------------------------------------------------------

void player::al_animate(bool set_zoom)							//if true, sets player to p_option->data.zoomfactor without interpolating
{
	//if set_zoom true, set player bone data to first keyframe of current loaded
	//animation times zoomfactor without interpolating
	if (set_zoom)
	{
		//for all bones
		for (register int b = 0; b < 19; ++b)
		{
			//if slot loaded with animation
			if (p_aslot[casi[b]] != NULL)
			{
				//set angle, length and width of first keyframe
				sk.b[b].angle	= p_aslot[casi[b]]->pkf[0].angle_ad[id][b];
				sk.b[b].length	= p_aslot[casi[b]]->pkf[0].length_ad[id][b] * p_option->data.zoomfactor;
				sk.b[b].width	= p_aslot[casi[b]]->pkf[0].width_ad[id][b] * p_option->data.zoomfactor;
			}
		}

		return;
	}

	//set t_sca_sf depending on subframes
	t_sca_sf	= (float)(p_time->sca / p_option->data.subframes);

	//for every bone
	for (register int i = 0; i < 19; ++i)
	{
		//if slot loaded with animation
		if (p_aslot[casi[i]] != NULL)
		{
			//---- initialization ----------------------------------------------------------------

			//if uninitialized, initialize
			if (p_aslot[casi[i]]->pkf[cki[i]].state[id][i] == 0)
			{
				//set keyframe state of bone to initialized
				p_aslot[casi[i]]->pkf[cki[i]].state[id][i] = 1;

				//set start time of keyframe for bone
				p_aslot[casi[i]]->pkf[cki[i]].t_kfstart[id][i] = p_time->current;

				//---- set adjusted data ---------------------------------------------------------

				//if bone not hit              
				if (bhi[i] != 1)
				{
					//set to default angle, length, width
					p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].angle[i];
					p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].length[i];
					p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].width[i];

					//apply zoom factor
					p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i]	*= p_option->data.zoomfactor;
					p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i]	*= p_option->data.zoomfactor;

					//apply diff angle
					//if diffn not 0 and user input angle lower than 90 degree
					if (p_aslot[casi[i]]->a_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[id] < 90)
					{
						//adjusted angle is max difference from absolute angle position
						//factored by user input angle
						p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] =
							p_aslot[casi[i]]->pkf[cki[i]].angle[i] +
							(p_aslot[casi[i]]->a_diffn[i] / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[id]);
					}
					if (p_aslot[casi[i]]->a_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[id] >= 90)
					{
						p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] =
							p_aslot[casi[i]]->pkf[cki[i]].angle[i] +
							(p_aslot[casi[i]]->a_diffp[i] / 89.0f) * (p_aslot[casi[i]]->angle_180[id] - 90);
					}
					//check angle_ad doesn't exceed its limit
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] -= 360;
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] += 360;

					//apply diff length
					if (p_aslot[casi[i]]->l_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[id] < 90)
					{
						p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i] =
							(p_aslot[casi[i]]->pkf[cki[i]].length[i] * p_option->data.zoomfactor) +
							(p_aslot[casi[i]]->l_diffn[i] * p_option->data.zoomfactor / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[id]);
					}
					if (p_aslot[casi[i]]->l_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[id] >= 90)
					{
						p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i] =
							(p_aslot[casi[i]]->pkf[cki[i]].length[i] * p_option->data.zoomfactor) +
							(p_aslot[casi[i]]->l_diffp[i] * p_option->data.zoomfactor / 89.0f) * (p_aslot[casi[i]]->angle_180[id] - 90);
					}

					//apply diff width
					if (p_aslot[casi[i]]->w_diffn[i] != 0 && p_aslot[casi[i]]->angle_180[id] < 90)
					{
						p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i] =
							(p_aslot[casi[i]]->pkf[cki[i]].width[i] * p_option->data.zoomfactor) +
							(p_aslot[casi[i]]->w_diffn[i] * p_option->data.zoomfactor / 89.0f) * (89 - p_aslot[casi[i]]->angle_180[id]);
					}
					if (p_aslot[casi[i]]->w_diffp[i] != 0 && p_aslot[casi[i]]->angle_180[id] >= 90)
					{
						p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i] =
							(p_aslot[casi[i]]->pkf[cki[i]].width[i] * p_option->data.zoomfactor) +
							(p_aslot[casi[i]]->w_diffp[i] * p_option->data.zoomfactor / 89.0f) * (p_aslot[casi[i]]->angle_180[id] - 90);
					}

					//adjust to angle mode
					//0 = absolute
					//1 = relative to parent bone
					//2 = relative to current angle
					//3 = relative to default keyframe
					switch (p_aslot[casi[i]]->pkf[cki[i]].mode_a[i])
					{
					//absolute
					case (0):
						{
							break;
						};
					//relative to parent bone
					case (1):
						{
							//index of parent bone
							//if (p_aslot[casi[i]]->pkf[cki[i]].pbi[i] >= 0)
							if (sk.b[i].pbi != -1)
							{
								//if parent bone not hit
								if (bhi[sk.b[i].pbi] != 1)
								{
									//adjusted angle is adjusted parent bone angle plus own offset
									//(represented by its angle or angle_ad, which is either still
									//default or modified by a_diff)
									p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] +=
										//p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][p_aslot[casi[i]]->pkf[cki[i]].pbi[i]];
										//uses animation slot and cki of parent bone (previous bug)
										p_aslot[casi[sk.b[i].pbi]]->pkf[cki[sk.b[i].pbi]].angle_ad[id][sk.b[i].pbi];
								}
								else
								//parent bone hit
								{
									//same as parent not hit
									//relative to adjusted parent bone angle
									//p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] +=
									//	p_aslot[casi[sk.b[i].pbi]]->pkf[cki[sk.b[i].pbi]].angle_ad[id][sk.b[i].pbi];

									//relative to current parent bone angle
									p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] +=
										sk.b[i].p_pb->angle;
									//+ p_aslot[casi[i]]->pkf[cki[i]].angle[i];
								}
							}

							break;
						}
					//relative to current angle
					case (2):
						{
							//angle is current position plus bias (which is keyframe angle)
							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] =
								sk.b[i].angle + p_aslot[casi[i]]->pkf[cki[i]].angle[i];
							break;
						}
					}
					//check angle_ad doesn't exceed its limit
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] -= 360;
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] += 360;

					//user input angle action keyframe
					//also works for defense angle input (action index = 7)
					//but active_off flags of player won't be set
					if (p_aslot[casi[i]]->pkf[cki[i]].action != 0 &&
						p_aslot[casi[i]]->ui_valid[id] == 1 &&
						p_aslot[casi[i]]->ui_index == i)
					{
						//set ui_indexed bone to user input angel plus bias
						p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] =
							(float)p_aslot[casi[i]]->angle[id] + p_aslot[casi[i]]->ui_bias;
					}

					//user input angle buffer keyframe
					if (p_aslot[casi[i]]->pkf[cki[i]].type == 1 &&
						p_aslot[casi[i]]->ui_valid[id] == 1 &&
						p_aslot[casi[i]]->ui_index == i)
					{
						//set ui_indexed bone to user input angel plus bias
						p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] =
							(float)p_aslot[casi[i]]->angle[id] + p_aslot[casi[i]]->ui_bias;
					}

					//check angle_ad doesn't exceed its limit
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 359)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] -= 360;
					if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] < 0)			p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] += 360;

					//convert adjusted data into integer
					p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
					p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i];
					p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i];

					//---- calculate speed of changes --------------------------------------------

					//if first keyframe of animation caluclate speed of change for angle/length/width
					//using the data from default keyframe
					//for every other keyframe use standard values of keyframe (adjusted only
					//for mode_a)

					//!!
					//difference between default current pos (either default keyframe pos
					//or if first keyframe default animation) and next default keyframe pos
					//difference between actual current position and fully adjusted keyframe pos
					//adjust t_frame

					//set adjusted keyframe time to default keyframe time
					p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i] = p_aslot[casi[i]]->pkf[cki[i]].t_frame[i];
					//adjust to speedfactor
					p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i] = (int)((float)p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i] * p_aslot[casi[i]]->speedfactor[id]);

					//calculate difference in degree between current default position and target default position
					//if first keyframe, cdp is from default animation else it's angle_def of previous keyframe
					float angle_diff_dd, angle_diff_ca;

					if (cki[i] == 0)
						if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[i])
							if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] <= 180)
								angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i];
							else
								angle_diff_dd = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i]);
						else
							if (p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] > 180)
								angle_diff_dd = (360 - p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[i];
							else
								angle_diff_dd = p_anmn[asi][AN_DEFAULT]->pkf[DKFI].angle[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i];
					else
						if (p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i] <= p_aslot[casi[i]]->pkf[cki[i]].angle_def[i])
							if (p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i] <= 180)
								angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i];
							else
								angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i] + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i]);
						else
							if (p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i] > 180)
								angle_diff_dd = (360 - p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i]) + p_aslot[casi[i]]->pkf[cki[i]].angle_def[i];
							else
								angle_diff_dd = p_aslot[casi[i]]->pkf[cki[i] - 1].angle_def[i] - p_aslot[casi[i]]->pkf[cki[i]].angle_def[i];
					//absolute difference
					if (angle_diff_dd < 0)		angle_diff_dd = -angle_diff_dd;

					//calculate difference between current position and adjusted target position
					//calculate difference between the two differences
					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle <= 180)
							angle_diff_ca = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle;
						else
							angle_diff_ca = sk.b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]);
					else
						if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 180)
							angle_diff_ca = (360 - sk.b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						else
							angle_diff_ca = sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
					//absolute difference
					if (angle_diff_ca < 0)		angle_diff_ca = -angle_diff_ca;

					//set t_frame_ad, defaultspeed is 90 degree in 100ms
					//only adjust if way increases, decreases stay uneffected
					if (angle_diff_ca - angle_diff_dd > 0)
						p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i] += (int)((angle_diff_ca - angle_diff_dd) / 135.0f * 100.0f);

					//current angle <= target angle
					//ac <= at
					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle <= 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle;
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle + (360 - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i]);
					}
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 180)
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = (360 - sk.b[i].angle) + p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
					}

					//angle change speed is difference times keyframe time
					p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i]);

					//---- length, width ---------------------------------------------------------

					p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i] - sk.b[i].length) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i]);
					p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = (p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i] - sk.b[i].width) * (1000 / p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i]);

					//---- check speed -----------------------------------------------------------
					//if speed smaller than 1 | -1 set speed to 90 | 5

					if (p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] < 1)
						p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] = 90;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = 5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] > -1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] = -5;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] < 1 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] >= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = 1;
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] > -5 &&
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] <= 0)
						p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] = -5;
				}
				//---- initialize hit animation --------------------------------------------------
				else
				{
					//target angle is current angle plus/minus hit force
					//(direction depending on angle of bone and side of player)
					//left side
					if (side == SLEFT)
					{
						if (sk.b[i].angle >= 0 && sk.b[i].angle < 180)
							p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]	= sk.b[i].angle + cd_bh_force[i];
						else
							p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]	= sk.b[i].angle - cd_bh_force[i];
					}
					//right side
					else
					{
						if (sk.b[i].angle >= 0 && sk.b[i].angle < 180)
							p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]	= sk.b[i].angle - cd_bh_force[i];
						else
							p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]	= sk.b[i].angle + cd_bh_force[i];
					}

					//target length and width is default length and width
					p_aslot[casi[i]]->pkf[DKFI].length_ad[id][i]	= (float)(int)p_anmn[asi][AN_HIT]->pkf[DKFI].length[i];
					p_aslot[casi[i]]->pkf[DKFI].width_ad[id][i]		= (float)(int)p_anmn[asi][AN_HIT]->pkf[DKFI].width[i];

					//apply zoom factor
					p_aslot[casi[i]]->pkf[DKFI].length_ad[id][i]	*= p_option->data.zoomfactor;
					p_aslot[casi[i]]->pkf[DKFI].width_ad[id][i]		*= p_option->data.zoomfactor;

					//check angle_ad doesn't exceed its limit
					if (p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] > 359)		p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] -= 360;
					if (p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] < 0)		p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] += 360;

					//convert adjusted data into integer
					p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]		= (float)(int)p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i];
					p_aslot[casi[i]]->pkf[DKFI].length_ad[id][i]	= (float)(int)p_aslot[casi[i]]->pkf[DKFI].length_ad[id][i];
					p_aslot[casi[i]]->pkf[DKFI].width_ad[id][i]		= (float)(int)p_aslot[casi[i]]->pkf[DKFI].width_ad[id][i];

					//---- calculate speed of changes --------------------------------------------

					//set adjusted keyframe time
					//p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i] = p_aslot[casi[i]]->pkf[cki[i]].t_frame[i];
					p_aslot[casi[i]]->pkf[DKFI].t_frame_ad[id][i]		= 70;

					//current angle <= target angle
					//ac <= at
					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i])
					{
						//distance in positive direction is smaller/equal to 180 degree
						//rotate angle in positive direction
						//ac====>at
						if (p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] - sk.b[i].angle <= 180)
							p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] - sk.b[i].angle;
						else
						//rotate in negative direction
						//<==ac----at<==
							p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = sk.b[i].angle + (360 - p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i]);
					}	
					else
					//current angle > target angle
					//ac > at
					{
						//distance in positive direction smaller
						//==>at----ac==>
						if (sk.b[i].angle - p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i] > 180)
							p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = (360 - sk.b[i].angle) + p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i];
						else
						//rotate in negative direction
						//at<====ac
							p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = sk.b[i].angle - p_aslot[casi[i]]->pkf[DKFI].angle_ad[id][i];
					}

					//angle change speed is difference times keyframe time
					p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] * (1000 / p_aslot[casi[i]]->pkf[DKFI].t_frame_ad[id][i]);

					//---- length, width ---------------------------------------------------------

					p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] = (p_aslot[casi[i]]->pkf[DKFI].length_ad[id][i] - sk.b[i].length) * (1000 / p_aslot[casi[i]]->pkf[DKFI].t_frame_ad[id][i]);
					p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] = (p_aslot[casi[i]]->pkf[DKFI].width_ad[id][i] - sk.b[i].width) * (1000 / p_aslot[casi[i]]->pkf[DKFI].t_frame_ad[id][i]);

					//---- check speed -----------------------------------------------------------
					//if speed smaller than 1 | -1 set speed to 90 | 5

					if (p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] < 1)
						p_aslot[casi[i]]->pkf[DKFI].speed_a[id][i] = 90;
					if (p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] < 1 &&
						p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] >= 0)
						p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] = 5;
					if (p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] > -1 &&
						p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] <= 0)
						p_aslot[casi[i]]->pkf[DKFI].speed_l[id][i] = -5;
					if (p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] < 1 &&
						p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] >= 0)
						p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] = 1;
					if (p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] > -5 &&
						p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] <= 0)
						p_aslot[casi[i]]->pkf[DKFI].speed_w[id][i] = -5;
				}
			}
//			else

			//---- interpolate -------------------------------------------------------------------
			//if initialized, animate (within same frame/subframe)

			if (p_aslot[casi[i]]->pkf[cki[i]].state[id][i] == 1)
			{
				//---- angle ---------------------------------------------------------------------

				//if current angle is not target angle
				if (sk.b[i].angle != p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
				{
					//ac <= at
					if (sk.b[i].angle <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
					{
						//ac====>at
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - sk.b[i].angle <= 180)
						{
							if (sk.b[i].angle + p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
								sk.b[i].angle += p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed;
							else
								//set to target angle
								sk.b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						}
						else
						//<==ac----at<==
						{
							if (sk.b[i].angle < p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] ||
								sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed >= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
								sk.b[i].angle -= p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed;
							else
								//set to target angle
								sk.b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						}
					}
					else
					//at > ac
					{
						//==>at----ac==>
						if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 180)
						{
							if (sk.b[i].angle > p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] ||
								sk.b[i].angle + p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed <= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
								sk.b[i].angle += p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed;
							else
								//set to target angle
								sk.b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						}
						else
						//at<====ac
						{
							if (sk.b[i].angle - p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed >= p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i])
								sk.b[i].angle -= p_aslot[casi[i]]->pkf[cki[i]].speed_a[id][i] * t_sca_sf * p_option->data.speed;
							else
								//set to target angle
								sk.b[i].angle = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i];
						}
					}
				}

				//---- joint limit ---------------------------------------------------------------

				//check target angle for validity
					//!!
					/*
						nicht per brute force in process bones sondern hier?
						flag in bone setzen?

						wenn target parent valid
							wenn target child unter target parent plus limit nicht erreichbar
								target child ist max limit
						sonst
							wenn target child unter current parent plus limit nicht erreichbar
								target child ist max limit
					*/

				//if pointer to parent bone not NULL (lower torso)
				if (sk.b[i].p_pb != NULL)
					//if parent bone with valid animation
//					if (p_aslot[casi[p_aslot[casi[i]]->pkf[cki[i]].pbi[i]]] != NULL)
				{
					//relative angle to adjusted parent bone target angle
					float angle_rp = sk.b[i].angle - sk.b[i].p_pb->angle;
//									 p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - 
//									 p_aslot[casi[p_aslot[casi[i]]->pkf[cki[i]].pbi[i]]]->pkf[cki[i]].angle_ad[id][i];

					//set relative angle to shortest direction
					if (angle_rp > 180)			angle_rp = -(360 - angle_rp);
					if (angle_rp < -180)		angle_rp += 360;

					//absolute relative angle
					float angle_rp_abs = angle_rp;
					if (angle_rp_abs < 0)	angle_rp_abs = -angle_rp_abs;

					//limit bone joint
					//if out of limit
					if (angle_rp < sk.b[i].angle_vd[0] ||
						angle_rp > sk.b[i].angle_vd[1])
					{
						//set adjusted angle target to adjusted angle target of parent bone plus limit
						if (fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[0])) <
							fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[1])))
							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = sk.b[i].p_pb->angle + sk.b[i].angle_vd[0];
//							sk.b[i].angle = sk.b[i].p_pb->angle + sk.b[i].angle_vd[0];
//							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = p_aslot[casi[p_aslot[casi[i]]->pkf[cki[i]].pbi[i]]]->pkf[cki[i]].angle_ad[id][i] + sk.b[i].angle_vd[0];
						else
							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = sk.b[i].p_pb->angle + sk.b[i].angle_vd[1];
//							sk.b[i].angle = sk.b[i].p_pb->angle + sk.b[i].angle_vd[1];
//							p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = p_aslot[casi[p_aslot[casi[i]]->pkf[cki[i]].pbi[i]]]->pkf[cki[i]].angle_ad[id][i] + sk.b[i].angle_vd[1];

						//check angle doesn't exceed its limit
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] > 359)	p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] -= 360;
						if (p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] < 0)		p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] += 360;
					}
				}
/*					else
					//parent bone without valid animation
					{
						//relative angle to current parent bone angle
						float angle_rp = p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] - 
										 sk.b[i].p_pb->angle;
//										 sk.b[p_aslot[casi[i]]->pkf[cki[i]].pbi[i]].angle;

						//set relative angle to shortest direction
						if (angle_rp > 180)			angle_rp = -(360 - angle_rp);
						if (angle_rp < -180)		angle_rp += 360;

						//absolute relative angle
						float angle_rp_abs = angle_rp;
						if (angle_rp_abs < 0)	angle_rp_abs = -angle_rp_abs;

						//limit bone joint
						//if out of limit
						if (angle_rp < sk.b[i].angle_vd[0] ||
							angle_rp > sk.b[i].angle_vd[1])
						{
							//set adjusted angle target to current angle of parent bone plus limit
							if (fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[0])) <
								fabs(angle_rp_abs - fabs(sk.b[i].angle_vd[1])))
								p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = sk.b[i].p_pb->angle + sk.b[i].angle_vd[0];
							else
								p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] = sk.b[i].p_pb->angle + sk.b[i].angle_vd[1];
						}
					}*/

				//---- length --------------------------------------------------------------------

				//if current length not target length
				if (sk.b[i].length != p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i])
				{
					//positive speed
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] > 0)
						if (sk.b[i].length + p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] * t_sca_sf * p_option->data.speed <= p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i])
							sk.b[i].length += p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] * t_sca_sf * p_option->data.speed;
						else
							sk.b[i].length = p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i];
					else
					//negative speed
						if (sk.b[i].length + p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] * t_sca_sf * p_option->data.speed >= p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i])
							sk.b[i].length += p_aslot[casi[i]]->pkf[cki[i]].speed_l[id][i] * t_sca_sf * p_option->data.speed;
						else
							sk.b[i].length = p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i];
				}

				//---- width ---------------------------------------------------------------------

				//if current width not target width
				if (sk.b[i].width != p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i])
				{
					//positive speed
					if (p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] > 0)
						if (sk.b[i].width + p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] * t_sca_sf * p_option->data.speed <= p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i])
							sk.b[i].width += p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] * t_sca_sf * p_option->data.speed;
						else
							sk.b[i].width = p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i];
					else
					//negative speed
						if (sk.b[i].width + p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] * t_sca_sf * p_option->data.speed >= p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i])
							sk.b[i].width += p_aslot[casi[i]]->pkf[cki[i]].speed_w[id][i] * t_sca_sf * p_option->data.speed;
						else
							sk.b[i].width = p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i];
				}
			}
		}
	}

	//target angle of back torso (up and low) is always the same as front
	if (p_aslot[casi[btll]] != NULL &&
		p_aslot[casi[btlr]] != NULL &&
		p_aslot[casi[btul]] != NULL &&
		p_aslot[casi[btur]] != NULL)
	{
		if (stance_feet == SLEFT)
		{
			p_aslot[casi[btlr]]->pkf[cki[btlr]].angle_ad[id][btlr] =
					p_aslot[casi[btll]]->pkf[cki[btll]].angle_ad[id][btll];
			p_aslot[casi[btur]]->pkf[cki[btur]].angle_ad[id][btur] =
					p_aslot[casi[btul]]->pkf[cki[btul]].angle_ad[id][btul];
		}
		else
		{
			p_aslot[casi[btll]]->pkf[cki[btll]].angle_ad[id][btll] =
					p_aslot[casi[btlr]]->pkf[cki[btlr]].angle_ad[id][btlr];
			p_aslot[casi[btul]]->pkf[cki[btul]].angle_ad[id][btul] =
					p_aslot[casi[btur]]->pkf[cki[btur]].angle_ad[id][btur];
		}
	}

	//---- hara initializing/interpolation -------------------------------------------------------

	//---- hara.x ----------------------------------------------------------------------------

	//if slot loaded with animation
	if (p_aslot[casi[IHX]] != NULL)
	{
		//---- initialize ------------------------------------------------------------------------

		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].state[id][IHX] == 0)
		{
			//set keyframe state of bone to initialized
			p_aslot[casi[IHX]]->pkf[cki[IHX]].state[id][IHX] = 1;

			//set start time of keyframe for bone
			p_aslot[casi[IHX]]->pkf[cki[IHX]].t_kfstart[id][IHX] = p_time->current;

			//set adjusted data
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x = p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x;
			//apply zoom factor
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x *= p_option->data.zoomfactor;

			//apply diff pos
			if (p_aslot[casi[IHX]]->h_diffn.x != 0 && p_aslot[casi[IHX]]->angle_180[id] < 90)
			{
				//adjusted hara.x is max difference from absolute hara.x offset
				//factored by user input angle
				p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x =
					(p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x * p_option->data.zoomfactor) +
					(p_aslot[casi[IHX]]->h_diffn.x * p_option->data.zoomfactor / 89.0f) * (89 - p_aslot[casi[IHX]]->angle_180[id]);
			}
			if (p_aslot[casi[IHX]]->h_diffp.x != 0 && p_aslot[casi[IHX]]->angle_180[id] >= 90)
			{
				p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x =
					(p_aslot[casi[IHX]]->pkf[cki[IHX]].hara.x * p_option->data.zoomfactor) +
					(p_aslot[casi[IHX]]->h_diffp.x * p_option->data.zoomfactor / 89.0f) * (p_aslot[casi[IHX]]->angle_180[id] - 90);
			}

			//convert to integer to avoid rounding errors (will be integer onscreen anyway)
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x = (float)(int)p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x;
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x = (float)(int)p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x;

			//set adjusted keyframe time to default keyframe time
			p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame_ad[id][IHX] = p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame[IHX];
			//adjust to speedfactor
			p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame_ad[id][IHX] = (int)((float)p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame_ad[id][IHX] * p_aslot[casi[IHX]]->speedfactor[id]);

			//calculate speed of change
			p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x = p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x * (1000 / p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame_ad[id][IHX]);
			//set hara.x reference
			p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x	= p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_ad[id].x;

			//check speed
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x < 1 &&
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x >= 0)
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x = 5;
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x > -1 &&
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x <= 0)
				p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x = -5;
		}
//		else

		//---- interpolate ----------------------------------------------------------------------
		//if initialized, animate (within same frame/subframe)

		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].state[id][IHX] == 1)
		{
			//if reference counter is not 0
			//(holds length of movement and gets decreased for every movement till 0)
			if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x != 0)
			{
				//adjust reference counter of x movement
				if (p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x > 0)
					if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x - p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed >= 0)
					{
						//adjust reference counter
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x -= p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed;
						//also apply movement to player
						sk.p_ref->v.p[0].x += p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed;
					}
					else
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x = 0;
				else
					if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x - p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed <= 0)
					{
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x -= p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed;
						sk.p_ref->v.p[0].x += p_aslot[casi[IHX]]->pkf[cki[IHX]].speed_h[id].x * t_sca_sf * p_option->data.speed;
					}
					else
						p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x = 0;
			}
		}
	}

	//---- hara.y --------------------------------------------------------------------------------

	//if slot loaded with animation
	if (p_aslot[casi[IHY]] != NULL)
	{
		//---- initialize ------------------------------------------------------------------------

		if (p_aslot[casi[IHY]]->pkf[cki[IHY]].state[id][IHY] == 0)
		{
			//set keyframe state of bone to initialized
			p_aslot[casi[IHY]]->pkf[cki[IHY]].state[id][IHY] = 1;

			//set start time of keyframe for bone
			p_aslot[casi[IHY]]->pkf[cki[IHY]].t_kfstart[id][IHY] = p_time->current;

			//set adjusted data
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y = p_aslot[casi[IHY]]->pkf[cki[IHY]].hara.y;
			//apply zoom factor
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y *= p_option->data.zoomfactor;

			//apply diff pos
			if (p_aslot[casi[IHY]]->h_diffn.y != 0 && p_aslot[casi[IHY]]->angle_180[id] < 90)
			{
				//adjusted hara.y is max difference from absolute hara.y offset
				//factored by user input angle
				p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y =
					p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y +
					(p_aslot[casi[IHY]]->h_diffn.y * p_option->data.zoomfactor / 89.0f) * (89 - p_aslot[casi[IHY]]->angle_180[id]);
			}
			if (p_aslot[casi[IHY]]->h_diffp.y != 0 && p_aslot[casi[IHY]]->angle_180[id] >= 90)
			{
				p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y =
					p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y +
					(p_aslot[casi[IHY]]->h_diffp.y * p_option->data.zoomfactor / 89.0f) * (p_aslot[casi[IHY]]->angle_180[id] - 90);
			}

			//convert to integer to avoid rounding errors
			p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y = (float)(int)p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y;

			//!!! default keyframe?

			//set adjusted keyframe time to default keyframe time
			p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame_ad[id][IHY] = p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame[IHY];
			//adjust to speedfactor
			p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame_ad[id][IHY] = (int)((float)p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame_ad[id][IHY] * p_aslot[casi[IHY]]->speedfactor[id]);

			//calculate speed of change
			p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y =
				((S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y) - sk.p_ref->v.p[0].y) *
				(1000 / p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame_ad[id][IHY]);

			//check speed
			if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y < 1 &&
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y >= 0)
				p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y = 5;
			if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y > -1 &&
			p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y <= 0)
					p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y = -5;
		}
//		else

		//---- interpolate ----------------------------------------------------------------------
		//if initialized, animate (within same frame/subframe)

		if (p_aslot[casi[IHY]]->pkf[cki[IHY]].state[id][IHY] == 1)
		{
			//if current hara.y position is not absolute position
			if (sk.p_ref->v.p[0].y != S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y)
			{
				if (p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y > 0)
					if (sk.p_ref->v.p[0].y + p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y * t_sca_sf * p_option->data.speed <= S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y)
						sk.p_ref->v.p[0].y += p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y * t_sca_sf * p_option->data.speed;
					else
						sk.p_ref->v.p[0].y = S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y;
				else
					if (sk.p_ref->v.p[0].y + p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y * t_sca_sf * p_option->data.speed >= S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y)
						sk.p_ref->v.p[0].y += p_aslot[casi[IHY]]->pkf[cki[IHY]].speed_h[id].y * t_sca_sf * p_option->data.speed;
					else
						sk.p_ref->v.p[0].y = S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y;
			}
		}
	}

	//---- advance keyframe ----------------------------------------------------------------------
	//the current keyframe index (cki) of a bone is advanced (if not last keyframe of
	//animtion) as soon as this bone has reached its position (angle, length, width)
	//and all other bones with same current animation slot index (casi) and same
	//priority have reached their positions
	//
	//for example:
	//left arm and right arm use same animation slot and each bone has the same priority
	//as soon as all bones have reached their positions, they get advanced to the next keyframe

	//reset bone done counter
	ZeroMemory(&bdc, sizeof(bdc));

	//---- check if bone/hara done ---------------------------------------------------------------

	//for every bone
	for (i = 0; i < 19; ++i)
		//if slot loaded with animation
		if (p_aslot[casi[i]] != NULL)
		{
			//angle, length and width are at target position
			//and time since keyframe ini is at least adjusted keyframe time
			if (sk.b[i].angle == p_aslot[casi[i]]->pkf[cki[i]].angle_ad[id][i] &&
				sk.b[i].length == p_aslot[casi[i]]->pkf[cki[i]].length_ad[id][i] &&
				sk.b[i].width == p_aslot[casi[i]]->pkf[cki[i]].width_ad[id][i] &&
				p_aslot[casi[i]]->pkf[cki[i]].t_kfstart[id][i] +
				((0.001f * p_aslot[casi[i]]->pkf[cki[i]].t_frame_ad[id][i]) / p_option->data.speed) * p_time->freq <= p_time->current)
			{
				//if bone not bound to hit-slot
				if (bhi[i] != 1)
				{
					//increase number of bones done with this priority
					++bdc[casi[i]][p_aslot[casi[i]]->priority[i]];
					//if last keyframe of animation also increase number of bones in this slot done
					if (cki[i] == p_aslot[casi[i]]->nokf - 1)
						++bdc[casi[i]][21];
				}
				else
				{
					//reset keyframe state for this bone
					p_aslot[casi[i]]->pkf[cki[i]].state[id][i] = 0;
					//deactivate bone hit indicator of bone
					bhi[i]		= 0;
					//!!
					/*
					if (bhi[btll] == 0)	{bhi[btlr] = 0;	bhi[btlr] = 0;}
					if (bhi[btlr] == 0)	{bhi[btll] = 0; bhi[btll] = 0;}
					if (bhi[btul] == 0)	{bhi[btur] = 0; bhi[btur] = 0;}
					if (bhi[btur] == 0)	{bhi[btul] = 0; bhi[btul] = 0;}*/
					//reset priority
					al_set_priority();
				}

				//!! delete damage if bone done
				//sk.b[i].damage = 0;
			}
			else
			{
				//!! apply damage if bone not done
				//sk.b[i].damage = 50;
			}
		}

	//check hara if done
	//if slot loaded with animation
	if (p_aslot[casi[IHX]] != NULL)
		if (p_aslot[casi[IHX]]->pkf[cki[IHX]].hara_r[id].x == 0 &&
			p_aslot[casi[IHX]]->pkf[cki[IHX]].t_kfstart[id][IHX] +
			((0.001f * p_aslot[casi[IHX]]->pkf[cki[IHX]].t_frame_ad[id][IHX]) / p_option->data.speed) * p_time->freq <= p_time->current)
		{
			++bdc[casi[IHX]][p_aslot[casi[IHX]]->priority[IHX]];
			//if last keyframe of animation also increase number of bones in this slot done
			if (cki[IHX] == p_aslot[casi[IHX]]->nokf - 1)
				++bdc[casi[IHX]][21];
		}
	//if slot loaded with animation
	if (p_aslot[casi[IHY]] != NULL)
		if (sk.p_ref->v.p[0].y == S_PYDEF + p_aslot[casi[IHY]]->pkf[cki[IHY]].hara_ad[id].y &&
			p_aslot[casi[IHY]]->pkf[cki[IHY]].t_kfstart[id][IHY] +
			((0.001f * p_aslot[casi[IHY]]->pkf[cki[IHY]].t_frame_ad[id][IHY]) / p_option->data.speed) * p_time->freq <= p_time->current)
		{
			++bdc[casi[IHY]][p_aslot[casi[IHY]]->priority[IHY]];
			//if last keyframe of animation also increase number of bones in this slot done
			if (cki[IHY] == p_aslot[casi[IHY]]->nokf - 1)
				++bdc[casi[IHY]][21];
		}

	//---- advance keyframes and animations ------------------------------------------------------

	//for all bones
	for (register int b = 0; b < 21; ++b)
		//if slot loaded with animation
		if (p_aslot[casi[b]] != NULL)
		{
			//if bpc of this bones slot and this bones priority is
			//same as bdc of this bones slot and this bones priority
			if (bpc[casi[b]][p_aslot[casi[b]]->priority[b]] ==
				bdc[casi[b]][p_aslot[casi[b]]->priority[b]])
			{
				//if buffer-keyframe and animation in pre-state
				//and all highest priority bones done
				//set soundflag so that sound is paused until final-state activated
				if (p_aslot[casi[b]]->pkf[cki[b]].type == 1 &&
					p_aslot[casi[b]]->state[id] == AS_PRE)
					s_set_slotsound(casi[b], SB_PAUSE);

				//if type not buffer keyframe
				if (p_aslot[casi[b]]->pkf[cki[b]].type == 0 ||
					(p_aslot[casi[b]]->pkf[cki[b]].type == 1 &&
					p_aslot[casi[b]]->state[id] == AS_FINAL))
				{
					//if current keyframe index of bone is smaller than number of kf in this animation
					if (cki[b] < p_aslot[casi[b]]->nokf - 1)
					{
						//reset keyframe state for this bone, increase keyframe
						p_aslot[casi[b]]->pkf[cki[b]].state[id][b] = 0;
						++cki[b];
					}
				}
			}
		}

	//deactivate animation if all bones of slot done
	//for both slots
	for (register int s = 0; s < 2; ++s)
		//if all bones of slot done
		if (bpc[s][21] == bdc[s][21])
		{
			al_deactivate_slot(s);

			//apply idle animation as default so player is never without assigned animation
			//same logic as in process_input
			//(happens if subframes > 1 because gl_process_input is called only every frame)
			if (s == aslot_cycle)
			{
				if (p_aslot[aslot_action] == NULL || p_aslot[aslot_action] == p_anmn[asi][AN_IDLE_LO])
				{
					if (last_anmn[aslot_cycle] != AN_IDLE_HI)
						al_create_idle_cycle(0, 100);
					else
						al_create_idle_cycle(0, 0);
					al_activate_slot(aslot_cycle, AN_IDLE_HI);
				}
			}
			else
			{
				if (p_aslot[aslot_cycle] == NULL || p_aslot[aslot_cycle] == p_anmn[asi][AN_IDLE_HI])
				{
					if (last_anmn[aslot_action] != AN_IDLE_LO)
						al_create_idle_cycle(1, 100);
					else
						al_create_idle_cycle(1, 0);
					al_activate_slot(aslot_action, AN_IDLE_LO);
				}
			}
//!!
/*
if (id == P1)
	if (s == 0)
		s_buffer[S_ERROR]	= SB_PLAY;
	else
		s_buffer[S_HIT_STD]	= SB_PLAY;*/
		}

	return;
}

//------------------------------------------------------------------------------------------------
//
//	player al_SetFreezeFrame
//
//	sets freeze frame
//
//------------------------------------------------------------------------------------------------

void player::al_SetFreezeFrame(int slot, int t_freeze)
{
	//slot valid
	if (p_aslot[slot] != NULL)
	{
		//verify freeze time
		if (t_freeze < 0)
			t_freeze	= 0;

		//for all bones
		for (register int i = 0; i < 19; ++i)
		{
			//if bones belongs to argumented slot
			if (casi[i] == slot)
			{
				//set angle, length and width target pos to current bone pos
				p_aslot[slot]->pkf[cki[i]].angle_ad[id][i]		= sk.b[i].angle;
				p_aslot[slot]->pkf[cki[i]].length_ad[id][i]		= sk.b[i].length;
				p_aslot[slot]->pkf[cki[i]].width_ad[id][i]		= sk.b[i].width;

				//reset start time and set freeze time in milliseconds
				p_aslot[slot]->pkf[cki[i]].t_kfstart[id][i]		= p_time->current;
				p_aslot[slot]->pkf[cki[i]].t_frame_ad[id][i]	= t_freeze;	//(int)(t_freeze / p_option->data.speed);
			}
		}

//!!!
/*		//for hara.x
		if (casi[IHX] == slot)
		{
			//halt movement
			p_aslot[slot]->pkf[cki[IHX]].hara_ad[id].x			= 0;

			p_aslot[slot]->pkf[cki[IHX]].t_kfstart[id][IHX]		= p_time->current;
			p_aslot[slot]->pkf[cki[IHX]].t_frame_ad[id][IHX]	= t_freeze;	//(int)(t_freeze / p_option->data.speed);
		}
		//for hara.y
		if (casi[IHY] == slot)
		{
			//halt movement
			p_aslot[slot]->pkf[cki[IHY]].hara_ad[id].y			= 0;

			p_aslot[slot]->pkf[cki[IHY]].t_kfstart[id][IHY]		= p_time->current;
			p_aslot[slot]->pkf[cki[IHY]].t_frame_ad[id][IHY]	= t_freeze;	//(int)(t_freeze / p_option->data.speed);
		}*/
	}
}

//------------------------------------------------------------------------------------------------
//
//	player al_SetDelayedAnimationAdj
//
//	sets delayed animation adjustment
//
//	AADJ_SETTARGET		1				//sets current bone position as its current target (softer)
//	AADJ_ADVKF			2				//advances keyframe (harder)
//
//------------------------------------------------------------------------------------------------

void player::al_SetDelayedAnimationAdj(int slot, int t_delay, int type)
{
	//verify argumented slot
	if (slot == aslot_cycle || slot == aslot_action)
	{
		//slot valid
		if (p_aslot[slot] != NULL)
		{
			//verify and assign t_delay
			if (t_delay > 0)
			{
				t_animation_adj_start[slot]		= p_time->current;
				t_animation_adj_delay[slot]		= t_delay;
				animation_adj_type[slot]		= type;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player 	al_ResetDelayedAnimationAdj
//
//	resets delayed animation adjustment data
//
//------------------------------------------------------------------------------------------------

void player::al_ResetDelayedAnimationAdj(int slot)
{
	//verify slot
	if (slot == aslot_cycle || slot == aslot_action)
	{
		t_animation_adj_start[slot]		= 0;
		t_animation_adj_delay[slot]		= 0;
		animation_adj_type[slot]		= 0;
	}
}

//------------------------------------------------------------------------------------------------
//
//	player 	al_ProcessDelayAnimationAdj
//
//	checks and executes delayed animation adjustment
//
//------------------------------------------------------------------------------------------------

void player::al_ProcessDelayAnimationAdj()
{
	//both slots
	for (register int s = 0; s < 2; ++s)
	{
		//if active
		if (t_animation_adj_start[s] > 0)
		{
			//if time since start plus delay (adjusted to user set speed) >= current time
			if (t_animation_adj_start[s] + p_time->freq * ((t_animation_adj_delay[s] / p_option->data.speed) / 1000.0f) <= p_time->current)
			{
				//slot valid and animation still advancing
				if (p_aslot[s] != NULL)
				{
					//animation still on way forward
					if (p_aslot[s]->pkf[cki[p_aslot[s]->ui_index]].dir == 0)
					{
						//s_set_sound(S_ERROR);

						//set bone target to current position
						if (animation_adj_type[s] == AADJ_SETTARGET)
							//for all bones
							for (register int b = 0; b < 19; ++b)
							{
								//if bones belongs to argumented slot
								if (casi[b] == s)
								{
									//set angle, length and width target pos to current bone pos
									p_aslot[s]->pkf[cki[b]].angle_ad[id][b]		= sk.b[b].angle;
									p_aslot[s]->pkf[cki[b]].length_ad[id][b]	= sk.b[b].length;
									p_aslot[s]->pkf[cki[b]].width_ad[id][b]		= sk.b[b].width;

									//reset start time and set freeze time in milliseconds
	//								p_aslot[s]->pkf[cki[b]].t_kfstart[id][b]	= p_time->current;
	//								p_aslot[s]->pkf[cki[b]].t_frame_ad[id][b]	= t_freeze;	//(int)(t_freeze / p_option->data.speed);
								}
							}

						//increase keyframe of bone
						if (animation_adj_type[s] == AADJ_ADVKF)
							//all bones and hara
							for (register int b = 0; b < 21; ++b)
							{
								//if bone belongs to current slot and
								//current keyframe of bone is a forward moving keyframe
								if (casi[b] == s && p_aslot[s]->pkf[cki[b]].dir == 0)
									//if not already reached last keyframe
									if (casi[b] == s && cki[b] < p_aslot[s]->nokf - 1)
									{
										//reset state of current keyframe, increase keyframe
										p_aslot[s]->pkf[cki[b]].state[id][b] = 0;
										++cki[b];
									}
							}
					}
				}

				//reset delay data
				//if slot invalid or done adjusting
				al_ResetDelayedAnimationAdj(s);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
//
//	player gl_SetBoneLockState
//
//	sets lock states of bones depening on gl_lock data
//
//------------------------------------------------------------------------------------------------

void player::gl_SetBoneLockState(bool reset)
{
	//if to reset all bones
	if (reset)
	{
		//for all bones
		for (register int i = 0; i < 19; ++i)
		{
			sk.b[i].lock_state		= ls_nolock;
		}

		return;
	}

	//don't show
	if (p_option->data.show_lockstate == 0)
		return;

	//lock states, default off
	int	arm_left	= ls_nolock;
	int	arm_right	= ls_nolock;
	int	leg_left	= ls_nolock;
	int	leg_right	= ls_nolock;

	//offense lock only
	if (gl_lock.lock_off[0] && !gl_lock.lock_def[0])		arm_left	= ls_off;
	if (gl_lock.lock_off[1] && !gl_lock.lock_def[1])		arm_right	= ls_off;
	if (gl_lock.lock_off[2] && !gl_lock.lock_def[2])		leg_left	= ls_off;
	if (gl_lock.lock_off[3] && !gl_lock.lock_def[3])		leg_right	= ls_off;

	//defense lock only
	if (!gl_lock.lock_off[0] && gl_lock.lock_def[0])		arm_left	= ls_def;
	if (!gl_lock.lock_off[1] && gl_lock.lock_def[1])		arm_right	= ls_def;
	if (!gl_lock.lock_off[2] && gl_lock.lock_def[2])		leg_left	= ls_def;
	if (!gl_lock.lock_off[3] && gl_lock.lock_def[3])		leg_right	= ls_def;

	//offense and defense lock
	if (gl_lock.lock_off[0] && gl_lock.lock_def[0])			arm_left	= ls_offdef;
	if (gl_lock.lock_off[1] && gl_lock.lock_def[1])			arm_right	= ls_offdef;
	if (gl_lock.lock_off[2] && gl_lock.lock_def[2])			leg_left	= ls_offdef;
	if (gl_lock.lock_off[3] && gl_lock.lock_def[3])			leg_right	= ls_offdef;

	//set lock state
	sk.b[bsl].lock_state	= arm_left;
	sk.b[baul].lock_state	= arm_left;
	sk.b[ball].lock_state	= arm_left;

	sk.b[bsr].lock_state	= arm_right;
	sk.b[baur].lock_state	= arm_right;
	sk.b[balr].lock_state	= arm_right;

	sk.b[bhl].lock_state	= leg_left;
	sk.b[blul].lock_state	= leg_left;
	sk.b[blll].lock_state	= leg_left;
	sk.b[bfl].lock_state	= leg_left;

	sk.b[bhr].lock_state	= leg_right;
	sk.b[blur].lock_state	= leg_right;
	sk.b[bllr].lock_state	= leg_right;
	sk.b[bfr].lock_state	= leg_right;
}

//------------------------------------------------------------------------------------------------
//
//	player s_reset_soundbuffer
//
//	reset soundbuffer status
//
//------------------------------------------------------------------------------------------------

void player::s_reset_soundbuffer()
{
	for (register int i = 0; i < NSBP; ++i)
		s_buffer[i]		= SB_OFF;
}

//------------------------------------------------------------------------------------------------
//
//	player s_set_slotsound
//
//	sets soundbuffer of argumented slot to argumented state
//	returns false if slot not valid/active or slot has no valid sound id
//
//------------------------------------------------------------------------------------------------

bool player::s_set_slotsound(int slot, int SC)
{
	//if slot valid
	if (p_aslot[slot] != NULL)
	{
		//if sound-id of animation in slot valid
		if (p_aslot[slot]->gl_soundid != -1)
		{
			s_buffer[p_aslot[slot]->gl_soundid] = SC;
			return(true);
		}
		else
			return(false);
	}
	else
		return(false);
}

//------------------------------------------------------------------------------------------------
//
//	player s_set_sound
//
//	sets argumented sound to argumented state
//
//------------------------------------------------------------------------------------------------

void player::s_set_sound(int soundid, int SC)
{
	s_buffer[soundid]	= SC;
}

//------------------------------------------------------------------------------------------------
//
//	player con_add_message
//
//	and now for the more professional version of the same thing
//	(*weep*)
//
//------------------------------------------------------------------------------------------------

void player::con_add_message(char *format, ...)
{
	//argument pointer
	va_list		ap;

	//initialize argument pointer
	va_start(ap, format);

	//clear message dump
	con_clear();

	//print formated string in console dump message
    vsprintf(con_dumpmessage, format, ap);

	//clear up
	va_end(ap);
}

//------------------------------------------------------------------------------------------------
//
//	player con_clear
//
//	clears console message buffer
//
//------------------------------------------------------------------------------------------------

void player::con_clear()
{
	ZeroMemory(&con_dumpmessage, sizeof(con_dumpmessage));
}

//------------------------------------------------------------------------------------------------
//
//	player hud_add_message
//
//------------------------------------------------------------------------------------------------

void player::hud_add_message(int _hud_id, int color, char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "player::hud_add_message NULL");
		return;
	}

	//verify id
	if (_hud_id > HUD_NOH - 1)		_hud_id	= 0;
	if (_hud_id < 0)				_hud_id = 0;

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	player hud_add_message
//
//------------------------------------------------------------------------------------------------

void player::hud_add_message(char *format, ...)
{
	//no text
	if (format == NULL)
	{
		gf_logger(true, "player::hud_add_message NULL");
		return;
	}

	//argument pointer
	va_list		ap;
	//initialize argument pointer
	va_start(ap, format);

	//holds formatted message
//	char *pbuffer	= new char[strlen(format) + 1];
	char pbuffer[HUD_TEXT_MAX_ENTRY_LENGTH];
	//copy message into buffer
	vsprintf(pbuffer, format, ap);
	//clear up
	va_end(ap);

	//default values
	int _hud_id		= 0;
	int color		= bmfblack;

	//create new hud entry
	p_hud_text[_hud_id].add_entry(color, pbuffer);

//	delete []	pbuffer;
//	pbuffer		= NULL;
}

//------------------------------------------------------------------------------------------------
//
//	player float_string
//
//	converts float into string which gets stored in argumented character array
//
//------------------------------------------------------------------------------------------------

void player::float_string(char numberstring[], int precision, double number)
{
	//check precision for validity
	if (precision < 0 || precision > 12)
		precision = 2;

	//convert float into string
	int decimal		= 0;		int sign = 0;
	char *ws;
	//convert number in ws char pointer, store decimal and sign in temporary variables
	ws = _fcvt(number, precision, &decimal, &sign);

	//if length of ws is zero, assign '0' and null to string
	if (strlen(ws) == 0)
	{
		numberstring[0] = 48;
		numberstring[1] = 0;
	}

	//format string using decimal and sign and store it in numberstring buffer
	for (register int i = 0, k = 0; i < 50 && ws[k] != 0; ++i, ++k)
	{
		if (k == 0 && sign != 0)
		{
			numberstring[i] = '-';
			++i;
		}

		if (k == 0 && decimal <= 0)
		{
			numberstring[i] = '0';
			numberstring[i + 1] = '.';
			i += 2;

			for (register int d = 0; d < -decimal; ++d)
			{
				numberstring[i] = '0';
				++i;
			}
		}

		if (k != 0 && decimal == k)
		{
			numberstring[i] = '.';
			++i;
		}

		numberstring[i] = ws[k];
	}
}