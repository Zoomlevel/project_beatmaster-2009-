//------------------------------------------------------------------------------------------------
//
//	directdraw class declaration
//
//------------------------------------------------------------------------------------------------

#ifndef DIRECTDRAW_H
#define DIRECTDRAW_H						//begin DIRECTDRAW_H

#include <ddraw.h>							//direct draw header
#include "structs.h"						//structs

//---- defines -----------------------------------------------------------------------------------

#define U_BITMAP	"beatmaster.bmp"		//offscreen bitmap to load

//------------------------------------------------------------------------------------------------

//global variable indicates program status
//0 == program inactive, idle
//1 == program running, resume
//2 == program reactivated, restore surfaces
extern int gAppState;

extern bool gAppRefresh;

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//---- error message strings ---------------------------------------------------------------------

extern const char *gp_ErrStr;				//global error string, in winmain.cpp

const char Err_DDDirectDrawCreateEx[]		= "DirectDrawCreateEx FAILED";
const char Err_DDSetCooperativeLevel[]		= "DD_SetCooperativeLevel FAILED";
const char Err_DDSetDisplayMode[]			= "SetDisplayMode FAILED";
const char Err_DDCreateSurfaceFB[]			= "CreateSurface (Primarybuffer) FAILED";
const char Err_DDGetAttachedSurface[]		= "GetAttachedSurface (Backbuffer) FAILED";
const char Err_DDCreateSurfaceOSB[]			= "CreateSurface (OffScreen) FAILED";
const char Err_DDGetPixelFormat[]			= "GetPixelFormat FAILED";
const char Err_DDSetColorKey[]				= "SetColorKey (OffScreen) FAILED";
const char Err_DDQueryInterface[]			= "QueryInterface (Gamma Control) FAILED";
const char Err_DDGetGammaRamp[]				= "GetGammaRamp FAILED";
const char Err_DDRestore[]					= "Error Restoring DD_Surfaces";

const char Err_DDLoadBMP[]					= "Error Loading Bitmap";

//------------------------------------------------------------------------------------------------

class directdraw
{
//------------------------------------------------------------------------------------------------
//	private directdraw objects
//------------------------------------------------------------------------------------------------

private:

	HRESULT						hRet;			//result of directdraw methods

	LPDIRECTDRAW7				lpDD7;			//pointer to dd7-object
	LPDIRECTDRAWSURFACE7		lpDDSPrimary;	//primary surface pointer
	LPDIRECTDRAWSURFACE7		lpDDSBack;		//back surface pointer
	LPDIRECTDRAWSURFACE7		lpDDSOff;		//offscreen surface pointer

	DDSURFACEDESC2				ddsd;			//contains surface description
	DDSCAPS2					ddscaps;		//defines capilities of surface, part of DDSURFACEDESC2
	LONG						ddspitch;		//contains surface pitch
//	unsigned short				*lplocked;		//pointer to surface (16-bit)

	LPDIRECTDRAWGAMMACONTROL	lpDDGamma;		//pointer to gamma interface
	DDGAMMARAMP					ddgamma;		//gamma structure
	DDGAMMARAMP					ddgamma_backup;	//contains old gamma settings


	DDPIXELFORMAT				ddpixel;		//structure with pixel format information
	DDCOLORKEY					ddcolorkey;		//structure with color key information
	DDBLTFX						ddbltfx;		//structure contains raster information

//------------------------------------------------------------------------------------------------
//	private directdraw functions
//------------------------------------------------------------------------------------------------

	//loads bitmap from file into offscreen surface
	//called by initialization() and restore()
	bool load_bitmap();

//------------------------------------------------------------------------------------------------
//	public directdraw objects
//------------------------------------------------------------------------------------------------

public:

	//---- timer/option data ---------------------------------------------------------------------

	const options	*p_option;						//pointer to options
	const timer		*p_time;						//pointer to timer

	//---- screen data ---------------------------------------------------------------------------

	RECT		rSCREEN;						//rect with screen-height/width values
	RECT		rSCREEN169;						//rect with 16:9 screen values
	RECT		rSCREEN_ARENA_TOP;				//rect with 16:9 screen only above area ground
	const int	COLORDEPTH;						//colordepth in bit per pixel

	gamma_change_settings		gcs;			//gamma change settings

	//---- RGB look up tables --------------------------------------------------------------------

	//32-bit unsigned integer
	DWORD		*p_rLUT;
	DWORD		*p_gLUT;
	DWORD		*p_bLUT;

	//---- color look up tables ------------------------------------------------------------------

	WORD		(*p_blackwhiteLUT)[3];			//black to white LUT
	WORD		(*p_bluewhiteLUT)[3];			//blue to white LUT
	WORD		(*p_greenredLUT)[3];			//green to red LUT
	WORD		(*p_greenblueLUT)[3];			//green to blue LUT
	WORD		(*p_yellowpinkLUT)[3];			//yellow to pink LUT

	//---- font look up tables -------------------------------------------------------------------

	RECT		*p_cfontbm_LUT;					//bitmap font
	point		bmfs_offset[9];					//bitmap font surface offset for
												//different color sets
	RECT		(*p_cfontsl_LUT)[6];			//scanline font

	//---- head and fist arrays ------------------------------------------------------------------

	signed char	*fist_a;						//fist array describing fist (0 = empty, 1 = border, 2 = fillcolor)
	signed char *head_f;						//head front (bigger fatigue indicator)
												//(0 = empty, 1 = border, 2 = damage, 3 = fatigue)
	signed char *head_b;						//head back (smaller fatigue indicator)

	//---- console variables ---------------------------------------------------------------------

	char				con_dumpmessage[CON_LINEMAX];	//console dump message

	//---- hud text data -------------------------------------------------------------------------

	hud_text		*p_hud_text;					//pointer to hud text

	//---- developer objects ---------------------------------------------------------------------

	int								VRAM_nlocks;			//holds numbers of vram locks
	int								VRAM_locked;			//true if video surface locked
	int								dev_i;					//can be filled with various data
	float							dev_f;					//just used to check certain values
	point							dev_p[2];

	int								*dev_pi;
	float							*dev_pf;

//------------------------------------------------------------------------------------------------
//	public directdraw functions
//------------------------------------------------------------------------------------------------

	//constructor
	directdraw();

	//directdraw initialization
	bool dd_initialization(HWND hwnd);				//hwnd for SetCooperativeLevel

	//dd initialization depending on screen mode
	bool dd_initialization_screenmode(HWND hwnd);

	//clean up frees ddraw interfaces
	void dd_cleanup();

	//clean up dd objects for screenmode change
	bool dd_cleanup_screenmode(HWND hwnd);

	//restores surfaces, reloades bitmap
	bool dd_restore();

	//set pointer to timer/option/hud data pointer
	void set_data_pointer(options *_options, timer *_timer, hud_text *_hud);

	//---- elemantary routines -------------------------------------------------------------------

	//flips surfaces
	void flip(int vsync);

	//standard screen rectangle clipper
	bool clipper(RECT rscreen,
				 RECT &rsource,
				 RECT &rdest);

	//clips four points of rectangle by reference
	void rectclipper(rectangle &r);

	//standard screen line clipper
	bool lineclipper(line &l);

	//fills RECT structure (for convenience)
	RECT &fillRECT(RECT &r, int x1, int y1, int x2, int y2);

	//rounds float to integer
	int	round_fi(float f);

	//saves current frontbuffer in a bitmap file
	//argument is char array which gets bitmap file id applied
	bool save_bitmap(char screenshot_id[256]);

	//---- look up tables ------------------------------------------------------------------------

	//creates 16bit rgb look up table
	DWORD	*Create16bppLUT(DWORD bitMask);

	//creates black to white color change LUT
	WORD	(*cblackwhite_LUT())[3];

	//creates blue to white color change LUT
	WORD	(*cbluewhite_LUT())[3];

	//creates green to red color change LUT
	WORD	(*cgreenred_LUT())[3];

	//creates green to blue color change LUT
	WORD	(*cgreenblue_LUT())[3];

	//creates yellow to pink color change LUT
	WORD	(*cyellowpink_LUT())[3];

	//creates bitmap font LUT
	RECT	*cfontbm_LUT();
	
	//creates scanline font LUT
	RECT	(*cfontsl_LUT())[6];

	//---- draw routines -------------------------------------------------------------------------

	//blits (and clips) rectangle from one surface to another
	bool blitrect(RECT rSCREEN,								//boundary coordinates of destination surface
				  RECT &csource,							//coordinates of source rectangle
				  RECT &cdest,								//coordinates of destination rectangle
				  int surface_source = 2,					//source surface
				  int surface_destination = 1);				//destination surface
															//0 = primary surface
															//1 = backbuffer
															//2 = offscreen surface

	//fills a specified part of the screen with a specified color
	//RECT is exclusive
	void colorfill(RECT r, RGBcolor c);

	//overloaded colorfill, fills entire surface by default
	void colorfill(RGBcolor c);

	//overloaded colorfill, fills entire surface witch enumerated basic colors
	//(black by default)
	void colorfill(color ec = black);

	//draws background consisting of two black borders and white (default) or
	//user defined background
	void drawbackground(int r = 255, int g = 255, int b = 255,		//color of middle part
						int u = 1, int m = 1, int l = 1);			//to draw upper, middle, lower part (0 = no, 1 = yes (default))

	//draws winning points for both players underneath their names
	//offsets is x-coordinates of beginning of name
	//old version
	void drawwinpoints_(int *pwl_p1, int offx1, int *pwl_p2, int offx2, int bwmode, int rounds);

	//draws winning points either between two player names y-centered or beneath round timer
	//if round time on
	void drawwinpoints(int rounds,							//number of rounds
					   int bwmode,							//black and white mode
					   int clock,							//clock
					   int *winpoints,						//array with win data
					   RGBcolor cp1,						//fistcolor p1 and p2
					   RGBcolor cp2);

	//draws single point, default color is black
	bool drawpoint(point p, RGBcolor c, int ml = 0);
	bool drawpoint_16(point p, RGBcolor c, int ml = 0);
	bool drawpoint_32(point p, RGBcolor c, int ml = 0);

	//draws single line
	bool drawline(line l, RGBcolor c);
	bool drawline_16(line l, RGBcolor c);
	bool drawline_32(line l, RGBcolor c);
	//drawline, manual lock
	bool drawline_ML(line l, RGBcolor c);
	bool drawline_16_ML(line l, RGBcolor c);
	bool drawline_32_ML(line l, RGBcolor c);

	//draws single circle
	bool drawcircle(int cx,										//center coordinates
					int cy,
					int radius,									//radius
					RGBcolor c,									//color, default black
					int ml = 1);								//manual lock
	bool drawcircle_16(int cx, int cy, int radius, RGBcolor c ,int ml = 1);
	bool drawcircle_32(int cx, int cy, int radius, RGBcolor c, int ml = 1);

	//draws array of circles
	bool drawcircle_array(circle c[], int elements, RGBcolor bc);
	bool drawcircle_array_16(circle c[], int elements, RGBcolor bc);
	bool drawcircle_array_32(circle c[], int elements, RGBcolor bc);

	//draws single unfilled rectangle
	//manual lock default off
	bool drawrectangle_uf(rectangle r, RGBcolor bc, int ml = 0);
	bool drawrectangle_uf_16(rectangle r, RGBcolor bc, int ml = 0);
	bool drawrectangle_uf_32(rectangle r, RGBcolor bc, int ml = 0);

	//draws several unfilled rectangles
	bool drawrectangle_array(rectangle r[], int elements, RGBcolor bc);
	bool drawrectangle_array_16(rectangle r[], int elements, RGBcolor bc);
	bool drawrectangle_array_32(rectangle r[], int elements, RGBcolor bc);

	//draws a single filled rectangle without border
	bool drawrectangle_f(rectangle r, RGBcolor fc, int ml = 0);
	bool drawrectangle_f_16(rectangle r, RGBcolor fc, int ml = 0);
	bool drawrectangle_f_32(rectangle r, RGBcolor fc, int ml = 0);

	//draws a single filled rectangle with border
	bool drawrectangle_bf(rectangle r, RGBcolor bc, RGBcolor fc, int ml = 0);
	bool drawrectangle_bf_16(rectangle r, RGBcolor bc, RGBcolor fc, int ml = 0);
	bool drawrectangle_bf_32(rectangle r, RGBcolor bc, RGBcolor fc, int ml = 0);

	//draws two times 19 rectangles either with or without shadows
	//including hardcoded head/fist bitmap
	bool drawplayers(player_data *pd,					//pointer to player_data
					 int shadows,						//shadows on/off
					 int bwmode,						//black and white mode on/off
					 float s_zoom);						//zoom factor set by user
	bool drawplayers_16(player_data *pd, int shadows, int bwmode, float s_zoom);
	bool drawplayers_32(player_data *pd, int shadows, int bwmode, float s_zoom);

	//draws complete scene in one backbuffer lock
	//including player names, winning points, figures and particles
	bool drawscene(player_data *pd,						//pointer to player_data
				   int mode_lutf,						//lut to use for fatigue
				   int mode_lutd,						//lut to use for damage
														//0 = blackwhite
														//1 = whiteblack
														//2 = bluewhite
														//3 = whiteblue
														//4 = greenred
														//5 = redgreen
														//6 = greenblue
														//7 = bluegreen
														//8 = yellowpink
														//9 = pinkyellow
					RGBcolor boneborder,				//bone border color
					int bias_r,							//color bias for all colors used
					int bias_g,							//(except for names and win points)
					int bias_b);						//drawing the scene (for pause mode)
	bool drawscene_16(player_data *pd,
					  int mode_lutf,
					  int mode_lutd,
					  RGBcolor boneborder,
					  int bias_r,
					  int bias_g,
					  int bias_b);
	bool drawscene_32(player_data *pd,
					  int mode_lutf,
					  int mode_lutd,
					  RGBcolor boneborder,
					  int bias_r,
					  int bias_g,
					  int bias_b);

	//draws fist with appropriate color for options menu
	bool drawfist(int x, int y, RGBcolor fc, int ml = 0);
	bool drawfist_16(int x, int y, RGBcolor fc, int ml = 0);
	bool drawfist_32(int x, int y, RGBcolor fc, int ml = 0);

	//draws a yin yang symbol (yy as reference)
	//yin = dark, yang = light
	//void drawyinyang(yinyang yy, RGBcolor cyin, RGBcolor cyang, int ml = 0);
	void drawyinyang(yinyang &yy, int ml = 0);

	//draws particles
	bool drawparticles(particle *pa,			//pointer to particles
					   int size,				//size of particle heap
					   int shadows,				//on/off
					   int c_scheme,			//color scheme
					   int r_no = 0);			//optional random number for further colors
	//color scheme
	//00 = white to black
	//01 = white to blue
	//02 = white to red
	//03 = green
	//04 = white to pink
	//05 = gray
	//06 = purple
	//07-13 color to white fades
	//14 = black to white
	//15 = green to red/pure red
	//16 = red to green/pure green
	//17 = green to blue/pure light blue
	//18 = blue to green
	//19 = yellow to pink
	//20 = pink to yellow/pure yellow
	//21-27 color to black fades
	//
	//100 = red only (blood)
	bool drawparticles_16(particle *pa, int size, int shadows, int c_scheme, int r_no = 0);
	bool drawparticles_32(particle *pa, int size, int shadows, int c_scheme, int r_no = 0);

	//draw console
	void draw_console(console *pc);

	//draw hud text
	void draw_hud_text(hud_text *ph);

	//draws options menu
	void draw_options_menu(data_options *pdo, int typemode);	//0 = bmf, 1 = slf

	//locks backbuffer surface
	bool BBLock();

	//unlocks backbuffer surface
	bool BBUnlock();

	//displays access to vram
	void VRAM_show();

	//displays current frames per second
	void FPS_show();

	//---- effect routines -----------------------------------------------------------------------

	//changes gamma settings (linear)
	void gamma_set(float factor_r = 1.0f,		//percentage of color intensity, 1.0 standard
				   float factor_g = 1.0f,
				   float factor_b = 1.0f);

	//fades gamma in/out (linear)
	void gamma_fade(int mode_io	= 0,			//fade mode, 0 = away from standard, 1 = to standard
					int mode_bw	= 0,			//fade mode color, 0 = from/to black, 1 = from/to white
					float time = 1.0f,			//time of fade in seconds
					bool idle = false);			//if true no gamma fade, just idling for time

	//sets data for realtime gamma fade
	void gamma_fade_ini(int mode_fade,			//0 = fade in one loop, 1 = fade simultaneous to program
						int mode_io,			//0 = away from standard, 1 = to standard, 2 = away from and back to standard
						RGBcolor color,			//color of change
						float time);			//time of change in seconds

	//realtime gamma fade
	void gamma_fade_rt();

	//creates array of particles forming a string of letters
	particle *font_pfx(char string[101], int &size, int x, int y);
	particle *font_pfx_16(char string[101], int &size, int x, int y);
	particle *font_pfx_32(char string[101], int &size, int x, int y);

	//draws bitmap or scanline font
	bool typefont(int x,							//x-coordinate
				  int y,							//y-coordinate
				  char string[101] = "",			//string to display
				  double number = 0,				//or number to display
				  int precision = 5,				//after decimal point
				  int type = 0,						//0 = bitmap, 1 = scanline
				  float sizefactor = 1.0f,			//size
				  int bred = 0, int bgreen = 0, int bblue = 0,		//border color (black)
																	//bred: for bitmap font #defined bitmap font color
																	//bred: if -1 and scanline font:
																	//unfilled scanline, use fcolor for border color
				  int fred = 0, int fgreen = 255, int fblue = 0);	//fill color (green)
	bool typefont_16(int x, int y, char string[101] = "",
					 double number = 0, int precision = 5,
					 int type = 0, float sizefactor = 1.0f,
					 int bred = 0, int bgreen = 0, int bblue = 0,
					 int fred = 0, int fgreen = 255, int fblue = 0);
	bool typefont_32(int x, int y, char string[101] = "",
					 double number = 0, int precision = 5,
					 int type = 0, float sizefactor = 1.0f,
					 int bred = 0, int bgreen = 0, int bblue = 0,
					 int fred = 0, int fgreen = 255, int fblue = 0);

	//scanline typefont function with "format, ..."
	bool typeSLF(int x, int y,
				 int bred, int bgreen, int bblue,
				 int fred, int fgreen, int fblue,
				 float sizefactor,
				 char *format, ...);
	bool typeSLF_16(int x, int y,
					int bred, int bgreen, int bblue,
					int fred, int fgreen, int fblue,
					float sizefactor,
					char *format);
	bool typeSLF_32(int x, int y,
					int bred, int bgreen, int bblue,
					int fred, int fgreen, int fblue,
					float sizefactor,
					char *format);
	//scanline typefont with manual lock/unlock of surface
	bool typeSLF_ML(int x, int y,
					int bred, int bgreen, int bblue,
					int fred, int fgreen, int fblue,
					float sizefactor,
					char *format, ...);
	bool typeSLF_16_ML(int x, int y,
					   int bred, int bgreen, int bblue,
					   int fred, int fgreen, int fblue,
					   float sizefactor,
					   char *format);
	bool typeSLF_32_ML(int x, int y,
					   int bred, int bgreen, int bblue,
					   int fred, int fgreen, int fblue,
					   float sizefactor,
					   char *format);

	//draws bitmap font (unscaled)
	bool typebmf(int x, int y,						//coordinates
				 int color,							//defined bitmap font color
				 char *format, ...);				//format

	//overloaded bitmap font draw funktion (unscaled)
	//draws additional background rectangle underneath font
	bool typebmf(int x, int y,
				 int color,
				 RGBcolor background,
				 char *format, ...);

	//overloaded bitmap font draw funktion (scaled)
	bool typebmf(int x, int y, int color, float sizefactor, char *format, ...);
	//overloaded bitmap font draw funktion (scaled) plus background
	bool typebmf(int x, int y, int color, RGBcolor background, float sizefactor, char *format, ...);

	//filters scene
	bool pixelfilter(RECT area,											//area of effect
					 int effect = 1,									//0 = negativ, 1 = color bias
					 WORD bred = 0, WORD bgreen = 0, WORD bblue = 0);	//color bias values
	bool pixelfilter_16(RECT area, int effect = 1, WORD bred = 0, WORD bgreen = 0, WORD bblue = 0);
	bool pixelfilter_32(RECT area, int effect = 1, WORD bred = 0, WORD bgreen = 0, WORD bblue = 0);

	//moves 16:9 borders smoothly in/out of screen
	void bordermove(int mode_io = 0,				//0 = borders move out, 1 = in
					int mode_s = 0,					//0 = borders from above, 1 = from sides
					int mode_t = 0,					//0 = small borders only,
													//1 = full screen borders from/to empty screen
													//2 = full screen borders from/to small borders
													//only valid if mode_s = 0
					float time = 1.0f,				//time of fade in in seconds
					int bgr = 255, int bgg = 255, int bgb = 255,	//background color, default white
					int type = 0);					//0 = no names and winning points
													//1 = with names and winning points

	//---- console -------------------------------------------------------------------------------

	//registers console variable
	void RegisterConVars(console *pcon);

	//dumps message in console
	void con_add_message(char *format, ...);

	//clear console message string
	void con_clear();

	//---- hud text ------------------------------------------------------------------------------

	//writes message on hud
	void hud_add_message(int _hud_id, int color, char *format, ...);
	void hud_add_message(char *format, ...);

//!! ??
bool drawtest(int type);
};

#endif										//end DIRECTDRAW_H
