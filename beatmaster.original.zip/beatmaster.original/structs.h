//------------------------------------------------------------------------------------------------
//
//	struct definitions
//
//	contains definitions of several structs
//
//------------------------------------------------------------------------------------------------

#ifndef DIRECTINPUT_VERSION
#define DIRECTINPUT_VERSION		0x0700		//used di version
#endif

#ifndef _WIN32_WINNT
#define _WIN32_WINNT			0x0501		//identify as windows xp application
											//necessary to access rawinput from user32.dll
#endif

#include <windows.h>						//general windows header (including raw input)

#include "memory_leak_tracker.h"			//overloaded global new operator function
#include <sys/timeb.h>						//time functions
#include <stdarg.h>							//for function with indefinite number of arguments
#include <stdio.h>							//file handling
#include <math.h>							//cos, sin, etc.
#include <dinput.h>							//direct input header (incl. DIK definitions)
#include <direct.h>							//_mkdir to create directory
#include <time.h>							//time functions (gf_logger)

//---- defines -----------------------------------------------------------------------------------

#ifndef STRUCTS_H
#define STRUCTS_H							//begin STRUCTS_H

//global logger function
extern bool gf_logger(bool error, char *format, ...);

//---- temporary developer data -------------------------------------------------------------------

#define	MINE			true				//true for name reservation
#define	DEVELOPER_		true				//program state
#define	TEASER_			false				//delete all real input, don't save config

#define MF_STACK		true				//true = master_frame object will be static
											//false = master_frame object will be dynamic allocated

#define SYS_ERRORM_OP	1					//system error message output

#define	GL_DATA_LOAD	0					//if to load gl_data from animation file instead
											//assigning the hardcoded data

#define SHOWVRAM		true				//to show access to video ram through locking the surface

#define PAL				0					//PAL-version, turns blood green, hehehe!
#define LOCALE_GER		"DEU"				//german system

//-------------------------------------------------------------------------------------------------

#define VERSION			0.100f						//version of program
#define VERSION_S		"0.100"
#define DATE			"2009.10.17"				//date of current program version
//#define DATE			__DATE__
#define LABEL			"Killing Me Software"		//display name
#define	APPTITLE		"Beatmaster"				//application name

#define WIDTH			800							//screen width, height
#define HEIGHT			600
#define BPP16			16
#define BPP32			32
#define BORDERCOLOR		black				//16:9 border color
//#define BORDERCOLOR		184, 234, 255				//16:9 border color
#define MBLUR_LIMIT		true				//motion blur limit only allows non % 3 settings
											//with triple buffering the screen won't be redrawn at all
											//with a setting if mblur % 3

#define	PI			3.141592654f			//pi constant
#define SR2			1.414213562f			//square root of 2
//modulo:
//a % b = a - (int)(a / b) * b
//#define MOD(a, b)		a - (int)(a / b) * b

//file names
#define FCONFIG		"beatmaster.cfg"		//configuration file (root)
#define FLOG		"log/log.txt"			//log file (root)
#define FERROR		"log/error.txt"			//error file (root)
#define	FMEMORY		"log/memory_log.txt"	//lists unfreed memory

//input type (directinput or rawinput)
#define IP_DI				0
#define IP_RAW				1
#define INPUTTYPE			IP_RAW
//raw input data
#define	RI_INCL_SYSMOUSE	false							//to include system mouse or not
#define	RDP_MOUSE_STRING	"\\??\\Root#RDP_MOU#0000#"		//system mouse device name string
#define RIDmax				32								//maximum number of raw input devices
															//also maxium number for RI mice

#define P1			0						//for player input commands
#define P2			1
#define PUNCH		0
#define KICK		1
#define DEFEND		2
#define LEFT		3
#define RIGHT		4
#define SPECIAL		5
#define STANCEUP	6
#define STANCEDOWN	7

//bot data
#define	B1			0						//bot id
#define B2			1
//name color
#define PLAYERNAMEBORDER		black
#define PLAYERNAMEFILL			white
#define PLAYERNAMEBORDERBW		black
#define PLAYERNAMEFILLBW		white
#define BOTNAMEBORDER			black
#define BOTNAMEFILL				red
#define BOTNAMEBORDERBW			white
#define BOTNAMEFILLBW			black

//event allocation quantity
//number of events to allocate each time (so they don't get allocated all one by one)
#define BAQ_EAQ					250

//input devices
#define DCD_MOUSE1				0
#define DCD_MOUSE2				1
#define DCD_CONTROLLER1_DIG		2
#define DCD_CONTROLLER2_DIG		3
#define DCD_CONTROLLER1_ANA		4
#define DCD_CONTROLLER2_ANA		5

//option data defines
//number of option slots
#define OS_X				4
#define OS_Y				20

//option type
#define OT_DEF				0
#define OT_ONOFF			1
#define	OT_INTOFF			2
#define OT_INT				3
#define OT_FLOAT			4
#define OT_STRING			5
#define OT_RGB				6
#define OT_INPUT			7
#define OT_MOUSE			8
#define OT_SYS				9

//option data type
#define ODT_DEF				0
#define ODT_INT				1
#define ODT_FLOAT			2
#define ODT_RGB				3
#define ODT_BOOL			4
#define ODT_CHAR			5

//option data incrementation type
//#define OIT_DEF				0
//#define OIT_SINGLE			1
//#define OIT_FIVE			2
//#define OIT_TEN				3
//#define OIT_PSINGLE			4
//#define OIT_PFIVE			5
//#define OIT_PTEN			6
#define OIT_DEF				1
#define OIT_SINGLE			1
#define OIT_FIVE			5
#define OIT_TEN				10
#define OIT_PSINGLE			0.1
#define OIT_PFIVE			0.5
#define OIT_PTEN			1.0

//color schemes
#define	OCS_DEF				0				//default color
#define OCS_BGN				1				//background
#define OCS_FIST			2				//fistcolor

//bounding box offsets, qualifier and data
#define BBOQ_BMF_X			-5
#define BBOQ_BMF_Y			0
#define BBOQ_SLF_X			-5
#define BBOQ_SLF_Y			0

#define BBOD_BMF_X			-5
#define BBOD_BMF_Y			0
#define BBOD_SLF_X			-5
#define BBOD_SLF_Y			0

//selection within option slot
#define SEL_NONE			0			//0000
#define SEL_QUAL			8			//1000
#define SEL_DAT1			4			//0100
#define SEL_DAT2			2			//0010
#define SEL_DAT3			1			//0001
#define SEL_DATA			7			//0111
#define SEL_ALL				15			//1111
#define SEL_PRE				16			//10000

//sub selections in data_options
#define SUBSEL_NONE			0
#define SUBSEL_DEF			2
#define SUBSEL_CRED			4
#define SUBSEL_EXIT			8
#define SUBSEL_INPUT		16
#define SUBSEL_NAME			32

//not available
#define NOTAVAILABLE		"N/A"
//command functions (0 - 255)
#define	cP1PUNCH			0
#define cP1KICK				1
#define cP1DEFEND			2
#define cP1LEFT				3
#define cP1RIGHT			4
#define cP1SPECIAL			5
#define	cP2PUNCH			6
#define cP2KICK				7
#define cP2DEFEND			8
#define cP2LEFT				9
#define cP2RIGHT			10
#define cP2SPECIAL			11

#define cP1STANCEUP			12
#define cP1STANCEDOWN		13
#define cP2STANCEUP			14
#define cP2STANCEDOWN		15

#define	cPAUSE				20
#define cEXIT				21
#define	cCONSOLE			22
#define	cSCREENSHOT			23
#define cSCREENMODE			24
#define	cVSYNC				25
#define cSHADOWS			30
#define cBLURUP				31
#define cBLURDOWN			32
#define cSPEEDUP			33
#define cSPEEDDOWN			34
#define cSOUND				35
#define cBWMODE				36
#define cDAMUP				40
#define cDAMDOWN			41
#define cFATUP				42
#define cFATDOWN			43
#define cTOGGLEBOT1			50
#define cTOGGLEBOT2			51

#define SLEFT				0						//stance, side
#define SRIGHT				1

#define OFF					0						//for general use
#define ON					1

#define	SYS_UP				DIK_UP					//system keys (menu)
#define SYS_DOWN			DIK_DOWN
#define SYS_LEFT			DIK_LEFT
#define SYS_RIGHT			DIK_RIGHT
#define SYS_RETURN			DIK_RETURN
#define SYS_ESC				DIK_ESCAPE
#define SYS_BACK			DIK_BACK
#define SYS_SPACE			DIK_SPACE

//bones
#define btll				0
#define btlr				1
#define btul				2
#define btur				3
#define bn					4
#define bsl					5
#define baul				6
#define ball				7
#define bsr					8
#define baur				9
#define balr				10
#define bhl					11
#define blul				12
#define blll				13
#define bfl					14
#define bhr					15
#define blur				16
#define bllr				17
#define bfr					18

#define bhead				19
#define bfistl				20
#define bfistr				21

//index hara.x/y for easier use
#define IHX					19
#define IHY					20

#define DKFI				0				//default animation keyframe index

#define	NODS				11				//number of damage slots

#define	DS_tll				0				//damage slots
#define DS_tlr				1
#define	DS_tul				2
#define	DS_tur				3
#define	DS_hn				4
#define	DS_al				5
#define	DS_ar				6
#define	DS_hll				7
#define	DS_fll				8
#define	DS_hlr				9
#define	DS_flr				10

//collision detection states
#define	cds_nohit			0				//not hitable
#define cds_hit				1				//hitable
#define	cds_def				2				//hitable, no/reduced damage
#define	cds_hitret			3				//hitable, but if state of bone to be attacked is
											//cds_def damage to be caused gets returned
#define cds_defpart			4				//cd will be done but continues afterwards
											//bones with cds_defpart will weaken attacks
#define cds_defpart_b		5				//only bone without extension
#define cds_defpart_e		6				//only extension without bone
											//(if _b and _e the parent bone is cds_hit by default)

//collision detection state colors
#define cdsc_nohit			white
#define cdsc_hit			red
#define cdsc_def			green
#define cdsc_hitret			yellow
#define cdsc_defpart		blue

//hit states for bones
#define	hs_nohit			0				//not hit
#define hs_hit				1				//standard hit
#define hs_hitred			2				//hit with reduced damage (through guard)
#define	hs_hitdef			3				//bone in defense state hit
#define	hs_hitret			4				//bone in hit return state hit
#define hs_stanceflash		99				//indicating change of stance_arms and which bone
											//is protecting
//colors for hit states
#define	hsc_hit				white
#define	hsc_hitred			lightblue
#define	hsc_hitdef			blue			//200, 100, 255
#define hsc_hitret			black
#define hsc_stanceflash		white
//for blackwhite mode
#define	hscbw_hit			red
//#define	hscbw_hitred		yellow
#define	hscbw_hitred		orange
#define	hscbw_hitdef		green
#define hscbw_hitret		blue
#define hscbw_stanceflash	red

//lock states for bones
#define	ls_nolock			0
#define ls_off				1
#define	ls_def				2
#define	ls_offdef			3
//colors for hit states
#define lsc_nolock			black
#define lsc_off				red
#define lsc_def				blue
#define lsc_offdef			pink
//colors for hit states in bw mode
#define lscbw_nolock		black
#define lscbw_off			red
#define lscbw_def			blue
#define lscbw_offdef		pink

//action types
#define	act_none			0
#define act_fistl			1
#define act_fistr			2
#define act_footl			3
#define act_footr			4
#define act_kneel			5
#define act_kneer			6
#define	act_def				7

//defense mode
#define DM_mTmE				0				//manual tapping, manual evading
#define DM_aTmE				1				//auto tapping, manual evading
#define DM_mTaE				2				//manual tapping, auto evading
#define DM_aTaE				3				//auto tapping, auto evading

#define DEFENSIVE			0
#define OFFENSIVE			1

//ko modes
#define KOM_HEAD					0				//head only
#define	KOM_HEAD_OR_UP				1				//head or upper torso
#define	KOM_HEAD_AND_UP				2				//head and upper torso
#define	KOM_HEAD_OR_LO				3				//head or lower torso
#define	KOM_HEAD_AND_LO				4				//head and lower torso
#define	KOM_HEAD_OR_UP_OR_LO		5				//head or both upper or lower torso
#define	KOM_HEAD_AND_UP_AND_LO		6				//head and both upper and lower torso
#define	KOM_HEAD_AND_UP_OR_LO		7				//head and upper or lower torso
#define	KOM_HEAD_OR_UP_AND_LO		8				//head or upper and lower torso
#define	KOM_UP						9				//upper torso
#define KOM_LO						10				//lower torso
#define	KOM_UP_OR_LO				11				//both upper or lower torso
#define	KOM_UP_AND_LO				12				//both upper and lower torso
#define KOM_HPRIMARY				13				//first hit on head or torso
#define KOM_HGENERAL				14				//first hit in general (also defense damage)

//fight modes
#define FM_DEF						0				//default
#define FM_BOX						1				//boxing only
#define FM_KICK						2				//kicking only

#define S_FLOOR				390				//y-coordinate of floor
#define S_LBOUND			50				//left and right screen boundaries
#define S_RBOUND			750
#define	S_PYDEF				300				//default y-value of player hara

#define CAV					1				//current animation/keyframe version

//directinput.h
#define	NPAN				38				//number of player animations

//animation slots
#define aslot_cycle			0
#define aslot_action		1
#define aslot_hit			2

//action states
//0 = inactive
//1 = active/pre phase
//2 = active/final phase
//3 = active/cancel phase
#define AS_INACTIVE			0
#define	AS_ACTIVE			1				//used for non phased actions
#define AS_PRE				1
#define AS_FINAL			2
#define AS_CANCEL			3
#define AS_DONE				4
#define AS_CONTEXT			5				//same as final but for context activated actions

#define AN_DEFAULT			0				//contains default keyframe
#define AN_HIT				1				//basicly same as default keyframe, used for special cases
#define AN_IDLE_HI			2
#define AN_IDLE_LO			3
#define AN_IDLE_SETS		4				//different sets for idle animation
#define AN_STANCE_ARMS		5
#define AN_STANCE_FEET		6
#define	AN_CHANGE_SIDE		7
#define	AN_WALK_FWD			8
#define	AN_WALK_BWD			9
#define	AN_WALK_SLIDE_FWD	10
#define	AN_WALK_SLIDE_BWD	11

#define AN_JAB				12
#define AN_JAB_HOOK			13
#define AN_CROSS			14
#define AN_CROSS_HOOK		15
#define AN_KICK_FWD			16
#define AN_KICK_KNEE		17
#define AN_KICK_SWD			18
#define AN_KICK_SWD_HI		19

#define AN_DEFEND			20				//defence button pressed
#define AN_EVADE_HI			21				//move upper torso
#define AN_EVADE_LO			22				//move lower torso/hip/leg
#define AN_DUCK				23
#define AN_EVADE_HI_HOLD	24				//evade hold states
#define AN_EVADE_LO_HOLD	25
#define AN_DUCK_HOLD		26

#define AN_TAP_ARMS			27
#define AN_TAP_ARMS_SET		28
#define AN_TAP_LEG			29				//rise knee to defend
#define	AN_GUARD_ARMS		30
#define AN_GUARD_LEGS		31
#define AN_GUARD_FULL		32
#define AN_PUSH_ARMS		33
#define AN_PULL_ARMS		34

#define AN_TAUNT1			35
#define AN_TAUNT2			36

#define AN_KNOCKOUT			37

//number of credits
#define NOC					20
#define CR_SPEED			-40				//default scrolling speed
#define CR_SPEEDMAX			6000			//min and max scrolling speed
#define CR_BMFCOLOR			bmfblack		//default credit text color

//number of maximum blood particles per heap
#define	NOBLOOD				50

#define	T_BONEFLASH			0.5f			//bone flash time
#define	T_PMESSAGE			1.0f			//player message in seconds

//animation adjustment
#define AADJ_SETTARGET		1				//sets current bone position as its current target (softer)
#define AADJ_ADVKF			2				//advances keyframe (harder)

#define AADJ_LOCKSPEED		1.5f			//speedfactor for offense locked attacks
#define OFF_LOCK_DAMAGE		0.5f			//damage malus for offense locked limbs
#define OFF_LOCK_SLOWDOWN	1				//0 offense locked limbs are locked
											//1 offense locked limbs only get slowed down
#define SF_DOUBLE_TAP		1.7f			//animation speedfactor for auto double tap in case
											//of successful tap

//player messages
#define	NPMESSAGES			5				//number of simultaneous player messages
//player message types
#define PM_DEFAULT			0
#define PM_STDDAMAGE		1
#define PM_POWERATTACK		2
#define PM_COMBO			3
#define	PM_FATDAMAGE		4
#define PM_PUSHPULL			5
#define PM_KO				6
#define PM_GODLIKE			7
#define PM_TAUNT			8
//scroll types
#define ST_STATIC			1				//no scrolling, stays where it started
#define ST_DYNAMIC			2				//no scrolling, stays above player
#define ST_DYNSTAT			3				//starts dynamic, becomes static after specified amount of time
#define ST_STATICUP			4				//scrolls up where it started
#define ST_DYNAMICUP		5				//scrolls up above player
#define ST_DYNSTATUP		6				//scrolls up dynamic, becomes static after specified amount of time
#define ST_DYNSTATUP_EX		7				//starts dynamic above player, then starts dyn scrolling up and then becomes static

//---- player skills -----------------------------------------------------------------------------

#define SKILL_FREG			16				//fatigue regeneration in units per second
#define SKILL_FAPP			100				//fatigue apply speed in units per second
#define SKILL_WALK_FWD		170				//walk speed in units per second
#define SKILL_WALK_BWD		170
//#define	SKILL_WALK_ACC		0.120f		//time till full speed
#define	SKILL_WALK_ACC		0.1f			//time till full speed
#define WALK_BWD_BONUS		40				//walkspeed bonus if walking bwd while defending
#define WALK_FWD_BONUS		60				//walkspeed bonus if walking fwd while attacking
#define SKILL_AAD_DISTANCE	160.0f			//minimum distance to opponent for air attack
											//to drag player forward
#define SKILL_ADD_FAT		50.0f			//minimum fatigue for air attack drag
#define FAT_GUARD_ARMS		10.0f			//fatigue for guard arms in units per second
#define FAT_GUARD_LEGS		10.0f
//#define FAT_GUARD_FULL		20.0f
#define FAT_GUARD_FULL		14.0f
#define	FAT_EVADE_HOLD		16.0f			//fatigue for evade hold in units per second
#define T_EVADE_HOLD		1.5f			//maximum evade hold time in seconds
#define LLOCK_FAT			8.0f			//fatigue to add if limb locked and tried to attack with
											//(adjusted to fom_multiplier)
#define T_WALK_STUN			1.2f			//walk stun time

//bitmap font colors
#define	bmfwhite			0
#define	bmfblack			1
#define	bmfred				2
#define	bmfgreen			3
#define	bmfblue				4
#define	bmfyellow			5
#define bmflightblue		6
#define bmforange			7
#define bmflightgreen		8
//maximum color index
#define	bmfMAX				8

//---- macros -------------------------------------------------------------------------------------

//random number between max and min (including)
#define RANDOM(max, min)	min + (rand() % (max - min + 1))

//modulo
#define MOD(a, b)		a - (int)(a / b) * b

//---- enumerations ------------------------------------------------------------------------------

//for convenience
enum color {black, red, orange, green, blue, yellow, lightblue, darkgreen, pink, lightgray, darkgray, white = 255, negative};

//---- hud text ----------------------------------------------------------------------------------

#define HUD_TEXT_MAX_ENTRY_LENGTH			1024	//max length of one entry
#define HUD_TEXT_MAX_ENTRIES				6		//max number of entries
#define	HUD_NOH								2		//number of hud objects

//---- console macros ----------------------------------------------------------------------------

//console data
#define CON_LINEMAX				256			//maximum characters per line
#define	CON_OBSTRING			1024		//maximum outputbuffer string
#define CON_MAXARGS				32			//maximum arguments per line
#define CON_COMBUFFER			10			//command history buffer
#define	CON_BREAK				'>'			//line break character

#define CONFUNCF_RESTRICTED		0x00000001		//function not accessible during restricted execute
#define CONVARF_RESTRICTED		0x00000001		//var is not accessible during restricted execute

//declare all classes console functions have access to
class master_frame;
class directdraw;
class directinput;
class directsound;
class player;
class bot;
//for player message
struct timer;
struct options;

//declare console function and console variable class
class con_func_t;
class con_var_t;

//declare console class
struct console;

//console function
//#define CON_FUNC(name, flags) \
//		void name##_confunc_body(con_var_t *argvar, int argc, char **argv); \
//		con_func_t name##_confunc(#name, name##_confunc_body, flags, false); \
//		void name##_confunc_body(con_var_t *argvar, int argc, char **argv)

#define CLASS_CON_FUNC(name) \
		static void name##_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv); \
		con_func_t name##_confunc

#define CLASS_CFI(name, flags) \
		name##_confunc.init(pcon, #name, name##_confunc_body, flags, false)

//console variable handler
//#define CON_VARHANDLER(type) \
//		void handler_##type##_confunc_body(con_var_t *argvar, int argc, char **argv); \
//		con_func_t handler_##type##_confunc(#type, handler_##type##_confunc_body, 0, true); \
//		void handler_##type##_confunc_body(con_var_t *argvar, int argc, char **argv)

#define CLASS_CON_VARHANDLER(type) \
		static void handler_##type##_confunc_body(console *pcon, con_var_t *argvar, int argc, char **argv); \
		con_func_t handler_##type##_confunc

//console function object handler initialization
#define CLASS_CHI(type) \
		handler_##type##_confunc.init(pcon, #type, handler_##type##_confunc_body, 0, true)

//console variable
//#define CON_VAR(type, name, ivalue, flags) \
//		type name = ivalue; \
//		con_var_t name##_convar(#name, &##name, #type, flags)

//console variable for classes
//need to be initialized separately
#define CLASS_CON_VAR(type, name) \
		type name; \
		type name##Min; \
		type name##Max; \
		con_var_t name##_convar

//console variable array for classes
#define CLASS_CON_VAR_A(type, name, elements) \
		type name[elements]; \
		type name##Min; \
		type name##Max; \
		con_var_t name##_convar

//console variable initialization (usually in constructor)
#define CLASS_CVI(type, name, ivalue, imin, imax, flags) \
		name			= ivalue; \
		name##Min		= imin; \
		name##Max		= imax; \
		name##_convar.init(pcon, #name, 0, &##name, &##name##Min, &##name##Max, #type, flags)

//without ini valus
#define CLASS_CVIMM(type, name, imin, imax, flags) \
		name##Min		= imin; \
		name##Max		= imax; \
		name##_convar.init(pcon, #name, 0, &##name, &##name##Min, &##name##Max, #type, flags)

//without ini, min, max values
#define CLASS_CVNI(type, name, flags) \
		name##_convar.init(pcon, #name, 0, &##name, &##name##Min, &##name##Max, #type, flags)

//for arrays
#define CLASS_CVIA(type, name, elements, ivalue, imin, imax, flags) \
		for (register int name##_i = 0; name##_i < elements; ++name##_i) \
			name[name##_i]	= ivalue; \
		name##Min		= imin; \
		name##Max		= imax; \
		name##_convar.init(pcon, #name, elements, &##name, &##name##Min, &##name##Max, #type, flags)

//without ini
#define CLASS_CVIAMM(type, name, elements, imin, imax, flags) \
		name##Min		= imin; \
		name##Max		= imax; \
		name##_convar.init(pcon, #name, elements, &##name, &##name##Min, &##name##Max, #type, flags)

//typedef pointer to functions which return void and have arguments:
//(pointer to console object, pointer to con_var_t object, int, char**)
//typedef void (*con_func_bodyFunc_t)(con_var_t*, int, char**);
typedef void (*con_func_bodyFunc_t)(console*, con_var_t*, int, char**);

//---- structs -----------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//
//	con_func_t
//
//	created for every console function
//	contains pointer to previous created con_func_t object
//	contains pointer to console function
//	(within console class)
//
//------------------------------------------------------------------------------------------------

class con_func_t
{
public:

	const char				*name;					//name of console function
	con_func_bodyFunc_t		func;					//pointer to console function within master_frame
													//(typedef)
													//function body to call

	unsigned long			flags;					//CONFUNCF_ flags

	con_func_t				*next;					//next console function in list
													//(previously created)

	//---- constructor ---------------------------------------------------------------------------

	con_func_t();

	//---- destructor ----------------------------------------------------------------------------

	~con_func_t()
	{
	};

	//---- init ----------------------------------------------------------------------------------

	void init(console *pcon,
			  const char *inName,
			  con_func_bodyFunc_t inFunc,
			  unsigned long inFlags,
			  unsigned char isVarHandler);
};

//------------------------------------------------------------------------------------------------
//
//	con_var_t
//
//	created for every console variable
//	contains pointer to previous created con_var_t object
//	contains pointer to console variable
//
//------------------------------------------------------------------------------------------------

class con_var_t
{
public:

	const char				*name;					//name of console variable
	const char				*varTypeName;			//name of variable type
	void					*valuePtr;				//pointer to actual data
	void					*valueMin;				//pointer to min and max value of actual data
	void					*valueMax;
	int						instance;				//instance of con var with same description
													//(several objects of same class with con var)
	int						elements;				//number of elements if pointing to an array of con vars

	unsigned long			flags;					//CONVARF_ flags
	con_func_t				*handler;				//pointer to con_func_t object which
													//has pointer to function which acts as var handler
	con_var_t				*next;					//next console variable in list
													//(previously created)

	//---- constructor ---------------------------------------------------------------------------

	con_var_t();

	//---- destructor ----------------------------------------------------------------------------

	~con_var_t()
	{
	};

	//---- init ----------------------------------------------------------------------------------

	void init(console *pcon,
			  const char *inName,
			  int _elements,
			  void *inValuePtr,
			  void *inValueMin,
			  void *inValueMax,
			  const char *inVarTypeName,
			  unsigned long inFlags);
};

//------------------------------------------------------------------------------------------------
//
//	program_options
//
//	global object containing program options
//
//------------------------------------------------------------------------------------------------

struct program_options
{	
	bool		logger;							//event logger on/off
	bool		log_head;						//if log file head printed
	bool		err_head;						//same for error file

	bool		HEL;							//no hardware acceleration
	bool		off_sys;						//if to create offscreen surface in system memory
												//otherwise in video memory
	bool		vb_sys;							//if to create video buffersin system memory
												//otherwise in video memory

	bool		_console;						//access to ingame console

	bool		open_file_log;					//to open log file after program exit
	bool		open_file_error;				//to open error file after program exit
	bool		open_file_mlog;					//to open memory error file after program exit

	//cheats
//	bool		fatigue[2];						//no fatigue
	CLASS_CON_VAR_A(bool, xfatigue, 2);

	//---- constructor ---------------------------------------------------------------------------

	program_options()
	{
		logger		= OFF;
		log_head	= false;
		err_head	= false;

		_console	= OFF;

		HEL			= OFF;
		off_sys		= OFF;
		vb_sys		= OFF;

		open_file_log		= false;
		open_file_error		= false;
		open_file_mlog		= false;

		xfatigue[P1]	= xfatigue[P2]	= OFF;
	};

	//---- RegisterConVars -----------------------------------------------------------------------

	void RegisterConVars(console *pcon);
};

//------------------------------------------------------------------------------------------------

//global program options object
extern program_options	gProgramOptions;

//------------------------------------------------------------------------------------------------
//
//	color triplet	12 byte
//
//------------------------------------------------------------------------------------------------

struct RGBcolor
{
	int r, g, b;

	//---- constructor ---------------------------------------------------------------------------

	//contructor with default values
	RGBcolor(int red = 0, int green = 0, int blue = 0)
	{
		//r = red; g = green; b = blue;
		setcolor(red, green, blue);
	};

	//---- setcolor ------------------------------------------------------------------------------

	//!!! nicht als referenz?

	//sets triplets to colors, return reference to itself
//	RGBcolor &setcolor(int red, int green, int blue)
	void setcolor(int red, int green, int blue)
	{
		//check for valid data
		red > 255	? r = 255	: r = red;
		red < 0		? r = 0		: r = red;
		green > 255	? g = 255	: g = green;
		green < 0	? g = 0		: g = green;
		blue > 255	? b = 255	: b = blue;
		blue < 0	? b = 0		: b = blue;

//		return(*this);
	};

	//---- converting constructor ----------------------------------------------------------------

	//converts enumerated color to RGBcolor
	RGBcolor(color ec)
	{
		//set color according to ec
		switch (ec)
		{
		case (black):
			{
				r = 0; g = 0; b = 0;
				break;
			}

		case (red):
			{
				r = 255; g = 0; b = 0;
				break;
			}

		case (orange):
			{
				r = 255; g = 155; b = 0;
				break;
			}

		case (green):
			{
				r = 0; g = 255; b = 0;
				break;
			}

		case (blue):
			{
				r = 0; g = 0; b = 255;
				break;
			}

		case (yellow):
			{
				r = 255; g = 255; b = 0;
				break;
			}

		case (lightblue):
			{
				r = 0; g = 255; b = 255;
				break;
			}

		case (darkgreen):
			{
				r = 0; g = 128; b = 0;
				break;
			}

		case (pink):
			{
				r = 255; g = 0; b = 255;
				break;
			}

		case (lightgray):
			{
				r = 192; g = 192; b = 192;
				break;
			}

		case (darkgray):
			{
				r = 128; g = 128; b = 128;
				break;
			}

		case (white):
			{
				r = 255; g = 255; b = 255;
				break;
			}
		}
	};

	//overloaded setcolor function takes enumerated color object as argument to set color
	void setcolor(color ec)
	{
		//set color according to ec
		switch (ec)
		{
		case (black):
			{
				r = 0; g = 0; b = 0;
				break;
			}

		case (red):
			{
				r = 255; g = 0; b = 0;
				break;
			}

		case (orange):
			{
				r = 255; g = 155; b = 0;
				break;
			}

		case (green):
			{
				r = 0; g = 255; b = 0;
				break;
			}

		case (blue):
			{
				r = 0; g = 0; b = 255;
				break;
			}

		case (yellow):
			{
				r = 255; g = 255; b = 0;
				break;
			}

		case (lightblue):
			{
				r = 0; g = 255; b = 255;
				break;
			}

		case (darkgreen):
			{
				r = 0; g = 128; b = 0;
				break;
			}

		case (pink):
			{
				r = 255; g = 0; b = 255;
				break;
			}

		case (lightgray):
			{
				r = 192; g = 192; b = 192;
				break;
			}

		case (darkgray):
			{
				r = 128; g = 128; b = 128;
				break;
			}

		case (white):
			{
				r = 255; g = 255; b = 255;
				break;
			}

		//reverse rgb elements
		case (negative):
			{
				r	= 255 - r;
				g	= 255 - g;
				b	= 255 - b;
				break;
			}
		}
	};

	//overloaded setcolor function takes itself (RGBcolor object) as argument to set color
	void setcolor(RGBcolor rgbcolor)
	{
		r = rgbcolor.r;
		g = rgbcolor.g;
		b = rgbcolor.b;
	};

	//---- overloaded comparison operator --------------------------------------------------------

	//returns true if parameter color (converted from enumerated color) is the same as
	//the color of the object for which this function is called
	bool operator== (RGBcolor c)
	{
		if (r == c.r &&
			g == c.g &&
			b == c.b)
			return true;
		else
			return false;
	};
};

//------------------------------------------------------------------------------------------------
//
//	pause settings
//
//------------------------------------------------------------------------------------------------

struct program_pause
{
	bool			pause;					//if paused or not
	float			time;					//time of pause in seconds
	LONGLONG		t_start;				//start of pause
	LONGLONG		t_freq;					//timer frequency

	//---- constructor ---------------------------------------------------------------------------

	program_pause()
	{
		pause				= false;
		time				= 0;
		t_start				= 0;

		//get frequency and store it in t_freq
		QueryPerformanceFrequency((LARGE_INTEGER*) &t_freq);
	};

	//---- pause ---------------------------------------------------------------------------------

	void set_pause(float _time)
	{
		//verify time
		if (_time <= 0)			_time = 0.1f;
		if (_time > 30.f)		_time = 30.0f;

		//set pause
		pause		= true;

		//set pause time
		time		= _time,

		//set start time
		QueryPerformanceCounter((LARGE_INTEGER*) &t_start);
	};

	//---- update --------------------------------------------------------------------------------
	//returns false if no pause, true if paused

	bool update()
	{
		//if paused
		if (pause)
		{
			//get current time
			LONGLONG t_current;
			QueryPerformanceCounter((LARGE_INTEGER*) &t_current);

			if (t_current >= t_start + (t_freq * time))
			{
				//unpause
				pause		= false;
				time		= 0;
				t_start		= 0;

				//unpaused
				return false;
			}
			else
				//still paused
				return true;
		}
		else
			//unpaused
			return false;
	};

	//---- sleep_pause ---------------------------------------------------------------------------

	void sleep_pause(LONGLONG &t_current, float _time)
	{
		//verify time
		if (_time <= 0)			_time = 0.1f;
		if (_time > 30.f)		_time = 30.0f;

		//get start time
		LONGLONG t_start;
		QueryPerformanceCounter((LARGE_INTEGER*) &t_start);

		while (t_current < t_start + (t_freq * _time))
		{
			//get current time
			QueryPerformanceCounter((LARGE_INTEGER*) &t_current);
		}
	};
};

//------------------------------------------------------------------------------------------------
//
//	gamma change settings
//
//------------------------------------------------------------------------------------------------

struct gamma_change_settings
{
	bool		active;					//whether or not change is in progress
	int			mode_fade;				//0 = fade in one loop, 1 = fade simultaneous to program
	int			mode_io;				//0 = away from standard, 1 = to standard, 2 = from standard to color and back to standard
	RGBcolor	color;					//color to flash to/from
	float		time;					//time of change in seconds
	LONGLONG	t_start;				//starting time
	LONGLONG	t_freq;					//timer frequency (set in constructor)

	//---- constructor ---------------------------------------------------------------------------

	gamma_change_settings()
	{
		active		= false;
		mode_fade	= 0;
		mode_io		= 0;
		color		= black;
		time		= 0;
		t_start		= 0;

		//get frequency and store it in t_freq
		QueryPerformanceFrequency((LARGE_INTEGER*) &t_freq);
	};
};

//------------------------------------------------------------------------------------------------
//
//	simple point	8 byte
//
//------------------------------------------------------------------------------------------------

struct ipoint;

struct point
{
	float	x, y;				//coordinates

	//---- constructor ---------------------------------------------------------------------------

	point(float px = 0, float py = 0)
	{
		x	= px;			y	= py;
	};

	//---- conversion constructor ----------------------------------------------------------------
	//converts arugmented int point into float point
	//defined in master_frame.cpp

	point(const ipoint &ip);

	//---- == operator function -------------------------------------------------------------------

	bool operator== (const point &i)
	{
		return(x == i.x && y == i.y);
	};

	bool operator== (const ipoint &i);
};

//------------------------------------------------------------------------------------------------
//
//	simple point	8 byte
//	integer precision
//
//------------------------------------------------------------------------------------------------

struct ipoint
{
	int		x, y;				//coordinates

	//---- constructor ---------------------------------------------------------------------------

	ipoint(int px = 0, int py = 0)
	{
		x	= px;			y	= py;
	};

	//---- setpoint ------------------------------------------------------------------------------

	void setpoint(int px = 0, int py = 0)
	{
		x	= px;			y	= py;
	};

	//---- conversion constructor ----------------------------------------------------------------
	//converts arugmented float point into int point

	ipoint(const point fp)
	{
		x	= (int)fp.x;
		y	= (int)fp.y;
	};

	//---- == operator function -------------------------------------------------------------------

	bool operator== (const ipoint &i)
	{
		return(x == i.x && y == i.y);
	};

	bool operator== (const point &i)
	{
		return(x == (int)i.x && y == (int)i.y);
	};
};

//------------------------------------------------------------------------------------------------
//
//	simple point	8 byte
//	integer precision
//	defined in directinput.h
//
//------------------------------------------------------------------------------------------------

/*struct ipoint
{
	int		x, y;				//coordinates

	//---- constructor ---------------------------------------------------------------------------

	ipoint(int px = 0, int py = 0)
	{
		x	= px;			y	= py;
	};
};*/

//------------------------------------------------------------------------------------------------
//
//	simple line		16 byte
//
//------------------------------------------------------------------------------------------------

struct line
{
	point	p[2];

	//---- constructor ---------------------------------------------------------------------------

	line(float x1 = 0, float y1 = 0,
		 float x2 = 0, float y2 = 0)
	{
		p[0].x = x1;		p[0].y = y1;
		p[1].x = x2;		p[1].y = y2;
	};

	//---- set_line ------------------------------------------------------------------------------

	void set_line(float x1, float y1, float x2, float y2)
	{
		p[0].x = x1;		p[0].y = y1;
		p[1].x = x2;		p[1].y = y2;
	};
};

//------------------------------------------------------------------------------------------------
//
//	simple rectangle	32 byte
//
//------------------------------------------------------------------------------------------------

struct rectangle
{
	point	p[4];

	//---- constructor ---------------------------------------------------------------------------

	rectangle(float x1 = 0, float y1 = 0,
			  float x2 = 0, float y2 = 0,
			  float x3 = 0, float y3 = 0,
			  float x4 = 0, float y4 = 0)
	{
		p[0].x = x1;		p[0].y = y1;
		p[1].x = x2;		p[1].y = y2;
		p[2].x = x3;		p[2].y = y3;
		p[3].x = x4;		p[3].y = y4;
	};

	//---- operator = ----------------------------------------------------------------------------

	//operator = converts RECT structures into rectangle structures
	//won't work with multidimensional arrays (scanline font LUT)
	rectangle& operator = (const RECT &r)
	{
		p[0].x = (float)r.left;		p[0].y = (float)r.top;
		p[1].x = (float)r.right;	p[1].y = (float)r.top;
		p[2].x = (float)r.right;	p[2].y = (float)r.bottom;
		p[3].x = (float)r.left;		p[3].y = (float)r.bottom;

		return(*this);
	};

	//---- convert constructor -------------------------------------------------------------------

	//converts RECT structures into rectangle structures
	rectangle(const RECT &r)
	{
		p[0].x = (float)r.left;		p[0].y = (float)r.top;
		p[1].x = (float)r.right;	p[1].y = (float)r.top;
		p[2].x = (float)r.right;	p[2].y = (float)r.bottom;
		p[3].x = (float)r.left;		p[3].y = (float)r.bottom;
	};

	//---- fill_rectangle ------------------------------------------------------------------------

	void fill_rectangle(float x1 = 0, float y1 = 0,
						float x2 = 0, float y2 = 0,
						float x3 = 0, float y3 = 0,
						float x4 = 0, float y4 = 0)
	{
		p[0].x = x1;		p[0].y = y1;
		p[1].x = x2;		p[1].y = y2;
		p[2].x = x3;		p[2].y = y3;
		p[3].x = x4;		p[3].y = y4;
	};
};

//------------------------------------------------------------------------------------------------
//
//	simple circle
//
//------------------------------------------------------------------------------------------------

struct circle
{
	point	c;						//center
	float	radius;					//radius

	//---- constructor ---------------------------------------------------------------------------

	circle(float x = 0, float y = 0,
		   float r = 0)
	{
		c.x			= x;
		c.y			= y;
		radius		= r;
	};

	//---- setcircle -----------------------------------------------------------------------------

	void setcircle(float x, float y, float r)
	{
		c.x			= x;
		c.y			= y;
		radius		= r;
	};
};

//------------------------------------------------------------------------------------------------
//
//	bone
//
//------------------------------------------------------------------------------------------------

struct bone
{
	int			id;										//player id

	rectangle	v;										//vertices of bone
	rectangle	vs;										//vertices of shadow of bone
														//only calculated if option.data.shadows == 1
	bone		*p_pb;									//pointer to parent bone
														//used in animator to get the angle of the parent bone
	point		*p_pbjv;								//pointer to point of rectangle of parent
														//bone which forms the joint between the two bones
	int			pbi;									//index of parent bone, -1 if none (low torso)

	float		angle;									//angle of bone
	float		angle_vd[2];							//valid angle range relative to parent bone
														//[0] to [1] in positive direction

	BYTE		f_aw;									//indicates whether angle of width is
														//angle + 90� (1) or angle - 90� (0)
	float		length, width;							//length and width of bone

	int			z;										//z-value of bone

	RECT		hitbox;									//hitbox of bone
	RECT		hitbox_e;								//hitbox for head/fists if assigned

	int			type;									//type of bone
														//0 = standard with visible damage
														//1 = standard with fist
														//2 = no visible damage (black)
														//3 = visible damage with head (neck)

	int			damage;									//damage from 0 to 100
	int			d_slot;									//damage slot of which the bone is part of

	int			cd_state;								//collision detection state of bone
														//0 = not hitable
														//1 = hitable

	int			hit_state;								//used in dd.drawscene to flash bones when hit
														//defined states
	int			hit_state_e;							//extended hit state for fists and head

	int			lock_state;								//used in dd.drawscene to show lock state
														//of bone (and extension if available)
														//#defined

	//---- constructor ---------------------------------------------------------------------------

	bone()
	{
		id				= 0;

		p_pb			= NULL;
		p_pbjv			= NULL;
		pbi				= -1;

		angle			= 0;
		angle_vd[0]		= 0;		angle_vd[1]	= 0;
		f_aw			= 0;
		length			= 0;		width		= 0;

		z				= 0;
		type			= 0;
		damage			= 0;
		d_slot			= 0;

		cd_state		= 0;
		hit_state		= 0;
		hit_state_e		= 0;

		lock_state		= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	skeleton
//
//------------------------------------------------------------------------------------------------

struct skeleton
{
	//reference bone of all movement and animation
	//changes with stance and position (player 1/2)
	//always index 0
	bone		*p_ref;

	//bone structure
	bone		b[19];

	//bone index order of first four bones to calculate
	//the bones have to be calculated in a different order
	//according to the side of which the player stands and his fighting stance
	//this array holds the indices in the correct order for the bones
	int			b_order[4];

	//center of head and both fists
	point		chead;
	point		cfistl, cfistr;

	//radius for head and fists (both fist the same)
	float		radius_head;
	float		radius_fist;

	//hitbox containing whole player
	RECT		r_hbp;

	int			damage[NODS];					//damage for damage slots
												//0 = torso lo left
												//1 = torso lo right
												//2 = torso up left
												//3 = torso up right
												//4 = neck and head
												//5 = left arm
												//6 = right arm
												//7 = left hip and left upper leg
												//8 = left lower leg and left foot
												//9 = right hip and right upper leg
												//10 = right lower leg and right foot

	//!! gesamtschaden

	//---- constructor ---------------------------------------------------------------------------

	skeleton()
	{
		//set to NULL
		p_ref			= NULL;

		ZeroMemory(&b_order, sizeof(b_order));

		radius_head		= 0;
		radius_fist		= 0;

		ZeroMemory(&damage, sizeof(damage));
	};
};

//------------------------------------------------------------------------------------------------
//
//	keyframe
//
//------------------------------------------------------------------------------------------------

 struct keyframe
{
	//on changes: constructor, copy-constructor, reset_runtime_data, load_animation (main_frame)
	//!!!
	//special flags, die vorerst leer bleiben, aber sp�ter genutzt werden k�nnen?

	//---- static data ---------------------------------------------------------------------------

	int			t_frame[21];					//time in milliseconds for the keyframe positions
												//to be reached, for each bone plus hara x/y

	point		hara;							//hara destination point
												//x relative to current position
												//y relative to default floor
	float		angle[19];						//destination angle for all bones
	float		length[19];						//destination length for all bones
	float		width[19];						//destination width for all bones

	int			mode_a[19];						//mode of angle
												//0 = absolute
												//1 = relative to parent bone
												//2 = relative to current angle
												//3 = relative to default keyframe

	int			type;							//0 = standard keyframe
												//1 = buffer keyframe
												//2 = stance_feet change
												//3 = side change

	int			action;							//0 = no action
												//1 = left fist
												//2 = right fist
												//3 = left foot
												//4 = right foot
												//5 = left knee
												//6 = right knee (not used at the moment)
												//7 = defend

	int			dir;							//0 = forward
												//1 = backward

	//---- runtime data --------------------------------------------------------------------------

	float		angle_def[19];					//default angle of keyframe to calculate adjusted
												//speed of change

//	int			pbi[19];						//index of parent bone

/*	float		*p_pbad[19];					//pointer to default angle of parent bone
	float		*p_pbaa[2][19];					//pointer to adjusted angle of parent bone*/

	//for both players
	LONGLONG	t_kfstart[2][21];				//start time of keyframe for both players, each bone and hara

	int			state[2][21];					//state of keyframe for both players for all bones and hara
												//0 = uninitialized
												//1 = initialized
												//2 = done

	int			t_frame_ad[2][21];				//adjusted keyframe time

	float		angle_ad[2][19];				//adjusted angle/length/width in reference to
												//mode_a, diff, user input
	float		length_ad[2][19];
	float		width_ad[2][19];

	point		hara_ad[2];						//same for hara
	point		hara_r[2];						//holds to covered distance of hara.x

	point		speed_h[2];						//hara speed in pixel per second

	float		speed_a[2][19];					//speed of angle change in degrees per second
	float		speed_l[2][19];					//speed of length change in pixel per second
	float		speed_w[2][19];					//speed of width change in pixel per second

	//---- constructor ---------------------------------------------------------------------------

	keyframe()
	{
		//default time 100 milliseconds
		for (register int i = 0; i < 21; ++i)
			t_frame[i]	= 100;

		hara.x		= hara.y	= 0;

		ZeroMemory(&angle, sizeof(angle));
		ZeroMemory(&length, sizeof(length));
		ZeroMemory(&width, sizeof(width));
		ZeroMemory(&mode_a, sizeof(mode_a));

		ZeroMemory(&angle_def, sizeof(angle_def));

		type		= 0;
		action		= 0;
		dir			= 0;

		reset_runtime_data(P1);
		reset_runtime_data(P2);

		//---- set parent bone indices -----------------------------------------------------------

/*		pbi[btll]		= -1;					pbi[btlr]		= -1;
		pbi[btul]		= btll;					pbi[btur]		= btll;
		pbi[bn]			= btul;

		pbi[bsl]		= btul;					pbi[bsr]		= btur;
		pbi[baul]		= bsl;					pbi[baur]		= bsr;
		pbi[ball]		= baul;					pbi[balr]		= baur;

		pbi[bhl]		= btll;					pbi[bhr]		= btlr;
		pbi[blul]		= bhl;					pbi[blur]		= bhr;
		pbi[blll]		= blul;					pbi[bllr]		= blur;
		pbi[bfl]		= blll;					pbi[bfr]		= bllr;

/*		for (i = 0; i < 2; ++i)
		{
			p_pbaa[i][btll]		= NULL;						p_pbaa[i][btlr]		= NULL;
			p_pbaa[i][btul]		= &angle_ad[i][btll];		p_pbaa[i][btur]		= &angle_ad[i][btll];
			p_pbaa[i][bn]		= &angle_ad[i][btul];

			p_pbaa[i][bsl]		= &angle_ad[i][btul];		p_pbaa[i][bsr]		= &angle_ad[i][btur];
			p_pbaa[i][baul]		= &angle_ad[i][bsl];		p_pbaa[i][baur]		= &angle_ad[i][bsr];
			p_pbaa[i][ball]		= &angle_ad[i][baul];		p_pbaa[i][balr]		= &angle_ad[i][baur];

			p_pbaa[i][bhl]		= &angle_ad[i][btll];		p_pbaa[i][bhr]		= &angle_ad[i][btlr];
			p_pbaa[i][blul]		= &angle_ad[i][bhl];		p_pbaa[i][blur]		= &angle_ad[i][bhr];
			p_pbaa[i][blll]		= &angle_ad[i][blul];		p_pbaa[i][bllr]		= &angle_ad[i][blur];
			p_pbaa[i][bfl]		= &angle_ad[i][blll];		p_pbaa[i][bfr]		= &angle_ad[i][bllr];
		}

		p_pbad[btll]		= NULL;						p_pbad[btlr]		= NULL;
		p_pbad[btul]		= &angle_def[btll];			p_pbad[btur]		= &angle_def[btll];
		p_pbad[bn]			= &angle_def[btul];

		p_pbad[bsl]			= &angle_def[btul];			p_pbad[bsr]			= &angle_def[btur];
		p_pbad[baul]		= &angle_def[bsl];			p_pbad[baur]		= &angle_def[bsr];
		p_pbad[ball]		= &angle_def[baul];			p_pbad[balr]		= &angle_def[baur];

		p_pbad[bhl]			= &angle_def[btll];			p_pbad[bhr]			= &angle_def[btlr];
		p_pbad[blul]		= &angle_def[bhl];			p_pbad[blur]		= &angle_def[bhr];
		p_pbad[blll]		= &angle_def[blul];			p_pbad[bllr]		= &angle_def[blur];
		p_pbad[bfl]			= &angle_def[blll];			p_pbad[bfr]			= &angle_def[bllr];*/
	};

	//---- copy constructor ----------------------------------------------------------------------

	keyframe(const keyframe &kf)
	{
		//copy all data

		for (register int i = 0; i < 21; ++i)
			t_frame[i]	= kf.t_frame[i];

		hara		= kf.hara;

		for (i = 0; i < 19; ++i)
		{
			angle[i]	= kf.angle[i];
			length[i]	= kf.length[i];
			width[i]	= kf.width[i];

			mode_a[i]	= kf.mode_a[i];
		}

		type		= kf.type;
		action		= kf.action;
		dir			= kf.dir;

		reset_runtime_data(P1);
		reset_runtime_data(P2);
	};

	//---- reset_runtime_data --------------------------------------------------------------------

	void reset_runtime_data(int p)
	{
		for (register int i = 0; i < 21; ++i)
		{
			t_kfstart[p][i]		= 0;
			state[p][i]			= 0;
			t_frame_ad[p][i]	= 0;
		}

		for (i = 0; i < 19; ++i)
		{
			angle_ad[p][i]	= 0;
			length_ad[p][i]	= 0;
			width_ad[p][i]	= 0;

			speed_a[p][i]	= 0;
			speed_l[p][i]	= 0;
			speed_w[p][i]	= 0;
		}

		hara_ad[p].x		= hara_ad[p].y		= 0;
		hara_r[p].x			= hara_r[p].y		= 0;
		speed_h[p].x		= speed_h[p].y		= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	animation
//
//------------------------------------------------------------------------------------------------

struct animation
{
	//on changes: constructor, copy-constructor, reset_runtime_data
	//!!!
	//special flags, die vorerst leer bleiben, aber sp�ter genutzt werden k�nnen

	int			id;								//id of animation

	keyframe	*pkf;							//pointer to array of keyframes
	int			nokf;							//number of keyframes of animation

	int			priority[21];					//priority level for all bones plus hara (x, y)
												//minimum prioritiy = 0
												//maximum prioritiy = 20

	int			ui_index;						//index of bone which gets user input value
												//if negative the positive index counts
												//but the user input angle gets mirrored
	int			ui_bias;						//bias for user input angle in degree
												//(-20 means user input - 20)

	//---- formula -------------------------------------------------------------------------------
	//the end position of a bone sometimes depends on the user input
	//_diffp is the maximum difference from the angle in the keyframe if
	//the user input angle_180 is less than 90 degree (including 0)
	//_diffn is the maximum difference from the angle in the keyframe if
	//the user input angle_180 is equal or more than 90 degree (up to 179)
	//the runtime _ad data of each keyframe holds the adjusted position
	//of each bone in reference to the user input
	//the formula is used for every keyframe of the animation
	//
	//formula:
	//kf.pos_ad = kf.pos + (_diffn or _diffp / max_value (= 89)) * value
	//neg: value = 89 - value
	//pos: value = value - 90

	int			a_diffp[19];					//positve difference to reference value for every bone
												//0 = formula not used (default)
	int			a_diffn[19];					//negtaive difference to reference value for every bone

	int			l_diffp[19];					//same for length, width and hara
	int			l_diffn[19];
	int			w_diffp[19];
	int			w_diffn[19];

	point		h_diffp;
	point		h_diffn;

	//---- runtime data --------------------------------------------------------------------------

	int		state[2];							//state of animation in animation buffer
												//0			= uninitialized
												//1			= initialized
												//AS_DONE	= done

	int		ui_valid[2];						//if angle/angle_180 valid
	int		angle[2];							//inputstate angle
	int		angle_180[2];						//inputstate angle with values from 0 to 179 only
	int		ui_dir[2];							//direction of bone which gets assigend user input

	int		power_attack[2];					//set true if animation was power attack

	//!! in gldata?
	float	speedfactor[2];						//speedfactor for all t_frame data of all keyframes
												//set in reference to damage and fatigue of player

	//---- game logic data -----------------------------------------------------------------------

	//!!
	//zeiger als parameter �bergeben, active setzen
	//bei aktivieren speedfactor selber berechnen (zeiger auf daten)
	//bei dir = 2 fatigue_target �ber parameter zeiger setzen
	//bei cancel aus animator heraus selbe funktion aber mit fatigue_cancel aufrufen
	int		gl_state[2];						//game logic state for both players
												//0 = not used
												//1 = uninitialized
												//2 = initialized (speedfactor)
												//3 = active frame
												//4 = finished, on way back, ready to apply fatigue
												//5 = either canceled or overwritten by another action, apply fatigue_cancel

	LONGLONG	gl_time[2];						//time index of animation start

	int		gl_fat[2];							//0 = fatigue not applied
												//1 = fatigue applied
	int		gl_attack[2];						//attacks can do damage only once then this
												//flag is set
												//0 = no attack registered
												//1 = attack registered
//	int		gl_def[2];							//same as attack flag but only for defense
												//if defense blocks attack this flag is set

	//!! nicht mehr aktuell
	bool	gl_soundplay[2];					//true = if sound of animation to be played
												//false = sound already played

	//--------------------------------------------------------------------------------------------

	int		gl_bcds_def[19];					//cd state of own bones for this animation
												//0 = not vulnerable
												//1 = vulnerable
												//2 = hitable, no damage
												//3 = hitable, reduced damage
	int		gl_bcds_off[4][19];					//cd state of opponent bones for this animation
												//(for all stances)
												//0 = not hitable
												//1 = hitable

	//efficiency ratio how fatigue and vital bone damage effect
	//speed of animation and offensive damage
	//0 = no effect
	//1 = 1:1 ratio, one point of damage costs one point of efficiency
	//2 = 2:1 ratio, two points of damage cost one point of efficiency
	//and so on
	//values below 1 would actually increase efficiency so shouldn't be used
	//(and can't be since 1.0f is the limit in the player functions)

	float	gl_eff_dam_speed[19];				//affect of damage of bone on speed of animation
	float	gl_eff_dam_off[19];					//affect of damage of bone on offensive damage of animation
												//effect cumulative
												//0 = not used
												//only used when >= 1.0

	float	gl_eff_fat_speed;					//affect of fatigue on speed of animation
	float	gl_eff_fat_off;						//affect of fatigue on offensive damage of animation

	int		gl_damage;							//basic damage this animation does
	int		gl_defend;							//if animation has cds_defpart set bones
												//gl_defend is the percentage of the opponents attack
												//which gets canceled (e.g. 100 = 100%)
												//also used for cds_def, same effect
												//0 = not used
	int		gl_fatigue;							//basic fatigue this animation costs
												//either per action or per second (for cycle animations)
	int		gl_fatigue_cancel;					//fatigue for canceling this animation

	int		gl_soundid;							//sound id to be played (starting when animation starts)

	//---- constructor ---------------------------------------------------------------------------

	animation()
	{
		id			= -1;
		pkf			= NULL;
		nokf		= 0;
		ui_index	= 0;
		ui_bias		= 0;

		ZeroMemory(&priority, sizeof(priority));

		ZeroMemory(&a_diffp, sizeof(a_diffp));
		ZeroMemory(&a_diffn, sizeof(a_diffn));
		ZeroMemory(&l_diffp, sizeof(l_diffp));
		ZeroMemory(&l_diffn, sizeof(l_diffn));
		ZeroMemory(&w_diffp, sizeof(w_diffp));
		ZeroMemory(&w_diffn, sizeof(w_diffn));

		h_diffp.x	= 0;		h_diffp.y	= 0;
		h_diffn.x	= 0;		h_diffn.y	= 0;

		reset_runtime_data(P1);
		reset_runtime_data(P2);

		reset_gl_data();
	};

	//---- destructor ----------------------------------------------------------------------------

	~animation()
	{
		//delete allocated keyframe array
		if (pkf != NULL)
		{
			delete [] pkf;
			pkf		= NULL;
		}

		nokf	= 0;
	};

	//---- reset_runtime_data --------------------------------------------------------------------
	//resets runtime data of player of animation and all keyframes

	void reset_runtime_data(int p)							//player
	{
		state[p]		= 0;
		ui_valid[p]		= 0;
		angle[p]		= 0;
		angle_180[p]	= 0;
		ui_dir[p]		= -1;
		power_attack[p]	= 0;
		speedfactor[p]	= 1.0f;

		//for number of keyframes, reset keyframe
		for (register int i = 0; i < nokf; ++i)
			pkf[i].reset_runtime_data(p);

		//reset state
		gl_state[p]		= 0;

		//reset time
		gl_time[p]		= 0;

		//game logic data
		gl_fat[p]		= 0;
		gl_attack[p]	= 0;
//		gl_def[p]		= 0;
		gl_soundplay[p]	= false;
	};

	//---- reset_gl_data -------------------------------------------------------------------------

	void reset_gl_data()
	{
		ZeroMemory(&gl_state, sizeof(gl_state));
		ZeroMemory(&gl_fat, sizeof(gl_fat));

		ZeroMemory(&gl_bcds_def, sizeof(gl_bcds_def));
		ZeroMemory(&gl_bcds_off, sizeof(gl_bcds_off));

		ZeroMemory(&gl_eff_dam_speed, sizeof(gl_eff_dam_speed));
		ZeroMemory(&gl_eff_dam_off, sizeof(gl_eff_dam_off));
		gl_eff_fat_speed		= 0;
		gl_eff_fat_off			= 0;

		gl_damage				= 0;
		gl_defend				= 0;
		gl_fatigue				= 0;
		gl_fatigue_cancel		= 0;

		gl_soundid				= -1;
	};

	//---- load_animation ------------------------------------------------------------------------
	//loads specified animation from file

	bool load_animation(char *file, int version, int _type)		//_type 0 = animation, 1 = keyframe
	{
		switch (version)
		{
		//---- load version 0 --------------------------------------------------------------------

		case (0):
			{
/*				//dummy data
				int special	= 0;

				//open animation file
				//(read, binary)
				FILE	*f_animation = fopen(file, "rb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//log file access
					gf_logger("accessing file:", file, false);

					//read animation header if _type 0
					if (_type == 0)
					{
						fscanf(f_animation,
							   "%i %i %i %i %i %i %i %i %i %i %i",
							   &nokf,
							   &sound_id, &fatigue, &damage,
							   &priority[0], &priority[1], &priority[2], &priority[3], &priority[4], &priority[5],
							   &special);

						//delete old keyframe array and create new one with size of nokf (at least size 1)
						//if read in nokf of animation ist at least 1
						if (nokf < 1)
						{
							//close file
							fclose(f_animation);

							return false;
						}
						else
						{
							//delete allocated keyframe array
							if (pkf != NULL)
							{
								delete [] pkf;
								pkf		= NULL;
							}

							//create array of keyframes
							pkf		= new keyframe[nokf];

							//return false if allocation fails, else true
							if (pkf == NULL)
							{
								nokf	= 0;

								//close file
								fclose(f_animation);

								return false;
							}
						}
					}

					//read keyframe data
					//number of keyframes to load, either whole animation or just one keyframe
					int nokf_r;
					_type == 0 ? nokf_r = nokf : nokf_r = 1;
					for (register int kfi = 0; kfi < nokf_r; ++kfi)
					{
						fscanf(f_animation,
							   "%i %i %i %i %i %i %f %f %i %i %i",
								&pkf[kfi].t_frame[0], &pkf[kfi].t_frame[1], &pkf[kfi].t_frame[2], &pkf[kfi].t_frame[3], &pkf[kfi].t_frame[4], &pkf[kfi].t_frame[5],
								&pkf[kfi].hara.x, &pkf[kfi].hara.y,
								&pkf[kfi].type,
								&pkf[kfi].action,
								&pkf[kfi].dir);

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							fscanf(f_animation,
								"%f %f %f %i",
								&pkf[kfi].angle[b],
								&pkf[kfi].length[b],
								&pkf[kfi].width[b],
								&pkf[kfi].mode_a[b]);
						}
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;*/

				break;
			}

		//---- load version 1 --------------------------------------------------------------------

		case (1):
			{
				//open animation file
				//(read, binary)
				FILE	*f_animation = fopen(file, "rb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//log file access
					gf_logger(false, "accessing file: %s", file);

					//read animation header if _type 0
					if (_type == 0)
					{
						//id, nokf, ui_index, ui_bias
						fscanf(f_animation, "%i %i %i %i", &id, &nokf, &ui_index, &ui_bias);
						//priority
						for (register int i = 0; i < 21; ++i)
							fscanf(f_animation, "%i", &priority[i]);
						//formula
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &a_diffp[i]);
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &a_diffn[i]);
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &l_diffp[i]);
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &l_diffn[i]);
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &w_diffp[i]);
						for (i = 0; i < 19; ++i)		fscanf(f_animation, "%i", &w_diffn[i]);
						fscanf(f_animation, "%f %f %f %f",
							   &h_diffp.x, &h_diffp.y, &h_diffn.x, &h_diffn.y);

/*						//game logic data
						//damage, defend, fatigue, fatigue_cancel, sound id
						fscanf(f_animation, "%i %i %i %i %i",
							   &gl_damage, &gl_defend, &gl_fatigue, &gl_fatigue_cancel, &gl_soundid);

						//cd state; efficiency
						for (i = 0; i < 19; ++i)
						{
							//cd defense state
							fscanf(f_animation, "%i", &gl_bcds_def[i]);

							//cd offense state
							for (register int s = 0; s < 4; ++s)
								fscanf(f_animation, "%i", &gl_bcds_off[s][i]);

							//damage efficiency
							fscanf(f_animation, "%f %f",
								   &gl_eff_dam_speed[i], &gl_eff_dam_off[i]);
						}
						//fatigue efficiency
						fscanf(f_animation, "%f %f",
							   &gl_eff_fat_speed, &gl_eff_fat_off);*/

						//delete old keyframe array and create new one with size of nokf (at least size 1)
						//if read in nokf of animation ist at least 1
						if (nokf < 1)
						{
							//close file
							fclose(f_animation);

							return false;
						}
						else
						{
							//delete allocated keyframe array
							if (pkf != NULL)
							{
								delete [] pkf;
								pkf		= NULL;
							}

							//create array of keyframes
							pkf		= new keyframe[nokf];

							//return false if allocation fails, else true
							if (pkf == NULL)
							{
								nokf	= 0;

								//close file
								fclose(f_animation);

								return false;
							}
						}
					}

					//read keyframe data
					//number of keyframes to load, either whole animation or just one keyframe
					int nokf_r;
					_type == 0 ? nokf_r = nokf : nokf_r = 1;
					for (register int kfi = 0; kfi < nokf_r; ++kfi)
					{
						//hara (x, y), type, action, dir
						fscanf(f_animation,
							   "%f %f %i %i %i",
							   &pkf[kfi].hara.x, &pkf[kfi].hara.y,
							   &pkf[kfi].type,
							   &pkf[kfi].action,
							   &pkf[kfi].dir);
						//t_frame
						for (register int i = 0; i < 21; ++i)
							fscanf(f_animation, "%i", &pkf[kfi].t_frame[i]);

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							//angle, length, widht, mode_a
							fscanf(f_animation,
								"%f %f %f %i",
								&pkf[kfi].angle[b],
								&pkf[kfi].length[b],
								&pkf[kfi].width[b],
								&pkf[kfi].mode_a[b]);
						}
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;

				break;
			}
		}

		return false;
	};

	//---- save_animation ------------------------------------------------------------------------
	//saves specified animation in file

	bool save_animation(char *file, int version, int _type)			//_type 0 = animation, 1 = single keyframe
	{
		switch (version)
		{
		//---- save version 0 --------------------------------------------------------------------

		case (0):
			{
/*				//dummy data
				int special	= 0;

				//open animation file
				//(overwrite, binary)
				FILE	*f_animation = fopen(file, "wb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//log file access
					gf_logger("accessing file:", file, false);

					//write animation header if no single keyframe
					if (_type == 0)
						fprintf(f_animation,
								"%i\n %i %i %i\n %i %i %i %i %i %i\n %i\n",	//nokf, sound id, fatigue, damage, priorities, special
								nokf,
								sound_id, fatigue, damage,
								priority[0], priority[1], priority[2], priority[3], priority[4], priority[5],
								special);

					//write keyframe data
					//number of keyframes to write, either whole animation or just one keyframe
					int nokf_w;
					_type == 0 ? nokf_w = nokf : nokf_w = 1;

					for (register int kfi = 0; kfi < nokf_w; ++kfi)
					{
						fprintf(f_animation,
								"%i %i %i %i %i %i\n %.f %.f\n %i\n %i\n %i\n",	//t_frame[6], hara.x/y, type, action, dir
								pkf[kfi].t_frame[0], pkf[kfi].t_frame[1], pkf[kfi].t_frame[2], pkf[kfi].t_frame[3], pkf[kfi].t_frame[4], pkf[kfi].t_frame[5],
								pkf[kfi].hara.x, pkf[kfi].hara.y,
								pkf[kfi].type,
								pkf[kfi].action,
								pkf[kfi].dir);

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							fprintf(f_animation,
									"%.f %.f %.f\n %i\n",		//angle, length, width, mode_a
									pkf[kfi].angle[b],
									pkf[kfi].length[b],
									pkf[kfi].width[b],
									pkf[kfi].mode_a[b]);
						}

						//set keyframe end sign
						if (_type == 0)
							fprintf(f_animation,
									"\n\n");
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;*/

				break;
			}

		//---- save version 1 --------------------------------------------------------------------

		case (1):
			{
				//open animation file
				//(overwrite, binary)
				FILE	*f_animation = fopen(file, "wb");

				//if file successfully opened
				if (f_animation != NULL)
				{
					//log file access
					gf_logger(false, "accessing file: %s", file);

					//write animation header if no single keyframe
					if (_type == 0)
						//!! sollte hier nicht eine klammer hin?
						//id, nokf, ui_index, ui_bias
						fprintf(f_animation,
								"%i\n %i\n %i %i\n",
								id, nokf, ui_index, ui_bias);
						//priority
						for (register int i = 0; i < 21; ++i)
							fprintf(f_animation, " %i", priority[i]);
						fprintf(f_animation, "\n");
						//formula
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", a_diffp[i]);
						fprintf(f_animation, "\n");
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", a_diffn[i]);
						fprintf(f_animation, "\n");
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", l_diffp[i]);
						fprintf(f_animation, "\n");
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", l_diffn[i]);
						fprintf(f_animation, "\n");
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", w_diffp[i]);
						fprintf(f_animation, "\n");
						for (i = 0; i < 19; ++i)		fprintf(f_animation, " %i", w_diffn[i]);
						fprintf(f_animation, "\n");
						fprintf(f_animation,
								" %.f %.f %.f %.f\n",
								h_diffp.x, h_diffp.y, h_diffn.x, h_diffn.y);

/*						//game logic data
						//damage, defend, fatigue, fatigue_cancel, sound id
						fprintf(f_animation, "%i %i %i %i %i\n",
								gl_damage, gl_defend, gl_fatigue, gl_fatigue_cancel, gl_soundid);

						//cd state, efficiency
						for (i = 0; i < 19; ++i)
						{
							//cd defense state
							fprintf(f_animation, " %i", gl_bcds_def[i]);

							//cd offense state
							for (register int s = 0; s < 4; ++s)
								fprintf(f_animation, " %i", gl_bcds_off[s][i]);

							//damage efficiency
							fprintf(f_animation, " %.2f %.2f",
									gl_eff_dam_speed[i], gl_eff_dam_off[i]);

							fprintf(f_animation, "\n");
						}
						//fatigue efficiency
						fprintf(f_animation, "%.2f %.2f",
								gl_eff_fat_speed, gl_eff_fat_off);
						fprintf(f_animation, "\n");*/

					//write keyframe data
					//number of keyframes to write, either whole animation or just one keyframe
					int nokf_w;
					_type == 0 ? nokf_w = nokf : nokf_w = 1;

					for (register int kfi = 0; kfi < nokf_w; ++kfi)
					{
						//hara (x, y), type, action, dir
						fprintf(f_animation,
								" %.f %.f\n %i\n %i\n %i\n\n",
								pkf[kfi].hara.x, pkf[kfi].hara.y,
								pkf[kfi].type,
								pkf[kfi].action,
								pkf[kfi].dir);
						//t_frame
						for (register int i = 0; i < 21; ++i)
							fprintf(f_animation, " %i", pkf[kfi].t_frame[i]);
						fprintf(f_animation, "\n");

						//for every bone
						for (register int b = 0; b < 19; ++b)
						{
							//angle, length, width, mode_a
							fprintf(f_animation,
									"%.f %.f %.f %i\n",
									pkf[kfi].angle[b],
									pkf[kfi].length[b],
									pkf[kfi].width[b],
									pkf[kfi].mode_a[b]);
						}

						//set keyframe end sign
						if (_type == 0)
							fprintf(f_animation, "\n\n");
					}

					//close file
					fclose(f_animation);

					return true;
				}
				else
					return false;

				break;
			}
		}

		return false;
	};

	//---- add_keyframe --------------------------------------------------------------------------

	bool add_keyframe()
	{
		//pointer to old keyframe array
		keyframe	*okf = pkf;

		//allocate new array with size + 1
		pkf			= new keyframe[nokf + 1];

		//return false if allocation fails, else true
		if (pkf == NULL)
		{
			//redirect pointer to old array
			pkf		= okf;
			okf		= NULL;
			return false;
		}
		else
		{
			//copy old keyframe array data into new one
			for (register int i = 0; i < nokf; ++i)
				pkf[i] = okf[i];

			//increase number of keyframes
			++nokf;

			//delete old array and NULL the pointer to old keyframe array
			delete [] okf;
			okf		= NULL;

			return true;
		}
	};

	//---- del_keyframe --------------------------------------------------------------------------

	bool del_keyframe()
	{
		//pointer to old keyframe array
		keyframe	*okf = pkf;

		//allocate new array with size - 1, only if array consists of more than 1 kf
		if (nokf > 1)
			pkf			= new keyframe[nokf - 1];
		else
			return false;

		//return false if allocation fails, else true
		if (pkf == NULL)
		{
			//redirect pointer to old array
			pkf		= okf;
			okf		= NULL;
			return false;
		}
		else
		{
			//copy old keyframe array data into new one
			for (register int i = 0; i < nokf - 1; ++i)
				pkf[i] = okf[i];

			//decrease number of keyframes
			--nokf;

			//delete old array and NULL the pointer to old keyframe array
			delete [] okf;
			okf		= NULL;

			return true;
		}
	};

	//---- new_animation -------------------------------------------------------------------------
	//creates new array of empty keyframes

	bool new_animation(int nkf)				//number of keyframes
	{
		//with at least size 1
		if (nkf < 1)
			return false;
		else
		{
			//number of keyframes
			nokf	= nkf;

			//create array of keyframes
			pkf		= new keyframe[nokf];

			//return false if allocation fails, else true
			if (pkf == NULL)
			{
				nokf	= 0;
				return false;
			}
			else
				return true;
		}
	};

	//---- calculate_default_angles --------------------------------------------------------------

	//parent bone index as argument (only neck changes though)
	void calculate_default_angles(int _btll, int _btlr, int _btul, int _btur, int _bn,
								  int _bsl, int _baul, int _ball,
								  int _bsr, int _baur, int _balr,
								  int _bhl, int _blul, int _blll, int _bfl,
								  int _bhr, int _blur, int _bllr, int _bfr)
	{
		//parent bone index
		int pbi[19] = {_btll, _btlr, _btul, _btur, _bn,
					   _bsl, _baul, _ball,
					   _bsr, _baur, _balr,
					   _bhl, _blul, _blll, _bfl,
					   _bhr, _blur, _bllr, _bfr};

		//for all keyframes of animation
		for (register int kf = 0; kf < nokf; ++kf)
			//for all bones
			for (register int b = 0; b < 19; ++b)
			{
				//initialize default angle with angle
				pkf[kf].angle_def[b] = (float)(int)pkf[kf].angle[b];

				//adjust to mode_a
				if (pkf[kf].mode_a[b] == 1)
					//if (pkf[kf].pbi[b] >= 0)
					if (pbi[b] != -1)
					{
						//set default speed angle
						pkf[kf].angle_def[b] +=
							//pkf[kf].angle_def[pkf[kf].pbi[b]];
							pkf[kf].angle_def[pbi[b]];

						//check angle_def doesn't exceed its limit
						if (pkf[kf].angle_def[b] > 359)		pkf[kf].angle_def[b] -= 360;
						if (pkf[kf].angle_def[b] < 0)		pkf[kf].angle_def[b] += 360;
					}
			}
	};
};

//------------------------------------------------------------------------------------------------
//
//	result_collision_detection
//
//	holds results of collision detection
//
//------------------------------------------------------------------------------------------------

struct result_collision_detection
{
	int					bone[2][22];				//indicates P1/P2 bones (19 head, 20/21 left/right fist)
													//are hit or not
													//0 = not hit
													//1 - 6 == hit by according action type

	LONGLONG			time[2][22];				//time index when hit

	int					attack[2][6];				//indicates which limb is hitting something
													//(P1/P2, left/right fist, foot, knee)
													//- 1 = no bone hit
													//0 - 21 = bones, head, fists
	int					defend[2];					//set to boneindex if attack hit that bone in cds_defpart state
													//gets reset by either player
													//by attacker if his attack animation is done
													//by defender if defense bonus was applied
													//like damage it holds the value for the other player
													//if defend[P1] is valid, P2 will get the bonus

	float				angle_h[2];					//P1/P2 angle of hit between head and fist/center of foot

	int					attack_cancel[2][6];		//for all attack types
													//if player hits bone in defense state
													//0 = don't cancel
													//1 = cancel
	int					attack_return[2][6];		//for all attack types
													//if player hits defense state and defense not locked
													//0 = don't return damage
													//1 = return damage

	float				damage[2];					//damage caused by player

	//---- constructor ---------------------------------------------------------------------------

	result_collision_detection()
	{
		ZeroMemory(&bone, sizeof(bone));
		ZeroMemory(&time, sizeof(time));
		for (register int i = 0; i < 6; ++i)
		{
			attack[P1][i]	= -1;
			attack[P2][i]	= -1;
		}
		defend[P1]			= -1;
		defend[P2]			= -1;
		ZeroMemory(&angle_h, sizeof(angle_h));
		ZeroMemory(&attack_cancel, sizeof(attack_cancel));
		ZeroMemory(&attack_return, sizeof(attack_return));
		ZeroMemory(&damage, sizeof(damage));
	};
};

//------------------------------------------------------------------------------------------------
//
//	yin yang symbol		9 * 32 byte + 4 * 16 byte = 352 byte (NOT UP TO DATE)
//
//	contains function to calculate itself with a given angle and size
//
//------------------------------------------------------------------------------------------------

struct yinyang
{
	rectangle	r[9];				//0 = small yellow part
									//1 = big yellow part
									//2 = big red
									//3 = small red
									//4 = yellow eye
									//5 = red eye
									//6 = outer border
									//7 = yellow patch
									//8 = red patch

	line		l[4];				//0 = center to small yellow part
									//1 = center to small red part
									//2 = small yellow border
									//3 = small red border

	point		pos;				//position of symbol
	float		angle;				//angle of symbol
	float		size;				//size of symbol
	float		speed;				//rotating speed
	float		speed_min;			//minimum absolute rotation speed
	float		speed_max;			//maximum absolute rotation speed
	float		speed_thresh;		//rotation threshold
	float		speed_acc;			//acceleration speed in units per second
	float		speed_dec;			//deceleration speed in units per second

	RGBcolor	ycyi;				//color of dark part
	RGBcolor	ycya;				//color of light part
	RGBcolor	ycborder;			//bordercolor

	//---- constructor ----------------------------------------------------------------------------

	yinyang()
	{
		pos.x	= 0;
		pos.y	= 0;

		angle		= 0;
		size		= 0;
		speed			= 0;
		speed_min		= 0;
		speed_max		= 0;
		speed_thresh	= 0;
		speed_acc		= 0;
		speed_dec		= 0;

		ycyi.setcolor(black);
		ycya.setcolor(white);
		ycborder.setcolor(black);
	};

	//---- constructor ----------------------------------------------------------------------------
	//overloaded with ini arguments

	yinyang(int x, int y, float _angle, float _size)
	{
		pos.x	= (float)x;
		pos.y	= (float)y;

		angle	= _angle;
		size	= _size;
	};

	//---- set_angle -----------------------------------------------------------------------------
	//set angle of yinyang, argumented or random

	void set_angle(float _angle, int random = 0)
	{
		//random angle
		if (random)
		{
			//random in 360 degree circle
			angle = 0 + (float)(rand() % (359 - 0 + 1));
			return;
		}
		else
		{
			//set angle
			angle = _angle;
			return;
		}
	};

	//---- check_angle ----------------------------------------------------------------------------
	//angle only valid between 0 and 359 degree
	//returns true if adjusted

	bool check_angle()
	{
		if (angle < 0)
		{
			while (angle < 0)
				angle += 360;
			return(true);
		}

		if (angle > 359)
		{
			while (angle > 359)
				angle -= 360;
			return(true);
		}

		return(false);
	};

	//---- set_position ---------------------------------------------------------------------------
	//set position of yinyang

	void set_position(int x, int y)
	{
		pos.x	= (float)x;
		pos.y	= (float)y;
	};

	//---- set_size -------------------------------------------------------------------------------
	//set size of yinyang

	void set_size(float _size)
	{
		size	= _size;
	};

	//---- set_speed ------------------------------------------------------------------------------
	//sets rotating speed of yinyang

	void set_speed(float _speed)
	{
		speed	= _speed;
	};

	void add_speed(float _add_speed)
	{
		speed	+= _add_speed;
	};

	//---- set speed data -------------------------------------------------------------------------

	void set_speed_data(float _min, float _max, float _thresh, float _acc, float _dec)
	{
		speed_min		= _min;
		speed_max		= _max;
		speed_thresh	= _thresh;
		speed_acc		= _acc;
		speed_dec		= _dec;
	};

	//---- set_colors -----------------------------------------------------------------------------
	//sets colors of yin yang symbol

	void set_colors(RGBcolor yin, RGBcolor yang, RGBcolor border = black)
	{
		ycyi.setcolor(yin);			//dark part
		ycya.setcolor(yang);		//light part
		ycborder.setcolor(border);
	};

	//---- calculate -----------------------------------------------------------------------------

	//calculates all values according to current center, angle and size
	void calculate()
	{
		point c = pos;
		float a = angle;

		float radDEF	= a / 180 * PI;						//angel in radians
		float rad090	= (a + 90) / 180 * PI;				//default angle + 90 degrees
		float rad180	= (a + 180) / 180 * PI;				//+ 180
		float rad270	= (a + 270) / 180 * PI;				//+ 270

		//diameter in pixel, 200 default
		float diameter				= 200 * size;
		l[0].p[0].x	= l[1].p[0].x	= c.x;
		l[0].p[0].y	= l[1].p[0].y	= c.y;

		//---- center to small yellow line -------------------------------------------------------

		l[0].p[1].x = l[0].p[0].x + diameter / 6 * (float)cos(radDEF);
		l[0].p[1].y = l[0].p[0].y + diameter / 6 * (float)sin(radDEF);

		//---- center to small red line ----------------------------------------------------------

		l[1].p[1].x = l[1].p[0].x + diameter / 6 * (float)cos(rad180);
		l[1].p[1].y = l[1].p[0].y + diameter / 6 * (float)sin(rad180);

		//---- small yellow ----------------------------------------------------------------------

		r[0].p[0].x = l[0].p[1].x;		r[0].p[0].y = l[0].p[1].y;

		r[0].p[1].x = r[0].p[0].x + diameter / 3 * (float)cos(radDEF);
		r[0].p[1].y = r[0].p[0].y + diameter / 3 * (float)sin(radDEF);
		r[0].p[2].x = r[0].p[1].x + diameter / 2 * (float)cos(rad090);
		r[0].p[2].y = r[0].p[1].y + diameter / 2 * (float)sin(rad090);
		r[0].p[3].x = r[0].p[2].x + diameter / 3 * (float)cos(rad180);
		r[0].p[3].y = r[0].p[2].y + diameter / 3 * (float)sin(rad180);

		//---- big yellow ------------------------------------------------------------------------

		r[1].p[0].x = r[0].p[1].x;		r[1].p[0].y = r[0].p[1].y;
		r[1].p[1].x = l[1].p[1].x;		r[1].p[1].y = l[1].p[1].y;

		r[1].p[2].x = r[1].p[1].x + diameter / 2 * (float)cos(rad270);
		r[1].p[2].y = r[1].p[1].y + diameter / 2 * (float)sin(rad270);
		r[1].p[3].x = r[1].p[2].x + diameter * (2.0f / 3.0f) * (float)cos(radDEF);
		r[1].p[3].y = r[1].p[2].y + diameter * (2.0f / 3.0f) * (float)sin(radDEF);

		//---- big red ---------------------------------------------------------------------------

		r[2].p[0].x = l[0].p[1].x;		r[2].p[0].y = l[0].p[1].y;
		r[2].p[1].x = r[0].p[3].x;		r[2].p[1].y = r[0].p[3].y;

		r[2].p[2].x = r[2].p[1].x + diameter * (2.0f / 3.0f) * (float)cos(rad180);
		r[2].p[2].y = r[2].p[1].y + diameter * (2.0f / 3.0f) * (float)sin(rad180);
		r[2].p[3].x = r[2].p[2].x + diameter / 2 * (float)cos(rad270);
		r[2].p[3].y = r[2].p[2].y + diameter / 2 * (float)sin(rad270);

		//---- small red -------------------------------------------------------------------------

		r[3].p[0].x = l[1].p[1].x;		r[3].p[0].y = l[1].p[1].y;
		r[3].p[1].x = r[2].p[3].x;		r[3].p[1].y = r[2].p[3].y;
		r[3].p[3].x = r[1].p[2].x;		r[3].p[3].y = r[1].p[2].y;

		r[3].p[2].x = r[3].p[1].x + diameter / 2 * (float)cos(rad270);
		r[3].p[2].y = r[3].p[1].y + diameter / 2 * (float)sin(rad270);

		//---- yellow eye ------------------------------------------------------------------------

		//temporary point
		float	tx, ty;

		tx = l[1].p[1].x + diameter / 6 * (float)cos(rad090);
		ty = l[1].p[1].y + diameter / 6 * (float)sin(rad090);

		r[4].p[0].x = tx + diameter / 12 * (float)cos(rad180);
		r[4].p[0].y = ty + diameter / 12 * (float)sin(rad180);

		r[4].p[1].x = r[4].p[0].x + diameter / 6 * (float)cos(radDEF);
		r[4].p[1].y = r[4].p[0].y + diameter / 6 * (float)sin(radDEF);

		r[4].p[2].x = r[4].p[1].x + diameter / 6 * (float)cos(rad090);
		r[4].p[2].y = r[4].p[1].y + diameter / 6 * (float)sin(rad090);

		r[4].p[3].x = r[4].p[2].x + diameter / 6 * (float)cos(rad180);
		r[4].p[3].y = r[4].p[2].y + diameter / 6 * (float)sin(rad180);

		//---- red eye ---------------------------------------------------------------------------

		tx = l[0].p[1].x + diameter / 6 * (float)cos(rad270);
		ty = l[0].p[1].y + diameter / 6 * (float)sin(rad270);

		r[5].p[0].x = tx + diameter / 12 * (float)cos(rad180);
		r[5].p[0].y = ty + diameter / 12 * (float)sin(rad180);

		r[5].p[1].x = r[5].p[0].x + diameter / 6 * (float)cos(radDEF);
		r[5].p[1].y = r[5].p[0].y + diameter / 6 * (float)sin(radDEF);

		r[5].p[2].x = r[5].p[1].x + diameter / 6 * (float)cos(rad270);
		r[5].p[2].y = r[5].p[1].y + diameter / 6 * (float)sin(rad270);

		r[5].p[3].x = r[5].p[2].x + diameter / 6 * (float)cos(rad180);
		r[5].p[3].y = r[5].p[2].y + diameter / 6 * (float)sin(rad180);

		//---- yellow patch ----------------------------------------------------------------------

		r[7].p[0].x = l[0].p[1].x + diameter / 20 * (float)cos(rad270);
		r[7].p[0].y = l[0].p[1].y + diameter / 20 * (float)sin(rad270);
		r[7].p[1].x = r[7].p[0].x + diameter / 3 * (float)cos(radDEF);
		r[7].p[1].y = r[7].p[0].y + diameter / 3 * (float)sin(radDEF);
		r[7].p[2].x = r[7].p[1].x + diameter / 10 * (float)cos(rad090);
		r[7].p[2].y = r[7].p[1].y + diameter / 10 * (float)sin(rad090);
		r[7].p[3].x = r[7].p[2].x + diameter / 3 * (float)cos(rad180);
		r[7].p[3].y = r[7].p[2].y + diameter / 3 * (float)sin(rad180);

		//---- red patch -------------------------------------------------------------------------

		r[8].p[0].x = l[1].p[1].x + diameter / 20 * (float)cos(rad270);
		r[8].p[0].y = l[1].p[1].y + diameter / 20 * (float)sin(rad270);
		r[8].p[1].x = r[8].p[0].x + diameter / 3 * (float)cos(rad180);
		r[8].p[1].y = r[8].p[0].y + diameter / 3 * (float)sin(rad180);
		r[8].p[2].x = r[8].p[1].x + diameter / 10 * (float)cos(rad090);
		r[8].p[2].y = r[8].p[1].y + diameter / 10 * (float)sin(rad090);
		r[8].p[3].x = r[8].p[2].x + diameter / 3 * (float)cos(radDEF);
		r[8].p[3].y = r[8].p[2].y + diameter / 3 * (float)sin(radDEF);

		//---- outer border ----------------------------------------------------------------------

		r[6].p[0].x = r[0].p[2].x;		r[6].p[0].y = r[0].p[2].y;
		r[6].p[1].x = r[2].p[2].x;		r[6].p[1].y = r[2].p[2].y;
		r[6].p[2].x = r[3].p[2].x;		r[6].p[2].y = r[3].p[2].y;
		r[6].p[3].x = r[1].p[3].x;		r[6].p[3].y = r[1].p[3].y;

		//---- small yellow border ---------------------------------------------------------------

		l[2].p[0].x = l[0].p[1].x;		l[2].p[0].y = l[0].p[1].y;
		l[2].p[1].x = r[0].p[3].x;		l[2].p[1].y = r[0].p[3].y;

		//---- small red border ------------------------------------------------------------------

		l[3].p[0].x = l[1].p[1].x;		l[3].p[0].y = l[1].p[1].y;
		l[3].p[1].x = r[3].p[3].x;		l[3].p[1].y = r[3].p[3].y;
	};

/*	//---- calculate -----------------------------------------------------------------------------

	//calculates all values according to center, angle and size
	void calculate(point c,				//center of symbol
				   float a,				//angel of l[0]
				   float size = 1.0f)	//size, default 1.0f
	{
		float radDEF	= a / 180 * PI;						//angel in radians
		float rad090	= (a + 90) / 180 * PI;				//default angle + 90 degrees
		float rad180	= (a + 180) / 180 * PI;				//+ 180
		float rad270	= (a + 270) / 180 * PI;				//+ 270

		//diameter in pixel, 200 default
		float diameter				= 200 * size;
		l[0].p[0].x	= l[1].p[0].x	= c.x;
		l[0].p[0].y	= l[1].p[0].y	= c.y;

		//---- center to small yellow line -------------------------------------------------------

		l[0].p[1].x = l[0].p[0].x + diameter / 6 * (float)cos(radDEF);
		l[0].p[1].y = l[0].p[0].y + diameter / 6 * (float)sin(radDEF);

		//---- center to small red line ----------------------------------------------------------

		l[1].p[1].x = l[1].p[0].x + diameter / 6 * (float)cos(rad180);
		l[1].p[1].y = l[1].p[0].y + diameter / 6 * (float)sin(rad180);

		//---- small yellow ----------------------------------------------------------------------

		r[0].p[0].x = l[0].p[1].x;		r[0].p[0].y = l[0].p[1].y;

		r[0].p[1].x = r[0].p[0].x + diameter / 3 * (float)cos(radDEF);
		r[0].p[1].y = r[0].p[0].y + diameter / 3 * (float)sin(radDEF);
		r[0].p[2].x = r[0].p[1].x + diameter / 2 * (float)cos(rad090);
		r[0].p[2].y = r[0].p[1].y + diameter / 2 * (float)sin(rad090);
		r[0].p[3].x = r[0].p[2].x + diameter / 3 * (float)cos(rad180);
		r[0].p[3].y = r[0].p[2].y + diameter / 3 * (float)sin(rad180);

		//---- big yellow ------------------------------------------------------------------------

		r[1].p[0].x = r[0].p[1].x;		r[1].p[0].y = r[0].p[1].y;
		r[1].p[1].x = l[1].p[1].x;		r[1].p[1].y = l[1].p[1].y;

		r[1].p[2].x = r[1].p[1].x + diameter / 2 * (float)cos(rad270);
		r[1].p[2].y = r[1].p[1].y + diameter / 2 * (float)sin(rad270);
		r[1].p[3].x = r[1].p[2].x + diameter * (2.0f / 3.0f) * (float)cos(radDEF);
		r[1].p[3].y = r[1].p[2].y + diameter * (2.0f / 3.0f) * (float)sin(radDEF);

		//---- big red ---------------------------------------------------------------------------

		r[2].p[0].x = l[0].p[1].x;		r[2].p[0].y = l[0].p[1].y;
		r[2].p[1].x = r[0].p[3].x;		r[2].p[1].y = r[0].p[3].y;

		r[2].p[2].x = r[2].p[1].x + diameter * (2.0f / 3.0f) * (float)cos(rad180);
		r[2].p[2].y = r[2].p[1].y + diameter * (2.0f / 3.0f) * (float)sin(rad180);
		r[2].p[3].x = r[2].p[2].x + diameter / 2 * (float)cos(rad270);
		r[2].p[3].y = r[2].p[2].y + diameter / 2 * (float)sin(rad270);

		//---- small red -------------------------------------------------------------------------

		r[3].p[0].x = l[1].p[1].x;		r[3].p[0].y = l[1].p[1].y;
		r[3].p[1].x = r[2].p[3].x;		r[3].p[1].y = r[2].p[3].y;
		r[3].p[3].x = r[1].p[2].x;		r[3].p[3].y = r[1].p[2].y;

		r[3].p[2].x = r[3].p[1].x + diameter / 2 * (float)cos(rad270);
		r[3].p[2].y = r[3].p[1].y + diameter / 2 * (float)sin(rad270);

		//---- yellow eye ------------------------------------------------------------------------

		//temporary point
		float	tx, ty;

		tx = l[1].p[1].x + diameter / 6 * (float)cos(rad090);
		ty = l[1].p[1].y + diameter / 6 * (float)sin(rad090);

		r[4].p[0].x = tx + diameter / 12 * (float)cos(rad180);
		r[4].p[0].y = ty + diameter / 12 * (float)sin(rad180);

		r[4].p[1].x = r[4].p[0].x + diameter / 6 * (float)cos(radDEF);
		r[4].p[1].y = r[4].p[0].y + diameter / 6 * (float)sin(radDEF);

		r[4].p[2].x = r[4].p[1].x + diameter / 6 * (float)cos(rad090);
		r[4].p[2].y = r[4].p[1].y + diameter / 6 * (float)sin(rad090);

		r[4].p[3].x = r[4].p[2].x + diameter / 6 * (float)cos(rad180);
		r[4].p[3].y = r[4].p[2].y + diameter / 6 * (float)sin(rad180);

		//---- red eye ---------------------------------------------------------------------------

		tx = l[0].p[1].x + diameter / 6 * (float)cos(rad270);
		ty = l[0].p[1].y + diameter / 6 * (float)sin(rad270);

		r[5].p[0].x = tx + diameter / 12 * (float)cos(rad180);
		r[5].p[0].y = ty + diameter / 12 * (float)sin(rad180);

		r[5].p[1].x = r[5].p[0].x + diameter / 6 * (float)cos(radDEF);
		r[5].p[1].y = r[5].p[0].y + diameter / 6 * (float)sin(radDEF);

		r[5].p[2].x = r[5].p[1].x + diameter / 6 * (float)cos(rad270);
		r[5].p[2].y = r[5].p[1].y + diameter / 6 * (float)sin(rad270);

		r[5].p[3].x = r[5].p[2].x + diameter / 6 * (float)cos(rad180);
		r[5].p[3].y = r[5].p[2].y + diameter / 6 * (float)sin(rad180);

		//---- yellow patch ----------------------------------------------------------------------

		r[7].p[0].x = l[0].p[1].x + diameter / 20 * (float)cos(rad270);
		r[7].p[0].y = l[0].p[1].y + diameter / 20 * (float)sin(rad270);
		r[7].p[1].x = r[7].p[0].x + diameter / 3 * (float)cos(radDEF);
		r[7].p[1].y = r[7].p[0].y + diameter / 3 * (float)sin(radDEF);
		r[7].p[2].x = r[7].p[1].x + diameter / 10 * (float)cos(rad090);
		r[7].p[2].y = r[7].p[1].y + diameter / 10 * (float)sin(rad090);
		r[7].p[3].x = r[7].p[2].x + diameter / 3 * (float)cos(rad180);
		r[7].p[3].y = r[7].p[2].y + diameter / 3 * (float)sin(rad180);

		//---- red patch -------------------------------------------------------------------------

		r[8].p[0].x = l[1].p[1].x + diameter / 20 * (float)cos(rad270);
		r[8].p[0].y = l[1].p[1].y + diameter / 20 * (float)sin(rad270);
		r[8].p[1].x = r[8].p[0].x + diameter / 3 * (float)cos(rad180);
		r[8].p[1].y = r[8].p[0].y + diameter / 3 * (float)sin(rad180);
		r[8].p[2].x = r[8].p[1].x + diameter / 10 * (float)cos(rad090);
		r[8].p[2].y = r[8].p[1].y + diameter / 10 * (float)sin(rad090);
		r[8].p[3].x = r[8].p[2].x + diameter / 3 * (float)cos(radDEF);
		r[8].p[3].y = r[8].p[2].y + diameter / 3 * (float)sin(radDEF);

		//---- outer border ----------------------------------------------------------------------

		r[6].p[0].x = r[0].p[2].x;		r[6].p[0].y = r[0].p[2].y;
		r[6].p[1].x = r[2].p[2].x;		r[6].p[1].y = r[2].p[2].y;
		r[6].p[2].x = r[3].p[2].x;		r[6].p[2].y = r[3].p[2].y;
		r[6].p[3].x = r[1].p[3].x;		r[6].p[3].y = r[1].p[3].y;

		//---- small yellow border ---------------------------------------------------------------

		l[2].p[0].x = l[0].p[1].x;		l[2].p[0].y = l[0].p[1].y;
		l[2].p[1].x = r[0].p[3].x;		l[2].p[1].y = r[0].p[3].y;

		//---- small red border ------------------------------------------------------------------

		l[3].p[0].x = l[1].p[1].x;		l[3].p[0].y = l[1].p[1].y;
		l[3].p[1].x = r[3].p[3].x;		l[3].p[1].y = r[3].p[3].y;
	};*/
};

//------------------------------------------------------------------------------------------------
//
//	cursor
//
//	mouse cursor with data
//
//------------------------------------------------------------------------------------------------

struct cursor
{
	int					mouse_index;				//mouse index which data is applied to cursor
	int					active;						//if mouse is active
	ipoint				pos;						//absolute cursor position on screen
	RECT				r_pos;						//absolute cursor position (tip) as RECT

	RECT				r_off;						//area of offscreen surface holding cursor bitmap
	RECT				r_scr;						//area of cursor adjusted to its coordinates on screen
	float				bm_zoom;					//zoomfactor of bitmap cursor

	int					collidable;					//collidable cursor (with other cursor)

	yinyang				yy;							//yinyang mouse cursor symbol
	RGBcolor			cyidef;						//yinyang cursor colors for unpressed and pressed button
	RGBcolor			cyadef;
	RGBcolor			cyiact;
	RGBcolor			cyaact;
	float				yy_size;					//yin yang default size

	RECT				rSCREEN;					//valid screen area

	//---- constructor ----------------------------------------------------------------------------

	cursor()
	{
		mouse_index		= 0;
		active			= 0;
		bm_zoom			= 1.0f;

		collidable		= 0;

		cyidef.setcolor(black);
		cyadef.setcolor(white);
		cyiact.setcolor(red);
		cyaact.setcolor(white);

		yy.ycyi	= cyidef;
		yy.ycya	= cyadef;
		yy_size	= 1.0f;
	};

	//---- toggle cursor --------------------------------------------------------------------------
	//toggle, or switch on/off

	int toggle_cursor(int status = -1)
	{
		//toggle on/off
		if (status == -1)
		{
			active	= !active;
			return(active);
		}

		//off
		if (status == 0)
			active	= 0;
		else
		//on
			active	= 1;

		return(active);
	};

	//---- toggle collidability -------------------------------------------------------------------

	int toggle_collidability(int status = -1)
	{
		//toggle on/off
		if (status == -1)
		{
			collidable	= !collidable;
			return(collidable);
		}

		//off
		if (status == 0)
			collidable	= 0;
		else
		//on
			collidable	= 1;

		return(collidable);
	};

	//---- set_valid_screen -----------------------------------------------------------------------

	void set_valid_screen(RECT _rscr)
	{
		rSCREEN		= _rscr;
	};

	//---- set_offscreen_rect ---------------------------------------------------------------------
	//offscreen surface rect that contains cursor image

	void set_offscreen_rect(int x1, int y1, int x2, int y2)
	{
		r_off.left	= x1;	r_off.right		= x2;
		r_off.top	= y1;	r_off.bottom	= y2;
	};

	//---- set_bm_cursor --------------------------------------------------------------------------
	//offscreen surface rect that contains bitmap cursor image

	void set_bm_cursor(int color = -1)
	{
		//big standard cursor
		if (color < 0)
		{
			r_off.left	= 780;	r_off.right		= 791;
			r_off.top	= 0;	r_off.bottom	= 19;

			return;
		}

		//verify bm color
		if (color > bmfMAX)		color	= bmfMAX;

		//bmfcolor
		//bitmap font surface offsets (same as font)
		ipoint		bmfs_offset[9];
		bmfs_offset[0].x	= 0;		bmfs_offset[0].y	= 0;
		bmfs_offset[1].x	= 256;		bmfs_offset[1].y	= 0;
		bmfs_offset[2].x	= 512;		bmfs_offset[2].y	= 0;
		bmfs_offset[3].x	= 0;		bmfs_offset[3].y	= 128;
		bmfs_offset[4].x	= 256;		bmfs_offset[4].y	= 128;
		bmfs_offset[5].x	= 512;		bmfs_offset[5].y	= 128;
		bmfs_offset[6].x	= 0;		bmfs_offset[6].y	= 255;
		bmfs_offset[7].x	= 256;		bmfs_offset[7].y	= 255;
		bmfs_offset[8].x	= 512;		bmfs_offset[8].y	= 255;

		r_off.left		= 8 * 3 + bmfs_offset[color].x;
		r_off.right		= 8 * 3 + 8 + bmfs_offset[color].x;
		r_off.top		= 0 + bmfs_offset[color].y;
		r_off.bottom	= 0 + 14 + bmfs_offset[color].y;
	};

	//---- set_bmc_zoom ---------------------------------------------------------------------------

	void set_bmc_zoom(float _zoom)
	{
		bm_zoom		= _zoom;
	};

	//---- add_input_data -------------------------------------------------------------------------
	//!! to return point or take parameters as reference and modify them depending on how much
	//of the input data was actually translated on screen due to screen limit?

	void add_input_data(int x, int y)
	{
		pos.x	+= x;
		pos.y	+= y;

		//check for screen boundaries
		check_screen_limit();

		//yy rotation speed equal to mouse movement
		yy.add_speed((x + y) * 1.2f);
	};

	//---- check screen ---------------------------------------------------------------------------

	void check_screen_limit()
	{
		//cursor screen limits
		if (pos.x < rSCREEN.left)		pos.x = rSCREEN.left;
		if (pos.x > rSCREEN.right)		pos.x = rSCREEN.right;
		if (pos.y < rSCREEN.top)		pos.y = rSCREEN.top;
		if (pos.y > rSCREEN.bottom)		pos.y = rSCREEN.bottom;
	};

	//---- set position ---------------------------------------------------------------------------

	void set_pos(int x, int y)
	{
		pos.x	= x;
		pos.y	= y;

		check_screen_limit();
	};

	//---- process --------------------------------------------------------------------------------

	void process(float tsca,							//passed time since last update
				 LONG lX, LONG lY, LONG lZ,				//mouse input
				 BYTE b0, BYTE b1, BYTE b2, BYTE b3)	//buttons
	{
		//movement
		add_input_data(lX, lY);

		//cursortip as RECT
		r_pos.left	= pos.x;	r_pos.right		= pos.x;
		r_pos.top	= pos.y;	r_pos.bottom	= pos.y;

		//calculate onscreen cursor rectangle
//		r_scr.left	= pos.x;	r_scr.right		= (long)(pos.x + (11 * bm_zoom));
//		r_scr.top	= pos.y;	r_scr.bottom	= (long)(pos.y + (19 * bm_zoom));
		r_scr.left	= pos.x;	r_scr.right		= (long)(pos.x + ((r_off.right - r_off.left) * bm_zoom));
		r_scr.top	= pos.y;	r_scr.bottom	= (long)(pos.y + ((r_off.bottom - r_off.top) * bm_zoom));

		//if above threshold speed slowly decrease yy rotating speed
		if (yy.speed > yy.speed_thresh)						yy.add_speed(-yy.speed_dec * tsca);
		if (yy.speed < -yy.speed_thresh)					yy.add_speed(yy.speed_dec * tsca);
		//but increase if slower than threshold
		//in random order for equal rotation direction probability in case of speed == 0
		if (0 + (rand() % (1 - 0 + 1)) == 0)
		{
			//right before left
			if (yy.speed >= 0 && yy.speed < yy.speed_thresh)	yy.add_speed(yy.speed_acc * tsca);
			if (yy.speed <= 0 && yy.speed > -yy.speed_thresh)	yy.add_speed(-yy.speed_acc * tsca);
		}
		else
		{
			//left before right
			if (yy.speed <= 0 && yy.speed > -yy.speed_thresh)	yy.add_speed(-yy.speed_acc * tsca);
			if (yy.speed >= 0 && yy.speed < yy.speed_thresh)	yy.add_speed(yy.speed_acc * tsca);
		}

		//speed limit
/*		//test min speed in random order for equal rotation direction probability in case of speed == 0
		if (0 + (rand() % (1 - 0 + 1)) == 0)
		{
			//right before left
			if (yy.speed >= 0 && yy.speed < yy.speed_min)		yy.set_speed(yy.speed_min);
			if (yy.speed <= 0 && yy.speed > -yy.speed_min)		yy.set_speed(-yy.speed_min);
		}
		else
		{
			//left before right
			if (yy.speed <= 0 && yy.speed > -yy.speed_min)		yy.set_speed(-yy.speed_min);
			if (yy.speed >= 0 && yy.speed < yy.speed_min)		yy.set_speed(yy.speed_min);
		}*/
		//speed limit
		if (yy.speed >= 0 && yy.speed < yy.speed_min)		yy.set_speed(yy.speed_min);
		if (yy.speed <= 0 && yy.speed > -yy.speed_min)		yy.set_speed(-yy.speed_min);
		if (yy.speed > yy.speed_max)				yy.set_speed(yy.speed_max);
		if (yy.speed < -yy.speed_max)				yy.set_speed(-yy.speed_max);

		//on button press
		if (b0 || b1 || b2)
		{
			//active color
			yy.set_colors(cyiact, cyaact);

			//halt rotation
			yy.set_speed(0);

			//yy.set_angle(0);
			//yy.set_size(1.0f);

			//change size with mousewheel
			if (lZ > 0)		yy.size += 0.025f;
			if (lZ < 0)		yy.size -= 0.005f;

			//size limit
			if (yy.size > 2.0f)		yy.size = 2.0f;
			if (yy.size < 0)		yy.size = 0;
		}
		else
		{
			//default color
			yy.set_colors(cyidef, cyadef);
			//reset data
			yy.set_size(yy_size);
		}

		//rotate
		yy.angle	+= yy.speed * tsca;

		//angle limit
		yy.check_angle();

		//set at cursor position
		yy.set_position(pos.x, pos.y);
	};
};

//------------------------------------------------------------------------------------------------
//
//	particle	48 byte
//
//------------------------------------------------------------------------------------------------

struct particle
{
	point			pos;				//position of particle
	point			pos_s;				//position of particle shadow
	point			p_origin;			//starting/gravity point if used as string-fx

	point			vel;				//velocity in pixel per second
	point			acc;				//acceleration in pixel per second�
	float			force;				//force in pixel per second
	float			angle;				//angle of force in degree

	int				lifetime;			//maximum age of particle in milliseconds
	int				age;				//age of particle in milliseconds

	int				uneffect;			//time in milliseconds which particle is uneffected
										//by p_origin gravity when used as string-fx

	//color of particle depends on color mode of particle_heap and often
	//in dependence of age compared to lifetime

	//---- constructor ---------------------------------------------------------------------------

	particle()
	{
		pos.x		= 0;		pos.y		= 0;
		pos_s.x		= 0;		pos_s.y		= 0;
		p_origin.x	= 0;		p_origin.y	= 0;
		vel.x		= 0;		vel.y		= 0;
		acc.x		= 0;		acc.y		= 0;
		force		= 0;		angle		= 0;
		lifetime	= 0;		age			= 0;

		uneffect	= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	particle_heap
//
//	manages particles, used either as font fx or as simple
//	particle system, uses 2 overloaded functions initialize() and update()
//
//------------------------------------------------------------------------------------------------

struct particle_heap
{
	particle		*pp;				//pointer to array of particles
	int				size;				//size of array in particles

	RECT			val_screen;			//valid area to draw particles in (excluding)

	int				state;				//0 = particles uneffected by gravity and
										//particles effected by gravity if .uneffect time reached
										//1 = all particles done, start idle time
										//2 = initialize explosion
										//3 = run explosion
										//4 = explosion done
										//---- simple explosion ----------------------------------
										//(for mode 0, no reemerging)
										//0 = still active particles
										//1 = all particles faded/died out, heap inactive

	LONGLONG		t_freq;				//timer frequency
	LONGLONG		t_start_i;			//start time when all particles reached gravity point
	float			t_idle;				//time for particles to idle when done

	//particle initialization data
	float			gravity;			//constant y-acceleration in pixel per second
										//(centimeter per second, so 981.0f is gravitation of earth)
	point			damper;				//damping velocity factor
										//damper.y should be zero if gravity != 0.0f

	int				tue_min, tue_max;	//time in milliseconds which particle is not effected
										//by p_origin gravity
	int				f_min, f_max;		//force range in pixel per second
	int				a_min, a_max;		//angle range in degree
										//for explosion a_min is the general direction and
										//a_max is the angle around the general direction angle
	int				lt_min, lt_max;		//lifetime range in millisenconds

	//simple explosion data
	point			source;				//source of particles
	int				mode;				//0 = one time particle (default)
										//1 = reemerging from source

	LONGLONG		t_start;			//starting time
	float			t_active;			//active time in seconds (if mode 1, -1 for infinite)

	int				x_tol, y_tol;		//starting position tolerance

	//---- constructor ---------------------------------------------------------------------------

	particle_heap()
	{
		pp				= NULL;
		size			= 0;

		//-1!
		val_screen.left	= 0;	val_screen.right	= WIDTH - 1;
		val_screen.top	= 0;	val_screen.bottom	= HEIGHT - 1;

		state			= 0;

		//t_freq			= 0;
		//get frequency and store it in t_freq
		QueryPerformanceFrequency((LARGE_INTEGER*) &t_freq);
		t_start_i		= 0;	t_idle				= 0;

		gravity			= 0;	damper.x			= 0;		damper.y		= 0;
		tue_min			= 0;	tue_max				= 0;

		f_min			= 0;	f_max				= 0;
		a_min			= 0;	a_max				= 0;
		lt_min			= 0;	lt_max				= 0;

		//
		source.x		= 0;	source.y			= 0;
		mode			= 0;
		t_start			= 0;	t_active			= -1;		//infinite
		x_tol			= 0;	y_tol				= 0;
	};

	//---- destructor ----------------------------------------------------------------------------

	~particle_heap()
	{
		//deletes allocated particle array
		if (pp != NULL)
		{
			//gf_logger(true, "~particle_heap: %i particles", (int)size);
			delete [] pp;
			pp	= NULL;
		}
	};

	//---- initialization ------------------------------------------------------------------------

	void initialization(LONGLONG tfreq,				//timer frequency
						LONGLONG tcurrent,			//current time
						RECT v_screen,				//valid particle area
						int tuemin, int tuemax,		//uneffected time
						float tidle,				//idle time
						float grav,					//constant y-acceleration
						float dampx, float dampy,	//velocity damper
						int fmin, int fmax,			//min, max force (ini, expl)
						int amin, int amax,			//min, max angle (ini, expl)
						int ltmin, int ltmax)		//min, max lifetime (expl)
	{
		//initialize random number generator with current time
		srand((unsigned int)tcurrent);

		//assign timer frequency
		t_freq			= tfreq;

		//assign valid particle screen
		val_screen		= v_screen;

		//gravity and damper
		gravity		= grav;
		damper.x	= dampx;	damper.y	= dampy;

		//force, angle and lifetime
		f_min		= fmin;		f_max		= fmax;
		a_min		= amin;		a_max		= amax;
		lt_min		= ltmin;	lt_max		= ltmax;

		//uneffected time
		tue_min		= tuemin;	tue_max		= tuemax;
		//idle time
		t_idle		= tidle;

		//for every particle
		for (register int i = 0; i < size; ++i)
		{
			//starting position is a random place within valid screen
			//pp[i].pos.x		= val_screen.left + (float)(rand() % (val_screen.right - val_screen.left + 1));
			//pp[i].pos.y		= val_screen.top + (float)(rand() % (val_screen.bottom - val_screen.top + 1));
			pp[i].pos.x			= (float)RANDOM(val_screen.right, val_screen.left);
			pp[i].pos.y			= (float)RANDOM(val_screen.bottom, val_screen.top);

			//assign initial force from f_min to f_max
			pp[i].force		= f_min + (float)(rand() % (f_max - f_min + 1));
			//assign initial angle from a_min to a_max
			pp[i].angle		= a_min + (float)(rand() % (a_max - a_min + 1));
			//initial lifetime is infinite
			pp[i].lifetime	= -1;
			//age is zero
			pp[i].age		= 0;

			//starting acceleration is zero
			pp[i].acc.x		= 0.0f;
			pp[i].acc.y		= 0.0f;

			//uneffected time
			pp[i].uneffect	= tue_min + (rand() % (tue_max - tue_min + 1));

			//------------------------------------------------------------------------------------

			//angle in rad
			double rad		= pp[i].angle / 180 * PI;
			//calculate velocity vector
			pp[i].vel.x		= pp[i].force * (float)cos(rad);
			pp[i].vel.y		= pp[i].force * (float)sin(rad);
		}
	};

	//---- update --------------------------------------------------------------------------------

	void update(LONGLONG t_current,						//current time
				double t_sca)							//time passed since last update in seconds
	{
		//counts particles which reached final position
		int counter			= 0;

		//t_sca�, so it has to be computed only once
		double t_sca2		= t_sca * t_sca;

		//for every particle
		for (register int i = 0; i < size; ++i)
		{
			//increase age
			pp[i].age = pp[i].age + (int)(t_sca * 1000);
			//!! if state soundso age soundso erh�hen

			//new velocity is old velocity plus acceleration times timefactor
			pp[i].vel.x += pp[i].acc.x * (float)t_sca;
			pp[i].vel.y += pp[i].acc.y * (float)t_sca;

			//calculate new position in dependence of current position,
			//current velocity and passed time
			pp[i].pos.x = pp[i].pos.x + pp[i].vel.x * (float)t_sca + 0.5f * pp[i].acc.x * (float)t_sca2;
			pp[i].pos.y = pp[i].pos.y + pp[i].vel.y * (float)t_sca + 0.5f * pp[i].acc.y * (float)t_sca2;

			//assign air-drag for terminal velocity
			//and damper values
			//(damper.y should be 0 if gravity != 0)
			pp[i].acc.y = gravity - pp[i].vel.y / 4.0f;
			pp[i].vel.x += -pp[i].vel.x * damper.x * (float)t_sca;
			pp[i].vel.y += -pp[i].vel.y * damper.y * (float)t_sca;

			//------------------------------------------------------------------------------------

			//if state is 0 and particle age is bigger than its uneffected time plus 750
			if (state == 0 && pp[i].age > pp[i].uneffect + 750)
			{
				//gravity of destination point (p_origin) depends on distance between
				//current position and p_origin

				//calculate absolute differences
				float diffx		= (float)fabs(pp[i].pos.x - pp[i].p_origin.x);
				float diffy		= (float)fabs(pp[i].pos.y - pp[i].p_origin.y);
				float sumdxdy	= diffx + diffy;

				float grav = 80000.0f / ((diffx + diffy) / 2 + 1.0f);

				//calculate new gravity vector
				//vgx = (vg / (xd + yd)) * xd
				//vgy = (vg / (xd + yd)) * yd
				//gravitation vector x/y is (entire gravity divided by
				//(difference of x-current and x-target) plus (difference of y-current and y-target))
				//times (difference of x/y-current and x/y-target)

				//no dividing through 0
				if (sumdxdy != 0)
				{
					pp[i].acc.x = (grav / sumdxdy) * diffx;
					pp[i].acc.y = (grav / sumdxdy) * diffy;
				}
				else
				{
					pp[i].acc.x = 0;	pp[i].acc.y = 0;
				}

				//if within 100 pixels, reduce accerlation to 600.0f
				if (diffx < 100 && diffy < 100)
				{
					pp[i].acc.x = 600.0f;	pp[i].acc.y = 600.0f;

					//if within 2 pixels and velocity below 10pps, set particle to p_origin
					if (diffx < 2 && diffy < 2 &&
						pp[i].vel.x < 10 && pp[i].vel.y < 10)
					{
						pp[i].pos.x = pp[i].p_origin.x;
						pp[i].pos.y = pp[i].p_origin.y;
					}
				}

				//since we were working with absolute numbers (fabs) reverse acceleration
				//if current position is bigger than target position
				if (pp[i].pos.x > pp[i].p_origin.x)
					pp[i].acc.x = -pp[i].acc.x;
				if (pp[i].pos.y > pp[i].p_origin.y)
					pp[i].acc.y = -pp[i].acc.y;

				//if rounded position is at target point, set accerleration to zero
				//and decrease velocity by third
				if ((int)pp[i].pos.x == pp[i].p_origin.x &&
					(int)pp[i].pos.y == pp[i].p_origin.y)
				{
					pp[i].vel.x *= 0.2f;	pp[i].vel.y *= 0.2f;
					pp[i].acc.x = 0.0f;		pp[i].acc.y = 0.0f;
				}

				//if particle at p_origin and velocity zero
				//count particle as done
				if ((int)pp[i].pos.x == pp[i].p_origin.x &&
					(int)pp[i].pos.y == pp[i].p_origin.y &&
					pp[i].vel.x == 0.0f &&
					pp[i].vel.y == 0.0f)
					++counter;

				//if all particles set and not already above state 0, set state to 1
				if (counter == size && state == 0)
					state = 1;
			}

			//clipping
			//if particle is out of bounds, his age becomes -1 and it won't be drawn, reset
			pp[i].pos.x < val_screen.left		? pp[i].age = -1 : pp[i].pos.x;
			pp[i].pos.x > val_screen.right		? pp[i].age = -1 : pp[i].pos.x;
			pp[i].pos.y < val_screen.top		? pp[i].age = -1 : pp[i].pos.y;
			pp[i].pos.y > val_screen.bottom		? pp[i].age = -1 : pp[i].pos.y;

			//---- reset -------------------------------------------------------------------------

			//if age -1 which means particle is out of bounds
			//or age is bigger than lifetime while lifetime is not infinite,
			//reset particle
//!!!
//			if (pp[i].age == -1 ||
//				(pp[i].age > pp[i].lifetime && pp[i].lifetime != -1))
			if (pp[i].age == -1 ||
				(pp[i].age > pp[i].lifetime && pp[i].lifetime != -1) &&
				state < 3)
			{
				//reset age
				pp[i].age			= 0;

				//starting position is a random place within valid screen
				//pp[i].pos.x		= val_screen.left + (float)(rand() % (val_screen.right - val_screen.left + 1));
				//pp[i].pos.y		= val_screen.top + (float)(rand() % (val_screen.bottom - val_screen.top + 1));
				pp[i].pos.x			= (float)RANDOM(val_screen.right, val_screen.left);
				pp[i].pos.y			= (float)RANDOM(val_screen.bottom, val_screen.top);

				//assign initial force from f_min to f_max
				pp[i].force		= f_min + (float)(rand() % (f_max - f_min + 1));
				//assign initial angle from a_min to a_max
				pp[i].angle		= a_min + (float)(rand() % (a_max - a_min + 1));
				//lifetime is still 1
				//pp[i].lifetime	= lt_min + (rand() % (lt_max - lt_min + 1));

				//starting acceleration is zero
				pp[i].acc.x		= 0.0f;
				pp[i].acc.y		= 0.0f;

				//uneffected time stays the same
				pp[i].uneffect		= 750;
				//pp[i].uneffect	= tue_min + (rand() % (tue_max - tue_min + 1));

				//angle in rad
				double rad		= pp[i].angle / 180 * PI;
				//calculate velocity vector
				pp[i].vel.x		= pp[i].force * (float)cos(rad);
				pp[i].vel.y		= pp[i].force * (float)sin(rad);
			}

			//---- idling, exploding -------------------------------------------------------------

			//if all particles settled set idle start time and increase state
			if (state == 1)
			{
				t_start_i = t_current;
				state = 2;
			}

			//if state is after idle-ini and
			//current time is bigger then time passed since start idling
			if (state == 2 && t_current > t_start_i + (t_freq * t_idle))
			{
				//increase state
				state = 3;

				//initialize every particle for explosion
				for (register int i = 0; i < size; ++i)
				{
					//assign initial force from f_min to f_max
					pp[i].force		= 20 + (float)(rand() % (180 - 20 + 1));
					//assign initial angle from a_min to a_max
					pp[i].angle		= a_min + (float)(rand() % (a_max - a_min + 1));
					//lifetime is still -1 (infinite)
					//pp[i].lifetime	= lt_min + (rand() % (lt_max - lt_min + 1));

					//starting acceleration is zero
					pp[i].acc.x		= 0.0f;		pp[i].acc.y		= 0.0f;

					//uneffected time set to zero
					pp[i].uneffect	= 0;

					//set age to random number so they won't fade out all at the same time
//!!!
					pp[i].age		= 0 + (rand() % (1500 - 0 + 1));
//pp[i].age = 0;
//pp[i].lifetime = lt_min + (rand() % (lt_max - lt_min + 1));

					//angle in rad
					double rad		= pp[i].angle / 180 * PI;
					//calculate velocity vector
					pp[i].vel.x		= pp[i].force * (float)cos(rad);
					pp[i].vel.y		= pp[i].force * (float)sin(rad);
				}
			}

			//if in explosion and time since start is bigger than idle time plus
			//4 seconds, set state to 4 (done)
			if (state == 3 && t_current > t_start_i + (t_freq * (t_idle + 4)))
				state = 4;
		}
	};

	//---- simple explosion ----------------------------------------------------------------------

	//---- create_heap ---------------------------------------------------------------------------

	void create_heap(int psize,						//number of particles
					 RECT v_screen)					//valid particle area
	{
		//check if array already exists
		if (pp != NULL)
		{
			//delete allocated memory, set pp to NULL and size to 0
			delete		[] pp;
			pp			= NULL;
			size		= 0;
		}

		//check (new) size for validity
		if (psize < 1 || psize > 20000)
		{
			gf_logger(true, "particle_heap::create_heap() wrong psize (%i)", psize);
			psize		= 10;
		}

		//number of particles is psize
		size			= psize;

		//allocate particle array in size of size
		pp				= new particle[size];

		//get time and store it in current
		//initialize random number generator with current time
		//LONGLONG t;
		//QueryPerformanceCounter((LARGE_INTEGER*) &t);
		//srand((unsigned int)t);

		//assign timer frequency
		//t_freq			= tfreq;

		//assign valid particle screen
		val_screen		= v_screen;

		return;
	};

	//---- initialization ------------------------------------------------------------------------
	//overloaded

	void initialization(LONGLONG tcurrent,			//current time
						int md,						//mode 0 = no reemerging, 1 = reemerging
						float tactive,				//active time in seconds if mode is 1
						int posx, int posy,			//source of particles
						int xtol, int ytol,			//position tolerance from starting point
						float grav,					//constant y-acceleration
						float dampx, float dampy,	//velocity damper
						int fmin, int fmax,			//min, max force (ini, expl)
						int amin, int amax,			//min, max angle (ini, expl)
						int ltmin, int ltmax,		//min, max lifetime (expl)
						float s_speed = 1.0f)		//user defined speed factor
	{
		//reset state
		state		= 0;

		//assign start time
		t_start		= tcurrent;

		//mode, active time
		mode		= md;
		t_active	= tactive;
		//adjust for user speed
		t_active	= t_active / s_speed;

		//source of particles, position tolerance
		source.x	= (float)posx;		source.y	= (float)posy;
		x_tol		= xtol;				y_tol		= ytol;

		//gravity and damper
		gravity		= grav;
		damper.x	= dampx;	damper.y	= dampy;

		//force, angle and lifetime
		f_min		= fmin;		f_max		= fmax;
		a_min		= amin;		a_max		= amax;
		lt_min		= ltmin;	lt_max		= ltmax;

		//check angle for boundary
		if (a_min > 359)			a_min -= 360;
		if (a_min < 0)				a_min += 360;
		if (a_max > 359)			a_max -= 360;
		if (a_max < 0)				a_max += 360;

		//for every particle
		for (register int i = 0; i < size; ++i)
		{
			//starting position is source plus tolerance (which counts in positive and
			//negative direction)
			pp[i].pos.x		= source.x + (-x_tol) + (float)(rand() % (x_tol - (-x_tol) + 1));
			pp[i].pos.y		= source.y + (-y_tol) + (float)(rand() % (y_tol - (-y_tol) + 1));

			//assign initial force from f_min to f_max
			pp[i].force		= f_min + (float)(rand() % (f_max - f_min + 1));
			//assign initial angle
			//a_min is general direction angle
			//a_max is angle left/right of direction angle
			pp[i].angle		= (a_min - a_max) + (float)(rand() % ((a_min + a_max) - (a_min - a_max) + 1));
			//initial lifetime
			pp[i].lifetime	= lt_min + (rand() % (lt_max - lt_min + 1));
			//adjust lifetime for user set speed
			pp[i].lifetime	= (int)(pp[i].lifetime / s_speed);

			//if t_active time is bigger than zero, the first batch of particles
			//has an increased age so that the delay for the second batch won't be as big
			if (t_active > 0)
				pp[i].age	= (int)(pp[i].lifetime * 0.75) + (rand() % (pp[i].lifetime - ((int)(pp[i].lifetime * 0.75))) + 1);
			else
				pp[i].age	= 0;

			//starting acceleration
			pp[i].acc.x		= 0.0f;
			pp[i].acc.y		= gravity;

			//uneffected time unused, remains zero (particle constructor)
			//pp[i].uneffect	= 0;

			//------------------------------------------------------------------------------------

			//angle in rad
			double rad		= pp[i].angle / 180 * PI;
			//calculate velocity vector
			pp[i].vel.x		= pp[i].force * (float)cos(rad);
			pp[i].vel.y		= pp[i].force * (float)sin(rad);
		}
	};

	//---- update --------------------------------------------------------------------------------
	//also overloaded

	void update(LONGLONG t_current,						//current time
				double t_sca,							//time passed since last update in seconds
				float s_speed,							//user defined speed factor
				int shadows, int s_mpy, point s_scale,	//shadows on/off, y-coordinate and scale of shadow
				int posx, int posy,						//source of particles (if changed)
				int amin, int amax,						//min, max angle (ini, expl)
				bool bottom = false)					//if bottom of valid screen used as bottom
														//(particles stay there until fade away)
	{
		//if all particles faded/died out, so set particle heap is inactive, return
		if (state == 1)
			return;

		//assign new position if necessary
		source.x			= (float)posx;
		source.y			= (float)posy;

		//assign new angle
		a_min		= amin;		a_max		= amax;
		//check angle for boundary
		if (a_min > 359)			a_min -= 360;
		if (a_min < 0)				a_min += 360;
		if (a_max > 359)			a_max -= 360;
		if (a_max < 0)				a_max += 360;

		//if reemerging mode
		if (mode == 1)
		{
			//calculate time passed since starting heap
			double t_passed = (t_current - t_start) / double(t_freq);

			//if time passed is bigger than active time set mode to 0 (no more reemerging)
			//and t_active is bigger than 0 (-1 = infinite)
			if (t_active > 0)
				if (t_passed > t_active)
					mode = 0;
		}

		//counts particles which faded/died out
		int counter			= 0;

		//t_sca�, so it has to be computed only once
		double t_sca2		= t_sca * t_sca;

		//for every particle
		for (register int i = 0; i < size; ++i)
		{
			//increase age by time passed
			//(t_sca is in seconds, 0.01 sec means 10 ms, since age is in ms)
			//pp[i].age = pp[i].age + (int)(t_sca * 1000 * s_speed);
			pp[i].age = pp[i].age + (int)(t_sca * 1000);

			//new velocity is old velocity plus acceleration times timefactor
			pp[i].vel.x += pp[i].acc.x * (float)t_sca * s_speed;
			pp[i].vel.y += pp[i].acc.y * (float)t_sca * s_speed;

			//calculate new position in dependence of current position,
			//current velocity and passed time
			pp[i].pos.x = pp[i].pos.x + pp[i].vel.x * (float)t_sca * s_speed + 0.5f * pp[i].acc.x * (float)t_sca2 * s_speed;
			pp[i].pos.y = pp[i].pos.y + pp[i].vel.y * (float)t_sca * s_speed + 0.5f * pp[i].acc.y * (float)t_sca2 * s_speed;

			//assign air-drag for terminal velocity
			//and damper values
			//(damper.y should be 0 if gravity != 0)
			pp[i].acc.y = gravity - pp[i].vel.y / 4.0f;
			pp[i].vel.x += -pp[i].vel.x * damper.x * (float)t_sca * s_speed;
			pp[i].vel.y += -pp[i].vel.y * damper.y * (float)t_sca * s_speed;

			//clipping
			//if particle is out of bounds, his age becomes -1 and it won't be drawn, reset
			pp[i].pos.x < val_screen.left		? pp[i].age = -1 : pp[i].pos.x;
			pp[i].pos.x > val_screen.right		? pp[i].age = -1 : pp[i].pos.x;
			pp[i].pos.y < val_screen.top		? pp[i].age = -1 : pp[i].pos.y;

			//if bottom activated, particles stay on lower valid screen coordinates
			//until they fade out, otherwise they get deleted when leaving valid screen
			if (bottom)
			{
				if (pp[i].pos.y >= val_screen.bottom)
				{
					//stop velocity
					pp[i].vel.x	= pp[i].vel.y = 0;
					//set y to bottom
					pp[i].pos.y	= (float)val_screen.bottom;
				}
			}
			else
			{
				pp[i].pos.y > val_screen.bottom - 1	? pp[i].age = -1 : pp[i].pos.y;
			}

			//---- reset -------------------------------------------------------------------------

			//if age exceeds lifetime or is -1, which means its out of bounds and
			//mode = 1 (reemerging) and particle heap time doesn't exceed active time (checked above)
			//reset particle else count it as faded/died out
			if (pp[i].age > pp[i].lifetime || pp[i].age == -1)
			{
				if (mode == 1)
				{
					//reset age
					pp[i].age			= 0;

					//position is source plus tolerance (which is positive and negative)
					pp[i].pos.x		= source.x + (-x_tol) + (float)(rand() % (x_tol - (-x_tol) + 1));
					pp[i].pos.y		= source.y + (-y_tol) + (float)(rand() % (y_tol - (-y_tol) + 1));

					//force range
					pp[i].force		= f_min + (float)(rand() % (f_max - f_min + 1));
					//angle
					pp[i].angle		= (a_min - a_max) + (float)(rand() % ((a_min + a_max) - (a_min - a_max) + 1));
					//lifetime
					pp[i].lifetime	= lt_min + (rand() % (lt_max - lt_min + 1));
					//adjust lifetime for user set speed
					pp[i].lifetime	= (int)(pp[i].lifetime / s_speed);

					//starting acceleration
					pp[i].acc.x		= 0.0f;
					pp[i].acc.y		= gravity;

					//--------------------------------------------------------------------------------

					//angle in rad
					double rad		= pp[i].angle / 180 * PI;
					//calculate velocity vector
					pp[i].vel.x		= pp[i].force * (float)cos(rad);
					pp[i].vel.y		= pp[i].force * (float)sin(rad);
				}
				else
				{
					//increase inactive particle counter
					++counter;

					//deactivate heap if all particles faded/died out
					if (counter == size)
						state = 1;
				}
			}

			//calculate particle shadows if shadows on
			if (shadows == 1)
			{
				pp[i].pos_s.y	= s_mpy + (s_mpy - pp[i].pos.y) * s_scale.y;
				pp[i].pos_s.x	= pp[i].pos.x + s_scale.x * (float)fabs(pp[i].pos.y - pp[i].pos_s.y);
			}
		}
	};
};

//------------------------------------------------------------------------------------------------
//
//	timer
//
//------------------------------------------------------------------------------------------------

struct timer
{
	LONGLONG		freq;				//timer frequency in ticks per second
	LONGLONG		current;			//current time
	LONGLONG		last;				//time stamp last time checked
	LONGLONG		last_max;			//time stamp used for fps_max
	LONGLONG		last_fps;			//time stamp of last fps update
	LONGLONG		last_sec;			//time stamp for second update
	LONGLONG		difference;			//difference between current and last time stamp
	double			sca;				//percentage of a second passed since last update

	int				framerate;			//framerate of application
	int				fps;				//same as framerate, but updatet only every second
	int				fps_max;			//maximum framerate
	__int32			frames_total;		//frames since application started
										//4byte is enough for more than 1000 hours playtime at 1000fps
										//(gets reset after that)

	int				ch, cm, cs;			//current hours, minutes, seconds
	float			chf, cmf;			//current hours and minutes in float for floating
										//point precision of hours and minutes

	LONGLONG		t_program_start;	//time index of program start
	int				ph, pm, ps;			//program hours, minutes, seconds
	char			cptime[9];			//program time as string

	int				ticker;				//changes value every tick(th) time
	LONGLONG		tick_last_update;	//time stamp for last tick update

	//---- constructor ---------------------------------------------------------------------------

	//queries get_timerfreq()
	timer()
	{
		//reset all values

		freq				= 0;
		current				= 0;	last		= 0;
		last_max			= 0;	last_fps	= 0;		last_sec	= 0;
		difference			= 0;	sca			= 0;

		framerate			= 0;	fps			= 0;
		frames_total		= 0;

		ch = cm = cs		= 0;
		chf = cmf			= 0;

		//gets changed in mf-constructor anyway
		fps_max				= 100;

		t_program_start		= 0;
		ph = pm = ps		= 0;
		//cptime[0]			= 0;
		//strcpy(cptime, "xx:xx:xx");
		strcpy(cptime, "NO:TS:ET");

		ticker				= 0;
		tick_last_update	= 0;

		get_timerfreq();
	};

	//---- get_timerfreq -------------------------------------------------------------------------

	void get_timerfreq()
	{
		//get frequency and store it in freq
		QueryPerformanceFrequency((LARGE_INTEGER*) &freq);
	};

	//---- set_fps_max ---------------------------------------------------------------------------

	void set_fps_max(int fmax)
	{
		if (fmax < 30 && fmax != 0)
			fps_max = 30;
		else
			fps_max = fmax;
	};

	//---- set_program_starttime -----------------------------------------------------------------

	void set_program_starttime()
	{
		//get time and store it in current
		QueryPerformanceCounter((LARGE_INTEGER*) &t_program_start);
	};

	//---- get_program_time ----------------------------------------------------------------------

	void get_program_time()
	{
		//reset
		ph = pm = ps = 0;
		cptime[0] = 0;

		//time difference since start in seconds
		long time_in_seconds	= (long)((current - t_program_start) / (float)freq);

		//extract hours, minuts and seconds
		while(time_in_seconds > 59)
		{
			time_in_seconds -= 60;
			++pm;

			if (pm > 59)
			{
				++ph;
				pm = 0;
			}

			if (ph > 23)
			{
				ph = 0;
			}
		}
		ps	= time_in_seconds;

		//create time string
		char nstring[3] = "";

		_itoa(ph, nstring, 10);
		if (ph < 10)			strcat(cptime, "0");
		strcat(cptime, nstring);
		strcat(cptime, ":");
		_itoa(pm, nstring, 10);
		if (pm < 10)			strcat(cptime, "0");
		strcat(cptime, nstring);
		strcat(cptime, ":");
		_itoa(ps, nstring, 10);
		if (ps < 10)			strcat(cptime, "0");
		strcat(cptime, nstring);
	};

	//---- set_starttime -------------------------------------------------------------------------

	void set_starttime()
	{
		//reset
		ch = cm = cs = 0;

		//holds time
		_timeb		timebuffer;

		//get time
		_ftime(&timebuffer);

		//s holds time in seconds since (00:00:00), january 1, 1970
		long time_in_seconds	= timebuffer.time;

		//add time zone
		time_in_seconds			-= 60 * timebuffer.timezone;

		//extract hours, minuts and seconds
		while(time_in_seconds > 59)
		{
			time_in_seconds -= 60;
			++cm;

			if (cm > 59)
			{
				++ch;
				cm = 0;
			}

			if (ch > 23)
			{
				ch = 0;
			}
		}
		cs	= time_in_seconds;
	};

	//---- set_time ------------------------------------------------------------------------------

	void set_time()
	{
		//update seconds
		if (current >= last_sec + freq)
		{
			//set last second time stamp to current time stamp
			last_sec = current;
			++cs;

			//extract hours, minutes and seconds
			while(cs > 59)
			{
				cs -= 60;
				++cm;

				if (cm > 59)
				{
					++ch;
					cm = 0;
				}

				if (ch > 23)
				{
					ch = 0;
				}
			}
		}
	};
	
	//---- get_timer -----------------------------------------------------------------------------

	void get_timer()
	{
		//get time and store it in current
		QueryPerformanceCounter((LARGE_INTEGER*) &current);

		//calculate time difference
		difference = current - last;

		//sca is the time in seconds passed since last frame
		//(like 0.1 second passed)

		//if fps_max is not infinite
		if (fps_max != 0)
			//if difference between user set fps_max and actual fps of last second is
			//equal/smaller than 10% of fps_max
			if (fps_max - fps <= fps_max * 0.1)
				//get a smooth movement by using a steady scale
				sca = 1.0f / fps_max;
			else
				//else calculate the actual scale using the time difference between
				//current and last frame
				sca = difference / (double)freq;
		else
			//else calculate the actual scale
			sca = difference / (double)freq;

		//!!
		//make sure time difference sca doesn't exceed a fixed limit which
		//could happen if there's a lag
		//fixed value is adjusted to minimum fps
		if (sca >= 0.035f)
			sca = 0.035f;
	};

	//---- get_framerate -------------------------------------------------------------------------

	void get_framerate()
	{
		//update fps counter every fps_update-th second
		float fps_update	= 0.5f;

		//if time passed is less than one second
		if (current < last_fps + freq * fps_update)
		{
			//increase framerate counter
			++framerate;
		}
		else
		{
			//assign fps, so that it's only updatet every fps_update-th second
//			fps			= (int)(framerate * (1.0f / fps_update));
			//estimate framerate from time passed since last frame
			fps			= (int)(1.0 / sca);

			//reset framerate
			framerate	= 0;

			//set last fps update time stamp to current time stamp
			last_fps	= current;
		}

		//---- idle at fps_max -------------------------------------------------------------------

		//if fps_max is not unlimited (0)
		if (fps_max != 0)
			//while time passed since last check is less then
			//last check + (1 second / fps_max)
			//which means the time passed since the last check
			//is less then 1 / fps_max second
			while (current < last_max + (freq / fps_max))
				//its ok that get_timer() updates current several times in this loop
				//because the timer-object itself is updated in the beginning of the
				//main loop
				get_timer();

		//fps_max check stamp is current time stamp
		last_max = current;
	};

	//---- get_tfr -------------------------------------------------------------------------------

	//do both, get timer and framerate (for convenience)
	void get_tfr()
	{
		//set last checked time stamp to current time stamp
		//this is not in get_timer() because this function is
		//called by get_framerate() to idle for fps_max
		last = current;

		get_timer();
		//
		get_framerate();

		//update hours, minutes, seconds
		set_time();

		//update floating point precision hours and minutes
		cmf		= (float)cm + (float)cs * 1 / 60;
		chf		= (float)ch + cmf * 1 / 60;

		//update total application frames
		++frames_total;
	};

	//---- tick -----------------------------------------------------------------------------------
	//sets variable ticker every argumented-th time (in seconds) to 0 or 1

	int tick(float tick_freq = 1.0f)
	{
		if (current >= tick_last_update + freq * tick_freq)
		{
			tick_last_update	= current;
			ticker = !ticker;
		}

		return(ticker);
	};
};

//------------------------------------------------------------------------------------------------
//
//	optionscore
//
//------------------------------------------------------------------------------------------------

struct optionscore
{
	//---- general options -----------------------------------------------------------------------

	int			sound;						//sound on/off
	int			volume;						//program main volume, 0 - -10.000

//	CLASS_CON_VAR(int, screenmode);			//fullscreen or windowed mode
	int			screenmode;
	CLASS_CON_VAR(int, vsync);				//vsync
	int			fps_max;					//maximum framerate, 0 = infinite
	CLASS_CON_VAR(int, show_fps);			//in the top left corner
	CLASS_CON_VAR(int, subframes);			//subframes per frame (1 means one frame with no subframe)

	CLASS_CON_VAR(int, shadows);			//shadows
	CLASS_CON_VAR(int, mblur);				//every th frame, 0 = off
	CLASS_CON_VAR(int, bw_mode);			//black and white mode (ingame)
	CLASS_CON_VAR(RGBcolor, cbackground);	//background color (ingame)

	CLASS_CON_VAR(int, hud_text);			//hud text on/off
	CLASS_CON_VAR(float, hud_text_time);	//time in seconds hud text stays on screeen
	CLASS_CON_VAR(int, show_lockstate);		//shows lockstate on bones
	CLASS_CON_VAR(int, show_hitbox);		//shows hitboxes
	CLASS_CON_VAR(int, show_damage);		//shows taken damage as player message
	CLASS_CON_VAR(int, show_scores);		//shows scores
	CLASS_CON_VAR(int, show_pmessages);		//shows state playermessages (power punch, etc.)

	CLASS_CON_VAR(int, rounds);				//rounds to be played
	CLASS_CON_VAR(int, roundtime);			//round time in seconds, 0 = off
	CLASS_CON_VAR(float, speed);			//game speed percentage
	int			ko_mode;					//ko mode, defined
	//CLASS_CON_VAR(int, ko_mode);			//ko mode, defined
	CLASS_CON_VAR(int, ko_limit);			//min damage for knockout attack
	CLASS_CON_VAR(int, ko_instant);			//damage for instant knockout, 0 = off
	CLASS_CON_VAR(int, digidamage);			//digital or analog damage
	int			fight_mode;					//fight mode, defined
	//CLASS_CON_VAR(int, fight_mode);			//0 = standard
											//1 = boxing only
											//2 = kicking only
	CLASS_CON_VAR(int, score_mode);			//score mode, 0 = simple, 1 = damage depending
	CLASS_CON_VAR(int, condition_masking);	//to hide damage and fatigue status
											//0 = off
											//1 = opponent only
											//2 = both
	CLASS_CON_VAR(int, randomstart);		//0 = player 1 starts always left
											//1 = randomly placed at round start

	CLASS_CON_VAR(int, demo_rec);			//auto demo recording
	CLASS_CON_VAR(int, demo_maxfiles);		//maximum number of demo files before overwriting existing files
	CLASS_CON_VAR(int, demo_maxlength);		//maximum recording time in seconds

	int			dam_handicap_p1[NODS];		//handicap for each damage slot
	int			dam_handicap_p2[NODS];		//(pre damage 0 to 100)
	float		fat_handicap[2];			//fatigue handicap
											//percentage of fatigue regeneration speed

	CLASS_CON_VAR(float, damage_multiplier);
	CLASS_CON_VAR(int, dam_transfer);		//to transfer damage to next damage slot
											//if damage exceeding limits
	CLASS_CON_VAR(float, fom_multiplier);	//fatigue-o-meter multiplier
	CLASS_CON_VAR(float, fat_delay);		//fatigue delay in seconds when no fatigue
	CLASS_CON_VAR(int, fat_dam);			//fatigue damage if max fatigue
	CLASS_CON_VAR(int, fat_damage);			//damage in units per second

	CLASS_CON_VAR(float, t_combo);			//time in seconds between two hits to count as combo
	CLASS_CON_VAR(float, combo_multiplier);	//damage multiplier for each combo hit

	CLASS_CON_VAR_A(float, sensitivity, 2);	//mouse sensitivity for both players
											//draws user input angles towards 0/180 degrees
											//the higher the sensitivity
	CLASS_CON_VAR_A(int, crad, 2);			//forward and backward mouse radius
//	CLASS_CON_VAR_A(int, mrad_fwd, 2);		//forward and backward mouse radius
//	CLASS_CON_VAR_A(int, mrad_bwd, 2);		//holding difference between short and long action
//	CLASS_CON_VAR_A(int, defense_mode, 2);	//defense mode for both players
	int			defense_mode[2];			//defense mode for both players

	CLASS_CON_VAR_A(float, t_defbuffer, 2);	//time in seconds after button down defense (dm_sim) is activated
											//also time after mouse movement started short/long test is applied
	CLASS_CON_VAR(float, t_lockdef);		//time in seconds defense lock lasts
	CLASS_CON_VAR(float, t_lockoff);		//time in seconds offense lock lasts
	CLASS_CON_VAR(float, tapdamratio);		//tap damage ratio, percentage of damage attacker takes of own attack
											//when blocked

	CLASS_CON_VAR(int, bot_ticks);			//bot updates per second

	CLASS_CON_VAR(bool, pal);				//PAL mode (green blood)
	CLASS_CON_VAR(int, cd_state);			//shows cd state
	CLASS_CON_VAR(int, r_hollow);			//render bone frame only

	CLASS_CON_VAR(float, zoomfactor);		//zoomfactor for game
	CLASS_CON_VAR(int, hitstop);			//time in milliseconds to stop animation when hit
											////to advance animations when hitting opponent

	//---- system data ---------------------------------------------------------------------------

	BYTE		sys_first;					//indicates if no config file was available so
											//program may be started the first time (for
											//specific start sequence)

	int			mouseflag;					//indicates if two mice available, only internal use
	int			controllerflag;				//number of controllers available

	//---- player options ------------------------------------------------------------------------

	char		name[2][21];					//name for both players
	con_var_t	name1_convar;
	con_var_t	name2_convar;

	CLASS_CON_VAR_A(RGBcolor, fistcolor, 2);	//fistcolor for both players

	//---- controls ------------------------------------------------------------------------------

	int				CBT[256];					//command binding table, defined
												//-1 = unbound
												//0 - 255 di scan line keyboard keys
												//300 - 303 mouse 1 buttons
												//305 and 306 mouse 1 wheel up and down
												//400 - 403 mouse 2 buttons
												//405 and 406 mouse 2 wheel up and down
												//500 - 531 controller 1 buttons
												//600 - 631 controller 2 buttons
												//
												//analog/digital move input depending on
												//inputdevice

	int				CBT_LOCK[256];				//locked command table
	int				KEY_LOCK[700];				//holds locked keys (including mouse, controller devices)

	int				inputdevice[2];				//inputdevice for player 1 and 2
												//0 = mouse 1
												//1 = mouse 2
												//2 = controller 1 digital
												//3 = controller 1 analog
												//4 = controller 2 digital
												//5 = controller 2 analog

	int				player_mouse[2];			//mouse for player 1 and 2
												//index of available RI mouse to use

/*	int				ckey[2][6];					//player commands, [P1/P2][PKDLRS] see define

	BYTE			cpause, cexit, cvsync, cshadows, cmblurup, cmblurdown,
					cbw_mode, cspeedup, cspeeddown, csound,
					cdamup, cdamdown, cfatup, cfatdown, cscreenshot;*/

	//---- console data --------------------------------------------------------------------------

	CLASS_CON_VAR(RGBcolor, con_color);						//console color
	CLASS_CON_VAR(RGBcolor, con_fcolor);					//console frame color
	CLASS_CON_VAR(int, con_textcolor);						//console text color, #defined
	CLASS_CON_VAR(int, con_frame);							//frame on or off
	CLASS_CON_VAR(int, con_dropspeed);						//console move speed in pixel per second
															//0 = instantly
	CLASS_CON_VAR(int, con_style);							//0 = move from above
															//1 = move from left
	CLASS_CON_VAR(RECT, con_dim);							//console dimensions

	//---- constructor ---------------------------------------------------------------------------

	optionscore()
	{
		//!!
		ZeroMemory(&CBT, sizeof(CBT));
		ZeroMemory(&CBT_LOCK, sizeof(CBT_LOCK));
		ZeroMemory(&KEY_LOCK, sizeof(KEY_LOCK));

		//empty names
		ZeroMemory(name[P1], sizeof(name[P1]));
		ZeroMemory(name[P2], sizeof(name[P2]));
	};

	//---- RegisterConVars -----------------------------------------------------------------------

	//registers console variable
	//type, name, min, max, flags
	void RegisterConVars(console *pcon)
	{
//		CLASS_CVIMM(int, screenmode, 0, 1, 0);
		CLASS_CVIMM(int, vsync, 0, 1, 0);
		CLASS_CVIMM(int, show_fps, 0, 1, 0);
		CLASS_CVIMM(int, subframes, 1, 200, 0);

		CLASS_CVIMM(int, shadows, 0, 1, 0);
		CLASS_CVIMM(int, mblur, 0, 20, 0);
		CLASS_CVIMM(int, bw_mode, 0, 1, 0);
		CLASS_CVIMM(RGBcolor, cbackground, black, white, 0);

		CLASS_CVIMM(int, hud_text, 0, 1, 0);
		CLASS_CVIMM(float, hud_text_time, 0, 10.0f, 0);
		CLASS_CVIMM(int, show_lockstate, 0, 1, 0);
		CLASS_CVIMM(int, show_hitbox, 0, 1, 0);
		CLASS_CVIMM(int, show_damage, 0, 1, 0);
		CLASS_CVIMM(int, show_scores, 0, 1, CONVARF_RESTRICTED);
		CLASS_CVIMM(int, show_pmessages, 0, 1, 0);

		CLASS_CVIMM(int, rounds, 1, 4, 0);
		CLASS_CVIMM(int, roundtime, 0, 5999, 0);
//!!		CLASS_CVIMM(float, speed, 0.1f, 3.0f, 0);
		CLASS_CVIMM(float, speed, 0.001f, 10.0f, 0);
		//CLASS_CVIMM(int, ko_mode, KOM_HEAD, 14, 0);
		//CLASS_CVIMM(int, fight_mode, 0, 2, 0);
		CLASS_CVIMM(int, ko_limit, 0, 100, 0);
		CLASS_CVIMM(int, ko_instant, 0, 1000, 0);
		CLASS_CVIMM(int, digidamage, 0, 1, 0);
		CLASS_CVIMM(int, score_mode, 0, 1, 0);
		CLASS_CVIMM(int, condition_masking, 0, 2, 0);
		CLASS_CVIMM(int, randomstart, 0, 1, 0);

		CLASS_CVIMM(int, demo_rec, 0, 1, 0);
		CLASS_CVIMM(int, demo_maxfiles, 0, 99, 0);
		CLASS_CVIMM(int, demo_maxlength, 30, 3600, 0);

		//dam_handicap_p1
		//dam_handicap_p2
		//fat_handicap

		CLASS_CVIMM(float, damage_multiplier, 0.1f, 5.0f, 0);
		CLASS_CVIMM(int, dam_transfer, 0, 1, 0);
		CLASS_CVIMM(float, fom_multiplier, 0, 5.0f, 0);
		CLASS_CVIMM(float, fat_delay, 0, 5.0f, 0);
		CLASS_CVIMM(int, fat_dam, 0, 1, 0);
		CLASS_CVIMM(int, fat_damage, 0, 100, CONVARF_RESTRICTED);

		CLASS_CVIMM(float, t_combo, 0.1f, 2.5f, CONVARF_RESTRICTED);
		CLASS_CVIMM(float, combo_multiplier, 1.0f, 2.0f, 0);

		CLASS_CVIAMM(float, sensitivity, 2, 1.0f, 5.0f, 0);
		CLASS_CVIAMM(int, crad, 2, 0, 2147483647, 0);
//		CLASS_CVIAMM(int, mrad_fwd, 2, 0, 2147483647, 0);
//		CLASS_CVIAMM(int, mrad_bwd, 2, 0, 2147483647, 0);
//		CLASS_CVIAMM(int, defense_mode, 2, 0, 3, 0);

		CLASS_CVIAMM(float, t_defbuffer, 2, 0.01f, 5.0f, 0);
		CLASS_CVIMM(float, t_lockdef, 0, 5.0f, 0);
		CLASS_CVIMM(float, t_lockoff, 0, 5.0f, 0);
		CLASS_CVIMM(float, tapdamratio, 0, 5.0f, 0);

		CLASS_CVIMM(int, bot_ticks, 10, 1000, 0);

		name1_convar.init(pcon, "name_p1", 21, name[0], NULL, NULL, "char", 0);
		name2_convar.init(pcon, "name_p2", 21, name[1], NULL, NULL, "char", 0);
		CLASS_CVIAMM(RGBcolor, fistcolor, 2, black, white, 0);

		CLASS_CVIMM(bool, pal, 0, 1, CONVARF_RESTRICTED);
		CLASS_CVIMM(int, cd_state, 0, 1, CONVARF_RESTRICTED);
		CLASS_CVIMM(int, r_hollow, 0, 1, CONVARF_RESTRICTED);

		CLASS_CVIMM(float, zoomfactor, 0.1f, 5.0f, CONVARF_RESTRICTED);
		CLASS_CVIMM(int, hitstop, 0, 1000, CONVARF_RESTRICTED);

		//----------------------------------------------------------------------------------------

		CLASS_CVIMM(RGBcolor, con_color, black, white, 0);
		CLASS_CVIMM(RGBcolor, con_fcolor, black, white, 0);
		CLASS_CVIMM(int, con_textcolor, -1, 5, 0);
		CLASS_CVIMM(int, con_frame, OFF, ON, 0);
		CLASS_CVIMM(int, con_style, 0, 1, 0);

		CLASS_CVIMM(int, con_dropspeed, 0, 10000, 0);

		RECT	tmp, tmpmin, tmpmax;

		tmp.left	= 0;	tmp.right		= 800;
		tmp.top		= 75;	tmp.bottom		= 155;

		tmpmin.left	= 0;	tmpmin.right	= 32;
		tmpmin.top	= 0;	tmpmin.bottom	= 16;

		tmpmax.left	= 750;	tmpmax.right	= 800;
		tmpmax.top	= 550;	tmpmax.bottom	= 600;

		CLASS_CVIMM(RECT, con_dim, tmpmin, tmpmax, 0);
	};
};

//------------------------------------------------------------------------------------------------
//
//	options
//
//------------------------------------------------------------------------------------------------

struct options
{
	//!! sollte besser ein [4] array sein
	//optionscore	data[4];
	optionscore		data;				//options
	optionscore		dataDEF;			//default options, also contains system data
	optionscore		dataMIN;			//minimum values
	optionscore		dataMAX;			//maximum values

	//!!
//	int				locked_key[256];	//0 = key not locked for user assignment
										//1 = key locked

	//---- constructor ---------------------------------------------------------------------------

	options()
	{
		//assign default/min/max values
		set_default();

		//open config file, read data and assign it to option.data
		//only if not the teaser
		if (!TEASER_)
			read_file();

		//verify data in option.data
		verify();
	};

	//---- destructor ----------------------------------------------------------------------------

	~options()
	{
		//opens file, writes option.data into configuration file, closes file
		//only if not the teaser
		if (!TEASER_)
			write_file();
	};

	//---- read_file -----------------------------------------------------------------------------
	//opens configuration file, reads data and assigns it to option data, closes file

	void read_file()
	{
		//open config file (read only)
		//(read)
		FILE	*f_config = fopen(FCONFIG, "r");

		//if file successfully opened
		if (f_config != NULL)
		{
			//log file access
			gf_logger(false, "accessing file: %s", FCONFIG);

/*			fscanf(f_config,
//				   "%*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i%i%i %*s%*s%i%*s%*s%i%*s%*s%f %*s%*s%s%*s%*s%s %*s%*s%i %i %i %*s%*s%i %i %i %*s%*s%i %i %i %i %i %i %*s%*s%i %i %i %i %i %i",
//					sound	 vsync	  fps_max  show_fps	shadows	 mblur	  bw_mode  bg rgb		sub, rounds, roundtime, speed	 dmg, fom multi	  sensitivity	   names			fistcolors					  input					  input
				   "%*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i%i%i %*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%f %*s%*s%f%*s%*s%f %*s%*s%f%*s%*s%f %*s%*s%s%*s%*s%s %*s%*s%i %i %i %*s%*s%i %i %i %*s%*s%i %i %i %i %i %i %*s%*s%i %i %i %i %i %i",
				   &data.sound, &data.vsync, &data.fps_max, &data.show_fps,
				   &data.shadows, &data.mblur, &data.bw_mode, &data.cbackground.r, &data.cbackground.g, &data.cbackground.b,
				   &data.subframes, &data.rounds, &data.roundtime, &data.speed,
				   &data.damage_multiplier, &data.fom_multiplier,
				   &data.sensitivity[P1], &data.sensitivity[P2],
				   data.name[P1], data.name[P2],
				   &data.fistcolor[P1].r, &data.fistcolor[P1].g, &data.fistcolor[P1].b,
				   &data.fistcolor[P2].r, &data.fistcolor[P2].g, &data.fistcolor[P2].b,
				   &data.ckey[P1][LEFT], &data.ckey[P1][RIGHT], &data.ckey[P1][PUNCH],
				   &data.ckey[P1][KICK], &data.ckey[P1][DEFEND], &data.ckey[P1][SPECIAL],
				   &data.ckey[P2][LEFT], &data.ckey[P2][RIGHT], &data.ckey[P2][PUNCH],
				   &data.ckey[P2][KICK], &data.ckey[P2][DEFEND], &data.ckey[P2][SPECIAL]);*/

			//read file data into option.data
			fscanf(f_config, "%*s%*s%i %*s%*s%i",
				   &data.sound, &data.volume);
			fscanf(f_config, "%*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i",
				   &data.screenmode, &data.vsync, &data.fps_max, &data.show_fps, &data.subframes);
			fscanf(f_config, "%*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %i %i",
				   &data.shadows, &data.mblur, &data.bw_mode, &data.cbackground.r, &data.cbackground.g, &data.cbackground.b);
			fscanf(f_config, "%*s%*s%i %*s%*s%f",
				   &data.hud_text, &data.hud_text_time);
			fscanf(f_config, "%*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i %*s%*s%i",
				   &data.show_lockstate, &data.show_hitbox, &data.show_damage, &data.show_scores, &data.show_pmessages);
			fscanf(f_config, "%*s%*s%i%*s%*s%i%*s%*s%f",
				   &data.rounds, &data.roundtime, &data.speed);
			fscanf(f_config, "%*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%i%*s%*s%i",
				   &data.ko_mode, &data.ko_limit, &data.ko_instant, &data.digidamage, &data.fight_mode, &data.score_mode, &data.condition_masking, &data.randomstart);
			fscanf(f_config, "%*s%*s%i%*s%*s%i%*s%*s%i",
				   &data.demo_rec, &data.demo_maxfiles, &data.demo_maxlength);
			fscanf(f_config, "%*s%*s%i%i%i%i%i%i%i%i%i%i%i%*s%*s%i%i%i%i%i%i%i%i%i%i%i%*s%*s%f%*s%*s%f",
				   &data.dam_handicap_p1[DS_tll], &data.dam_handicap_p1[DS_tlr],
				   &data.dam_handicap_p1[DS_tul], &data.dam_handicap_p1[DS_tur],
				   &data.dam_handicap_p1[DS_hn],
				   &data.dam_handicap_p1[DS_al], &data.dam_handicap_p1[DS_ar],
				   &data.dam_handicap_p1[DS_hll], &data.dam_handicap_p1[DS_fll],
				   &data.dam_handicap_p1[DS_hlr], &data.dam_handicap_p1[DS_flr],
				   &data.dam_handicap_p2[DS_tll], &data.dam_handicap_p2[DS_tlr],
				   &data.dam_handicap_p2[DS_tul], &data.dam_handicap_p2[DS_tur],
				   &data.dam_handicap_p2[DS_hn],
				   &data.dam_handicap_p2[DS_al], &data.dam_handicap_p2[DS_ar],
				   &data.dam_handicap_p2[DS_hll], &data.dam_handicap_p2[DS_fll],
				   &data.dam_handicap_p2[DS_hlr], &data.dam_handicap_p2[DS_flr],
				   &data.fat_handicap[P1], &data.fat_handicap[P2]);
			fscanf(f_config, "%*s%*s%f %*s%*s%i %*s%*s%f %*s%*s%f %*s%*s%i",
				   &data.damage_multiplier, &data.dam_transfer,
				   &data.fom_multiplier, &data.fat_delay, &data.fat_dam);
			fscanf(f_config, "%*s%*s%f%*s%*s%f",
				   &data.t_combo, &data.combo_multiplier);
			fscanf(f_config, "%*s%*s%s%*s%*s%s",
				   data.name[P1], data.name[P2]);
			fscanf(f_config, "%*s%*s%i %i %i %*s%*s%i %i %i",
				   &data.fistcolor[P1].r, &data.fistcolor[P1].g, &data.fistcolor[P1].b,
				   &data.fistcolor[P2].r, &data.fistcolor[P2].g, &data.fistcolor[P2].b);
			fscanf(f_config, "%*s%*s%i %i",
				   &data.player_mouse[P1],
				   &data.player_mouse[P2]);
			fscanf(f_config, "%*s%*s%i %i",
				   &data.inputdevice[P1],
				   &data.inputdevice[P2]);
/*			fscanf(f_config, "%*s%*s%i %i %i %i %i %i",
				   &data.ckey[P1][LEFT], &data.ckey[P1][RIGHT], &data.ckey[P1][PUNCH],
				   &data.ckey[P1][KICK], &data.ckey[P1][DEFEND], &data.ckey[P1][SPECIAL]);
			fscanf(f_config, "%*s%*s%i %i %i %i %i %i",
				   &data.ckey[P2][LEFT], &data.ckey[P2][RIGHT], &data.ckey[P2][PUNCH],
				   &data.ckey[P2][KICK], &data.ckey[P2][DEFEND], &data.ckey[P2][SPECIAL]);*/
			fscanf(f_config, "%*s%*s%i %i %i %i %i %i %i %i",
				   &data.CBT[cP1LEFT], &data.CBT[cP1RIGHT], &data.CBT[cP1PUNCH],
				   &data.CBT[cP1KICK], &data.CBT[cP1DEFEND], &data.CBT[cP1SPECIAL],
				   &data.CBT[cP1STANCEUP], &data.CBT[cP1STANCEDOWN]);
			fscanf(f_config, "%*s%*s%i %i %i %i %i %i %i %i",
				   &data.CBT[cP2LEFT], &data.CBT[cP2RIGHT], &data.CBT[cP2PUNCH],
				   &data.CBT[cP2KICK], &data.CBT[cP2DEFEND], &data.CBT[cP2SPECIAL],
				   &data.CBT[cP2STANCEUP], &data.CBT[cP2STANCEDOWN]);
			fscanf(f_config, "%*s%*s%f %f",
				   &data.sensitivity[P1], &data.sensitivity[P2]);
			fscanf(f_config, "%*s%*s%i %i",
				   &data.crad[P1], &data.crad[P2]);
//			fscanf(f_config, "%*s%*s%i %i",
//				   &data.mrad_fwd[P1], &data.mrad_bwd[P1]);
//			fscanf(f_config, "%*s%*s%i %i",
//				   &data.mrad_fwd[P2], &data.mrad_bwd[P2]);
			fscanf(f_config, "%*s%*s%i %i",
				   &data.defense_mode[P1], &data.defense_mode[P2]);
			fscanf(f_config, "%*s%*s%f %f",
				   &data.t_defbuffer[P1], &data.t_defbuffer[P2]);
			fscanf(f_config, "%*s%*s%f %*s%*s%f",
				   &data.t_lockdef, &data.t_lockoff);
			fscanf(f_config, "%*s%*s%f",
				   &data.tapdamratio);
			fscanf(f_config, "%*s%*s%i %i %i %*s%*s%i %i %i %*s%*s%i",
				   &data.con_color.r, &data.con_color.g, &data.con_color.b,
				   &data.con_fcolor.r, &data.con_fcolor.g, &data.con_fcolor.b,
				   &data.con_textcolor);
			fscanf(f_config, "%*s%*s%i %*s%*s%i %*s%*s%i",
				   &data.con_frame, &data.con_dropspeed, &data.con_style);
			fscanf(f_config, "%*s%*s%i %i %i %i",
				   &data.con_dim.left, &data.con_dim.right, &data.con_dim.top, &data.con_dim.bottom);

			//close file
			fclose(f_config);
		}
		else
		//set sys_first data to 1 indicating no config file was found
		{
			dataDEF.sys_first = 1;
		}
	};

	//---- write_file ----------------------------------------------------------------------------
	//opens file, stores option.data in configuration file, closes file

	void write_file()
	{
		//verify player names
		verify_player_names();

		//open config file (overwrite)
		FILE	*f_config = fopen(FCONFIG, "w");

		//for every letter
		for (register int i = 0; i < 21; ++i)
		{
			//if character within name is space change it to _
			//(_ acts as as subset for space, which causes trouble when loading a
			//string with space characters)
			if (data.name[P1][i] == 32)
				data.name[P1][i] = 95;

			//same for player 2
			if (data.name[P2][i] == 32)
				data.name[P2][i] = 95;
		}

		//if file successfully opened
		if (f_config != NULL)
		{
			//log file access
			gf_logger(false, "accessing file: %s", FCONFIG);

/*			fprintf(f_config,
//					"%s%i\n%s%i\n%s%i\n%s%i\n\n%s%i\n%s%i\n%s%i\n%s%i %i %i\n\n%s%i\n%s%i\n%s%.1f\n\n%s%s\n%s%s\n\n%s%i %i %i\n%s%i %i %i\n\n%s%i %i %i %i %i %i\n%s%i %i %i %i %i %i",
					"%s%i\n%s%i\n%s%i\n%s%i\n\n%s%i\n%s%i\n%s%i\n%s%i %i %i\n\n%s%i\n%s%i\n%s%i\n%s%.1f\n\n%s%.1f\n%s%.1f\n%s%.1f\n%s%.1f\n\n%s%s\n%s%s\n\n%s%i %i %i\n%s%i %i %i\n\n%s%i %i %i %i %i %i\n%s%i %i %i %i %i %i",
					"sound			= ", data.sound,
					"vsync			= ", data.vsync,
					"fps_max			= ", data.fps_max,
					"show_fps		= ", data.show_fps,

					"shadows			= ", data.shadows,
					"m_blur			= ", data.mblur,
					"bw_mode			= ", data.bw_mode,
					"background_rgb		= ", data.cbackground.r, data.cbackground.g, data.cbackground.b,

					"subframes		= ", data.subframes,
					"rounds			= ", data.rounds,
					"roundtime		= ", data.roundtime,
					"speed			= ", data.speed,

					"damage_multiplier	= ", data.damage_multiplier,
					"fom_multiplier		= ", data.fom_multiplier,
					"sensitivity_p1		= ", data.sensitivity[P1],
					"sensitivity_p2		= ", data.sensitivity[P2],

					"name_player1		= ", data.name[P1],
					"name_player2		= ", data.name[P2],

					"fistcolor_p1_rgb	= ", data.fistcolor[P1].r, data.fistcolor[P1].g, data.fistcolor[P1].b,
					"fistcolor_p2_rgb	= ", data.fistcolor[P2].r, data.fistcolor[P2].g, data.fistcolor[P2].b,

					"p1_lrpkds		= ",
					data.ckey[P1][LEFT], data.ckey[P1][RIGHT], data.ckey[P1][PUNCH],
					data.ckey[P1][KICK], data.ckey[P1][DEFEND], data.ckey[P1][SPECIAL],
					"p2_lrpkds		= ",
					data.ckey[P2][LEFT], data.ckey[P2][RIGHT], data.ckey[P2][PUNCH],
					data.ckey[P2][KICK], data.ckey[P2][DEFEND], data.ckey[P2][SPECIAL]);*/

			//write option.data into file
			fprintf(f_config, "%s%i\n%s%i\n\n",
					"sound			= ", data.sound,
					"volume			= ", data.volume);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n\n",
				    "screenmode		= ", data.screenmode,
					"vsync			= ", data.vsync,
					"fps_max			= ", data.fps_max,
					"show_fps		= ", data.show_fps,
					"subframes		= ", data.subframes);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n%s%i %i %i\n\n",
					"shadows			= ", data.shadows,
					"m_blur			= ", data.mblur,
					"bw_mode			= ", data.bw_mode,
					"background_rgb	= ", data.cbackground.r, data.cbackground.g, data.cbackground.b);
			fprintf(f_config, "%s%i\n%s%.1f\n",
					"hud_text		= ", data.hud_text,
					"hud_text_time	= ", data.hud_text_time);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n\n",
					"show_lockstate	= ", data.show_lockstate,
					"show_hitbox		= ", data.show_hitbox,
					"show_damage		= ", data.show_damage,
					"show_scores		= ", data.show_scores,
					"show_pmessages	= ", data.show_pmessages);
			fprintf(f_config, "%s%i\n%s%i\n%s%.1f\n",
					"rounds			= ", data.rounds,
					"roundtime		= ", data.roundtime,
					"speed			= ", data.speed);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n%s%i\n\n",
					"ko_mode			= ", data.ko_mode,
					"ko_limit		= ", data.ko_limit,
					"ko_instant		= ", data.ko_instant,
					"digidamage		= ", data.digidamage,
					"fight_mode		= ", data.fight_mode,
					"score_mode		= ", data.score_mode,
					"condition_mask	= ", data.condition_masking,
					"randomstart		= ", data.randomstart);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n\n",
					"demo_rec		= ", data.demo_rec,
					"demo_maxfiles	= ", data.demo_maxfiles,
					"demo_maxlength	= ", data.demo_maxlength);
			fprintf(f_config, "%s%i %i %i %i %i %i %i %i %i %i %i\n%s%i %i %i %i %i %i %i %i %i %i %i\n%s%.1f\n%s%.1f\n\n",
					"dam_handicap_p1		= ", data.dam_handicap_p1[DS_tll], data.dam_handicap_p1[DS_tlr],
												 data.dam_handicap_p1[DS_tul], data.dam_handicap_p1[DS_tur],
												 data.dam_handicap_p1[DS_hn],
												 data.dam_handicap_p1[DS_al], data.dam_handicap_p1[DS_ar],
												 data.dam_handicap_p1[DS_hll], data.dam_handicap_p1[DS_fll],
												 data.dam_handicap_p1[DS_hlr], data.dam_handicap_p1[DS_flr],
					"dam_handicap_p2		= ", data.dam_handicap_p2[DS_tll], data.dam_handicap_p2[DS_tlr],
												 data.dam_handicap_p2[DS_tul], data.dam_handicap_p2[DS_tur],
												 data.dam_handicap_p2[DS_hn],
												 data.dam_handicap_p2[DS_al], data.dam_handicap_p2[DS_ar],
												 data.dam_handicap_p2[DS_hll], data.dam_handicap_p2[DS_fll],
												 data.dam_handicap_p2[DS_hlr], data.dam_handicap_p2[DS_flr],
					"fat_handicap_p1		= ", data.fat_handicap[P1],
					"fat_handicap_p2		= ", data.fat_handicap[P2]);
			fprintf(f_config, "%s%.1f\n%s%i\n%s%.1f\n%s%.1f\n%s%i\n\n",
					"damage_multiplier	= ", data.damage_multiplier,
					"dam_transfer		= ", data.dam_transfer,
					"fom_multiplier		= ", data.fom_multiplier,
					"fat_delay			= ", data.fat_delay,
					"fat_dam				= ", data.fat_dam);
			fprintf(f_config, "%s%.1f\n%s%.1f\n\n",
					"t_combo				= ", data.t_combo,
					"combo_multiplier	= ", data.combo_multiplier);
			fprintf(f_config, "%s%s\n%s%s\n\n",
					"name_player1		= ", data.name[P1],
					"name_player2		= ", data.name[P2]);
			fprintf(f_config, "%s%i %i %i\n%s%i %i %i\n\n",
					"fistcolor_p1_rgb	= ", data.fistcolor[P1].r, data.fistcolor[P1].g, data.fistcolor[P1].b,
					"fistcolor_p2_rgb	= ", data.fistcolor[P2].r, data.fistcolor[P2].g, data.fistcolor[P2].b);
			fprintf(f_config, "%s%i %i\n",
					"player_mouse_p1_p2	= ",
					data.player_mouse[P1],
					data.player_mouse[P2]);
			fprintf(f_config, "%s%i %i\n",
					"inputdevice_p1_p2	= ",
					data.inputdevice[P1],
					data.inputdevice[P2]);
/*			fprintf(f_config, "%s%i %i %i %i %i %i\n",
					"p1_lrpkds		= ",
					data.ckey[P1][LEFT], data.ckey[P1][RIGHT], data.ckey[P1][PUNCH],
					data.ckey[P1][KICK], data.ckey[P1][DEFEND], data.ckey[P1][SPECIAL]);
			fprintf(f_config, "%s%i %i %i %i %i %i\n\n",
					"p2_lrpkds		= ",
					data.ckey[P2][LEFT], data.ckey[P2][RIGHT], data.ckey[P2][PUNCH],
					data.ckey[P2][KICK], data.ckey[P2][DEFEND], data.ckey[P2][SPECIAL]);*/
			fprintf(f_config, "%s%i %i %i %i %i %i %i %i\n",
					"p1_lrpkdsud			= ",
					data.CBT[cP1LEFT], data.CBT[cP1RIGHT], data.CBT[cP1PUNCH],
					data.CBT[cP1KICK], data.CBT[cP1DEFEND], data.CBT[cP1SPECIAL],
					data.CBT[cP1STANCEUP], data.CBT[cP1STANCEDOWN]);
			fprintf(f_config, "%s%i %i %i %i %i %i %i %i\n\n",
					"p2_lrpkdsud			= ",
					data.CBT[cP2LEFT], data.CBT[cP2RIGHT], data.CBT[cP2PUNCH],
					data.CBT[cP2KICK], data.CBT[cP2DEFEND], data.CBT[cP2SPECIAL],
					data.CBT[cP2STANCEUP], data.CBT[cP2STANCEDOWN]);
			fprintf(f_config, "%s%.1f %.1f\n",
					"sensitivity_p1_p2	= ", data.sensitivity[P1], data.sensitivity[P2]);
			fprintf(f_config, "%s%i %i\n",
					"crad_p1_p2			= ", data.crad[P1], data.crad[P2]);
//			fprintf(f_config, "%s%i %i\n%s%i %i\n",
//					"mrad_fwd_bwd_p1		= ", data.mrad_fwd[P1], data.mrad_bwd[P1],
//					"mrad_fwd_bwd_p2		= ", data.mrad_fwd[P2], data.mrad_bwd[P2]);
			fprintf(f_config, "%s%i %i\n\n",
					"defense_mode_p1_p2	= ", data.defense_mode[P1], data.defense_mode[P2]);
			fprintf(f_config, "%s%.2f %.2f\n",
					"t_defbuffer_p1_p2	= ", data.t_defbuffer[P1], data.t_defbuffer[P2]);
			fprintf(f_config, "%s%.1f\n%s%.1f\n",
					"t_lockdef			= ", data.t_lockdef,
					"t_lockoff			= ", data.t_lockoff);
			fprintf(f_config, "%s%.1f\n\n",
					"tapdamratio			= ", data.tapdamratio);
			fprintf(f_config, "%s%i %i %i\n%s%i %i %i\n%s%i\n",
				    "con_color_rgb		= ", data.con_color.r, data.con_color.g, data.con_color.b,
					"con_fcolor_rgb		= ", data.con_fcolor.r, data.con_fcolor.g, data.con_fcolor.b,
					"con_textcolor		= ", data.con_textcolor);
			fprintf(f_config, "%s%i\n%s%i\n%s%i\n",
					"con_frame			= ", data.con_frame,
					"con_dropspeed		= ", data.con_dropspeed,
					"con_style			= ", data.con_style);
			fprintf(f_config, "%s%i %i %i %i",
					"con_dim				= ", data.con_dim.left, data.con_dim.right, data.con_dim.top, data.con_dim.bottom);

			//close file
			fclose(f_config);
		}
	};
	
	//---- set_default ---------------------------------------------------------------------------
	//set default and boundary values

	void set_default()
	{
		//---- assign default and boundary values ------------------------------------------------

		dataDEF.sys_first		= 0;
		dataDEF.mouseflag		= 0;	dataMIN.mouseflag	= 0;		dataMAX.mouseflag		= 1;
		dataDEF.controllerflag	= 0;	dataMIN.controllerflag	= 0;	dataMAX.controllerflag	= 1;

		dataDEF.sound			= 1;	dataMIN.sound		= 0;		dataMAX.sound		= 1;
		dataDEF.volume			= 0;	dataMIN.volume		= -10000;	dataMAX.volume		= 0;

		dataDEF.screenmode		= 1;	dataMIN.screenmode	= 0;	dataMAX.screenmode	= 1;
		dataDEF.vsync			= 1;	dataMIN.vsync		= 0;	dataMAX.vsync		= 1;
		dataDEF.fps_max			= 0;	dataMIN.fps_max		= 30;	dataMAX.fps_max		= 1000;
		dataDEF.show_fps		= 1;	dataMIN.show_fps	= 0;	dataMAX.show_fps	= 1;
		dataDEF.subframes		= 3;	dataMIN.subframes	= 1;	dataMAX.subframes	= 200;

		dataDEF.shadows			= 1;	dataMIN.shadows		= 0;	dataMAX.shadows		= 1;
		dataDEF.mblur			= 0;	dataMIN.mblur		= 0;	dataMAX.mblur		= 20;
		dataDEF.bw_mode			= 0;	dataMIN.bw_mode		= 0;	dataMAX.bw_mode		= 1;
		dataDEF.cbackground.setcolor(white);
		dataMIN.cbackground.setcolor(black);
		dataMAX.cbackground.setcolor(white);

		dataDEF.hud_text		= 1;	dataMIN.hud_text	= 0;	dataMAX.hud_text	= 1;
		dataDEF.hud_text_time	= 5.0f;	dataMIN.hud_text_time	= 0;	dataMAX.hud_text_time	= 10.f;
		dataDEF.show_lockstate	= 0;	dataMIN.show_lockstate	= 0;	dataMAX.show_lockstate	= 1;
		dataDEF.show_hitbox		= 0;	dataMIN.show_hitbox	= 0;	dataMAX.show_hitbox	= 1;
		dataDEF.show_damage		= 0;	dataMIN.show_damage	= 0;	dataMAX.show_damage	= 1;
		dataDEF.show_scores		= 0;	dataMIN.show_scores	= 0;	dataMAX.show_scores	= 1;
		dataDEF.show_pmessages	= 1;	dataMIN.show_pmessages	= 0;	dataMAX.show_pmessages	= 1;

		dataDEF.rounds			= 2;	dataMIN.rounds		= 1;	dataMAX.rounds		= 4;
		dataDEF.roundtime		= 0;	dataMIN.roundtime	= 5;	dataMAX.roundtime	= 5999;
		dataDEF.speed			= 1.0f;	dataMIN.speed		= 0.1f;	dataMAX.speed		= 3.0f;
		dataDEF.ko_mode			= KOM_HEAD_AND_UP_OR_LO;			dataMIN.ko_mode		= 0;	dataMAX.ko_mode		= 14;
		dataDEF.ko_limit		= 12;	dataMIN.ko_limit	= 0;	dataMAX.ko_limit	= 100;
		dataDEF.ko_instant		= 40;	dataMIN.ko_instant	= 0;	dataMAX.ko_instant	= 1000;
		dataDEF.digidamage		= 1;	dataMIN.digidamage	= 0;	dataMAX.digidamage	= 1;
		dataDEF.fight_mode		= 0;	dataMIN.fight_mode	= 0;	dataMAX.fight_mode	= 2;
		dataDEF.score_mode		= 0;	dataMIN.score_mode	= 0;	dataMAX.score_mode	= 1;
		dataDEF.condition_masking = 0;	dataMIN.condition_masking = 0; dataMAX.condition_masking = 2;
		dataDEF.randomstart		= 1;	dataMIN.randomstart	= 0;	dataMAX.randomstart	= 1;

		dataDEF.demo_rec		= 0;	dataMIN.demo_rec		= 0;	dataMAX.demo_rec		= 1;
		dataDEF.demo_maxfiles	= 5;	dataMIN.demo_maxfiles	= 0;	dataMAX.demo_maxfiles	= 99;
		dataDEF.demo_maxlength	= 60 * 10;	dataMIN.demo_maxlength	= 30;	dataMAX.demo_maxlength	= 60 * 60;

		//handicaps
		for (register int i = 0; i < NODS; ++i)
		{
			dataDEF.dam_handicap_p1[i]	= 0;
			dataMIN.dam_handicap_p1[i]	= 0;
			dataMAX.dam_handicap_p1[i]	= 100;
			dataDEF.dam_handicap_p2[i]	= 0;
			dataMIN.dam_handicap_p2[i]	= 0;
			dataMAX.dam_handicap_p2[i]	= 100;
		}

		dataDEF.fat_handicap[P1]	= 1.0f;	dataMIN.fat_handicap[P1]	= -10.0f;	dataMAX.fat_handicap[P1]	= 10.0f;
		dataDEF.fat_handicap[P2]	= 1.0f;	dataMIN.fat_handicap[P2]	= -10.0f;	dataMAX.fat_handicap[P2]	= 10.0f;

		//multipliers
		dataDEF.damage_multiplier	= 1.0f;
		dataMIN.damage_multiplier	= 0.1f;
		dataMAX.damage_multiplier	= 5.0f;
		dataDEF.dam_transfer		= 1;	dataMIN.dam_transfer = 0;	dataMAX.dam_transfer = 1;
		dataDEF.fom_multiplier		= 1.0f;
		dataMIN.fom_multiplier		= 0;			//OFF
		dataMAX.fom_multiplier		= 5.0f;
		dataDEF.fat_delay			= 1.0f;	dataMIN.fat_delay	= 0;	dataMAX.fat_delay	= 5.0f;
		dataDEF.fat_dam				= 1;	dataMIN.fat_dam		= 0;	dataMAX.fat_dam		= 1;
		dataDEF.fat_damage			= 5;	dataMIN.fat_damage	= 0;	dataMAX.fat_damage	= 100;

		dataDEF.t_combo				= 0.5f;	dataMIN.t_combo				= 0.1f;	dataMAX.t_combo				= 2.5f;
		dataDEF.combo_multiplier	= 1.2f;	dataMIN.combo_multiplier	= 1.0f;	dataMAX.combo_multiplier	= 2.0f;

		//copy names
		strcpy(dataDEF.name[P1], "PLAYER_1");
		strcpy(dataDEF.name[P2], "PLAYER_2");

		dataDEF.fistcolor[P1].setcolor(red);	dataDEF.fistcolor[P2].setcolor(blue);
		dataMIN.fistcolor[P1]					= dataMIN.fistcolor[P2]		= black;
		dataMAX.fistcolor[P1]					= dataMAX.fistcolor[P2]		= white;

		dataDEF.player_mouse[P1]	= 0;				dataDEF.player_mouse[P2]	= 1;
		dataMIN.player_mouse[P1]	=					dataMIN.player_mouse[P2]	= 0;
		dataMAX.player_mouse[P1]	=					dataMAX.player_mouse[P2]	= RIDmax - 1;
		dataDEF.inputdevice[P1]		= DCD_MOUSE1;		dataDEF.inputdevice[P2]		= DCD_MOUSE2;
		dataMIN.inputdevice[P1]		=					dataMIN.inputdevice[P2]		= 0;
		dataMAX.inputdevice[P1]		=					dataMAX.inputdevice[P2]		= 5;

		//sensitivity
		dataDEF.sensitivity[P1]		= dataDEF.sensitivity[P2]		= 1.0f;
		dataMIN.sensitivity[P1]		= dataMIN.sensitivity[P2]		= 1.0f;
		dataMAX.sensitivity[P1]		= dataMAX.sensitivity[P2]		= 5.0f;

		//mouse radius
		dataDEF.crad[P1]			= dataDEF.crad[P2]			= 12;
		dataMIN.crad[P1]			= dataMIN.crad[P2]			= 0;
		dataMAX.crad[P1]			= dataMAX.crad[P2]			= 2147483647;
//		dataDEF.mrad_fwd[P1]		= dataDEF.mrad_fwd[P2]		= 150;
//		dataMIN.mrad_fwd[P1]		= dataMIN.mrad_fwd[P2]		= 0;
//		dataMAX.mrad_fwd[P1]		= dataMAX.mrad_fwd[P2]		= 2147483647;
//		dataDEF.mrad_bwd[P1]		= dataDEF.mrad_bwd[P2]		= 150;
//		dataMIN.mrad_bwd[P1]		= dataMIN.mrad_bwd[P2]		= 0;
//		dataMAX.mrad_bwd[P1]		= dataMAX.mrad_bwd[P2]		= 2147483647;

		//defense mode
		dataDEF.defense_mode[P1]	= dataDEF.defense_mode[P2]	= DM_aTaE;
		dataMIN.defense_mode[P1]	= dataMIN.defense_mode[P2]	= 0;
		dataMAX.defense_mode[P1]	= dataMAX.defense_mode[P2]	= 3;

		//t_defbuffer
		dataDEF.t_defbuffer[P1]		= dataDEF.t_defbuffer[P2]	= 0.02f;
		dataMIN.t_defbuffer[P1]		= dataMIN.t_defbuffer[P2]	= 0.01f;
		dataMAX.t_defbuffer[P1]		= dataMAX.t_defbuffer[P2]	= 5.0f;

		//t_lockdef/t_lockoff
		dataDEF.t_lockdef			= 1.0f;		dataDEF.t_lockoff		= 1.0f;
		dataMIN.t_lockdef			= dataMIN.t_lockoff					= 0;
		dataMAX.t_lockdef			= dataMAX.t_lockoff					= 5.0f;

		//tapdamratio
		dataDEF.tapdamratio	= 1.0f;	dataMIN.tapdamratio	= 0;	dataMAX.tapdamratio = 5.0f;

		//bot ticks
		dataDEF.bot_ticks	= 30;	dataMIN.bot_ticks	= 10;	dataMAX.bot_ticks	= 1000;

		//misc
		dataDEF.pal			= PAL;	dataMIN.pal			= 0;	dataMAX.pal			= 1;
		dataDEF.cd_state	= 0;	dataMIN.cd_state	= 0;	dataMAX.cd_state	= 1;
		dataDEF.r_hollow	= 0;	dataMIN.r_hollow	= 0;	dataMAX.r_hollow	= 1;

		dataDEF.zoomfactor	= 1.0f;	dataMIN.zoomfactor	= 0.1f;	dataMAX.zoomfactor	= 5.0f;
		dataDEF.hitstop		= 30;	dataMIN.hitstop		= 0;	dataMAX.hitstop		= 1000;

		//---- user keys -------------------------------------------------------------------------

		dataDEF.CBT[cP1PUNCH]			= 300;
		dataDEF.CBT[cP1KICK]			= 301;
		dataDEF.CBT[cP1DEFEND]			= DIK_SPACE;
		dataDEF.CBT[cP1LEFT]			= DIK_A;
		dataDEF.CBT[cP1RIGHT]			= DIK_D;
		dataDEF.CBT[cP1SPECIAL]			= DIK_S;
		dataDEF.CBT[cP1STANCEUP]		= 305;
		dataDEF.CBT[cP1STANCEDOWN]		= 306;

		dataDEF.CBT[cP2PUNCH]			= 400;
		dataDEF.CBT[cP2KICK]			= 401;
		dataDEF.CBT[cP2DEFEND]			= DIK_NUMPADENTER;
		dataDEF.CBT[cP2LEFT]			= DIK_NUMPAD4;
		dataDEF.CBT[cP2RIGHT]			= DIK_NUMPAD6;
		dataDEF.CBT[cP2SPECIAL]			= DIK_NUMPAD5;
		dataDEF.CBT[cP2STANCEUP]		= 405;
		dataDEF.CBT[cP2STANCEDOWN]		= 406;

		//---- general commands ------------------------------------------------------------------

		dataDEF.CBT[cPAUSE]				= DIK_ESCAPE;
		dataDEF.CBT[cEXIT]				= DIK_F12;
		dataDEF.CBT[cCONSOLE]			= DIK_GRAVE;
		dataDEF.CBT[cSCREENSHOT]		= DIK_SYSRQ;
		dataDEF.CBT[cSCREENMODE]		= DIK_F10;
		dataDEF.CBT[cVSYNC]				= 0;
		dataDEF.CBT[cSHADOWS]			= DIK_F2;
		dataDEF.CBT[cBLURUP]			= DIK_F9;
		dataDEF.CBT[cBLURDOWN]			= DIK_F8;
		dataDEF.CBT[cSPEEDUP]			= DIK_F5;
		dataDEF.CBT[cSPEEDDOWN]			= DIK_F4;
		dataDEF.CBT[cSOUND]				= DIK_F1;
		dataDEF.CBT[cBWMODE]			= DIK_F3;
		dataDEF.CBT[cDAMUP]				= DIK_F7;
		dataDEF.CBT[cDAMDOWN]			= DIK_F6;
		dataDEF.CBT[cFATUP]				= DIK_F7;
		dataDEF.CBT[cFATDOWN]			= DIK_F6;

//		dataDEF.CBT[cTOGGLEBOT1]		= DIK_T;
//		dataDEF.CBT[cTOGGLEBOT2]		= DIK_G;
		dataDEF.CBT[cTOGGLEBOT1]		= DIK_1;
		dataDEF.CBT[cTOGGLEBOT2]		= DIK_2;

		//---- locked functions ------------------------------------------------------------------

		dataDEF.CBT_LOCK[cPAUSE]		= 1;

		//---- locked keys -----------------------------------------------------------------------

		dataDEF.KEY_LOCK[DIK_ESCAPE]	= 1;
		dataDEF.KEY_LOCK[DIK_F1]		= 1;
		dataDEF.KEY_LOCK[DIK_F2]		= 1;
		dataDEF.KEY_LOCK[DIK_F3]		= 1;
		dataDEF.KEY_LOCK[DIK_F4]		= 1;
		dataDEF.KEY_LOCK[DIK_F5]		= 1;
		dataDEF.KEY_LOCK[DIK_F6]		= 1;
		dataDEF.KEY_LOCK[DIK_F7]		= 1;
		dataDEF.KEY_LOCK[DIK_F8]		= 1;
		dataDEF.KEY_LOCK[DIK_F9]		= 1;
		dataDEF.KEY_LOCK[DIK_F10]		= 1;
		dataDEF.KEY_LOCK[DIK_F11]		= 1;
		dataDEF.KEY_LOCK[DIK_F12]		= 1;
		dataDEF.KEY_LOCK[DIK_PAUSE]		= 1;
		dataDEF.KEY_LOCK[DIK_SYSRQ]		= 1;
		dataDEF.KEY_LOCK[DIK_GRAVE]		= 1;

		//bot toggle
		dataDEF.KEY_LOCK[DIK_1]			= 1;
		dataDEF.KEY_LOCK[DIK_2]			= 1;

/*		dataDEF.cpause					= DIK_ESCAPE;
		dataDEF.cexit					= DIK_F12;
		dataDEF.cvsync					= DIK_F1;
		dataDEF.cshadows				= DIK_F2;
		dataDEF.csound					= DIK_F3;
		dataDEF.cspeeddown				= DIK_F4;
		dataDEF.cspeedup				= DIK_F5;
		dataDEF.cmblurdown				= DIK_F6;
		dataDEF.cmblurup				= DIK_F7;
		dataDEF.cbw_mode				= DIK_F8;
		dataDEF.cdamdown				= DIK_F9;
		dataDEF.cdamup					= DIK_F10;
		dataDEF.cfatdown				= DIK_F9;
		dataDEF.cfatup					= DIK_F10;
		dataDEF.cscreenshot				= DIK_SYSRQ;*/

		//console data
		dataDEF.con_color				= orange;
		dataMIN.con_color				= black;
		dataMAX.con_color				= white;
		dataDEF.con_fcolor				= black;
		dataMIN.con_fcolor				= black;
		dataMAX.con_fcolor				= white;
		dataDEF.con_textcolor			= -1;
		dataMIN.con_textcolor			= -1;
		dataMAX.con_textcolor			= 5;

		dataDEF.con_frame				= 0;
		dataMIN.con_frame				= 0;
		dataMAX.con_frame				= 1;

		dataDEF.con_dropspeed			= 600;
		dataMIN.con_dropspeed			= 0;
		dataMAX.con_dropspeed			= 10000;

		dataDEF.con_style				= 0;
		dataMIN.con_style				= 0;
		dataMAX.con_style				= 1;

		dataDEF.con_dim.left			= 0;
		dataDEF.con_dim.right			= 800;
		dataDEF.con_dim.top				= 75;
		dataDEF.con_dim.bottom			= 155;
		dataMIN.con_dim.left			= 0;
		dataMIN.con_dim.right			= 24;
		dataMIN.con_dim.top				= 0;
		dataMIN.con_dim.bottom			= 16;
		dataMAX.con_dim.left			= 750;
		dataMAX.con_dim.right			= 800;
		dataMAX.con_dim.top				= 550;
		dataMAX.con_dim.bottom			= 600;

		//---- copy dataDEF into data ------------------------------------------------------------
		//!! why?

		data = dataDEF;

		//---- set locked keys -------------------------------------------------------------------

		/*/unlock all
		ZeroMemory(&locked_key, sizeof(locked_key));

		//locks
		locked_key[dataDEF.cpause]		= 1;
		locked_key[dataDEF.cvsync]		= 1;
		locked_key[dataDEF.cshadows]	= 1;
		locked_key[dataDEF.csound]		= 1;
		locked_key[dataDEF.cspeeddown]	= 1;
		locked_key[dataDEF.cspeedup]	= 1;
		locked_key[dataDEF.cmblurdown]	= 1;
		locked_key[dataDEF.cmblurup]	= 1;
		locked_key[dataDEF.cbw_mode]	= 1;
		locked_key[dataDEF.cexit]		= 1;
		locked_key[DIK_F9]				= 1;
		locked_key[DIK_F10]				= 1;
		locked_key[DIK_F11]				= 1;
		locked_key[DIK_PAUSE]			= 1;
		locked_key[DIK_SYSRQ]			= 1;
		locked_key[DIK_GRAVE]			= 1;*/
	};

	//---- verify --------------------------------------------------------------------------------
	//checks if option.data is within extent of validity, else assigns default value

	void verify()
	{
		if (data.sound < dataMIN.sound)			data.sound	= dataMIN.sound;
		if (data.sound > dataMAX.sound)			data.sound	= dataMAX.sound;
		if (data.volume < dataMIN.volume)		data.volume	= dataMIN.volume;
		if (data.volume > dataMAX.volume)		data.volume	= dataMAX.volume;

		if (data.screenmode < dataMIN.screenmode)	data.screenmode = dataMIN.screenmode;
		if (data.screenmode > dataMAX.screenmode)	data.screenmode = dataMAX.screenmode;
		if (data.vsync < dataMIN.vsync)			data.vsync = dataMIN.vsync;
		if (data.vsync > dataMAX.vsync)			data.vsync = dataMAX.vsync;
		if (data.fps_max < dataMIN.fps_max && data.fps_max != 0)
			data.fps_max = dataMIN.fps_max;
		if (data.fps_max > dataMAX.fps_max)		data.fps_max	= dataMAX.fps_max;
		if (data.show_fps < dataMIN.show_fps)	data.show_fps	= dataMIN.show_fps;
		if (data.show_fps > dataMAX.show_fps)	data.show_fps	= dataMAX.show_fps;
		if (data.subframes < dataMIN.subframes)	data.subframes	= dataMIN.subframes;
		if (data.subframes > dataMAX.subframes)	data.subframes	= dataMAX.subframes;

		if (data.shadows < dataMIN.shadows || data.shadows > dataMAX.shadows)
			data.shadows = dataDEF.shadows;
		if (data.mblur < dataMIN.mblur)			data.mblur = dataMIN.mblur;
		if (data.mblur > dataMAX.mblur)			data.mblur = dataMAX.mblur;
		if (MBLUR_LIMIT)
			if (data.mblur != 0 && !(data.mblur % 3))	data.mblur = dataDEF.mblur;
		if (data.bw_mode < dataMIN.bw_mode || data.bw_mode > dataMAX.bw_mode)
			data.bw_mode = dataDEF.bw_mode;

		if (data.cbackground.r < dataMIN.cbackground.r || data.cbackground.r > dataMAX.cbackground.r)
			data.cbackground.r = dataDEF.cbackground.r;
		if (data.cbackground.g < dataMIN.cbackground.g || data.cbackground.g > dataMAX.cbackground.g)
			data.cbackground.g = dataDEF.cbackground.g;
		if (data.cbackground.b < dataMIN.cbackground.b || data.cbackground.b > dataMAX.cbackground.b)
			data.cbackground.b = dataDEF.cbackground.b;

		if (data.hud_text < dataMIN.hud_text)	data.hud_text	= dataMIN.hud_text;
		if (data.hud_text > dataMAX.hud_text)	data.hud_text	= dataMAX.hud_text;
		if (data.hud_text_time < dataMIN.hud_text_time)	data.hud_text_time	= dataMIN.hud_text_time;
		if (data.hud_text_time > dataMAX.hud_text_time)	data.hud_text_time	= dataMAX.hud_text_time;
		if (data.show_lockstate < dataMIN.show_lockstate)	data.show_lockstate = dataMIN.show_lockstate;
		if (data.show_lockstate > dataMAX.show_lockstate)	data.show_lockstate = dataMAX.show_lockstate;
		if (data.show_hitbox < dataMIN.show_hitbox || data.show_hitbox > dataMAX.show_hitbox)
			data.show_hitbox = dataDEF.show_hitbox;
		if (data.show_damage < dataMIN.show_damage || data.show_damage > dataMAX.show_damage)
			data.show_damage = dataDEF.show_damage;
		if (data.show_scores < dataMIN.show_scores || data.show_scores > dataMAX.show_scores)
			data.show_scores = dataDEF.show_scores;
		if (data.show_pmessages < dataMIN.show_pmessages || data.show_pmessages > dataMAX.show_pmessages)
			data.show_pmessages = dataDEF.show_pmessages;

		if (data.rounds < dataMIN.rounds)			data.rounds = dataMIN.rounds;
		if (data.rounds > dataMAX.rounds)			data.rounds = dataMAX.rounds;

		if (data.roundtime < dataMIN.roundtime && data.roundtime != 0)
			data.roundtime = dataMIN.roundtime;
		if (data.roundtime > dataMAX.roundtime)		data.roundtime = dataMAX.roundtime;

		if (data.speed < dataMIN.speed)				data.speed = dataMIN.speed;
		if (data.speed > dataMAX.speed)				data.speed = dataMAX.speed;

		if (data.ko_mode < dataMIN.ko_mode)			data.ko_mode	= dataMIN.ko_mode;
		if (data.ko_mode > dataMAX.ko_mode)			data.ko_mode	= dataMAX.ko_mode;
		if (data.ko_limit < dataMIN.ko_limit)		data.ko_limit	= dataMIN.ko_limit;
		if (data.ko_limit > dataMAX.ko_limit)		data.ko_limit	= dataMAX.ko_limit;
		if (data.ko_instant < dataMIN.ko_instant)	data.ko_instant	= dataMIN.ko_instant;
		if (data.ko_instant > dataMAX.ko_instant)	data.ko_instant	= dataMAX.ko_instant;
		if (data.digidamage < dataMIN.digidamage )	data.digidamage = dataMIN.digidamage;
		if (data.digidamage > dataMAX.digidamage )	data.digidamage = dataMAX.digidamage;
		if (data.fight_mode < dataMIN.fight_mode)	data.fight_mode	= dataMIN.fight_mode;
		if (data.fight_mode > dataMAX.fight_mode)	data.fight_mode	= dataMAX.fight_mode;
		if (data.score_mode < dataMIN.score_mode)	data.score_mode	= dataMIN.score_mode;
		if (data.score_mode > dataMAX.score_mode)	data.score_mode	= dataMAX.score_mode;
		if (data.condition_masking < dataMIN.condition_masking)		data.condition_masking	= dataMIN.condition_masking;
		if (data.condition_masking > dataMAX.condition_masking)		data.condition_masking	= dataMAX.condition_masking;
		if (data.randomstart < dataMIN.randomstart)	data.randomstart	= dataMIN.randomstart;
		if (data.randomstart > dataMAX.randomstart)	data.randomstart	= dataMAX.randomstart;

		if (data.demo_rec < dataMIN.demo_rec) data.demo_rec		= dataMIN.demo_rec;
		if (data.demo_rec > dataMAX.demo_rec) data.demo_rec		= dataMAX.demo_rec;
		if (data.demo_maxfiles < dataMIN.demo_maxfiles) data.demo_maxfiles		= dataMIN.demo_maxfiles;
		if (data.demo_maxfiles > dataMAX.demo_maxfiles) data.demo_maxfiles		= dataMAX.demo_maxfiles;
		if (data.demo_maxlength < dataMIN.demo_maxlength) data.demo_maxlength		= dataMIN.demo_maxlength;
		if (data.demo_maxlength > dataMAX.demo_maxlength) data.demo_maxlength		= dataMAX.demo_maxlength;

		//handicaps
		for (register int i = 0; i < NODS; ++i)
		{
			if (data.dam_handicap_p1[i] < dataMIN.dam_handicap_p1[i])
				data.dam_handicap_p1[i] = dataMIN.dam_handicap_p1[i];
			if (data.dam_handicap_p1[i] > dataMAX.dam_handicap_p1[i])
				data.dam_handicap_p1[i] = dataMAX.dam_handicap_p1[i];
			if (data.dam_handicap_p2[i] < dataMIN.dam_handicap_p2[i])
				data.dam_handicap_p2[i] = dataMIN.dam_handicap_p2[i];
			if (data.dam_handicap_p2[i] > dataMAX.dam_handicap_p2[i])
				data.dam_handicap_p2[i] = dataMAX.dam_handicap_p2[i];
		}

		if (data.fat_handicap[P1] < dataMIN.fat_handicap[P1])
			data.fat_handicap[P1] = dataMIN.fat_handicap[P1];
		if (data.fat_handicap[P1] > dataMAX.fat_handicap[P1])
			data.fat_handicap[P1] = dataMAX.fat_handicap[P1];
		if (data.fat_handicap[P2] < dataMIN.fat_handicap[P2])
			data.fat_handicap[P2] = dataMIN.fat_handicap[P2];
		if (data.fat_handicap[P2] > dataMAX.fat_handicap[P2])
			data.fat_handicap[P2] = dataMAX.fat_handicap[P2];

		//multipliers
		if (data.damage_multiplier < dataMIN.damage_multiplier) data.damage_multiplier = dataMIN.damage_multiplier;
		if (data.damage_multiplier > dataMAX.damage_multiplier) data.damage_multiplier = dataMAX.damage_multiplier;
		if (data.dam_transfer < dataMIN.dam_transfer || data.dam_transfer > dataMAX.dam_transfer)
			data.dam_transfer = dataDEF.dam_transfer;
		if (data.fom_multiplier < dataMIN.fom_multiplier)		data.fom_multiplier = dataMIN.fom_multiplier;
		if (data.fom_multiplier > dataMAX.fom_multiplier)		data.fom_multiplier = dataMAX.fom_multiplier;
		if (data.fat_delay < dataMIN.fat_delay)					data.fat_delay = dataMIN.fat_delay;
		if (data.fat_delay > dataMAX.fat_delay)					data.fat_delay = dataMAX.fat_delay;
		if (data.fat_dam < dataMIN.fat_dam)						data.fat_dam = dataMIN.fat_dam;
		if (data.fat_dam > dataMAX.fat_dam)						data.fat_dam = dataMAX.fat_dam;
		if (data.fat_damage < dataMIN.fat_damage)				data.fat_dam = dataMIN.fat_damage;
		if (data.fat_damage > dataMAX.fat_damage)				data.fat_dam = dataMAX.fat_damage;

		if (data.t_combo < dataMIN.t_combo)						data.t_combo = dataMIN.t_combo;
		if (data.t_combo > dataMAX.t_combo)						data.t_combo = dataMAX.t_combo;
		if (data.combo_multiplier < dataMIN.combo_multiplier)	data.combo_multiplier = dataMIN.combo_multiplier;
		if (data.combo_multiplier > dataMAX.combo_multiplier)	data.combo_multiplier = dataMAX.combo_multiplier;

		//player mouse
		if (data.player_mouse[P1] < dataMIN.player_mouse[P1])		data.player_mouse[P1] = dataMIN.player_mouse[P1];
		if (data.player_mouse[P1] > dataMAX.player_mouse[P1])		data.player_mouse[P1] = dataMAX.player_mouse[P1];
		if (data.player_mouse[P2] < dataMIN.player_mouse[P2])		data.player_mouse[P2] = dataMIN.player_mouse[P2];
		if (data.player_mouse[P2] > dataMAX.player_mouse[P2])		data.player_mouse[P2] = dataMAX.player_mouse[P2];
		//player 1 and 2 can't share the same mouse
		if (data.player_mouse[P1] == data.player_mouse[P2])
		{
			if (data.player_mouse[P1] > 0)		data.player_mouse[P2] = 0;
			else								data.player_mouse[P2] = 1;
		}

		//inputdevice
		if (data.inputdevice[P1] < dataMIN.inputdevice[P1])		data.inputdevice[P1] = dataMIN.inputdevice[P1];
		if (data.inputdevice[P1] > dataMAX.inputdevice[P1])		data.inputdevice[P1] = dataMAX.inputdevice[P1];
		if (data.inputdevice[P2] < dataMIN.inputdevice[P2])		data.inputdevice[P2] = dataMIN.inputdevice[P2];
		if (data.inputdevice[P2] > dataMAX.inputdevice[P2])		data.inputdevice[P2] = dataMAX.inputdevice[P2];
		//player 1 and 2 can't share the same device
		if (data.inputdevice[P1] == data.inputdevice[P2])
		{
			if (data.inputdevice[P1] > 0)		data.inputdevice[P2] = 0;
			else								data.inputdevice[P2] = 1;
		}
		//mice can't be switched via inputdevice, only through 'mouse' command
		if (data.inputdevice[P1] == DCD_MOUSE2)					data.inputdevice[P1] = DCD_MOUSE1;
		if (data.inputdevice[P2] == DCD_MOUSE1)					data.inputdevice[P2] = DCD_MOUSE2;

		//verify player names
		verify_player_names();

		for (register int p = 0; p < 2; ++p)
		{
			if (data.fistcolor[p].r < dataMIN.fistcolor[p].r || data.fistcolor[p].r > dataMAX.fistcolor[p].r)
				data.fistcolor[p].r = dataDEF.fistcolor[p].r;
			if (data.fistcolor[p].g < dataMIN.fistcolor[p].g || data.fistcolor[p].g > dataMAX.fistcolor[p].g)
				data.fistcolor[p].g = dataDEF.fistcolor[p].g;
			if (data.fistcolor[p].b < dataMIN.fistcolor[p].b || data.fistcolor[p].b > dataMAX.fistcolor[p].b)
				data.fistcolor[p].b = dataDEF.fistcolor[p].b;

			//sensitivity
			if (data.sensitivity[p] < dataMIN.sensitivity[p])	data.sensitivity[p] = dataMIN.sensitivity[p];
			if (data.sensitivity[p] > dataMAX.sensitivity[p])	data.sensitivity[p] = dataMAX.sensitivity[p];

			//mouse radius
			if (data.crad[p] < dataMIN.crad[p])		data.crad[p] = dataMIN.crad[p];
			if (data.crad[p] > dataMAX.crad[p])		data.crad[p] = dataMAX.crad[p];
//			if (data.mrad_fwd[p] < dataMIN.mrad_fwd[p])		data.mrad_fwd[p] = dataMIN.mrad_fwd[p];
//			if (data.mrad_fwd[p] > dataMAX.mrad_fwd[p])		data.mrad_fwd[p] = dataMAX.mrad_fwd[p];
//			if (data.mrad_bwd[p] < dataMIN.mrad_bwd[p])		data.mrad_bwd[p] = dataMIN.mrad_bwd[p];
//			if (data.mrad_bwd[p] > dataMAX.mrad_bwd[p])		data.mrad_bwd[p] = dataMAX.mrad_bwd[p];
	
			//defense mode
			if (data.defense_mode[p] < dataMIN.defense_mode[p] ||
				data.defense_mode[p] > dataMAX.defense_mode[p])
				data.defense_mode[p] = dataDEF.defense_mode[p];

			//t_defbuffer
			if (data.t_defbuffer[p] < dataMIN.t_defbuffer[p])	data.t_defbuffer[p] = dataMIN.t_defbuffer[p];
			if (data.t_defbuffer[p] > dataMAX.t_defbuffer[p])	data.t_defbuffer[p] = dataMAX.t_defbuffer[p];
		}

		//t_lockdef/t_lockoff
		if (data.t_lockoff < dataMIN.t_lockoff)	data.t_lockoff = dataMIN.t_lockoff;
		if (data.t_lockoff > dataMAX.t_lockoff)	data.t_lockoff = dataMAX.t_lockoff;
		if (data.t_lockdef < dataMIN.t_lockdef)	data.t_lockdef = dataMIN.t_lockdef;
		if (data.t_lockdef > dataMAX.t_lockdef)	data.t_lockdef = dataMAX.t_lockdef;

		//tapdamratio
		if (data.tapdamratio < dataMIN.tapdamratio)	data.tapdamratio = dataMIN.tapdamratio;
		if (data.tapdamratio > dataMAX.tapdamratio)	data.tapdamratio = dataMAX.tapdamratio;

		//zoomfactor
//		if (data.zoomfactor < dataMIN.zoomfactor ||
//			data.zoomfactor > dataMAX.zoomfactor)
//			data.zoomfactor = dataDEF.zoomfactor;

		//controls, mouse button not below 3 and for keyboard not above 255
		//the rest doesn't get checked (like double assignment, etc.)
		//for both players
/*		for (p = 0; p < 2; ++p)
		{
			//for all keys
			for (register int k = 0; k < 6; ++k)
			{
				if (data.ckey[p][k] < -3 || data.ckey[p][k] > 255 ||
					verify_key(data.ckey[p][k]) == false)
					data.ckey[p][k] = dataDEF.ckey[p][k];
			}
		}*/

		//con_color
		if (data.con_color.r < dataMIN.con_color.r)		data.con_color.r	= dataMIN.con_color.r;
		if (data.con_color.g < dataMIN.con_color.g)		data.con_color.g	= dataMIN.con_color.g;
		if (data.con_color.b < dataMIN.con_color.b)		data.con_color.b	= dataMIN.con_color.b;
		if (data.con_color.r > dataMAX.con_color.r)		data.con_color.r	= dataMAX.con_color.r;
		if (data.con_color.g > dataMAX.con_color.g)		data.con_color.g	= dataMAX.con_color.g;
		if (data.con_color.b > dataMAX.con_color.b)		data.con_color.b	= dataMAX.con_color.b;
		if (data.con_fcolor.r < dataMIN.con_fcolor.r)		data.con_fcolor.r	= dataMIN.con_fcolor.r;
		if (data.con_fcolor.g < dataMIN.con_fcolor.g)		data.con_fcolor.g	= dataMIN.con_fcolor.g;
		if (data.con_fcolor.b < dataMIN.con_fcolor.b)		data.con_fcolor.b	= dataMIN.con_fcolor.b;
		if (data.con_fcolor.r > dataMAX.con_fcolor.r)		data.con_fcolor.r	= dataMAX.con_fcolor.r;
		if (data.con_fcolor.g > dataMAX.con_fcolor.g)		data.con_fcolor.g	= dataMAX.con_fcolor.g;
		if (data.con_fcolor.b > dataMAX.con_fcolor.b)		data.con_fcolor.b	= dataMAX.con_fcolor.b;

		if (data.con_textcolor < dataMIN.con_textcolor)		data.con_textcolor	= dataMIN.con_textcolor;
		if (data.con_textcolor > dataMAX.con_textcolor)		data.con_textcolor	= dataMAX.con_textcolor;

		//con_frame, con_dropspeed, con_style
		if (data.con_frame < dataMIN.con_frame)		data.con_frame	= dataMIN.con_frame;
		if (data.con_frame > dataMAX.con_frame)		data.con_frame	= dataMAX.con_frame;
		if (data.con_dropspeed < dataMIN.con_dropspeed)		data.con_dropspeed	= dataMIN.con_dropspeed;
		if (data.con_dropspeed > dataMAX.con_dropspeed)		data.con_dropspeed	= dataMAX.con_dropspeed;
		if (data.con_style < dataMIN.con_style)		data.con_style	= dataMIN.con_style;
		if (data.con_style > dataMAX.con_style)		data.con_style	= dataMAX.con_style;

		//con_dim
		if (data.con_dim.left < dataMIN.con_dim.left)		data.con_dim.left	= dataMIN.con_dim.left;
		if (data.con_dim.right < dataMIN.con_dim.right)		data.con_dim.right	= dataMIN.con_dim.right;
		if (data.con_dim.top < dataMIN.con_dim.top)			data.con_dim.top	= dataMIN.con_dim.top;
		if (data.con_dim.bottom < dataMIN.con_dim.bottom)	data.con_dim.bottom	= dataMIN.con_dim.bottom;
		if (data.con_dim.left > dataMAX.con_dim.left)		data.con_dim.left	= dataMAX.con_dim.left;
		if (data.con_dim.right > dataMAX.con_dim.right)		data.con_dim.right	= dataMAX.con_dim.right;
		if (data.con_dim.top > dataMAX.con_dim.top)			data.con_dim.top	= dataMAX.con_dim.top;
		if (data.con_dim.bottom > dataMAX.con_dim.bottom)	data.con_dim.bottom	= dataMAX.con_dim.bottom;
	};

	//---- verify_key ----------------------------------------------------------------------------
	//checks for invalid (system) keys
	//if argumented key index is locked returns false else true

	bool verify_key(int i)
	{
		//limit
		if (i < 0 || i > 700)
			return(true);

		if (data.KEY_LOCK[i] == 1)
			return(false);
		else
			return(true);

/*		//true becaue of mouse buttons
		if (i < 0 || i > 255)
			return true;

		if (locked_key[i] == 1)
			return false;
		else
			return true;*/
	};

	//---- verify_player_names -------------------------------------------------------------------
	//checks player names for invalid lengths or locked strings
	//returns true if names didn't need to be adjusted, else returns false

	bool verify_player_names()
	{
		bool result = true;

		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//length
			//(check first and remove '_' afterwards)
			if (strlen(data.name[p]) < 1 || strlen(data.name[p]) > 20)
			{
				strcpy(data.name[p], dataDEF.name[p]);
				result = false;
			}

			//for every letter
			for (register int i = 0; i < 21; ++i)
			{
				//if character within name is _ change it to space
				//(_ acts as as subset for space because it causes trouble when loading a
				//string with space characters)
				if (data.name[p][i] == 95)
				{
					data.name[p][i]	= 32;
					result			= false;
				}
			}
		}

		//if name reservation
		if (!MINE)
			//for both players
			for (register int p = 0; p < 2; ++p)
			{
				//backup name and convert name to lower case
				char name_buffer[21];
				strcpy(name_buffer, data.name[p]);
				_strlwr(name_buffer);

				//if same or including locked string set default
				if (!strcmp(name_buffer, "twohours") || strstr(name_buffer, "twohours") != NULL)
				{
					strcpy(data.name[p], dataDEF.name[p]);
					result = false;
				}
				if (!strcmp(name_buffer, "two hours") || strstr(name_buffer, "two hours") != NULL)
				{
					strcpy(data.name[p], dataDEF.name[p]);
					result = false;
				}
				if (!strcmp(name_buffer, "2h") || strstr(name_buffer, "2h") != NULL)
				{
					strcpy(data.name[p], dataDEF.name[p]);
					result = false;
				}
				if (!strcmp(name_buffer, "vorlaut boy") || strstr(name_buffer, "vorlaut boy") != NULL)
				{
					strcpy(data.name[p], dataDEF.name[p]);
					result = false;
				}
				if (!strcmp(name_buffer, "vorlautboy") || strstr(name_buffer, "vorlautboy") != NULL)
				{
					strcpy(data.name[p], dataDEF.name[p]);
					result = false;
				}

				//cheats
				if (!strcmp(data.name[p], "fatigue"))
					gProgramOptions.xfatigue[p] = ON;
			}

		return(result);
	};
	
/*	//old version
	void verify_player_names()
	{
		//for both players
		for (register int p = 0; p < 2; ++p)
		{
			//for every letter
			for (register int i = 0; i < 21; ++i)
			{
				//if character within name is _ change it to space
				//(_ acts as as subset for space because it causes trouble when loading a
				//string with space characters)
				if (data.name[p][i] == 95)
					data.name[p][i] = 32;
			}

			//length
			if (strlen(data.name[p]) < 1 || strlen(data.name[p]) > 20)
				strcpy(data.name[p], dataDEF.name[p]);
		}

		//if name reservation
		if (!MINE)
			//for both players
			for (register int p = 0; p < 2; ++p)
			{
				//backup name and convert name to lower case
				char name_buffer[21];
				strcpy(name_buffer, data.name[p]);
				_strlwr(name_buffer);

				//if same or including locked string set default
				if (!strcmp(name_buffer, "twohours") || strstr(name_buffer, "twohours") != NULL)
					strcpy(data.name[p], dataDEF.name[p]);
				if (!strcmp(name_buffer, "two hours") || strstr(name_buffer, "two hours") != NULL)
					strcpy(data.name[p], dataDEF.name[p]);
				if (!strcmp(name_buffer, "2h") || strstr(name_buffer, "2h") != NULL)
					strcpy(data.name[p], dataDEF.name[p]);
				if (!strcmp(name_buffer, "vorlaut boy") || strstr(name_buffer, "vorlaut boy") != NULL)
					strcpy(data.name[p], dataDEF.name[p]);
				if (!strcmp(name_buffer, "vorlautboy") || strstr(name_buffer, "vorlautboy") != NULL)
					strcpy(data.name[p], dataDEF.name[p]);

				//cheats
				if (!strcmp(data.name[p], "fatigue"))
					gProgramOptions.xfatigue[p] = ON;
			}
	};*/

	//---- reset ---------------------------------------------------------------------------------

	void reset()
	{
		//reset all options to default
		data = dataDEF;
	};
};

//------------------------------------------------------------------------------------------------
//
//	player message data
//
//------------------------------------------------------------------------------------------------

struct player_message_data
{
	char		message[101];				//message string

	bool		active;
	point		cpos;						//current position of string
	point		opos;						//original position

	RGBcolor	b_color;					//border color
	RGBcolor	f_color;					//fill color
											//(original, doesn't get changed for colorfade)
	float		size;						//size of message

	float		time;						//display time of message in seconds
	LONGLONG	t_start;					//start time of displaying message

	int			colorfading;				//on or off
	float		t_colorfade;				//time in seconds after which color fade starts
	RGBcolor	b_color_fade;				//color target of fade on
	RGBcolor	f_color_fade;
	RGBcolor	b_color_adj;				//current to colorfade adjusted color
	RGBcolor	f_color_adj;

	int			scrolltype;					//defined ST_ types
	float		t_scrollswitch;				//time in seconds for scrolltype switch
	float		scrollspeed;				//in pixel per message (T_PMESSAGE)


	//---- constructor ---------------------------------------------------------------------------

	player_message_data()
	{
		ZeroMemory(&message, sizeof(message));
		active			= false;
		size			= 0;
		time			= 0;
		t_start			= 0;
		colorfading		= 0;
		t_colorfade		= 0;
		scrolltype		= 0;
		t_scrollswitch	= 0;
		scrollspeed		= 0;
	};

	//---- reset ---------------------------------------------------------------------------------

	void reset()
	{
		message[0]		= 0;
		active			= false;
		size			= 0;
		time			= 0;
		t_start			= 0;
		colorfading		= 0;
		t_colorfade		= 0;
		scrolltype		= 0;
		t_scrollswitch	= 0;
		scrollspeed		= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	player message
//
//------------------------------------------------------------------------------------------------

struct player_message
{
	player_message_data		pm[NPMESSAGES];				//player messages
	int						pm_sorted[NPMESSAGES];		//index of sorted player messages
														//(oldest to newest)
	int						cmessages;					//number of active player messages

	const options			*p_option;					//pointer to options
	const timer				*p_time;					//pointer to timer
	const point				*p_chead;					//pointer to player head

	//---- constructor ---------------------------------------------------------------------------

	player_message()
	{
		ZeroMemory(&pm_sorted, sizeof(pm_sorted));

		cmessages	= 0;

		p_option			= NULL;
		p_time				= NULL;
		p_chead				= NULL;
	};

	//---- set_data_pointer ----------------------------------------------------------------------

	//set pointer to timer and option data
	void set_data_pointer(options *_options, timer *_timer, point *_chead)
	{
		p_option			= _options;
		p_time				= _timer;
		p_chead				= _chead;
	};
	
	//---- reset ---------------------------------------------------------------------------------
	//resets argumented message, default resets all messages

	void reset(int slot = -1)
	{
		//reset all
		if (slot == -1)
		{
			for (register int s = 0; s < NPMESSAGES; ++s)
				pm[s].reset();

			//reset message counter
			cmessages	= 0;
		}
		else
		//reset argumented
		{
			//verify slot
			if (slot >= 0 && slot < NPMESSAGES)
			{
				//if active
				if (pm[slot].active)
				{
					pm[slot].reset();
					--cmessages;
				}
			}
		}
	};

	//---- get_message_slot ----------------------------------------------------------------------
	//if s_replace is not NULL it will reset and return
	//the first message slot that contains the string
	//else it will look for the next free slot or delete the oldest of none free

	int get_message_slot(char *s_replace = NULL)
	{
		//if message to be replaced find message
		if (s_replace != NULL)
		{
			//for all messages
			for (register int m = 0; m < NPMESSAGES; ++m)
			{
				//compare strings and substrings
				if (!strcmp(pm[m].message, s_replace) || strstr(pm[m].message, s_replace) != NULL)
				{
					//reset and return slot
					reset(m);
					return(m);
				}
			}
		}

		//for all message slots
		for (register int s = 0; s < NPMESSAGES; ++s)
		{
			//if slot not active
			if (!pm[s].active)
				//return slot index
				return(s);
		}

		//all slots full
		//get oldest message
		int i = 0;
		LONGLONG t_om = pm[i].t_start;
		for (s = 1; s < NPMESSAGES; ++s)
		{
			//if message older then previously stored
			if (pm[s].t_start < t_om)
			{
				//save new oldest time and index
				t_om	= pm[s].t_start;
				i		= s;
			}
		}

		//reset and return slot
		reset(i);
		return(i);
	};

	//---- set_message ---------------------------------------------------------------------------
	//formated text

	//pre-defined player message types
	void set_message(int pmtype, RGBcolor cfill, char *format, ...)
	{
		//---- copy string or number into new buffer -------------------------------------------------

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		//char *pbuffer	= new char[strlen(format) + 1];
		//copy message into buffer
		//vsprintf(pbuffer, format, ap);
		//honestly, i don't even know how it works anymore :(
		char pbuffer[101] = "";
		vsprintf(pbuffer, format, ap);

		//clear up
		va_end(ap);

		//----------------------------------------------------------------------------------------

		switch (pmtype)
		{
		case (PM_DEFAULT):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNSTAT,
							T_PMESSAGE * 0.75f, 0,
							NULL, pbuffer);
				break;
			}

		case (PM_STDDAMAGE):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.8f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNSTATUP_EX,
							T_PMESSAGE / 3.0f, 50.0f,
							NULL, pbuffer);
				break;
			}

		case (PM_POWERATTACK):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNSTAT,
							T_PMESSAGE * 0.75f, 0,
							NULL, pbuffer);
				break;
			}

		case (PM_COMBO):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNSTAT,
							T_PMESSAGE * 0.5f, 0,
							"Hits", pbuffer);
				break;
			}

		case (PM_FATDAMAGE):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNAMIC,
							T_PMESSAGE / 1.0f, 0,
							NULL, pbuffer);
				break;
			}

		case (PM_PUSHPULL):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNAMIC,
							0, 0,
							"Pu", pbuffer);
				break;
			}

		case (PM_KO):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNAMIC,
							0, 0,
							"!", pbuffer);
				break;
			}

		case (PM_GODLIKE):
			{
				//reset all other messages
				reset();

				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.45f,
							T_PMESSAGE,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNAMIC,
							0, 0,
							NULL, pbuffer);
				break;
			}

		case (PM_TAUNT):
			{
				set_message(0, 0, 0, cfill.r, cfill.g, cfill.b,
							0.35f,
							T_PMESSAGE * 1.5f,
							1, T_PMESSAGE * 0.75f,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							p_option->data.cbackground.r, p_option->data.cbackground.g, p_option->data.cbackground.b,
							ST_DYNAMIC,
							0, 0,
							NULL, pbuffer);
				break;
			}
		}

		//----------------------------------------------------------------------------------------

		//delete string buffer
		//delete []	pbuffer;
		//pbuffer		= NULL;
	};

	//all parameters
	void set_message(int br, int bg, int bb,						//border color
					 int fr, int fg, int fb,						//fill color
					 float _size,									//font size
					 float _time,									//message display time
					 int _colorfading, float _t_colorfade,			//on/off, time after cf start
					 int _bfr, int _bfg, int _bfb,					//target border color
					 int _ffr, int _ffg, int _ffb,					//target fill color
					 int _stype, float _t_scroll, float _sspeed,	//defined ST_ types, time after scrollswitch, scrollspeed in pixel per message
					 char *s_replace,								//replacement string
					 char *format, ...)
	{
		//---- copy string or number into new buffer -------------------------------------------------

		//argument pointer
		va_list		ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		//unsigned, else you get negativ values for the LUT
		unsigned char wordstring[101] = "";
		//copy message into buffer
		vsprintf((char *)wordstring, format, ap);

		//clear up
		va_end(ap);

		//----- get message slot -----------------------------------------------------------------

		//get free slot index
		int mslot = get_message_slot(s_replace);

		//increase message counter
		++cmessages;

		//---- assign data -----------------------------------------------------------------------

		//for every letter
		for (register int i = 0; i < 101; ++i)
		{
			//copy into message string
			pm[mslot].message[i] = wordstring[i];
			if (wordstring[i] == 0)
				i = 101;
		}

		pm[mslot].b_color.r	= br;		pm[mslot].b_color.g	= bg;		pm[mslot].b_color.b	= bb;
		pm[mslot].f_color.r	= fr;		pm[mslot].f_color.g	= fg;		pm[mslot].f_color.b	= fb;
		pm[mslot].b_color_adj		= pm[mslot].b_color;
		pm[mslot].f_color_adj		= pm[mslot].f_color;

		pm[mslot].size		= _size * p_option->data.zoomfactor;
		pm[mslot].time		= _time / p_option->data.speed;
		pm[mslot].t_start	= p_time->current;

		pm[mslot].colorfading		= _colorfading;
		pm[mslot].t_colorfade		= _t_colorfade / p_option->data.speed;
		pm[mslot].b_color_fade.r	= _bfr;		pm[mslot].b_color_fade.g	= _bfg;		pm[mslot].b_color_fade.b	= _bfb;
		pm[mslot].f_color_fade.r	= _ffr;		pm[mslot].f_color_fade.g	= _ffg;		pm[mslot].f_color_fade.b	= _ffb;

		pm[mslot].scrolltype		= _stype;
		pm[mslot].t_scrollswitch	= _t_scroll / p_option->data.speed;
		pm[mslot].scrollspeed		= _sspeed;

		//set original text position
		pm[mslot].opos.y	= p_chead->y - 50;
		pm[mslot].opos.x	= p_chead->x -
							  (strlen(pm[mslot].message) * 32.0f * pm[mslot].size + (strlen(pm[mslot].message) - 1.0f) * 3.0f * pm[mslot].size) / 2.0f;
		//current pos is original pos
		pm[mslot].cpos		= pm[mslot].opos;

		//activate message
		pm[mslot].active	= true;
	};

	//---- update --------------------------------------------------------------------------------

	void update(LONGLONG t_current, LONGLONG t_freq, float t_sca, point _chead)
	{
		//for all messages
		for (register int m = 0; m < NPMESSAGES; ++m)
		{
			//if message active
			if (pm[m].active)
			{
				//---- check time ----------------------------------------------------------------

				//deactivate if time up
				if (t_current > pm[m].t_start + (t_freq * pm[m].time))
				{
					reset(m);
					//!continues even if message just deactivated...
				}

				//--------------------------------------------------------------------------------

				//time passed since message start
				//for colorfading, text movement
				float tpass	= (float)(t_current - pm[m].t_start) / t_freq;
				//message time left in percentage (1.0 == 100%)
				float tleft = 1.0f - (tpass / pm[m].time);

				//---- text position -------------------------------------------------------------

				//no scrolling, stays where it started
				if (pm[m].scrolltype == ST_STATIC)
				{
					//pm[m].cpos		= pm[m].opos;
				}

				//no scrolling, stays above player
				if (pm[m].scrolltype == ST_DYNAMIC)
				{
					//set text position
					pm[m].cpos.y	= _chead.y - 50;
					pm[m].cpos.x	= _chead.x -
									  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;
				}

				//starts dynamic, becomes static after specified amount of time
				if (pm[m].scrolltype == ST_DYNSTAT)
				{
					//if time passed smaller than scrollswitch time
					//stay dynamic
					if ((float)(t_current - pm[m].t_start) / t_freq < pm[m].t_scrollswitch)
					{
						//set text position
						pm[m].cpos.y	= _chead.y - 50;
						pm[m].cpos.x	= _chead.x -
										  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;
					}
					else
					//static
					{
						//pm[m].cpos		= pm[m].cpos;
					}
				}

				//scrolls up where it started
				if (pm[m].scrolltype == ST_STATICUP)
				{
					//x stays the same
					//pm[m].cpos.x		= pm[m].opos.x;

					//y scroll
					pm[m].cpos.y		-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
				}

				//scrolls up above player
				if (pm[m].scrolltype == ST_DYNAMICUP)
				{
					//x pos
					pm[m].cpos.x	= _chead.x -
										  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;

					//y scroll
					pm[m].cpos.y	-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
				}

				//scrolls up dynamic, becomes static after specified amount of time
				if (pm[m].scrolltype == ST_DYNSTATUP)
				{
					//if time passed smaller than scrollswitch time
					//stay dynamic
					if ((float)(t_current - pm[m].t_start) / t_freq < pm[m].t_scrollswitch)
					{
						//x pos
						pm[m].cpos.x	= _chead.x -
										  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;

						//y scroll
						pm[m].cpos.y	-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
					}
					else
					//static
					{
						//x stays the same
						//pm[m].cpos.x	= pm[m].cpos.x;

						//y scroll
						pm[m].cpos.y	-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
					}
				}

				//stays dynamic over player without scrolling for 1/3 of message_time
				//after that it starts dynamic scrolling
				//after 2/3 of time it becomas static and continues scrolling
				if (pm[m].scrolltype == ST_DYNSTATUP_EX)
				{
					//if time passed smaller than scrollswitch time
					//stay dynamic, no scrolling
					if ((float)(t_current - pm[m].t_start) / t_freq < pm[m].t_scrollswitch)
					//dynamic, no scrolling
//					if ((float)(t_current - pm[m].t_start) / t_freq < pm[m].time / 3.0f)
					{
						//x pos
						pm[m].cpos.x	= _chead.x -
										  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;

						//y pos
						pm[m].cpos.y	= _chead.y - 50;
					}
					else
					{
						//dynamic, scrolling
//						if ((float)(t_current - pm[m].t_start) / t_freq < pm[m].time / 1.5f)
						{
							//x pos
//							pm[m].cpos.x	= _chead.x -
//											  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f;

							//limit dynamic x-movement speed to 150 pixel per seconds
							//decreasing with passed time
							if (pm[m].cpos.x < _chead.x -
											  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f)
								pm[m].cpos.x	+= 150.0f * tleft * p_option->data.speed * t_sca;
							if (pm[m].cpos.x > _chead.x -
											  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f)
								pm[m].cpos.x	-= 150.0f * tleft * p_option->data.speed * t_sca;

							//y scroll
							pm[m].cpos.y	-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
						}
/*						else
						//static, scrolling
						//-> redundant with dynamic x-movement speed change
						{
							//x stays the same
							//pm[m].cpos.x	= pm[m].cpos.x;
							//limit dynamic x-movement speed to 150 pixel per seconds
							//decreased with passed time
							if (pm[m].cpos.x < _chead.x -
											  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f)
								pm[m].cpos.x	+= 150.0f * tleft * p_option->data.speed * t_sca;
							if (pm[m].cpos.x > _chead.x -
											  (strlen(pm[m].message) * 32.0f * pm[m].size + (strlen(pm[m].message) - 1.0f) * 3.0f * pm[m].size) / 2.0f)
								pm[m].cpos.x	-= 150.0f * tleft * p_option->data.speed * t_sca;

							//y scroll
							pm[m].cpos.y	-= pm[m].scrollspeed / (T_PMESSAGE / p_option->data.speed) * t_sca;
						}*/
					}
				}

				//---- text color ----------------------------------------------------------------
				//linear change to target color over active time of message or
				//after t_colorfade passed

				//white flash for 0.1 sec
				//(independent from colorfading)
				if (tpass <= 0.1f / p_option->data.speed)	pm[m].f_color_adj = white;
				else										pm[m].f_color_adj = pm[m].f_color;

				//if colorfading
				if (pm[m].colorfading)
				{
					//passed time minus time after colorfade starts
					tpass	-= pm[m].t_colorfade;

					//if positive, do fade
					if (tpass > 0)
					{
						//border, fill color difference from target to current
						RGBcolor b_diff, f_diff;

						b_diff.r	= pm[m].b_color_fade.r - pm[m].b_color.r;
						b_diff.g	= pm[m].b_color_fade.g - pm[m].b_color.g;
						b_diff.b	= pm[m].b_color_fade.b - pm[m].b_color.b;
						f_diff.r	= pm[m].f_color_fade.r - pm[m].f_color.r;
						f_diff.g	= pm[m].f_color_fade.g - pm[m].f_color.g;
						f_diff.b	= pm[m].f_color_fade.b - pm[m].f_color.b;

						//color change speed in units/sec
						float b_diff_speed_r,
							  b_diff_speed_g,
							  b_diff_speed_b;
						float f_diff_speed_r,
							  f_diff_speed_g,
							  f_diff_speed_b;

						b_diff_speed_r	= (float)b_diff.r / (pm[m].time - pm[m].t_colorfade);
						b_diff_speed_g	= (float)b_diff.g / (pm[m].time - pm[m].t_colorfade);
						b_diff_speed_b	= (float)b_diff.b / (pm[m].time - pm[m].t_colorfade);
						f_diff_speed_r	= (float)f_diff.r / (pm[m].time - pm[m].t_colorfade);
						f_diff_speed_g	= (float)f_diff.g / (pm[m].time - pm[m].t_colorfade);
						f_diff_speed_b	= (float)f_diff.b / (pm[m].time - pm[m].t_colorfade);

						//adjust color
						pm[m].b_color_adj.r	= pm[m].b_color.r + (int)(b_diff_speed_r * tpass);
						pm[m].b_color_adj.g	= pm[m].b_color.g + (int)(b_diff_speed_g * tpass);
						pm[m].b_color_adj.b	= pm[m].b_color.b + (int)(b_diff_speed_b * tpass);
						pm[m].f_color_adj.r	= pm[m].f_color.r + (int)(f_diff_speed_r * tpass);
						pm[m].f_color_adj.g	= pm[m].f_color.g + (int)(f_diff_speed_g * tpass);
						pm[m].f_color_adj.b	= pm[m].f_color.b + (int)(f_diff_speed_b * tpass);

						//check limits
						if (pm[m].b_color_adj.r < 0)	pm[m].b_color_adj.r	= 0;
						if (pm[m].b_color_adj.g < 0)	pm[m].b_color_adj.g	= 0;
						if (pm[m].b_color_adj.b < 0)	pm[m].b_color_adj.b	= 0;
						if (pm[m].f_color_adj.r < 0)	pm[m].f_color_adj.r	= 0;
						if (pm[m].f_color_adj.g < 0)	pm[m].f_color_adj.g	= 0;
						if (pm[m].f_color_adj.b < 0)	pm[m].f_color_adj.b	= 0;
						if (pm[m].b_color_adj.r > 255)	pm[m].b_color_adj.r	= 255;
						if (pm[m].b_color_adj.g > 255)	pm[m].b_color_adj.g	= 255;
						if (pm[m].b_color_adj.b > 255)	pm[m].b_color_adj.b	= 255;
						if (pm[m].f_color_adj.r > 255)	pm[m].f_color_adj.r	= 255;
						if (pm[m].f_color_adj.g > 255)	pm[m].f_color_adj.g	= 255;
						if (pm[m].f_color_adj.b > 255)	pm[m].f_color_adj.b	= 255;
					}
				}
			}
		}

		//bubble sort messages oldest to newest (for drawing)
		LONGLONG	t_times[NPMESSAGES];
		LONGLONG	temp = 0;

		//indices
		for (m = 0; m < NPMESSAGES; ++m)
		{
			//copy of message times
			t_times[m]		= pm[m].t_start;
			pm_sorted[m]	= m;
		}

		//sort indices oldest message to newest
		for (register int n = NPMESSAGES - 1; n != 0; --n)
		{
			for (register int i = 0; i < n; ++i)
			{
				if (t_times[i] > t_times[i + 1])
				{
					//switch dummy array and array index
					temp				= t_times[i];
					t_times[i]			= t_times[i + 1];
					t_times[i + 1]		= temp;

					temp				= pm_sorted[i];
					pm_sorted[i]		= pm_sorted[i + 1];
					pm_sorted[i + 1]	= (int)temp;
				}
			}
		}
	};
};

//------------------------------------------------------------------------------------------------
//
//	player_data
//
//	contains pointer to player data
//
//------------------------------------------------------------------------------------------------

struct player_data
{
	int					*phost_id;					//pointer to host id

	bone				*pzb[38];					//pointer to bones of both players in z-order
	RECT				*p_rbhp[2];					//whole player hitboxes

	float				*p_fatigue[2];				//pointer to fatigue

	int					*p_blood_active[2];			//pointer to blood active flags
	particle_heap		*p_heap[2];					//pointer to particle heaps
	int					*p_bsize[2];				//number of particles to draw

	point				*p_chead[2];				//pointer to head center
	point				*p_cfistl[2], *p_cfistr[2];	//pointer to fist center

	int					*p_side[2];					//pointer to side
	int					*p_stance[2];				//pointer to stance

	point				*p_s_scale;					//pointer to shadow data
	int					*p_s_mpy;

	int					*p_winloss;					//pointer to wins and losses of players
	char				*p_rts;						//pointer to round time string
	int					*p_roundtime;				//pointer to round time
	float				*p_score[2];				//pointer to score of both players

	player_message		*p_message[2];				//pointer to player messages

	bool				*p_bot[2];					//if player is bot

	//---- constructor ---------------------------------------------------------------------------

	player_data()
	{
		phost_id			= NULL;

		//set to NULL
		for (register int i = 0; i < 38; ++i)
			pzb[i]			 = NULL;

		p_rbhp[P1]			= p_rbhp[P2]			= NULL;

		p_fatigue[P1]		= p_fatigue[P2]			= NULL;

		p_blood_active[P1]	= p_blood_active[P2]	= NULL;
		p_heap[P1]			= p_heap[P2]			= NULL;
		p_bsize[P1]			= p_bsize[P2]			= NULL;

		p_chead[P1]			= p_chead[P2]			= NULL;
		p_cfistl[P1]		= p_cfistl[P2]			= NULL;
		p_cfistr[P1]		= p_cfistr[P2]			= NULL;

		p_side[P1]			= p_side[P2]			= NULL;
		p_stance[P1]		= p_stance[P2]			= NULL;

		p_s_scale			= NULL;
		p_s_mpy				= NULL;

		p_winloss			= NULL;
		p_rts				= NULL;
		p_roundtime			= NULL;
		p_score[P1]			= p_score[P2]			= NULL;

		p_message[P1]		= p_message[P2]			= NULL;

		p_bot[P1]			= p_bot[P2]				= NULL;
	};

	//---- set_player_data -----------------------------------------------------------------------

	void set_player_data(int *_host_id,
						 point *s_scale, int *s_mpy,
						 skeleton *P1sk, skeleton *P2sk,
						 RECT *P1rbhp, RECT *P2rbhp,
						 int *_winloss,
						 char *_rts, int *_roundtime,
						 float *P1score, float *P2score,
						 float *P1fatigue, float *P2fatigue,
						 int *P1bactive, int *P2bactive,
						 particle_heap *P1heap, particle_heap *P2heap,
						 int *P1bsize, int *P2bsize,
						 point *P1chead, point *P2chead,
						 point *P1cfistl, point *P1cfistr,
						 point *P2cfistl, point *P2cfistr,
						 int *P1side, int *P2side,
						 int *P1stance_feet, int *P2stance_feet,
						 player_message *P1pm, player_message *P2pm,
						 bool *P1bot, bool *P2bot)
	{
		phost_id			= _host_id;

		p_s_scale			= s_scale;
		p_s_mpy				= s_mpy;

		for (register int i = 0; i < 19; ++i)
		{
			//pointer to all bones
			pzb[i]			= &P1sk->b[i];
			pzb[37 - i]		= &P2sk->b[i];
		}

		//whole player hitboxes
		p_rbhp[P1]			= P1rbhp;
		p_rbhp[P2]			= P2rbhp;

		//pointer to fatigue
		p_fatigue[P1]		= P1fatigue;
		p_fatigue[P2]		= P2fatigue;

		//pointer to blood active flags
		p_blood_active[P1]	= P1bactive;
		p_blood_active[P2]	= P2bactive;
		p_heap[P1]			= P1heap;
		p_heap[P2]			= P2heap;
		p_bsize[P1]			= P1bsize;
		p_bsize[P2]			= P2bsize;

		//pointer to head center
		p_chead[P1]			= P1chead;
		p_chead[P2]			= P2chead;

		//pointer to fist center
		p_cfistl[P1]		= P1cfistl;
		p_cfistr[P1]		= P1cfistr;
		p_cfistl[P2]		= P2cfistl;
		p_cfistr[P2]		= P2cfistr;

		//pointer to side
		p_side[P1]			= P1side;
		p_side[P2]			= P2side;

		//pointer to stance
		p_stance[P1]		= P1stance_feet;
		p_stance[P2]		= P2stance_feet;

		//point to winloss
		p_winloss			= _winloss;
		//round time string, round time
		p_rts				= _rts;
		p_roundtime			= _roundtime;
		//scores
		p_score[P1]			= P1score;
		p_score[P2]			= P2score;

		//player message
		p_message[P1]		= P1pm;
		p_message[P2]		= P2pm;

		//bot
		p_bot[P1]			= P1bot;
		p_bot[P2]			= P2bot;
	};
};

//------------------------------------------------------------------------------------------------
//
//	lock_data
//
//	contains data locked limbs
//
//------------------------------------------------------------------------------------------------

struct lock_data
{
	int								lock_def[4];			//defense and offense lock
	int								lock_off[4];			//left, right arm/leg

	int								lock_defc[4];			//context for defense
	int								lock_offc[4];			//context for offense
															//context index gets overwritten
															//for each lock of same limb
															//e.g. jab gets locked, offc = 0
															//jab_hook gets locked, offc = 1,
															//jab is unlocked

	int								angle_def[4];			//angle of lock
	int								angle_off[4];

	LONGLONG						ts_def[4];				//holds start time of locks
	LONGLONG						ts_off[4];

	float							stun_walk_bwd;			//
	float							stun_walk_fwd;
	LONGLONG						t_stun_bwd;
	LONGLONG						t_stun_fwd;

	//---- constructor ---------------------------------------------------------------------------

	lock_data()
	{
		reset();
	};

	//---- reset ---------------------------------------------------------------------------------

	void reset()
	{
		ZeroMemory(&lock_def, sizeof(lock_def));
		ZeroMemory(&lock_off, sizeof(lock_off));

		ZeroMemory(&lock_defc, sizeof(lock_defc));
		ZeroMemory(&lock_offc, sizeof(lock_offc));

		ZeroMemory(&angle_def, sizeof(angle_def));
		ZeroMemory(&angle_off, sizeof(angle_off));

		ZeroMemory(&ts_def, sizeof(ts_def));
		ZeroMemory(&ts_off, sizeof(ts_def));

		stun_walk_bwd	= stun_walk_fwd		= 1.0f;
		t_stun_bwd		= t_stun_fwd		= 0;
	};

	//---- set_lockstate -------------------------------------------------------------------------

	void set_lockstate(int type,						//offensive or defensive
					   int index,						//limb index
														//0 = left arm
														//1 = right arm
														//2 = left leg
														//3 = right leg
														//5 = left knee -> converted to 2
														//6 = right knee -> converted to 3
					   int context,						//context of limb
					   int state,						//ON or OFF
					   int angle,						//lock angle
					   LONGLONG t_current)				//lock start time
	{

		//verify
		if (index < 0 || index > 3)
		{
			return;
		}

		//if (index == act_kneel)		index = 2;
		//if (index == act_kneer)		index = 3;

		//if offensive lock set offensive lock
		if (type == OFFENSIVE)
		{
			lock_off[index]				= state;

			//either save or reset angle and starttime
			if (state == ON)
			{
				lock_offc[index]		= context;
				angle_off[index]		= angle;
				ts_off[index]			= t_current;
			}
			else
			{
				lock_offc[index]		= 0;
				angle_off[index]		= 0;
				ts_off[index]			= 0;
			}
		}
		else
		//defense lock
		{
			//lock for arms locks both arms
			if (index == 0 || index == 1)
			{
				lock_def[0] = lock_def[1]	= state;

				if (state == ON)
				{
					lock_defc[0]		= lock_defc[1]		= context;
					angle_def[0]		= angle_def[1]		= angle;
					ts_def[0]			= ts_def[1]			= t_current;
				}
				else
				{
					lock_defc[0]		= lock_defc[1]		= 0;
					angle_def[0]		= angle_def[1]		= 0;
					ts_def[0]			= ts_def[1]			= 0;
				}
			}
			else
			{
				lock_def[index]				= state;

				if (state == ON)
				{
					lock_defc[index]		= context;
					angle_def[index]		= angle;
					ts_def[index]			= t_current;
				}
				else
				{
					lock_defc[index]		= 0;
					angle_def[index]		= 0;
					ts_def[index]			= 0;
				}
			}
		}
	};

	//---- get_offlockstate ----------------------------------------------------------------------
	//for offense state
	//return true if limb locked, false if not
	//absolute limb values independent of asi
	//accepts knee indices (return leg status)

	bool get_offlockstate(int limb)						//0 to 5 (la, ra, ll, rl, lk, rk)
	{
		//limb limit
		if (limb < 0 || limb > 5)
			return(false);

		//knees are their legs
		if (limb == 4)		limb	= 2;
		if (limb == 5)		limb	= 3;

		if (lock_off[limb] == 1)
			return(true);
		else
			return(false);
	};

	//---- get_lockstate -------------------------------------------------------------------------
	//for offense state
	//return true if attack locked, false if not

	bool get_lockstate(int asi,							//current asi of player
					   int limb,						//attacking limb with asi 0
					   int context,						//context of attack
					   int angle_180,					//angle_180 of new attack
					   int angle_diff)					//angle difference to lock to be not locked
														//0 = always not locked for angle
														//-1 = always locked on angle
	{
		//limb index
		int lindex = limb;

		//get limb adjusted to current animation side index (asi)
		//left hand forward
		if (asi == 0 || asi == 2)
		{
			//limb index is same as argument
			lindex			= limb;
		}
		else
		//right hand forward
		{
			//select limb
			if (limb == 0)			lindex	= 1;
			if (limb == 1)			lindex	= 0;
			if (limb == 2)			lindex	= 3;
			if (limb == 3)			lindex	= 2;
		}

		//if context locked return locked no matter if angle difference is big enough
		if (lock_offc[lindex] == 1)
			return(true);

		//not locked
		if (lock_off[lindex] == 0)
		{
			return(false);
		}
		else
		//locked
		{
			//not locked for angle
			if (angle_diff == 0)
			{
				//unlock previously locked limb
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);
				return(false);
			}

			//always locked for angle
			if (angle_diff == -1)
			{
				return(true);
			}

			//if difference between locked angle and new angle >= argumented angle
			if (abs(angle_180 - angle_off[lindex]) >= angle_diff)
			{
				//unlock previously locked limb
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);
				return(false);
			}
			else
				return(true);
		}

/*		//if limb not locked or difference between locked angle and new angle >=
		//argumented angle
//		if (lock_off[lindex] != 1 || abs(angle_180 - angle_off[lindex]) >= angle_diff)
		//limb not locked
		if (lock_off[lindex] != 1)
		{

			//don't lock on angle or angle difference between locked angle and new angle >=
			//argumented angle
			if (angle_diff == 0 || abs(angle_180 - angle_off[lindex]) >= angle_diff)
			{
				//also unlock previously locked limb
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);

				return(false);
			}

			//always locked on angle or angle difference < argumented angle
			if (angle_diff == -1 || abs(angle_180 - angle_off[lindex]) < angle_diff)
				return(true);
			else
				return(false);
		}
		else
			return(true);*/

/*		//if limb not locked or difference between locked angle and new angle >=
		//argumented angle
		if (lock_off[lindex] != 1 || abs(angle_180 - angle_off[lindex]) >= angle_diff)
		{
			//if angle difference big enough also unlock previously locked limb
			if (abs(angle_180 - angle_off[lindex]) >= angle_diff)
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);

			return(false);
		}
		else
			return(true);*/

/*		//if check for pre- or non-context attack
		if (context == 0)
		{
			//if limb not locked or context limb locked
			//difference between locked angle and new angle >= argumented angle
			if ((lock_off[lindex] != 1 || lock_offc[lindex] != 0) ||
				abs(angle_180 - angle_off[lindex]) >= angle_diff)
			{
				//if angle difference big enough (and pre- or non-context attack) and
				//context not locked
				//unlock previously locked limb
				if (abs(angle_180 - angle_off[lindex]) >= angle_diff &&
					lock_offc[lindex] != 1)
					set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);

				//return unlocked
				return(false);
			}
			else
			//limb locked and angle difference not big enough
			//return locked
				return(true);
		}

		//if check for context attack
		if (context == 1)
		{
			//if locked
			if (lock_offc[lindex] == 1)
				//return locked
				return(true);
			else
				//else return unlocked
				return(false);
		}

		//default, but context is always either 0 or 1
		return(false);*/

//		if (context == 1)
//			if (lock_off[lindex] == 1)
//				return(true);
//			else
//				return(false);

		//if limb not locked or different context locked or difference between locked angle and new angle >= argument
//		if (lock_off[lindex] != 1 || lock_offc[lindex] != context || abs(angle_180 - angle_off[lindex]) >= angle_diff)
/*		if (lock_off[lindex] != 1 || abs(angle_180 - angle_off[lindex]) >= angle_diff)
		{
			//if angle difference big enough also unlock previously locked limb
			if (abs(angle_180 - angle_off[lindex]) >= angle_diff &&
				lock_offc[lindex] != 1)
				set_lockstate(OFFENSIVE, lindex, 0, OFF, 0, 0);

			return(false);
		}
		else
			return(true);*/
	};

	//---- get_lockstate -------------------------------------------------------------------------
	//for defense state
	//returns true if defense for bone locked, false if not
	//absolute bone

	bool get_lockstate(int bone)
	{
		//limb index
		int lindex = -1;

		if (bone == bsl || bone == baul || bone == ball)				lindex	= 0;
		if (bone == bsr || bone == baur || bone == balr)				lindex	= 1;
		if (bone == bhl || bone == blul || bone == blll || bone == bfl)	lindex	= 2;
		if (bone == bhr || bone == blur || bone == bllr || bone == bfr)	lindex	= 3;

		//lindex for extended state defense bone logic
		//always both arms
		if (bone == bn || bone == btul || bone == btll || bone == btur || bone == btlr)
			lindex	= 0;

		//bone not registered
		if (lindex == -1)
			return false;

		if (lock_def[lindex] == 1)
			return true;
		else
			return false;
	};

	//---- get_lockstate -------------------------------------------------------------------------
	//for defense state
	//returns true if defense for bone locked, false if not
	//argumented bone is for asi 0

	bool get_lockstate(int bone,						//index of bone to test if in defense lock
														//bone for asi 0
					   int asi)							//current asi of player
	{
		//limb index to test
		int lindex = -1;

		//left side forward
		if (asi == 0 || asi == 2)
		{
			if (bone == bsl || bone == baul || bone == ball)				lindex	= 0;
			if (bone == bsr || bone == baur || bone == balr)				lindex	= 1;
			if (bone == bhl || bone == blul || bone == blll || bone == bfl)	lindex	= 2;
			if (bone == bhr || bone == blur || bone == bllr || bone == bfr)	lindex	= 3;
		}
		else
		//right side forward
		{
			if (bone == bsl || bone == baul || bone == ball)				lindex	= 1;
			if (bone == bsr || bone == baur || bone == balr)				lindex	= 0;
			if (bone == bhl || bone == blul || bone == blll || bone == bfl)	lindex	= 3;
			if (bone == bhr || bone == blur || bone == bllr || bone == bfr)	lindex	= 2;
		}

		//bone not registered
		if (lindex == -1)
		{
			gf_logger(true, "lock_data::get_lockstate(2) bone not registered %i", bone);
			return(false);
		}

		if (lock_def[lindex] == 1)
			return(true);
		else
			return(false);
	};
};

//------------------------------------------------------------------------------------------------
//
//	data_startup
//
//	contains data for startup sequence
//
//------------------------------------------------------------------------------------------------

struct data_startup
{
	//startup state
	BYTE					state;		//0 = ph uninitialized
										//1 = ph initialized
										//2 = c_scheme reinitialized
										//3 = font done
	BYTE					soundflag;	//0 = unplayed
										//1 = played

	//start of particle heap
	LONGLONG				t_start;

	//background color
	RGBcolor				cbackground;

	//color scheme and random number for sub-scheme
	int						c_scheme;
	int						r_no;

	//particle heap
	particle_heap			pfx;

	//number of particles to show
	float					p_show;

	//---- constructor ---------------------------------------------------------------------------

	data_startup()
	{
		state		= 0;		soundflag	= 0;
		t_start		= 0;

		c_scheme	= 0;		r_no		= 0;
		p_show		= 0;
	};

	//---- destructor ----------------------------------------------------------------------------

/*	~data_startup()
	{
		if (pfx.pp != NULL)
		{
			delete [] pfx.pp;
			pfx.pp	= NULL;
		}
	};*/
};

//------------------------------------------------------------------------------------------------
//
//	data_title
//
//	contains data for title sequence
//
//------------------------------------------------------------------------------------------------

struct data_title
{
	BYTE					state;			//0 = title uninitialized
											//1 = title initialized/yinyang zoom in
											//2 = beatmaster move in
											//3 = standard idling
											//4 = fade back in from black
											//5 = fade back in from white

	BYTE					style;			//0 = horizontal alignment
											//1 = vertical alignment

	yinyang					yy;				//yinyang symbol

	point					tm;				//position of trademark symbol
	point					version;		//position of version
	point					date;			//position of date

	int						selection;		//selected option by keyboard (fight!, options, exit)
	int						last_input;		//last input, 0 = kb, 1 = mouse
	RECT					c_selection[4];	//mouse cursor selection areas
											//same index as selection
											//last index includes the whole options section

	float					pos_beat;		//position of "beat"
	float					pos_master;		//position of "master"

	//---- constructor ---------------------------------------------------------------------------

	data_title()
	{
		state				= 0;
		style				= 0;

		selection			= 0;
		last_input			= 0;

		pos_beat			= 0.0f;			pos_master	= 0.0f;
	};
};

//------------------------------------------------------------------------------------------------
//
//	option slot
//
//	new version of option entry
//
//------------------------------------------------------------------------------------------------

struct option_slot
{
	BYTE					set;				//if slot is filled or not
	BYTE					locked;				//if slot is available

	ipoint					slot;				//x, y slot (NOT coordinates!)
	ipoint					pos_qual;			//qualifier x, y screen coordinates
	ipoint					pos_data;			//data offset from pos as x, y coordinates
	RECT					r_pos_qual;			//rectangle enclosing qualifier
	RECT					r_pos_data[3];		//rectangle enclosing data
	ipoint					qoff;				//qualifier and data offsets to default position
	ipoint					doff;

	void					*p_data;			//pointer to option data, default, min and max
	void					*p_dataDEF;
	void					*p_dataMIN;
	void					*p_dataMAX;
	char					data_string[50];	//contains formatted data as string

	int						selection;			//see defines

	char					*qualifier;			//displayed name of option
	float					bmf_size;			//size of bmfont
	float					slf_size;			//size of slfont

	int						color_scheme;		//color scheme, defined
	int						o_type;				//option type, defined
	int						d_type;				//data type, defined
	double					inc_type;			//data incrementation type, defined

	//additional data
	char					**p_lutDIK_DESC;	//pointer to DI description LUT
	UINT					RIMn;				//number of all raw input mice

	//---- constructor ---------------------------------------------------------------------------

	option_slot()
	{
		set					= 0;
		locked				= 0;

		ZeroMemory(&r_pos_qual, sizeof(r_pos_qual));
		ZeroMemory(&r_pos_data, sizeof(r_pos_data));

		p_data				= NULL;
		p_dataDEF			= NULL;
		p_dataMIN			= NULL;
		p_dataMAX			= NULL;
		ZeroMemory(&data_string, sizeof(data_string));

		selection			= SEL_NONE;

		qualifier			= NULL;
		bmf_size			= 1.0f;
		slf_size			= 1.0f;

		color_scheme		= OCS_DEF;
		o_type				= OT_DEF;
		d_type				= ODT_DEF;
		inc_type			= OIT_DEF;

		p_lutDIK_DESC		= NULL;
		RIMn				= 0;
	};

	//---- fill slot -----------------------------------------------------------------------------
	//fills entry with given data

	void fill_slot(int slotx, int sloty,							//slot coordinates
				   char *qual,										//qualifier
				   BYTE _lock,										//if locked
				   void *pd, void *pddef, void *pdmin, void *pdmax,	//pointer to data
				   int otype, int dtype, double itype, int color,	//option type, data type, increment type, color scheme
				   int qoffx, int qoffy, int doffx, int doffy,		//qualifier/data offset
				   float _bmf_size, float _slf_size)				//bitmap/scanline font size
	{
		set					= 1;
		locked				= _lock;

		slot.x				= slotx;
		slot.y				= sloty;

		qoff.x				= qoffx;
		qoff.y				= qoffy;
		doff.x				= doffx;
		doff.y				= doffy;

		p_data				= pd;
		p_dataDEF			= pddef;
		p_dataMIN			= pdmin;
		p_dataMAX			= pdmax;

		qualifier			= qual;
		bmf_size			= _bmf_size;
		slf_size			= _slf_size;

		color_scheme		= color;
		o_type				= otype;
		d_type				= dtype;
		inc_type			= itype;

		//set qualifier/data coordinates, adjusted with offsets
		set_position_data();
	};

	//---- set position data ----------------------------------------------------------------------
	//default position for qualifier and data and qualifier and data rectangles

	void set_position_data()
	{
		//gf_logger(true, "option_slot::set_default_position_data() slot: %i, %i", slot.x, slot.y);

		//set qualifier coordinates
		pos_qual.x			= slot.x * 200 + 10;
		pos_qual.y			= slot.y * 20 + 90;
		if (slot.y > 9)
			pos_qual.y		= slot.y * 20 + 90 + 20;
		//set data coordinates
		pos_data.x			= pos_qual.x + 120;
		pos_data.y			= pos_qual.y;

		//offsets
		pos_qual.x			+= qoff.x;
		pos_qual.y			+= qoff.y;
		pos_data.x			+= doff.x;
		pos_data.y			+= doff.y;

		//set (default) qualifier rectangles
		r_pos_qual.left		= pos_qual.x;
		r_pos_qual.top		= pos_qual.y;
		r_pos_qual.right	= r_pos_qual.left + (15 * 8);
		r_pos_qual.bottom	= r_pos_qual.top + (1 * 16);

		//set (default) data rectangles
		for (int s = 0; s < 3; ++s)
		{
			r_pos_data[s].left		= pos_data.x + (3 * 8 * s);
			r_pos_data[s].top		= pos_data.y;
			r_pos_data[s].right		= r_pos_data[s].left + (3 * 8);
			r_pos_data[s].bottom	= r_pos_data[s].top + (1 * 16);
		}
	};

	//---- set qualifier box -------------------------------------------------------------------
	//sets rectangle around option qualifier
	//adjusts x and y length (.right and .bottom)
	//must have valid non-NULL qualifier, else default set

	void set_qualifier_box(int type = 0)
	{
		//if no qualifier
		if (qualifier == NULL)
		{
			//reset default
			//r_pos_qual.right	= r_pos_qual.left + 120;
			//r_pos_qual.bottom	= r_pos_qual.top + 19;
			return;
		}

		//bitmap font
		if (type == 0)
		{
			r_pos_qual.left		= pos_qual.x + BBOQ_BMF_X;
			//left plus length * 8 (bitmap font width times size)
			r_pos_qual.right	= (long)(r_pos_qual.left + (strlen(qualifier) * (8.0f * bmf_size)));
			r_pos_qual.right	-= BBOQ_BMF_X;
//			r_pos_qual.right	= r_pos_data[0].left;
			//top plus 16 (bitmap font height times size)
			r_pos_qual.bottom	= (long)(r_pos_qual.top + (16.0f * bmf_size));
			return;
		}

		//scanline font
		if (type == 1)
		{
			r_pos_qual.left		= pos_qual.x + BBOQ_SLF_X;
			//scanline font width 32 + 3 (separator between slf letters) times size
			r_pos_qual.right	= (long)(r_pos_qual.left + (strlen(qualifier) * ((32 + 3) * slf_size)));
			r_pos_qual.right	-= BBOQ_SLF_X;
//			r_pos_qual.right	= r_pos_data[0].left;
			//scanline font height 58 times size
			r_pos_qual.bottom	= (long)(r_pos_qual.top + 58.0f * slf_size);
			return;
		}
	};

	//---- set data box ------------------------------------------------------------------------
	//sets rectangle around option data
	//adjusts x and y length (.right and .bottom)
	//retrieves formatted data string first

	void set_data_box(int type = 0)
	{
		//get current represented data in formatted string
		get_data_string();

/*		//no valid data
		if (p_data == NULL)
		{
			//reset default
			for (int s = 0; s < 3; ++s)
			{
				//r_pos_data[s].left	= pos_data.x - 8 + (s * 21);
				//r_pos_data[s].right	= r_pos_data[s].left + 20;
			}
			return;
		}*/

		//option type
		switch (o_type)
		{
		//same for most data types
		//only first data value valid
		case (OT_DEF):
		case (OT_ONOFF):
		case (OT_INTOFF):
		case (OT_INT):
		case (OT_FLOAT):
		case (OT_STRING):
		case (OT_INPUT):
		case (OT_MOUSE):
			{
				//only first data rectangle valid
				//bitmap font
				if (type == 0)
				{
					r_pos_data[0].left		= pos_data.x + BBOD_BMF_X;
					r_pos_data[0].right		= (long)(r_pos_data[0].left + (strlen(data_string) * (8.0f * bmf_size)));
					r_pos_data[0].right		-= BBOD_BMF_X;
					r_pos_data[0].bottom	= (long)(r_pos_data[0].top + (16.0f * bmf_size));
				}
				//scanline font
				if (type == 1)
				{
					r_pos_data[0].left		= pos_data.x + BBOD_SLF_X;
					r_pos_data[0].right		= (long)(r_pos_data[0].left + (strlen(data_string) * ((32 + 3) * slf_size)));
					r_pos_data[0].right		-= BBOD_SLF_X;
					r_pos_data[0].bottom	= (long)(r_pos_data[0].top + 58.0f * slf_size);
				}
				//remaining rectangles invalid
				for (int s = 1; s < 3; ++s)
				{
					r_pos_data[s].left		= -1;			r_pos_data[s].right		= -1;
					r_pos_data[s].top		= -1;			r_pos_data[s].bottom	= -1;
				}
				break;
			}

		//all three data values valid
		case (OT_RGB):
			{
				for (int s = 0; s < 3; ++s)
				{
					//bitmap font
					if (type == 0)
					{
						r_pos_data[s].left		= (long)(pos_data.x + (s * (4 * (8.0f * bmf_size))));
						r_pos_data[s].left		+= BBOD_BMF_X;
						r_pos_data[s].right		= (long)(r_pos_data[s].left + (strlen("000") * (8.0f * bmf_size)));
						r_pos_data[s].right		-= BBOD_BMF_X;
						r_pos_data[s].bottom	= (long)(r_pos_data[s].top + (16.0f * bmf_size));
					}
					//scanline font
					if (type == 1)
					{
						r_pos_data[s].left		= (long)(pos_data.x + (s * (4 * ((32 + 3) * slf_size))));
						r_pos_data[s].left		+= BBOD_SLF_X;
						r_pos_data[s].right		= (long)(r_pos_data[s].left + (strlen("000") * ((32 + 3) * slf_size)));
						r_pos_data[s].right		-= BBOD_SLF_X;
						r_pos_data[s].bottom	= (long)(r_pos_data[s].top + 58.0f * slf_size);
						//gf_logger(true, "%.4f, %.4f", (float)r_pos_data[s].left, (float)r_pos_data[s].right);
						//gf_logger(true, "	%.4f, %.4f", pos_data.x - 0 + (s * (4 * ((32 + 3) * slf_size))), r_pos_data[s].left + 0 + (strlen("000") * ((32 + 3) * slf_size)));
					}
				}
				break;
			}

		//no data
		case (OT_SYS):
			{
				//all invalid
				for (int s = 0; s < 3; ++s)
				{
					r_pos_data[s].left		= -1;			r_pos_data[s].right		= -1;
					r_pos_data[s].top		= -1;			r_pos_data[s].bottom	= -1;
				}
				break;
			}
		}
	};

	//---- get data string -------------------------------------------------------------------
	//formats data of option entry into string depending on option type

	char *get_data_string()
	{
		//verify
		if (p_data == NULL)
		{
			strcpy(data_string, "DATA NULL");
			//return(data_string);
		}

		//option type
		switch (o_type)
		{
		case (OT_DEF):
			{
				strcpy(data_string, "OT_DEF");
				break;
			}

		case (OT_ONOFF):
			{
				//on or off
				if (*(int*)p_data == 0)		strcpy(data_string, "OFF");
				else						strcpy(data_string, "ON");
				break;
			}

		case (OT_INTOFF):
			{
				//off or convert to string
				if (*(int*)p_data == 0)		strcpy(data_string, "OFF");
				else						_itoa(*(int*)p_data, data_string, 10);
				break;
			}

		case (OT_INT):
			{
				//convert int to string
				_itoa(*(int*)p_data, data_string, 10);
				break;
			}

		case (OT_FLOAT):
			{
				//convert float to string
				//_gcvt(*(float*)p_data, 2, data_string);
				sprintf(data_string, "%.1f", *(float*)p_data);
				break;
			}

		case (OT_STRING):
			{
				//copy string
				strcpy(data_string, (char*)p_data);
				break;
			}

		case (OT_RGB):
			{
				//create "r g b" ("255 255 255") string
/*				char ctemp[4] = "";
				_itoa(((int*)p_data)[0], ctemp, 10);
				strcpy(data_string, ctemp);
				strcat(data_string, " ");
				_itoa(((int*)p_data)[1], ctemp, 10);
				strcat(data_string, ctemp);
				strcat(data_string, " ");
				_itoa(((int*)p_data)[2], ctemp, 10);
				strcat(data_string, ctemp);*/
				//sprintf(data_string, "%i %i %i", ((int*)p_data)[0], ((int*)p_data)[1], ((int*)p_data)[2]);

				//create "rrr ggg bbb" string
				int *r = &((int*)p_data)[0];
				int *g = &((int*)p_data)[1];
				int *b = &((int*)p_data)[2];
				char ctemp[4] = "";
				_itoa(*r, ctemp, 10);
				strcpy(data_string, ctemp);
				strcat(data_string, " ");
				_itoa(*g, ctemp, 10);
				if (*r < 10)				strcat(data_string, "  ");
				if (*r > 9 && *r < 100)		strcat(data_string, " ");
				strcat(data_string, ctemp);
				strcat(data_string, " ");
				_itoa(*b, ctemp, 10);
				if (*g < 10)				strcat(data_string, "  ");
				if (*g > 9 && *g < 100)		strcat(data_string, " ");
				strcat(data_string, ctemp);
				break;
			}

		case (OT_INPUT):
			{
				//if no valid look up table
				if (p_lutDIK_DESC == NULL)
				{
					strcpy(data_string, "p_lutDIK_DESC == NULL");
					break;
				}

				//indexed direct input key
				int dik = *(int*)p_data;

				//if argument is keyboard button
				if (dik >= 0 && dik <= 255)
				{
					strcpy(data_string, p_lutDIK_DESC[dik]);
					break;
				}

				//argument is mouse/controller button
				if (dik == 300)				strcpy(data_string, "M0B0");
				if (dik == 301)				strcpy(data_string, "M0B1");
				if (dik == 302)				strcpy(data_string, "M0B2");
				if (dik == 303)				strcpy(data_string, "M0B3");
				if (dik == 400)				strcpy(data_string, "M1B0");
				if (dik == 401)				strcpy(data_string, "M1B1");
				if (dik == 402)				strcpy(data_string, "M1B2");
				if (dik == 403)				strcpy(data_string, "M1B3");
				if (dik == 305)				strcpy(data_string, "M0WU");
				if (dik == 306)				strcpy(data_string, "M0WD");
				if (dik == 405)				strcpy(data_string, "M1WU");
				if (dik == 406)				strcpy(data_string, "M1WD");
				if (dik == 500)				strcpy(data_string, "C0B0");
				if (dik == 501)				strcpy(data_string, "C0B1");
				if (dik == 502)				strcpy(data_string, "C0B2");
				if (dik == 503)				strcpy(data_string, "C0B3");
				if (dik == 504)				strcpy(data_string, "C0B4");
				if (dik == 505)				strcpy(data_string, "C0B5");
				if (dik == 506)				strcpy(data_string, "C0B6");
				if (dik == 507)				strcpy(data_string, "C0B7");
				if (dik == 508)				strcpy(data_string, "C0B8");
				if (dik == 509)				strcpy(data_string, "C0B9");
				if (dik == 510)				strcpy(data_string, "C0B10");
				if (dik == 511)				strcpy(data_string, "C0B11");
				if (dik == 512)				strcpy(data_string, "C0B12");
				if (dik == 513)				strcpy(data_string, "C0B13");
				if (dik == 514)				strcpy(data_string, "C0B14");
				if (dik == 515)				strcpy(data_string, "C0B15");
				if (dik == 516)				strcpy(data_string, "C0B16");
				if (dik == 517)				strcpy(data_string, "C0B17");
				if (dik == 518)				strcpy(data_string, "C0B18");
				if (dik == 519)				strcpy(data_string, "C0B19");
				if (dik == 520)				strcpy(data_string, "C0B20");
				if (dik == 600)				strcpy(data_string, "C1B0");
				if (dik == 601)				strcpy(data_string, "C1B1");
				if (dik == 602)				strcpy(data_string, "C1B2");
				if (dik == 603)				strcpy(data_string, "C1B3");
				if (dik == 604)				strcpy(data_string, "C1B4");
				if (dik == 605)				strcpy(data_string, "C1B5");
				if (dik == 606)				strcpy(data_string, "C1B6");
				if (dik == 607)				strcpy(data_string, "C1B7");
				if (dik == 608)				strcpy(data_string, "C1B8");
				if (dik == 609)				strcpy(data_string, "C1B9");
				if (dik == 610)				strcpy(data_string, "C1B10");
				if (dik == 611)				strcpy(data_string, "C1B11");
				if (dik == 612)				strcpy(data_string, "C1B12");
				if (dik == 613)				strcpy(data_string, "C1B13");
				if (dik == 614)				strcpy(data_string, "C1B14");
				if (dik == 615)				strcpy(data_string, "C1B15");
				if (dik == 616)				strcpy(data_string, "C1B16");
				if (dik == 617)				strcpy(data_string, "C1B17");
				if (dik == 618)				strcpy(data_string, "C1B18");
				if (dik == 619)				strcpy(data_string, "C1B19");
				if (dik == 620)				strcpy(data_string, "C1B20");
				break;

				//not found
				strcpy(data_string, NOTAVAILABLE);
				break;
			}

		case (OT_MOUSE):
			{
				//sprintf(data_string, "MOUSE %i", *(int*)p_data);
				//sprintf(data_string, "%i", *(int*)p_data);
				//sprintf(data_string, "%i/%i", *(int*)p_data, RIMn - 1);
				sprintf(data_string, "%i/%i", *(int*)p_data + 1, RIMn);
				break;
			}

		case (OT_SYS):
			{
				//empty
				strcpy(data_string, "");
				break;
			}

		default:
			{
				strcpy(data_string, "NO DATA TYPE HANDLER");
			}
		}

		return(data_string);
	};

	//---- set_selection -------------------------------------------------------------------------
	//sets selection status of option entry
	//defined

	bool set_selection(int sel)
	{
		//verify
		switch (sel)
		{
		case (SEL_NONE):
		case (SEL_QUAL):
		case (SEL_DAT1):
		case (SEL_DAT2):
		case (SEL_DAT3):
		case (SEL_DATA):
		case (SEL_ALL):
		case (SEL_PRE):
			{
			selection = sel;
			return(true);
			}
		}

		//no valid selection
		return(false);
	};

	//---- increase data --------------------------------------------------------------------------
	//increase data of option entry
	//by set increment type
	//and depending on selection within data

	bool increase_data()
	{
		//locked
		if (locked)
			return(false);

		//no data
		if (p_data == NULL || p_dataDEF == NULL || p_dataMIN == NULL || p_dataMAX == NULL)
			return(false);

		//no direct change for input
		if (o_type == OT_INPUT)
			return(false);

		//integer
		if (d_type == ODT_INT)
		{
			//direct pointers to data
			int *pd		= (int*)p_data;
			int *pdDEF	= (int*)p_dataDEF;
			int *pdMIN	= (int*)p_dataMIN;
			int *pdMAX	= (int*)p_dataMAX;

			//incrementation type (defined)
			int inc		= (int)inc_type;

			//special hardcoded types
			//fps_max, round time
			if (!stricmp(qualifier, "Maximum FPS")||
				!stricmp(qualifier, "Round Time"))
			{
				//increase data or set to specified minimum
				if (*pd + inc <= *pdMAX)	*pd += inc;
				else						*pd = 0;

				if (*pd < *pdMIN && *pd != 0)
					*pd = *pdMIN;

				return(true);
			}
			//motion blur
			if (MBLUR_LIMIT)
				if (!stricmp(qualifier, "MotionBlur"))
				{
					//increase data, and only allow non !(%3) values (except 0)
					//(triple buffering with %3 values causes the screen never to be redrawn)
					if (*pd + inc <= *pdMAX)	*pd += inc;
					else						*pd = *pdMIN;
					while (*pd != 0 && !(*pd % 3))
					{
						if (*pd + inc <= *pdMAX)	*pd += inc;
						else						*pd = *pdMIN;
					}

					return(true);
				}

			//no toggle
			if (false)
				if (o_type == OT_ONOFF)
				{
					if (*pd + inc <= *pdMAX)
					{
						*pd += inc;
						return(true);
					}
					else
						return(false);
				}

			//increase data or set to specified minimum
			if (*pd + inc <= *pdMAX)	*pd += inc;
			else						*pd = *pdMIN;

			return(true);
		}

		//float
		if (d_type == ODT_FLOAT)
		{
			float *pd		= (float*)p_data;
			float *pdDEF	= (float*)p_dataDEF;
			float *pdMIN	= (float*)p_dataMIN;
			float *pdMAX	= (float*)p_dataMAX;

			float inc		= (float)inc_type;

			if (*pd + inc <= *pdMAX)	*pd += inc;
			else						*pd = *pdMIN;

			return(true);
		}

		//RGBcolor
		if (d_type == ODT_RGB)
		{
			int inc		= (int)inc_type;

			//only qualifier selected
			if (selection & SEL_QUAL)
			{
				RGBcolor *pd	= (RGBcolor*)p_data;
				RGBcolor *pdDEF	= (RGBcolor*)p_dataDEF;
				RGBcolor *pdMIN	= (RGBcolor*)p_dataMIN;
				RGBcolor *pdMAX	= (RGBcolor*)p_dataMAX;

				//r
				if (pd->r + inc <= pdMAX->r)	pd->r += inc;
				else							pd->r = pdMIN->r;
				//g
				if (pd->g + inc <= pdMAX->g)	pd->g += inc;
				else							pd->g = pdMIN->g;
				//b
				if (pd->b + inc <= pdMAX->b)	pd->b += inc;
				else							pd->b = pdMIN->b;

				return(true);
			}

			int *pd		= NULL;
			int *pdDEF	= NULL;
			int *pdMIN	= NULL;
			int *pdMAX	= NULL;
			if (selection & SEL_DAT1)
			{
				pd		= &((RGBcolor*)p_data)->r;
				pdDEF	= &((RGBcolor*)p_dataDEF)->r;
				pdMIN	= &((RGBcolor*)p_dataMIN)->r;
				pdMAX	= &((RGBcolor*)p_dataMAX)->r;
			}
			if (selection & SEL_DAT2)
			{
				pd		= &((RGBcolor*)p_data)->g;
				pdDEF	= &((RGBcolor*)p_dataDEF)->g;
				pdMIN	= &((RGBcolor*)p_dataMIN)->g;
				pdMAX	= &((RGBcolor*)p_dataMAX)->g;
			}
			if (selection & SEL_DAT3)
			{
				pd		= &((RGBcolor*)p_data)->b;
				pdDEF	= &((RGBcolor*)p_dataDEF)->b;
				pdMIN	= &((RGBcolor*)p_dataMIN)->b;
				pdMAX	= &((RGBcolor*)p_dataMAX)->b;
			}
			if (pd == NULL)
				return(false);

			if (*pd + inc <= *pdMAX)	*pd += inc;
			else						*pd = *pdMIN;

			return(true);
		}

		//bool
		if (d_type == ODT_BOOL)
		{
			//switch and check for limits
			*(bool*)p_data	= !*(bool*)p_data;
			if (*(bool*)p_data < *(bool*)p_dataMIN)
				*(bool*)p_data = *(bool*)p_dataMIN;
			if (*(bool*)p_data > *(bool*)p_dataMAX)
				*(bool*)p_data = *(bool*)p_dataMAX;

			return(true);
		}

		//no data handler found
		return(false);
	};

	//---- decrease data --------------------------------------------------------------------------
	//decrease data of option entry
	//by set increment type
	//and depending on selection within data

	bool decrease_data()
	{
		//locked
		if (locked)
			return(false);

		//no data
		if (p_data == NULL || p_dataDEF == NULL || p_dataMIN == NULL || p_dataMAX == NULL)
			return(false);

		//no direct change for input
		if (o_type == OT_INPUT)
			return(false);

		//integer
		if (d_type == ODT_INT)
		{
			//direct pointers to data
			int *pd		= (int*)p_data;
			int *pdDEF	= (int*)p_dataDEF;
			int *pdMIN	= (int*)p_dataMIN;
			int *pdMAX	= (int*)p_dataMAX;

			//incrementation type (defined)
			int inc		= (int)inc_type;

			//special hardcoded types
			//!! special flag instead of string comparison?
			//fps_max, round time
			if (!stricmp(qualifier, "Maximum FPS")||
				!stricmp(qualifier, "Round Time"))
			{
				if (*pd - inc >= 0)			*pd -= inc;
				else						*pd = *pdMAX;

				if (*pd < *pdMIN && *pd != 0)
					*pd = 0;

				return(true);
			}
			//motion blur
			if (MBLUR_LIMIT)
				if (!stricmp(qualifier, "MotionBlur"))
				{
					//decrease data, and only allow non !(%3) values (except 0)
					//(triple buffering with %3 values causes the screen never to be redrawn)
					if (*pd - inc >= *pdMIN)	*pd -= inc;
					else						*pd = *pdMAX;
					while (*pd != 0 && !(*pd % 3))
					{
						if (*pd - inc >= *pdMIN)	*pd -= inc;
						else						*pd = *pdMAX;
					}

					return(true);
				}

			//no toggle
			if (false)
				if (o_type == OT_ONOFF)
				{
					if (*pd - inc >= *pdMIN)
					{
						*pd -= inc;
						return(true);
					}
					else
						return(false);
				}

			//decrease data or set to specified maximum
			if (*pd - inc >= *pdMIN)	*pd -= inc;
			else						*pd = *pdMAX;

			return(true);
		}

		//float
		if (d_type == ODT_FLOAT)
		{
			float *pd		= (float*)p_data;
			float *pdDEF	= (float*)p_dataDEF;
			float *pdMIN	= (float*)p_dataMIN;
			float *pdMAX	= (float*)p_dataMAX;

			float inc		= (float)inc_type;

			if (*pd - inc >= *pdMIN)	*pd -= inc;
			else						*pd = *pdMAX;

			return(true);
		}

		//RGBcolor
		if (d_type == ODT_RGB)
		{
			int inc		= (int)inc_type;

			//only qualifier selected
			if (selection & SEL_QUAL)
			{
				RGBcolor *pd	= (RGBcolor*)p_data;
				RGBcolor *pdDEF	= (RGBcolor*)p_dataDEF;
				RGBcolor *pdMIN	= (RGBcolor*)p_dataMIN;
				RGBcolor *pdMAX	= (RGBcolor*)p_dataMAX;

				//r
				if (pd->r - inc >= pdMIN->r)	pd->r -= inc;
				else							pd->r = pdMAX->r;
				//g
				if (pd->g - inc >= pdMIN->g)	pd->g -= inc;
				else							pd->g = pdMAX->g;
				//b
				if (pd->b - inc >= pdMIN->b)	pd->b -= inc;
				else							pd->b = pdMAX->b;

				return(true);
			}

			int *pd		= NULL;
			int *pdDEF	= NULL;
			int *pdMIN	= NULL;
			int *pdMAX	= NULL;
			if (selection & SEL_DAT1)
			{
				pd		= &((RGBcolor*)p_data)->r;
				pdDEF	= &((RGBcolor*)p_dataDEF)->r;
				pdMIN	= &((RGBcolor*)p_dataMIN)->r;
				pdMAX	= &((RGBcolor*)p_dataMAX)->r;
			}
			if (selection & SEL_DAT2)
			{
				pd		= &((RGBcolor*)p_data)->g;
				pdDEF	= &((RGBcolor*)p_dataDEF)->g;
				pdMIN	= &((RGBcolor*)p_dataMIN)->g;
				pdMAX	= &((RGBcolor*)p_dataMAX)->g;
			}
			if (selection & SEL_DAT3)
			{
				pd		= &((RGBcolor*)p_data)->b;
				pdDEF	= &((RGBcolor*)p_dataDEF)->b;
				pdMIN	= &((RGBcolor*)p_dataMIN)->b;
				pdMAX	= &((RGBcolor*)p_dataMAX)->b;
			}
			if (pd == NULL)
				return(false);
			
			if (*pd - inc >= *pdMIN)	*pd -= inc;
			else						*pd = *pdMAX;

			return(true);
		}

		//bool
		if (d_type == ODT_BOOL)
		{
			*(bool*)p_data	= !*(bool*)p_data;
			if (*(bool*)p_data < *(bool*)p_dataMIN)
				*(bool*)p_data = *(bool*)p_dataMIN;
			if (*(bool*)p_data > *(bool*)p_dataMAX)
				*(bool*)p_data = *(bool*)p_dataMAX;

			return(true);
		}

		return(false);
	};

	//---- reset data -----------------------------------------------------------------------------
	//resets data to default

	bool reset_data()
	{
		//locked
		if (locked)
			return(false);

		//no valid data
		if (p_data == NULL || p_dataDEF == NULL || p_dataMIN == NULL || p_dataMAX == NULL)
			return(false);

		//if anything else than qualifier selected return false
		//if (selection != 1)
//		if (selection ^ SEL_QUAL)
//			return(false);
		//if neither qualifier nor pre selected return false
		if (!(selection & (SEL_QUAL | SEL_PRE)))
			return(false);

		//integer
		if (d_type == ODT_INT)
		{
			*(int*)p_data	= *(int*)p_dataDEF;

			return(true);
		}

		//float
		if (d_type == ODT_FLOAT)
		{
			*(float*)p_data	= *(float*)p_dataDEF;

			return(true);
		}

		//rgb (all at once)
		if (d_type == ODT_RGB)
		{
			*(RGBcolor*)p_data	= *(RGBcolor*)p_dataDEF;

			return(true);
		}

		//char (name string, etc.)
		if (d_type == ODT_CHAR)
		{
			//*(char*)p_data		= *(char*)p_dataDEF;
			strcpy((char*)p_data, (char*)p_dataDEF);

			return(true);
		}

		//bool
		if (d_type == ODT_BOOL)
		{
			*(bool*)p_data	= *(bool*)p_dataDEF;

			return(true);
		}

		return(false);
	};

	//---- set input ------------------------------------------------------------------------------
	//set option data to argumented input device and key/button

	bool set_input(int dik,					//direct input key or button
				   int device = 0)			//0 = keyboard (default)
											//1/2 = mouse 1/2
											//2/3 = controller 1/2
	{
		//locked
		if (locked)
			return(false);

		//keyboard
		if (device == 0)
		{
			*(int*)p_data	= dik;

			return(true);
		}
		else
		//mouse/controller
		{
			//set general mouse 1/2 or controller 1/2
			if (device == 1)		*(int*)p_data	= 300;
			if (device == 2)		*(int*)p_data	= 400;
			if (device == 3)		*(int*)p_data	= 500;
			if (device == 4)		*(int*)p_data	= 600;

			//set specific button of device
			*(int*)p_data	+= dik;

			return(true);
		}

		return(false);
	};
};

//------------------------------------------------------------------------------------------------
//
//	data_options
//
//	contains data for options menu
//
//------------------------------------------------------------------------------------------------

struct data_options
{
	BYTE					state;				//0 = option uninitialized/fade in
												//1 = idling
												//2 = exit to black
												//3 = exit to white

	yinyang					yy;					//yinyang symbol in background

	option_slot				slot[OS_X][OS_Y];	//option slots
	ipoint					selection;			//selected slot, -1.-1 == nothing selected
	option_slot				*p_SELOPT;			//pointer to currently selected slot, NULL if nothing selected
	int						sub_selection;		//sub_selections
												//0 = none
												//1 = default
												//2 = control input
												//3 = name input

	char					name_buffer[2][21];	//holds name as a backup until change is confirmed...
	int						s_index;			//string index (names)

	//---- constructor ---------------------------------------------------------------------------

	data_options()
	{
		state				= 0;
		reset_SELOPT();
		sub_selection		= SUBSEL_NONE;

//		last_input			= 0;

		//empty names
		ZeroMemory(name_buffer[P1], sizeof(name_buffer[P1]));
		ZeroMemory(name_buffer[P2], sizeof(name_buffer[P2]));
		s_index				= 0;

		//set slot coordinates and default position data for all slots
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				//set slot info
				slot[x][y].slot.x = x;
				slot[x][y].slot.y = y;
				slot[x][y].set_position_data();
			}

/*		//now part of option_slot::fill_slot()
		//for all slots set defaults
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				//set slot coordinates
				slot[x][y].pos.x	= x * 200 + 10;
				slot[x][y].pos.y	= y * 20 + 90;
				if (y > 9)
					slot[x][y].pos.y	= y * 20 + 90 + 20;
				//set data coordinates
				slot[x][y].pos_data.x	= slot[x][y].pos.x + 120;
				slot[x][y].pos_data.y	= slot[x][y].pos.y;

				//set slot rectangles
				slot[x][y].r_pos.left		= slot[x][y].pos.x - 8;
				slot[x][y].r_pos.top		= slot[x][y].pos.y - 2;
				slot[x][y].r_pos.right		= slot[x][y].r_pos.left + 120;
				slot[x][y].r_pos.bottom		= slot[x][y].r_pos.top + 19;
				//set slot data rectangles
				for (int s = 0; s < 3; ++s)
				{
					//slot[x][y].r_pos_data[s].left	= slot[x][y].r_pos.right + 1 + (s * 21);
					//slot[x][y].r_pos_data[s].top	= slot[x][y].r_pos.top;
					//slot[x][y].r_pos_data[s].right	= slot[x][y].r_pos_data[s].left + 20;
					//slot[x][y].r_pos_data[s].bottom	= slot[x][y].r_pos.bottom;
					slot[x][y].r_pos_data[s].left	= slot[x][y].pos_data.x - 8 + (s * 21);
					slot[x][y].r_pos_data[s].top	= slot[x][y].pos_data.y - 2;
					slot[x][y].r_pos_data[s].right	= slot[x][y].r_pos_data[s].left + 20;
					slot[x][y].r_pos_data[s].bottom	= slot[x][y].r_pos_data[s].top + 19;
				}
			}*/
	};

	//---- initialze ------------------------------------------------------------------------------
	//sets initialization data

	bool initialize(char** plut, int nmouse)
	{
		//DIK description look up table
		//for all slots
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				slot[x][y].p_lutDIK_DESC	= plut;
				slot[x][y].RIMn				= nmouse;
			}

		/*
		//copy names into buffers for editing
		for (int i = 0; i < 20; ++i)
		{
			name_buffer[P1][i] = name_p1[i];
			name_buffer[P2][i] = name_p2[i];
		}*/

		return(true);
	};

	//---- set name buffer ------------------------------------------------------------------------
	//copies argumented string into name editing buffer

/*	void set_name_buffer(char *pcbuffer, char *ps)
	{
		if (sizeof(ps)
		if (pcbuffer == NULL)
			pcbuffer = "
	};*/
	
/*	void set_name_buffer(int buffer, char *ps)
	{
		return;

		//no valid string
		if (ps == NULL)
			ps = "EMPTY";

		if (buffer == P1)
			for (int i = 0; i < 20; ++i)
				name_buffer[P1][i] = ps[i];
		if (buffer == P2)
			for (int i = 0; i < 20; ++i)
				name_buffer[P2][i] = ps[i];

		return;
	};*/

	//---- set_option ----------------------------------------------------------------------------

	bool set_option(int sx, int sy,										//slot
					char *qual,											//qualifier
					BYTE locked,										//if locked
					void *pd, void *pddef, void *pdmin, void *pdmax,	//pointer to data
					int otype, int dtype, double itype,					//option type, data type, increment type,
					int color = OCS_DEF,								//color scheme
					int qoffx = 0, int qoffy = 0, int doffx = 0, int doffy = 0,	//qualifier/data position offset
					float _bmf_size = 1.0f, float _slf_size = 0.35f)			//size of bitmap/scanline font
	{
		//verify slot
		if (sx < 0 || sx > OS_X - 1 ||
			sy < 0 || sy > OS_Y - 1)
		{
			gf_logger(true, "data_options::set_option: WRONG INDEX [%i][%i]", sx, sy);
			return(false);
		}

		//verify qualifier
		if (qual == NULL)
		{
			gf_logger(true, "data_options::set_option: NO QUALIFER [%i][%i]", sx, sy);
			return(false);
		}

		//fill slot
		slot[sx][sy].fill_slot(sx, sy,
							   qual,
							   locked,
							   pd, pddef, pdmin, pdmax,
							   otype, dtype, itype, color,
							   qoffx, qoffy, doffx, doffy,
							   _bmf_size, _slf_size);

		return(true);
	};

	//---- set_bounding_box -----------------------------------------------------------------------
	//sets bounding boxes of options, qualifier and data

	void set_bounding_box(int type)			//0 = bmf, 1 = slf
	{
		//for all options
		for (int x = 0; x < OS_X; ++x)
			for (int y = 0; y < OS_Y; ++y)
			{
				//if slot set
				if (slot[x][y].set)
				{
					slot[x][y].set_qualifier_box(type);
					slot[x][y].set_data_box(type);
				}
			}
	};

	//---- set SELOPT -----------------------------------------------------------------------------
	//(re)set currently selected option slot

	bool set_SELOPT(int x, int y)
	{
		//reset
		if (x == -1 || y == -1)
		{
			return(reset_SELOPT());
		}

		//verify!
		if (x >= 0 && x < OS_X &&
			y >= 0 && y < OS_Y)
		{
			selection.setpoint(x, y);
			p_SELOPT	= &slot[selection.x][selection.y];
			return(true);
		}
		else
			return(false);
	};

	//---- reset SELOPT ---------------------------------------------------------------------------
	//reset currently selected slot to none, pointer to selected slot

	bool reset_SELOPT()
	{
		selection.x		= -1;
		selection.y		= -1;
		p_SELOPT		= NULL;

		return(true);
	};

	//---- SELOPT reset selection -----------------------------------------------------------------
	//resets selection of currently selected slot

	bool SELOPT_reset_selection(int slot_x, int slot_y, bool all = true)
	{
		//reset selection of all slots
		if (all)
		{
			//for all slots set slot selection to none
			for (int x = 0; x < OS_X; ++x)
				for (int y = 0; y < OS_Y; ++y)
					slot[x][y].set_selection(SEL_NONE);

			return(true);
		}
		else
			//verify index
			if (slot_x < 0 || slot_x > OS_X - 1 ||
				slot_y < 0 || slot_y > OS_Y - 1)
				return(false);
			else
			{
				//set argumented slot to no selection
				slot[slot_x][slot_y].set_selection(SEL_NONE);
				return(true);
			}
	};

	//---- increase SELOPT ------------------------------------------------------------------------
	//increase currently selected slot along x and/or y axis

	bool increase_SELOPT(int x, int y)
	{
		//axis
		if (x)
			if (selection.x < OS_X - 1)		set_SELOPT(selection.x + 1, selection.y);
			else							set_SELOPT(0, selection.y);
		if (y)
			if (selection.y < OS_Y - 1)		set_SELOPT(selection.x, selection.y + 1);
			else							set_SELOPT(selection.x, 0);

		return(true);
	};

	//decrease currently selected slot
	bool decrease_SELOPT(int x, int y)
	{
		//axis
		if (x)
			if (selection.x > 0)			set_SELOPT(selection.x - 1, selection.y);
			else							set_SELOPT(OS_X - 1, selection.y);
		if (y)
			if (selection.y > 0)			set_SELOPT(selection.x, selection.y - 1);
			else							set_SELOPT(selection.x, OS_Y - 1);

		return(true);
	};

	//---- SELOPT ---------------------------------------------------------------------------------
	//returns true if currently a slot is selected, else false

	bool SELOPT()
	{
		//selection valid
		if (selection.x >= 0 && selection.x < OS_X &&
			selection.y >= 0 && selection.y < OS_Y &&
			(p_SELOPT != NULL))
			return(true);
		else
			return(false);
	};

	//returns currently selected option slot as ipoint
	ipoint SSELOPT()
	{
		return(selection);
	};

	//---- SELOPT selection -----------------------------------------------------------------------
	//returns the selection of the currently selected option slot
	//if no option slot is set it returns SEL_NONE

	int SELOPT_selection()
	{
		if (SELOPT())
			return(slot[selection.x][selection.y].selection);
		else
			return(SEL_NONE);
	};

	//---- SELOPT set selection -------------------------------------------------------------------
	//sets currently selected option slot to selected value
	//returns false if currently no option slot selected or invalid argumented value

	bool SELOPT_set_selection(int slot_value)
	{
		if (SELOPT())
			return(slot[selection.x][selection.y].set_selection(slot_value));
		else
			return(false);
	};

	//---- SELOPT inc data ------------------------------------------------------------------------
	//increase currently selected option slot's data
	//returns false if no slot selected or inc/dec function of slot returned false

	bool SELOPT_inc_data()
	{
		if (SELOPT())
			return(slot[selection.x][selection.y].increase_data());
		else
			return(false);
	};

	//---- SELOPT dec data ------------------------------------------------------------------------
	//decrease currently selected option slot's data
	//returns false if no slot selected or inc/dec function of slot returned false

	bool SELOPT_dec_data()
	{
		if (SELOPT())
			return(slot[selection.x][selection.y].decrease_data());
		else
			return(false);
	};

	//---- SELOPT reset data ----------------------------------------------------------------------
	//resets currently selected option slot's data
	//returns false if no slot selected or reset function of slot returned false

	bool SELOPT_reset_data()
	{
		if (SELOPT())
			return(slot[selection.x][selection.y].reset_data());
		else
			return(false);
	};
};

//------------------------------------------------------------------------------------------------
//
//	credit_entry
//
//	contains data for credits scroll
//
//------------------------------------------------------------------------------------------------

struct credit_entry
{
	BYTE					set;					//if entry set or not

	char					*pc;					//pointer to credit string
	int						el;						//number of empty lines before string

	point					pos;					//current position (offset to template)
	int						bmfcolor;				//bmfcolor of entry

	//---- constructor ---------------------------------------------------------------------------

	credit_entry()
	{
		set				= 0;

		pc				= NULL;
		el				= 0;

		bmfcolor		= bmfblack;
	};

	//---- destructor ----------------------------------------------------------------------------

	~credit_entry()
	{
		set				= 0;

		pc				= NULL;
		el				= 0;
	};

	//---- set_entry -----------------------------------------------------------------------------

	void set_entry(int el_, char *pc_, int cbmf = bmfblack)
	{
		//active entry
		set			= 1;

		pc			= pc_;
		el			= el_;

		bmfcolor	= cbmf;
	};
};

//------------------------------------------------------------------------------------------------
//
//	data_credits
//
//	contains data for credits scroll
//
//------------------------------------------------------------------------------------------------

struct data_credits
{
	BYTE					state;			//0 = uninitialized/fade in
											//1 = scrolling
											//2 = done, return

	int						pause;			//if scrolling is paused

	credit_entry			pcq[NOC];		//credit queue
	int						ecounter;		//internal entry counter for initialization
	
	rectangle				temp;			//template for text
											//p[0] = top
											//p[2] = bottom
	point					temp_offset;	//offset

	point					scroll_speed;	//speed of scrolling
	int						bmfcolor;		//color of credits

	//---- constructor ---------------------------------------------------------------------------

	data_credits()
	{
		state				= 0;
		pause				= 0;

		ecounter			= 0;

		scroll_speed.y		= CR_SPEED;
		bmfcolor			= CR_BMFCOLOR;

		//set credits text and format
		set_entry(0, "PROJECT BEATMASTER");
		set_entry(1, "by");
		set_entry(1, "Killing Me Software");
		set_entry(3, "EXECUTIVE PRODUCER");
		set_entry(1, "Karim Zeghida");
		set_entry(0, "SUPERVISOR");
		set_entry(0, "Karim Zeghida");
		set_entry(0, "CHIEF OF STAFF");
		set_entry(0, "Karim Zeghida");
		set_entry(0, "ADDITIONAL TESTING");
		set_entry(0, "Samir Zeghida");
		set_entry(0, "THANKS TO");
		set_entry(0, "Microsoft for their Operating System, Developing Environment,");
		set_entry(0, "Mice, Keyboard, Gamepad");
		set_entry(0, "Nintendo for their Games I grew up with");
		set_entry(0, "NBH");
		set_entry(0, "VS6.0, DX7");
		set_entry(0, "lego (figur), internet community, mjj, bruce lee, trainer");
		set_entry(0, "online dictionary");
		set_entry(0, "");
		//to all you gamers out there: feels good to be one of you!
		//NBH providing musical background
		//panza kickboxing, budokan, streetfighter 2
		//console:  Chris Hargrove

		//positions of all entries within template
		set_entry_pos();
	};

	//---- set entry ------------------------------------------------------------------------------
	//assign entry, handle entry number

	void set_entry(int el, char *pc, int cbmf = bmfblack)
	{
		//verify
		if (ecounter > NOC - 1)
		{
			gf_logger(true, "data_credits initializing: number of credits overflow %i of %i", ecounter + 1, NOC);
			return;
		}

		//assign
		pcq[ecounter].set_entry(el, pc, cbmf);
		++ecounter;
	};

	//---- set entry pos --------------------------------------------------------------------------
	//set entry position within template

	void set_entry_pos()
	{
		//for all valid entries
		for (int i = 0, l = 0; i < ecounter; ++i)
		{
			//increase empty lines
			l					+= pcq[i].el;
			//calculate position on template
			pcq[i].pos.y		= (float)(16 * (i + l));
		}

		//offset, last entry minus size of bmf height
		temp_offset.y = pcq[i - 1].pos.y + 16;

		//set template to bottom (default)
		set_temp_pos();
	};

	//---- set temp pos ---------------------------------------------------------------------------
	//resets template postion to either (out of) top or bottom of screen

	void set_temp_pos(int bottom = 1)
	{
		//set to bottom
		if (bottom)
		{
			temp.p[0].y = 600;
			temp.p[2].y = temp.p[0].y + temp_offset.y;
		}
		else
		//set to top
		{
			temp.p[2].y = 0;
			temp.p[0].y = temp.p[2].y - temp_offset.y;
		}
	};

	//---- reset ----------------------------------------------------------------------------------
	//resets credits data

	void reset()
	{
		state			= 0;
		pause			= 0;

		set_temp_pos();

		scroll_speed.y	= CR_SPEED;
		bmfcolor		= CR_BMFCOLOR;
	};
};

//------------------------------------------------------------------------------------------------
//
//	data_ingame
//
//	contains additional data for ingame
//
//------------------------------------------------------------------------------------------------

struct data_ingame
{
	//soundflag
	//controlflag 0 = no user control, 1 = only stances, 2 = full control
	//oder gleich von state abh�ngig machen !3 2 3

	BYTE					state;			//0 = uninitialized/fade in
											//1 = new round (control freeze, except for stance
											//(arms and feet) changes) - round message
											//2 = new round - fight message
											//10 = ko sequence
											//15 = final win message
											//50 = round running
											//100 = done, return to title

	BYTE					state_s;		//soundstate

	int						state_ip;		//0 = all input valid
											//1 = only stance arms/feet input valid
											//(at begin of new round)
											//2 = no input valid

	bool					pause;			//extra pause flag

	LONGLONG				t_start_a;		//time stamp for startup sequence
	LONGLONG				t_start_s;		//time stamp for sound sequence
	LONGLONG				t_round;		//time stamp for last round time update
	LONGLONG				t_pause;		//time stamp game was paused

	float					speed_start;	//game speed at time of ko
											//used to interpolate speed during amount of time to 0

	int						round;			//current round
	int						roundtime;		//remaining round time in seconds
	char					rts[6];			//contains round time as string ("mm:ss")

	int						gl_winpoints[5];			//0 = empty
														//1 = player 1 wins
														//2 = player 2 wins
														//3 = draw
	int						gl_totalscore[2];	//total scores for all rounds

	//win messages
	char					*pstartmessage[5];	//start messages
	BYTE					message;			//index of message

	RGBcolor				c_mf;				//general message fill and border color
	RGBcolor				c_mb;

	//ingame option data
	BYTE					f_pause;			//flag indicates if pause initialized
	LONGLONG				f_vsync;			//start times of option change
	LONGLONG				f_shadows;
	LONGLONG				f_sound;
	LONGLONG				f_speed;
	LONGLONG				f_mblur;
	LONGLONG				f_bwmode;
	LONGLONG				f_damage_multiplier;
	LONGLONG				f_fom_multiplier;
	LONGLONG				f_screenshot;		//displays message when screenshot taken

	char					screenshot_id[256];	//holds name of screenshot file

	//pause color bias
	RGBcolor				Pcb;

	//---- constructor ---------------------------------------------------------------------------

	data_ingame()
	{
		state				= 0;
		state_s				= 0;
		state_ip			= 0;

		pause				= false;

		t_start_a			= 0;
		t_start_s			= 0;
		t_round				= 0;
		t_pause				= 0;

		speed_start			= 0;

		round				= 0;
		roundtime			= 0;
		ZeroMemory(&rts, sizeof(rts));

		ZeroMemory(&gl_winpoints, sizeof(gl_winpoints));
		ZeroMemory(&gl_totalscore, sizeof(gl_totalscore));

		pstartmessage[0]	= "Fight!";
		pstartmessage[1]	= "Go! Go! Go!";
		pstartmessage[2]	= "Use the Force!";
		pstartmessage[3]	= "Up and At'im!";
		pstartmessage[4]	= "blabla";
		message				= 0;

		ZeroMemory(&screenshot_id, sizeof(screenshot_id));

		//!!
		c_mf.setcolor(green);
		c_mb.setcolor(black);

		f_pause				= 0;
		f_vsync				= 0;
		f_shadows			= 0;
		f_sound				= 0;
		f_speed				= 0;
		f_mblur				= 0;
		f_bwmode			= 0;
		f_screenshot		= 0;
		f_damage_multiplier	= 0;
		f_fom_multiplier	= 0;
	};

	//---- reset ---------------------------------------------------------------------------------
	//reset data for new game

	void reset()
	{
		state			= 0;
		state_s			= 0;
		state_ip		= 0;

		t_start_a		= 0;
		t_start_s		= 0;
		t_round			= 0;

		speed_start		= 0;

		round			= 0;
		roundtime		= 0;

		ZeroMemory(&gl_winpoints, sizeof(gl_winpoints));
		ZeroMemory(&gl_totalscore, sizeof(gl_totalscore));
	};
};

//------------------------------------------------------------------------------------------------
//
//	data_teaser
//
//	contains data for teaser sequence
//
//------------------------------------------------------------------------------------------------

struct data_teaser
{
	BYTE					state;				//0 =

	LONGLONG				t_start;			//starting time
	LONGLONG				t_start_a;			//start time of different actions

	//---- constructor ---------------------------------------------------------------------------

	data_teaser()
	{
		state			= 0;

		t_start			= 0;
		t_start_a		= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	console
//
//	ingame console
//
//------------------------------------------------------------------------------------------------

struct console
{
	//---- frontend data -------------------------------------------------------------------------

	bool					state;							//0 = off, 1 = on

	//in options
//	BYTE					console_toggle_key;				//toggles console on and off
	bool					moving;							//set true when dropping up/down (no input)

	LONGLONG				t_last;							//last time of movement update

	char					line_start;						//start and end symbols of command line
	char					line_end;

	int						ppline;							//pixel per line, pixel per column
	int						ppcolumn;
	int						lines;							//lines and columns of console size
	int						columns;
	rectangle				console_r;						//console position

	unsigned char			active_buffer[CON_LINEMAX];					//holds active unfinished command
																		//including null termination
	int						ab_cursor;									//active line cursor
	unsigned char			output_buffer[CON_OBSTRING];				//outputbuffer, holds all outputted strings
																		//visible in console
	unsigned char			com_buffer[CON_COMBUFFER][CON_LINEMAX];		//command history buffer
	int						cb_index;									//command history buffer index

	//---- visuals -------------------------------------------------------------------------------

	RGBcolor				*pcon_color;
	RGBcolor				*pcon_fcolor;
	int						*pcon_textcolor;
	int						*pcon_frame;
	int						*pcon_dropspeed;
	int						*pcon_style;
	RECT					*pcon_dim;

	//---- intern data ---------------------------------------------------------------------------

	master_frame			*pmf;							//pointers to all objects console
	directdraw				*pdd;							//functions have access to
	directinput				*pdi;
	directsound				*pds;
	player					*pp;

	con_var_t				*con_varList;					//points to last created con_var_t object
	con_func_t				*con_funcList;					//point to last created con_func_t objects
	con_func_t				*con_varHandlerList;

	//---- constructor ---------------------------------------------------------------------------

	console()
	{
		state					= OFF;
//		console_toggle_key		= DIK_GRAVE;
		moving					= false;
		t_last					= 0;

		line_start				= CON_BREAK;
		line_end				= '<';

		ppline					= 16;
		ppcolumn				= 8;

		lines					= 5;
		columns					= 100;

		clear_active_buffer();
		clear_output_buffer();
		clear_command_buffer();

		pcon_color				= NULL;
		pcon_fcolor				= NULL;
		pcon_textcolor			= NULL;
		pcon_frame				= NULL;
		pcon_dropspeed			= NULL;
		pcon_style				= NULL;
		pcon_dim				= NULL;

		//----------------------------------------------------------------------------------------

		pmf						= NULL;
		pdd						= NULL;
		pdi						= NULL;
		pds						= NULL;
		pp						= NULL;

		con_varList				= NULL;
		con_funcList			= NULL;
		con_varHandlerList		= NULL;
	};

	//---- toggle_console ------------------------------------------------------------------------
	//to toggle console call function:
	//con.toggle_console(!con.state)
	//returns new state of console (on/off)

	bool toggle_console(bool _state)
	{
		state = _state;

		//clear active line
		clear_active_buffer();

		//set up console movement data only when not instant movement speed
		if (*pcon_dropspeed > 0)
		{
			//set start time
			QueryPerformanceCounter((LARGE_INTEGER*) &t_last);

			//set console to moving
			moving = true;
		}
		else
		{
			//set visible console rect depending on state
			if (state)
				console_r = *pcon_dim;
			else
				ZeroMemory(&console_r, sizeof(console_r));
		}

		//return new state
		return(state);
	};

	//---- open ----------------------------------------------------------------------------------
	//called when console opened

	void open()
	{
	};

	//---- close ---------------------------------------------------------------------------------
	//called when console closed

	void close()
	{
	};

	//---- clear_active_buffer -------------------------------------------------------------------

	void clear_active_buffer()
	{
		//clear active buffer
		ZeroMemory(&active_buffer, sizeof(active_buffer));
		//reset cursor
		ab_cursor		= 0;
	};

	//---- clear_output_buffer -------------------------------------------------------------------

	void clear_output_buffer()
	{
		//clear output buffer
		ZeroMemory(&output_buffer, sizeof(output_buffer));
	};

	//---- clear_command_buffer ------------------------------------------------------------------

	void clear_command_buffer(int buffer = -1)
	{
		//all buffers
		if (buffer <= -1)
			ZeroMemory(&com_buffer, sizeof(com_buffer));
		else
		//specified buffer
		{
			if (buffer < CON_COMBUFFER)
				for (register int i = 0; i < CON_LINEMAX; ++i)
					com_buffer[buffer][i] = 0;
		}

		cb_index	= -1;
	};

	//---- add_outputbuffer ----------------------------------------------------------------------
	//adds string to outputbuffer

	void add_outputbuffer(char source[], char prompt = 62)
	{
		//valid size
		if (strlen(source) < 1)
			return;

		//temporary buffer with size of outputbuffer and source plus additional
		//new line character plus null terminator
		char *ptmp = new char[CON_OBSTRING + strlen(source) + 1];
		ZeroMemory(ptmp, CON_OBSTRING + strlen(source) + 1);
		//copy outputbuffer, new line character and source into temporary buffer
		strcat(ptmp, (char*)output_buffer);
		ptmp[strlen(ptmp)] = prompt;
		ptmp[strlen(ptmp)] = 0;
		strcat(ptmp, source);

		//if length of temporary buffer is bigger than output buffer
		//lefthshift temporary buffer
		if (strlen(ptmp) > CON_OBSTRING - 1)
			leftshift_buffer(ptmp, CON_OBSTRING + strlen(source) + 1,
							 strlen(ptmp) - (CON_OBSTRING - 1));
		//copy temporary buffer into output buffer
		strcpy((char*)output_buffer, ptmp);
		//first character always prompt
		//output_buffer[0] = prompt;

		//delete memory and pointer
		delete []	ptmp;
		ptmp		= NULL;
	};

	//---- print_outputbuffer --------------------------------------------------------------------

	void print_outputbuffer(char* format, ...)
	{
		//argument pointer
		va_list	ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		char buffer[2048];
		//copy message into buffer
		vsprintf(buffer, format, ap);
		//clear up
		va_end(ap);

		//temporary buffer with size of outputbuffer and source plus additional
		//new line character plus null terminator
		char *ptmp = new char[CON_OBSTRING + strlen(buffer) + 1];
		ZeroMemory(ptmp, CON_OBSTRING + strlen(buffer) + 1);
		//copy outputbuffer, new line character and source into temporary buffer
		strcat(ptmp, (char*)output_buffer);
		ptmp[strlen(ptmp)] = '\n';
		ptmp[strlen(ptmp)] = 0;
		strcat(ptmp, buffer);

		//if length of temporary buffer is bigger than output buffer
		//lefthshift temporary buffer
		if (strlen(ptmp) > CON_OBSTRING - 1)
			leftshift_buffer(ptmp, CON_OBSTRING + strlen(buffer) + 1,
							 strlen(ptmp) - (CON_OBSTRING - 1));
		//copy temporary buffer into output buffer
		strcpy((char*)output_buffer, ptmp);
		//first character always prompt
		//output_buffer[0] = prompt;

		//delete memory and pointer
		delete []	ptmp;
		ptmp		= NULL;
	};

	//---- leftshift_buffer ----------------------------------------------------------------------
	//shifts char string for argumented number of places to the left
	//if whole buffer to be shifted, clear buffer

	void leftshift_buffer(char buffer[], int size, int p)
	{
		if (p > 0)
		{
			//- 1 since it's a char string
			if (p < size - 1)
			{
				for (register int i = 0; i < size - p; ++i)
				{
					buffer[i] = buffer[p + i];
				}
			}
			else
			//clear whole buffer
				ZeroMemory(buffer, size);
		}
	};

	//---- add_commandbuffer ---------------------------------------------------------------------

	void add_commandbuffer(char source[])
	{
		//valid size and command buffer
		if (strlen(source) < 1 || !CON_COMBUFFER)
			return;

		//command history buffer from 0 to CON_COMBUFFER - 1
		//rightshift command buffers to free first one
		//copy latest command into first command buffer
		for (register int i = CON_COMBUFFER - 1; i > 0; --i)
			strcpy((char*)com_buffer[i], (char*)com_buffer[i - 1]);

		strcpy((char*)com_buffer[0], source);

		//reset cb index
		cb_index	= -1;
	};

	//---- load_commandbuffer --------------------------------------------------------------------

	void load_commandbuffer()
	{
		//clear active buffer
		clear_active_buffer();
		//copy into destination buffer
		strcpy((char*)active_buffer, (char*)com_buffer[cb_index]);
		ab_cursor = strlen((char*)active_buffer);
	};

	//---- console_move --------------------------------------------------------------------------

	void console_move()
	{
		//get current time index
		LONGLONG t_current	= 0;
		QueryPerformanceCounter((LARGE_INTEGER*) &t_current);
		//get frequency and store it in t_freq
		LONGLONG t_freq		= 0;
		QueryPerformanceFrequency((LARGE_INTEGER*) &t_freq);
		//time in seconds passed since last update
		double t_sca = (t_current - t_last) / (double)t_freq;

/*		if (t_pass < console_movetime)
		{
			console_r				= con_dim;

			//if drop down
			if (state)
			{
				console_r.bottom	= (long)(con_dim.top +
									  (con_dim.bottom - con_dim.top) /
									  console_movetime * t_pass);
			}
			else
			//move up
			{
				console_r.bottom	= (long)(con_dim.bottom -
									  (con_dim.bottom - con_dim.top) /
									  console_movetime * t_pass);
			}
		}
		else
		{
			console_r	= con_dim;

			//deactivate movement
			moving		= false;
			t_start		= 0;
		}*/

		//move from top
		if (*pcon_style == 0)
		{
			console_r.p[0].x	= (float)pcon_dim->left;		console_r.p[0].y	= (float)pcon_dim->top;
			console_r.p[1].x	= (float)pcon_dim->right;		console_r.p[1].y	= (float)pcon_dim->top;
			console_r.p[2].x	= (float)pcon_dim->right;
			console_r.p[3].x	= (float)pcon_dim->left;

			//if drop in
			if (state)
			{
				if (console_r.p[2].y + *pcon_dropspeed * t_sca <= pcon_dim->bottom)
				{
					console_r.p[2].y += *pcon_dropspeed * (float)t_sca;
					console_r.p[3].y += *pcon_dropspeed * (float)t_sca;
				}
				else
				{
					console_r	= *pcon_dim;
					//deactive movement
					moving		= false;
				}
			}
			else
			//drop out
			{
				if (console_r.p[2].y - *pcon_dropspeed * t_sca >= pcon_dim->top)
				{
					console_r.p[2].y -= *pcon_dropspeed * (float)t_sca;
					console_r.p[3].y -= *pcon_dropspeed * (float)t_sca;
				}
				else
				{
					console_r			= *pcon_dim;
					console_r.p[2].y	= (float)pcon_dim->top;
					console_r.p[3].y	= (float)pcon_dim->top;
					//deactive movement
					moving		= false;
				}
			}
		}

		//move from left
		if (*pcon_style == 1)
		{
			console_r.p[0].x	= (float)pcon_dim->left;		console_r.p[0].y	= (float)pcon_dim->top;
			/*console_r.p[1].x	= (float)con_dim.right;*/		console_r.p[1].y	= (float)pcon_dim->top;
			/*console_r.p[2].x	= (float)con_dim.right;*/		console_r.p[2].y	= (float)pcon_dim->bottom;
			console_r.p[3].x	= (float)pcon_dim->left;		console_r.p[3].y	= (float)pcon_dim->bottom;

			//if drop in
			if (state)
			{
				if (console_r.p[1].x + *pcon_dropspeed * t_sca <= pcon_dim->right)
				{
					console_r.p[1].x += *pcon_dropspeed * (float)t_sca;
					console_r.p[2].x += *pcon_dropspeed * (float)t_sca;
				}
				else
				{
					console_r	= *pcon_dim;
					//deactive movement
					moving		= false;
				}
			}
			else
			//drop out
			{
				if (console_r.p[1].x - *pcon_dropspeed * t_sca >= pcon_dim->left)
				{
					console_r.p[1].x -= *pcon_dropspeed * (float)t_sca;
					console_r.p[2].x -= *pcon_dropspeed * (float)t_sca;
				}
				else
				{
					console_r			= *pcon_dim;
					console_r.p[1].x	= (float)pcon_dim->left;
					console_r.p[2].x	= (float)pcon_dim->left;
					//deactive movement
					moving		= false;
				}
			}
		}

		//update last update time index
		t_last	= t_current;
	};

	//---- process -------------------------------------------------------------------------------

	void process(BYTE dikey[256], BYTE dikey1D[256], int ascii)
	{
		//if still dropping down or up don't get any input
		//just move console window
		if (moving)
		{
			console_move();
			return;
		}

		//for all keys
		for (register int i = 0; i < 256; ++i)
			//if key pressed and valid key
			if (ascii)
			{
				//if not at end of line add character to active line input string
				if (ab_cursor < CON_LINEMAX - 1)
				{
					active_buffer[ab_cursor] = ascii;
					++ab_cursor;
				}

				break;
			}

		//if backspace and input line not empty
		if (dikey1D[SYS_BACK] & 0x80 && ab_cursor > 0)
		{
			--ab_cursor;
			active_buffer[ab_cursor]		= 0;
		}

		//if enter
		if (dikey1D[SYS_RETURN] & 0x80 || dikey1D[DIK_NUMPADENTER] & 0x80)
		{
			//copy active buffer into output buffer
			add_outputbuffer((char*)active_buffer);

			//copy into last command buffer
			add_commandbuffer((char*)active_buffer);

			//check and execute active line
//!!			con_execute(true, "%s", active_buffer);
			con_execute(false, "%s", active_buffer);

			//clear active buffer
			clear_active_buffer();
		}

		//if tab list vars
		if (dikey1D[DIK_TAB] & 0x80)
		{
			char buffer[CON_LINEMAX] = "LISTVARS ";
			strcat(buffer, (char*)active_buffer);
			print_outputbuffer(buffer);
			con_execute(0, buffer);
		}

		//if command buffer history
		if (dikey1D[SYS_UP] & 0x80)
		{
			//if not at last index
			if (cb_index < CON_COMBUFFER - 1)
			{
				//if next com buffer not empty
				if (strlen((char*)com_buffer[cb_index + 1]))
					//increase index
					++cb_index;
			}
//			else
//				//else begin in off-position
//				cb_index = -1;

			//if current index valid
			if (cb_index != -1)
				//copy into active buffer
				load_commandbuffer();
			else
				//clear active buffer
				clear_active_buffer();
		}
		if (dikey1D[SYS_DOWN] & 0x80)
		{
			//if not at first index
			if (cb_index > 0)
				//if previous com buffer not empty
				if (strlen((char*)com_buffer[cb_index - 1]))
					//decrease index
					--cb_index;
				else
					//else in off-position
					cb_index = -1;
			else
			{
				/*
				//else get topmost com buffer and set index to it
				for (register int i = 0; i < CON_COMBUFFER - 1; ++i)
					if (strlen(com_buffer[i]))
					{
						cb_index	= i;
						break;
					}*/

				cb_index = -1;
			}

			//if current index valid
			if (cb_index != -1)
				//copy into active buffer
				load_commandbuffer();
			else
				//clear active buffer
				clear_active_buffer();
		}

		//clear
		if (dikey1D[SYS_LEFT] & 0x80)
			clear_active_buffer();

		//change console text color
		if (dikey1D[DIK_F1])
		{
			*pcon_textcolor	= -1;			//auto color
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F2])
		{
			*pcon_textcolor	= bmfwhite;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F3])
		{
			*pcon_textcolor	= bmfblack;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F4])
		{
			*pcon_textcolor	= bmfred;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F5])
		{
			*pcon_textcolor	= bmfgreen;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F6])
		{
			*pcon_textcolor	= bmfblue;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F7])
		{
			*pcon_textcolor	= bmfyellow;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F8])
		{
			*pcon_textcolor	= bmflightblue;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F9])
		{
			*pcon_textcolor	= bmforange;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}
		if (dikey1D[DIK_F10])
		{
			*pcon_textcolor	= bmflightgreen;
			print_outputbuffer("con_textcolor = %i", *pcon_textcolor);
		}

		//clear all keys
		for (i = 0; i < 256; ++i)
			//except for screenshot
			if (i != DIK_SYSRQ)
				dikey[i] = dikey1D[i] = 0;
	};

	//---- con_execute ---------------------------------------------------------------------------

	unsigned char con_execute(unsigned char restricted, char* format, ...)
	{
		//commandbuffer
		char cmdBuffer[CON_LINEMAX] = "";
		//holds remaining command line if several command separated by ';'
		char pendingBuffer[CON_LINEMAX] = "";
		//array of pointers to char, each pointing to one argument
		char *cmdArgv[CON_MAXARGS] = {NULL};

		//argument counter
		int cmdArgc		= 0;
		//points to each character within commandbuffer
		char *ptr		= NULL;

		//holds instance of var/func to call
		char *cmdIns	= "0";
		//flag if next argument is instance
		int ins			= 0;

		//quoted statements ("1.2")
		enum
		{
			STATE_NORMAL,
			STATE_QUOTE
		} state = STATE_NORMAL;

		//currently checked con var/func, last checked con var/func
		con_var_t *v	= NULL, *vlast	= NULL;
		con_func_t *f	= NULL, *flast	= NULL;

		//if within white space in command string, to separate arguments
		unsigned char inWhiteSpace = 1;
		//if con var/func found
		unsigned char found = 0;

		//argument pointer
		va_list args;
		//initialize argument pointer
		va_start(args, format);
		//copy command line into buffer
		vsprintf(cmdBuffer, format, args);
		//clear up
		va_end(args);

		//for every character in command buffer
		for (ptr = cmdBuffer; *ptr != 0; ++ptr)
		{
			//not within quotes
			if (state == STATE_NORMAL)
			{
				//semicolon delimits a command, exit loop, copy the remaining command line
				//into pending buffer, execute command and call con_execute with the
				//pending buffer
				if (*ptr == ';')
				{
					*ptr	= 0;
					strcpy(pendingBuffer, ptr + 1);
					//so the zero will catch, to exit loop
					//also delimits argument pointers
					--ptr;
				}
				else
					//colon is followed by instance of var/func which is to call
					if (*ptr == ':')
					{
						//next argument is instance
						ins		= 1;
						*ptr	= 0;
					}
					else
						//comment, exit loop, no more commands
						if ((*ptr == '/') && (*(ptr + 1) == '/'))
						{
							*ptr	= 0;
							--ptr;
						}
						else
							//replace apostrophes ' with literal quotes "
							if (*ptr == '`')
							{
								*ptr = '\"';
							}
							else
								//whitespace delimits an argument, set flag
								if (*ptr == ' ')
								{
									*ptr			= 0;
									inWhiteSpace	= 1;
								}
								else
									//last loop was in whitespace
									//or last loop was colon which starts instance argument
									if (inWhiteSpace || ins)
									{
										//exit loop if maximum number of arguments taken
										if (cmdArgc >= CON_MAXARGS)
										{
											*ptr	= 0;
											--ptr;
										}
										else
										//get a new argument
										{
											//if instance flag save argument as instance
											if (ins)
											{
												cmdIns			= ptr;
												ins				= 0;
											}
											else
											{
												//save argument, increase argument counter
												cmdArgv[cmdArgc]	= ptr;
												++cmdArgc;
												//reset whitespace
												inWhiteSpace		= 0;

												//if argument starts with quotations, change state
												if (*ptr == '\"')
												{
													state	= STATE_QUOTE;
													//ignore quotation character
													cmdArgv[cmdArgc - 1] = ptr + 1;
												}
											}

										}
									}
			}
			else
			//whithin quotes
			if (state == STATE_QUOTE)
			{
				//end of quote
				if (*ptr == '\"')
				{
					//exit loop, reset state
					*ptr			= 0;
					state			= STATE_NORMAL;
					inWhiteSpace	= 1;
				}
				else
					//replace apostophe ' with literal quotes "
					if (*ptr == '`')
					{
						*ptr = '\"';
					}
			}
		}

		//if no arguments exit
		if (!cmdArgc)
			return(0);

		//for all console variables
		for (v = con_varList; v != NULL; vlast = v, v = v->next)
		{
			//argumented instance into integer
			int i = atoi(cmdIns);

			//compare first argument of command line with descriptor of con var
			//and instance of con var is specified instance
			if (!stricmp(v->name, cmdArgv[0]) &&
				v->instance == i)
			{
				//check if access restricted
				if ((restricted) && (v->flags & CONVARF_RESTRICTED))
				{
					print_outputbuffer("Access to %s is restricted", v->name);
					found = 1;
					break;
				}

				//if con var has no handler function
				if (!v->handler)
				{
					//try to get var handler for con var
					if (!(v->handler = GetHandlerForVarType((char*)v->varTypeName)))
					{
						//no such handler
						print_outputbuffer("Unknown data type %s", v->varTypeName);
						found = 1;
						break;
					}
				}

				//call type handler with pointer to this console object
				v->handler->func(this, v, cmdArgc, cmdArgv);

				//move variable to top of list for quicker access next time
				if (vlast)
				{
					vlast->next		= v->next;
					v->next			= con_varList;
					con_varList		= v;
				}
				found = 1;
				break;
			}
		}

		//if no con var found, check con functions
		if (!found)
		{
			//for all console functions
			for (f = con_funcList; f != NULL; flast = f, f = f->next)
			{
				//compare first argument of command line with descriptor of con func
				if (!stricmp(f->name, cmdArgv[0]))
				{			    
					//check if access restricted
					if ((restricted) && (f->flags & CONFUNCF_RESTRICTED))
					{
						print_outputbuffer("Access to %s is restricted", f->name);
						found = 1;
						break;
					}

					//call the function with pointer to this console object
					f->func(this, NULL, cmdArgc, cmdArgv);

					//move function to top of list for quicker access next time
					if (flast)
					{
						flast->next		= f->next;
						f->next			= con_funcList;
						con_funcList	= f;
					}
					found = 1;
					break;
				}
			}
		}

		//if no con var/func found
		if (!found)
			print_outputbuffer("Unknown variable/cmd: %s", cmdArgv[0]);

		//if a command is pending because of a semicolon, execute it
		if (pendingBuffer[0])
			return(con_execute(restricted, pendingBuffer));

		return(1);
	};

	//---- ExecuteFile ---------------------------------------------------------------------------
	//opens specified file and executes all (console-)commands within

	unsigned char ExecuteFile(char* fileName)
	{
		return(0);
/*		static char execbuf[256];
		static char filebuf[256];
		char *ptr, *cfgbuf;
		int len, elen;
		dword fp;

		strcpy(filebuf, fileName);
		M_SuggestFileExtension(filebuf, "cfg");
		fp = XF_Open(filebuf);
		if (!fp)
			return(0);
		CON_Printf("Executing \"%s\"\n", filebuf);
		len = XF_Size(fp);
		cfgbuf = SYS_MALLOC(char, len+1);
		cfgbuf[len] = 0;
		XF_Read(cfgbuf, len, fp);
		XF_Close(fp);

		// the following code isn't the speediest road runner in the desert, but who cares
		elen = 0;
		execbuf[0] = 0;
		for (ptr = cfgbuf; *ptr != NULL; ++ptr)
		{
			// NOTE: these 0x0D/0x0A checks are somewhat platform-dependent
			switch(*ptr)
			{
			case 0x0D: break; // skip carriage return
			case 0x0A:
				// execute current command on line feed
				if (!execbuf[0])
					break;
				CON_Execute(false, execbuf);
				elen = 0;
				execbuf[0] = 0;
				break;
			default:
				// any other character gets tacked on
				execbuf[elen++] = *ptr;
				execbuf[elen] = 0;
				break;
			}
		}
		SYS_FREE(cfgbuf);
		return(1);*/
	};

	//---- assign_pointers -----------------------------------------------------------------------

	void assign_pointers(RGBcolor *_con_color,
						 RGBcolor *_con_fcolor,
						 int *_con_textcolor,
						 int *_con_frame,
						 int *_con_dropspeed,
						 int *_con_style,
						 RECT *_con_dim,
						 master_frame *_mf,
						 directdraw *_dd,
						 directinput *_di,
						 directsound *_ds)
	{
		pcon_color				= _con_color;
		pcon_fcolor				= _con_fcolor;
		pcon_textcolor			= _con_textcolor;
		pcon_frame				= _con_frame;
		pcon_dropspeed			= _con_dropspeed;
		pcon_style				= _con_style;
		pcon_dim				= _con_dim;

		pmf						= _mf;
		pdd						= _dd;
		pdi						= _di;
		pds						= _ds;
	};

	//---- init ----------------------------------------------------------------------------------

	void init(console *pcon);

	//---- registration functions ----------------------------------------------------------------

	void RegisterVar(con_var_t* var);						//adds a variable to the console variable list
	void RegisterFunc(con_func_t* func);					//adds a function to the console function list
	void RegisterVarHandler(con_func_t* varHandler);		//adds a variable handler to the handler list

	con_func_t* GetHandlerForVarType(char* varTypeName);	//returns pointer to function which handles variable

	//---- console variable handlers -------------------------------------------------------------

	CLASS_CON_VARHANDLER(int);
	CLASS_CON_VARHANDLER(float);
	CLASS_CON_VARHANDLER(bool);
	CLASS_CON_VARHANDLER(char);
	CLASS_CON_VARHANDLER(RGBcolor);
	CLASS_CON_VARHANDLER(RECT);

	CLASS_CON_FUNC(clear);									//clear outputbuffer
	CLASS_CON_FUNC(listvars);								//list all con vars
	CLASS_CON_FUNC(listcmds);								//list all con functions
	CLASS_CON_FUNC(listtypes);								//list all variable handlers
	CLASS_CON_FUNC(help);									//list all con functions
	CLASS_CON_FUNC(version);								//program version, date
	CLASS_CON_FUNC(exec);									//execute file
	CLASS_CON_FUNC(screenshot);								//takes screenshot

	CLASS_CON_FUNC(exit);									//exit program
	CLASS_CON_FUNC(program_state);							//change program_state
	CLASS_CON_FUNC(input);									//set input devices for both players
	CLASS_CON_FUNC(bind);									//bind key to function
	CLASS_CON_FUNC(unbind);									//unbind key from function
//	CLASS_CON_FUNC(screenmode);								//fullscreen, windowed mode

	CLASS_CON_FUNC(fps_max);								//set/get fps_max
	CLASS_CON_FUNC(sound);									//set/get sound
	CLASS_CON_FUNC(volume);									//set/get main volume
	CLASS_CON_FUNC(ko_mode);								//changes ko_mode
	CLASS_CON_FUNC(fight_mode);								//sets fight mode
	CLASS_CON_FUNC(def_mode);								//changes defense mode
	CLASS_CON_FUNC(handicap);								//sets players handicaps
															//damage and fatigue

	CLASS_CON_FUNC(playdemo);								//replays demo

	//!!
	CLASS_CON_FUNC(reset);
	CLASS_CON_FUNC(mouse);									//set player mouse
	CLASS_CON_FUNC(set_damage);								//set damage of argumented damage slot

//	CLASS_CON_VAR(RGBcolor, con_color);						//console color
//	CLASS_CON_VAR(RGBcolor, con_fcolor);					//console frame color
//	CLASS_CON_VAR(int, con_frame);							//frame on or off
//	CLASS_CON_VAR(int, con_dropspeed);						//console move speed in pixel per second
															//0 = instantly
//	CLASS_CON_VAR(int, con_style);							//0 = move from above
															//1 = move from left
//	CLASS_CON_VAR(RECT, con_dim);							//console dimensions

	//!!
//	CLASS_CON_VAR(char, _char);
//	CLASS_CON_VAR_A(int, _int, 3);
//	CLASS_CON_VAR_A(bool, _bool, 3);
//	CLASS_CON_VAR_A(float, _float, 3);
//	CLASS_CON_VAR_A(RGBcolor, _rgbcolor, 3);
//	CLASS_CON_VAR_A(RECT, _rect, 3);
};

//------------------------------------------------------------------------------------------------
//
//	hud_text_entry
//
//	ingame hud text display entry
//
//------------------------------------------------------------------------------------------------

struct hud_text_entry
{
	unsigned char		ctext[HUD_TEXT_MAX_ENTRY_LENGTH];	//entry text

	int					color;								//bitmap font color
															//0 = bmfwhite
															//1 = bmfblack
															//2 = bmfred
															//3 = bmfgreen
															//4 = bmfblue
															//5 = bmfyellow
															//6 = bmflightblue
															//7 = bmforange
															//8 = bmflightgreen

	LONGLONG			t_start;							//time index when entry was added

	//---- constructor ---------------------------------------------------------------------------

	hud_text_entry()
	{
		ZeroMemory(&ctext, sizeof(ctext));

		color			= bmfblack;

		t_start			= 0;
	};

	//---- set_entry_data ------------------------------------------------------------------------

	void set_entry_data(int _color, LONGLONG _tstart, char *ptext)
	{
		//copy text
		strcpy((char*)ctext, ptext);

		//verify color
		if (_color < 0)			_color	= 0;
		if (_color > bmfMAX)	_color	= bmfMAX;
		color		= _color;

		t_start		= _tstart;
	};
};

//------------------------------------------------------------------------------------------------
//
//	hud_text
//
//	ingame hud text display
//
//------------------------------------------------------------------------------------------------

struct hud_text
{
	hud_text_entry		*p_entry;						//pointer to all hud text entries
	int					entries;						//number of entries

	char				line_start;						//start and end symbols of hud text line
	char				line_end;

	RECT				rdim;							//screen area where to print hud text

	console				*p_con;							//pointer to console
	LONGLONG			*p_tcurrent;					//pointer to current time, set in mf constructor

	//---- constructor ---------------------------------------------------------------------------

	hud_text()
	{
		p_entry				= NULL;
		entries				= 0;

		line_start			= CON_BREAK;
		line_end			= '<';

		rdim.left			= 0;	rdim.right		= 399;
		rdim.top			= 0;	rdim.bottom		= 525;

		p_con				= NULL;
		p_tcurrent			= NULL;
	};

	//---- destructor ----------------------------------------------------------------------------

	~hud_text()
	{
		if (p_entry != NULL)
		{
			delete []	p_entry;
			p_entry		= NULL;
		}
		entries			= 0;

		p_con			= NULL;
		p_tcurrent		= NULL;
	};

	//---- clear ---------------------------------------------------------------------------------
	//deletes all entries

	void clear()
	{
		if (p_entry != NULL)
		{
			delete []	p_entry;
			p_entry		= NULL;
		}
		entries			= 0;
	};

	//---- reset_time ----------------------------------------------------------------------------
	//resets start time of all entries to current time
	//(cheap hack to display hud_text system messages at start of program/restores)

	void reset_time()
	{
		//for all entries
		for (register int e = 0; e < entries; ++e)
		{
			//set start time to current time
			p_entry[e].t_start	= *p_tcurrent;
		}
	};

	//---- add_entry -----------------------------------------------------------------------------
	//only to the end of the queue

	bool add_entry(int _color, char *format, ...)
	{
		//no text
		if (format == NULL)
		{
			gf_logger(true, "hud_text::add_entry NULL");
			return(false);
		}

		//if new entry exceeds entry limit delete first entry
		if (entries + 1 > HUD_TEXT_MAX_ENTRIES)
		{
			//print entry to console first (even if console on)
			p_con->print_outputbuffer((char*)p_entry[0].ctext);
			delete_entry(0);
		}

		//create new hud_text_entry array which is 1 element bigger than the existing one
		hud_text_entry *p_temp		= new hud_text_entry[entries + 1];

		//allocation failed
		if (p_temp == NULL)
		{
			gf_logger(true, "hud_text::add_entry allocation failed");
			return(false);
		}

		//copy old array data into new array
		for (register int i = 0; i < entries; ++i)
		{
			p_temp[i]		= p_entry[i];
		}

		//delete old array if existing
		if (p_entry)
		{
			delete []	p_entry;
		}

		//assign new array
		p_entry			= p_temp;
		p_temp			= NULL;

		//increase number of entries
		++entries;

		//----------------------------------------------------------------------------------------

		//argument pointer
		va_list	ap;
		//initialize argument pointer
		va_start(ap, format);

		//holds formatted message
		char *pbuffer	= new char[strlen(format) + 1];
		//copy message into buffer
		vsprintf(pbuffer, format, ap);
		//clear up
		va_end(ap);

		//message too long
		if (strlen(pbuffer) > HUD_TEXT_MAX_ENTRY_LENGTH - 1)
		{
			strcpy(pbuffer, "ERROR: message too long");
		}

		//assign new entry data
		//p_entry[entries - 1].set_entry_data(_color, _tcurrent, pbuffer);
		//use pointer to timer
		p_entry[entries - 1].set_entry_data(_color, *p_tcurrent, pbuffer);

		delete []	pbuffer;
		pbuffer		= NULL;

		return(true);
	};

	//---- delete_entry --------------------------------------------------------------------------

	bool delete_entry(int ie)
	{
		//no entries
		if (entries < 1)
		{
			gf_logger(true, "hud_text::delete_entry no entries");
			return(false);
		}

		//verify index
		if (ie < 0 || ie > entries - 1)
		{
			gf_logger(true, "hud_text::delete_entry invalid entry[%i]", ie);
			return(false);
		}

		//if only one entry
		if (entries == 1)
		{
			clear();
			return(true);
		}

		//create new hud_text_entry array which is 1 element smaller than the existing one
		hud_text_entry *p_temp		= new hud_text_entry[entries - 1];

		//allocation failed
		if (p_temp == NULL)
		{
			gf_logger(true, "hud_text::delete_entry allocation failed");
			return(false);
		}

		//copy old array data into new array except for delete entry
		for (register int i = 0; i < entries - 1; ++i)
		{
			//skip entry which is deleted
			if (i < ie)
			{
				p_temp[i]		= p_entry[i];
			}
			else
			{
				p_temp[i]		= p_entry[i + 1];
			}
		}

		//delete old array if existing
		if (p_entry)
		{
			delete []	p_entry;
		}

		//assign new array
		p_entry			= p_temp;
		p_temp			= NULL;

		//decrease number of entries
		--entries;

		return(true);
	};

	//---- process -------------------------------------------------------------------------------
	//called every frame, deletes entries if time up

	void process(float hud_time, LONGLONG t_freq)
	{
		//for all entries
		for (register int e = 0; e < entries; ++e)
		{
			if ((*p_tcurrent - p_entry[e].t_start) / (float)t_freq >= hud_time)
			{
				//add entry to console
				//(only if console off, else keep active)
				if (p_con->state == 0)
				{
					p_con->print_outputbuffer((char*)p_entry[e].ctext);
					//delete entry
					delete_entry(e);
				}
			}
		}
	};
};

//------------------------------------------------------------------------------------------------
//
//	recorder state frame
//
//	one state frame for ingame recorder
//
//------------------------------------------------------------------------------------------------

struct recorder_state_frame
{
	//int	fps;
	float	time_index;						//time index of frame relative to last frame

	ipoint	hara;							//hara position

	int		angle[19];						//angle, length and width for all bones
	int		length[19];
	int		width[19];

	//!! d_slot?
	int		damage[19];						//damage and hitstates for all bones
	int		hitstate[19];
	int		hitstate_e[19];

	int		fatigue;						//fatigue and stance_feet
	int		stance_feet;

	//!! in directsound.h
	//#define	NSBP								20
	int		s_buffer[20];					//0 = not playing (not TO BE stopped)
											//1 = play
											//2	= pause
											//3 = stop

	//---- constructor ----------------------------------------------------------------------------

	recorder_state_frame()
	{
		time_index			= 0;

		for (int i = 0; i < 19; ++i)
		{
			angle[i]	= length[i]		= width[i]			= 0;
			damage[i]	= hitstate[i]	= hitstate_e[i]		= 0;
		}

		fatigue		= 0;
		stance_feet	= 0;

		//!! in directsound.h
		//#define	NSBP								20
		for (i = 0; i < 20; ++i)
			s_buffer[i]			= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	demonstration
//
//	recording
//
//------------------------------------------------------------------------------------------------

struct demonstration
{
	int		frames;						//number of frames for each player

	recorder_state_frame	*p_frame;	//pointer to recorded frames

	//---- constructor ----------------------------------------------------------------------------

	demonstration()
	{
		frames			= 0;

		p_frame			= 0;
	};
};

//------------------------------------------------------------------------------------------------
//
//	recorder
//
//	to record and replay demos
//
//------------------------------------------------------------------------------------------------

struct game_recorder
{
//	demonstration	*p_demo;		//pointer to demonstration

	//pointer
	const timer		*p_time;		//pointer to timer
	const options	*p_option;		//pointer to options
	const player	*P[2];			//pointer to players

	FILE	*f_demo;				//demo recording file
	char	demo_name[256];			//demo name

	bool	recording;				//flag if recording/replaying
	bool	replaying;

	LONGLONG	t_rec_start;		//time index of demo recording start

	//---- constructor ----------------------------------------------------------------------------

	game_recorder()
	{
//		p_demo			= NULL;

		p_time			= NULL;
		P[P1]			= NULL;
		P[P2]			= NULL;

		f_demo			= NULL;
		demo_name[0]	= '\0';

		recording		= false;
		replaying		= false;

		t_rec_start		= 0;
	};

	//---- destructor -----------------------------------------------------------------------------

	~game_recorder()
	{
		//alle laufenden demos beenden
	};

	//---- set data pointer  ----------------------------------------------------------------------
	//data pointers

	void set_data_pointer(timer *_time, options *_option, player *pl1, player *pl2)
	{
		p_time		= _time;
		p_option	= _option;
		P[P1]		= pl1;
		P[P2]		= pl2;
	};

	//---- functions ------------------------------------------------------------------------------

	bool process()
	{
		return(true);
	};

	//---- recording start ------------------------------------------------------------------------

	bool record_start(int round = 0)
	{
		//already recording
		if (recording)
		{
			gf_logger(true, "game_recorder::rec_start Already Recording! \"%s\"", demo_name);
			return(false);
		}

		//get file and open to record to
		if (!attain_file(round))
		{
			gf_logger(true, "game_recorder::rec_start Attain File FAILED!");
			return(false);
		}

		//if file successfully attained

		//set recording on
		recording		= true;

		//set time data
		t_rec_start		= p_time->current;

		//write file header
		//format:
		//"YYYY-MM-DD HH:MM.SS NAME_PLAYER_1 Vs. NAME_PLAYER_2 ROUND X"

		//get current date and time
		//time and date string
		char td[128]	= "";
		//time struct
		tm *t;
		time_t ltime;
		//get system time in ltime, adjust to local time
		time(&ltime);
		t = localtime(&ltime);
		//format time string "YYYY-MM-DD HH:MM.SS"
		strftime(td, 127, "%Y-%m-%d %H:%M.%S - ", t);
		fprintf(f_demo,
				"%s", td);

		//name of both players
		fprintf(f_demo,
				"%s Vs. %s", p_option->data.name[P1], p_option->data.name[P2]);
		//round if argumented
		if (round > 0 && round < 10)
		{
			fprintf(f_demo,
					" - Round %i\n", round);
		}

		//log recording
		gf_logger(false, "game_recorder::rec_start DEMO recording started \"%s\"", demo_name);

		return(true);
	};

	//---- attain file ----------------------------------------------------------------------------

	bool attain_file(int round)
	{
		//create demo folder
		_mkdir("replays");

		//create file name
		//format:
		//replay_000.bmd
		//old:
		//YEAR-MO-DA HH.MM.SS - Name1 Vs. Name2 - Round x.bmd
//		strcpy(demo_name, "demos/replay_");

		//get demo file index
		int dfi				= 0;				//demo file index
		char index[4]		= "";				//file index as string

		//try to open demo file
		//as long as file exists, increase index
		//if option.data.demo_maxfiles files exist the last one will be overwritten
		for (dfi = 0; dfi < p_option->data.demo_maxfiles; ++dfi)
		{
			//create file names to open
			//add zeros in front
			if (dfi < 10)
				strcpy(demo_name, "replays/replay_00");
			if (dfi > 9 && dfi < 100)
				strcpy(demo_name, "replays/replay_0");
			if (dfi > 99)
				strcpy(demo_name, "replays/replay_");

			//convert index integer to string
			_itoa(dfi, index, 10);
			//append index to filename
			strcat(demo_name, index);
			//append file ending to filename
			strcat(demo_name, ".bmd");

			//exit loop if no such file found
			//(read, binary)
			FILE *f = fopen(demo_name, "rb");
			if (f == NULL)
			//if (fopen(demo_name, "rb") == NULL)
			{
				break;
			}
			else
			{
				//close file
				//(unassigned pointer to file of previous versions causes remaining unclosed files)
				fclose(f);
			}
		}

/*		//get current date and time
		//time and date string
		char td[128]	= "";
		//time struct
		tm *t;
		time_t ltime;
		//get system time in ltime, adjust to local time
		time(&ltime);
		t = localtime(&ltime);
		//format time string "YYYY-MM-DD HH.MM.SS"
		strftime(td, 127, "%Y-%m-%d %H.%M.%S - ", t);
		strcat(demo_name, td);*/

/*		//get current date and time into buffer
		char b_date[9]				= {0};
		char b_time[9]				= {0};
		_strdate(b_date);
		_strtime(b_time);
		b_date[2]	= '-';
		b_date[5]	= '-';
		b_time[2]	= '.';
		b_time[5]	= '\0';
		strcat(demo_name, b_date);
		strcat(demo_name, " ");
		strcat(demo_name, b_time);
		strcat(demo_name, " - ");*/

/*		//name of both players
		strcat(demo_name, p_option->data.name[P1]);
		strcat(demo_name, " Vs. ");
		strcat(demo_name, p_option->data.name[P2]);
		//round if argumented
		if (round > 0 && round < 10)
		{
			strcat(demo_name, " - Round ");
			char cr[2] = "";
			_itoa(round, cr, 10);
			strcat(demo_name, cr);
		}
		//file ending
		strcat(demo_name, ".bmd");*/

		//open file
		//(overwrite, binary)
		f_demo			= fopen(demo_name, "wb");

		//error on opening
		if (f_demo == NULL)
		{
			gf_logger(true, "game_recorder::attain_file() fopen FAILED %s", demo_name);

			//delete demo name
			demo_name[0]	= '\0';

			return(false);
		}

		return(true);
	};

	//---- record ---------------------------------------------------------------------------------

	//in master_frame.cpp
	bool record();

	//---- replay start ---------------------------------------------------------------------------

	bool replay_start()
	{
		//no playback when still recording or alreayd playing back
		if (recording || replaying)
		{
			gf_logger(true, "game_recorder::replay_start Already Replaying/Still Recording! \"%s\"", demo_name);
			return(false);
		}

		//? wie header auslesen?

//file header
/*
	int c = 0;
	bool loop = true;
	byte res = -1;
	while(loop && c < 1000)
	{
		++c;
		fscanf(f, "%c", &res);
		gf_logger(true, "%c", res);
		if (res == '\n')
			loop = false;
	}

/*		//open file if name valid
		//(read)
		if (pname != NULL)
			f_

//open file (read) if name valid
if (pname != NULL)
{
	f_demo_pb		= fopen(pname, "rb");
}
else
{
	//log playback
	gf_logger(true, "DEMO playback sdemo_startplay failed %s", pname);
	return false;
}

//if files successfully opened
if (f_demo_pb != NULL)
{
	//set time data
	t_dpb_start				= time.current;
	t_dpb_lastframe			= 0;

	//read file header
	fscanf(f_demo_pb, "%*i");

	//set playback on
	demo_playback	= true;

	//log playback
	gf_logger(false, "DEMO playback started %s", pname);
}
else
{
	//log playback
	gf_logger(true, "DEMO playback sdemo_startplay failed %s", pname);
	return false;
}

return true;*/
	};

	bool replay()
	{
		return(true);
	};

	//---- stop -----------------------------------------------------------------------------------

	bool stop()
	{
		//if recording a demo
		if (recording && f_demo != NULL)
		{
			//write file end
			//!!

			//close demo file
			fclose(f_demo);
			//nullify
			f_demo			= NULL;
			//delete demo name
			//demo_name[0]	= '\0';

			//reset time data
			t_rec_start		= 0;

			//stop recording
			recording	= false;

			//log recording
			gf_logger(false, "game_recorder::stop DEMO recording stopped \"%s\"", demo_name);

			return(true);
		}
		else
		{
			gf_logger(true, "game_recorder::stop Not Recording");

			//no demo recording
			return(false);
		}
	};
};

//------------------------------------------------------------------------------------------------
//
//	bot_queue_event_state
//
//
//
//------------------------------------------------------------------------------------------------

struct bot_queue_event_state
{
	int					action_index;		//action index (PA index)
											//-1 = not valid
	int					state;				//#defined action index state

	//---- constructor ---------------------------------------------------------------------------

	bot_queue_event_state()
	{
		action_index			= -1;
		state					= -1;
	};

	//---- set_state -----------------------------------------------------------------------------

	void set_state(int _action_index, int _state)
	{
		action_index		= _action_index;
		state				= _state;
	};
};

//------------------------------------------------------------------------------------------------
//
//	bot_queue_event
//
//
//
//------------------------------------------------------------------------------------------------

struct bot_queue_event
{
	float				t_;					//time in seconds of event after previous event or
											//if first event after event start
	int					angle;				//angle of event
	int					angle_180;			//angle 180 of event

	float				distance;			//distance to other player

	bot_queue_event_state	*p_estate;		//pointer to bot_queue_event_state array
	int					elements;			//number of elements of p_estate array

	//---- constructor ---------------------------------------------------------------------------

	bot_queue_event()
	{
		reset();
	};

	//---- destructor ----------------------------------------------------------------------------

	~bot_queue_event()
	{
		if (p_estate)
		{
			delete []			p_estate;
			p_estate			= NULL;
		}
		elements			= 0;
	};

	//---- reset ---------------------------------------------------------------------------------
	//called by constructor and
	//in bot_action_queue::add_event() when a new array with bot_queue_event is
	//allocated
	//the values (including pointer address) are copied into the new array and
	//this objects values get reset so the destructor doesn't try to delete
	//the allocated bot_queue_event_state array which doesn't belong to the object anymore

	void reset()
	{
		t_				= 0;

		angle			= 0;
		angle_180		= 0;

		distance		= 0;

		p_estate		= NULL;
		elements		= 0;
	};

	//---- set_state -----------------------------------------------------------------------------

	void set_event(float _t_, int _angle, int _angle_180, float _distance)
	{
		t_				= _t_;
		angle			= _angle;
		angle_180		= _angle_180;
		distance		= _distance;
	}

	//---- add_estate ----------------------------------------------------------------------------
	//returns false if allocation failed

	bool add_estate(int _action_index, int _state)
	{
		//create new bot_queue_event_state array which is 1 element bigger than the existing one
		bot_queue_event_state *p_temp		= new bot_queue_event_state[elements + 1];

		//allocation failed
		if (p_temp == NULL)
		{
			gf_logger(true, "bot_queue_event::add_estate allocation failed");
			return(false);
		}

		//copy old array data into new array
		for (register int i = 0; i < elements; ++i)
		{
			p_temp[i]		= p_estate[i];
		}

		//delete old array if existing
		if (p_estate)
		{
			delete []			p_estate;
		}

		//assign new array
		p_estate			= p_temp;
		p_temp				= NULL;

		//increase number of elements counter
		++elements;

		//assign new data
		p_estate[elements - 1].set_state(_action_index, _state);

		return(true);
	};
};

//------------------------------------------------------------------------------------------------
//
//	bot_action_queue
//
//
//
//------------------------------------------------------------------------------------------------

struct bot_action_queue
{
	bot_queue_event			*p_event;			//pointer to array with bot_queue_event elements
	int						elements;			//number of bot_queue_event elements
												//current maximum events

	int						elements_allocate;	//number of bot_queue_events allocated ahead

	//---- constructor ---------------------------------------------------------------------------

	bot_action_queue()
	{
		reset();
	};

	//---- destructor ----------------------------------------------------------------------------

	~bot_action_queue()
	{
		if (p_event)
		{
			delete []			p_event;
			p_event				= NULL;
		}
		elements			= 0;
		elements_allocate	= 0;
	};

	//---- reset ---------------------------------------------------------------------------------

	void reset()
	{
		p_event				= NULL;
		elements			= 0;
		elements_allocate	= 0;
	};

	//---- del_queue -----------------------------------------------------------------------------
	//deletes all events

	void del_queue()
	{
		if (p_event)
		{
			delete []				p_event;
			p_event					= NULL;
			elements				= 0;
			elements_allocate		= 0;
		}
	};

	//---- add_event -----------------------------------------------------------------------------
	//allocates 1 new event and fills it with argumented data
	//returns false if allocation fails

	bool _OLD_add_event(float _toffset, int _angle, int _angle_180, float _distance)
	{
		//create new bot_queue_event array which is 1 element bigger than the existing one
		bot_queue_event *p_temp		= new bot_queue_event[elements + 1];

		//allocation failed
		if (p_temp == NULL)
		{
			gf_logger(true, "bot_action_queue::add_event allocation failed");
			return(false);
		}

		//copy old array data into new array
		//(pointer flat copy)
		for (register int i = 0; i < elements; ++i)
		{
			p_temp[i]		= p_event[i];
			//reset *p_estate pointer to NULL
			//so it isn't tried to get deleted by the destructor when old array is
			//deleted below
			p_event[i].reset();
		}

		//delete old array if existing
		if (p_event)
		{
			delete []			p_event;
		}

		//assign new array
		p_event				= p_temp;
		p_temp				= NULL;

		//increase number of elements counter
		++elements;

		//assign new data
		p_event[elements - 1].set_event(_toffset, _angle, _angle_180, _distance);

		return(true);
	};

	//---- add_event -----------------------------------------------------------------------------
	//allocates BAQ_EAQ amount of events ahead when new elements needed instead of only 1
	//returns false if allocation fails

	bool add_event(float _toffset, int _angle, int _angle_180, float _distance)
	{
		//if number of current events plus 1 is bigger than events already allocated
		if (elements + 1 > elements_allocate)
		{
			//verify number of events to allocate
			if (BAQ_EAQ < 1)
			{
				gf_logger(true, "bot_action_queue::#define BAQ_EAQ < 1: %i", BAQ_EAQ);
				return(false);
			}

			//create new bot_queue_event array which is BAQ_EAQ elements bigger than the existing one
			bot_queue_event *p_temp		= new bot_queue_event[elements + BAQ_EAQ];

			//allocation failed
			if (p_temp == NULL)
			{
				gf_logger(true, "bot_action_queue::add_event allocation failed");
				return(false);
			}

			//copy old array data into new array
			//(pointer flat copy)
			for (register int i = 0; i < elements; ++i)
			{
				p_temp[i]		= p_event[i];
				//reset *p_estate pointer to NULL
				//so it isn't tried to get deleted by the destructor when old array is
				//deleted below
				p_event[i].reset();
			}

			//delete old array if existing
			if (p_event)
			{
				delete []			p_event;
			}

			//assign new array
			p_event				= p_temp;
			p_temp				= NULL;

			//increase number of events allocated counter
			elements_allocate	+= BAQ_EAQ;
			//gf_logger(true, "elements: %i, allocated: %i", elements, elements_allocate);
		}

		//increase number of elements counter
		++elements;

		//assign new data
		p_event[elements - 1].set_event(_toffset, _angle, _angle_180, _distance);

		return(true);
	};
};

#endif										//end STRUCTS_H